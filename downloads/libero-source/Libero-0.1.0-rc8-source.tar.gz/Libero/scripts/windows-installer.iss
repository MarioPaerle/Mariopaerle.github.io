#ifndef Payload
  #error Payload must point to the packaged Windows files
#endif
#ifndef ReleaseLabel
  #define ReleaseLabel "0.1.0-rc4"
#endif
[Setup]
AppId={{037380BC-C477-4AD0-9BCE-85DFEF4D289E}
AppName=Libero
AppVersion={#ReleaseLabel}
AppPublisher=Libero
DefaultDirName={commoncf64}\VST3\Libero.vst3
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir={#ReleaseOutput}
OutputBaseFilename=Libero-{#ReleaseLabel}-Windows-x64-Setup
Compression=lzma2
SolidCompression=yes
LicenseFile=..\LICENSE
UninstallFilesDir={commonappdata}\Libero\Uninstall
WizardStyle=modern
SetupIconFile=..\docs\assets\libero-icon.ico
CloseApplications=no

[Files]
Source: "{#Payload}\Libero.vst3\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#Payload}\Notices\*"; DestDir: "{app}\Contents\Resources\Notices"; Flags: ignoreversion
Source: "{#Payload}\LICENSE"; DestDir: "{app}\Contents\Resources\Notices"; Flags: ignoreversion
Source: "{#Payload}\NOTICE"; DestDir: "{app}\Contents\Resources\Notices"; Flags: ignoreversion

[Messages]
FinishedLabel=Libero is installed. Open your DAW and rescan VST3 plugins. Import downloaded .liberobank files inside Libero. If its interface requests WebView2, install Microsoft's Evergreen Runtime. Your sound library is stored separately and is preserved when uninstalling.
