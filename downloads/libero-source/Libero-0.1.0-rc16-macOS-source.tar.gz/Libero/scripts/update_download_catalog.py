#!/usr/bin/env python3
"""Prepare the in-app catalogue after verified release files have been uploaded."""
import argparse, hashlib, json, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

def drive_url(value):
    if not value or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in value):
        raise ValueError('Pass the verified public Drive file ID, not a private download URL.')
    return f'https://drive.usercontent.google.com/download?id={value}&export=download&confirm=t'

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--pack', type=Path); p.add_argument('--drive-id')
    p.add_argument('--build', type=int); p.add_argument('--version')
    p.add_argument('--mac', type=Path); p.add_argument('--mac-drive-id')
    p.add_argument('--windows', type=Path); p.add_argument('--windows-drive-id')
    a = p.parse_args(); catalog = json.loads((ROOT/'data/pack-catalog.json').read_text())
    if a.pack:
        with zipfile.ZipFile(a.pack) as z:
            name = next(n for n in z.namelist() if n.count('/') == 1 and n.endswith('/bank.json'))
            meta = json.loads(z.read(name)); manifests = [json.loads(z.read(n)) for n in z.namelist() if n.endswith('/build/manifest.json')]
            row = {'id':meta['slug'], 'title':meta['title'], 'version':meta['version'], 'sounds':len(manifests), 'bytes':a.pack.stat().st_size,
                   'uncompressed_bytes':sum(n.file_size for n in z.infolist()), 'sha256':sha(a.pack), 'url':drive_url(a.drive_id), 'instruments':[m['title'] for m in manifests]}
        catalog['packs'] = [r for r in catalog['packs'] if r['id'] != row['id']] + [row]
    if a.build:
        if not all([a.version,a.mac,a.mac_drive_id,a.windows,a.windows_drive_id]): p.error('Release updates need both platform files/IDs and a version.')
        if a.build <= catalog.get('release',{}).get('build',0): p.error('Release build number must increase.')
        with zipfile.ZipFile(a.mac) as z: expanded = sum(i.file_size for i in z.infolist())
        catalog['release'] = {'build':a.build,'version':a.version,'packages':{
            'macos':{'bytes':a.mac.stat().st_size,'uncompressed_bytes':expanded,'sha256':sha(a.mac),'url':drive_url(a.mac_drive_id)},
            'windows':{'bytes':a.windows.stat().st_size,'uncompressed_bytes':max(50_000_000,a.windows.stat().st_size*3),'sha256':sha(a.windows),'url':drive_url(a.windows_drive_id)}}}
    if not a.pack and not a.build: p.error('Select --pack or --build.')
    raw = json.dumps(catalog,indent=2)+'\n'; (ROOT/'data/pack-catalog.json').write_text(raw)
    (ROOT/'ui/js/pack-catalog.json').write_text(raw)
    (ROOT/'plugin/src/PackCatalogue.h').write_text('#pragma once\nnamespace libero::packs { inline constexpr auto fallbackCatalogue = R"CATALOG('+raw+')CATALOG"; }\n')
    print('Catalogue prepared. Publish data/pack-catalog.json as libero-catalog.json on the Pages site after anonymous download and source-availability checks.')

if __name__ == '__main__': main()
