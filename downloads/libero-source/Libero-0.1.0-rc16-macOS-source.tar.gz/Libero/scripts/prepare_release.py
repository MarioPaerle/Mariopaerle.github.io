#!/usr/bin/env python3
"""Stage macOS binaries and their corresponding source without publishing them."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import re
import shutil
import subprocess
import tarfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(*args: str, cwd: Path = ROOT) -> str:
    return subprocess.check_output(args, cwd=cwd, text=True).strip()


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def source_files() -> list[Path]:
    """Include working changes and submodule sources, excluding build/cache output."""
    names = subprocess.check_output(
        ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"], cwd=ROOT
    ).decode().split("\0")
    files = {ROOT / name for name in names if name and (ROOT / name).is_file()}
    juce = ROOT / "third_party/JUCE"
    names = subprocess.check_output(["git", "ls-files", "-z"], cwd=juce).decode().split("\0")
    files.update(juce / name for name in names if name and (juce / name).is_file())
    return sorted(files)


def archive_sources(out: Path, label: str):
    files = source_files()
    inventory = [{"path": p.relative_to(ROOT).as_posix(), "sha256": digest(p)} for p in files]
    source_digest = hashlib.sha256(json.dumps(inventory, sort_keys=True).encode()).hexdigest()
    archive_path = out / f"Libero-{label}-source.tar.gz"
    with tarfile.open(archive_path, "w:gz") as archive:
        for path in files:
            archive.add(path, arcname="Libero/" + path.relative_to(ROOT).as_posix(), recursive=False)
    return archive_path, inventory, source_digest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-dir", type=Path, default=ROOT / "build")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--label", default="0.1.0-rc1", help="Download version label")
    parser.add_argument("--banks-dir", type=Path, help="Verified banks to include in a complete-download ZIP")
    parser.add_argument("--source-only", action="store_true", help="Archive corresponding sources on any platform")
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:-[a-z0-9.]+)?", args.label):
        parser.error("label must be a version such as 0.1.0-rc1")
    out = args.output.expanduser().resolve()
    if out.exists():
        parser.error("output already exists; use a new staging directory")
    if out == ROOT or (ROOT in out.parents and not args.source_only):
        parser.error("stage outside the source tree")
    if ROOT in out.parents:
        ignored = subprocess.run(["git", "check-ignore", "--quiet", str(out)], cwd=ROOT)
        if ignored.returncode:
            parser.error("source staging inside the repo must use an ignored build directory")
    if args.source_only:
        out.mkdir(parents=True)
        archive, inventory, source_digest = archive_sources(out, args.label)
        (out / "source-inventory.json").write_text(json.dumps({"source_commit": run("git", "rev-parse", "HEAD"),
            "source_inventory_sha256": source_digest, "files": inventory}, indent=2) + "\n")
        print(archive)
        return

    artifacts = args.build_dir.resolve() / "plugin"
    inputs = {
        "Libero.vst3": artifacts / "Libero_artefacts/Release/VST3/Libero.vst3",
        "Libero.component": artifacts / "Libero_artefacts/Release/AU/Libero.component",
        "libero-render": artifacts / "libero_render_artefacts/Release/libero-render",
    }
    missing = [str(path) for path in inputs.values() if not path.exists()]
    if missing:
        parser.error("missing build outputs: " + ", ".join(missing))
    if platform.system() != "Darwin":
        parser.error("this packager verifies macOS build outputs")

    binaries = {}
    for name, path in inputs.items():
        executable = path / "Contents/MacOS/Libero" if path.is_dir() else path
        arches = run("lipo", "-archs", str(executable)).split()
        if set(arches) != {"arm64", "x86_64"}:
            parser.error(f"{name} is not universal: {arches}")
        binaries[name] = {"architectures": arches, "sha256": digest(executable)}

    out.mkdir(parents=True)
    payload = out / "Libero-macOS"
    payload.mkdir()
    for name, path in inputs.items():
        dest = payload / name
        if path.is_dir():
            shutil.copytree(path, dest)
        else:
            shutil.copy2(path, dest)
    for bundle in (payload / "Libero.vst3", payload / "Libero.component"):
        run("codesign", "--force", "--deep", "--sign", "-", str(bundle))
        run("codesign", "--verify", "--deep", "--strict", str(bundle))
        binaries[bundle.name]["sha256"] = digest(bundle / "Contents/MacOS/Libero")
    notices = payload / "Notices"
    notices.mkdir()
    for name in ("LICENSE.md", "JUCE.spdx.json"):
        shutil.copy2(ROOT / "third_party/JUCE" / name, notices / ("JUCE-" + name))
    for path in (ROOT / "ui/fonts").glob("OFL-*.txt"):
        shutil.copy2(path, notices / path.name)
    shutil.copy2(ROOT / "docs/release/install-macos.md", payload / "INSTALL.md")
    shutil.copy2(ROOT / "scripts/macos-install.command", payload / "Install Libero.command")
    license_path = ROOT / "LICENSE"
    blockers = []
    if license_path.is_file():
        shutil.copy2(license_path, payload / "LICENSE")
    else:
        blockers.append("Project software license has not been chosen.")
    if (ROOT / "NOTICE").is_file():
        shutil.copy2(ROOT / "NOTICE", payload / "NOTICE")

    signatures = {}
    for name in inputs:
        path = payload / name
        result = subprocess.run(
            ["codesign", "--verify", "--deep", "--strict", str(path)],
            capture_output=True, text=True,
        )
        detail = subprocess.run(
            ["codesign", "-dv", "--verbose=2", str(path)], capture_output=True, text=True
        )
        signatures[name] = {"valid": result.returncode == 0, "details": detail.stderr.strip()}
        if result.returncode or "Signature=adhoc" in detail.stderr:
            blockers.append(f"{name}: Developer ID signing and notarization pending.")

    source_archive, inventory, source_digest = archive_sources(out, args.label)
    plugin_archive = out / f"Libero-{args.label}-macOS.zip"
    shutil.make_archive(str(plugin_archive.with_suffix("")), "zip", out, payload.name)
    archives = [plugin_archive, source_archive]
    bank_summary = None
    if args.banks_dir is not None:
        bank_dir = args.banks_dir.expanduser().resolve()
        catalog = json.loads((bank_dir / "catalog.json").read_text())
        bank_files = []
        for item in catalog["packs"]:
            name = item["file"]
            if Path(name).name != name or not name.endswith(".liberobank"):
                parser.error(f"invalid bank filename: {name}")
            path = bank_dir / name
            if not path.is_file() or digest(path) != item["sha256"]:
                parser.error(f"bank checksum mismatch: {name}")
            bank_files.append(path)
        complete = out / f"Libero-{args.label}-complete.zip"
        with zipfile.ZipFile(complete, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
            archive.write(plugin_archive, "Plugin/" + plugin_archive.name)
            for path in bank_files:
                archive.write(path, "Banks/" + path.name)
            for name in ("catalog.json", "SHA256SUMS", "SOUND-DATA-TERMS.md"):
                archive.write(bank_dir / name, "Banks/" + name)
            archive.write(ROOT / "docs/release/install-macos.md", "INSTALL.md")
            archive.writestr("README.txt", "Extract this archive. Install the plugin from Plugin/, then import the .liberobank files in Banks/ through Libero's Library. Each package installs one collection. Review the import summary before installing or updating. Sources are a separate download beside this release.\n")
        archives.append(complete)
        bank_summary = {"presets": catalog["preset_count"], "packs": len(bank_files),
                        "compressed_bytes": sum(p.stat().st_size for p in bank_files),
                        "catalog_sha256": digest(bank_dir / "catalog.json")}
    report = {
        "format": "libero.release-stage/1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "version": "0.1.0",
        "release_label": args.label,
        "status": "LOCAL DRAFT — NOT PUBLISHED",
        "publication_blockers": sorted(set(blockers)),
        "source_commit": run("git", "rev-parse", "HEAD"),
        "working_tree_changes": run("git", "status", "--porcelain"),
        "source_inventory_sha256": source_digest,
        "juce_commit": run("git", "rev-parse", "HEAD", cwd=ROOT / "third_party/JUCE"),
        "cmake_version": run("cmake", "--version").splitlines()[0],
        "compiler_version": run("clang", "--version").splitlines()[0],
        "binaries": binaries,
        "signatures": signatures,
        "banks": bank_summary,
        "source_inventory": inventory,
        "archives": [{"file": p.name, "bytes": p.stat().st_size, "sha256": digest(p)} for p in archives],
    }
    (out / "release-manifest.json").write_text(json.dumps(report, indent=2) + "\n")
    (out / "SHA256SUMS").write_text("".join(f"{digest(p)}  {p.name}\n" for p in archives))
    print(json.dumps({"output": str(out), "archives": report["archives"], "blockers": report["publication_blockers"]}, indent=2))


if __name__ == "__main__":
    main()
