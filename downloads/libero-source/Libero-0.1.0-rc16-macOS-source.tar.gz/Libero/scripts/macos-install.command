#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
printf 'Close your DAW before continuing. Press Return to install Libero, or Control-C to cancel.\n'
read -r
plugin_root="${LIBERO_INSTALL_ROOT:-$HOME/Library/Audio/Plug-Ins}"
destinations=("$plugin_root/VST3" "$plugin_root/Components")
names=("Libero.vst3" "Libero.component")
committed=0
moved=(0 0)
activated=(0 0)
rollback() {
    if [[ "$committed" == 0 ]]; then
        for i in 0 1; do
            destination="${destinations[$i]}"
            if [[ "${activated[$i]}" == 1 ]]; then rm -rf "$destination/${names[$i]}"; fi
            if [[ "${moved[$i]}" == 1 ]]; then
                rm -rf "$destination/${names[$i]}"
                mv "$destination/.${names[$i]}.previous" "$destination/${names[$i]}"
            fi
            rm -rf "$destination/.${names[$i]}.update-$$"
        done
    fi
}
trap rollback EXIT
# Stage and verify both formats before replacing either installed plugin.
for i in 0 1; do
    destination="${destinations[$i]}"
    source_bundle="${names[$i]}"
    [[ -d "$source_bundle" ]] || { printf 'Missing %s. Installation stopped.\n' "$source_bundle"; exit 1; }
    codesign --verify --deep --strict "$source_bundle"
    mkdir -p "$destination"
    [[ ! -e "$destination/.$source_bundle.previous" ]] || { printf 'A previous installation needs recovery in %s. Installation stopped.\n' "$destination"; exit 1; }
    ditto "$source_bundle" "$destination/.$source_bundle.update-$$"
done
for i in 0 1; do
    destination="${destinations[$i]}"
    source_bundle="${names[$i]}"
    if [[ -e "$destination/$source_bundle" ]]; then
        mv "$destination/$source_bundle" "$destination/.$source_bundle.previous"
        moved[$i]=1
    fi
    mv "$destination/.$source_bundle.update-$$" "$destination/$source_bundle"
    activated[$i]=1
    xattr -dr com.apple.quarantine "$destination/$source_bundle" 2>/dev/null || true
done
committed=1
for i in 0 1; do rm -rf "${destinations[$i]}/.${names[$i]}.previous"; done
printf 'Libero installed. Reopen your DAW and rescan plugins if needed. Your sound library is unchanged.\n'
