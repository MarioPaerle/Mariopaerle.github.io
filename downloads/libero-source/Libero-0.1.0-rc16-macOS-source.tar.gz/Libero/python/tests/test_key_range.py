"""Authored sample ranges survive compilation, recompile and native playback."""
import json

import numpy as np
import pytest

from libero import Sound, render
from libero.compiler import compile_sound
from libero.recipe import RecipeError
from libero import library


@pytest.mark.parametrize("bounds", [(-1, 90), (21, 128), (90, 21), (True, 90), (21, 90.0)])
def test_key_range_rejects_invalid_bounds(bounds):
    with pytest.raises(RecipeError):
        Sound("Bounds").key_range(*bounds)


def test_generated_range_recompiles_and_native_exterior_is_silent(tmp_path):
    folder = tmp_path / "bounded-synth"
    folder.mkdir()
    (folder / "sound.py").write_text("""from libero import Sound, synth
sound = Sound('Bounded Synth', roots=[48, 72], velocities=[80, 120], tags=['synth'])
sound.key_range(40, 80)
sound.defaults(rev_mix=0, amp_attack=0, amp_release=5, lvl_air=-60)
sound.performance(humanize={'cents':0,'ms':0,'db':0})
@sound.body
def body(ctx):
    return synth.sine(ctx.freq, .4, sr=ctx.sr).gain_db(-12)
""")
    results = []
    for _ in range(2):
        compiled = compile_sound(folder, jobs=1)
        assert compiled.ok, compiled.error
        manifest = json.loads((folder / 'build/manifest.json').read_text())
        assert manifest['key_range'] == [40, 80]
        assert library.validate_bundle(folder / 'build') == []
        mapping = {(z['root'], z['lo'], z['hi']) for z in manifest['zones'] if z['layer']=='body'}
        assert mapping == {(48, 40, 60), (72, 61, 80)}
        results.append(mapping)
    assert results[0] == results[1]
    if render.find_renderer() is None:
        pytest.skip('native renderer unavailable after compiler checks')
    for note in [39, 40, 80, 81]:
        wav = tmp_path / f'n{note}.wav'
        render.render(folder, wav, f'{note}:0:.15:127', tail=.1)
        audio = render.Audio.load(wav)
        peak = float(np.max(np.abs(audio.data)))
        assert peak > .005 if note in (40, 80) else peak == 0, (note, peak)
