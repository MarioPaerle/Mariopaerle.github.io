"""The recipe API (SPEC §3): a `Sound` with decorated layer functions.

    from libero import Sound, Audio, synth, load

    sound = Sound(title="Lira", roots=[36, 48, 60, 72, 84])

    @sound.body
    def body(ctx):
        return synth.karplus(ctx.freq, dur=4.0, sr=ctx.sr, seed=ctx.seed)

Layer functions receive a `Ctx` and return an `Audio` (or None to omit the layer).
"""

from __future__ import annotations

import hashlib
import importlib.util
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from . import dsp, params
from .audio import Audio, set_search_dirs

LAYERS = ("body", "attack", "tail", "air", "impulse")


class RecipeError(Exception):
    pass


@dataclass
class Layer:
    name: str
    fn: Callable
    pitched: bool


@dataclass
class LoopSpec:
    body: bool = False
    tail: bool = False
    min_seconds: float = 0.4
    region: tuple[float, float] | None = None


@dataclass
class Ctx:
    """What a layer function knows about the zone it is rendering.

    note      MIDI root being rendered (60 for unpitched layers)
    freq      its frequency in Hz (A4 = 440)
    velocity  1..127;  vel = velocity / 127
    sr        sample rate to render at
    samples   Path of the sound's samples/ folder
    folder    Path of the sound folder
    seed      deterministic per (layer, note, velocity, take): use it for every random choice
    take      0..takes-1: which round-robin take is being rendered (vary the performance with it)
    dyn       0..1 position on the dynamics axis when the sound declares `dynamics=[...]`
              (else velocity / 127): render soft layers darker, not just quieter
    layer     'body' | 'attack' | 'tail' | 'air' | 'impulse'
    roots     all roots of the sound; velocities likewise
    """

    note: int
    velocity: int
    sr: int
    samples: Path
    folder: Path
    seed: int
    layer: str
    roots: tuple[int, ...] = ()
    velocities: tuple[int, ...] = ()
    take: int = 0
    takes: int = 1
    dyn_value: float | None = None

    @property
    def dyn(self) -> float:
        return self.velocity / 127.0 if self.dyn_value is None else self.dyn_value

    @property
    def freq(self) -> float:
        return dsp.midi_to_freq(self.note)

    @property
    def vel(self) -> float:
        return self.velocity / 127.0

    @property
    def note_name(self) -> str:
        return dsp.note_name(self.note)

    @property
    def register(self) -> float:
        """0 at the lowest root, 1 at the highest: handy for pitch-dependent choices."""
        if len(self.roots) < 2:
            return 0.5
        lo, hi = min(self.roots), max(self.roots)
        return (self.note - lo) / (hi - lo) if hi > lo else 0.5

    def load(self, name: str, sr: int | None = None) -> Audio:
        """Load a file from samples/ (resampled to ctx.sr unless sr is given)."""
        p = Path(name)
        if not p.is_absolute():
            cand = self.samples / p
            if not cand.exists() and cand.suffix == "":
                cand = cand.with_suffix(".wav")
            p = cand
        return Audio.load(p, sr=sr or self.sr)

    def has(self, name: str) -> bool:
        """True if samples/<name> exists (so a recipe can fall back to synthesis)."""
        p = self.samples / name
        return p.exists() or (p.suffix == "" and p.with_suffix(".wav").exists())


class Sound:
    """A sound recipe. See the module docstring and SPEC §3."""

    def __init__(self, title: str, subtitle: str = "", tags: list[str] | tuple[str, ...] = (),
                 roots: list[int] | tuple[int, ...] = (48, 60, 72), velocities: list[int] | tuple[int, ...] = (100,),
                 sample_rate: int = 48000, accent: str | None = None, seed: int = 0, takes: int = 1,
                 dynamics: list[float] | tuple[float, ...] | None = None):
        if not title:
            raise RecipeError("Sound needs a title")
        self.title = str(title)
        self.subtitle = str(subtitle)
        self.tags = [str(t) for t in tags]
        roots = sorted({dsp.parse_note(r) for r in roots})
        if not roots or any(not 0 <= r <= 127 for r in roots):
            raise RecipeError(f"roots must be MIDI notes 0..127, got {roots}")
        vels = sorted({int(v) for v in velocities})
        if not vels or any(not 1 <= v <= 127 for v in vels):
            raise RecipeError(f"velocities must be 1..127, got {vels}")
        if sample_rate not in (44100, 48000, 88200, 96000):
            raise RecipeError("sample_rate must be 44100, 48000, 88200 or 96000")
        if accent is not None and not (isinstance(accent, str) and accent.startswith("#") and len(accent) in (4, 7)):
            raise RecipeError("accent must be a CSS hex colour like '#c9a86a'")
        self.roots = tuple(roots)
        self.velocities = tuple(vels)
        self.sample_rate = int(sample_rate)
        self.accent = accent
        self.seed = int(seed)
        from .library import MAX_TAKES
        if isinstance(takes, bool) or not isinstance(takes, int) or not 1 <= takes <= MAX_TAKES:
            raise RecipeError(f"takes must be an integer 1..{MAX_TAKES}, got {takes!r}")
        self.takes = int(takes)
        if dynamics is not None:
            dyn = sorted({float(d) for d in dynamics})
            if not dyn or any(not 0 < d <= 1 for d in dyn):
                raise RecipeError(f"dynamics must be positions in 0 < d <= 1, got {dynamics!r}")
            if len(self.velocities) > 1:
                raise RecipeError("use either velocities=[...] or dynamics=[...], not both")
            self.dynamics: tuple[float, ...] | None = tuple(dyn)
        else:
            self.dynamics = None
        self.multisamples: dict = {}
        self.performance_spec: dict = {}
        self.key_range_spec: tuple[int, int] | None = None
        self.articulations_spec: list[dict] = []
        self.credits_extra: list[dict] = []
        self.layers: dict[str, Layer] = {}
        self.loop_spec = LoopSpec()
        self.params: dict = {}
        self.folder: Path | None = None

    # ------------------------------------------------------------ decorators

    def _register(self, name: str, fn: Callable | None, pitched: bool):
        def deco(f: Callable):
            if not callable(f):
                raise RecipeError(f"@sound.{name} must decorate a function")
            self.layers[name] = Layer(name, f, pitched)
            return f
        return deco(fn) if fn is not None else deco

    def body(self, fn: Callable | None = None):
        """Pitched sustaining part; rendered at every (root, velocity). Required."""
        return self._register("body", fn, True)

    def attack(self, fn: Callable | None = None, *, pitched: bool = False):
        """Transient. pitched=False (default): rendered once per velocity, plays at original speed."""
        return self._register("attack", fn, pitched)

    def tail(self, fn: Callable | None = None, *, pitched: bool = False):
        """Played on note-off (release noise, damper, breath out)."""
        return self._register("tail", fn, pitched)

    def air(self, fn: Callable | None = None):
        """Background noise bed: one unpitched zone that always loops."""
        return self._register("air", fn, False)

    def impulse(self, fn: Callable | None = None):
        """Impulse response for the 'Impronta' reverb (stereo preferred)."""
        return self._register("impulse", fn, False)

    # ------------------------------------------------------------ options

    def loop(self, body: bool = True, tail: bool = False, min_seconds: float = 0.4,
             region: tuple[float, float] | None = None):
        """Ask the compiler to find seamless sustain loops (in body and/or pitched tail zones).
        `region` = (t0, t1) seconds restricts the search."""
        self.loop_spec = LoopSpec(bool(body), bool(tail), float(min_seconds), region)
        return self

    def key_range(self, lo: int, hi: int):
        """Limit generated and sampled pitched zones to inclusive MIDI bounds.

        Unpitched kit/air zones and live oscillators are unchanged. The source
        roots and audio remain intact; only their mapped key ranges are clipped.
        """
        if (isinstance(lo, bool) or isinstance(hi, bool)
                or not isinstance(lo, int) or not isinstance(hi, int)
                or not 0 <= lo <= hi <= 127):
            raise RecipeError("key_range needs integer MIDI bounds 0 <= lo <= hi <= 127")
        self.key_range_spec = (lo, hi)
        return self

    def multisample(self, layer: str, regions: list, process: dict | None = None, custom: Callable | None = None,
                    as_dyn: bool | None = None, fill_gaps: bool = False):
        """Declare recorded regions for `layer` ('body', 'attack' or 'tail') instead of rendering it.

        regions: [{file, root, lo?, hi?, vel|dyn?, take?, tune_cents?, gain_db?, loop?, offset?, end?,
                   rt_decay?, rt_min_db?, pitched?, one_shot?, choke_group?, chokes?}, ...]
                 (files relative to samples/). Unpitched regions keep their own lo/hi, one articulation
                 per key for a drum kit; one_shot ignores note-off; choke_group N fades the sounding
                 voices of group N when a region of that group starts (chokes: [N..] without joining).
        process: editing options (pre_ms, align_ms, tune, ladder, peak_db, max_seconds, end_db,
                 fade_ms, loop, loop_min_s, encoding, mono): see libero.multisample.Process.
        custom:  optional fn(audio, region, ctx) -> Audio applied to each trimmed region.
        as_dyn:  map velocity layers onto the continuous dynamics axis (default: when > 1 layer).
        fill_gaps: close the gaps between unpitched key ranges by nearest centre (default: keep them).
        Missing key ranges are filled by nearest root, gapless; levels keep their natural ladder."""
        from .multisample import LAYERS as MS_LAYERS, MultiSpec, Process, Region

        if layer not in MS_LAYERS:
            raise RecipeError(f"multisample layer must be one of {MS_LAYERS}")
        if layer in self.layers:
            raise RecipeError(f"layer '{layer}' already has a function; use one or the other")
        try:
            regs = [Region.from_any(r, layer) for r in regions]
            self.multisamples[layer] = MultiSpec(layer, regs, Process.from_any(process), custom, as_dyn, bool(fill_gaps))
        except ValueError as e:
            raise RecipeError(str(e)) from None
        return self

    def performance(self, dynamics_source: str | None = None, velocity_curve: float | None = None,
                    humanize: dict | None = None, rr_reset_ms: float | None = None,
                    onset_ms: float | None = None, one_shot: bool | None = None,
                    dyn_crossfade: float | None = None):
        """Playing behaviour written to the manifest (bundle/2): what drives the dynamics axis
        ('velocity', 'cc1', 'cc11') and its velocity curve (dyn = (vel/127)^curve), per-note
        humanisation {"cents", "ms", "db"}, after how much silence round robins restart, and
        onset_ms: the pre-roll kept before each recorded strike, which the engine skips so the
        strike lands on note-on (use it when regions were trimmed with a generous pre-roll),
        one_shot: note-off is ignored by every zone that does not say otherwise (drums, gongs),
        dyn_crossfade: 0..1, the fraction of the gap between two dynamics layers over which they
        blend; 0 = a note plays exactly one layer, picked at note-on (struck, plucked and
        percussive sounds: summing two different strikes smears), > 0 only for phase-aligned
        sustains. Unset: the family default applies (the compiler reports it)."""
        from .library import DYN_SOURCES

        if dynamics_source is not None:
            if dynamics_source not in DYN_SOURCES:
                raise RecipeError(f"dynamics_source must be one of {DYN_SOURCES}")
            self.performance_spec.setdefault("dynamics", {})["source"] = dynamics_source
        if velocity_curve is not None:
            if not 0.1 <= float(velocity_curve) <= 10:
                raise RecipeError("velocity_curve must be within 0.1..10")
            self.performance_spec.setdefault("dynamics", {})["velocity_curve"] = float(velocity_curve)
        if humanize is not None:
            bad = set(humanize) - {"cents", "ms", "db"}
            if bad:
                raise RecipeError(f"humanize keys are cents, ms, db (got {sorted(bad)})")
            self.performance_spec["humanize"] = {k: float(v) for k, v in humanize.items()}
        if rr_reset_ms is not None:
            self.performance_spec["rr_reset_ms"] = float(rr_reset_ms)
        if one_shot is not None:
            self.performance_spec["one_shot"] = bool(one_shot)
        if dyn_crossfade is not None:
            if not 0 <= float(dyn_crossfade) <= 1:
                raise RecipeError("dyn_crossfade must be within 0..1 (0 = hard layer switch)")
            self.performance_spec.setdefault("dynamics", {})["crossfade"] = float(dyn_crossfade)
        if onset_ms is not None:
            if not 0 <= float(onset_ms) <= 200:
                raise RecipeError("onset_ms must be within 0..200")
            self.performance_spec["onset_ms"] = float(onset_ms)
        return self

    def articulations(self, items: list[dict]):
        """Declare the sound's articulations (bundle/2): [{"id": "sus", "name": "Sostenuto", "key": 24}, ...],
        in UI order, the first being the default. `id` is what a multisample region names in its
        "articulation"; `name` is the Italian label the UI shows; `key` is a MIDI note whose
        note-on switches to the articulation (no sound; it must lie outside every zone's playing
        range) or None for an articulation reachable only from the `artic` parameter."""
        from .library import validate_articulations

        spec = [{"id": a.get("id"), "name": a.get("name") or a.get("id"), "key": a.get("key"),
                 **({"params": dict(a["params"])} if "params" in a else {})} for a in items]
        probs = validate_articulations(spec)
        if probs:
            raise RecipeError("articulations: " + "; ".join(probs))
        self.articulations_spec = spec
        return self

    def credit(self, source: str, license: str, license_class: str = "by", author: str = "", url: str = ""):
        """Credit a source used by this recipe (also read from samples/credits.json)."""
        self.credits_extra.append({"source": source, "license": license, "license_class": license_class,
                                   "author": author, "url": url})
        return self

    def retitle(self, title: str, subtitle: str | None = None):
        """Rename the sound after construction (the plugin's "Salva come…" appends this to a
        copied recipe). Metadata only: it never causes zones to re-render."""
        if not title or not str(title).strip():
            raise RecipeError("retitle() needs a title")
        self.title = str(title).strip()
        if subtitle is not None:
            self.subtitle = str(subtitle)
        return self

    def defaults(self, **values):
        """Default values of the live parameters (SPEC §5), validated. Choices by name."""
        self.params.update(params.validate(values))
        return self

    # ------------------------------------------------------------ rendering

    def zone_seed(self, layer: str, note: int, velocity: int, take: int = 0) -> int:
        # take 0 keeps the historical seed, so adding takes never changes the first take.
        key = f"{self.seed}:{layer}:{note}:{velocity}" + (f":t{take}" if take else "")
        h = hashlib.sha256(key.encode()).digest()
        return int.from_bytes(h[:4], "little")

    def ctx(self, layer: str, note: int, velocity: int, take: int = 0, dyn: float | None = None) -> Ctx:
        folder = self.folder or Path.cwd()
        return Ctx(note=int(note), velocity=int(velocity), sr=self.sample_rate, samples=folder / "samples",
                   folder=folder, seed=self.zone_seed(layer, note, velocity, take), layer=layer, roots=self.roots,
                   velocities=self.velocities, take=int(take), takes=self.takes, dyn_value=dyn)

    def render(self, layer: str, note: int = 60, velocity: int = 100, take: int = 0,
               dyn: float | None = None) -> Audio | None:
        """Run one layer function for one zone (and take) and return its Audio (at the sound's rate)."""
        if layer not in self.layers:
            return None
        c = self.ctx(layer, note, velocity, take, dyn)
        token = set_search_dirs(c.samples, c.folder)
        try:
            out = self.layers[layer].fn(c)
        finally:
            from .audio import _search_dirs
            _search_dirs.reset(token)
        if out is None:
            return None
        if not isinstance(out, Audio):
            raise RecipeError(f"layer '{layer}' returned {type(out).__name__}, expected Audio or None")
        return out.resample(self.sample_rate) if out.sr != self.sample_rate else out

    def check(self) -> list[str]:
        problems = []
        if "body" not in self.layers and "body" not in self.multisamples:
            from .library import oscillators_on

            if not oscillators_on(self.params):
                problems.append("no @sound.body layer or sound.multisample('body', ...), and no oscillator turned "
                                "on in sound.defaults(...) (e.g. osc1_level=-6): the sound would be silent")
        return problems


def load_recipe(folder: Path | str) -> Sound:
    """Import <folder>/sound.py and return its module-level `sound`."""
    folder = Path(folder).resolve()
    path = folder / "sound.py"
    if not path.exists():
        raise RecipeError(f"{path} does not exist")
    name = "libero_recipe_" + hashlib.sha1(str(folder).encode()).hexdigest()[:10]
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    token = set_search_dirs(folder / "samples", folder)
    sys.modules[name] = mod
    dont_write = sys.dont_write_bytecode
    sys.dont_write_bytecode = True  # never leave __pycache__ inside a sound folder
    try:
        spec.loader.exec_module(mod)
    except params.ParamError as e:
        raise RecipeError(f"sound.defaults(): {e}") from None
    finally:
        sys.dont_write_bytecode = dont_write
        from .audio import _search_dirs
        _search_dirs.reset(token)
    snd = getattr(mod, "sound", None)
    if not isinstance(snd, Sound):
        raise RecipeError("sound.py must define a module-level `sound = Sound(...)`")
    snd.folder = folder
    problems = snd.check()
    if problems:
        raise RecipeError("; ".join(problems))
    return snd
