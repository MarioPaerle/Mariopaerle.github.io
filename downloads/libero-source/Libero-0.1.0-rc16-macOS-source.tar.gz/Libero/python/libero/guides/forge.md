# libero.forge: wavetable synthesis for recipes

`libero.forge` provides offline oscillator, filter and modulation synthesis inside a recipe. You describe a patch
(oscillators, filters, modulation, FX), `Patch.render()` returns a stereo `libero.Audio`, and the
compiler bakes it into zones like any other layer. Use it for electronic sounds (bass, leads,
plucks, pads, FX, drums) and as the synthetic half of hybrids with recordings. For acoustic
instruments use `guide('physics')` and `guide('sampled')`.

```python
from libero import forge
from libero.forge import Patch, Osc, Sub, Noise, Filter, Env, LFO, Mod, Wavetable, FX
```

Everything is deterministic (same arguments + `seed` = same samples) and fast: a 2 s note with
2 oscillators x 8 unison voices, a filter and a five-effect rack renders in about 0.1-0.3 s once
the numba kernels are cached (the first call of a session compiles them, about 10 s once per machine).

## Design and playback limits

A rendered patch captures its envelopes, modulation phase and FX. It does not
make that routing live in the plugin. Source LFO `sync` uses the render BPM;
compiled audio cannot follow a new host tempo merely because the source patch
specified sync. `controls` are render-time values, not live controller bindings.
Native controller modulation must be configured and tested separately.

Choose excitation, topology and playing gesture from the musical reference
before choosing a rendering shortcut. Long looped oscillator notes with the same
low-pass contour can remain similar despite different hardware names. Preserve
separate mechanisms for tonewheel organs, string ensembles, connected leads,
struck sources and noisy/inharmonic textures. Compare a genuinely dry patch render
and the final defaults at matched pitch/level; bypassing native FX cannot remove
offline FX. Use live synthesis where the native engine can preserve the intended
motion and note/controller response; document the remaining approximation.

## 1. Concepts

- **Patch**: `oscs` (osc1, osc2, ...), `sub`, `noise`, `filters` (filter1, filter2), `envs` (env1 is the
  amplitude envelope), `lfos`, `macros`, `mods` (the mod matrix), `fx` (rack, in order), `voice`.
- **Signal flow per voice**: sources -> filter 1 / filter 2 (serial or parallel; a source with
  `filtered=False` skips them) -> amp envelope x velocity -> stereo sum -> FX rack -> output trim.
- **Modulation** works like turning a knob: `Mod(src, dst, amount)` adds `amount * source` to the
  destination's normalised 0..1 position. `amount=0.5` on `osc1.pos` sweeps half the wavetable; on
  `filter1.cutoff` (20 Hz-20 kHz, 10 octaves) `0.1` is one octave; on `pitch` (+/-48 st) `0.125` is 12
  semitones. Sources: `env1..4`, `lfo1..4`, `macro1..4`, `velocity`, `note`, `random`, `modwheel`,
  `aftertouch`. `bipolar=True/False` recentres a source, `aux='macro1'` scales the amount by another source.
  `patch.targets()` lists every destination, `patch.sources()` every source.
- **Bake across the keyboard**: `forge.layer(patch)` returns a function of `ctx`, so each root and velocity
  layer is rendered with `ctx.note`, `ctx.velocity` and the deterministic `ctx.seed`.

## 2. Quick start

```python
from libero import forge
from libero.forge import Patch, Osc, Filter, Env, LFO, Mod, FX

p = Patch(
    "wobble",
    oscs=[Osc("saw", unison=5, detune=0.3), Osc("square", octave=-1, level=0.6)],
    filters=[Filter("lp24", cutoff=500, res=0.4)],
    envs=[Env(0.005, 0.3, 0.8, 0.2)],
    lfos=[LFO("sine", sync="1/8", mode="trig")],
    mods=[Mod("lfo1", "filter1.cutoff", 0.2)],
    fx=[FX.Distortion("tube", drive=0.3), FX.Reverb("plate", decay=1.2, mix=0.15)],
    bpm=140,
)
a = p.render("E1", velocity=110, duration=0.5, sr=48000, seed=1)   # libero.Audio, stereo
print(a.duration, a.peak_db)
```

`render(note, velocity, duration, sr, seed, tail=None, macros=None, controls=None)`: `duration` is how long
the key is held, `tail` the release/FX ring-out after it (None = automatic, silence trimmed),
`macros={'macro1': 0.7}` and `controls={'modwheel': 1.0}` override knobs per render.
`patch.set('filter1.cutoff', 900)` returns an edited copy (paths: `osc1.pos`, `osc2.warp1`,
`env2.attack`, `lfo1.rate`, `sub.level`, `macro1`, `fx.delay.mix`, `bpm`, ...).

## 3. Oscillators and wavetables

`Osc(table, pos, warp1, warp1_amount, warp2, warp2_amount, fm_src, octave, semi, fine, unison, detune,
blend, spread, rand_phase, phase, voice_phase, level, pan, filtered)`.

- **Band-limited**: tables are mipmapped in half-octave levels; a saw at C8 at 48 kHz carries only the
  harmonics below Nyquist, so plain playback does not alias (tested at < -60 dB). Pitch is exact to
  well under 1 cent.
- **Position** `pos` 0..1 morphs between frames; modulate `osc1.pos`.
- **Warp modes** (two slots per oscillator, amount 0..1, modulate `osc1.warp1` / `osc1.warp2`):
  `sync` (hard-sync-like, ratio 1-8), `bend+` `bend-` `bend+-`, `pwm`, `asym+` `asym-`, `mirror`, `remap`
  (phase distortion), `quantize`, and cross-oscillator `fm`, `am`, `rm` (modulator = `fm_src`, 0-based
  oscillator index, default the other one; give it `level=0` to use it only as a modulator).
  FM and AM cycles (A modulated by B modulated by A) raise `ForgeError`.
- **Unison** 1..16: `detune` 0..1 (outer voices at `forge.unison_cents(detune)` cents: 0.25 is about 14 c,
  1.0 is 100 c), `blend` (0 centre voice only, 1 all equal), `spread` stereo width, `rand_phase` randomises
  start phases from the seed, `voice_phase` spreads them evenly.
- **Sub**: `Sub('sine'|'tri'|'square'|'saw', octave=-1, level=0.4)`, unfiltered by default.
- **Noise**: `Noise('white'|'pink'|'brown'|'blue', level)` or `Noise('sample', sample=audio, keytrack=True,
  root=60)` which loops a recording (vinyl dust, breath, rain) with a crossfade and a seeded start offset.

```python
import numpy as np
from libero import forge
from libero.forge import Wavetable, Patch, Osc

# every way to make a table (all 2048 points per frame, any number of frames)
t1 = Wavetable.classic("vocal")                                   # saw sine square tri pulse pwm sine_saw saw_square
                                                                  # tri_saw supersaw vocal digital organ fm bell noise_cycle
t2 = Wavetable.from_formula(lambda ph, pos: np.sin(2*np.pi*ph + 6*pos*np.sin(2*np.pi*ph)), frames=24)
t3 = Wavetable.from_harmonics([[1, 0, .5, 0, .25], [1, .8, .6, .4, .2]])        # one spectrum per frame
t4 = Wavetable.from_additive(lambda k, pos: (1.0/k) * (k <= 2 + 30*pos), harmonics=64, frames=32)
t5 = Wavetable.morph(Wavetable.classic("saw"), Wavetable.classic("square"), frames_each=8)
for wt in (t1, t2, t3, t4, t5):
    a = Patch("t", oscs=[Osc(wt, pos=0.5, unison=3)]).render(48, 100, 0.2, 24000, tail=0.05)
    assert np.isfinite(a.data).all()
```

`from_formula(fn)` evaluates `fn(phase_array, position)` at 4x resolution and band-limits it, so sharp
formulas (clipped sines, steps) do not fold back. `fn` may also take scalars.

### Tables from recordings

```python
import numpy as np
from libero import Audio
from libero.forge import Wavetable, Patch, Osc

sr = 48000
t = np.arange(sr) / sr
voice = Audio(0.3 * sum(np.sin(2*np.pi*220*k*t) / k for k in range(1, 9)), sr)   # stand-in for a recording
wt = Wavetable.from_audio(voice, frames=32)                    # auto: pitch-synchronous cycles when a pitch is found
grit = Wavetable.from_audio(Audio(np.random.default_rng(0).standard_normal(sr), sr), frames=16, mode="window")
one = Wavetable.from_cycle(Audio(np.sin(2*np.pi*np.arange(400)/400) ** 3, sr))      # a single recorded cycle
spec = Wavetable.from_audio(voice, frames=8, mode="spectral", f0=220.0)             # timbre only, phase-free
a = Patch("resynth", oscs=[Osc(wt, pos=0.3, unison=3, detune=0.1)]).render(57, 100, 0.3, sr, tail=0.05)
assert a.n > 0
```

`mode='cycle'` slices one period per frame and aligns the fundamental phase so frames morph cleanly
(pass `f0=` for pitched sources, `t0/t1` to choose the region); `'window'` reads 2048-sample windows
as cycles (noise, drums, textures); `'spectral'` rebuilds each frame's magnitude spectrum on a
harmonic series. Always pass a **recording you are allowed to use**; the table keeps its character.

## 4. Filters

`Filter(type, cutoff, res, drive, morph, keytrack, mix)`; types in `forge.FILTER_TYPES`:

| type | use | cutoff means |
|---|---|---|
| `lp12 lp24 hp12 hp24` | the workhorses (Butterworth; measured -3 dB point within 5 %) | -3 dB corner |
| `bp12 bp24 notch12 notch24` | bands, notches (res narrows) | centre |
| `svf` | state variable, `morph` 0 LP -> 0.5 BP -> 1 HP | corner / centre |
| `ladder` | Moog-like 4 pole, self-oscillates near res=1 | resonance peak |
| `diode` | 303-style: softer slope, tighter resonance, asymmetric | resonance peak |
| `comb+ comb-` | feedback comb (`res` = feedback, - is hollow) | first tooth (delay = 1/cutoff) |
| `flanger`, `phaser` | swept notches (`morph` = phaser stages) | notch sweep centre |
| `formant` | vowels: `morph` 0..1 = a e i o u, `res` = sharpness | 1000 is neutral, shifts the formants |

`drive` saturates inside the filter, `keytrack` 1 follows pitch (reference C4), `mix` blends dry/filtered.
Two filters run `filter_routing='serial'` or `'parallel'` (`filter_mix` = share of filter 2).
`Filter(...).response()` returns `(freqs, dB)` so you can check a curve before rendering.

```python
from libero import forge
from libero.forge import Filter, Patch, Osc

for kind in forge.FILTER_TYPES:
    f, db = Filter(kind, cutoff=1000.0, res=0.4, morph=0.5).response(48000, 4096)
    assert db.shape == f.shape
lp = Patch("dual", oscs=[Osc("saw", unison=3)],
           filters=[Filter("hp12", cutoff=120), Filter("lp24", cutoff=2500, res=0.3, keytrack=0.5)])
assert lp.render(48, 100, 0.2, 24000, tail=0.05).n > 0
```

## 5. Modulation

- `Env(attack, decay, sustain, release, hold, delay, curves=(a, d, r))`: curves -1..1, 0 linear;
  negative decay/release curves are exponential (natural). Retriggering restarts from the current level.
- `LFO(shape, rate | sync, mode, phase, smooth, delay, fade, points)`: shapes `sine tri saw ramp square sh
  smooth points`; `sync='1/8'` ('1/8t' triplet, '1/4.' dotted) follows `patch.bpm`; modes `trig` (restart per
  note), `free` (global clock), `env` (one cycle per note); `points=[(x, y, curve?), ...]` is a drawn
  LFO (x 0..1, y -1..1); `lfoN.rate` is modulatable.
- Macros are 0..1 knobs (`macros={'macro1': 0.5}`, labelled with `macro_labels`), perfect for
  "brightness", "grit", "vowel". Velocity/note/random are sources; `vel_amp` sets how much velocity
  scales loudness.

```python
from libero.forge import Patch, Osc, Filter, Env, LFO, Mod

p = Patch(
    "mod demo",
    oscs=[Osc("sine_saw", unison=3, warp1="bend+-", warp1_amount=0.5)],
    filters=[Filter("lp24", cutoff=800, res=0.2)],
    envs=[Env(0.01, 0.4, 0.7, 0.3), Env(0.0, 0.3, 0.0, 0.1)],
    lfos=[LFO("points", rate=2.0, mode="trig", points=[(0, -1), (0.3, 1, -0.5), (1, -1)]), LFO("sine", sync="1/4", mode="free")],
    macros={"macro1": 0.0},
    mods=[
        Mod("env2", "filter1.cutoff", 0.3),                  # filter snaps closed
        Mod("lfo1", "osc1.pos", 0.4, bipolar=False),         # drawn LFO scans the table
        Mod("lfo2", "osc1.warp1", 0.3, aux="macro1"),        # macro scales the wobble
        Mod("velocity", "filter1.cutoff", 0.1),
        Mod("macro1", "pitch", 0.0),
    ],
)
a0 = p.render(48, 100, 0.4, 24000, macros={"macro1": 0.0}, tail=0.1)
a1 = p.render(48, 100, 0.4, 24000, macros={"macro1": 1.0}, tail=0.1)
assert a0.n == a1.n
```

## 6. FX rack

`fx=[...]` in order. `mix` is dry/wet except for `Delay` and `Reverb`, where it is a wet send added to the
untouched dry. Parameters marked modulatable take `Mod(..., 'fx.<kind>.<param>')` (`'fx.delay.mix'`,
`'fx.reverb2.mix'` for a second reverb) or `'fxK.<param>'` (K = 1-based position).

| effect | what it does | key parameters |
|---|---|---|
| `Hyper` | unison chorus over the whole sound | rate detune voices(<=8) width mix |
| `Dimension` | Roland-style widener | size mix |
| `Distortion` | tube, soft, hard, diode, fold, bitcrush, downsample, waveshaper (callable or table) | drive bias tone bits rate mix |
| `Flanger` `Phaser` `Chorus` | classic modulation | rate depth delay feedback stages voices mix |
| `Delay` | stereo / ping-pong / mono, ms or `sync='1/8.'`, filtered feedback | time feedback lowpass highpass offset mix |
| `Reverb` | plate / hall / room FDN | decay size damping predelay width lowcut highcut mix |
| `Compressor` | feed-forward, peak/rms, parallel via mix | threshold ratio attack release knee makeup |
| `MultibandComp` | OTT: 3 bands, downward + upward | depth time mode('ott','up','down') low high |
| `EQ` | `bands=[('peak', 1000, 3, 1), ('highpass', 30, 0, .7), ...]` | |
| `FilterFx`, `Utility` | any filter type in the rack; gain, width, pan, mono bass | |
| `Tape` | wow and flutter add pitch drift; saturation, age (HF loss, dropouts), head bump and hiss add tape colour | wow flutter saturation age bump hiss_db |
| `Vinyl` | crackle, pops, hiss, rumble, wear, warp | crackle pops hiss_db wear warp level_db |

```python
import numpy as np
from libero import forge
from libero.forge import Patch, Osc, FX, Mod

rack = [
    FX.Hyper(mix=0.3), FX.Chorus(), FX.Flanger(), FX.Phaser(),
    FX.Distortion("tube", drive=0.3), FX.Distortion("bitcrush", bits=6.0, mix=0.3),
    FX.Delay(sync="1/8", feedback=0.4, mode="pingpong", mix=0.2),
    FX.Reverb("hall", decay=2.5, mix=0.2), FX.MultibandComp(depth=0.4),
    FX.Compressor(), FX.EQ([("lowshelf", 120, 3, 0.7)]),
    FX.Tape(wow=0.0, flutter=0.0, age=0.4), FX.Vinyl(crackle=0.4), FX.Utility(width=1.2),
]
p = Patch("rack", oscs=[Osc("saw", unison=3)], fx=rack, mods=[Mod("macro1", "fx.delay.mix", 0.3)])
a = p.render(55, 100, 0.3, 24000, tail=0.3, macros={"macro1": 1.0})
assert np.isfinite(a.data).all() and a.peak_db < 0.0
```

Output is soft-limited below 0 dBFS (`Patch(safe=True)`), every effect keeps NaN/inf out, and the wet
sections are seeded (`seed`), so renders are reproducible.

For ordinary presets, keep wow and flutter at zero. Add them only for an explicit
tape/vintage sound or a measured reference, then audition at the intended mix: with
non-zero modulation, a partial Tape mix can create comb filtering or a flanged tone.
The named `lofi_keys_tape` preset below remains the deliberate tape-drift option.

## 7. Voices and phrases

`Voice(mode='poly'|'mono'|'legato', glide=0.0, glide_shape='exp'|'linear', glide_legato_only=False)`.
`patch.render_phrase([(note, start_s, dur_s[, velocity]), ...])` renders with the voice mode: poly mixes a
voice per note with overlapping releases (FX once on the sum), mono retriggers envelopes, legato slides
into overlapping notes without retriggering. `sequential=True` takes `(note, dur[, vel])` back to back.
Use it for previews and for baking riffs, not for the zone layers (those are single notes).

```python
from libero import forge
from libero.forge import Patch, Osc, Filter, Env, Voice, Mod

acid = Patch("acid", oscs=[Osc("saw")], filters=[Filter("diode", cutoff=400, res=0.7)],
             envs=[Env(0.002, 0.2, 0.6, 0.08), Env(0.0, 0.2, 0.0, 0.1)], mods=[Mod("env2", "filter1.cutoff", 0.35)],
             voice=Voice("legato", glide=0.06))
riff = acid.render_phrase([(36, 0.0, 0.3), (39, 0.25, 0.3), (43, 0.5, 0.3), (36, 1.0, 0.2)], sr=24000, seed=1)
poly = acid.set("voice", Voice("poly")).render_phrase([(48, 0.0, 0.5), (55, 0.0, 0.5)], sr=24000)
assert riff.duration > 1.0 and poly.duration > 0.5
```

## 8. Presets

`forge.presets.catalog()` returns `{name: (low_note, high_note, description)}`; `forge.presets.get(name)`
a fresh editable Patch. All are original constructions, loudness-calibrated to about -4 dBFS peak at
velocity 100.

| preset | role |
|---|---|
| `trap_808` | 808 sub bass: pitch-dropped sine, long tail, tube saturation (macro1 = saturation) |
| `reese_bass` | detuned saw stack with slow filter drift, grit (macro1 = brightness) |
| `supersaw_lead` | 2 stacks, 16 voices, hyper + 1/8 ping-pong + plate |
| `pluck` | filter-snap pluck for arps and chords |
| `warm_pad` | slow analog-style pad, chorus + phaser + hall |
| `vocal_formant_lead` | vowel table + formant filter, delayed vibrato (macro1 = vowel a-e-i-o-u) |
| `fm_bell` | FM bell / DX keys, decaying index |
| `lofi_keys_tape` | dusty piano: chorus, tape wow/flutter/age, vinyl (macro1 = tape age) |
| `wobble_bass` | tempo-synced wobble, set `p.bpm` (macro1 = depth) |
| `riser_whoosh` | noise + rising saw sweep; `presets.riser(seconds)` fits the length |
| `impact` | cinematic boom: pitch drop, noise crack, 4 s hall |
| `sub_drop` | clean falling sine sweep |
| `acid_bass` | 303-style legato diode ladder; use `render_phrase` |
| `pwm_strings` | string-machine pad on a PWM table |
| `evolving_pad` | morphing digital pad, position/warp drift (macro1 = morph) |
| `organ_keys` | drawbar organ with click and rotary-like modulation |
| `hoover_lead` | rave hoover: pitch dive, bend warp, wide unison |
| `brass_stab` | poly-synth brass with filter swell |
| `sync_lead` | hard-sync sweep lead (modwheel adds more sync) |
| `trap_hat` | closed hat from noise + metallic squares, bit-crushed |

```python
from libero import forge

assert len(forge.presets.catalog()) == 20
for name in ("trap_808", "supersaw_lead", "trap_hat"):
    p = forge.presets.get(name)
    lo, hi, why = forge.presets.catalog()[name]
    note = lo + 12 if lo != hi else 60
    a = p.render(note, 100, 0.2, 24000, seed=1)
    assert a.is_stereo and a.peak_db < 0
riser = forge.presets.riser(1.0).render(60, 100, 1.0, 24000)
bright = forge.presets.reese_bass().set("macro1", 1.0).render(36, 100, 0.3, 24000)
```

## 9. Using forge in a recipe

```python
from libero import Sound, forge

sound = Sound(title="Reese", roots=[24, 36, 48], velocities=[60, 110])

# one layer per root/velocity; macros can follow ctx.dyn (soft = darker)
sound.body(forge.layer(forge.presets.reese_bass(), duration=1.2, normalize_db=-3.0,
                       macros=lambda ctx: {"macro1": 0.3 + 0.5 * ctx.dyn}))

a = sound.render("body", 36, 110)
assert a.is_stereo
```

Layering with recordings (`stack` aligns at t = 0, `recording` repitches from its `root`):

```python
import numpy as np
from libero import Audio, Sound, forge

sound = Sound(title="Hybrid pluck", roots=[60])
sound.body(forge.stack(
    forge.layer(forge.presets.pluck(), duration=0.4, gain_db=-3),
    lambda ctx: Audio(0.1 * np.random.default_rng(ctx.seed).standard_normal(4800), ctx.sr),   # or forge.recording("hit.wav", root=60)
))
assert sound.render("body", 60, 100).duration >= 0.4
```

`forge.layer(patch, duration, tail, macros, gain_db, velocity, normalize_db)`: `duration` and `macros`
may be callables of `ctx`; `velocity` can pin or remap the velocity (`lambda ctx: 80 + ctx.dyn * 40`).
For a sound with a sustain loop, render long (`duration=4`) and use `sound.loop(...)`.

## 10. Cookbook: request -> patch

| request | start from | then |
|---|---|---|
| "808 / trap sub" | `trap_808` | lengthen `env1.decay`, macro1 for drive; long notes need `duration` 2-4 |
| "reese / neuro / dark DnB bass" | `reese_bass` | `osc1.detune` 0.15-0.3, add `FX.MultibandComp` |
| "dubstep wobble" | `wobble_bass` | `p.bpm`, LFO `sync` 1/4 to 1/16, `lp24` res .3-.5 |
| "supersaw / trance chord / future bass" | `supersaw_lead` | `unison` 9-16, `FX.Hyper`, sidechain role is the mixer's job |
| "pluck / arp / EDM stab" | `pluck` | `env2.decay` shortens the snap, `filter1.cutoff` base 400-1500 |
| "warm pad / strings / ambient bed" | `warm_pad`, `pwm_strings`, `evolving_pad` | longer `env1.attack`, `FX.Reverb('hall')` |
| "vocal / choir / talking lead" | `vocal_formant_lead` | macro1 vowel; or `Filter('formant')` on any saw |
| "bell / FM keys / DX e-piano" | `fm_bell` | `osc1.warp1_amount` base + `env2` amount for brightness |
| "lo-fi keys / tape / dusty" | `lofi_keys_tape` | explicit tape-drift option; macro1 age; `FX.Vinyl(crackle=...)` |
| "riser / whoosh / build" | `presets.riser(4.0)` | hold the note that long; add a `FX.Delay` |
| "impact / boom / hit" | `impact` | `env1.decay`, bigger `FX.Reverb` decay |
| "sub drop / 808 fall" | `sub_drop` | `env2.decay` = fall time |
| "acid 303" | `acid_bass` | `render_phrase`; `res` .6-.8, `env2` amount |
| "organ / rotary" | `organ_keys` | swap the table: `Wavetable.from_harmonics` drawbars |
| "hoover / rave stab" | `hoover_lead` | `unison` 8-12, `warp1_amount` |
| "brass / synth stab" | `brass_stab` | `env2.attack` for swell time |
| "sync lead / screaming lead" | `sync_lead` | `warp1_amount` base, `modwheel` |
| "closed / open hat" | `trap_hat` | `p.set('env1.decay', 0.35)` for open |
| "make it wider" | any | `FX.Hyper`, `Osc.spread`, `FX.Utility(width=1.3, mono_below=120)` |
| "make it grittier" | any | `FX.Distortion('tube'/'diode')`, `FX.Distortion('bitcrush')`, `FX.MultibandComp` |
| "make it old" | any | `FX.Tape`, `FX.Vinyl`, lower `Filter` cutoff |
| "my own timbre from a recording" | `Wavetable.from_audio` | `Osc(wt, pos=...)`, modulate `osc1.pos` |

## 11. Checks and troubleshooting

- Render once and look: `a.peak_db`, `a.rms_db`, `a.duration`; compare tilt/centroid against a reference
  with the analysis tools before deciding "bright" or "dark".
- Too quiet or clipped: set `Patch(volume_db=...)`, or `forge.layer(..., normalize_db=-3)`.
- Tail cut off: pass `tail=` (seconds) explicitly; the automatic tail follows `env1.release` plus the FX.
- Slow first call: numba compiles the kernels once and caches them; later renders are fast.
- Unknown mod destination: the error lists close matches; `patch.targets()` lists all.
- Aliasing under heavy warp/FM at high notes is possible (warps are not oversampled); use `Filter('lp12')`
  or `FX.Distortion(oversample=4)` in the chain, or render the layer higher and resample.
- Not covered: wavetable import of third-party `.wav` bundles with embedded metadata (slice with
  `Wavetable.from_audio(..., mode='cycle'|'window')`), sample-accurate MIDI CC curves, per-voice mono FX.
