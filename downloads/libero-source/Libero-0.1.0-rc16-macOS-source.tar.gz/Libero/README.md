# Libero

Libero is a sampler and synthesizer for macOS and Windows. It combines sampled
acoustic instruments, live synthesis, selectable articulations and expressive
MIDI control. Load a collection, choose a sound and adjust its layers, envelopes,
filters and effects while playing.

This is an early pre-release. Actual DAW testing is still in progress.

## Downloads

[Downloads on Drive](https://drive.google.com/drive/folders/1H8RPLpUjnRy4grvidcRvtLt1DuVlx28L)
contains **Installs** for the current macOS and Windows beta builds, and **Packs**
for sounds. Choose the download named for your operating system and read
**START HERE.txt**. The portable Windows ZIP is in the optional manual-install folder.

The public plugin build is **0.1.0-rc12**. The Base Bundle **0.1.6** contains
95 instruments in 14 collections, about 5.25 GB across two independent ZIP parts.
Select both parts together in **Library → Import**, or choose individual
`.liberobank` files. For extracted packs, use **Import folder**.

[Corresponding source archives](https://mariopaerle.github.io/libero-source/)
are available separately. The development repository is not public yet.
The development library contains additional sounds outside the public bundle.

Plugin builds are distributed separately from the sound packs. Playing sounds
and importing banks do not require Python or a repository checkout.

| Platform | Plugin formats | Requirements |
| --- | --- | --- |
| macOS | Audio Unit, VST3 | macOS 11 or later; Apple Silicon or Intel |
| Windows | VST3, x64 preview | Windows 10/11; a 64-bit VST3 host; Microsoft WebView2 Runtime |

The Windows x64 preview passed native build, audio, MIDI, import, editor and
installer checks. Testing in actual DAWs is still needed. The Windows installer
is unsigned; the macOS build is ad-hoc signed and has not been notarized.

## Install and load sounds

1. Download the plugin package for your platform and close your DAW.
2. On macOS, copy `Libero.component` or `Libero.vst3` into your user plugin
   directory. On Windows, run the x64 installer, or copy the complete
   `Libero.vst3` folder into the system VST3 directory.
3. Reopen your DAW, rescan plugins if needed and load Libero.
4. Download individual `.liberobank` files or both Base Bundle ZIP parts.
5. Open **Library → Import** and select several packs together, or select the
   both ZIP parts together. Review the list, select the collections you want,
   then choose **Install packs**. The progress screen reports each result.

Batch import requires the updated plugin build; earlier pre-release builds
accept one `.liberobank` at a time after extracting the complete ZIP.

Keep individual `.liberobank` files intact. The import screen reports an already
installed version, refuses downgrades and checks archive contents before
installation. Updating a collection replaces that collection, including local
changes; make personal copies of sounds you want to keep before updating.

Your sound library is stored in `~/Libero` on macOS and `%USERPROFILE%\Libero`
on Windows. Removing the plugin preserves this library.

Detailed instructions: [macOS](docs/release/install-macos.md) ·
[Windows](docs/release/install-windows.md) · [sound packs](docs/release/sound-packs.md).

Libero currently provides AU and VST3 builds. It does not provide VST2; use a
host or bridge that supports the supplied formats.

[Pitch and host slide behavior](docs/host-pitch-and-slides.md) explains MIDI pitch bend,
FL Studio wrapper settings, LMMS track pitch and Libero Legato/Glide.

## Playing and editing

- Select an articulation when the sound provides alternatives.
- For slides, choose **Legato**, set **Glide** and overlap MIDI notes. Pitch
  wheel and sustain are supported. Theremin and Trautonium presets use velocity
  for loudness and the modulation wheel primarily for vibrato.
- On eligible sampled instruments, the **Sample** panel shows the playback
  waveform and the live playback position, including loops. Set trim bounds,
  loop bounds and crossfade directly in your library. Changes apply and save
  automatically.
  **Restore** returns the selected zone to its original settings. Edits travel
  with exported banks; the original recordings remain intact. **Follow keys**
  selects the sounding sample unless you have pending edits.
- Resize the window using the lower-right grip; width and height are independent
  and remembered. The DAW provides the plugin window’s close and minimise controls.
- **Save as…** makes a personal copy with the source cover and a small **Copy** flag.
- Use **Character** for the optional EQ, compression and texture presets.

See [MIDI and host pitch behavior](plugin/README.md#portamento-and-host-pitch-automation)
for host-specific slide limitations.

## Build from source

```sh
git clone --recurse-submodules https://github.com/MarioPaerle/Libero.git
cd Libero
```

For an existing checkout, run `git submodule update --init --recursive`.

### macOS

Install CMake, Ninja and the Xcode Command Line Tools, then run:

```sh
scripts/build.sh
scripts/install.sh
```

This builds universal arm64/x86_64 plugins and the `libero-render` offline tool.

### Windows

Install Visual Studio 2022 with **Desktop development with C++**, CMake and
the Microsoft WebView2 SDK (downloaded by the build script). From PowerShell at the repository root:

```powershell
./scripts/build-windows.ps1
```

The script builds the Release x64 VST3 and native tools in `build/windows` and
obtains the pinned Microsoft WebView2 SDK. For installation, copy
`build/windows/plugin/Libero_artefacts/Release/VST3/Libero.vst3` into
`C:\Program Files\Common Files\VST3`.

Python 3.12 is needed for the automated Python tests and source-archive packaging,
not for the native build or playback.

To produce a ZIP and installer, install Python 3.12 and Inno Setup 6 and run:

```powershell
./scripts/package-windows.ps1
```

[Windows build checks](.github/workflows/windows.yml) cover rendering, MIDI,
bank imports, sample edits, VST3 loading, the embedded WebView2 interface and
installer execution. Actual DAW testing is still needed.

## Sound authoring

The Python tools build playable bundles from recipes. An MCP server exposes
recording acquisition, synthesis, editing, analysis and compilation to compatible
clients. Previews use the same native engine as the plugin.

Install Python 3.12 and uv, then:

```sh
cd python
uv sync
uv run python scripts/install_examples.py
```

Configure an MCP client with `uv --directory <repo>/python run libero-mcp`.
The [Python guide](python/README.md) describes the authoring API. The `skills/`
folder contains `libero-fast` and `libero-slow` workflows, also available through
`guide("fast")` and `guide("slow")` in the MCP server.

## Source and licenses

- `plugin/`: C++ engine, AU/VST3 plugin and offline renderer.
- `ui/`: embedded HTML/CSS/JavaScript interface.
- `python/`: authoring library and MCP server.
- `sounds/`: example recipes.

The software is [AGPLv3](LICENSE). Original authored sound data in the public
selection is CC0; third-party recordings retain their own terms and credits.
Keep the attribution files when redistributing sound packs. See [NOTICE](NOTICE)
and the `SOUND-DATA-TERMS.md` included with the downloads.

The component contract is [SPEC.md](SPEC.md). Build and validation details are
in [plugin/README.md](plugin/README.md) and the
[release guide](docs/release/first-release.md).

When reporting a problem, include your OS, DAW and version, sample rate, buffer
size, preset name and the steps needed to reproduce it.
