# Synth identity and artist references

Use this reference for a synth palette, a named artist/album, or listener feedback
about repeated timbres. It records the rejected first Pink collection and the
decisions that need to change. The redesign examples below are design routes,
not claims of listener approval.

## What failed in Pink

On 14 October 2026 the user rejected most of Pink, singled out the guitars
positively, and identified similar resonances across oscillator-made sounds.
They requested *The Dark Side of the Moon*, especially *Breathe (In the Air)*,
as the main reference.

Nine keyboard recipes rendered conventional oscillator stacks through mostly
low-pass filters into ten-second looped bodies. They shared Poly behaviour,
instantaneous native attack, full sustain, 420 ms release and similar small-room
defaults. Different hardware labels concealed too much shared construction.
The supposed Minimoog lead was polyphonic with no glide; the organ omitted
important keying/percussion/scanner behaviour. Baked modulation repeated with
the sample and changed speed under transposition.

Technical checks passed but did not establish character or resemblance to the
music. Matched-level steady-note spectra converged despite different labels.
The native filter was open at 20 kHz and the resonator was disabled: blaming a
common native resonator would have misdiagnosed this particular failure.

## Establish the musical target

For an artist recreation, identify a particular role in a particular recording:
supportive organ chords, expressive single-note lead, moving string ensemble,
struck electric piano, sequenced pulse or environmental texture. Consult original
musician/engineer accounts and instrument documentation. A list of equipment
owned across decades does not establish its use on a song.

Separate documented observations, measured reference features and design
interpretation in the notes. Do not report that you listened when only text or
spectra were available. Reference audio obtained through permitted access is
kept outside distributable assets; listening/analysis rights do not imply
sampling rights. Never put commercial record excerpts into zones or IRs.

For Pink, [Alan Parsons' original interview](https://www.premierguitar.com/diy/studio-legends-alan-parsons-on-dark-side-of-the-moon)
supports Leslie treatment on Breathe's guitar rig and restrained drum processing.
That passage does not establish a particular Hammond registration. The
[Wright archive gear list](https://rickwright.com/wp-content/uploads/2019/10/Richard-Wright-GEAR-list-WIP.pdf)
is explicitly work in progress; use it as era/context evidence with its limits.
Later-era Solina/Oberheim/JX equipment must not be assigned to Dark Side merely
because it appears in a Floyd-related collection.

## Give each role a foundation

Record excitation, signal path, attack/release behaviour, sustain movement,
controller response and practical register before implementing the patch.
Shared code is useful for the same physical family. Distinct musical
registrations can share an instrument; label them as registrations/variants.
Do not count EQ, room, a detuned duplicate or gain alone as a new source.

Choose mechanisms with audible consequences. Warmth may come from strong low
partials, transient/body contrast, electrical or mechanical behaviour and an
appropriate recording perspective. A universal low-pass cutoff, resonance bed,
sub layer or noise floor is not a substitute. Preserve useful upper articulation
and leave space between elements when the musical reference is sparse.

Examples of different foundations:

| Role | Source or mechanism | Playing behaviour to preserve |
| --- | --- | --- |
| Tonewheel support | Actual legal recordings or a documented tonewheel implementation: registration, foldback/leakage, keying; independent scanner/rotary stage where available | Immediate keying, sustained chords, expression control; appropriate percussion triggering and mono compatibility |
| Combo organ | Divided ranks and tab/register combinations with their own filtering and vibrato | Immediate chords, reed-like upper structure; avoid substituting smooth Hammond registration |
| Electric piano | Legally recorded struck tines/reeds with actual dynamics, takes and releases | Per-note physical decay, soft/hard gesture contrast, no endless sustain loop |
| String ensemble | Divided string ranks with string-forming envelopes and separately moving ensemble delays | Slower entry, independently evolving width; chorus rate should not simply follow note transposition |
| Connected lead | Defined oscillator registration/mixer, filter and loudness contours with live mono/legato pitch where supported | New attack after a rest, connected held notes, controlled delayed vibrato and useful wheel range |
| EMS-style texture | Ring modulation, noise, feedback or patch-matrix interaction appropriate to the reference | A genuinely changing pitched/inharmonic gesture; not another softened saw pad |
| Sequenced role | Playable tone plus actual MIDI sequence, or a truthful live rhythmic gate | Note choice belongs to the performer; distinguish MIDI/host tempo control from a fixed baked period |

An instrument name requires the corresponding mechanism or recording. Disclose
model captures, approximations and missing controls. Synth-engine licensing and
audio-output licensing are separate questions; verify both without assuming
that a free synthesizer grants rights to third-party included samples.

## Preserve movement and response

Do not bake a fixed phrase or chord into a generic chromatic note preset unless
the brief specifically asks for phrases. Do not claim host sync for fixed sample
modulation. If movement must be captured, use a musically adequate cycle, mapped
roots close enough to preserve its rate, and test several wraps under actual
pitch/controller use. A crossfade that hides a seam can still create periodic
phasing or erase the original movement.

Choose native defaults per role. A short electronic pluck needs its own decay;
a mono lead needs intentional retrigger/glide; an organ needs sustained keying.
Twenty-four voices with the same generic envelope is not a neutral default for
every instrument. Test mod-wheel and velocity at their zero, middle and high
positions; controller initialization must not accidentally mute the patch.

## Compare foundations before effects

Compare old/new and neighboring candidates at matched pitch, register and body
loudness, then with the same short musical phrase. Inspect onset, settled body,
held evolution and release separately. Include low/high registers, soft/hard
gestures, repeated notes, connected notes, chords where appropriate and a long
hold. Render actual defaults as well as diagnostic dry variants.

Setting native room/echo/tape to zero does not remove effects already rendered
into sample zones. Produce a separate dry source render for that comparison.
Keep raw recordings intact and provenance current.

Use spectral shape, partial balance, temporal modulation and stereo/mono
behaviour to locate convergence and defects. High correlation at one root is a
diagnostic flag, not a universal rejection threshold: related registrations can
be useful, and different spectra can still sound dull. Require an explanation
of the audible mechanism and intended role for each retained programme. Do not
broaden spectra or add random modulation just to improve a metric.

Model captures also need a practical memory budget. Long loops multiplied by
chromatic roots and rotor states can consume hundreds of megabytes even when
the archive compresses well. Keep the complete attack and enough evolving
sustain for the intended gesture; measure the decoded footprint before freezing
large sampled instruments. Do not shorten every loop indiscriminately.

A concrete Pink example: the first tonewheel capture used 61 chromatic roots ×
three rotor states × 28-second notes and occupied about 900 MiB in the resident
renderer. Preserving the full key/percussion entry and shorter matched sustain
windows reduced the first engine load to about 242 MiB without dropping roots,
rotor states or the 48 kHz bandwidth. Four same-path/rate engines shared the
sample data and used about 265 MiB total. Those measurements describe this
headless test, not every DAW, sample rate or patch. Long-hold and seam checks
remain necessary after shortening.

Distinguish offline rendering from plugin playback when measuring memory.
Libero's offline renderer deliberately loads resident audio; it does not test
VST sample streaming. Use the native host streaming/realtime profiles for that
claim, and separate fresh-process results from an allocator already warmed by a
resident reference load. Record the sample rate, instance count and block size.

The quality gate has two independent parts: technical operation and musical
fit. Report listener approval only after it occurs. A rejected collection needs
new foundations/behaviour where the feedback requires them; a clean lint result
and new names do not complete that revision.
