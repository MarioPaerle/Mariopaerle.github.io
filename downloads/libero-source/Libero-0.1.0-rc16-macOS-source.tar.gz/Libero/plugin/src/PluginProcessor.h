#pragma once

#include "AgentServer.h"
#include "Engine.h"

#include <juce_audio_processors/juce_audio_processors.h>

#include <array>
#include <atomic>
#include <functional>
#include <memory>

namespace libero
{

class LiberoProcessor : public juce::AudioProcessor,
                        public AgentServer::Delegate,
                        private juce::Timer
{
public:
    LiberoProcessor();
    ~LiberoProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Libero"; }
    bool acceptsMidi() const override  { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 10.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    juce::AudioProcessorValueTreeState& getState() noexcept { return apvts; }
    juce::UndoManager& getUndoManager() noexcept           { return undoManager; }
    juce::Point<int> preferredEditorSize() const noexcept
    {
        const auto size = editorSize.load (std::memory_order_relaxed);
        return { (int) (size >> 32), (int) (size & 0xffffffffu) };
    }
    void rememberEditorSize (int width, int height) noexcept
    {
        editorSize.store ((uint64_t) juce::jlimit (1000, 2600, width) << 32
                         | (uint64_t) juce::jlimit (560, 1600, height), std::memory_order_relaxed);
    }

    // Message thread. Loads on a background thread; done(ok, titleOrError) is called on the
    // message thread. applyManifestParams: reset params to defaults + the bundle's "params".
    void loadSound (const juce::File& path, bool applyManifestParams,
                    std::function<void (bool, juce::String)> done = {}, bool allowStreaming = true);

    // Message thread: the current sound's folder was moved (sketch saved to the library).
    void soundMoved (const juce::File& from, const juce::File& to);

    // Message thread. Reload the current bundle from disk keeping the current parameter values
    // (picks up a recompile); `automatic` when triggered by the manifest watcher.
    void reloadSound (bool automatic, std::function<void (bool, juce::String)> done = {});
    // Message thread. The sound's own defaults again (SPEC defaults + manifest params).
    bool resetSound();
    // Message thread. Copy the current sound under a new title with the current settings as its
    // defaults, then load the copy. done(ok, pathOrError).
    void saveSoundAs (const juce::String& title, std::function<void (bool, juce::String)> done);
    juce::var setFavorite (const juce::File& soundFolder, bool favorite);
    juce::var setColorTag (const juce::File& soundFolder, int tag);
    bool isModified() const;             // params differ from the sound's defaults
    juce::var currentParamsAsDefaults() const;   // non-default params: {id: plain or choice}

    // Sample edits are stored beside a sound in the user's library. Source PCM stays intact.
    juce::var sampleEditorInfo() const;
    juce::var sampleEditorWaveform (const juce::String& zoneFile) const;
    static juce::var sampleEditorInfoForFolder (const juce::File& folder);
    static juce::var sampleEditorWaveformForFolder (const juce::File& folder, const juce::String& zoneFile);
    void applySampleEditorEdit (const juce::var& edit, std::function<void (bool, juce::String)> done);

    // Message thread: mirrors the engine's active articulation (a keyswitch) into the `artic`
    // parameter and tells the listeners. Cheap; called by both timers.
    void pollArticulation();
    juce::var getCurrentSoundInfo() const;     // message thread
    juce::String getCurrentSoundPath() const;  // any thread
    juce::var getAgentStatus() const;          // any thread
    juce::String getHostName() const           { return hostName; }

    // Any thread: queue an audition note / panic through the lock-free note queue.
    void queueNote (int pitch, int velocity, int durationMs) noexcept;
    void queuePanic() noexcept;

    // Scope data for the UI: 64 decimated points per channel and an RMS level.
    bool readScope (std::array<float, 64>& l, std::array<float, 64>& r, float& level);
    bool readSamplePlayback (Voice::Playback&);
    void setVisualisationActive (bool active) noexcept { visualisationActive.store (active, std::memory_order_relaxed); }

    struct Listener
    {
        virtual ~Listener() = default;
        virtual void soundChanged() {}
        virtual void soundLoading (const juce::var& /*info*/) {}
        virtual void soundLoadFailed (const juce::String& /*error*/) {}
        virtual void agentStatusChanged() {}
        virtual void soundReloaded (bool /*automatic*/) {}
        virtual void soundModifiedChanged (bool /*modified*/) {}
        virtual void articulationChanged (int /*index*/, const juce::String& /*id*/) {}
    };

    void addLiberoListener (Listener* l)    { listeners.add (l); }
    void removeLiberoListener (Listener* l) { listeners.remove (l); }

    AgentServer::Reply handleAgentRequest (const juce::String& method, const juce::var& params, juce::Thread& caller) override;
    void agentClientsChanged() override;

    int getAgentPort() const noexcept { return agent.getPort(); }

    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

private:
    void timerCallback() override;
    void applyParamValues (const juce::var& values, juce::Array<juce::var>& applied, juce::Array<juce::var>& rejected);
    void resetParamsToDefaults();
    bool runOnMessageThread (std::function<void()> fn, juce::Thread& caller, int timeoutMs);
    void notifyAgentStatus();

    struct NoteRequest { int pitch, velocity, durationMs; };

    juce::UndoManager undoManager;
    juce::AudioProcessorValueTreeState apvts;
    std::array<std::atomic<float>*, kNumParams> rawParams {};

    Engine engine;
    ParamSet paramSnapshot;

    // Agent/UI notes -> audio thread.
    juce::CriticalSection noteProducerLock; // UI and agent producers; audio never acquires it
    juce::AbstractFifo noteFifo { 256 };
    std::atomic<bool> emergencyPanic { false };
    std::array<NoteRequest, 256> noteQueue {};
    struct PendingOff { int pitch = -1; juce::int64 samplesLeft = 0; };
    std::array<PendingOff, 64> pendingOffs {};
    juce::MidiBuffer injected;

    // Audio thread -> UI scope.
    static constexpr int kScopeSize = 16384;
    std::atomic<bool> visualisationActive { false };
    std::atomic<uint64_t> editorSize { 0 };
    juce::AbstractFifo scopeFifo { kScopeSize };
    juce::AbstractFifo playbackFifo { 128 };
    std::array<Voice::Playback, 128> playbackQueue {};
    std::vector<float> scopeL, scopeR;
    std::vector<float> scopeReadL, scopeReadR;
    std::vector<float> scopeHistoryL, scopeHistoryR;

    // Sound state (message thread, mirrored for other threads under lock).
    juce::ThreadPool loaderPool { juce::ThreadPoolOptions{}.withThreadName ("Libero loader").withNumberOfThreads (1) };
    std::atomic<int> loadGeneration { 0 };
    std::atomic<bool> residentReloadQueued { false }, residentReloadRequested { false };
    juce::var currentSoundInfo;
    std::shared_ptr<SampleStreamPool> currentStreamPool;
    std::atomic<bool> publishedStreaming { false };
    uint64_t reportedStreamIssues = 0;
    juce::var manifestParams;             // "params" of the loaded bundle
    juce::Time loadedManifestTime;        // build/manifest.json mtime when it was loaded
    std::atomic<int> loadsInFlight { 0 };
    int watchTicks = 0;
    bool lastModified = false;
    int lastArticulation = -1;
    mutable juce::CriticalSection soundLock;
    juce::File currentSoundFolder;
    std::atomic<double> loadedRate { 0.0 };

    std::atomic<double> currentSampleRate { 48000.0 };
    std::atomic<int> currentBlockSize { 512 };

    AgentServer agent { *this };
    juce::String hostName;
    mutable juce::CriticalSection statusLock;
    juce::String lastAgentMessage;

    juce::ListenerList<Listener> listeners;
    void loadDefaultSound();
    std::atomic<bool> stateRestored { false };
    std::shared_ptr<std::atomic<bool>> alive = std::make_shared<std::atomic<bool>> (true);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LiberoProcessor)
};

} // namespace libero
