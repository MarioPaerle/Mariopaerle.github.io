#pragma once
#include <juce_gui_extra/juce_gui_extra.h>
namespace libero::packs
{
juce::var catalogue (bool refresh = false);
juce::var status();
juce::var start (const juce::String& id, bool application = false);
juce::var cancel();
juce::var openInstaller();
void setActiveSound (const void* instance, const juce::File& folder);
void forgetInstance (const void* instance);
std::shared_ptr<void> acquireSoundLoad (const juce::File& folder);
bool validateCatalogue (const juce::var& value);
#if LIBERO_HOST_TEST
void setCatalogueForTest (const juce::var& value);
#endif
}
