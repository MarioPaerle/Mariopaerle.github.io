#!/usr/bin/env python3
"""Native collection import tests: sessions, duplicates, partial failures and ZIP safety."""
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import zipfile

host = pathlib.Path(sys.argv[1]).resolve()
fixture = pathlib.Path(sys.argv[2]).resolve()


def run(args, home, expect_ok=True):
    env = dict(os.environ, LIBERO_HOME=str(home))
    proc = subprocess.run([str(host), *map(str, args)], env=env, text=True, capture_output=True, timeout=120)
    if (proc.returncode == 0) != expect_ok:
        raise AssertionError(f"unexpected result for {args}: {proc.stdout}\n{proc.stderr}")
    return json.loads(proc.stdout.strip().splitlines()[-1])


def bank_pack(out, version, source_hash="test-tone-source"):
    meta = {"format": "libero.bank/1", "slug": "test-bank", "title": "Test bank",
            "subtitle": "", "description": "", "version": version, "author": "", "license": "CC0",
            "created": "2026-01-01T00:00:00Z", "updated": "2026-01-01T00:00:00Z", "figure": None}
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("test-bank/bank.json", json.dumps(meta))
        for p in sorted((fixture / "build").rglob("*")):
            if p.is_file():
                name = p.relative_to(fixture).as_posix()
                data = p.read_bytes()
                if name == "build/manifest.json":
                    manifest = json.loads(data)
                    manifest["source_hash"] = source_hash
                    data = json.dumps(manifest).encode()
                z.writestr("test-bank/test-tone/" + name, data)
    return out


with tempfile.TemporaryDirectory(prefix="libero-bank-collection-") as td:
    root = pathlib.Path(td)
    home = root / "home"
    pack1 = bank_pack(root / "one.liberobank", "1.0.0")
    pack2 = bank_pack(root / "two.liberobank", "2.0.0")
    pack2same = bank_pack(root / "two-copy.liberobank", "2.0.0")
    pack2conflict = bank_pack(root / "two-conflict.liberobank", "2.0.0", "different-source")

    # A pack ZIP, an extracted pack, and an extracted collection all use the same review/install flow.
    direct_zip = root / "direct-pack.zip"
    shutil.copyfile(pack1, direct_zip)
    extracted = root / "Extracted packs"
    with zipfile.ZipFile(pack1) as archive:
        archive.extractall(extracted)
    flat_zip = root / "flat-pack.zip"
    with zipfile.ZipFile(pack1) as original, zipfile.ZipFile(flat_zip, "w") as archive:
        for name in original.namelist():
            archive.writestr(name.removeprefix("test-bank/"), original.read(name))
    finder_zip = root / "finder-pack.zip"
    with zipfile.ZipFile(pack1) as original, zipfile.ZipFile(finder_zip, "w") as archive:
        archive.writestr("test-bank/", b"")
        archive.writestr("__MACOSX/._test-bank", b"metadata")
        for name in original.namelist(): archive.writestr(name, original.read(name))
    folder_of_archives = root / "Downloaded packs"
    folder_of_archives.mkdir()
    shutil.copyfile(pack1, folder_of_archives / "pack.liberobank")
    bundle_folder = root / "Unzipped bundle"
    (bundle_folder / "Banks").mkdir(parents=True)
    shutil.copyfile(pack1, bundle_folder / "Banks/one.liberobank")
    for number, selected in enumerate([direct_zip, flat_zip, finder_zip, extracted / "test-bank", extracted, folder_of_archives, bundle_folder]):
        selected_home = root / f"folder-home-{number}"
        selected_plan = run(["--inspect-bank-collection", selected], selected_home)
        assert len(selected_plan["entries"]) == 1 and selected_plan["entries"][0]["ok"], (str(selected), selected_plan)
        run(["--import-bank-collection-entry", selected_plan["sessionId"], 0], selected_home)
        assert (selected_home / "banks/test-bank/test-tone/build/manifest.json").is_file()
        run(["--cleanup-bank-collection", selected_plan["sessionId"]], selected_home)
    # Deletion cannot address personal sounds, traversal paths, missing packs or symlink targets.
    delete_home = root / "delete-home"
    installed = delete_home / "banks/test-bank"
    installed.mkdir(parents=True)
    (installed / "bank.json").write_text('{"slug":"test-bank"}')
    for slug in ["../outside", "mie", "prove", "missing"]:
        run(["--delete-bank", slug], delete_home, expect_ok=False)
        assert installed.exists()
    run(["--delete-bank", "test-bank"], delete_home)
    assert not installed.exists()
    if os.name != "nt":
        (extracted / "test-bank/unsafe-link").symlink_to(fixture, target_is_directory=True)
        run(["--inspect-bank-collection", extracted / "test-bank"], root / "symlink-home", expect_ok=False)
        (extracted / "test-bank/unsafe-link").unlink()

    # Direct multi-select chooses only the highest selected version and retains its staging session.
    plan = run(["--inspect-bank-collection", pack1, pack2], home)
    assert plan["format"] == "libero.bank-collection/1" and len(plan["entries"]) == 2
    winner = next(i for i, e in enumerate(plan["entries"]) if e.get("bank", {}).get("version") == "2.0.0")
    loser = 1 - winner
    assert plan["entries"][winner]["action"] == "install"
    assert plan["entries"][loser]["code"] == "DUPLICATE_SELECTION"
    session = plan["sessionId"]
    imported = run(["--import-bank-collection-entry", session, winner], home)
    assert imported["ok"] is True and imported["slug"] == "test-bank"
    assert (home / "cache" / "import-sessions" / session).is_dir()
    run(["--cleanup-bank-collection", session], home)
    assert not (home / "cache" / "import-sessions" / session).exists()

    # Identical same-version inputs collapse to one; divergent contents become an explicit conflict.
    duplicate_home = root / "duplicate-home"
    same = run(["--inspect-bank-collection", pack2, pack2same], duplicate_home)
    assert sum(e.get("action") == "install" for e in same["entries"]) == 1
    assert sum(e.get("code") == "DUPLICATE_SELECTION" for e in same["entries"]) == 1
    run(["--cleanup-bank-collection", same["sessionId"]], duplicate_home)
    conflict = run(["--inspect-bank-collection", pack2, pack2conflict], duplicate_home)
    assert all(e.get("code") == "VERSION_CONFLICT" for e in conflict["entries"])
    run(["--cleanup-bank-collection", conflict["sessionId"]], duplicate_home)

    # A bundle ZIP may contain good packs, a broken bank and its harmless catalog documents.
    broken = root / "broken.liberobank"
    broken.write_bytes(b"not a ZIP")
    collection = root / "base.zip"
    with zipfile.ZipFile(collection, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(pack1, "Libero Base Bundle/test-bank-1.liberobank")
        z.write(broken, "Libero Base Bundle/broken.liberobank")
        z.writestr("Libero Base Bundle/README.txt", "fixture")
        z.writestr("Libero Base Bundle/catalog.json", "{}")
        z.writestr("Libero Base Bundle/SHA256SUMS", "")
        z.writestr("Libero Base Bundle/SOUND-DATA-TERMS.md", "fixture terms")
    partial = run(["--inspect-bank-collection", collection], home)
    assert len(partial["entries"]) == 2
    assert sum(bool(e.get("ok")) for e in partial["entries"]) == 1
    assert sum(not bool(e.get("ok")) for e in partial["entries"]) == 1
    run(["--cleanup-bank-collection", partial["sessionId"]], home)

    unsafe = root / "unsafe.zip"
    with zipfile.ZipFile(unsafe, "w") as z:
        z.writestr("../escape.liberobank", pack1.read_bytes())
    rejected = run(["--inspect-bank-collection", unsafe], home, expect_ok=False)
    assert rejected["code"] == "UNSAFE_ARCHIVE"
    assert not (root / "escape.liberobank").exists()

    # File/directory collisions must be rejected regardless of ZIP record order or case.
    for reverse in (False, True):
        collisions = root / f"bank-collision-{reverse}.liberobank"
        with zipfile.ZipFile(pack1) as original, zipfile.ZipFile(collisions, "w") as archive:
            for name in original.namelist(): archive.writestr(name, original.read(name))
            pair = [("test-bank/test-tone/build/ALIAS", b"file"),
                    ("test-bank/test-tone/build/alias/child.txt", b"child")]
            for name,data in (pair[::-1] if reverse else pair): archive.writestr(name,data)
        result = run(["--inspect-bank", collisions], home, expect_ok=False)
        assert result["code"] == "UNSAFE_ARCHIVE"
        collection_collision = root / f"collection-collision-{reverse}.zip"
        with zipfile.ZipFile(collection_collision, "w") as archive:
            pair = [("Base/README.txt", b"file"), ("Base/readme.txt/one.liberobank", pack1.read_bytes())]
            for name,data in (pair[::-1] if reverse else pair): archive.writestr(name,data)
        result = run(["--inspect-bank-collection", collection_collision], home, expect_ok=False)
        assert result["code"] == "UNSAFE_ARCHIVE"

    # Corrupt compressed member bytes are rejected by length/CRC verification before any bank import.
    corrupt = root / "corrupt.zip"
    with zipfile.ZipFile(corrupt, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(pack1, "Base/test-bank-1.liberobank")
    with zipfile.ZipFile(corrupt) as z:
        info = z.getinfo("Base/test-bank-1.liberobank")
        with corrupt.open("r+b") as f:
            f.seek(info.header_offset + 30 + len(info.filename.encode()) + len(info.extra) + info.compress_size // 2)
            byte = f.read(1)
            f.seek(-1, 1)
            f.write(bytes([byte[0] ^ 0x40]))
    corrupt_result = run(["--inspect-bank-collection", corrupt], home, expect_ok=False)
    assert corrupt_result["code"] == "UNSAFE_ARCHIVE"
