#pragma once

#include "Dsp.h"
#include "Params.h"

#include <array>

namespace libero
{

// Optional warm EQ + stereo-linked soft-knee parallel compressor. No limiter,
// saturation, delay, or pitch motion; the default mode is an exact bypass.
class Caldi
{
public:
    void prepare (float sampleRate);
    void reset() noexcept;
    void set (int mode, float amount, float body, float light, float grain,
              float motion, float outputDb) noexcept;
    void process (float* l, float* r, int n) noexcept;
private:
    struct Biquad
    {
        float b0=1, b1=0, b2=0, a1=0, a2=0, z1=0, z2=0;
        float tick (float x) noexcept;
        void shelf (float hz, float db, bool high, float sr) noexcept;
        void peak (float hz, float db, float q, float sr) noexcept;
        void clear() noexcept { z1=z2=0; }
    };
    void configure() noexcept;
    std::array<Biquad, 3> eqL, eqR;
    dsp::Smoother mix, bodyS, lightS, grainS, motionS, outputS;
    dsp::OnePoleLP noiseLow, noiseHigh;
    dsp::Rng rng;
    float sr=48000, envelope=0, gainDb=0, gate=0;
    float threshold=-22, ratio=2, attack=.001f, release=.001f, parallel=.45f, makeup=1;
    float body=.5f, light=.5f, grain=0, motion=0, output=0, amount=.65f;
    float noiseBottom=180, noiseTop=2200;
    int configuredMode=-1;
    float configuredBody=-1, configuredLight=-1;
    int requested=0, active=0;
    double phase=0, phase2=0;
};

//==============================================================================
// Bank of two-pole modal resonators excited by the voice sum (Vetro / Legno / Metallo).
class ModalResonator
{
public:
    void prepare (float sampleRate);
    void reset() noexcept;

    // Control rate. mode must be one of vetro/legno/metallo; a change fades out, swaps, fades in.
    void set (ResMode mode, float tuneSemis, float decay, float bright) noexcept;

    // In place: out = in + amount * wet. amount is per sample.
    void process (float* l, float* r, const float* amount, int n) noexcept;

private:
    static constexpr int kModes = 12;

    void configure (ResMode) noexcept;
    void computeCoeffs() noexcept;

    struct Mode
    {
        float ratio = 1.0f, amp = 0.0f, decayScale = 1.0f, pan = 0.5f;
        float a1 = 0.0f, a2 = 0.0f, b = 0.0f, gl = 0.0f, gr = 0.0f;
        float y1 = 0.0f, y2 = 0.0f;
    };

    std::array<Mode, kModes> modes;
    float x1 = 0.0f, x2 = 0.0f;
    float sampleRate = 48000.0f;

    ResMode current = ResMode::vetro, pending = ResMode::vetro;
    float baseHz = 523.25f;
    float tune = 0.0f, decay = 0.5f, bright = 0.5f;
    float fade = 1.0f, fadeStep = 0.0f;
    bool dirty = true, running = false;
};

//==============================================================================
// Nastro: wow/flutter transport, saturation, age (hiss, HF loss, dropouts). Deterministic.
class Tape
{
public:
    void prepare (float sampleRate);
    void reset() noexcept;
    void set (float wow, float flutter, float sat, float age, float mix) noexcept;
    void process (float* l, float* r, int n) noexcept;

private:
    dsp::DelayLine lineL, lineR;
    dsp::Smoother wow, flutter, sat, age, mix, baseDelay;
    dsp::OnePoleLP hfL, hfR, hissL, hissR, drift;
    dsp::DCBlocker dcL, dcR, satDcL, satDcR;
    dsp::Rng rng;
    float sampleRate = 48000.0f;
    double wowPhase = 0.0, flutPhase = 0.0, flutPhase2 = 0.0;
    float driftTarget = 0.0f;
    int driftCounter = 0;
    int dropCountdown = 0, dropRemaining = 0;
    float dropDepth = 0.0f, dropGain = 1.0f;
};

//==============================================================================
// Eco: stereo feedback delay with tone filter in the loop and ping-pong spread.
class Echo
{
public:
    void prepare (float sampleRate);
    void reset() noexcept;
    // Libero mode (synced = false): timeMs, slewed like a tape echo. Tempo mode: the delay is
    // `beats` quarter notes at `bpm`; a change crossfades between two taps (no pitch glide).
    void set (float timeMs, float feedback, float tone, float spread, float mix) noexcept;
    void setSynced (bool synced, float beats, float bpm) noexcept;
    void process (float* l, float* r, int n) noexcept;

private:
    dsp::DelayLine lineL, lineR;
    dsp::Smoother time, feedback, spread, mix;
    bool synced = false;
    float syncTarget = 0.0f;           // samples
    float curT = 0.0f, newT = 0.0f;    // the delay in use / the one fading in (samples)
    float xf = 1.0f, xfStep = 0.0f;    // crossfade position 0..1 (1 = settled)
    dsp::OnePoleLP lpL, lpR, hpL, hpR;
    float sampleRate = 48000.0f, configuredTone = -1.0f;
};

} // namespace libero
