#include "Voice.h"

namespace libero
{

using namespace dsp;

//==============================================================================
float Envelope::shape (float p, float curve, bool rising) noexcept
{
    if (std::abs (curve) < 1e-3f)
        return p;

    const auto k = 1.0f + 4.0f * std::abs (curve);
    const auto convex  = std::pow (p, k);                  // slow start, fast finish
    const auto concave = 1.0f - std::pow (1.0f - p, k);    // fast start, slow finish

    // curve < 0: exponential-ish (convex rise, fast early fall); > 0: logarithmic-ish.
    if (rising)
        return curve < 0.0f ? convex : concave;

    return curve < 0.0f ? concave : convex;
}

float Envelope::advance (int n, const VoiceControl& c) noexcept
{
    const auto msToStep = [&] (float ms) { return (float) n / std::max (1.0f, ms * 0.001f * c.sampleRate); };

    switch (stage)
    {
        case Stage::idle:
            value = 0.0f;
            break;

        case Stage::attack:
            progress += msToStep (c.attackMs);

            if (progress >= 1.0f)
            {
                value = 1.0f;
                stage = Stage::decay;
                progress = 0.0f;
                from = 1.0f;
            }
            else
            {
                value = from + (1.0f - from) * shape (progress, c.curve, true);
            }
            break;

        case Stage::decay:
            progress += msToStep (c.decayMs);

            if (progress >= 1.0f)
            {
                value = c.sustain;
                stage = Stage::sustain;
            }
            else
            {
                value = 1.0f + (c.sustain - 1.0f) * shape (progress, c.curve, false);
            }
            break;

        case Stage::sustain:
            value = c.sustain;
            break;

        case Stage::release:
            progress += msToStep (c.releaseMs);

            if (progress >= 1.0f)
            {
                value = 0.0f;
                stage = Stage::idle;
            }
            else
            {
                value = from * (1.0f - shape (progress, c.curve, false));
            }
            break;
    }

    return value;
}

//==============================================================================
void CordeResonator::prepare (float sr)
{
    sampleRate = sr;
    coefficientsValid = false;

    for (auto& l : lines)
        l.allocate ((int) (sr / 20.0f) + 16);

    reset();
}

void CordeResonator::reset() noexcept
{
    if (! active)
        return;

    for (auto& l : lines)
        l.reset();

    prev.fill (0.0f);
    active = false;
}

void CordeResonator::setNote (float noteSemis, const VoiceControl& c) noexcept
{
    if (coefficientsValid && noteSemis == lastNote && c.resTune == lastTune
        && c.resDecay == lastDecay && c.resBright == lastBright)
        return;

    lastNote = noteSemis;
    lastTune = c.resTune;
    lastDecay = c.resDecay;
    lastBright = c.resBright;
    coefficientsValid = true;

    static constexpr float ratios[kStrings] = { 1.0f, 1.5f, 2.0f, 1.33484f };
    static constexpr float pans[kStrings]   = { 0.5f, 0.2f, 0.8f, 0.35f };

    const auto f0 = 440.0f * std::exp2 ((noteSemis + c.resTune - 69.0f) / 12.0f);
    const auto t60 = 0.05f * std::exp2 (8.0f * clampf (c.resDecay, 0.0f, 1.0f));
    const auto b = clampf (c.resBright, 0.0f, 1.0f) * 0.96f;

    c0 = 0.5f + 0.5f * b;
    c1 = 0.5f - 0.5f * b;

    float gainSum = 0.0f;

    for (int s = 0; s < kStrings; ++s)
    {
        const auto f = clampf (f0 * ratios[s], 20.0f, sampleRate * 0.25f);
        delay[(size_t) s] = clampf (sampleRate / f - c1, 2.0f, (float) lines[(size_t) s].capacity() - 4.0f);
        fb[(size_t) s] = std::min (0.9995f, std::pow (10.0f, -3.0f / (t60 * f)));
        gainSum += 1.0f - fb[(size_t) s];

        panL[(size_t) s] = std::sqrt (1.0f - pans[s]);
        panR[(size_t) s] = std::sqrt (pans[s]);
    }

    inGain = 1.5f * gainSum / kStrings;
}

void CordeResonator::process (const float* inL, const float* inR, float* outL, float* outR,
                              const float* amount, int n) noexcept
{
    if (amount[0] <= 0.0f && amount[n - 1] <= 0.0f)
    {
        if (active)
            reset();

        return;
    }

    active = true;

    for (int i = 0; i < n; ++i)
    {
        const auto x = (inL[i] + inR[i]) * 0.5f * inGain;
        float wetL = 0.0f, wetR = 0.0f;

        for (int s = 0; s < kStrings; ++s)
        {
            auto& line = lines[(size_t) s];
            const auto d = line.readHermite (delay[(size_t) s] - 1.0f);
            const auto lf = c0 * d + c1 * prev[(size_t) s];
            prev[(size_t) s] = d;
            line.push (fastTanh (x + fb[(size_t) s] * lf));
            wetL += lf * panL[(size_t) s];
            wetR += lf * panR[(size_t) s];
        }

        outL[i] = inL[i] + amount[i] * wetL * 0.5f;
        outR[i] = inR[i] + amount[i] * wetR * 0.5f;
    }
}

//==============================================================================
float Voice::Player::sample (int ch, int i) const noexcept
{
    const auto& a = zone->audio;

    if (i < 0)
        return 0.0f;

    if (zone->looped && i >= zone->loopEnd)
        i = zone->loopStart + (i - zone->loopEnd) % (zone->loopEnd - zone->loopStart);

    if (zone->stream != nullptr)
        return stream.sample (ch, i);

    if (i >= a.getNumSamples())
        return 0.0f;

    return a.getReadPointer (std::min (ch, a.getNumChannels() - 1))[i];
}

void Voice::Player::read (float& l, float& r) const noexcept
{
    // Fixed velocity layers that are inaudible keep their timeline but need no disk slot.
    if (zone->stream != nullptr && ! streamAttempted)
    {
        stream = zone->streamPool->acquire (zone->stream);
        streamAttempted = true;
        stream.position ((int) pos);
    }
    stream.beginRead();
    const auto i = (int) pos;
    const auto f = (float) (pos - (double) i);

    if (zone->stream != nullptr)
        stream.read (i, f, l, r);
    else if (f == 0.0f && i >= 0 && i < endFrame && (!looping || i < loopEnd))
    {
        l = zone->audio.getReadPointer (0)[i];
        r = zone->audio.getNumChannels() > 1 ? zone->audio.getReadPointer (1)[i] : l;
    }
    else if (f == 0.0f)
    {
        l = sample (0, i);
        r = zone->audio.getNumChannels() > 1 ? sample (1, i) : l;
    }
    else if (i > 0 && i + 2 < endFrame && (! looping || i + 2 < loopEnd))
    {
        const auto* left = zone->audio.getReadPointer (0) + i;
        l = hermite (left[-1], left[0], left[1], left[2], f);
        if (zone->audio.getNumChannels() > 1)
        {
            const auto* right = zone->audio.getReadPointer (1) + i;
            r = hermite (right[-1], right[0], right[1], right[2], f);
        }
        else r = l;
    }
    else
    {
        l = hermite (sample (0, i - 1), sample (0, i), sample (0, i + 1), sample (0, i + 2), f);
        r = zone->audio.getNumChannels() > 1
            ? hermite (sample (1, i - 1), sample (1, i), sample (1, i + 1), sample (1, i + 2), f) : l;
    }

    if (zone->stream != nullptr)
    {
        if (stream.missedRead())
        {
            streamGain = std::max (0.0f, streamGain - 1.0f / 64.0f);
            l = lastStreamL * streamGain; r = lastStreamR * streamGain;
        }
        else
        {
            lastStreamL = l; lastStreamR = r;
            streamGain = std::min (1.0f, streamGain + 1.0f / 64.0f);
            l *= streamGain; r *= streamGain;
        }
    }
    if (fadeLeft > 0)
    {
        const auto g = 1.0f - (float) fadeLeft / (float) (fadeLen + 1);
        l *= g;
        r *= g;
    }
}

void Voice::Player::advance() noexcept
{
    pos += inc;

    if (fadeLeft > 0)
        --fadeLeft;

    if (looping)
    {
        while (pos >= (double) loopEnd)
            pos -= (double) (loopEnd - loopStart);
    }
    else if (pos >= (double) endFrame)
    {
        active = false;
        stream.reset();
    }
}

double Voice::Player::ratioFor (float semitones, float playbackScale) const noexcept
{
    if (zone == nullptr || ! zone->pitched)
        return playbackScale;

    return playbackScale * std::exp2 (((double) semitones + 0.01 * (double) zone->tuneCents - zone->root) / 12.0);
}

//==============================================================================
void Voice::prepare (float sr)
{
    sampleRate = sr;
    filterHz = -1.0f;
    corde.prepare (sr);
    oscs.prepare (sr);
    kill();
}

void Voice::start (const SoundData& sd, int noteIn, int velIn, float startPitch, uint64_t orderIn,
                   const VoiceControl& c, const NoteSetup& setup) noexcept
{
    sound = &sd;
    takes = setup.takes;
    art = setup.art;
    legatoPending = legatoGlide = false;
    bodyOld.clear();
    xfade = 1.0f;
    noteDyn = setup.dyn;
    lastDyn = setup.dyn < 0.0f ? 0.0f : setup.dyn;
    startDelay = setup.delay;
    oscs.start (setup.oscSeed, setup.oscRetrigger);
    tailGain = 1.0f;
    age = 0;
    note = noteIn;
    velocity = juce::jlimit (1, 127, velIn);
    order = orderIn;

    active = true;
    keyDown = true;
    released = false;
    stealing = false;
    sustained = false;
    stealGain = 1.0f;
    silentSamples = 0;
    ringSamples = 0;

    const auto v = (float) velocity / 127.0f;
    velGain = setup.hasVelocityGain ? setup.velocityGain
                                    : lerp (1.0f, v * std::sqrt (v), clampf (c.velSens, 0.0f, 1.0f)) * setup.gain;
    velGainTarget = velGain;
    velGainRamp = 0;

    targetPitch = (float) note + setup.detune;
    pitch = (c.glideMs > 0.5f && startPitch >= 0.0f) ? startPitch : targetPitch;

    attack.setup (sd, note, velocity, takes.attack, Layer::attack, art);
    attack.weigh (setup.dyn, setup.dyn);   // dynamics layers of the attack: crossfaded once, per note
    body.setup (sd, note, velocity, takes.body, Layer::body, art);
    bodyZone = body.leadZone();
    oneShot = bodyZone != nullptr && bodyZone->oneShot;
    tail.clear();
    hasTail = ! sd.byLayer[(size_t) Layer::tail].empty();

    env.reset();
    env.start();
    lastEnv = 0.0f;
    fenv.reset();
    fenv.start();
    lastFenv = 0.0f;

    for (auto& f : svf)
        f.reset();

    for (auto& ch : formant)
        for (auto& f : ch)
            f.reset();

    corde.reset();
}

void Voice::noteOff() noexcept
{
    if (released || ! active || sound == nullptr)
        return;

    if (oneShot && ! stealing)
    {
        keyDown = false;   // the sample plays on; the envelope stays in sustain
        sustained = false;
        return;
    }

    released = true;
    keyDown = false;
    sustained = false;
    env.release();
    fenv.release();

    if (! stealing)
    {
        tail.setup (*sound, note, velocity, takes.tail, Layer::tail, art);
        tail.weigh (lastDyn, lastDyn);

        // Release by duration (SFZ rt_decay): the longer the note was held, the quieter its tail.
        if (const auto* z = tail.leadZone(); z != nullptr && z->rtDecay > 0.0f)
            tailGain = dbToGain (std::max (z->rtMinDb, -z->rtDecay * (float) age / sampleRate));
    }
}

void Voice::legatoTo (int newNote, const NoteSetup& setup) noexcept
{
    if (! active || released || stealing || sound == nullptr)
        return;

    note = newNote;
    if (setup.hasVelocityGain)
    {
        velGainTarget = setup.velocityGain;
        velGainRamp = std::max (1, (int) (0.025f * sampleRate));
        velGainStep = (velGainTarget - velGain) / (float) velGainRamp;
    }
    targetPitch = (float) newNote + setup.detune;
    takes.body = setup.takes.body;
    takes.tail = setup.takes.tail;
    art = setup.art;
    legatoGlide = true;
    legatoPending = true;
}

//==============================================================================
void Voice::BodySource::setup (const SoundData& sd, int key, int vel, int take, Layer layer, int art) noexcept
{
    clear();
    xf = sd.dynCrossfade;
    const auto g = sd.findKeyGroup (layer, key, vel, art);

    if (g < 0)
        return;

    const auto set = sd.groupDynSet[(size_t) g];

    if (set < 0)
    {
        p[0].start (&sd.zoneOf (g, take));
        centre[0] = 0.0f;
        count = 1;
    }
    else
    {
        for (auto member : sd.dynSets[(size_t) set])
        {
            if (count == kMax)
                break;

            const auto& z = sd.zoneOf (member, take);
            p[(size_t) count].start (&z);
            centre[(size_t) count] = z.dynCentre();
            ++count;
        }
    }

    w0.fill (0.0f);
    w1.fill (0.0f);
    w0[0] = w1[0] = 1.0f;
    lead = 0;
    weightedCount = 1;
    weightedPlayers[0] = 0;
}

void Voice::BodySource::clear() noexcept
{
    weightsValid = false;
    weightedCount = 0;
    for (auto& player : p)
    {
        player.active = false;
        player.stream.reset();
        player.zone = nullptr;
    }

    count = 0;
    lead = 0;
}

bool Voice::BodySource::active() const noexcept
{
    for (int k = 0; k < count; ++k)
        if (p[(size_t) k].active)
            return true;

    return false;
}

bool Voice::BodySource::sameAs (const BodySource& o) const noexcept
{
    if (count != o.count)
        return false;

    for (int k = 0; k < count; ++k)
        if (p[(size_t) k].zone != o.p[(size_t) k].zone)
            return false;

    return true;
}

void Voice::weightsFor (const BodySource& b, float d, std::array<float, BodySource::kMax>& w) noexcept
{
    w.fill (0.0f);

    if (b.count <= 1 || d <= b.centre[0])
    {
        w[0] = 1.0f;
        return;
    }

    const auto last = b.count - 1;

    if (d >= b.centre[(size_t) last])
    {
        w[(size_t) last] = 1.0f;
        return;
    }

    int i = 0;

    while (i + 1 < last && d > b.centre[(size_t) i + 1])
        ++i;

    const auto span = std::max (1.0e-6f, b.centre[(size_t) i + 1] - b.centre[(size_t) i]);
    auto t = clampf ((d - b.centre[(size_t) i]) / span, 0.0f, 1.0f);

    if (b.xf >= 0.0f)
    {
        // Blend only over the middle `xf` of the gap; outside it a single layer plays.
        const auto x = std::min (1.0f, b.xf);
        t = x <= 0.0f ? (t < 0.5f ? 0.0f : 1.0f) : clampf ((t - (0.5f - 0.5f * x)) / x, 0.0f, 1.0f);
    }

    w[(size_t) i] = std::cos (t * 0.5f * kPi);
    w[(size_t) i + 1] = std::sin (t * 0.5f * kPi);
}

void Voice::BodySource::weigh (float d0, float d1) noexcept
{
    if (count <= 1)
        return;

    if (weightsValid && d0 == weightedStart && d1 == weightedEnd)
        return;
    weightsFor (*this, d0, w0);
    if (d0 == d1) w1 = w0;
    else weightsFor (*this, d1, w1);
    weightedStart = d0;
    weightedEnd = d1;
    weightsValid = true;
    weightedCount = 0;
    for (int k = 0; k < count; ++k)
        if (w0[(size_t) k] > 0.0f || w1[(size_t) k] > 0.0f)
        {
            weightedPlayers[(size_t) weightedCount++] = k;
        }

    lead = 0;

    for (int k = 1; k < count; ++k)
        if (w1[(size_t) k] > w1[(size_t) lead])
            lead = k;
}

void Voice::BodySource::setInc (float semitones, float playbackScale) noexcept
{
    for (int k = 0; k < count; ++k)
        if (p[(size_t) k].active)
            p[(size_t) k].setIncrement (semitones, playbackScale);
}

void Voice::BodySource::setPos (double pos) noexcept
{
    for (int k = 0; k < count; ++k)
    {
        auto& player = p[(size_t) k];

        if (player.zone == nullptr)
            continue;

        auto q = pos;

        if (player.zone->looped)
            while (q >= (double) player.zone->loopEnd)
                q -= (double) (player.zone->loopEnd - player.zone->loopStart);

        player.pos = q;
        player.active = player.zone->looped || q < (double) player.zone->length();
    }
}

void Voice::BodySource::read (int i, int n, float& l, float& r) const noexcept
{
    if (count == 1)
    {
        p[0].read (l, r);
        return;
    }

    l = r = 0.0f;
    const auto t = (float) (i + 1) / (float) n;

    for (int index = 0; index < weightedCount; ++index)
    {
        const auto k = weightedPlayers[(size_t) index];
        const auto w = w0[(size_t) k] + (w1[(size_t) k] - w0[(size_t) k]) * t;

        if (w <= 0.0f || ! p[(size_t) k].active)
            continue;

        float a, b;
        p[(size_t) k].read (a, b);
        l += w * a;
        r += w * b;
    }
}

void Voice::BodySource::advance() noexcept
{
    for (int k = 0; k < count; ++k)
        if (p[(size_t) k].active)
            p[(size_t) k].advance();
}

float Voice::Player::mono (double at) const noexcept
{
    const auto i = (int) at;
    const auto f = (float) (at - (double) i);
    return hermite (sample (0, i - 1), sample (0, i), sample (0, i + 1), sample (0, i + 2), f);
}

void Voice::beginLegato (const VoiceControl& c) noexcept
{
    legatoPending = false;

    BodySource incomingSource;
    incomingSource.setup (*sound, note, velocity, takes.body, Layer::body, art);

    if (incomingSource.count == 0 || incomingSource.sameAs (body) || ! body.active())
        return;   // same zone: the glide alone carries the slur

    incomingSource.weigh (lastDyn, lastDyn);

    const auto p = pitch + c.pitchOffset;   // both zones sound at the current (gliding) pitch

    const auto& current = body.p[(size_t) body.lead];
    const auto& incoming = incomingSource.p[(size_t) incomingSource.lead];
    const auto* next = incoming.zone;
    const auto incOld = current.ratioFor (p, c.playbackScale);
    const auto incNew = incoming.ratioFor (p, c.playbackScale);

    // Same point in the recorded note's life (zones of one sound share a timeline).
    auto base = current.pos;

    const auto wrap = [next] (double pos)
    {
        if (next->looped)
            while (pos >= (double) next->loopEnd)
                pos -= (double) (next->loopEnd - next->loopStart);

        return pos;
    };

    base = wrap (base);

    if (! next->looped && base >= (double) next->length() - 4.0)
        return;   // the new zone has already died out at this point: nothing to fade to

    // Phase-align: try 16 offsets across one period and keep the best-correlated one, so the
    // two tones reinforce instead of cancelling during the crossfade.
    const auto hz = 440.0 * std::exp2 (((double) p - 69.0) / 12.0);
    const auto period = incNew * (double) sampleRate / std::max (20.0, hz);
    constexpr int kProbe = 128, kOffsets = 16;

    double bestPos = base, bestCorr = -1.0e30, bestRho = 0.0;

    for (int k = 0; k < kOffsets; ++k)
    {
        const auto start = wrap (base + period * k / kOffsets);
        double xy = 0.0, xx = 0.0, yy = 0.0;

        for (int i = 0; i < kProbe; ++i)
        {
            const auto x = (double) current.mono (current.pos + incOld * i);
            const auto y = (double) incoming.mono (wrap (start + incNew * i));
            xy += x * y;
            xx += x * x;
            yy += y * y;
        }

        if (xy > bestCorr)
        {
            bestCorr = xy;
            bestPos = start;
            bestRho = xy / std::sqrt (std::max (1.0e-20, xx * yy));
        }
    }

    bodyOld = body;
    body = incomingSource;
    body.setPos (bestPos);
    body.setInc (p, c.playbackScale);
    xfade = 0.0f;
    xfadeStep = 1.0f / (0.03f * sampleRate);
    xfadeRho = clampf ((float) bestRho, 0.0f, 1.0f);
}

void Voice::steal() noexcept
{
    if (! active || stealing)
        return;

    // A replaced voice that has not rendered cannot need a declick fade. This
    // also prevents simultaneous over-limit notes from producing short blips.
    if (age == 0)
    {
        kill();
        return;
    }

    stealing = true;
    keyDown = false;
    stealStep = 1.0f / (0.004f * sampleRate);
}

void Voice::choke() noexcept
{
    if (! active || stealing)
        return;

    // A replaced voice that has not rendered cannot need a declick fade. This
    // also prevents simultaneous over-limit notes from producing short blips.
    if (age == 0)
    {
        kill();
        return;
    }

    stealing = true;
    keyDown = false;
    sustained = false;
    stealStep = 1.0f / (0.015f * sampleRate);
}

void Voice::kill() noexcept
{
    active = false;
    stealing = false;
    keyDown = false;
    released = true;
    attack.clear();
    tail.clear();
    body.clear();
    bodyOld.clear();
    xfade = 1.0f;
    legatoPending = legatoGlide = false;
    sound = nullptr;
    bodyZone = nullptr;
    oneShot = false;
    env.reset();
    fenv.reset();
}

void Voice::upgradeResident (const SoundData& resident) noexcept
{
    if (sound == nullptr) return;
    const auto* old = sound;
    const auto replace = [&] (BodySource& source)
    {
        for (auto& player : source.p)
            if (player.zone)
            {
                const auto index = (size_t) (player.zone - old->zones.data());
                player.stream.reset();
                player.zone = &resident.zones[index];
            }
    };
    replace (attack); replace (body); replace (bodyOld); replace (tail);
    if (bodyZone) bodyZone = &resident.zones[(size_t) (bodyZone - old->zones.data())];
    sound = &resident;
}

void Voice::updateFilter (const VoiceControl& c, float e, float lfoOctaves) noexcept
{
    auto fc = c.cutoff;
    if (c.fltEnv != 0.0f)
        fc *= std::exp2 (c.fltEnv * 5.0f * e);

    if (lfoOctaves != 0.0f)
        fc *= std::exp2 (lfoOctaves);

    fc = clampf (fc, 20.0f, 20000.0f);
    const auto usesFormant = c.fltModeA == (int) FilterMode::vocale || c.fltModeB == (int) FilterMode::vocale;
    if (fc == filterHz && c.reso == filterReso && usesFormant == filterUsesFormant)
        return;

    filterHz = fc;
    filterReso = c.reso;
    filterUsesFormant = usesFormant;
    const auto q = 0.5f * std::exp2 (clampf (c.reso, 0.0f, 1.0f) * 5.6f);

    for (auto& f : svf)
        f.setup (fc, q, sampleRate);

    bpNorm = svf[0].k * (1.0f + c.reso);

    if (! usesFormant)
        return;

    // Vowels ordered dark -> bright: u o a e i. Formant freqs/gains/bandwidths (tenor).
    static constexpr float F[5][3]  = { { 350, 600, 2700 }, { 400, 800, 2600 }, { 650, 1080, 2650 },
                                        { 400, 1700, 2600 }, { 290, 1870, 2800 } };
    static constexpr float G[5][3]  = { { 0, -20, -17 }, { 0, -10, -12 }, { 0, -6, -7 },
                                        { 0, -14, -12 }, { 0, -15, -18 } };
    static constexpr float BW[5][3] = { { 40, 60, 100 }, { 40, 80, 100 }, { 80, 90, 120 },
                                        { 70, 80, 100 }, { 40, 90, 100 } };

    const auto pos = clampf (std::log2 (fc / 20.0f) / std::log2 (1000.0f), 0.0f, 1.0f) * 4.0f;
    const auto i0 = std::min (3, (int) pos);
    const auto t = pos - (float) i0;
    const auto qScale = 0.4f + 1.6f * clampf (c.reso, 0.0f, 1.0f);

    for (int k = 0; k < 3; ++k)
    {
        const auto f  = lerp (F[i0][k],  F[i0 + 1][k],  t);
        const auto bw = lerp (BW[i0][k], BW[i0 + 1][k], t);
        formantGain[(size_t) k] = dbToGain (lerp (G[i0][k], G[i0 + 1][k], t));

        for (auto& ch : formant)
            ch[(size_t) k].setup (f, clampf (f / bw * qScale, 0.7f, 40.0f), sampleRate);
    }
}

float Voice::filterOne (int ch, float x, float mix, const VoiceControl& c) noexcept
{
    auto& f = svf[(size_t) ch];
    f.tick (x);

    const auto usesFormant = c.fltModeA == (int) FilterMode::vocale || c.fltModeB == (int) FilterMode::vocale;
    float vowel = 0.0f;

    if (usesFormant)
    {
        for (int k = 0; k < 3; ++k)
        {
            auto& b = formant[(size_t) ch][(size_t) k];
            b.tick (x);
            vowel += b.bp * b.k * formantGain[(size_t) k];
        }

        vowel *= 1.8f;
    }

    const auto out = [&] (int mode)
    {
        switch ((FilterMode) mode)
        {
            case FilterMode::basso:  return f.lp;
            case FilterMode::banda:  return f.bp * bpNorm;
            case FilterMode::alto:   return f.hp;
            case FilterMode::vocale: return vowel;
        }

        return x;
    };

    if (c.fltModeA == c.fltModeB || mix >= 1.0f)
        return out (c.fltModeB);

    return lerp (out (c.fltModeA), out (c.fltModeB), mix);
}

void Voice::render (const VoiceControl& c, float* outL, float* outR, int n) noexcept
{
    if (! active)
        return;

    if (startDelay > 0)
    {
        // Humanised onset: nothing sounds (and nothing advances) until the delay has passed.
        startDelay -= n;
        return;
    }

    age += n;

    if (legatoPending)
        beginLegato (c);

    if (legatoGlide)
    {
        // A slur: settles within about max(glide, 25 ms).
        const auto tau = std::max (c.glideMs, 25.0f) / 3.0f;
        pitch += (targetPitch - pitch) * (1.0f - std::exp (-(float) n / (tau * 0.001f * sampleRate)));
    }
    else if (c.glideMs > 0.5f)
        pitch += (targetPitch - pitch) * (1.0f - std::exp (-(float) n / (c.glideMs * 0.001f * sampleRate)));
    else
        pitch = targetPitch;

    // The LFO fades in over lfo_delay from each note's start.
    const auto lfoFade = c.lfoDelayMs > 0.0f ? std::min (1.0f, (float) age / (c.lfoDelayMs * 0.001f * sampleRate)) : 1.0f;

    auto p = pitch + c.pitchOffset;

    if (c.lfoPitch > 0.0f)
        p += c.lfoPitch * 0.01f * c.lfoEnd * lfoFade;

    const auto oscOn = c.osc != nullptr && c.osc->any();

    if (oscOn)
    {
        std::fill (oscL.begin(), oscL.begin() + n, 0.0f);
        std::fill (oscR.begin(), oscR.begin() + n, 0.0f);
        oscs.render (*c.osc, p, c.lfoPw > 0.0f ? c.lfoPw * 0.45f * c.lfoEnd * lfoFade : 0.0f,
                     oscL.data(), oscR.data(), n);
    }

    attack.setInc (p, c.playbackScale);
    body.setInc (p, c.playbackScale);
    if (xfade < 1.0f) bodyOld.setInc (p, c.playbackScale);

    // Hard layer switching (crossfade 0) never moves a layer mid-note, even with CC dynamics.
    const auto live = c.dynLive && ! (sound != nullptr && sound->dynCrossfade == 0.0f);
    const auto d0 = live ? c.dynStart : noteDyn;
    const auto d1 = live ? c.dynEnd : noteDyn;
    body.weigh (d0, d1);
    if (xfade < 1.0f) bodyOld.weigh (d0, d1);
    lastDyn = std::max (0.0f, d1);
    tail.setInc (p, c.playbackScale);

    const auto env0 = lastEnv;
    const auto env1 = env.advance (n, c);
    lastEnv = env1;

    // Filter modulation: its own envelope or the amp one, LFO, key and velocity tracking.
    auto filterEnv = env1;

    if (c.fenvOwn)
    {
        auto fc = c;
        fc.attackMs = c.fenvAttack;
        fc.decayMs = c.fenvDecay;
        fc.sustain = c.fenvSustain;
        fc.releaseMs = c.fenvRelease;
        fc.curve = 0.0f;
        lastFenv = fenv.advance (n, fc);
        filterEnv = lastFenv;
    }

    auto octaves = c.lfoCutoff > 0.0f ? c.lfoCutoff * c.lfoEnd * lfoFade : 0.0f;

    if (c.fltKey > 0.0f)
        octaves += c.fltKey * (p - 60.0f) / 12.0f;

    if (c.fltVel > 0.0f)
        octaves += c.fltVel * 3.0f * (float) velocity / 127.0f;

    // Keep this expression axis separate from pitch/key tracking: pitch-wheel and
    // legato change oscillator frequency, while CC1/Manopola may move the fixed-Hz
    // filter/formant profile smoothly around its centre.
    if (c.fltDyn > 0.0f && c.dynLive)
    {
        const auto d = c.dynStart + (c.dynEnd - c.dynStart) * 0.5f;
        octaves += c.fltDyn * (d - 0.5f);
    }

    updateFilter (c, filterEnv, octaves);
    if (c.corde[0] > 0.0f || c.corde[n - 1] > 0.0f)
        corde.setNote (p, c);

    const auto drive = clampf (c.drive, 0.0f, 1.0f);
    const auto driveWet = std::min (1.0f, drive * 5.0f);
    if (driveWet > 0.0f && drive != cachedDrive)
    {
        drivePre = dbToGain (drive * 30.0f);
        drivePost = 0.5f / fastTanh (drivePre * 0.5f);
        cachedDrive = drive;
    }
    const auto pre = drivePre;
    const auto post = drivePost;

    for (int i = 0; i < n; ++i)
    {
        if (velGainRamp > 0)
        {
            velGain += velGainStep;
            if (--velGainRamp == 0) velGain = velGainTarget;
        }
        const auto e = env0 + (env1 - env0) * (float) (i + 1) / (float) n;
        float sL = 0.0f, sR = 0.0f, l, r;

        if (attack.active())
        {
            attack.read (i, n, l, r);
            sL += l * c.gAttack[i];
            sR += r * c.gAttack[i];
            attack.advance();
        }

        if (xfade < 1.0f)
        {
            // Correlation-aware crossfade: equal power for unrelated signals (rho = 0),
            // equal gain for aligned ones (rho = 1); constant loudness either way.
            xfade = std::min (1.0f, xfade + xfadeStep);
            const auto a = 1.0f - xfade, b = xfade;
            const auto norm = 1.0f / std::sqrt (std::max (1.0e-6f, a * a + b * b + 2.0f * xfadeRho * a * b));
            const auto g = e * c.gBody[i];
            float ol, orr;
            bodyOld.read (i, n, ol, orr);
            sL += ol * g * a * norm;
            sR += orr * g * a * norm;
            bodyOld.advance();

            if (body.active())
            {
                body.read (i, n, l, r);
                sL += l * g * b * norm;
                sR += r * g * b * norm;
                body.advance();
            }

            if (xfade >= 1.0f)
                bodyOld.clear();
        }
        else if (body.active())
        {
            body.read (i, n, l, r);
            const auto g = e * c.gBody[i];
            sL += l * g;
            sR += r * g;
            body.advance();
        }

        if (oscOn)
        {
            sL += oscL[(size_t) i] * e;
            sR += oscR[(size_t) i] * e;
        }

        if (tail.active())
        {
            tail.read (i, n, l, r);
            const auto gt = c.gTail[i] * tailGain;
            sL += l * gt;
            sR += r * gt;
            tail.advance();
        }

        auto g = velGain;

        if (stealing)
        {
            // Raised-cosine fade: no slope discontinuity at either end.
            stealGain = std::max (0.0f, stealGain - stealStep);
            g *= 0.5f - 0.5f * std::cos (kPi * stealGain);
        }

        if (c.lfoAmp > 0.0f)
        {
            const auto lfo = c.lfoStart + (c.lfoEnd - c.lfoStart) * (float) (i + 1) / (float) n;
            g *= 1.0f - c.lfoAmp * lfoFade * 0.5f * (1.0f + lfo);
        }

        if (oscOn && c.ampDyn > 0.0f && c.dynLive)
        {
            const auto d = c.dynStart + (c.dynEnd - c.dynStart) * (float) (i + 1) / (float) n;
            const auto amount = clampf (c.ampDyn, 0.0f, 1.0f);
            g *= 1.0f - amount + amount * clampf (d, 0.0f, 1.0f);
        }

        sL *= g;
        sR *= g;

        if (driveWet > 0.0f)
        {
            sL = lerp (sL, fastTanh (pre * sL) * post, driveWet);
            sR = lerp (sR, fastTanh (pre * sR) * post, driveWet);
        }

        const auto mix = c.fltMixStart + (c.fltMix - c.fltMixStart) * (float) (i + 1) / (float) n;
        bufL[(size_t) i] = filterOne (0, sL, mix, c);
        bufR[(size_t) i] = filterOne (1, sR, mix, c);
    }

    corde.process (bufL.data(), bufR.data(), bufL.data(), bufR.data(), c.corde, n);

    float peak = 0.0f;

    for (int i = 0; i < n; ++i)
    {
        const auto l = sanitize (bufL[(size_t) i]);
        const auto r = sanitize (bufR[(size_t) i]);
        outL[i] += l;
        outR[i] += r;
        peak = std::max (peak, std::max (std::abs (l), std::abs (r)));
    }

    if (stealing && stealGain <= 0.0f)
    {
        kill();
        return;
    }

    const auto bodyDone = oscOn ? env.isIdle() : ((! body.active() && xfade >= 1.0f) || env.isIdle());
    const auto sourcesDone = ! attack.active() && ! tail.active() && bodyDone && (released || oneShot || ! hasTail);

    if (sourcesDone)
    {
        // Let filter and string resonances ring out, then free the voice.
        silentSamples = peak < 1.0e-5f ? silentSamples + n : 0;
        ringSamples += n;

        if (silentSamples > (int) (0.03f * sampleRate) || ringSamples > (int) (15.0f * sampleRate))
            kill();
    }
    else
    {
        ringSamples = 0;
    }
}

} // namespace libero
