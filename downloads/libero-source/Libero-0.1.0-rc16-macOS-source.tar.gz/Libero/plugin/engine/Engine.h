#pragma once

#include "Bundle.h"
#include "Effects.h"
#include "Params.h"
#include "Reverb.h"
#include "Voice.h"

#include <juce_audio_basics/juce_audio_basics.h>

#include <atomic>
#include <cmath>
#include <memory>

namespace libero
{

// The Libero engine: voices, air bed, resonators and the global effect chain.
// process() is realtime safe. Sounds are handed over from other threads with submitSound().
class Engine
{
public:
    static constexpr int kMaxVoices = 32;
    static constexpr int kVoicePool = kMaxVoices + 8;   // extra slots for voices fading out

    Engine();
    ~Engine();

    // Not realtime: allocates. Keeps the current sound.
    void prepare (double sampleRate, int maxBlockSize);
    // Not realtime: kills voices, clears effect tails, snaps smoothers to the current parameters.
    void reset();

    // Audio thread (or before prepare): plain parameter values, applied smoothly.
    void setParameters (const ParamSet& p) noexcept { params = p; }

    // Audio thread: host tempo in BPM (<= 0 or non-finite = unknown, 120 is used).
    void setTempo (double bpm) noexcept { hostBpm = (bpm > 0.0 && std::isfinite (bpm)) ? (float) bpm : kDefaultBpm; }

    // Audio thread. Renders n samples into l/r (overwritten), consuming the MIDI in buffer.
    void process (float* l, float* r, int n, const juce::MidiBuffer& midi, const juce::MidiBuffer* additional = nullptr) noexcept;

    // Any non-audio thread. Takes ownership; the audio thread swaps it in with a short fade.
    void submitSound (std::unique_ptr<SoundData>);
    // Offline use only (no concurrent process()): installs the pending sound and IR immediately.
    void finishLoadingOffline();
    // Any non-audio thread: frees sounds the audio thread has retired.
    void collectGarbage();

    // Active articulation (index into the sound's list, -1 without any). Follows the `artic`
    // parameter when it changes and note-ons on a keyswitch key. Any thread.
    int activeArticulation() const noexcept { return activeArt.load (std::memory_order_relaxed); }

    // Audio thread helpers.
    void allNotesOff (bool hard) noexcept;
    int getActiveVoiceCount() const noexcept;
    bool hasStreamingSound() const noexcept { return current != nullptr && current->streaming != nullptr; }
    double getSampleRate() const noexcept { return sampleRate; }
    // Audio thread only. The editor receives a copied value through the processor FIFO.
    Voice::Playback samplePlayback() const noexcept;

private:
    void handleMidi (const juce::MidiMessage&) noexcept;
    void noteOn (int note, int velocity) noexcept;
    void noteOff (int note) noexcept;
    Voice* startVoice (int note, int velocity, int limit, float glideFrom) noexcept;
    void legato (Voice&, int note, int velocity) noexcept;
    void releaseVoice (Voice&) noexcept;
    Voice* monoVoice() noexcept;
    void stackRemove (int note) noexcept;
    int chooseTake (int group, int count) noexcept;
    Takes chooseTakes (int note, int velocity, int art) noexcept;
    NoteSetup setupNote (int note, int velocity) noexcept;
    float liveDynamicsTarget() const noexcept;   // < 0 when dynamics come from velocity
    void renderChunk (float* l, float* r, int n) noexcept;
    void swapSoundIfPending() noexcept;
    void snapSmoothers() noexcept;
    bool retire (SoundData*) noexcept;

    struct AirPlayer
    {
        const Zone* zone = nullptr;
        double pos = 0.0;

        void start (const Zone* z) noexcept { zone = z; pos = 0.0; }
        void read (double inc, float& l, float& r) noexcept;
    };

    double sampleRate = 48000.0;
    float sr = 48000.0f;
    ParamSet params;
    float hostBpm = kDefaultBpm;

    std::array<Voice, kVoicePool> voices;
    uint64_t voiceOrder = 0;
    float lastNote = -1.0f;
    std::array<bool, 128> keyDown {};
    std::array<uint8_t, 128> keyVelocity {}, heldStack {};   // held keys, oldest first (note memory)
    int heldCount = 0;
    int monoIndex = -1;
    uint64_t monoOrder = 0;

    dsp::Rng takeRng, humanRng;
    float cc1 = -1.0f, cc11 = -1.0f;            // last CC1 / CC11 (0..1), < 0 before the first one
    dsp::Smoother dynSmooth, lfoPitchCc1;
    dsp::Smoother osc1Gain, osc2Gain;
    std::array<dsp::Smoother, 3> subGain;
    std::array<dsp::Smoother, 2> phaseS;
    std::array<double, 3> motionPhase { 0.0, 2.1, 4.4 };
    OscControl oscControl;
    Lfo lfo;
    dsp::Rng oscRng;
    int64_t idleSamples = 0;                    // silence so far (rr_reset_ms)
    std::array<int16_t, 1024> lastTake {};   // last round-robin take per zone group
    bool sustainPedal = false;
    std::atomic<int> activeArt { -1 };
    int lastArticParam = 0;                     // last value of `artic` seen, to tell a parameter move from a keyswitch
    float pitchBend = 0.0f;
    struct BendChannel
    {
        uint8_t rpnMsb=127, rpnLsb=127, semitones=2, cents=0;
        int wheel=8192;
    };
    std::array<BendChannel,16> bendChannels {};
    int bendChannel=0; // existing omni bend: last wheel channel controls the whole instrument
    void updatePitchBend() noexcept;

    // Sound ownership: pending (any thread -> audio), current / outgoing (audio thread),
    // retired ring (audio -> collector).
    std::atomic<SoundData*> pending { nullptr };
    SoundData* current = nullptr;
    SoundData emptySound;                       // stands in for `current` when nothing is loaded
    const SoundData& snd() const noexcept { return current != nullptr ? *current : emptySound; }
    SoundData* outgoing = nullptr;
    static constexpr int kRetired = 16;
    std::array<std::atomic<SoundData*>, kRetired> retired {};

    AirPlayer air, airOld;
    float airEnv = 0.0f, airSwap = 1.0f;

    // Smoothed controls.
    dsp::Smoother gAttack, gBody, gTail, gAir, cordeAmt, modalAmt, widthS, masterS;
    dsp::Smoother cutoffLog, reso, fltEnv, drive, pitchOffset;
    int fltModeA = 0, fltModeB = 0;
    float fltMix = 1.0f;

    std::array<float, kChunk> aAtt {}, aBody {}, aTail {}, aCorde {}, aModal {};
    std::array<float, kChunk> sumL {}, sumR {};

    ModalResonator modal;
    Tape tape;
    Caldi caldi;
    Echo echo;
    Reverb reverb;
    dsp::DCBlocker outDcL, outDcR;
};

} // namespace libero
