# Multiple-instance hotfix — 9 October 2026

Drive still offered macOS rc8 and Windows rc4 when this investigation began.
The sample-sharing, UI and loading work from 8 October had only been installed
locally. Both platform downloads were replaced with rc9 and corresponding
source archives; previous sources remain available separately.

## Corrections

- Decoding now uses a shared low-priority pool, limited to half the logical CPU
  count and at most four workers per process. Independent instruments no longer
  each spawn up to sixteen decoder threads.
- The 600 ms initial-sound fallback now runs only when no load has been requested.
  Previously it could cancel a slow explicit selection and replace it with the
  last/default instrument. A regression check also verifies that new instances
  still load a default when there is no explicit selection.
- rc9 includes the previously tested shared PCM, lossless resampling cache,
  hidden-editor suspension, lazy library tiles and persistent editor dimensions.

## Measurements

The final probe used the released Concert Grand Piano, eight processor instances,
eight editors and 32 held notes per instance, at 48 kHz and 256 samples. Hardware
was an Apple M5 with 24 GB RAM on AC power. The native host uses no hardware audio
device, so these results are not end-to-end latency measurements or DAW guarantees.

The first load in a fresh process with warm filesystem caches took 907 ms. Further instances took 10–12 ms. Host physical footprint
was 2,574 MB for one loaded processor and 2,634 MB for eight before editors opened.
The piano itself is large: sharing prevents duplication but does not make different
large instruments cheap to hold in RAM. Sharing is limited to a common host process.

The visible editor probe measured about 60 FPS and 78 ms for opening the library.
Observed WebKit RSS was roughly 1 GB with eight editors. WebKit PIDs are associated
by launch timing, not proven ownership; RSS also includes shared pages and must not
be added to host footprint as a precise total.

Across 339 audio blocks, mean processing was 1,925 microseconds, p99 3,678 and
maximum 4,364, against a 5,333 microsecond budget. Output was finite and no block in
this final run exceeded the budget. An earlier eight-instance probe did have one
over-budget block. A probe overlapping the native suite was discarded; there is
no claim that the new loading policy improves steady-state DSP processing time.

The bounded pool increased this cold 48 kHz load from about 592 ms to 907 ms while
reserving background CPU headroom. The fixed fallback prevents that slower first
load from being cancelled at 600 ms.

## Verification

The full native suite and WebView checks passed on macOS, followed by AU validation.
The loading check covers eight concurrent loads of distinct source folders,
bit-identical sample data, damaged-cache recovery and cancellation. Cache checks
cover shared PCM, independent edits and parameters, invalidation and release.

Windows workflow 37914809106 completed successfully from private source snapshot
792f896b0c49c67721700d22fbfa953649c3da4b, including native, cache, initial-load,
WebView, window-state and installer checks. Windows performance in an actual DAW
remains unmeasured. Reported user lag still needs their OS, DAW and symptom type.

Raw local measurements and logs are in
`plugin/tests/out/performance/multi-instance-2026-10-09/`.
