# Packs and Libero updates

Library → Pack Manager and Downloader searches published packs and their instrument names,
shows installed versions, downloads and verifies archives, and installs them
through the existing transactional importer. Delete moves an installed pack to
the OS Trash/Recycle Bin. Updating a pack asks before replacing local edits.
Playback requires no network. Catalogue refresh and downloads require internet.
A cached catalogue remains available offline. The library refreshes after a download
finishes even if its dialog is closed. A same-version pack with fewer sounds than
the catalogue remains available through Repair download, with confirmation before
replacement. The previous incomplete bank is recoverable from Trash/Recycle Bin.

A single native worker serves all instances in the same process. It writes to
disk with a bounded buffer; archive bytes do not pass through the WebView.
Closing the editor does not cancel a transfer. Cancellation removes unfinished
files; installation cannot be cancelled once the transactional import begins.
Downloads verify exact byte count, SHA-256, bank identity, version and full sound count before
installing. A changed local bank during download stops the update for review. Packs selected
or loading in any instance cannot be replaced; choose another pack first. A
short install guard also blocks new loads until the replacement completes.

Libero updates has a separate Library button. Application updates are downloaded and verified inside the plugin, then the
user opens the installer. Windows Setup handles plugin file locks with Restart
Manager. macOS opens a command that waits for the user to close the DAW and
stages/verifies both AU and VST3 before replacing them. Restart the DAW after
installing. Builds before this manager require one manual installation first.

## Shipping a release

Use a monotonically increasing `LIBERO_BUILD` and matching `LIBERO_RELEASE` when
building both platforms. Upload versioned files with new public file IDs, retaining
old files long enough for cached catalogues. Publish corresponding source and
licences before announcing an executable update. Check anonymous downloads.

Run `scripts/update_download_catalog.py --pack path/to/pack.liberobank
--drive-id PUBLIC_FILE_ID` to add/update a pack. For application updates pass
`--build N --version LABEL --mac PATH --mac-drive-id ID --windows PATH
--windows-drive-id ID`. The script hashes local release files and updates the
catalogue plus the embedded fallback. Copy `data/pack-catalog.json` into the
Pages repository as `libero-catalog.json` and publish that file. Existing users
receive the changed catalogue via “Check for updates”; no plugin rebuild is
needed to announce later releases or packs.

The public catalogue contains only reviewed, already-published downloads.
Local audition banks, including Pink 1.1, are not added automatically.
