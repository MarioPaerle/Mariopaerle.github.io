# Sound packs

[GitHub Releases](https://github.com/MarioPaerle/Libero/releases)

Pre-release 0.1.0-rc4 is prepared as a draft with individual collections and two
independent Base Bundle ZIP parts, each below GitHub's 2 GiB asset limit.
Download both parts for all 75 sounds; select both together in Library → Import.
Each ZIP contains its `.liberobank` files and the instructions, catalog,
checksums and sound-data terms. Plugin binaries are separate downloads.

The [previous Drive download](https://drive.google.com/drive/folders/1H8RPLpUjnRy4grvidcRvtLt1DuVlx28L?usp=drive_link) contains bank version 0.1.0.

## Base bundle 0.1.1

75 presets across 11 collections. Sizes below use decimal MB/GB.

| Collection | Presets | Download size |
| --- | ---: | ---: |
| Aria | 14 | 245 MB |
| Blue | 8 | 709 MB |
| Giove | 22 | 86 MB |
| Bebop | 7 | 1.10 GB |
| Mog | 5 | 29 MB |
| Strings | 3 | 126 MB |
| Bass | 3 | 23 MB |
| Guitars | 3 | 73 MB |
| Brass | 1 | 43 MB |
| Percussion | 4 | 86 MB |
| Trap | 5 | 186 MB |
| **Total** | **75** | **2.70 GB** |

This is the audited pre-release selection. Restricted, conditional or unaudited
sounds from the working library are excluded, including the authentic
freeware-only Mellotron recordings. The included Giove tape sounds are separate
presets; they are not those authentic Mellotron recordings.

## Import

1. Install and open Libero in your DAW.
2. Download individual `.liberobank` files or both Base Bundle ZIP parts. Keep
   these archives intact.
3. Open **Library → Import**. Select multiple `.liberobank` files together,
   or select both Base Bundle ZIP parts together.
4. Review the collection names, versions, sound counts, sizes and warnings.
   Deselect collections you do not want. Already installed packs are skipped;
   invalid entries have their own explanation.
5. Choose **Install packs** or **Install / update packs**. Watch the per-pack
   results, then close the review and open a collection in the library.

The updated plugin supports batch import. Earlier pre-release builds require
extracting the complete ZIP and importing each `.liberobank` separately.

**Stop after current pack** finishes the active installation before stopping.
Completed packs remain installed; the remaining selection can be resumed in the
same review. A failed pack does not prevent the others from installing. If the
selection contains several versions of a bank, the newest is selected. Conflicting
files with the same bank version are reported; choose one source and import again.

An identical installed version is reported as already installed. A newer
version can replace the installed collection after confirmation; an older
version is refused. Invalid or unsafe archives are rejected before installation.
An update replaces the whole collection, including local edits or added sounds.
Use **Save as…** to keep personal copies before updating a bank.

The same pack files work on macOS and Windows. Sample-editor changes stored in
personal sounds are included when exporting their bank and retained on import.

## Licenses and integrity

Original authored sound data in this selection is CC0. Source recordings retain
the licenses and attribution included inside each bank. One selected preset
uses CC BY recordings; retain its attribution and modification notes when
redistributing. The software's AGPL license is separate from sound-data terms.

Keep `SOUND-DATA-TERMS.md` and the attribution files with redistributed packs.
`SHA256SUMS` lists the hashes of the separate bank files; the complete ZIP has
its own checksum supplied alongside the local release artifacts.

## Preset levels

Version 0.1.1 raises the initial master level of 56 quieter presets by measured
amounts. Source samples, recorded dynamics and effects are unchanged. Velocity
127 notes, representative chords and authored articulations were checked before
choosing the boosts. Some naturally quiet sounds retain lower levels where
other notes or articulations already use the available headroom.

Select a sound again from the library to hear its updated defaults. Saved DAW projects retain their
stored parameter settings. Personal copies are not replaced by bank updates.

## Importing extracted folders

Use **Library → Import folder…** to select an extracted pack containing `bank.json`, or a folder containing pack folders and archives. **Import…** accepts `.liberobank` files, pack ZIPs and bundle ZIPs. The review screen shows versions, duplicates and errors before installation.

## Removing a pack

Open the pack in Library and choose **Delete pack…**. Confirm to move the pack, including local edits and added sounds, to Trash / Recycle Bin. Select a sound from another pack first if this instance is using it. Close other instances using the pack if Windows reports that its files are in use. Copies saved in other packs remain installed.
