# Pitch and slides in hosts

Libero receives standard 14-bit MIDI pitch wheel and RPN 0 pitch-bend sensitivity, including semitones and cents. The default range is ±2 semitones until a host sends another range. A channel's range selection cannot be completed by messages on another channel. CC121 centres the wheel and clears the RPN selection while retaining the negotiated range; an engine reset restores ±2.

## FL Studio

In the plugin wrapper, enable **Send pitch bend range** and choose the required semitone range. Automate the wrapper's channel pitch control or send MIDI pitch wheel. Libero also exposes Tune for host parameter automation.

FL Studio's special piano-roll slide notes are exclusive to its native instruments. The host does not send those native slide instructions to a standard VST3/AU instrument. Libero cannot infer a slide that the host never sends.

To connect overlapping notes within Libero, select **Legato** and set **Glide** (for example 100–180 ms), then overlap the ordinary notes. Mono retriggers notes; Legato preserves the sounding envelope. This produces one melodic voice, not FL's colour-specific polyphonic slide behavior.

Official references:
- https://support.image-line.com/action/knowledgebase?ans=592
- https://www.image-line.com/fl-studio-learning/fl-studio-online-manual/html/plugins/wrapper.htm

## LMMS

The local LMMS checkout sends instrument-track pitch as MIDI Pitch Bend. Changing its pitch range sends RPN 0 (CC100/101) and data entry (CC6). Those messages match Libero's native MIDI regression tests. Automate track pitch and set its pitch range consistently.

Per-note detuning in the LMMS piano roll modifies the note's frequency inside LMMS; it is distinct from track MIDI pitch. The local VeSTige path passes MIDI events and does not translate that per-note frequency into Libero slides. Use track pitch automation or Libero Legato/Glide where the chosen plugin host supports Libero.

This local VeSTige implementation hosts VST2. The released Libero build is VST3/AU, so this is not a claim that it loads directly in VeSTige. A host/bridge such as Carla must support the supplied plugin format and forward MIDI pitch/range messages.

Source inspected: /Users/mario/Documents/lmms/lmms/src/tracks/InstrumentTrack.cpp (updatePitch/updatePitchRange/processOutEvent), src/core/NotePlayHandle.cpp (frequency/per-note detuning) and plugins/vestige/vestige.cpp (handleMidiEvent).

## What was verified

Native MIDI-to-audio tests cover both range-byte orders, intermediate wheel values, positive/negative ranges, cents, RPN Null/NRPN rejection, channel isolation and reset behavior. The renderer tests cover overlapping Legato notes and held-note return. These tests do not substitute for a live FL Studio or LMMS/Carla session. No foreground DAW windows were opened for this work.
