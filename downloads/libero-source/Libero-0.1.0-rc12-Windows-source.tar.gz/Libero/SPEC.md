# Libero — specification

Libero is an instrument plugin (VST3 + AU, macOS universal, Windows later) whose
sounds are *designed by a language model* through an MCP server, then played
instantly by the plugin. It is the first of a family: the engine, the sound
format and the style layer are meant to be reused by later instruments.

This document is the contract between the three parts of the repo. If code
disagrees with this file, one of the two is wrong — fix it, don't drift.

```
plugin/   C++ (JUCE 9): realtime engine, VST3/AU wrapper, offline renderer CLI, agent socket
ui/       HTML/CSS/JS served inside the plugin's WebView; themeable
python/   `libero` library: sound recipes, DSP workbench, analysis, compiler, MCP server
sounds/   example sound sources shipped with the repo
```

---------------------------------------------------------------------------

## 1. The idea in one paragraph

A **sound** is a folder: source samples, a `sound.py` recipe that says how to
turn them (plus synthesis) into four layers, a hand-authored `figure.svg`, and
design notes. **Compiling** runs the recipe offline — everything expensive
(convolution, resynthesis, stretching, multi-root rendering, loop finding) —
and writes a `build/` bundle of plain WAV zones plus a `manifest.json`. The
plugin only ever reads bundles, so playback is instantaneous and
deterministic. What stays *live* in the plugin is what a player wants to turn:
layer balance, envelopes, filter, resonators, tape, echo, reverbs.

The same C++ engine is compiled into a command-line renderer
(`libero-render`), so the model hears and sees *exactly* what the plugin will
play, not a Python approximation.

## 2. Library on disk

Root: `$LIBERO_HOME`, default `~/Libero`.

```
~/Libero/
  sketches/<slug>/     unsaved sounds (the model's workbench; may be discarded)
  sounds/<slug>/       saved sounds (the user's library)
  banks/<bank>/        sound banks: bank.json + sound folders (§2.4)
  themes/<name>.css    user themes (override the built-in ones)
  instances/<id>.json  one file per running plugin instance (see §6)
  cache/               compiler cache, downloads
  config.json          optional: {"freesound_api_key": "...", "theme": "harmonic",
                                  "last_sound": "<path>", "favorites": [{"path": "...", "slug": "..."}],
                                  "tags": {"<sound slug>": 1}}
  ui-override/         developer only: if index.html exists here the plugin serves its UI
                       from this folder instead of the copy embedded in the binary
```

A favourite matches a sound by path, or by slug when the stored path no longer
exists (the sketch was saved, i.e. moved to `sounds/`).

`<slug>`: `[a-z0-9-]{1,48}`. "Saving" a sound = moving its folder from
`sketches/` to `sounds/`. Nothing else distinguishes them.

`sounds/` is the user's own implicit bank ("Mie"), `sketches/` the bank "Prove".
A slug is looked up in sketches, sounds, then banks (alphabetically): keep slugs unique across banks.

### 2.1 Sound folder

```
<slug>/
  sound.py         the recipe (§3)
  samples/         source audio: downloaded, recorded, synthesised, intermediate
  figure.svg       the sound's figure (§8). viewBox 0 0 512 512.
  notes.md         the designer's notes: intent, references, what was tried
  build/           compiled bundle (§4) — generated, never hand-edited
```

### 2.4 Banks

A bank is a named collection of saved sounds, meant to be distributed as a pack. It is a folder,
`~/Libero/banks/<bank-slug>/`, whose sound folders (each laid out as §2.1) sit directly inside it,
next to `bank.json`, format `libero.bank/1`:

```json
{"format": "libero.bank/1", "slug": "piano", "title": "Piano", "subtitle": "grand, felt, tape",
 "description": "Pianos from acoustic recordings.", "version": "1.0.0", "author": "Mario Prignano",
 "license": "CC BY 4.0", "created": "2026-09-30T22:38:17Z", "updated": "2026-09-30T22:38:17Z", "figure": null}
```

| field | |
|---|---|
| `format` | `"libero.bank/1"`, required |
| `slug` | the folder name (`[a-z0-9-]{1,48}`, not `mie`/`prove`), required |
| `title` | required, non-empty; `subtitle`, `description`, `author`: strings, may be empty |
| `version` | semver `x.y.z`, required; starts at `1.0.0`; only the author raises it |
| `license` | derived, never typed: the most restrictive licence among the sounds' `samples/credits.json` (see `licenses.py`; `by-sa` adds the share-alike note; no credits: `original work`). Recomputed whenever a sound enters or leaves the bank and on export |
| `created`, `updated` | UTC ISO 8601 (`2026-09-30T22:38:17Z`); `updated` moves on every edit, move-in/out and export |
| `figure` | optional path (inside the bank) of an SVG cover, or `null`. Without one the UI shows a mosaic of the first four sounds' figures |

A reader tolerates missing fields (defaults: version `1.0.0`, empty strings, dates unknown); the
one-off `libero bank migrate` (Python) rewrites every installed `bank.json` to the full schema
(idempotent). Sounds in a bank count as saved. `sounds/` ("Mie") and `sketches/` ("Prove") are
built-in folders without `bank.json`; `mie` and `prove` are reserved slugs. A sound is moved
between banks by moving its folder (favourites and colour tags follow by slug); an existing
folder is never overwritten.

**Pack** `<bank>.liberobank`: a zip with one top-level folder `<bank-slug>/` holding `bank.json`
(freshly derived `license`) and its figure, and per sound `build/`, `figure.svg`, `notes.md`,
`sound.py`, `SOUND-DATA-TERMS.md`, `samples/ATTRIBUTION.md`, `samples/credits.json`,
`samples/TERMS.md` and files in `samples/licenses/` when present. Source audio in `samples/` and
caches are not packed. **Export is refused**, naming the sounds, if any sound's licence class
(§4, `licenses.py`) is not shippable (cc0, by, by-sa): non-commercial, private-use and unknown
terms stay home.
**Import** checks one `libero.bank/1` collection with a title and an `x.y.z`
version. Duplicate archive paths, path traversal, links, file/directory collisions
and invalid runtime bundles are rejected before changing an installed bank.
The UI first presents the title, version, sound count, size, installed version
and warnings. Installation and updates require a separate confirmation.
Same-version packs and downgrades leave the installed collection unchanged.
An update replaces the entire bank, including local additions and edits; the
review states this explicitly. Installation uses a staged directory and a
recoverable backup, restores the prior bank if replacement fails, and moves
the backup to the Trash after success. If that move fails, the result identifies
the retained backup. Empty collections are supported with a warning.

`inspectBank` returns `{ok, code, path, bank:{slug,title,version}, installedVersion,
action, soundCount, compressedBytes, uncompressedBytes, warnings}`. `action` is
`install`, `update` or `already_installed`; `SAME_VERSION` and `DOWNGRADE` distinguish
the last case. The inspection path names the archive. Successful `importBank`
preserves the legacy `slug` and installed-directory `path`, and adds `packPath`
and `installedPath`. Failures include `code` and a readable `error`; cancellation
includes `cancelled:true`. Sounds with the same identifier elsewhere are reported
as warnings and remain separate collections.

Python (`libero/library.py`) is the reference; the plugin implements the same rules natively in
`plugin/src/Library.cpp` and both are tested against the same behaviour.
CLI: `libero bank new|list|add|edit|pack|install|migrate|tag`; MCP: `bank_create`, `bank_list`,
`bank_add`, `bank_edit`, `bank_pack`, `bank_install`, `sound_tag`. Socket (§6): `create_bank`,
`edit_bank`, `export_bank`, `import_bank`, `set_color_tag`.

**Colour tags.** A sound may carry one of four colour tags, `tags: {<sound slug>: 1..4}` in
`config.json` (keyed by slug, so moves keep it): 1 Rosso pompeiano, 2 Ocra, 3 Verderame,
4 Lapislazzuli (theme tokens `--tag-1..4`, §9.1). `0` removes it.

## 3. Recipe (`sound.py`)

Plain Python using the `libero` library. It must define a module-level
`sound = Sound(...)`. Layer functions are registered with decorators and
return `libero.Audio` objects.

```python
from libero import Sound, Audio, synth, load

sound = Sound(
    title="Lyra Aeterna",
    subtitle="corda pizzicata, cassa di cipresso",
    tags=["plucked", "string", "warm"],
    roots=[36, 48, 60, 72, 84],   # MIDI notes where pitched layers are rendered
    velocities=[100],             # optional velocity layers (1..127)
    sample_rate=48000,
    takes=1,                      # optional round-robin takes per zone (1..32), see below
)

@sound.body                       # pitched, sustaining part. Rendered at every (root, velocity).
def body(ctx):                    # ctx.note, ctx.freq, ctx.velocity, ctx.sr, ctx.samples (dir), ctx.seed, ctx.take
    return synth.karplus(ctx.freq, dur=4.0, bright=0.6, sr=ctx.sr)

@sound.attack(pitched=False)      # transient. pitched=False → rendered once, played unpitched
def attack(ctx):
    return load("pick.wav").trim(0, 0.08).fade_out(0.03)

@sound.tail(pitched=True)         # played on note-off (release noise, damper, breath)
def tail(ctx): ...

@sound.air                        # background noise bed, looped, unpitched
def air(ctx):
    return synth.noise("pink", dur=6.0).lowpass(4000).gain_db(-30)

@sound.impulse                    # optional impulse response for the "Impronta" reverb
def ir(ctx): ...

sound.loop(body=True)             # ask the compiler to find a seamless sustain loop in body zones
sound.defaults(amp_release=900, rev_mode="Basilica", rev_mix=0.28, res_mode="Corde")
```

Every layer is optional except `body`. Returning `None` omits a layer. A recipe with no
body at all is valid when its `sound.defaults(...)` turns an oscillator on (`osc1_level`,
`osc2_level` or `sub_level` above -60, §5): an oscillator-only sound.

**Round-robin takes.** With `takes=N` (default 1) every body, attack and tail
zone is rendered N times, once per `ctx.take` = 0..N-1, each with its own
`ctx.seed` (take 0 keeps the single-take seed, so adding takes never changes
the first one). A recipe should vary the performance with them (pitch, noise,
onset, brightness). Air and the impulse have no takes. The compiler caches each
(zone, take) separately.

**Synthesised dynamics layers.** `Sound(dynamics=[0.3, 0.6, 0.9])` (instead of
`velocities`) renders every body/attack/tail zone once per position; the layer
function reads `ctx.dyn` (0..1; without `dynamics` it is `velocity/127`) and
should make soft layers darker, not only quieter. Zones get `dyn` ranges tiling
0..1 at the midpoints between positions (bundle/2).

**Recorded multisamples.** A layer can be made of real recordings instead of a
function:

```python
sound.multisample("body", regions=[
    {"file": "salamander/A0v1.flac", "root": 21, "vel": [1, 26]},          # files under samples/
    {"file": "salamander/A0v16.flac", "root": 21, "vel": [121, 127], "tune_cents": -3},
    ...],
    process={"tune": "smooth", "ladder": "smooth", "peak_db": -9, "align_ms": 5,
             "max_seconds": [[21, 10], [108, 3.5]], "loop": "none"})
sound.multisample("tail", regions=[{"file": "salamander/rel40.flac", "root": 40,
                                    "rt_decay": 2, "gain_db": -37}, ...])
sound.performance(dynamics_source="velocity", velocity_curve=1.0, dyn_crossfade=0,
                  humanize={"cents": 1, "ms": 2, "db": 0.4}, rr_reset_ms=2000)
```

Region fields: `file, root, lo?, hi?, vel? | dyn?, take?, tune_cents?, gain_db?,
loop?, offset?, end?, rt_decay?, rt_min_db?` (tails), `pitched?`. Missing key
ranges are filled by nearest root, gapless per (dynamics layer, take); several
velocity layers become continuous `dyn` layers unless `as_dyn=False`. The
compiler edits the files the way a sample editor would (`libero.multisample.Process`):
resample to the sound's rate; true-onset trim with a fixed faded pre-roll
(`pre_ms`); cut where the note has decayed (`end_db`) or at a register-dependent
length (`max_seconds`); fade; optional long loop (`loop="auto"|"source"`);
per key, phase-align all dynamics layers and takes to the top layer
(`align_ms`); tuning (`tune`: `source` keeps the region's `tune_cents`,
`smooth` keeps the instrument's own stretch tuning and corrects outliers,
`detect` tunes every zone to equal temperament) written as `tune_cents`; level
ladder (`ladder`: one gain for the whole instrument so the loudest zone peaks at
`peak_db`, plus bounded corrections of uneven notes and oversized steps between
layers; never per-file normalisation); attack/tail layers share the body's
instrument gain so recorded releases keep their natural level. Edited regions are
cached by source file, region and options; recorded zones are written as 24-bit
FLAC by default (`encoding`).

**Articulations** (bundle/2). One sound can hold several playing techniques of a section
(sustain, staccato, pizzicato, tremolo…). Declare them, then tag every region with the one it
belongs to:

```python
sound.articulations([{"id": "sus", "name": "Sostenuto", "key": 24},     # first = default
                     {"id": "stacc", "name": "Staccato", "key": 25},
                     {"id": "pizz", "name": "Pizzicato", "key": 26},
                     {"id": "trem", "name": "Tremolo", "key": None}])   # parameter / UI only
sound.multisample("body", regions=[{"file": "vln/sus_A3.flac", "root": 57, "articulation": "sus"}, ...])
```

`id` is lowercase `[a-z0-9_]`, unique; `name` is the Italian label the UI shows; `key` is a unique
MIDI note (or `None`) whose note-on selects the articulation. At most 16. Region field
`articulation` (an id; absent = the region belongs to every articulation). The compiler plans
the key, velocity/dynamics and take ranges of each articulation as a keyboard of its own, keeps
the edge stretch of a range short of the keyswitch keys between its edge and its root (so
keyswitches sit beyond the played range), calibrates the level ladder and tuning per
articulation, and names the zone files `<layer>_<articulation>_n…`. `lint` runs its per-key
checks (dynamics ladder, takes, tuning, alignment) per articulation.

`sound.performance(...)` writes the manifest's playing behaviour (§4):
`dynamics` source (`velocity`, `cc1`, `cc11`) and `velocity_curve`, `humanize`,
`rr_reset_ms`. Credits: `samples/credits.json` (a list of `{source, author,
license, license_class, url, retrieved}`, written by the importers) and
`sound.credit(...)`; the compiler copies them into the manifest and into
`build/ATTRIBUTION.md`.

## 4. Compiled bundle (`build/`)

```
build/
  manifest.json
  body_n048_v100.wav   ...     one file per zone, float32 WAV, mono or stereo
  body_n048_v100_t1.wav ...     with takes > 1: one file per zone and take, suffix _t<take>
  body_n048_d060.flac  ...     bundle/2: dynamics layers (d = top of the dyn range × 100);
                                zone files may also be 24/16-bit WAV or FLAC (recorded material)
  ATTRIBUTION.md                when the sound credits sources
  attack.wav | attack_n048_v100.wav ...
  tail...wav
  air.wav
  ir.wav                        optional, stereo preferred
  figure.svg                    copy of the figure at compile time
```

`manifest.json`:

```json
{
  "format": "libero.bundle/2",     // "libero.bundle/1" bundles load unchanged
  "slug": "lyra-aeterna",
  "title": "Lyra Aeterna",
  "subtitle": "corda pizzicata, cassa di cipresso",
  "tags": ["plucked", "string"],
  "description": "free text, the first paragraph of notes.md",
  "sample_rate": 48000,
  "compiled_at": "2026-09-30T12:00:00Z",
  "source_hash": "sha256 of sound.py + samples/",
  "zones": [
    {
      "layer": "body",              // body | attack | tail | air
      "file": "body_n048_v100.wav",
      "root": 48,                   // MIDI root; ignored if pitched=false
      "pitched": true,
      "lo": 0, "hi": 53,            // key range (inclusive)
      "vel_lo": 1, "vel_hi": 127,   // velocity range (inclusive)
      "gain_db": 0.0,
      "loop": {"start": 12000, "end": 96000, "crossfade": 2048},  // samples, or null
      "take": 0,                    // optional round-robin take 0..N-1 (absent = 0)
      "dyn": [0.0, 0.33],           // bundle/2, optional: dynamics layer range in 0..1
      "tune_cents": -4.2,           // bundle/2, optional: fine correction (pitched zones)
      "rt_decay": 12.0,             // bundle/2, optional, tails: dB lost per second the note was held
      "rt_min_db": -40.0,           // bundle/2, optional, tails: floor of that loss (default -40)
      "one_shot": true,             // bundle/2, optional: note-off is ignored (default: the manifest's)
      "choke_group": 1,             // bundle/2, optional, int >= 1: see "Choke groups"
      "chokes": [2],                // bundle/2, optional: further groups this zone chokes
      "articulation": "sus"         // bundle/2, optional: id from the manifest's `articulations` (absent = all)
    }
  ],
  "dynamics": {"source": "velocity", "velocity_curve": 1.0, "crossfade": 0},   // bundle/2, optional: velocity | cc1 | cc11; crossfade 0..1
  "humanize": {"cents": 2.0, "ms": 3.0, "db": 0.8},             // bundle/2, optional: per-note jitter
  "rr_reset_ms": 1500,                                         // bundle/2, optional: RR restart after silence
  "one_shot": false,                                           // bundle/2, optional: default for every zone
  "articulations": [                // bundle/2, optional; order = UI order, the first is the default
    {"id": "sus", "name": "Sostenuto", "key": 24},   // key: MIDI note that selects it, or null
    {"id": "pizz", "name": "Pizzicato", "key": 26}
  ],
  "ir": "ir.wav",                   // or null
  "figure": "figure.svg",
  "accent": "#c9a86a",              // optional: tints the UI while this sound is loaded
  "params": { "amp_release": 900, "rev_mode": "Basilica" }   // defaults for §5 params
}
```

Metadata the plugin may show and must otherwise ignore: `credits` (list of
`{source, author, license, license_class, url, retrieved}`), `license` (the most
restrictive of the sources: a sound built from a non-commercial or EULA source
is private), `meta` (what the compiler measured, e.g. `meta.calibration`: the
instrument gain and per-zone corrections of the level ladder). The format is
`libero.bundle/2` exactly when a bundle/2 feature is used (`dyn`, `tune_cents`,
`rt_decay`, `rt_min_db`, `one_shot`, `choke_group`, `chokes`, `articulation`, `articulations`, `dynamics`, `humanize`, `rr_reset_ms`, more than 8 takes,
or zone files that are not float WAV); otherwise it stays `libero.bundle/1`.

Rules the plugin relies on:
- Pitched zones of one layer cover their mapped musical range without gaps. By default the
  compiler fills ranges by nearest root and stretches the outer zones across the keyboard.
  `edge_fill=False` retains a limited range. `preserve_key_ranges=True` additionally keeps each
  explicit region's `lo/hi`, even when round robins selected on one played key have different
  physical sample roots; every pitched region must then declare both bounds. Coverage is checked
  between the mapped minimum and maximum, excluding reserved articulation keys; internal holes
  and overlaps remain invalid.
- Takes: zones of one layer with identical key and velocity ranges are the takes of one zone; their
  `take` values are exactly 0..N-1. On each note-on the plugin picks a body take at random without
  repeating the previous take of that zone (seeded, so `libero-render` stays reproducible). Attack and
  tail use the body's take when they have the same number of takes, otherwise pick their own.
- `loop.end` is exclusive: when playback reaches `end` it continues at `start`.
- **Dynamics layers** (`dyn`): zones of one layer with the same key and velocity ranges and a `dyn`
  range are the dynamics layers of that key (each may have its own takes). A body voice plays all of
  them on one timeline and crossfades equal power (cos/sin) between the two layers whose centres
  bracket the current dynamics value, the lowest/highest layer alone outside them. How much of the
  gap between two centres is blended is `dynamics.crossfade` (0..1, optional): **absent = 1**, the
  blend spans the whole gap (the original behaviour, kept byte-identical for bundles without the
  field); `0.3` blends only the middle 30 % of the gap and plays one layer alone on either side;
  **`0` is a hard switch**: a note plays exactly one layer, the one whose range holds the dynamics
  value at note-on (the nearer centre), with no blend at all. With CC dynamics and `crossfade` 0
  the layer is still chosen at note-on and never changes mid-note; with `crossfade` > 0 the CC
  moves the blend live. Use 0 for struck, plucked and percussive instruments (piano, guitar,
  harp, mallets, drums, pizzicato): two different strikes summed differ in pitch, phase and decay and
  smear into chorus/flange. Crossfade only phase-aligned sustained layers (bowed, wind, brass), and
  only when `libero lint` (`crossfade` check, render-vs-raw correlation >= 0.95 at a mid velocity)
  agrees. The compiler writes the sound's `sound.performance(dyn_crossfade=...)`, else the family
  default (piano, plucked, mallet, percussion: 0; bowed, wind, brass: 0.3 when the layers measure
  phase-aligned, else 0) and reports the choice. Attack and tail layers with `dyn` use the same
  weights, with the dynamics value at trigger time, fixed for that note. Zones without `dyn` keep
  hard `vel_lo/vel_hi` switching.
- **Dynamics value**: with source `velocity` it is `(velocity/127)^velocity_curve`, fixed at note-on.
  With `cc1`/`cc11` it follows the controller on every sounding voice (smoothed ~20 ms); before the
  controller first moves it reads the `dynamics` parameter. Velocity still sets the level through
  `vel_sens`. The `dyn_mode` parameter (§5) can override the source.
- `tune_cents` shifts a pitched zone's playback; unpitched zones ignore it.
- **Release by duration**: a tail zone with `rt_decay` plays `max(rt_min_db, -rt_decay × held_s)` dB
  quieter, `held_s` being the time from note-on to note-off (SFZ `rt_decay`).
- **Humanize**: on each note-on the plugin draws, from a seeded generator (renders stay
  reproducible), a tuning offset in ±`cents`, an onset delay in 0..`ms` (resolution: one control
  block, ≤ 32 samples) and a level offset in ±`db`, all scaled by the `humanize` parameter.
- **`rr_reset_ms`**: after this much silence (no voice sounding, no key held) the take cycle
  restarts: the next note plays take 0. Bundles with `rr_reset_ms` also start at take 0.
- `air` has exactly one zone, unpitched, and always loops (loop = whole file if null); it has no
  takes, `dyn` or humanize.
- Unpitched zones play at original speed regardless of note. Body, attack and tail zones may keep
  their own `lo`/`hi` (a drum kit: one articulation per key); keys no zone maps play the nearest
  one, and only `air` must cover 0..127. The recipe's `fill_gaps=True` tiles the gaps at compile time.
- **One-shot** (`one_shot`, zone value or manifest default, read from the body zone of the note): note-off
  and the sustain pedal are ignored. The body, attack and tail layers play on to their natural end
  (the compiler's end fade); the amp envelope stays in sustain, so release applies only to a voice
  steal. No release-triggered tail is started. Not meant for bundles that also play live oscillators.
- **Choke groups** (`choke_group` ≥ 1 on the body zone, `chokes` a list of further groups): when a note
  starts, every other sounding voice whose body zone is in the new zone's group or in one of its
  `chokes` fades out over about 15 ms (raised cosine, click-free) and is freed; no release tail.
  The new voice itself is never choked, so a zone in group G also cuts its own earlier hits.
  Typical: closed/pedal hat (`choke_group` 1) over the open hat (`choke_group` 1), or a muted
  conga over its open ring. Zones without a group are never choked.
- **Articulations** (`articulations` in the manifest, `articulation` on zones): the plugin keeps one
  *active articulation* (an index into the list; the first, index 0, after loading a sound). Every
  zone lookup (body, attack, tail, takes, dynamics sets) considers only the zones whose
  `articulation` is the active one plus the zones without the field; air is never filtered. A
  zone group (§ takes, dynamics) never mixes articulations. The active articulation is chosen by
  (a) a note-on on an articulation's `key`: it switches and makes no sound (its note-off is
  swallowed too; the key never reaches the voices, the held-key memory or the glide), (b) the
  `artic` parameter (§5), whose value indexes the list, clamped to its length, (c) the socket's
  `set_params {artic: n}` (same parameter). A keyswitch overrides the parameter until the
  parameter moves again; the plugin mirrors the keyswitch into the parameter (so the host and UI
  follow). Switching affects **new notes only**: a sounding note and its release tail keep the
  articulation they started with. `key` values must be unique and lie outside every zone's
  `lo..hi` (a bundle may therefore leave keys beyond its played range unmapped; this relaxes the
  "no gaps" rule for those edge keys only). Sounds without `articulations` ignore all of this
  and key 24 plays normally.
- Missing keys in `params` → parameter defaults from §5. Exception: `echo_time` without `echo_sync`
  sets `echo_sync` to Libero (§5, echo sync).
- **`preview.m4a`** (optional file next to the manifest; `preview.wav`, mono 22 kHz, where AAC is
  unavailable): 4–6 s of the sound rendered by `libero-render` at compile time and normalised to
  about -16 LUFS: a phrase and chord in the main register (pitched sounds), a 2-bar groove from the
  playable octave (drum kits), the main hits in sequence (one-shot banks). `libero preview-all`
  makes the missing ones for the whole library. The plugin only streams it for the library's play
  buttons; the engine ignores it.
- **Oscillator-only bundles** (bundle/2): `zones` may be empty (or have no body) when `params`
  turns an oscillator on; the plugin then plays its live oscillators only. It also plays them with
  no bundle loaded at all.
- **`onset_ms`** (bundle/2, manifest-level default, per-zone override): the pre-roll before the
  strike in each attack/body/tail zone, skipped at note-on (playback starts that many ms into the
  zone with a 1 ms fade-in) so the strike lands on the note. Air ignores it. Default 0.

## 5. Live parameters

These are the host-automatable parameters. IDs are stable forever (DAW
projects store them). Ranges are the *plain* values; the plugin maps them with
the given skew. `choice` params are stored as index.

| id | name (UI) | range / choices | default | notes |
|---|---|---|---|---|
| **Layers** |
| `lvl_attack` | Attacco | -60..+6 dB | 0 | |
| `lvl_body` | Corpo | -60..+6 dB | 0 | |
| `lvl_tail` | Coda | -60..+6 dB | -6 | |
| `lvl_air` | Aria | -60..+6 dB | -18 | the noise bed: "rumore di fondo"; unpitched, so `tune`/`fine` do not move it |
| **Envelope (body)** |
| `amp_attack` | Attacco | 0..5000 ms, skew log | 2 | |
| `amp_decay` | Decadimento | 1..10000 ms, log | 400 | |
| `amp_sustain` | Sostegno | 0..1 | 1.0 | |
| `amp_release` | Rilascio | 1..15000 ms, log | 300 | |
| `amp_curve` | Curvatura | -1..1 | 0 | <0 = exponential-ish, >0 = logarithmic-ish |
| `air_attack` | Aria · entrata | 0..5000 ms, log | 30 | air follows note-on/off with its own AR |
| `air_release` | Aria · uscita | 1..15000 ms, log | 800 | |
| `air_follow` | Aria · segue | 0..1 | 1.0 | 0 = air is always on (drone bed), 1 = gated by notes |
| **Pitch** |
| `tune` | Intonazione | -24..+24 st, step 1 | 0 | |
| `fine` | Fine | -100..+100 cents | 0 | |
| `glide` | Portamento | 0..2000 ms, log | 0 | only between overlapping notes: a note glides from the most recent key still held, never after a rest (all modes) |
| `vel_sens` | Velocity | 0..1 | 0.7 | amplitude response to velocity |
| `vel_amp_curve` | Velocity curve | 0..1 | 0 | blends the existing amplitude response with `1.32x/(x+0.32)`, where `x=velocity/127`; higher velocities change gently, with a steeper fall near zero. Giove Theremin/Trautonium presets use 1 |
| `voices` | Voci | 1..32, step 1 | 16 | |
| `mode` | Modo | Poli, Mono, Legato | Poli | Mono/Legato: one voice, last-note priority, note memory (releasing the top note returns to the previous held one). Mono retriggers each note. Legato: a note played while another is held does not retrigger the envelope or the attack layer; the pitch glides over max(`glide`, 25 ms) and the body crossfades (≈30 ms, phase-aligned) to the new key's zone |
| `dyn_mode` | Dinamica da | Velocità, Modulazione, Manopola | Velocità | source of the dynamics axis (§4): Velocità = the bundle's own `dynamics.source` (velocity unless it says cc1/cc11); Modulazione = CC1; Manopola = the `dynamics` knob (automatable in any host) |
| `dynamics` | Dinamica | 0..1 | 0.7 | position on the dynamics axis with Manopola; the value CC sources start from until they move |
| `humanize` | Umano | 0..1 | 1.0 | scales the bundle's `humanize` (0 = off) |
| `artic` | Articolazione | 0..15, step 1 | 0 | active articulation: index into the manifest's `articulations` (§4; clamped to the list, ignored without one). Moves with keyswitches; not counted as "modificato". Appended at the end of the plugin's parameter list |
| **Oscillatori** (live, per voice, mixed with the sample layers before drive → filter; shaped by the body envelope) |
| `osc1_wave` | Onda 1 | Sega, Quadra, Triangolo, Seno, Rumore | Sega | band-limited wavetables (quarter-octave mipmaps, never above Nyquist) |
| `osc1_oct` | Ottava 1 | -3..+3, step 1 | 0 | |
| `osc1_semi` | Semitoni 1 | -12..+12 st, step 1 | 0 | |
| `osc1_fine` | Fine 1 | -100..+100 cents | 0 | |
| `osc1_level` | Livello 1 | -60..+6 dB | -60 | -60 = off |
| `osc1_pw` | Larghezza 1 | 0.05..0.95 | 0.5 | pulse width (Quadra) |
| `osc1_phase` | Fase L/R 1 | 0..1 | 0 | right channel's phase offset, fraction of a cycle: width without unison. A true phase offset, so partial k cancels in mono where k × offset is near half a cycle (0.5 removes the odd harmonics in mono) |
| `osc1_voices` | Voci 1 | 1..8, step 1 | 1 | unison |
| `osc1_detune` | Scordatura 1 | 0..1 | 0.25 | unison spread: voices evenly placed within ±60·detune² cents |
| `osc1_spread` | Apertura 1 | 0..1 | 0.5 | unison stereo spread |
| `osc1_phase_mod` | Moto di fase 1 | 0..1 | 0 | slow motion of the L/R offset (three rates, 0.4–1.4 Hz, up to ±¼ cycle) |
| `osc2_*` | … 2 | same as `osc1_*` | same (level -60) | |
| `sub_level` | Sub | -60..+6 dB | -60 | one octave below oscillator 1, centred |
| `sub_wave` | Onda sub | Seno, Quadra | Seno | |
| `osc_drift` | Deriva | 0..1 | 0.15 | slow analogue pitch drift, independent per oscillator and per side (up to ±7 cents); seeded |
| `osc_retrig` | Fase | Libera, Riavvia | Libera | Libera: random (seeded) start phase per note; Riavvia: phases reset at note-on |
| **Moto** (one global LFO; each note fades it in over `lfo_delay`) |
| `lfo_shape` | Forma | Seno, Triangolo, Quadra, Dente, Casuale | Seno | Quadra has softened edges; Casuale = smoothed sample-and-hold |
| `lfo_rate` | Frequenza | 0.02..20 Hz, log | 5 | |
| `lfo_delay` | Ritardo | 0..3000 ms | 0 | |
| `lfo_pitch` | Vibrato | 0..100 cents | 0 | applies to samples and oscillators |
| `lfo_pitch_cc1` | Wheel vibrato | 0..100 cents | 0 | additional LFO pitch depth multiplied by live CC1; before a wheel message its contribution is zero. Giove Theremin/Trautonium presets set base `lfo_pitch` to zero, allowing loud straight, loud vibrato and quiet straight playing |
| `lfo_cutoff` | Al filtro | 0..4 oct | 0 | |
| `lfo_amp` | Tremolo | 0..1 | 0 | gain swings between 1 and 1 − depth |
| `lfo_pw` | Alla larghezza | 0..1 | 0 | pulse width (Quadra oscillators) |
| **Tone** |
| `flt_mode` | Filtro | Basso, Banda, Alto, Vocale | Basso | Vocale = formant (vowel via `flt_cutoff`); Basso at 20 kHz is open |
| `flt_cutoff` | Taglio | 20..20000 Hz, log | 20000 | |
| `flt_reso` | Risonanza | 0..1 | 0.1 | |
| `flt_env` | Inviluppo filtro | -1..1 | 0 | modulation from body envelope, ±5 octaves |
| `drive` | Calore | 0..1 | 0 | soft saturation pre-filter |
| `fenv_source` | Inviluppo del filtro | Ampiezza, Propria | Ampiezza | what `flt_env` follows: the amp envelope, or the filter's own `fenv_*` ADSR |
| `fenv_attack` | Filtro · attacco | 0..5000 ms | 0 | |
| `fenv_decay` | Filtro · decadimento | 1..10000 ms | 400 | |
| `fenv_sustain` | Filtro · sostegno | 0..1 | 0 | |
| `fenv_release` | Filtro · rilascio | 1..15000 ms | 300 | |
| `flt_key` | Segue la nota | 0..1 | 0 | 1 = cutoff follows pitch 1:1 around C4 |
| `flt_vel` | Velocità al filtro | 0..1 | 0 | up to +3 octaves of cutoff at velocity 127 |
| **Risonanze** (resonator) |
| `res_mode` | Risonanza | Corde, Vetro, Legno, Metallo | Corde | Corde = sympathetic comb strings; Vetro = inharmonic modal glass; Legno = body formants; Metallo = plate modes |
| `res_tune` | Accordatura | -24..+24 st | 0 | relative to played note (Corde) or to C (others) |
| `res_decay` | Durata | 0..1 | 0.5 | |
| `res_bright` | Luce | 0..1 | 0.5 | |
| `res_mix` | Quantità | 0..1 | 0 | |
| **Nastro** (tape) |
| `tape_wow` | Wow | 0..1 | 0 | slow pitch drift |
| `tape_flutter` | Flutter | 0..1 | 0 | fast pitch jitter |
| `tape_sat` | Saturazione | 0..1 | 0 | |
| `tape_age` | Età | 0..1 | 0 | hiss + HF loss + slight dropouts |
| `tape_mix` | Nastro | 0..1 | 0 | |
| **Eco** (delay) |
| `echo_time` | Tempo | 10..2000 ms, log | 375 | used when `echo_sync` = Libero |
| `echo_feedback` | Ritorno | 0..0.95 | 0.35 | |
| `echo_tone` | Colore | 0..1 | 0.5 | dark ↔ bright in the loop |
| `echo_spread` | Ampiezza | 0..1 | 0.5 | ping-pong amount |
| `echo_mix` | Eco | 0..1 | 0 | |
| `echo_sync` | Sincro | Tempo, Libero | Tempo | Tempo: the delay is `echo_div` at the host BPM; Libero: `echo_time` in ms |
| `echo_div` | Suddivisione | 1/32, 1/16T, 1/16, 1/16., 1/8T, 1/8, 1/8., 1/4T, 1/4, 1/4., 1/2, 1/1 | 1/8 | used when `echo_sync` = Tempo |
| **Sala** (reverb) |
| `rev_mode` | Sala | Cappella, Basilica, Cisterna, Piastra, Impronta | Basilica | Impronta = convolution with the bundle's `ir.wav` (falls back to Basilica if absent) |
| `rev_size` | Dimensione | 0..1 | 0.6 | |
| `rev_decay` | Durata | 0.1..30 s, log | 3.5 | |
| `rev_predelay` | Attesa | 0..250 ms | 20 | |
| `rev_damp` | Ombra | 0..1 | 0.4 | high-frequency damping |
| `rev_width` | Ampiezza | 0..1 | 1.0 | |
| `rev_shimmer` | Aureola | 0..1 | 0 | octave-up shimmer fed back into the tank |
| `rev_mix` | Sala | 0..1 | 0.2 | |
| **Output** |
| `width` | Stereo | 0..2 | 1 | mid/side |
| `master` | Volume | -60..+6 dB | 0 | |
| **Caldi** (optional EQ/compression chains) |
| `caldi_mode` | Carattere | Spento, Velluto, Presenza, Intimo, Blu, Soffio | Spento | bypass is bit-identical |
| `caldi_amount` | Quantità | 0..1 | 0.65 | dry/wet amount; selecting a character engages it |
| `caldi_body` | Corpo | 0..1 | 0.5 | low shelf relative to the chosen character |
| `caldi_light` | Luce | 0..1 | 0.5 | high shelf relative to the chosen character |
| `caldi_grain` | Grana | 0..1 | 0 | filtered generated texture follows input, silent at rest |
| `caldi_motion` | Movimento | 0..1 | 0 | shallow slow amplitude/texture motion, no pitch modulation |
| `caldi_output` | Uscita | -12..+3 dB | 0 | trim of the treated path |

Parameters added after the first release (`mode`, `dyn_mode`, `dynamics`, `humanize`, then
the oscillators, the LFO, then the filter envelope and tracking, `osc*_phase_mod`, `artic`, then `echo_sync` and `echo_div`, then the seven `caldi_*` parameters) are appended at the end of
the plugin's parameter list, whatever their group here, so host automation
indices stay stable.

Signal order per voice: `attack + (body + oscillators)(→env) + tail` → drive → filter →
resonator (per voice for Corde, since it tracks the note). Then summed with
air → Caldi → tape → echo → reverb → width → master.

**Caldi.** Each character combines three EQ filters and a stereo-linked soft-knee
parallel compressor. Grain and movement are optional, with no flanger or pitch
wow. Switching characters fades through dry; controls are smoothed. Spento
bypasses the chain exactly, including its output trim. New or old sounds do not
enable it implicitly. Loading a legacy DAW state inserts the defaults for absent
Caldi parameters so an already-enabled instance cannot leak its chain into the
old project. Saved new values retain their seven appended automation indices.

**Echo sync.** In Tempo mode the delay is `echo_div` (in quarter-note beats: 1/32 = 1/8 beat … 1/1 = 4,
T = ×2/3, dot = ×1.5) at the BPM the host reports (`AudioPlayHead`; 120 when it reports none and
in `libero-render`), clamped to 10..4000 ms. A change of division or tempo crossfades (50 ms) between
two taps, so it never glides in pitch or clicks; a host ramping its tempo is followed smoothly.
Libero mode is the original delay (`echo_time`, slewed like a tape echo). **Migration:** a
manifest `params` (or a `--params` / `set_params`-style JSON object applied by the engine's loader)
that sets `echo_time` without `echo_sync` loads with `echo_sync` = Libero, so every sound made
before the sync existed sounds exactly as before; sounds that set neither get Tempo.

## 6. Agent socket (live control of a running plugin)

Each plugin instance listens on TCP `127.0.0.1`, first free port in
`47800..47899`, and writes `~/Libero/instances/<id>.json` (removed on
destruction):

```json
{"id": "a1b2c3", "port": 47801, "pid": 1234, "host": "FL Studio", "sound": "/Users/.../sounds/lyra-aeterna", "started": "2026-..."}
```

Protocol: newline-delimited JSON. Request `{"id": 1, "method": "...", "params": {...}}`,
response `{"id": 1, "result": ...}` or `{"id": 1, "error": "message"}`.

| method | params | result |
|---|---|---|
| `info` | – | `{id, host, sound, title, modified, version, sample_rate, block_size}` — `modified`: params differ from the sound's defaults |
| `load` | `{path}` (a sound folder or its `build/`) | `{ok, title}`; applies manifest `params` |
| `get_params` | `{ids?}` | `{id: plainValue}` (choices as their string) |
| `set_params` | `{values: {id: plainValue or choice string}}` | `{ok, applied:[...]}` (host-notified, undoable) |
| `note` | `{pitch, velocity=100, duration_ms=800}` | `{ok}` — audition through the plugin's output |
| `panic` | – | `{ok}` all notes off |
| `status` | `{text}` | `{ok}` — shows a line in the UI ("the agent is tuning the resonators…") |
| `reload` | – | `{ok, title}` — re-reads the current bundle from disk (after a recompile), keeping the current params |
| `reset` | – | `{ok}` — params back to the sound's defaults (§5 defaults + manifest `params`) |
| `list_banks` | – | `[{slug, title, subtitle, description, version, author, license, created, updated, count, figureUrl?, builtin}]` — banks, then `mie`, `prove` |
| `set_color_tag` | `{path, color}` | `{ok}` — `color` 0–4 (0 removes), stored in `config.json` by slug |
| `create_bank` | `{title, subtitle?}` | `{ok, slug, path}` — `banks/<slug from title>/bank.json` (unique slug, `1.0.0`) |
| `edit_bank` | `{slug, title?, subtitle?, description?}` | `{ok, slug}` — only the given fields change |
| `export_bank` | `{slug, path}` | `{ok, path}` — writes the `.liberobank` (a folder `path` gets `<slug>.liberobank`); error names the sounds that forbid it |
| `import_bank` | `{path}` | `{ok, slug, path}` — installs a pack; refuses the same or an older version |
| `move_sound` | `{path, bank}` | `{ok, path}` — moves a saved sound into the bank (`mie` = back to `sounds/`); refuses overwrite and sketches; keeps a loaded sound loaded |
| `save_as` | `{title}` | `{ok, path, slug}` — saves what is playing as a new sound (see `saveSoundAs`, §9) and loads it |

The plugin also reloads by itself: about once a second it checks the current
sound's `build/manifest.json` and, when its modification time changes, reloads
the bundle keeping the current params (the UI shows "Ricaricato").

The UI shows a subtle "in ascolto" mark while any client is connected.

## 7. Offline renderer (`libero-render`)

Same engine, no host. Used by the Python library for previews and tests.

```
libero-render [--sound <folder or build dir>] --out out.wav    # no --sound: the oscillators alone
              [--notes "60:0:1.2:100,64:0.5:1.0:90"]   # pitch:start_s:dur_s:velocity
              [--params '{"rev_mix":0.3}'] [--params-file p.json]
              [--tail 3.0] [--sr 48000] [--block 256]
              [--bpm 120]                               # host tempo, for echo_sync = Tempo
              [--automation '[{"t": 2.0, "params": {...}, "bpm": 140}]']   # params and/or tempo changes mid-render
              [--cc "0:1:0,4.0:1:127"]                  # time_s:controller:value (MIDI CC, e.g. CC1)
```

Deterministic given the same inputs (fixed seeds for noise/tape, the choice of
round-robin takes, oscillator start phases and drift). Overlapping notes in `--notes` exercise
`mode=Legato` (a note that starts before the previous one ends is slurred). Prints a
one-line JSON summary on stdout: `{"out": ..., "seconds": ..., "peak_db": ..., "rms_db": ...}`.

## 8. Figures

Every sound has a figure: `figure.svg`, `viewBox="0 0 512 512"`, drawn by the
same model that designed the sound. It is shown large in the plugin and as a
tile in the library. It must be self-contained (no external refs, no scripts,
no raster images) and should *read from the sound*: its envelope, its
partials, its material. The house style and the rules against generic
imagery live in `python/libero/guides/figures.md`; the MCP exposes them.

## 9. UI

The plugin UI is a WebView (JUCE `WebBrowserComponent`) loading `ui/` from
resources embedded in the binary. In a normal browser, `ui/index.html` runs
with a mock backend so the design can be worked on without a DAW.

Native functions (JS → C++), all async, JSON in/out:

| name | args | returns |
|---|---|---|
| `listSounds` | – | `[{slug, path, title, subtitle, tags, saved, bank: {slug, title}, figureUrl, previewUrl?, accent, favorite, colorTag (0–4), mtime}]` (sketches, sounds, banks) — `mtime`: ms since epoch of `build/manifest.json`; `previewUrl` (`/preview/<folder>`, served by the editor) only when `build/preview.m4a|wav` exists |
| `loadSound` | `path` | `{ok, error?}` |
| `currentSound` | – | same shape as a list item plus `modified` and, with articulations, `articulation` (the active index), or null |
| `reloadSound` | – | `{ok, error?}` — like the socket's `reload` |
| `resetSound` | – | `{ok}` — like `reset`; one transaction in the plugin's undo history |
| `saveSoundAs` | `title` | `{ok, path}` — creates `sounds/<slug from title>/` (unique): `build/` audio and `samples/` hard-linked (copied only where links fail), `sound.py`, `notes.md`, `figure.svg` copied; `build/manifest.json` gets the new slug, title and the current non-default params; the copied `sound.py` gets `sound.retitle(title)` and `sound.defaults(...)` appended so a recompile keeps them. Then loads it |
| `setFavorite` | `path, bool` | `{ok}` (persisted in config.json) |
| `saveSound` | `path` | `{ok, path}` — sketch → library |
| `discardSketch` | `path` | `{ok}` — moves to the OS trash (recoverable) |
| `listBanks` | – | `[{slug, title, subtitle, description, version, author, license, created, updated, count, figureUrl?, builtin}]` — installed banks, then Mie and Prove; `figureUrl` serves the bank's cover |
| `setColorTag` | `path, n` | `{ok}` — as the socket's `set_color_tag` |
| `createBank` | `title, subtitle` | `{ok, slug, path}` |
| `editBank` | `slug, {title?, subtitle?, description?}` | `{ok}` |
| `exportBank` | `slug, path?` | without `path` a native save dialog opens; `{ok, path}`, `{ok:false, cancelled:true}` or `{ok:false, error}` |
| `inspectBank` | `path?` | without `path` a native open dialog; returns the bank review and intended action (§2.4) without installing |
| `importBank` | `path?` | without `path` a native open dialog; `{ok, slug, path}`, cancelled or `{ok:false, error}` |
| `moveSound` | `path, bankSlug` | `{ok, path}` or `{ok:false, error}` — as the socket's `move_sound` |
| `revealSound` | `path` | opens the folder in Finder |
| `listThemes` | – | `[{name, builtin}]` |
| `getTheme` | `name?` | `{name, css}` of the theme (current if no name) |
| `setTheme` | `name` | `{ok}` (persisted in config.json) |
| `agentStatus` | – | `{port, clients, lastMessage}` |
| `audition` | `pitch, velocity` | `{ok}` — click-to-hear from the UI keyboard/figure |
| `sampleEditorInfo` | – | Mapped pitched body zones, identity, editability and original loop/trim defaults |
| `sampleEditorWaveform` | `file` | Decoded source waveform, duration and loop defaults for a listed zone |
| `applySampleEditorEdit` | `edit` | Validated trim/loop for the exact zone and source hash; `restore:true` removes its override |

Events (C++ → JS) via `window.__JUCE__.backend.addEventListener(name, fn)`:
`soundChanged` (payload = current sound), `soundLoading` (payload = the incoming
sound's list item, sent before its samples are decoded), `soundError` (`{error}`),
`soundReloaded` (`{auto}`: true when triggered by the manifest watcher),
`soundModified` (`{modified}`), `articulationChanged` (`{index, id}`: the active articulation changed, from a keyswitch, the parameter or a click), `agentStatus`, `scope`
(`{l: [..64 floats], r: [...], level: float}` at ~30 Hz, for the living figure).
`samplePlayback` reports `{sound_id, zone, note, seconds, looped}` for the newest
sounding body voice. Positions come from the audio engine, including pitch changes,
trim offsets and loop wraps; `zone:-1` clears the playhead when no sample is sounding.
The audio thread passes copied numeric values through a bounded FIFO without UI
calls, allocation or file access.

**Sample editor.** Simple pitched sample instruments can be edited directly in
the user's banks, sounds or sketches. `sample-edits.json` stores per-zone bounds
and loops; source audio stays intact. Changes save automatically and reload playback with the live parameters
preserved. An explicit start replaces the preset's onset skip. Restore removes the
selected override and reloads the original bounds. Shared files remain read-only
because one file can address several different mappings. Follow keys selects the
currently sounding zone unless an edit is pending; selecting a zone manually turns
following off. The sound column scrolls when controls exceed the window height.

**Personal copies.** Save as preserves the source artwork and records the original
slug and title in `sound-origin.json` (`libero.sound-origin/1`). Further copies keep
the original identity. The current cover and library tile display a small Copy flag.
The sidecar travels with bank exports and remains after recompilation.

**Articulation row.** When the loaded sound has `articulations`, a row of words (their `name`s, in
manifest order, set in italic) sits under the caption; the active one is underlined in the accent
colour, a click selects it (through the `artic` parameter) and it follows keyswitches and
automation (`articulationChanged`). Without articulations the row is hidden.

Parameters are bound with JUCE relays named exactly as the §5 ids
(`WebSliderRelay` for continuous/int, `WebComboBoxRelay` for choices).

The library drawer is organised as folders. Its top level is a grid of folder plates (a tabbed
folder drawn in hairlines, a `§` in the tab, the title, subtitle and sound count, and a cover: the
bank's `figure`, else a 2×2 mosaic of its first four sounds): **Preferiti** (virtual, every
favourite), **Mie**, **Prove**, then the installed banks. A folder opens into the sound grid
(search, colour filter and sort work within the whole library, see below); the head shows the
breadcrumb "Biblioteca / <folder>", and Esc or Backspace goes up one level (Esc at the top closes
the drawer). The last opened folder is remembered. Covers and figures are drawn only when their
plate scrolls into view.

Search and the colour filter look at every sound, whatever the folder: results appear as a flat grid
("Biblioteca / Ricerca"), each plate naming its bank; clearing the search returns to the folder.
Four swatches filter by colour tag. A sound's colour tag is a small corner triangle on its plate
and next to the caption's favourite star; both open a menu with the four names and "Nessuno".
Plates also offer "Sposta in…" (saved sounds), "Colore…" and "Mostra".

Top level actions: "Nuova banca…" (inline title and subtitle) and "Importa…" (native open
dialog). Inside a bank: "Esporta…" (native save dialog; a refusal is shown as the toast), "Modifica"
(inline title, subtitle, description), and the bank's description and `version · author · licence`.
A plate whose sound has a preview carries a small ▶ button (also on search results): it plays or stops that file in an HTML `<audio>` element, one at a time; another preview, loading a sound or closing the drawer stops it. Nothing is loaded into the engine.
Plates are created once and reused, so hundreds of sounds and dozens of banks stay fast.

### 9.1 Themes

A theme is a CSS file defining custom properties on `:root`. The built-in one
is `ui/themes/harmonic.css`. Only these tokens may be relied on by the UI
(themes may define more for their own decorative rules):

```
--bg, --bg-2, --surface, --ink, --ink-soft, --ink-faint, --line,
--accent, --accent-2, --glow, --danger,
--tag-1, --tag-2, --tag-3, --tag-4 (colour tags: Pompeian red, ochre, verdigris, lapis),
--font-display, --font-text, --font-mono,
--radius, --grain-opacity, --texture (a url() or none), --sky (a gradient)
```

A theme may also include ordinary CSS rules (ornaments, textures). Built-in
themes live in `ui/themes/`; user themes in `~/Libero/themes/` win on name
clashes.

## 10. Build & install

`scripts/build.sh` → universal (arm64 + x86_64) Release: `Libero.vst3`,
`Libero.component`, `libero-render`. `scripts/install.sh` copies plugins into
`~/Library/Audio/Plug-Ins/{VST3,Components}` and `libero-render` into
`~/.local/bin`. x86_64 is required: LMMS on macOS is an Intel build hosted
through Carla; FL Studio is native arm64.

## 11. Rules for contributors

- The engine is realtime-safe: no allocation, locks or file IO on the audio
  thread. Bundles are loaded on a background thread and swapped atomically.
- A sound that loads must never click, denormal, or blow up — clamp feedback,
  flush denormals, crossfade loops.
