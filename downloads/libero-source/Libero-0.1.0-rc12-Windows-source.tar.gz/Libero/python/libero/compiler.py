"""Compile a sound folder into its `build/` bundle (SPEC §4).

`compile_sound()` runs the recipe in a separate process with a timeout, so a
broken or endless recipe cannot hang the caller. Inside that process zones are
rendered in parallel and cached by a hash of everything that can change their
audio, so recompiling after editing only `defaults()` or the title is instant.
"""

from __future__ import annotations

import ast
import datetime as _dt
import hashlib
import json
import math
import os
import shutil
import signal as _signal
import subprocess
import sys
import time
import traceback
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from . import __version__, dsp, library
from .audio import Audio

RESULT_TAG = "LIBERO_RESULT "


@dataclass
class Zone:
    layer: str
    note: int
    velocity: int
    pitched: bool
    file: str
    lo: int = 0
    hi: int = 127
    vel_lo: int = 1
    vel_hi: int = 127
    take: int = 0
    dyn: float | None = None          # synthesised dynamics layer: its position 0..1
    dyn_lo: float | None = None
    dyn_hi: float | None = None


@dataclass
class CompileResult:
    ok: bool
    summary: str
    warnings: list[str] = field(default_factory=list)
    manifest: dict | None = None
    build: str | None = None
    error: str | None = None
    seconds: float = 0.0

    def text(self) -> str:
        if not self.ok:
            return f"compile FAILED: {self.error}"
        w = "\n".join(f"  ! {x}" for x in self.warnings) or "  (none)"
        return f"{self.summary}\nwarnings:\n{w}"


# ---------------------------------------------------------------- ranges

def key_ranges(roots: list[int] | tuple[int, ...]) -> list[tuple[int, int]]:
    """Nearest-root key ranges covering 0..127 without gaps (ties go to the lower root)."""
    rs = sorted(roots)
    out = []
    for i, r in enumerate(rs):
        lo = 0 if i == 0 else (rs[i - 1] + r) // 2 + 1
        hi = 127 if i == len(rs) - 1 else (r + rs[i + 1]) // 2
        out.append((lo, hi))
    return out


def vel_ranges(vels: list[int] | tuple[int, ...]) -> list[tuple[int, int]]:
    vs = sorted(vels)
    out = []
    for i, v in enumerate(vs):
        lo = 1 if i == 0 else (vs[i - 1] + v) // 2 + 1
        hi = 127 if i == len(vs) - 1 else (v + vs[i + 1]) // 2
        out.append((lo, hi))
    return out


def _take_name(file: str, take: int, takes: int) -> str:
    return file if takes <= 1 else file[:-4] + f"_t{take}.wav"


def dyn_ranges(dyns) -> list[tuple[float, float]]:
    """Tile 0..1 around the given dynamics positions (boundaries at midpoints)."""
    ds = sorted(dyns)
    out = []
    for i, d in enumerate(ds):
        lo = 0.0 if i == 0 else round((ds[i - 1] + d) / 2, 6)
        hi = 1.0 if i == len(ds) - 1 else round((d + ds[i + 1]) / 2, 6)
        out.append((lo, hi))
    return out


def plan_zones(snd) -> list[Zone]:
    zones: list[Zone] = []
    kr = key_ranges(snd.roots)
    takes = getattr(snd, "takes", 1)
    dyns = getattr(snd, "dynamics", None)
    if dyns:
        # synthesised dynamics layers: one render per position, velocity only names the zone
        axis = [(max(1, round(d * 127)), 1, 127, d, lo, hi) for d, (lo, hi) in zip(dyns, dyn_ranges(dyns))]
    else:
        axis = [(v, lo, hi, None, None, None) for v, (lo, hi) in zip(snd.velocities, vel_ranges(snd.velocities))]
    for name in ("body", "attack", "tail"):
        layer = snd.layers.get(name)
        if layer is None:
            continue
        for v, vlo, vhi, d, dlo, dhi in axis:
            tag = f"d{int(round(d * 100)):03d}" if d is not None else f"v{v:03d}"
            for t in range(takes):
                if layer.pitched:
                    for ri, r in enumerate(snd.roots):
                        f = _take_name(f"{name}_n{r:03d}_{tag}.wav", t, takes)
                        zones.append(Zone(name, r, v, True, f, kr[ri][0], kr[ri][1], vlo, vhi, t, d, dlo, dhi))
                else:
                    f = f"{name}.wav" if len(axis) == 1 else f"{name}_{tag}.wav"
                    zones.append(Zone(name, 60, v, False, _take_name(f, t, takes), 0, 127, vlo, vhi, t, d, dlo, dhi))
    if "air" in snd.layers:
        zones.append(Zone("air", 60, axis[-1][0], False, "air.wav"))
    if "impulse" in snd.layers:
        zones.append(Zone("impulse", 60, axis[-1][0], False, "ir.wav"))
    return zones


# ---------------------------------------------------------------- hashing

def _package_hash() -> str:
    h = hashlib.sha256(__version__.encode())
    for p in sorted(Path(__file__).parent.glob("*.py")):
        h.update(p.read_bytes())
    return h.hexdigest()


def render_hash(folder: Path) -> str:
    """Hash of what determines the audio: sound.py without its metadata and defaults()
    (normalised through the AST, so comments do not count), samples/, and the libero code."""
    src = (folder / "sound.py").read_text()
    try:
        tree = ast.parse(src)
        body = []
        for node in tree.body:
            if (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                    and isinstance(node.value.func, ast.Attribute)
                    and node.value.func.attr in ("defaults", "retitle")):
                continue
            body.append(node)
        tree.body = body
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "Sound":
                # `takes` only adds zones; each (zone, take) has its own cache key below.
                node.keywords = [k for k in node.keywords
                                 if k.arg not in ("title", "subtitle", "tags", "accent", "takes")]
                node.args = []
        norm = ast.dump(tree, annotate_fields=False)
    except SyntaxError:
        norm = src
    h = hashlib.sha256(norm.encode())
    for p in library.sample_files(folder):
        h.update(str(p.relative_to(folder)).encode())
        h.update(library.file_digest(p))
    h.update(_package_hash().encode())
    return h.hexdigest()


# ---------------------------------------------------------------- zone rendering (worker side)

_RECIPE = None


def _init_worker(folder: str):
    global _RECIPE
    from .recipe import load_recipe

    _RECIPE = load_recipe(folder)


def _render_zone(args) -> dict:
    zone_d, cache_path = args
    z = Zone(**zone_d)
    snd = _RECIPE
    t0 = time.time()
    try:
        audio = snd.render(z.layer, z.note, z.velocity, z.take, z.dyn)
    except Exception:
        return {"zone": zone_d, "error": traceback.format_exc(limit=6)}
    if audio is None:
        return {"zone": zone_d, "omitted": True}
    try:
        audio, loop, warns, stats = _postprocess(audio, z, snd)
    except Exception:
        return {"zone": zone_d, "error": traceback.format_exc(limit=6)}
    cp = Path(cache_path)
    cp.parent.mkdir(parents=True, exist_ok=True)
    audio.save(cp)
    meta = {"loop": loop, "warnings": warns, "stats": stats}
    cp.with_suffix(".json").write_text(json.dumps(meta))
    return {"zone": zone_d, "cache": str(cp), **meta, "seconds": round(time.time() - t0, 2)}


def _zone_label(z: Zone) -> str:
    t = f" t{z.take}" if z.take else ""
    if z.pitched:
        return f"{z.layer} n{z.note}({dsp.note_name(z.note)}) v{z.velocity}{t}"
    return (z.layer if z.layer != "impulse" else "ir") + t


def _postprocess(audio: Audio, z: Zone, snd) -> tuple[Audio, dict | None, list[str], dict]:
    label = _zone_label(z)
    warns: list[str] = []
    sr = snd.sample_rate
    if audio.sr != sr:
        audio = audio.resample(sr)
    if audio.n < 16:
        raise ValueError(f"{label}: returned only {audio.n} samples")
    if not np.all(np.isfinite(audio.data)):
        raise ValueError(f"{label}: audio contains NaN or inf")
    if audio.duration > 60:
        warns.append(f"{label}: {audio.duration:.1f} s long — zones over ~20 s waste memory; loop instead")

    dc = float(np.abs(dsp.mono(audio.data).mean()))
    audio = audio.remove_dc(5.0 if z.layer == "impulse" else 8.0)
    if dc > 1e-2:
        warns.append(f"{label}: DC offset {dsp.db(dc):.0f} dB removed")

    loop = None
    ls = snd.loop_spec
    want_loop = (z.layer == "body" and ls.body) or (z.layer == "tail" and ls.tail and z.pitched)
    if want_loop:
        lp = audio.loop_points(ls.min_seconds, ls.region)
        if lp is None:
            warns.append(f"{label}: no loop found (sound too short or region too small); zone plays one-shot")
        else:
            if lp.error_db > -20:
                warns.append(f"{label}: loop seam error {lp.error_db:.1f} dB (audible; > -20 dB). "
                             f"Try a steadier sustain, a longer render, or loop(region=...)")
            audio = audio.bake_loop(lp)
            loop = lp.as_manifest()
            loop["error_db"] = lp.error_db
    elif z.layer == "air":
        audio, loop = _seamless_whole(audio)

    audio = audio.fade_in(16 / sr, "linear")
    if loop is None and z.layer != "impulse":
        audio = audio.fade_out(min(0.005, audio.duration / 4))

    pk = audio.peak_db
    if pk > -1.0:
        y, red = dsp.limit(audio.data, sr, -1.0)
        audio = Audio(y, sr)
        if red < -3.0:
            warns.append(f"{label}: peaked at {pk:+.1f} dBFS, limited by {-red:.1f} dB — lower the level in the recipe")
    if audio.peak_db < -60:
        warns.append(f"{label}: nearly silent (peak {audio.peak_db:.0f} dBFS)")

    stats = {"seconds": round(audio.duration, 3), "peak_db": round(audio.peak_db, 1),
             "rms_db": round(audio.rms_db, 1), "channels": audio.channels}
    if z.layer in ("body", "tail", "attack") and audio.duration > 0.05:
        stats["lufs"] = round(dsp.integrated_loudness(audio.data, sr), 1)
        stats["lufs_max"] = round(dsp.momentary_max(audio.data, sr), 1)

    if z.layer != "impulse" and sr >= 44100 and audio.duration > 0.05:
        from scipy import signal as sps

        m = dsp.mono(audio.data.astype(np.float64))
        f, p = sps.welch(m[: 4 * sr], sr, nperseg=min(len(m[: 4 * sr]), 4096))
        hf = 10 * math.log10(p[f >= 18000].sum() / (p.sum() + 1e-30) + 1e-20)
        stats["above_18k_db"] = round(hf, 1)
        if hf > -45 and z.layer == "body":
            warns.append(f"{label}: {hf:.0f} dB of its energy is above 18 kHz — aliasing or a harsh top; "
                         f"lowpass or render the oscillators band-limited")

    if z.layer == "body" and z.pitched:
        body = audio.trim(min(0.3, audio.duration * 0.2), min(audio.duration, 3.0))
        f0, voiced = dsp.estimate_f0(body.data, sr, 25.0, 5000.0)
        if np.isfinite(f0) and voiced > 0.4:
            f0 = dsp.refine_f0(body.data, sr, f0)
            cents = 1200 * math.log2(f0 / dsp.midi_to_freq(z.note))
            pc_cents = (cents + 600) % 1200 - 600  # distance to the root's pitch class, any octave
            stats["f0"] = round(f0, 2)
            stats["cents"] = round(pc_cents, 1)
            if abs(pc_cents) <= 60 and abs(pc_cents) > 8:
                warns.append(f"{label}: detuned {pc_cents:+.1f} cents from {dsp.note_name(z.note)} — use tune_to()")
    return audio, loop, warns, stats


def _seamless_whole(audio: Audio) -> tuple[Audio, dict]:
    """Make the whole file loop: blend its last `xf` samples into its head, then cut them off."""
    n = audio.n
    xf = min(int(0.25 * audio.sr), n // 4)
    if xf < 16:
        return audio, {"start": 0, "end": n, "crossfade": 0}
    x = audio.data.astype(np.float64)
    head = x[:xf]
    tail = x[n - xf:]
    t = (np.arange(xf) + 0.5) / xf
    gi, go = np.sin(0.5 * math.pi * t), np.cos(0.5 * math.pi * t)
    if x.ndim == 2:
        gi, go = gi[:, None], go[:, None]
    y = x[: n - xf].copy()
    y[:xf] = head * gi + tail * go
    out = Audio(y, audio.sr)
    return out, {"start": 0, "end": out.n, "crossfade": 0}


# ---------------------------------------------------------------- recorded multisamples

def _ms_code_hash() -> str:
    h = hashlib.sha256()
    for name in ("multisample.py", "audio.py", "dsp.py"):
        h.update((Path(__file__).parent / name).read_bytes())
    return h.hexdigest()[:16]


def _ms_source(folder: Path, file: str) -> Path:
    p = Path(file).expanduser()
    if not p.is_absolute():
        p = folder / "samples" / p
    if not p.exists():
        raise RuntimeError(f"multisample file not found: {file}")
    return p


def _ms_stage_a(args) -> dict:
    """Edit one recorded region (worker side; the recipe is loaded by _init_worker)."""
    from . import multisample as MS

    layer, idx, cache_path = args
    snd = _RECIPE
    spec = snd.multisamples[layer]
    reg = spec.regions[idx]
    try:
        src = _ms_source(snd.folder, reg.file)
        audio = Audio.load(src)
        if spec.custom is not None:
            ctx = snd.ctx(layer, reg.root, 100, reg.take)
            pre = audio
            audio = spec.custom(audio, reg, ctx)
            if not isinstance(audio, Audio):
                raise TypeError(f"custom process returned {type(audio).__name__}, expected Audio")
            del pre
        edited, facts = MS.edit_region(audio, reg, spec.process, snd.sample_rate)
    except Exception:
        return {"layer": layer, "index": idx, "error": traceback.format_exc(limit=5)}
    cp = Path(cache_path)
    cp.parent.mkdir(parents=True, exist_ok=True)
    tmp = cp.with_name(cp.name + ".part")
    import soundfile as sf

    sf.write(str(tmp), edited.data, snd.sample_rate, format="FLAC", subtype="PCM_24")
    os.replace(tmp, cp)
    cp.with_suffix(".json").write_text(json.dumps(facts))
    return {"layer": layer, "index": idx, "cache": str(cp), "facts": facts}


def _ms_stage_c(args) -> dict:
    from . import multisample as MS

    src, dst, shift, gain, enc = args
    try:
        info = MS.write_final(Path(src), Path(dst), shift, gain, enc)
    except Exception:
        return {"dst": dst, "error": traceback.format_exc(limit=5)}
    Path(dst).with_suffix(".json").write_text(json.dumps(info))
    return {"dst": dst, **info}


def _pool_map(fn, items, folder: Path, jobs: int | None):
    if not items:
        return []
    n_jobs = jobs or min(len(items), max(1, (os.cpu_count() or 2) - 1), 8)
    if n_jobs <= 1 or len(items) == 1:
        if _RECIPE is None or _RECIPE.folder != folder:
            _init_worker(str(folder))
        return [fn(a) for a in items]
    import multiprocessing as mp

    ctx = mp.get_context("spawn")
    with ProcessPoolExecutor(n_jobs, mp_context=ctx, initializer=_init_worker, initargs=(str(folder),)) as ex:
        return list(ex.map(fn, items, chunksize=max(1, len(items) // (n_jobs * 4))))


def build_multisamples(snd, folder: Path, jobs: int | None, use_cache: bool) -> tuple[list[dict], list[str], dict]:
    """All recorded layers → [{zone (manifest fields), file, final (cache path), facts}], warnings, report."""
    import inspect

    from . import multisample as MS

    if not snd.multisamples:
        return [], [], {}
    cache_root = library.cache_dir() / "multisample"
    code = _ms_code_hash()
    warnings: list[str] = []
    report: dict = {}
    out: list[dict] = []
    used_files: set[str] = set()
    body_gain = None
    reserved_keys = {a["key"] for a in (getattr(snd, "articulations_spec", None) or []) if a.get("key") is not None}
    order = sorted(snd.multisamples, key=lambda l: 0 if l == "body" else 1)
    for layer in order:
        spec = snd.multisamples[layer]
        planned = MS.plan_regions(spec, reserved_keys=reserved_keys)
        custom_src = ""
        if spec.custom is not None:
            try:
                custom_src = inspect.getsource(spec.custom)
            except (OSError, TypeError):
                custom_src = repr(spec.custom)
            # A custom step may read module-level constants or helpers; key it on the whole
            # recipe (defaults/retitle excluded), not only on its own source.
            custom_src += "|" + render_hash(folder)
        fp = MS.spec_fingerprint(spec)
        todo, facts, cache_a = [], {}, {}
        for z in planned:
            reg = spec.regions[z["index"]]
            src = _ms_source(folder, reg.file)
            key = MS.cache_key("A", code, MS.source_signature(src), json.dumps(asdict(reg), default=str), fp,
                               custom_src, snd.sample_rate)
            cp = cache_root / "a" / key[:2] / f"{key}.flac"
            cache_a[z["index"]] = cp
            if use_cache and cp.exists() and cp.with_suffix(".json").exists():
                facts[z["index"]] = json.loads(cp.with_suffix(".json").read_text())
            else:
                todo.append((layer, z["index"], str(cp)))
        for r in _pool_map(_ms_stage_a, todo, folder, jobs):
            if "error" in r:
                raise RuntimeError(f"{layer} region {spec.regions[r['index']].file}: {r['error']}")
            facts[r["index"]] = r["facts"]

        # stage B: alignment per key group, tuning, ladder
        import soundfile as sf

        proc = spec.process
        shifts = {z["index"]: 0 for z in planned}
        if proc.align_ms > 0:
            groups: dict[tuple, list[dict]] = {}
            for z in planned:
                if z["pitched"] or (z["lo"], z["hi"]) != (0, 127):   # a kit key aligns its layers and takes too
                    groups.setdefault((z.get("articulation"), z["root"], z["lo"], z["hi"]), []).append(z)
            for grp in groups.values():
                if len(grp) < 2:
                    continue
                # reference: the top dynamics layer, take 0 (lint aligns against the same one)
                ref = max(grp, key=lambda z: (tuple(z.get("dyn") or (z["vel_lo"], z["vel_hi"])), -z["take"]))
                n = int((proc.pre_ms + 60 + 3 * proc.align_ms) * 1e-3 * snd.sample_rate)
                ra, _ = sf.read(str(cache_a[ref["index"]]), frames=int(1.5 * snd.sample_rate), dtype="float32")
                on = MS.true_onset(ra, snd.sample_rate)  # the same measurement lint makes on the bundle
                for z in grp:
                    if z is ref:
                        continue
                    xa, _ = sf.read(str(cache_a[z["index"]]), frames=on + n, dtype="float32")
                    sh, c = MS.align_shift(ra, xa, snd.sample_rate, proc.align_ms, on)
                    shifts[z["index"]] = sh
                    facts[z["index"]]["align_corr"] = round(c, 3)
                    facts[z["index"]]["align_shift"] = sh
        items = [{"id": z["index"], "root": z["root"], "take": z["take"], "art": z.get("articulation"),
                  "axis": tuple(z.get("dyn") or (z["vel_lo"], z["vel_hi"])),
                  "lufs_max": facts[z["index"]]["lufs_max"] + spec.regions[z["index"]].gain_db,
                  "peak_db": facts[z["index"]]["peak_db"] + spec.regions[z["index"]].gain_db} for z in planned]
        fixed = body_gain if (layer != "body" and proc.link_gain and proc.ladder != "none") else None
        gains, lrep = MS.ladder_gains(items, proc, fixed)
        if layer == "body":
            body_gain = lrep["instrument_gain_db"]
        report[layer] = lrep

        # stage C: final files (cached by source edit + shift + gain)
        enc = proc.encoding
        ext = MS.ENCODINGS[enc][2]
        taken: set = set()
        jobs_c, finals = [], {}
        for z in planned:
            i = z["index"]
            reg = spec.regions[i]
            g = round(gains[i] + reg.gain_db, 3)
            key = MS.cache_key("C", cache_a[i].name, shifts[i], g, enc)
            fp_c = cache_root / "c" / key[:2] / f"{key}{ext}"
            finals[i] = fp_c
            if not (use_cache and fp_c.exists() and fp_c.with_suffix(".json").exists()):
                jobs_c.append((str(cache_a[i]), str(fp_c), shifts[i], g, enc))
        for r in _pool_map(_ms_stage_c, jobs_c, folder, jobs):
            if "error" in r:
                raise RuntimeError(f"{layer} final write: {r['error']}")
        used_files |= {str(p) for p in cache_a.values()} | {str(p) for p in finals.values()}
        tune_fix, tune_warn = _tuning_analysis(layer, planned, facts, spec)
        warnings += tune_warn
        if tune_fix:
            report[layer]["tuning_fixed"] = {str(k): round(v, 1) for k, v in tune_fix.items()}
        for z in planned:
            i = z["index"]
            reg = spec.regions[i]
            f = facts[i]
            sh = shifts[i]
            mz = {"layer": layer, "root": z["root"], "pitched": z["pitched"], "lo": z["lo"], "hi": z["hi"],
                  "vel_lo": z["vel_lo"], "vel_hi": z["vel_hi"], "gain_db": 0.0, "loop": None}
            if "dyn" in z:
                mz["dyn"] = z["dyn"]
            if f.get("loop"):
                lp = f["loop"]
                if lp["start"] - sh > 0:
                    mz["loop"] = {"start": lp["start"] - sh, "end": lp["end"] - sh, "crossfade": lp["crossfade"]}
            tune = 0.0
            if proc.tune in ("source", "smooth"):
                tune = reg.tune_cents + tune_fix.get(i, 0.0)
            elif proc.tune == "detect":
                tune = reg.tune_cents - f["cents"] if "cents" in f else reg.tune_cents
            if not np.isfinite(tune) or abs(tune) > 100:
                raise RuntimeError(
                    f"{layer} region {reg.file}: effective tune_cents {tune:g} exceeds "
                    "the bundle limit ±100 cents; use the actual source root or bake "
                    "the semitone transposition into the sample. Tuning is never silently clipped.")
            if abs(tune) >= 0.05:
                mz["tune_cents"] = round(float(tune), 2)
            if layer == "tail":
                if reg.rt_decay is not None:
                    mz["rt_decay"] = float(reg.rt_decay)
                if reg.rt_min_db is not None:
                    mz["rt_min_db"] = float(reg.rt_min_db)
            if reg.one_shot is not None:
                mz["one_shot"] = reg.one_shot
            if reg.choke_group:
                mz["choke_group"] = reg.choke_group
            if reg.chokes:
                mz["chokes"] = list(reg.chokes)
            if reg.articulation:
                mz["articulation"] = reg.articulation
            if z["take"] or any(r.take for r in spec.regions):
                mz["take"] = z["take"]
            name = MS.zone_file(layer, z, ext, taken)
            out.append({"zone": mz, "file": name, "final": str(finals[i]), "facts": f,
                        "gain": gains[i], "source": reg.file})
            label = f"{layer} n{z['root']}({dsp.note_name(z['root'])}) " + (
                f"dyn {z['dyn'][0]:.2f}-{z['dyn'][1]:.2f}" if "dyn" in z else f"v{z['vel_lo']}-{z['vel_hi']}") + \
                (f" t{z['take']}" if z["take"] else "")
            if f.get("truncated"):
                pass
            if f.get("loop") and f["loop"].get("error_db", -99) > -20:
                warnings.append(f"{label}: loop seam error {f['loop']['error_db']:.1f} dB")
            if f["peak_db"] + gains[i] < -60:
                warnings.append(f"{label}: nearly silent after calibration")
    _ms_cache_hygiene(folder, used_files)
    return out, warnings, report


def _ms_index_dir() -> Path:
    d = library.cache_dir() / "multisample" / "_by_sound"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ms_cache_hygiene(folder: Path, used: set[str]):
    """Edited-region caches are large. Remember which files this sound uses; files it used before
    and no longer uses (and no other sound lists) are removed — they are regenerable cache."""
    idx_dir = _ms_index_dir()
    me = idx_dir / (hashlib.sha1(str(folder).encode()).hexdigest()[:16] + ".json")
    before = set(json.loads(me.read_text()).get("files", [])) if me.exists() else set()
    others: set[str] = set()
    for f in idx_dir.glob("*.json"):
        if f != me:
            try:
                others |= set(json.loads(f.read_text()).get("files", []))
            except (OSError, json.JSONDecodeError):
                pass
    for stale in before - used - others:
        for q in (Path(stale), Path(stale).with_suffix(".json")):
            try:
                q.unlink()
            except OSError:
                pass
    me.write_text(json.dumps({"folder": str(folder), "files": sorted(used)}))


def prune_multisample_cache() -> dict:
    """Remove edited-region cache files that no compiled sound lists (e.g. left by old versions)."""
    root = library.cache_dir() / "multisample"
    listed: set[str] = set()
    for f in _ms_index_dir().glob("*.json"):
        try:
            data = json.loads(f.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        if not Path(data.get("folder", "")).exists():
            f.unlink()
            continue
        listed |= set(data.get("files", []))
    removed, freed = 0, 0
    for sub in ("a", "c"):
        for q in (root / sub).rglob("*") if (root / sub).exists() else []:
            if not q.is_file() or q.suffix == ".json":
                continue
            if str(q) not in listed:
                freed += q.stat().st_size if q.stat().st_nlink == 1 else 0
                q.unlink()
                q.with_suffix(".json").unlink(missing_ok=True)
                removed += 1
    return {"removed": removed, "freed_mb": round(freed / 1e6, 1)}


def _tuning_analysis(layer: str, planned: list[dict], facts: dict, spec) -> tuple[dict, list[str]]:
    """Consistency, not equal temperament: acoustic instruments are stretch-tuned on purpose.
    Finds dynamics layers/takes that disagree with the other recordings of their key (> 8 c) and
    keys that jump off the smooth curve of their neighbours (> 12 c; > 5 c when fixing).
    With tune='smooth' returns the corrections (cents per region index); otherwise warnings."""
    fixes: dict[int, float] = {}
    out: list[str] = []
    if spec.process.tune not in ("source", "smooth") or layer != "body":
        return fixes, out
    smooth = spec.process.tune == "smooth"
    by_root: dict[tuple, list[tuple[dict, float]]] = {}
    for z in planned:
        f = facts[z["index"]]
        if z["pitched"] and "cents" in f:
            played = f["cents"] + spec.regions[z["index"]].tune_cents
            by_root.setdefault((z.get("articulation"), z["root"]), []).append((z, played))
    med = {}
    for (art, root), lst in sorted(by_root.items(), key=lambda kv: (kv[0][0] or "", kv[0][1])):
        m = float(np.median([c for _, c in lst]))
        med[(art, root)] = m
        for z, c in lst:
            if abs(c - m) > 8:
                if smooth:
                    fixes[z["index"]] = fixes.get(z["index"], 0.0) - (c - m)
                else:
                    ax = f"dyn {z['dyn'][0]:.2f}-{z['dyn'][1]:.2f}" if "dyn" in z else f"v{z['vel_lo']}-{z['vel_hi']}"
                    out.append(f"body n{root}({dsp.note_name(root)}) {ax}: {c - m:+.1f} cents from the other layers "
                               f"of its key — check the source or use tune='smooth'")
    for art in dict.fromkeys(a for a, _ in sorted(med, key=lambda k: (k[0] or "", k[1]))):
      roots = sorted(r for a, r in med if a == art)
      for i, r in enumerate(roots):
        nb = [med[(art, q)] for q in roots[max(0, i - 2): i + 3] if q != r]
        if len(nb) < 2:
            continue
        dev = med[(art, r)] - float(np.median(nb))
        if smooth and abs(dev) > 5:
            for z in planned:
                if z["root"] == r and z["pitched"] and z.get("articulation") == art:
                    fixes[z["index"]] = fixes.get(z["index"], 0.0) - dev
        elif not smooth and abs(dev) > 12:
            out.append(f"body n{r}({dsp.note_name(r)}): {dev:+.1f} cents off the tuning curve of its neighbours "
                       f"(tune='smooth' corrects it)")
    return fixes, out


# ---------------------------------------------------------------- the build (worker side)

def _description(folder: Path) -> str:
    p = folder / "notes.md"
    if not p.exists():
        return ""
    para: list[str] = []
    for line in p.read_text(errors="replace").splitlines():
        s = line.strip()
        if s.startswith("#"):
            if para:
                break
            continue
        if not s:
            if para:
                break
            continue
        para.append(s)
    return " ".join(para)


def build_bundle(folder: Path, jobs: int | None = None, use_cache: bool = True) -> dict:
    """Render and write <folder>/build. Runs in the current process (see compile_sound)."""
    from .recipe import load_recipe

    t_start = time.time()
    folder = Path(folder).resolve()
    snd = load_recipe(folder)
    zones = plan_zones(snd)
    rhash = render_hash(folder)
    cache_root = library.cache_dir() / "zones"
    todo, results = [], {}
    for z in zones:
        take_key = f"|t{z.take}" if z.take else ""   # take 0 keeps the single-take key
        if z.dyn is not None:
            take_key += f"|d{z.dyn:.6f}"
        key = hashlib.sha256(f"{rhash}|{z.layer}|{z.note}|{z.velocity}|{z.pitched}|{snd.sample_rate}{take_key}"
                             .encode()).hexdigest()
        cp = cache_root / key[:2] / f"{key}.wav"
        if use_cache and cp.exists() and cp.with_suffix(".json").exists():
            meta = json.loads(cp.with_suffix(".json").read_text())
            results[z.file] = {"zone": asdict(z), "cache": str(cp), "cached": True, **meta}
        else:
            todo.append((asdict(z), str(cp)))

    if todo:
        n_jobs = jobs or min(len(todo), max(1, (os.cpu_count() or 2) - 1), 8)
        if n_jobs <= 1 or len(todo) == 1:
            _init_worker(str(folder))
            outs = [_render_zone(a) for a in todo]
        else:
            import multiprocessing as mp

            ctx = mp.get_context("spawn")
            with ProcessPoolExecutor(n_jobs, mp_context=ctx, initializer=_init_worker,
                                     initargs=(str(folder),)) as ex:
                outs = list(ex.map(_render_zone, todo))
        for o in outs:
            results[o["zone"]["file"]] = o

    errors = [f"{_zone_label(Zone(**r['zone']))}: {r['error']}" for r in results.values() if "error" in r]
    if errors:
        raise RuntimeError("\n".join(errors))

    ms_results, ms_warnings, ms_report = build_multisamples(snd, folder, jobs, use_cache)

    # assemble the bundle in a temp dir, then swap it in
    tmp = folder / f".build.tmp-{os.getpid()}"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir()
    warnings: list[str] = []
    manifest_zones = []
    ir_file = None
    body_lufs = {}
    for z in zones:
        r = results[z.file]
        if r.get("omitted"):
            if z.layer == "body":
                raise RuntimeError(f"{_zone_label(z)}: body returned None (body is required)")
            continue
        from .multisample import link_or_copy

        link_or_copy(Path(r["cache"]), tmp / z.file)
        warnings += r.get("warnings", [])
        if z.layer == "impulse":
            ir_file = z.file
            if r["stats"].get("channels") == 1:
                warnings.append("ir: mono impulse response (stereo gives the Impronta reverb its width)")
            continue
        loop = r.get("loop")
        if z.layer == "body" and "lufs_max" in r["stats"]:
            body_lufs.setdefault(z.velocity, []).append((z.note, r["stats"]["lufs_max"]))
        mz = {
            "layer": z.layer, "file": z.file, "root": z.note, "pitched": z.pitched,
            "lo": z.lo, "hi": z.hi, "vel_lo": z.vel_lo, "vel_hi": z.vel_hi, "gain_db": 0.0,
            "loop": ({k: loop[k] for k in ("start", "end", "crossfade")} if loop else None),
        }
        if snd.takes > 1 and z.layer in ("body", "attack", "tail"):
            mz["take"] = z.take
        if z.dyn is not None:
            mz["dyn"] = [z.dyn_lo, z.dyn_hi]
        manifest_zones.append(mz)
    from .multisample import link_or_copy

    for r in ms_results:
        link_or_copy(Path(r["final"]), tmp / r["file"])
        manifest_zones.append({"layer": r["zone"]["layer"], "file": r["file"], **{k: v for k, v in r["zone"].items()
                                                                                    if k != "layer"}})
    warnings += ms_warnings
    if "body" not in {z["layer"] for z in manifest_zones} and not library.oscillators_on(snd.params):
        raise RuntimeError("the sound has no body zones and no oscillator turned on")
    for v, pairs in body_lufs.items():
        vals = [p[1] for p in pairs]
        if len(vals) > 1 and max(vals) - min(vals) > 8:
            lo = min(pairs, key=lambda p: p[1])
            hi = max(pairs, key=lambda p: p[1])
            warnings.append(f"body v{v}: loudness spreads {max(vals) - min(vals):.1f} LU across roots (momentary max "
                            f"n{lo[0]} {lo[1]} … n{hi[0]} {hi[1]} LUFS) — even it out unless intended")

    from . import licenses

    credits = licenses.read_credits(folder) + list(getattr(snd, "credits_extra", []))
    if credits:
        (tmp / "ATTRIBUTION.md").write_text(licenses.attribution_text(credits))
    fig = folder / "figure.svg"
    has_fig = fig.exists()
    if has_fig:
        shutil.copyfile(fig, tmp / "figure.svg")
    else:
        warnings.append("no figure.svg yet (draw one: see guide('figures'))")

    manifest = {
        "format": "libero.bundle/1",
        "slug": folder.name,
        "title": snd.title,
        "subtitle": snd.subtitle,
        "tags": snd.tags,
        "description": _description(folder),
        "sample_rate": snd.sample_rate,
        "compiled_at": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source_hash": library.source_hash(folder),
        "zones": manifest_zones,
        "ir": ir_file,
        "figure": "figure.svg" if has_fig else None,
        "params": dict(snd.params),
    }
    if snd.accent:
        manifest["accent"] = snd.accent
    if getattr(snd, "articulations_spec", None):
        manifest["articulations"] = [dict(a) for a in snd.articulations_spec]
    perf = dict(getattr(snd, "performance_spec", {}) or {})
    if any("dyn" in z for z in manifest_zones):
        perf.setdefault("dynamics", {})
    if "dynamics" in perf:
        perf["dynamics"] = {"source": "velocity", "velocity_curve": 1.0, **perf["dynamics"]}
    xf_note = None
    if "dynamics" in perf and "crossfade" not in perf["dynamics"]:
        # family default: hard switch for struck/plucked/percussive, 0.3 for phase-aligned sustains
        from . import families, lint

        fam = families.of_tags(snd.tags)
        dflt = families.dyn_crossfade_default(fam)
        if dflt == "aligned":
            cs = lint.dyn_crossfade_correlation(tmp, manifest_zones, 0.3)
            worst = min((c for _, c in cs), default=None)
            if worst is not None and worst >= lint.XF_CORR_MIN:
                dflt, why = 0.3, f"layers phase-aligned (render-vs-raw correlation {worst:.2f} >= {lint.XF_CORR_MIN})"
            else:
                dflt, why = 0, ("layers not phase-aligned (render-vs-raw correlation "
                                f"{worst:.2f} < {lint.XF_CORR_MIN})" if worst is not None else "no layer pairs to measure")
        else:
            why = f"{fam} family default"
        if dflt is not None:
            perf["dynamics"]["crossfade"] = dflt
            xf_note = (f"dynamics crossfade {dflt:g} ({'hard layer switch' if dflt == 0 else 'blend'}): {why}; "
                       f"set sound.performance(dyn_crossfade=...) to override")
    manifest.update(perf)
    if credits:
        manifest["credits"] = credits
        manifest["license"], _cls = licenses.bundle_license(credits)
    if ms_report:
        manifest["meta"] = {"calibration": ms_report}
    if library.bundle_uses_v2(manifest, tmp):
        manifest["format"] = library.BUNDLE_V2
    (tmp / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
    # The plugin's library listing reads only this, never the (possibly huge) zone list.
    (tmp / "info.json").write_text(json.dumps(library.light_info(manifest), ensure_ascii=False))

    build = folder / "build"
    old = folder / f".build.old-{os.getpid()}"
    if build.exists():
        os.replace(build, old)
    os.replace(tmp, build)
    if old.exists():
        shutil.rmtree(old, ignore_errors=True)

    problems = library.validate_bundle(build)
    if problems:
        warnings += [f"bundle check: {p}" for p in problems]

    # A few seconds of the sound for the library's play buttons (never fails the compile).
    try:
        from . import preview as _preview

        pv = _preview.make_preview(folder)
        if pv is None:
            warnings.append("no preview rendered")
    except Exception as e:
        warnings.append(f"no preview (build/preview.m4a): {str(e).splitlines()[0][:160] if str(e) else type(e).__name__}")

    rendered = sum(1 for r in results.values() if not r.get("cached"))
    cached = sum(1 for r in results.values() if r.get("cached"))
    zone_lines = []
    for z in zones:
        r = results[z.file]
        if r.get("omitted"):
            continue
        s = r["stats"]
        extra = ""
        if "cents" in s:
            extra += f" f0 {s['cents']:+.1f}c"
        if r.get("loop"):
            lp = r["loop"]
            extra += f" loop {lp['start']}–{lp['end']} xf {lp['crossfade']} seam {lp.get('error_db', 0):.0f}dB"
        if "lufs_max" in s:
            extra += f" {s['lufs_max']} LUFSmax"
        zone_lines.append(f"  {z.file:<24} {s['seconds']:>6.2f}s pk {s['peak_db']:>6.1f}{extra}")
    if ms_results:
        by_layer: dict[str, list[dict]] = {}
        for r in ms_results:
            by_layer.setdefault(r["zone"]["layer"], []).append(r)
        for layer, rs in by_layer.items():
            roots = sorted({r["zone"]["root"] for r in rs})
            axes = sorted({tuple(r["zone"].get("dyn") or (r["zone"]["vel_lo"], r["zone"]["vel_hi"])) for r in rs})
            takes = 1 + max(r["zone"].get("take", 0) for r in rs)
            secs = sum(r["facts"]["seconds"] for r in rs)
            rep = ms_report.get(layer, {})
            zone_lines.append(f"  {layer}: {len(rs)} recorded zones — {len(roots)} roots "
                              f"{dsp.note_name(roots[0])}..{dsp.note_name(roots[-1])}, {len(axes)} dynamics layers, "
                              f"{takes} take(s), {secs / 60:.1f} min of audio; instrument gain "
                              f"{rep.get('instrument_gain_db', 0):+.1f} dB, {len(rep.get('corrections', {}))} notes evened")
    if xf_note:
        zone_lines.append("  " + xf_note)
    elapsed = time.time() - t_start
    summary = (f"compiled '{folder.name}' → {build}\n"
               f"{len(manifest_zones)} zones{' + ir' if ir_file else ''}; {rendered} files rendered, {cached} from cache, "
               f"{elapsed:.1f} s; "
               + (f"roots {list(snd.roots)}, "
                  + (f"dynamics {list(snd.dynamics)}" if getattr(snd, "dynamics", None) else f"velocities {list(snd.velocities)}")
                  + (f", takes {snd.takes}" if snd.takes > 1 else "") + "; " if snd.layers.keys() & {"body", "attack", "tail"} else "")
               + f"params {manifest['params']}\n" + "\n".join(zone_lines))
    return {"ok": True, "summary": summary, "warnings": warnings, "manifest": manifest, "build": str(build),
            "seconds": round(elapsed, 2)}


# ---------------------------------------------------------------- public entry point

def compile_sound(folder: Path | str, timeout: float = 600.0, jobs: int | None = None,
                  use_cache: bool = True) -> CompileResult:
    """Compile in a subprocess with a hard timeout. Never raises for recipe errors."""
    folder = Path(folder).resolve()
    t0 = time.time()
    cmd = [sys.executable, "-m", "libero.compiler", str(folder)]
    if jobs:
        cmd += ["--jobs", str(jobs)]
    if not use_cache:
        cmd += ["--no-cache"]
    env = dict(os.environ)
    env["PYTHONPATH"] = str(Path(__file__).resolve().parent.parent) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env,
                            cwd=str(folder), start_new_session=True)
    try:
        out, err = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        _kill_group(proc)
        for p in folder.glob(".build.tmp-*"):
            shutil.rmtree(p, ignore_errors=True)
        return CompileResult(False, "", error=f"recipe timed out after {timeout:.0f} s (killed)",
                             seconds=time.time() - t0)
    for line in reversed(out.splitlines()):
        if line.startswith(RESULT_TAG):
            d = json.loads(line[len(RESULT_TAG):])
            if d.get("ok"):
                return CompileResult(True, d["summary"], d["warnings"], d["manifest"], d["build"],
                                     seconds=time.time() - t0)
            return CompileResult(False, "", error=d.get("error"), seconds=time.time() - t0)
    tail = "\n".join((err or out).strip().splitlines()[-25:])
    return CompileResult(False, "", error=f"compiler process exited with {proc.returncode}:\n{tail}",
                         seconds=time.time() - t0)


def _kill_group(proc: subprocess.Popen):
    try:
        os.killpg(proc.pid, _signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        proc.kill()
    proc.wait()


def _main(argv: list[str]) -> int:
    import argparse

    ap = argparse.ArgumentParser(prog="python -m libero.compiler")
    ap.add_argument("folder")
    ap.add_argument("--jobs", type=int, default=None)
    ap.add_argument("--no-cache", action="store_true")
    a = ap.parse_args(argv)
    try:
        res = build_bundle(Path(a.folder), a.jobs, not a.no_cache)
    except Exception as e:  # report, never hang
        from .recipe import RecipeError

        msg = str(e) if isinstance(e, (RecipeError, RuntimeError)) else traceback.format_exc(limit=8)
        res = {"ok": False, "error": msg}
    sys.stdout.write("\n" + RESULT_TAG + json.dumps(res, ensure_ascii=False) + "\n")
    sys.stdout.flush()
    return 0 if res.get("ok") else 1


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
