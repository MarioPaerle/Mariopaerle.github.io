# Designing sounds for Libero

## The quality bar

**Kontakt in the samples, Serum in the controls.** A Libero sound should stand
next to a commercial sampled instrument: real recordings where a real instrument
is named, continuous dynamics, round robins, release samples, phase-aligned and
level-calibrated zones. On top of that, everything a synth player expects stays
live and audible: layers, envelopes, filter, resonators, tape, echo, rooms.

**Route the sound first.** Before the table below, decide genre, role and route (REC / SYN / PM /
HYB) in one line; `guide("genres")` has the decision tree, per-genre cheat-sheets (trap, drill,
boom-bap, pop, R&B, house/techno, EDM, ambient, jazz, rock/metal, orchestral, folk, Latin,
Italian pop/rap), the metrics to match a reference, and the failure modes behind our past bad
sounds. Synth sounds are built with `libero.forge` (`guide("forge")`). Measure defects and source fidelity; do not infer listening preference from those measurements.

Choose the route by what the user asked for:

| request | route | guide |
|---|---|---|
| a real instrument ("piano", "cello", "marimba", "drum kit") | legal multisamples → `import_sfz` / `import_wav_set` → compile → lint | `guide('sampled')` |
| an instrument with no good free recordings (duduk, aulos, e-piano, choir) | hybrid: recorded breath/transient/noise layers over a physical-model body | `guide('physics')` + `guide('sampled')` |
| a synth sound from electronic music (lead, bass, pluck, pad, arp, "vocal-like" lead, a named hook from a track) | **live oscillators** (`osc1_*`, `osc2_*`, sub, LFO, filter envelope `fenv_*`, `flt_mode` incl. Vocale) when the architecture is expressible live; otherwise original procedural synthesis rendered into zones | `guide('sound_design')` §synth |
| a designed sound (texture, cinematic hit, ambience) | recordings processed (freeze, granular, tape, reverse) and/or synthesis | this guide |
| a sound "like" a film score or record | measure the reference (never sample it), then one of the routes above | `skills/libero-slow` |

Recognise synth sounds first. A sound in an electronic track that people describe by
what it resembles ("meow", "vocal", "talking", "laser") is almost always a synth lead
whose filter or formant envelope makes the shape — e.g. a resonant lowpass or Vocale
filter opening and closing over the first 50–300 ms. Measure the reference's pitch
stability, harmonic count, centroid over time and onset sweep, then build it with live oscillators and `fenv_*` where those can express it.
For pitch envelopes, FM or spectral motion missing from the live engine, render
original procedural synthesis into zones instead of simplifying away its identity.
Do not reach for recordings of the thing a synth nickname resembles.

Defaults are always polyphonic with no portamento (`mode="Poli"`, `glide=0`), also for
winds and brass; Mono/Legato and glide are the player's choice.

Synthesis alone is not an option for anything acoustic: a physically modelled
guitar with no recordings under it was judged unusable. When no legal recording
exists for a named acoustic instrument, stop and tell the user what is missing
and what could fill it (a library they own, a private-lane source, a recording
session) instead of shipping a model.
Recordings alone are rarely enough for designed sounds: process and layer them.

You are the sound designer. If auditory listening is unavailable, report that limit.
Numbers and pictures (`analyze`, `spectrogram`, `waveform`, `compare`, `preview`)
verify technical behavior, not musical taste. Incorporate user listening feedback
and compare the construction and musical role of the candidates. A clean lint
report does not establish that a palette is original or full.
This guide is how Libero thinks, the techniques that make sounds feel real,
the checklist before a sound is done, and the workflow.

## Palette identity

Start a collection from different excitations, performers, body structures and
gestures. Do not manufacture variety by changing the vowel, filter or room on the
same construction. Preserve full recorded attacks and evolving spectral detail;
a static cycle is useful for some synths but removes much of a natural source.
Warm sounds can retain rich mids and clear attacks; darkness alone often makes
them empty. Compare candidates with the same musical phrase and loudness, checking
attack, sustain and decay separately. Pure subs deliberately differ from dense
pads: there is no universal spectral fullness target.

## 1. How Libero thinks

A sound is a **recipe** (`sound.py`) that is **compiled offline** into plain
WAV zones. The plugin plays sampled zones and live oscillators. Expensive offline operations belong in
the recipe: convolution, resynthesis, stretching, tuning, loop finding.

Four layers, each optional except the body:

| layer | what it is | rendered | plays |
|---|---|---|---|
| `body` | the pitched, sustaining tone | at every (root, velocity) | pitched from the nearest root, through the amp envelope, looped if you asked |
| `attack` | the transient: pick, hammer, breath, bow bite | once per velocity (`pitched=False`, default) or per root (`pitched=True`) | at note-on, one-shot |
| `tail` | the release event: damper, finger, exhale | like attack | at note-off |
| `air` | the room / noise bed ("rumore di fondo") | once | always looping, with its own AR envelope |

Plus an optional `impulse` (the IR for the *Impronta* reverb), `figure.svg`
and `notes.md`.

**Bake vs leave live.** Bake what defines the instrument's identity and is
expensive or impossible live: the material (body IRs, modal banks), the
excitation, the tuning, velocity timbre, the sustain loop, the breath inside
a voice. Leave live what a player wants to turn: level balance of the four
layers, the envelope, filter, resonators, tape, echo, reverb, width. Put your
intended settings in `sound.defaults(...)` — they become the sound's preset.
Do not bake a big reverb into the body: use `rev_*` (or ship an `impulse`).

**Roots.** Every pitched zone is transposed by the plugin up to half the
distance to the next root. Resampling moves formants and changes decay
speed, so:
- plucked / struck / vocal material: a root every 5–7 semitones;
- smooth synthetic pads: every 7–12 semitones is fine;
- keep the extremes covered: the lowest root plays everything below it.
Use `ctx.register` (0 at the lowest root, 1 at the highest) to make high
strings shorter and brighter, high voices younger, etc.

**Velocities.** Add velocity layers when the *timbre* should change with
force (brighter pick, harder mallet, more breath). If only loudness changes,
one layer is enough: the plugin's `vel_sens` scales level. Typical: `[60, 115]`
or `[45, 90, 125]`. Soft layers should be darker, not just quieter.

## 2. Techniques that make sounds feel real

**A real transient on a synthetic body.** Synthetic bodies are clean; real
instruments start with a mess: a plectrum click, a hammer thump, a bow bite,
breath. Put it in the `attack` layer (so the player can balance it with
`lvl_attack`) or bake it in with `Audio.transient(other, overlap_ms)`. A
good pick is ~5–15 ms: bright bandpassed noise click (2–5 kHz) + a tiny
low thump (100–200 Hz sine sweep down, −10 dB) + optionally a short scrape.
Keep it unpitched unless it rings.

**Excitation defines the instrument more than the resonator.** For
Karplus strings, the pick position (`pick_position`) and brightness change
character more than the decay. For modal banks, the mallet `hardness`
decides which modes speak. Velocity should drive excitation, not only level.

**Physical models for real instrument families.** When the brief names a real
instrument with continuous control (bowed, blown, hammered, struck, a room),
`libero.physics` simulates it: waveguide strings (pluck / felt hammer / bow
friction), single and double reeds, flute, brass lip valve, modal bars, bells,
membranes, bodies and rooms. They are exactly in tune, stable across the range,
and velocity drives the physics (brighter, not just louder). One line:
`ph.render_note(ph.presets.cello(), ctx.note, ctx.vel, 4.0, ctx=ctx)` with
`from libero import physics as ph`. Read `guide('physics')` first: it has a
copy-pasteable `@sound.body` recipe per instrument and a troubleshooting table.

**Convolution with materials.** `synth.impulse_response("wood")` or your own
body IR (a handful of damped modes plus a strong direct impulse) turns a
string into an instrument. Keep the direct path dominant and the mode phases
consistent, or an anti-resonance will swallow some string's fundamental —
check `analyze` on every root: the fundamental should never be > 12 dB below
the strongest partial unless you mean it. `convolve(ir, mix=0.4–0.6)`.

**Noise beds.** A faint, moving noise bed (`air`) is what makes a sampled
instrument sound like it is *in a room*. Pink or `synth.breath` (slow random
swells), low-passed, around −40 to −50 dBFS RMS in the file; the plugin's
`lvl_air` sets the final balance. `air_follow=0` makes it a drone bed.
`Audio.noise_floor(db)` adds a steady bed directly into a sample.

**Tuning samples.** Imported recordings are never exactly in tune.
`tune_to("A3")` detects f0 (YIN + FFT refinement) and resamples to the exact
note; `pitch(st)` shifts by semitones; `stretch(factor)` fixes the duration
back if the shift made it too short. Check `f0` in `analyze` afterwards —
target within ±3 cents.

**Loops.** For sustaining sounds call `sound.loop(body=True, min_seconds=…,
region=(t0, t1))`. The compiler searches rising zero crossings for the best
match and bakes a crossfade. Seam error below −30 dB is inaudible; −20 dB
is the warning line. For synthetic sustains you can do better than search:
**design the loop in**. `synth.LoopGrid(ctx.freq, seconds, ctx.sr)` snaps
every oscillator frequency and LFO rate to a grid that repeats exactly every
`g.samples`; tiled noise (`noise(..., g.seconds).tile(dur)`) repeats too;
`formant(...)` with keyframes that repeat every loop stays periodic. Then
the finder lands on a −100 dB seam. Give stacked voices different start
`phase`s, or their edges line up into a click once per loop.

**Chorus and beating without mono holes.** Two equal partials a few tenths
of a hertz apart cancel completely every beat in a mono sum. Make the twin
weaker (e.g. 0.75 / 0.25) and avoid independent left/right detuning of the
*same* partial; spread voices across the panorama instead.

**Loudness.** Normalise bodies by loudness, not peak:
`normalize_loudness(-16)` (momentary max) makes every root equally loud even
when high notes are spiky and short. Aim body zones at about −15 to −18 LUFS
(momentary max), attacks/tails well below, air around −40 LUFS. The compiler
limits peaks to −1 dBFS and warns when the spread across roots exceeds 8 LU.

**Aliasing.** The oscillators are band-limited, `pitch()` and `resample()`
filter properly, but nonlinearities (`saturate`) create new harmonics: put
filters *after* saturation. The compiler warns when a body has more than
−45 dB of its energy above 18 kHz.

**Determinism.** Always pass `seed=ctx.seed` to anything random. Recompiles
are cached per zone; unchanged zones cost nothing.

## 3. Checklist before a sound is done

1. `compile` returns **no warnings** (or only ones you understand and chose).
2. `preview(slug, "36 48 60 72 84")` — listen with numbers: level even across
   the range, nothing clipping, T60 sensible, f0 on the notes.
3. `spectrogram` of a body zone **at the attack** (`t0=0, t1=0.15`): the
   transient is where you want it, no DC thump, no broadband click unless it
   is the pick.
4. `spectrogram` **of the sustain**: no aliasing (partials folding down from
   the top), no hum below the fundamental, no unwanted noise floor.
5. **Tuning across roots**: the compiler prints cents per zone; every root
   within ±3 cents (chorused sounds: ±5).
6. **Loop seams**: `seam` in the compile summary below −30 dB; for noisy
   loops look at `waveform(slug, 'build/body_…wav', t0, t1)` around the loop
   end and `compare` the regions before start and end.
7. **Loudness**: body zones about −15 to −18 LUFS (momentary max), even
   across roots and sensible across velocities (soft layer 3–8 LU quieter).
8. **Mono**: stereo sounds keep their body in mono (`analyze` → stereo
   correlation > 0.3; no deep periodic dips in the mono envelope).
9. `figure_view` — the figure passes the checks and reads from the sound.
10. `notes.md` — first paragraph is the description shown in the library.

## 4. Workflow

1. **Understand the brief.** Name the instrument's physics: what excites it,
   what resonates, what space it lives in, what makes it *this* sound.
2. `sound_new(slug, template, title, subtitle)` — pick the closest template
   and read its `sound.py`.
3. **Gather or synthesise samples.** `synth_generate` for single primitives,
   `workbench` for anything composite (a body IR, a pick, a breath), `sample_*`
   tools for cutting, tuning, layering, convolving; `freesound_search` /
   `freesound_download` or `sample_import` for real recordings (licences are
   recorded in `samples/ATTRIBUTION.md`; prefer CC0 / CC BY).
4. **Iterate with analysis.** After every change: `analyze`, and a
   `spectrogram` of the part you changed. `compare` before/after.
5. **Write the recipe** with `sound_write(slug, "sound.py", …)`. Keep samples
   small and let the recipe do per-root work.
6. `compile` → fix every warning.
7. `preview` → check the rendered result through the real engine (levels,
   envelope, reverb). Adjust `defaults(...)`.
8. **Push to the plugin** if one is running: `plugin_load`, `plugin_play`
   a few notes, `plugin_set_params` to audition settings, `plugin_status`
   to tell the user what you are doing.
9. **Figure**: read `guide('figures')`, draw `figure.svg`, check it with
   `figure_view` and improve it until it reads from the sound.
10. **Notes**: `notes.md` — intent, references, what you tried and why.
11. **Ask the user** whether to keep it. Only then `sound_save(slug)`.
    Never discard a sketch you did not create in this session without asking.

## 5. Recipe skeleton

```python
from libero import Sound, synth

sound = Sound(title="…", subtitle="…", tags=[…], roots=[36, 43, 50, 57, 64, 71, 78, 85],
              velocities=[60, 115], sample_rate=48000, accent="#b5874e")

@sound.body
def body(ctx):
    s = synth.karplus(ctx.freq, dur=5 - 2 * ctx.register, bright=0.3 + 0.5 * ctx.vel,
                      sr=ctx.sr, seed=ctx.seed)
    return s.convolve(ctx.load("body_ir.wav"), mix=0.5).fit(s.duration).normalize_loudness(-16)

@sound.attack
def attack(ctx):
    return ctx.load("pick.wav")

@sound.air
def air(ctx):
    return synth.breath(8.0, sr=ctx.sr, seed=1, brightness=0.2).normalize_rms(-44)

sound.defaults(amp_release=600, rev_mode="Cappella", rev_mix=0.2)
```

The exact API of every function is in `guide('recipe_api')`; parameter ids
and ranges in `params_reference()`.

### Realism for played instruments: takes and legato

- `Sound(..., takes=3)` renders every body/attack/tail zone three times with a
  different `ctx.seed` (and `ctx.take` = 0..2). The plugin picks a take per
  note-on without repeating the previous one, so repeated notes stop sounding
  like a machine gun. Make takes differ the way a player does — a few cents of
  pitch, breath noise, onset timing, brightness — not by level alone. Attack
  and tail follow the body's take when they have as many takes. Cost: N× the
  render time; each (zone, take) is cached on its own, and take 0 is the
  single-take zone, so raising `takes` only renders the new ones.
- For monophonic instruments (winds, voice, bowed lines) set
  `defaults(mode="Legato")`: one voice, last-note priority with note memory;
  overlapping notes slur (no envelope retrigger, no attack layer, the pitch
  glides over max(`glide`, 25 ms) and the body crossfades to the new key's
  zone). `mode="Mono"` retriggers every note on a single voice.
- The air bed is unpitched: `tune`/`fine` do not move it.

When balancing layers with `base.mix(a, b, gains_db=[ga, gb])`, those gains apply only to `a` and `b`. Set the base gain before mixing. Extra gain entries do not affect any signal; do not hide the recorded source by assuming the list includes the base. Check each component and the mixed result.
