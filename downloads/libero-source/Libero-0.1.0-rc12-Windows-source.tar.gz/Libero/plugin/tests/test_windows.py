"""Windows build checks: native engine, DLL loading, imports and embedded WebView2 UI."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = HERE / "out/windows"


def run(command, name, env=None, timeout=300):
    result = subprocess.run([str(item) for item in command], env=env, capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=timeout)
    (OUT / (name + ".log")).write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"{name} failed ({result.returncode}):\n{result.stdout[-3000:]}\n{result.stderr[-1000:]}")
    return result.stdout


def main():
    os.environ.setdefault("PYTHONUTF8", "1")
    build = Path(sys.argv[1]).resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    fixtures = HERE / "fixtures"
    fixtures.mkdir(exist_ok=True)
    options = {
        "test-tone": [], "test-noir": ["--no-ir", "--rate", "48000", "--pads"],
        "test-takes": ["--takes", "3"], "test-dyn": ["--dyn", "3", "--rt-decay", "12"],
        "test-dyn-hard": ["--dyn", "3", "--dyn-xf", "0"],
        "test-dyn-hard-cc": ["--dyn", "3", "--dyn-xf", "0", "--dyn-source", "cc1"],
        "test-dyn-attack": ["--dyn", "3", "--dyn-attack", "3"], "test-osc": ["--osc-only"],
        "test-onset": ["--onset-ms", "20", "--rate", "48000"],
        "test-onset-ref": ["--onset-ms", "20", "--onset-undeclared", "--rate", "48000"],
        "test-human": ["--humanize", "5,4,1", "--tune-cents", "30"],
        "test-rr": ["--takes", "3", "--rr-reset", "300"],
        "test-streaming": ["--rate", "48000", "--dyn", "3", "--dyn-xf", "0", "--no-ir", "--no-loops"],
        "test-drums": ["--drums"], "test-artic": ["--artic"],
    }
    for name, flags in options.items():
        run([sys.executable, HERE / "make_test_bundle.py", fixtures / name, *flags], name)
    art = build / "plugin"
    render = art / "libero_render_artefacts/Release/libero-render.exe"
    host = art / "libero_host_test_artefacts/Release/libero-host-test.exe"
    failures = []
    for name, command in [
        ("renderer", [sys.executable, HERE / "test_render.py", render, fixtures]),
        ("oscillators", [sys.executable, HERE / "test_osc.py", render, fixtures]),
        ("rpn-legato", [art / "libero_rpn_test_artefacts/Release/libero-rpn-test.exe"]),
        ("socket", [sys.executable, HERE / "test_socket.py", host, fixtures / "test-tone"]),
        ("sample-editor", [sys.executable, HERE / "test_sample_editor.py", host, fixtures / "test-artic"]),
        ("bank-collection", [sys.executable, HERE / "test_bank_collection.py", host, fixtures / "test-tone"]),
    ]:
        try:
            run(command, name)
        except RuntimeError as error:
            failures.append(str(error))
    module = art / "Libero_artefacts/Release/VST3/Libero.vst3/Contents/x86_64-win/Libero.vst3"
    dll = ctypes.CDLL(str(module))
    dll.GetPluginFactory.restype = ctypes.c_void_p
    assert dll.GetPluginFactory(), "VST3 factory could not be created"

    with tempfile.TemporaryDirectory(prefix="libero-windows-") as temporary:
        directory = Path(temporary) / "Café sounds"
        directory.mkdir()
        env = os.environ.copy()
        env["LIBERO_HOME"] = str(directory / "library")
        run([host, "--stream-validation-check", fixtures / "test-streaming"], "stream-validation",
            env={**env, "LIBERO_SAMPLE_STREAMING": "1"})
        run([host, "--sample-cache-check", fixtures / "test-tone"], "sample-cache", env=env)
        run([host, "--loading-cache-check", fixtures / "test-tone"], "loading-cache",
            env={**env, "LIBERO_DISABLE_SAMPLE_CACHE": "1"})
        run([host, "--editor-size-check"], "editor-size", env=env)
        run([host, "--initial-load-check", fixtures / "test-tone"], "initial-load", env=env)
        source = fixtures / "test-tone/build"

        def pack(version, broken=False):
            target = directory / ("Piano é " + version + ".liberobank")
            with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("windows-bank/bank.json", json.dumps({
                    "format": "libero.bank/1", "slug": "windows-bank", "title": "Windows test",
                    "version": version, "subtitle": "", "description": "", "author": "", "license": "CC0",
                }))
                for file in source.rglob("*"):
                    if file.is_file():
                        name = "windows-bank/test-tone/build/" + file.relative_to(source).as_posix()
                        archive.writestr(name, b"broken" if broken and file.suffix == ".wav" else file.read_bytes())
            return target

        def call(operation, archive):
            result = subprocess.run([str(host), operation, str(archive)], env=env, capture_output=True,
                                    text=True, encoding="utf-8", errors="replace", timeout=120)
            reply = json.loads(result.stdout)
            assert (result.returncode == 0) == bool(reply["ok"]), reply
            return reply

        first = pack("1.0.0")
        assert call("--inspect-bank", first)["action"] == "install"
        assert call("--import-bank", first)["ok"]
        assert call("--import-bank", first)["code"] == "SAME_VERSION"
        assert call("--import-bank", pack("0.9.0"))["code"] == "DOWNGRADE"
        broken = call("--import-bank", pack("2.0.0", broken=True))
        assert not broken["ok"]
        installed = directory / "library/banks/windows-bank"
        assert json.loads((installed / "bank.json").read_text())["version"] == "1.0.0"
        update = pack("2.0.0")
        assert call("--inspect-bank", update)["action"] == "update"
        assert call("--import-bank", update)["ok"]
        for file in source.rglob("*"):
            if file.is_file():
                copied = installed / "test-tone/build" / file.relative_to(source)
                assert hashlib.sha256(file.read_bytes()).digest() == hashlib.sha256(copied.read_bytes()).digest()
        for name, entries in {
            "traversal": [("../escape", "x")],
            "case-collision": [("bank/bank.json", "{}"), ("BANK/BANK.JSON", "{}")],
        }.items():
            archive = directory / (name + ".liberobank")
            with zipfile.ZipFile(archive, "w") as z:
                for path, text in entries:
                    z.writestr(path, text)
            assert call("--inspect-bank", archive)["code"] == "UNSAFE_ARCHIVE"

        ui_home = directory / "ui-home"
        bank = ui_home / "banks/test-bank"
        bank.mkdir(parents=True)
        (bank / "bank.json").write_text(json.dumps({"format": "libero.bank/1", "slug": "test-bank",
            "title": "Banco di prova", "version": "1.0.0", "subtitle": "", "description": "",
            "author": "", "license": "CC0", "figure": None}))
        preview = ui_home / "sounds/test-preview/build"
        shutil.copytree(source, preview)
        run([render, "--sound", str(preview.parent), "--out", str(preview / "preview.wav"),
             "--notes", "60:0:1:100", "--tail", ".5"], "preview")
        env["LIBERO_HOME"] = str(ui_home)
        output = run([host, "--ui-check", fixtures / "test-tone", fixtures / "test-noir",
                      fixtures / "test-artic"], "webview2", env=env, timeout=180)
        ui = json.loads(output.splitlines()[-1])
        (OUT / "ui.json").write_text(json.dumps(ui, indent=2), encoding="utf-8")
        assert ui["juce"] == "object" and ui["sliders"] == 96 and ui["combos"] == 14
        for field in ["reload", "reset", "saveAs", "inspectSame", "importSame", "exportBank",
                      "collectionInspect", "collectionSkip", "collectionCleanup", "collectionExpired",
                      "returnToSound", "previewPlays", "previewStops", "noOscUi", "done"]:
            assert ui["calls"].get(field) is True, (field, ui)
        assert ui["artic"]["ok"] is True
    (OUT / "summary.json").write_text(json.dumps({"status": "FAIL" if failures else "PASS", "platform": "Windows x64",
        "failures": failures,
        "checks": ["renderer", "oscillators", "RPN/legato", "agent socket", "sample editing", "VST3 factory",
                   "Unicode paths", "bank install/update/downgrade/failure", "unsafe ZIP", "batch bank import", "WebView2 UI"]}, indent=2))
    if failures:
        raise RuntimeError("\n\n".join(failures))
    print("Windows native checks: PASS")


if __name__ == "__main__":
    main()
