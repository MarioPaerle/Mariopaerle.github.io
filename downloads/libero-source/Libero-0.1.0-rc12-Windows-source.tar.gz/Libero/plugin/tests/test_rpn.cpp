// Native MIDI-to-audio regression, linked against the exact offline engine objects.
#include "Engine.h"
#include <iostream>
#include <vector>
#include <cmath>
#include <complex>

static int failed=0;
static void check(bool ok,const char* label) {std::cout<<(ok ? "ok " : "FAIL ")<<label<<'\n';failed+=!ok;}
using Msg=juce::MidiMessage;
static Msg cc(int ch,int c,int value){return Msg::controllerEvent(ch,c,value);}
static std::vector<Msg> rpn(int ch,int semis,int cents=0)
{return {cc(ch,100,0),cc(ch,101,0),cc(ch,6,semis),cc(ch,38,cents)};}
struct Rig
{
    libero::Engine engine;
    Rig()
    {
        libero::ParamSet p;p.setChoice("osc1_wave","Seno");p.set("osc1_level",-12);
        p.set("rev_mix",0);p.set("amp_attack",0);p.set("amp_sustain",1);p.set("vel_sens",0);
        p.set("osc_drift",0);p.set("humanize",0);p.set("glide",0);p.set("amp_release",1);
        engine.setParameters(p);engine.prepare(48000,256);
    }
    double audio(std::vector<Msg> messages)
    {
        std::vector<float> x(28800),r(28800);juce::MidiBuffer midi;
        for(auto& m:messages)midi.addEvent(m,0);
        for(int i=0;i<(int)x.size();i+=256)
        {
            engine.process(x.data()+i,r.data()+i,std::min(256,(int)x.size()-i),midi);midi.clear();
        }
        std::vector<double> crosses;
        for(size_t i=4801;i<x.size();++i)if(x[i-1]<=0 && x[i]>0)
            crosses.push_back((double)(i-1)-x[i-1]/(x[i]-x[i-1]));
        return crosses.size()>2 ? 48000*static_cast<double>(crosses.size()-1)/(crosses.back()-crosses.front()) : 0;
    }
    void pitch(std::vector<Msg> msgs,float semitones,const char* label)
    {
        double hz=audio(std::move(msgs));double measured=hz>0 ? 12*std::log2(hz/440) : -999;
        std::cout<<"  measured "<<measured<<" semitones, target "<<semitones<<'\n';
        check(std::abs(measured-semitones)<.005,label);
    }
};

static std::vector<float> formantRender(int note, int wheel)
{
    libero::Engine engine;
    libero::ParamSet p;
    p.setChoice("osc1_wave","Sega"); p.set("osc1_level",-12);
    p.setChoice("flt_mode","Vocale"); p.set("flt_cutoff",900); p.set("flt_reso",.35f);
    p.set("flt_key",0); p.set("flt_dyn",0); p.set("lfo_pitch",0);
    p.set("amp_attack",0); p.set("amp_sustain",1); p.set("amp_release",1);
    p.set("vel_sens",0); p.set("rev_mix",0); p.set("osc_drift",0);
    engine.setParameters(p); engine.prepare(48000,256);
    std::vector<float> x(57600), r(57600);
    juce::MidiBuffer midi;
    midi.addEvent(Msg::pitchWheel(1,wheel),0);
    midi.addEvent(Msg::noteOn(1,note,(juce::uint8)100),0);
    for(int i=0;i<(int)x.size();i+=256)
    {
        engine.process(x.data()+i,r.data()+i,std::min(256,(int)x.size()-i),midi);
        midi.clear();
    }
    return x;
}

static double toneAmp(const std::vector<float>& x,double hz)
{
    constexpr double sr=48000.0;
    const size_t begin=9600,end=48000;
    std::complex<double> acc{};
    for(size_t i=begin;i<end;++i)
    {
        const auto phase=2.0*juce::MathConstants<double>::pi*hz*(double)(i-begin)/sr;
        acc+=(double)x[i]*std::complex<double>(std::cos(phase),-std::sin(phase));
    }
    return 2.0*std::abs(acc)/(double)(end-begin);
}

static void checkFixedFormantsUnderPitchBend()
{
    const double f0=440.0*std::exp2((48.0-69.0)/12.0)*std::exp2(2.0/12.0);
    const double pairLow=f0*2.0, pairHigh=f0*4.0;
    const auto low=formantRender(48,16383);  // +2 semitones
    const auto high=formantRender(60,16383); // +2 semitones, exactly one octave above
    const auto ratioLow=toneAmp(low,pairHigh)/std::max(1e-12,toneAmp(low,pairLow))*2.0;
    const auto ratioHigh=toneAmp(high,pairHigh)/std::max(1e-12,toneAmp(high,pairLow))*2.0;
    const auto deltaDb=20.0*std::log10(std::max(1e-12,ratioLow)/std::max(1e-12,ratioHigh));
    std::cout<<"  fixed-Hz harmonic response ratio "<<ratioLow<<" vs "<<ratioHigh<<" ("<<deltaDb<<" dB)\n";
    check(std::abs(deltaDb)<1.0,"Vocale formant profile stays at fixed Hz under note transposition and pitch wheel");
}
int main()
{
    Rig a;
    a.pitch({Msg::noteOn(1,69,(juce::uint8)100),Msg::pitchWheel(1,0)},-2,"default negative bend remains -2");
    a.pitch({Msg::pitchWheel(1,16383)},2*8191.f/8192,"default positive bend remains compatible");
    auto m=rpn(1,12);m.push_back(Msg::pitchWheel(1,0));a.pitch(m,-12,"LMMS RPN0 semitone range reaches -12");
    a.pitch({Msg::pitchWheel(1,16383)},12*8191.f/8192,"RPN0 positive end follows 14-bit wheel value");
    a.pitch({cc(1,38,50)},12.5f*8191.f/8192,"LSB cents immediately update an already held bend");
    a.pitch({cc(1,6,7)},7.5f*8191.f/8192,"MSB update retains independent cents");
    a.pitch({cc(1,101,0),cc(1,100,1),cc(1,6,30),cc(1,38,90)},7.5f*8191.f/8192,"unknown RPN never changes sensitivity");
    a.pitch({cc(1,100,0),cc(1,101,0),cc(1,99,1),cc(1,6,30)},7.5f*8191.f/8192,"NRPN MSB cancels registered data entry");
    a.pitch({cc(1,100,0),cc(1,6,30)},7.5f*8191.f/8192,"partial selection after NRPN cannot reuse stale RPN half");
    a.pitch({cc(1,101,0),cc(1,98,1),cc(1,38,90)},7.5f*8191.f/8192,"NRPN LSB also cancels registered data entry");
    a.pitch({cc(1,100,127),cc(1,101,127),cc(1,6,30),cc(1,38,90)},7.5f*8191.f/8192,"RPN Null ignores following data entry");
    a.pitch(rpn(2,24,25),7.5f*8191.f/8192,"another channel range does not retune active wheel");
    a.pitch({cc(1,100,0),cc(2,101,0),cc(1,6,30),cc(2,100,127),cc(2,6,30)},7.5f*8191.f/8192,"interleaved channel selection cannot form RPN0 across channels");
    a.pitch({Msg::pitchWheel(2,0)},-24.25,"wheel uses its channel's independently stored range");
    a.pitch({Msg::pitchWheel(1,0)},-7.5,"switching wheel channel returns to that channel's range");
    a.pitch({cc(1,121,0),Msg::noteOn(1,69,(juce::uint8)100)},0,"CC121 centres the previously bent wheel");
    a.pitch({Msg::pitchWheel(1,0)},-7.5,"CC121 retains negotiated RPN range");
    a.pitch({cc(1,6,30)},-7.5,"CC121 cleared the RPN data entry selection");
    a.engine.reset();
    a.pitch({Msg::noteOn(1,69,(juce::uint8)100)},0,"engine reset clears a held bend");
    a.pitch({cc(1,6,30),Msg::pitchWheel(1,0)},-2,"engine reset restores default range and null selection");
    a.pitch({Msg::pitchWheel(2,0)},-2,"engine reset clears other channels too");
    a.pitch(rpn(2,0),0,"zero bend sensitivity is a valid negotiated value");
    checkFixedFormantsUnderPitchBend();
    std::cout<<failed<<" failures\n";return failed ? 1 : 0;
}
