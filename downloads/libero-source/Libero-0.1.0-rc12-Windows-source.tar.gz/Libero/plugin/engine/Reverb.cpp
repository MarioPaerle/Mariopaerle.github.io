#include "Reverb.h"

namespace libero
{

using namespace dsp;

namespace
{
    void hadamard (float* v, int n) noexcept
    {
        for (int h = 1; h < n; h <<= 1)
            for (int i = 0; i < n; i += h << 1)
                for (int j = i; j < i + h; ++j)
                {
                    const auto a = v[j], b = v[j + h];
                    v[j] = a + b;
                    v[j + h] = a - b;
                }

        const auto s = 1.0f / std::sqrt ((float) n);

        for (int i = 0; i < n; ++i)
            v[i] *= s;
    }

    float msToSamples (float ms, float sr) noexcept { return ms * 0.001f * sr; }
}

//==============================================================================
void FdnReverb::prepare (float sr, const FdnConfig& c)
{
    cfg = c;
    sampleRate = sr;
    modDepth = msToSamples (cfg.modDepthMs, sr);

    const auto n = cfg.lines;

    for (int k = 0; k < n; ++k)
    {
        baseSamples[(size_t) k] = msToSamples (cfg.delayMs[(size_t) k], sr);
        lines[(size_t) k].allocate ((int) (baseSamples[(size_t) k] * cfg.sizeMax + 2.0f * modDepth) + 16);

        innerSamples[(size_t) k] = 0.0f;

        if (cfg.innerMs > 0.0f)
        {
            // Spread inner allpass delays over roughly an octave, mutually prime-ish.
            innerSamples[(size_t) k] = std::round (msToSamples (cfg.innerMs * (0.7f + 0.61f * (float) ((k * 7) % n) / (float) n), sr));
            inner[(size_t) k].allocate ((int) innerSamples[(size_t) k] + 4);
            inner[(size_t) k].g = cfg.innerG;
        }

        const auto t = (float) ((k * 5) % n) / (float) std::max (1, n - 1);
        const auto rate = lerp (cfg.modRateMin, cfg.modRateMax, t);
        rotC[(size_t) k] = std::cos (kTwoPi * rate / sr);
        rotS[(size_t) k] = std::sin (kTwoPi * rate / sr);

        signL[(size_t) k]  = (k & 1) ? -1.0f : 1.0f;
        signR[(size_t) k]  = (k & 2) ? -1.0f : 1.0f;
        signIn[(size_t) k] = (k & 4) ? -1.0f : 1.0f;
    }

    for (int j = 0; j < cfg.diffusers; ++j)
    {
        const auto maxD = (int) msToSamples (cfg.diffMs[(size_t) j] * 1.07f * 1.2f, sr) + 8;
        diffL[(size_t) j].allocate (maxD);
        diffR[(size_t) j].allocate (maxD);
        diffL[(size_t) j].g = diffR[(size_t) j].g = cfg.diffG;
    }

    if (cfg.erTaps > 0)
    {
        erLine.allocate ((int) msToSamples (60.0f * cfg.sizeMax, sr) + 16);

        for (int j = 0; j < cfg.erTaps; ++j)
        {
            const auto t = 3.1f + 3.37f * (float) j + 1.3f * std::sin ((float) j * 2.7f);
            erTimeMs[(size_t) j] = t;
            const auto g = 0.8f * std::exp (-t / 30.0f) * ((j % 5 == 3) ? -1.0f : 1.0f);
            const auto side = (j % 2 == 0) ? 0.8f : 0.35f;
            erGainL[(size_t) j] = g * side;
            erGainR[(size_t) j] = g * (1.15f - side);
        }
    }

    sizeScale.setTimeMs (250.0f, sr);
    levelComp.setTimeMs (50.0f, sr);
    outNorm = cfg.gain / std::sqrt ((float) n);
    erMix = std::sqrt ((float) n);   // early reflections bypass the 1/sqrt(N) tap normalisation
    currentDamp = -1.0f;
    reset();
}

void FdnReverb::reset() noexcept
{
    for (int k = 0; k < cfg.lines; ++k)
    {
        lines[(size_t) k].reset();

        if (cfg.innerMs > 0.0f)
            inner[(size_t) k].reset();

        z[(size_t) k] = 0.0f;
        const auto ph = kTwoPi * 0.618034f * (float) k;
        oscC[(size_t) k] = std::cos (ph);
        oscS[(size_t) k] = std::sin (ph);
    }

    for (int j = 0; j < cfg.diffusers; ++j)
    {
        diffL[(size_t) j].reset();
        diffR[(size_t) j].reset();
    }

    if (cfg.erTaps > 0)
        erLine.reset();

    outLpL.reset();
    outLpR.reset();
    sizeScale.reset (sizeScale.target > 0.0f ? sizeScale.target : 1.0f);
    levelComp.reset (levelComp.target);
}

void FdnReverb::set (float size, float decaySeconds, float damp) noexcept
{
    const auto scale = lerp (cfg.sizeMin, cfg.sizeMax, clampf (size, 0.0f, 1.0f));
    sizeScale.target = scale;

    const auto t60 = std::max (0.05f, decaySeconds * cfg.decayScale);
    const auto alpha = clampf (std::exp2 (-4.5f * clampf (damp, 0.0f, 1.0f)) * cfg.hfScale, 0.02f, 1.0f);
    float energy = 0.0f;

    for (int k = 0; k < cfg.lines; ++k)
    {
        const auto d = baseSamples[(size_t) k] * scale + innerSamples[(size_t) k];
        const auto g = std::pow (10.0f, -3.0f * d / (t60 * sampleRate));
        const auto gHf = std::pow (g, 1.0f / alpha);
        gain[(size_t) k] = g;
        pole[(size_t) k] = (g - gHf) / (g + gHf);
        energy += 1.0f / (1.0f - g * g);
    }

    // Steady-state loudness grows only gently with decay (~ T60^0.25) instead of ~ sqrt(T60),
    // so short and long settings of every room sit at comparable levels.
    const auto amplitude = std::sqrt (energy / (float) cfg.lines);
    levelComp.target = std::pow (t60, 0.25f) / amplitude;

    if (cfg.outLowpassHz > 0.0f && std::abs (damp - currentDamp) > 1.0e-6f)
    {
        currentDamp = damp;
        outLpL.setHz (cfg.outLowpassHz * std::exp2 (-1.5f * damp), sampleRate);
        outLpR.a = outLpL.a;
    }
}

void FdnReverb::process (const float* inL, const float* inR, float* outL, float* outR, int n) noexcept
{
    const auto N = cfg.lines;
    std::array<float, kMax> v {};

    for (int k = 0; k < N; ++k)
    {
        // Keep the quadrature oscillators on the unit circle.
        const auto m = oscC[(size_t) k] * oscC[(size_t) k] + oscS[(size_t) k] * oscS[(size_t) k];
        const auto fix = 1.5f - 0.5f * m;
        oscC[(size_t) k] *= fix;
        oscS[(size_t) k] *= fix;
    }

    for (int i = 0; i < n; ++i)
    {
        const auto s = sizeScale.next();
        const auto diffScale = 0.6f + 0.5f * (s / cfg.sizeMax);
        auto xl = inL[i], xr = inR[i];

        float erL = 0.0f, erR = 0.0f;

        if (cfg.erTaps > 0)
        {
            erLine.push (0.5f * (xl + xr));

            for (int j = 0; j < cfg.erTaps; ++j)
            {
                const auto tap = erLine.readLinear (msToSamples (erTimeMs[(size_t) j], sampleRate) * s);
                erL += tap * erGainL[(size_t) j];
                erR += tap * erGainR[(size_t) j];
            }

            xl += 0.5f * erL;
            xr += 0.5f * erR;
        }

        for (int j = 0; j < cfg.diffusers; ++j)
        {
            const auto d = msToSamples (cfg.diffMs[(size_t) j], sampleRate) * diffScale;
            xl = diffL[(size_t) j].tick (xl, d);
            xr = diffR[(size_t) j].tick (xr, d * 1.07f);
        }

        float yl = 0.0f, yr = 0.0f;

        for (int k = 0; k < N; ++k)
        {
            const auto c = oscC[(size_t) k], sn = oscS[(size_t) k];
            oscC[(size_t) k] = c * rotC[(size_t) k] - sn * rotS[(size_t) k];
            oscS[(size_t) k] = sn * rotC[(size_t) k] + c * rotS[(size_t) k];

            const auto d = baseSamples[(size_t) k] * s + modDepth * (1.0f + oscS[(size_t) k]);
            const auto y = lines[(size_t) k].readLinear (d - 1.0f);

            // Output taps come straight off the delay lines (Jot): the loop attenuation only
            // applies to what is fed back.
            yl += signL[(size_t) k] * y;
            yr += signR[(size_t) k] * y;

            auto& zk = z[(size_t) k];
            zk = gain[(size_t) k] * (1.0f - pole[(size_t) k]) * y + pole[(size_t) k] * zk;

            v[(size_t) k] = cfg.innerMs > 0.0f ? inner[(size_t) k].tickInt (zk, (int) innerSamples[(size_t) k]) : zk;
        }

        hadamard (v.data(), N);

        for (int k = 0; k < N; ++k)
        {
            const auto x = (k & 1) ? xr : xl;
            lines[(size_t) k].push (sanitize (v[(size_t) k] + x * signIn[(size_t) k]));
        }

        const auto comp = levelComp.next();
        yl = (yl * comp + erL * erMix) * outNorm;
        yr = (yr * comp + erR * erMix) * outNorm;

        if (cfg.outLowpassHz > 0.0f)
        {
            yl = outLpL.tick (yl);
            yr = outLpR.tick (yr);
        }

        outL[i] = yl;
        outR[i] = yr;
    }
}

//==============================================================================
namespace plate
{
    constexpr float kRate = 29761.0f;
    constexpr float in1 = 142, in2 = 107, in3 = 379, in4 = 277;
    constexpr float apL1 = 672, dL1 = 4453, apL2 = 1800, dL2 = 3720;
    constexpr float apR1 = 908, dR1 = 4217, apR2 = 2656, dR2 = 3163;
    constexpr float excursion = 16;
    constexpr float loopTotal = apL1 + dL1 + apL2 + dL2 + apR1 + dR1 + apR2 + dR2;
    constexpr float sizeMin = 0.45f, sizeMax = 1.25f;
}

void PlateReverb::prepare (float sr)
{
    sampleRate = sr;
    k = sr / plate::kRate;

    const auto big = [this] (float d) { return (int) (d * k * plate::sizeMax) + 32; };

    inDiff[0].allocate ((int) (plate::in1 * k) + 4);
    inDiff[1].allocate ((int) (plate::in2 * k) + 4);
    inDiff[2].allocate ((int) (plate::in3 * k) + 4);
    inDiff[3].allocate ((int) (plate::in4 * k) + 4);
    inDiff[0].g = inDiff[1].g = 0.75f;
    inDiff[2].g = inDiff[3].g = 0.625f;

    modApL.allocate (big (plate::apL1 + plate::excursion));
    modApR.allocate (big (plate::apR1 + plate::excursion));
    apL.allocate (big (plate::apL2));
    apR.allocate (big (plate::apR2));
    modApL.g = modApR.g = -0.7f;
    apL.g = apR.g = 0.5f;

    d1L.allocate (big (plate::dL1));
    d2L.allocate (big (plate::dL2));
    d1R.allocate (big (plate::dR1));
    d2R.allocate (big (plate::dR2));

    bandwidth.setHz (11000.0f, sr);
    sizeScale.setTimeMs (250.0f, sr);
    reset();
}

void PlateReverb::reset() noexcept
{
    for (auto& a : inDiff)
        a.reset();

    for (auto* a : { &modApL, &modApR, &apL, &apR })
        a->reset();

    for (auto* d : { &d1L, &d2L, &d1R, &d2R })
        d->reset();

    bandwidth.reset();
    dampL.reset();
    dampR.reset();
    tankL = tankR = 0.0f;
    lfoPhase = 0.0;
    sizeScale.reset (sizeScale.target > 0.0f ? sizeScale.target : 1.0f);
}

void PlateReverb::set (float size, float decaySeconds, float damp) noexcept
{
    const auto s = lerp (plate::sizeMin, plate::sizeMax, clampf (size, 0.0f, 1.0f));
    sizeScale.target = s;

    const auto loopSeconds = plate::loopTotal * s / plate::kRate;
    decayGain = std::min (0.985f, std::pow (10.0f, -3.0f * loopSeconds / (4.0f * std::max (0.05f, decaySeconds))));

    dampL.setHz (16000.0f * std::exp2 (-4.2f * clampf (damp, 0.0f, 1.0f)), sampleRate);
    dampR.a = dampL.a;
}

void PlateReverb::process (const float* inL, const float* inR, float* outL, float* outR, int n) noexcept
{
    const auto lfoInc = 1.0 / sampleRate;

    for (int i = 0; i < n; ++i)
    {
        const auto s = sizeScale.next() * k;

        auto x = bandwidth.tick (0.5f * (inL[i] + inR[i]));
        x = inDiff[0].tickInt (x, (int) (plate::in1 * k));
        x = inDiff[1].tickInt (x, (int) (plate::in2 * k));
        x = inDiff[2].tickInt (x, (int) (plate::in3 * k));
        x = inDiff[3].tickInt (x, (int) (plate::in4 * k));

        lfoPhase += lfoInc;
        if (lfoPhase >= 1.0) lfoPhase -= 1.0;
        const auto lfo = (float) std::sin (kTwoPi * lfoPhase);
        const auto lfo2 = (float) std::cos (kTwoPi * lfoPhase * 1.0);

        // Left half of the tank.
        auto a = modApL.tick (x + tankR, (plate::apL1 + plate::excursion * (1.0f + lfo) * 0.5f) * s);
        auto y = d1L.readLinear (plate::dL1 * s - 1.0f);
        d1L.push (a);
        y = dampL.tick (y) * decayGain;
        a = apL.tick (y, plate::apL2 * s);
        y = d2L.readLinear (plate::dL2 * s - 1.0f);
        d2L.push (a);
        const auto newTankL = y * decayGain;

        // Right half.
        a = modApR.tick (x + tankL, (plate::apR1 + plate::excursion * (1.0f + lfo2) * 0.5f) * s);
        y = d1R.readLinear (plate::dR1 * s - 1.0f);
        d1R.push (a);
        y = dampR.tick (y) * decayGain;
        a = apR.tick (y, plate::apR2 * s);
        y = d2R.readLinear (plate::dR2 * s - 1.0f);
        d2R.push (a);
        const auto newTankR = y * decayGain;

        tankL = sanitize (newTankL);
        tankR = sanitize (newTankR);

        const auto tap = [s] (const DelayLine& l, float t) { return l.readLinear (t * s); };

        const auto yl =  tap (d1R, 266) + tap (d1R, 2974) - tap (apR.line, 1913) + tap (d2R, 1996)
                       - tap (d1L, 1990) - tap (apL.line, 187) - tap (d2L, 1066);
        const auto yr =  tap (d1L, 353) + tap (d1L, 3627) - tap (apL.line, 1228) + tap (d2L, 2673)
                       - tap (d1R, 2111) - tap (apR.line, 335) - tap (d2R, 121);

        outL[i] = yl * 0.6f;
        outR[i] = yr * 0.6f;
    }
}

//==============================================================================
void ConvolutionReverb::prepare (float sr)
{
    sampleRate = sr;
    block.setSize (2, kBlock);
    conv.prepare ({ (double) sr, (juce::uint32) kBlock, 2 });
    prepared = true;
    reset();
}

void ConvolutionReverb::reset() noexcept
{
    conv.reset();
    block.clear();
    outFifoL.fill (0.0f);
    outFifoR.fill (0.0f);
    fill = 0;
    lpL.reset();
    lpR.reset();
}

void ConvolutionReverb::set (float damp) noexcept
{
    lpL.setHz (20000.0f * std::exp2 (-3.3f * clampf (damp, 0.0f, 1.0f)), sampleRate);
    lpR.a = lpL.a;
}

void ConvolutionReverb::process (const float* inL, const float* inR, float* outL, float* outR, int n) noexcept
{
    auto* bl = block.getWritePointer (0);
    auto* br = block.getWritePointer (1);

    for (int i = 0; i < n; ++i)
    {
        bl[fill] = inL[i];
        br[fill] = inR[i];
        // JUCE normalises the IR to 1/8 of unit energy; bring it back to unit energy.
        outL[i] = lpL.tick (outFifoL[(size_t) fill]) * 8.0f;
        outR[i] = lpR.tick (outFifoR[(size_t) fill]) * 8.0f;

        if (++fill == kBlock)
        {
            juce::dsp::AudioBlock<float> ab (block);
            conv.process (juce::dsp::ProcessContextReplacing<float> (ab));
            std::copy (bl, bl + kBlock, outFifoL.begin());
            std::copy (br, br + kBlock, outFifoR.begin());
            fill = 0;
        }
    }
}

void ConvolutionReverb::loadImpulse (juce::AudioBuffer<float>&& ir, double irSampleRate)
{
    if (ir.getNumSamples() == 0)
        return;

    jassert (ir.getNumChannels() == 2);

    conv.loadImpulseResponse (std::move (ir), irSampleRate,
                              juce::dsp::Convolution::Stereo::yes,
                              juce::dsp::Convolution::Trim::no,
                              juce::dsp::Convolution::Normalise::yes);
}

void ConvolutionReverb::finishLoading()
{
    if (prepared)
    {
        conv.prepare ({ (double) sampleRate, (juce::uint32) kBlock, 2 });
        reset();
    }
}

//==============================================================================
void OctaveShifter::prepare (float sr)
{
    grain = std::round (0.07f * sr);
    minDelay = 48.0f;
    line.allocate ((int) (grain + minDelay) + 64);
    reset();
}

void OctaveShifter::reset() noexcept
{
    line.reset();
    phase = 0.0f;
}

float OctaveShifter::read (int i) noexcept
{
    phase += 1.0f / grain;

    if (phase >= 1.0f)
        phase -= 1.0f;

    auto p2 = phase + 0.5f;

    if (p2 >= 1.0f)
        p2 -= 1.0f;

    const auto tap = [this, i] (float p)
    {
        const auto w = std::sin (kPi * p);
        const auto d = minDelay + (1.0f - p) * grain;
        return w * w * line.readLinear (d - 1.0f - (float) i);
    };

    return tap (phase) + tap (p2);
}

//==============================================================================
void Reverb::prepare (float sr)
{
    sampleRate = sr;

    FdnConfig cap;
    cap.lines = 8;
    cap.delayMs = { 11.3f, 13.7f, 17.9f, 19.4f, 23.1f, 27.3f, 29.9f, 33.7f };
    cap.sizeMin = 0.45f; cap.sizeMax = 1.3f;
    cap.modDepthMs = 0.12f; cap.modRateMin = 0.6f; cap.modRateMax = 1.3f;
    cap.hfScale = 1.6f;
    cap.diffusers = 3;
    cap.diffMs = { 1.9f, 3.1f, 4.7f };
    cap.diffG = 0.6f;
    cap.erTaps = 14;
    cap.gain = 0.7f;

    FdnConfig bas;
    bas.lines = 16;
    bas.delayMs = { 41.1f, 47.3f, 53.9f, 61.7f, 67.3f, 73.1f, 79.9f, 87.3f,
                    93.7f, 101.9f, 109.3f, 118.7f, 127.1f, 137.3f, 149.9f, 163.1f };
    bas.sizeMin = 0.35f; bas.sizeMax = 1.25f;
    bas.modDepthMs = 0.45f; bas.modRateMin = 0.15f; bas.modRateMax = 0.85f;
    bas.hfScale = 1.0f;
    bas.diffusers = 4;
    bas.diffMs = { 4.3f, 7.1f, 11.7f, 17.3f };
    bas.diffG = 0.65f;
    bas.innerMs = 6.0f; bas.innerG = 0.35f;
    bas.gain = 0.75f;

    FdnConfig cis;
    cis.lines = 16;
    cis.delayMs = { 61.3f, 67.9f, 76.1f, 83.3f, 91.7f, 99.1f, 108.7f, 117.9f,
                    127.3f, 139.1f, 149.3f, 161.9f, 175.1f, 189.7f, 204.1f, 221.3f };
    cis.sizeMin = 0.5f; cis.sizeMax = 1.3f;
    cis.modDepthMs = 1.6f; cis.modRateMin = 0.07f; cis.modRateMax = 0.31f;
    cis.hfScale = 0.3f;
    cis.diffusers = 6;
    cis.diffMs = { 3.7f, 6.1f, 9.9f, 14.3f, 21.1f, 29.3f };
    cis.diffG = 0.7f;
    cis.innerMs = 11.0f; cis.innerG = 0.5f;
    cis.outLowpassHz = 5500.0f;
    cis.gain = 0.9f;

    cappella.prepare (sr, cap);
    basilica.prepare (sr, bas);
    cisterna.prepare (sr, cis);
    plate.prepare (sr);
    convolution.prepare (sr);
    shifter.prepare (sr);

    preL.allocate ((int) (0.26f * sr));
    preR.allocate ((int) (0.26f * sr));

    predelay.setTimeMs (60.0f, sr);
    mix.setTimeMs (25.0f, sr);
    width.setTimeMs (25.0f, sr);
    shimmer.setTimeMs (40.0f, sr);

    shimLp.setHz (9000.0f, sr);
    shimHpLp.setHz (250.0f, sr);

    reset();
}

void Reverb::reset() noexcept
{
    for (int m = 0; m < kModes; ++m)
        resetRoom (m);

    live.fill (false);
    fade.fill (0.0f);
    fadeTarget.fill (0.0f);
    inFade.fill (0.0f);
    live[(size_t) activeMode] = true;
    fade[(size_t) activeMode] = fadeTarget[(size_t) activeMode] = inFade[(size_t) activeMode] = 1.0f;

    shifter.reset();
    preL.reset();
    preR.reset();
    shimLp.reset();
    shimHpLp.reset();

    predelay.reset (predelay.target);
    mix.reset (mix.target);
    width.reset (width.target);
    shimmer.reset (shimmer.target);
}

void Reverb::resetRoom (int m) noexcept
{
    switch ((RevMode) m)
    {
        case RevMode::cappella: cappella.reset(); break;
        case RevMode::basilica: basilica.reset(); break;
        case RevMode::cisterna: cisterna.reset(); break;
        case RevMode::piastra:  plate.reset(); break;
        case RevMode::impronta: convolution.reset(); break;
    }
}

void Reverb::set (RevMode mode, bool hasIR, float size, float decay, float predelayMs, float damp,
                  float w, float shim, float m) noexcept
{
    auto effective = (int) mode;

    if (mode == RevMode::impronta && ! hasIR)
        effective = (int) RevMode::basilica;

    if (effective != activeMode)
    {
        fadeTarget[(size_t) activeMode] = 0.0f;
        activeMode = effective;
        fadeTarget[(size_t) activeMode] = 1.0f;

        // A room coming up from silence has an empty tank: its output can be at full gain at
        // once while its input ramps in, so no delayed onset inside it ever arrives as a step.
        if (! live[(size_t) activeMode])
        {
            live[(size_t) activeMode] = true;
            fade[(size_t) activeMode] = 1.0f;
            inFade[(size_t) activeMode] = 0.0f;
        }
    }

    decaySeconds = clampf (decay, 0.1f, 30.0f);

    for (int r = 0; r < kModes; ++r)
    {
        if (! live[(size_t) r])
            continue;

        switch ((RevMode) r)
        {
            case RevMode::cappella: cappella.set (size, decaySeconds, damp); break;
            case RevMode::basilica: basilica.set (size, decaySeconds, damp); break;
            case RevMode::cisterna: cisterna.set (size, decaySeconds, damp); break;
            case RevMode::piastra:  plate.set (size, decaySeconds, damp); break;
            case RevMode::impronta: convolution.set (damp); break;
        }
    }

    predelay.target = clampf (predelayMs, 0.0f, 250.0f) * 0.001f * sampleRate;
    width.target = clampf (w, 0.0f, 1.0f);
    shimmer.target = clampf (shim, 0.0f, 1.0f);
    mix.target = clampf (m, 0.0f, 1.0f);
}

void Reverb::processRoom (int m, const float* inL, const float* inR, float* outL, float* outR, int n) noexcept
{
    switch ((RevMode) m)
    {
        case RevMode::cappella: cappella.process (inL, inR, outL, outR, n); break;
        case RevMode::basilica: basilica.process (inL, inR, outL, outR, n); break;
        case RevMode::cisterna: cisterna.process (inL, inR, outL, outR, n); break;
        case RevMode::piastra:  plate.process (inL, inR, outL, outR, n); break;
        case RevMode::impronta: convolution.process (inL, inR, outL, outR, n); break;
    }
}

void Reverb::process (float* l, float* r, int n) noexcept
{
    jassert (n <= (int) xL.size());

    const auto convLatency = (float) ConvolutionReverb::kBlock;
    const auto fbScale = 0.75f / (1.0f + 0.15f * decaySeconds);

    for (int i = 0; i < n; ++i)
    {
        preL.push (l[i]);
        preR.push (r[i]);

        const auto d = predelay.next();
        const auto dc = std::max (0.0f, d - convLatency);

        auto sh = shifter.read (i);
        sh = shimLp.tick (sh);
        sh -= shimHpLp.tick (sh);
        sh = 0.5f * fastTanh (2.0f * sh * shimmer.next() * fbScale);

        xL[(size_t) i] = preL.readLinear (d) + sh;
        xR[(size_t) i] = preR.readLinear (d) + sh;
        cL[(size_t) i] = preL.readLinear (dc) + sh;
        cR[(size_t) i] = preR.readLinear (dc) + sh;
        wL[(size_t) i] = wR[(size_t) i] = 0.0f;
    }

    const auto fadeStep = (float) n / (0.05f * sampleRate);

    for (int m = 0; m < kModes; ++m)
    {
        if (! live[(size_t) m])
            continue;

        const auto isConv = m == (int) RevMode::impronta;
        const auto* inL = isConv ? cL.data() : xL.data();
        const auto* inR = isConv ? cR.data() : xR.data();

        const auto g0 = inFade[(size_t) m];
        const auto g1 = fadeTarget[(size_t) m] > g0 ? std::min (1.0f, g0 + fadeStep)
                                                    : std::max (fadeTarget[(size_t) m], g0 - fadeStep);
        inFade[(size_t) m] = g1;

        if (g0 < 1.0f || g1 < 1.0f)
        {
            for (int i = 0; i < n; ++i)
            {
                const auto g = g0 + (g1 - g0) * (float) (i + 1) / (float) n;
                iL[(size_t) i] = inL[i] * g;
                iR[(size_t) i] = inR[i] * g;
            }

            inL = iL.data();
            inR = iR.data();
        }

        processRoom (m, inL, inR, tL.data(), tR.data(), n);

        const auto f0 = fade[(size_t) m];
        auto f1 = f0;

        if (fadeTarget[(size_t) m] > f0)      f1 = std::min (1.0f, f0 + fadeStep);
        else if (fadeTarget[(size_t) m] < f0) f1 = std::max (0.0f, f0 - fadeStep);

        for (int i = 0; i < n; ++i)
        {
            const auto g = f0 + (f1 - f0) * (float) (i + 1) / (float) n;
            wL[(size_t) i] += tL[(size_t) i] * g;
            wR[(size_t) i] += tR[(size_t) i] * g;
        }

        fade[(size_t) m] = f1;

        if (f1 <= 0.0f && fadeTarget[(size_t) m] <= 0.0f)
        {
            live[(size_t) m] = false;
            resetRoom (m);
        }
    }

    for (int i = 0; i < n; ++i)
    {
        auto wl = sanitize (wL[(size_t) i]);
        auto wr = sanitize (wR[(size_t) i]);
        shifter.push (0.5f * (wl + wr));

        const auto mid = 0.5f * (wl + wr);
        const auto side = 0.5f * (wl - wr) * width.next();
        wl = mid + side;
        wr = mid - side;

        const auto m = mix.next();
        const auto dryG = std::sqrt (1.0f - m), wetG = std::sqrt (m);
        l[i] = l[i] * dryG + wl * wetG;
        r[i] = r[i] * dryG + wr * wetG;
    }
}

} // namespace libero
