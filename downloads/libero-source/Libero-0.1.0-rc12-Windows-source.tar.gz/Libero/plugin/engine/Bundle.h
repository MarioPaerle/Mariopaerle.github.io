#pragma once

#include <juce_audio_formats/juce_audio_formats.h>
#include "SampleBuffer.h"
#include "SampleStream.h"

#include <array>
#include <memory>
#include <vector>
#include <functional>

namespace libero
{

enum class Layer { body = 0, attack, tail, air };

struct Zone
{
    int manifestIndex = -1;
    double sourceStartSeconds = 0.0;
    Layer layer = Layer::body;
    bool pitched = true;
    int root = 60, lo = 0, hi = 127, velLo = 1, velHi = 127;
    int take = 0;           // round-robin take (manifest "take", absent = 0)
    int group = -1;         // zones of one layer sharing key, velocity and dyn ranges are one group

    // libero.bundle/2 (all optional)
    float dynLo = -1.0f, dynHi = -1.0f;   // position on the dynamics axis, [lo, hi] in 0..1
    float tuneCents = 0.0f;               // fine correction, pitched zones only
    float rtDecay = 0.0f;                 // tails: dB per second of held time
    float rtMinDb = -40.0f;               // tails: floor of that attenuation
    int onset = 0;                        // samples of pre-roll skipped at note-on (onset_ms)
    int onsetFade = 0;                    // fade-in after that skip, samples
    bool oneShot = false;                 // note-off ignored: the sample plays to its end
    int art = -1;                         // articulation index (manifest "articulation"), -1 = every articulation
    int chokeGroup = 0;                   // 0 = none; starting a note chokes the sounding voices of this group
    std::vector<int> chokes;              // further groups this zone chokes without belonging to them

    bool hasDyn() const noexcept { return dynLo >= 0.0f; }
    float dynCentre() const noexcept { return 0.5f * (dynLo + dynHi); }

    // Stored at SoundData::sampleRate, zone gain already applied, loop crossfade already baked in:
    // when the play head reaches loopEnd it jumps to loopStart with no further blending.
    SampleBuffer audio;
    const SampleStreamPool::Asset* stream = nullptr;
    SampleStreamPool* streamPool = nullptr;
    bool looped = false;
    int loopStart = 0, loopEnd = 0;

    int length() const noexcept { return stream != nullptr ? stream->frames : audio.getNumSamples(); }
};

// An immutable sound bundle with resident PCM or resident attacks and streamed bodies.
// Created on a background thread, then handed to the
// engine. Never modified after load.
struct SoundData
{
    std::shared_ptr<const SoundData> cacheBacking;
    std::shared_ptr<SampleStreamPool> streaming;
    int playbackId = 0;
    int64_t contentId = 0;
    bool residentUpgrade = false;
    juce::File folder;      // the sound folder (parent of build/), or build dir if standalone
    juce::File buildDir;
    juce::String slug, title, subtitle, description, accent;
    juce::StringArray tags;
    juce::var params;       // manifest "params" object (may be void)

    double sampleRate = 48000.0;
    std::vector<Zone> zones;
    std::array<std::vector<int>, 4> byLayer;
    std::vector<std::vector<int>> groups;   // zone indices of each group, sorted by take
    // Dynamics layers: groups of one layer with the same key/velocity ranges and a `dyn` range,
    // sorted by dyn centre. groupDynSet maps a group to its set (-1 without `dyn`).
    std::vector<std::vector<int>> dynSets;
    std::vector<int> groupDynSet;
    int airZone = -1;

    // Articulations (bundle/2): the manifest's list, in UI order; the first is the default. A
    // note-on on an articulation's key switches the active one and sounds nothing.
    struct Articulation
    {
        juce::String id, name;
        int key = -1;
        std::vector<std::pair<int, float>> profile;   // optional live synth parameter overrides
    };
    std::vector<Articulation> articulations;
    std::array<int8_t, 128> keyswitch = makeKeyswitch();    // key -> articulation index, -1 = ordinary key
    static std::array<int8_t, 128> makeKeyswitch() { std::array<int8_t, 128> a; a.fill (-1); return a; }
    int numArticulations() const noexcept { return (int) articulations.size(); }

    // Manifest-level playing behaviour (bundle/2).
    enum class DynSource { velocity, cc1, cc11 };
    DynSource dynSource = DynSource::velocity;
    float velocityCurve = 1.0f;
    float dynCrossfade = -1.0f;             // < 0: legacy (equal-power blend across the whole gap); 0..1 = blend fraction, 0 = hard switch
    bool hasHumanize = false;
    float humanizeCents = 0.0f, humanizeMs = 0.0f, humanizeDb = 0.0f;
    float rrResetMs = -1.0f;                // < 0: never restart the take cycle

    juce::AudioBuffer<float> ir;
    double irSampleRate = 0.0;
    juce::AudioBuffer<float> publicationIR; // stereo handoff, prepared by the submitting thread

    bool hasIR() const noexcept { return ir.getNumSamples() > 0; }

    // `art` >= 0 keeps only the zones of that articulation and those without one; -1 keeps all.
    // Zone to play for (layer, note, velocity): exact range match first, then nearest; `take`
    // picks among the group's round-robin takes (modulo their count). Never allocates.
    // With dynamics layers, `dyn` (0..1) picks the layer whose range holds it (nearest centre).
    const Zone* find (Layer, int note, int velocity, int take = 0, float dyn = -1.0f, int art = -1) const noexcept;

    // Group of the zone find() would pick (-1 if the layer is empty), and its number of takes.
    int findGroup (Layer, int note, int velocity, float dyn = -1.0f, int art = -1) const noexcept;
    int findKeyGroup (Layer, int note, int velocity, int art = -1) const noexcept;   // ignoring dyn
    const Zone& zoneOf (int group, int take) const noexcept
    {
        const auto& m = groups[(size_t) group];
        return zones[(size_t) m[(size_t) (std::abs (take) % (int) m.size())]];
    }
    int takeCount (int group) const noexcept { return group < 0 ? 0 : (int) groups[(size_t) group].size(); }

    bool validateStreamedAudio (juce::String& error) const;

    // Loads a bundle from a sound folder or its build/ dir, resampling every zone to targetRate.
    static std::unique_ptr<SoundData> load (const juce::File& path, double targetRate, juce::String& error,
                                           const std::function<bool()>& cancelled = {}, bool allowStreaming = false);
};

// Accepts either a sound folder or its build/ directory; returns the build dir (or an invalid File).
juce::File resolveBuildDir (const juce::File& path);

// Offline band-limited resampler (Kaiser-windowed sinc). ratio = inputRate / outputRate.
std::vector<float> resample (const float* input, int numInput, double ratio);
int resampleHalo (double ratio) noexcept;
void resampleWindow (const float* source, int sourceStart, int totalSourceFrames,
                     double ratio, int targetStart, int targetCount, float* output);

} // namespace libero
