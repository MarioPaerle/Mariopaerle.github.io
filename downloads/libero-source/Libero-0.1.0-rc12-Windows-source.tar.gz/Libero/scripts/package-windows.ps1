param(
    [string]$BuildDir = "",
    [string]$Output = "",
    [string]$Label = "0.1.0-rc9"
)
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
if (!$BuildDir) { $BuildDir = Join-Path $root "build/windows" }
if (!$Output) { $Output = Join-Path $BuildDir "release" }
if ($Label -notmatch '^\d+\.\d+\.\d+(?:-[a-z0-9.]+)?$') { throw "Invalid release label" }
if (Test-Path $Output) { throw "Output already exists: $Output" }
$plugin = Join-Path $BuildDir "plugin/Libero_artefacts/Release/VST3/Libero.vst3"
$renderer = Join-Path $BuildDir "plugin/libero_render_artefacts/Release/libero-render.exe"
if (!(Test-Path $plugin) -or !(Test-Path $renderer)) { throw "Build the Release configuration first" }
$payload = Join-Path $Output "Libero-Windows-x64"
New-Item -ItemType Directory -Force $payload | Out-Null
Copy-Item $plugin $payload -Recurse
Copy-Item $renderer $payload
Copy-Item "$root/docs/release/install-windows.md" "$payload/INSTALL.md"
Copy-Item "$root/LICENSE", "$root/NOTICE" $payload
$notices = New-Item -ItemType Directory "$payload/Notices"
Copy-Item "$root/third_party/JUCE/LICENSE.md" "$notices/JUCE-LICENSE.md"
Copy-Item "$root/third_party/JUCE/JUCE.spdx.json" $notices
Copy-Item "$root/ui/fonts/OFL-*.txt" $notices
$sdk = Join-Path $BuildDir "packages/Microsoft.Web.WebView2.1.0.3485.44"
if (!(Test-Path "$sdk/LICENSE.txt")) { throw "WebView2 SDK license is missing" }
Copy-Item "$sdk/LICENSE.txt" "$notices/WebView2-LICENSE.txt"
& python "$root/scripts/prepare_release.py" --source-only --output "$BuildDir/source-stage" --label $Label
if ($LASTEXITCODE) { throw "Source archive failed" }
Copy-Item "$BuildDir/source-stage/*" $Output

$zip = Join-Path $Output "Libero-$Label-Windows-x64.zip"
Compress-Archive -Path $payload -DestinationPath $zip
$iscc = Get-Command ISCC.exe -ErrorAction SilentlyContinue
$compiler = if ($iscc) { $iscc.Source } else { $null }
if (!$compiler) {
    $candidate = "${env:ProgramFiles(x86)}/Inno Setup 6/ISCC.exe"
    if (Test-Path $candidate) { $compiler = $candidate }
}
if (!$compiler) { throw "Inno Setup 6 is required to produce the installer; ZIP is at $zip" }
& $compiler "/DPayload=$payload" "/DReleaseLabel=$Label" "/DReleaseOutput=$Output" "$PSScriptRoot/windows-installer.iss"
if ($LASTEXITCODE) { throw "Installer compilation failed" }
$files = Get-ChildItem $Output -File | Where-Object { $_.Extension -in '.zip', '.exe', '.gz' }
$hashes = @($files | ForEach-Object { $h = Get-FileHash $_.FullName -Algorithm SHA256; "$($h.Hash.ToLower())  $($_.Name)" })
$hashes | Set-Content "$Output/SHA256SUMS" -Encoding ascii
@{ format = 'libero.windows-stage/1'; label = $Label; platform = 'Windows x64'; signed = $false; source_commit = (& git -C $root rev-parse HEAD); archives = @($files | ForEach-Object { @{ file=$_.Name; bytes=$_.Length; sha256=(Get-FileHash $_.FullName).Hash.ToLower() } }) } | ConvertTo-Json -Depth 5 | Set-Content "$Output/release-manifest.json" -Encoding utf8
Write-Host "Windows ZIP and installer prepared: $Output"
