# Source-led palettes: worked examples

Read for rich acoustic/designed collections, human motion, or requested infinite
holds. These examples describe the Aria and Cielo builds this user approved on
3 October 2026. His approval supports that palette and his preferences; it is not
a general claim of commercial parity or a guarantee for future recipes.

## Choose a physical identity before a treatment

The successful Aria palette used six recognizably different recorded excitations:
Schoenhut toy piano, mechanical music box, xylophone with three mallets,
Cage-prepared piano, plucked kalimba and blown pan pipes. A seventh voice was
original live subtractive synthesis. Each had a different body, gesture and role.
Earlier attempts based on a common resonator/pad scaffold with EQ or effects were
rejected as empty and similar. A label, louder gain or more reverb did not fix that.

For a new collection, write a small roster of excitation, resonant body, motion,
usable register and musical role. Acquire new material where those entries would
otherwise repeat. Warm/full means useful body and low/mid structure remain audible,
with upper detail articulating the gesture. It does not mean a noise carpet or
an arbitrary layer of sine waves underneath every source. Compare phrases at
similar loudness in registers appropriate to the recordings, not one identical
low MIDI note that pitches a high music box down two octaves.

## Establish what was actually recorded

Store source URL, author, exact licence and permitted distribution lane, archive
SHA-256, original files, original SFZ/map and source-to-zone mapping. Preserve all
actual dynamics, takes, articulations and recorded releases. Duplicate filenames
and alternate encodings do not create extra performances. Processing variants
are not round robins. A new timbre is not a new recording when it only transforms
another bank's source; label a deliberately designed hybrid honestly.

Examples:

| Source | What the build preserved | Important distinction |
|---|---|---|
| Corsica_S / Tim Kahn Schoenhut | 18 distinct recordings, C4–F5 | 29 WAV entries include 11 identical aliases; no fake RR |
| VCSL xylophone | 8 roots × 3 mallets × pp/ff | Mallets are articulations; source names are an octave below sounding pitch |
| CCRMA prepared piano, Kurt James Werner | 43 dry notes plus 25 pedal recordings | Pedal is an articulation, not a dynamic; an identical D3 duplicate is retained as an original only |
| FreePats kalimba | 45 real strikes over 8 roots | Variable genuine take counts, one recorded dynamic; SFZ tuning offsets matter |
| Pattingthestar pan pipes | 10 actual pipes, one performance each | Original stereo sometimes cancels in mono; one stronger recorded channel was used, originals retained |

Use pitch evidence rather than blindly choosing the strongest FFT bin. The toy
piano recording 196932 had a weak frame mode near 162.6 Hz, but its high resonant
family supported E5 near 664.3 Hz. Treating the frame as E3 gave a wrong key map.
An inharmonic prepared piano, on the other hand, retains the player's original
key identity: its preparation is not an equal-temperament defect to erase.

## Keep the real entry and the early body

Preserve the source attack after any documented leading-silence trim and necessary
sample-rate conversion. Confirm aligned raw-versus-derived entry separately from
the renderer's level/envelope processing. Keep natural differences in recorded
velocity layers; hard-switch struck/plucked sources rather than blending unrelated
carrier phases. Do not align distinct takes by carrier phase or smooth away their
timing gestures. A recorded release must start at the bow lift/finger release;
including active bowing in a note-off tail can make the sound appear to restart.

For a percussive sound that must hold forever, analyse the useful early ringing
body before it sinks into background noise. The final toy piano/xylophone/music-box
fits used roughly 40–300 ms, with the body target measured in 40–160 ms. The prepared
piano used a longer 80–700 ms source window. These are examples, not universal
constants. Inspect a low, middle and high note and each articulation/dynamic: a
muted high strike may die before a long source window has finished.

Avoid fixed mode counts, arbitrary 18 Hz spacing and phase randomisation. Keep
significant measured resonances above the source's measured background, including
inharmonic frequencies and actual complex phase. The approved prepared source
needed 20–900 fitted modes depending on the note; a generic 36-mode cap removed body.
Do not amplify late electrical noise or room hiss to manufacture a sustained tone.

## Source-derived sustain: phase and timeline matter

A seamless indefinite continuation still needs a musical decay. In the October
2026 Aria review, held percussion bodies masked subsequent attacks even though
their loops were continuous and the timbres had been approved. Preserve the real
entry, then let the envelope settle to a lower nonzero floor. Use different decay
times for a xylophone, music box, tubular bell and gong; keep wind and bowed bodies
stronger. Compare a held note and repeated overlapping notes through the native
engine, measuring early entry and late body separately. `scripts/refine_sample_gestures.py`
records the applied profiles and creates metadata backups without rewriting PCM.
These settings follow this user's correction and still need his listening verdict.

For melodic 808s, check the first 200 ms as well as the stable body. An octave
pitch drop and a bright transient can make an otherwise approved bass behave like
a kick. The October correction starts the existing sample at its stable pitched
body, with a short click-free rise; original recordings and loops are retained.
Compare register extremes and fresh attacks after rests. A separately named kick
can keep its pitch sweep; the melodic bass must suit the requested role.

For an explicitly requested designed hold on a struck instrument, preserve its
original first 180–250 ms and splice to a periodic continuation fitted to that
same recording. Document that the continuation is designed, not a naturally
endless instrument. The fitted amplitude/phase must share the source's time origin:

```python
# window starts at t0; c is its measured complex sinusoidal projection
c_at_source_zero = c * np.exp(-2j * np.pi * measured_hz * t0)
# Quantise measured frequencies to a sufficiently long periodic cycle.
bin_index = round(measured_hz * period_seconds)
periodic_spectrum[bin_index] += cycle_samples * c_at_source_zero / 2
cycle = np.fft.irfft(periodic_spectrum, n=cycle_samples, axis=0)

# Use the note-on timeline throughout the crossfade and after it.
continuation = cycle[np.arange(output_samples) % cycle_samples]
derived[:join_start] = original[:join_start]
derived[join_start:join_end] = (
    original[join_start:join_end] * (1 - smooth_weight)
    + continuation[join_start:join_end] * smooth_weight
)
```

The schematic assumes compatible dimensions and omits peak selection, gain,
floor estimation and stereo handling: see the real builders below. Recomputing
complex coefficients at refined frequencies is better than inheriting the phase
of a nearby coarse FFT bin. Frequency rounding and periodic energy compensation
must not remove the measured mode balance or real pp/ff contrast.

A previous bug used `cycle(t - join_end)` during the splice but `cycle(t)` after
it. The phase estimate was correct; the time origin was wrong, so the source and
continuation cancelled. Small loop seam numbers did not reveal that thin entry.
Check the entire transition, including correlation and level against the raw
source, not only the loop wrap. For three very fast strikes, the join ended at
350 ms rather than 650 ms while keeping the first 180 ms intact. Natural attack
decay is allowed; a deep artificial null or a delayed conspicuous swell needs work.

Anchor sustain level to that recording's early body, with a documented bounded
floor only when a intentionally muted resonance would otherwise disappear. Do
not normalise all real dynamics into one layer. Put the loop start after the
join and settling region; loop endpoints must be explicit in every body zone.
An automatic loop search can return no loop, even when the recipe has a long
periodic file. Check the compiled manifest, not the recipe's intention.

## Avoid a second attack from the continuation

On 5 October 2026 the user reported a delayed rise in Steinway Bebop and Blue
keys. The native Steinway middle note fell near −30 dBFS and returned near
−26 dBFS at the join; Magnetic Thread had a larger return in its compiled PCM.
Matching a continuation to 40–160 ms body RMS can overshoot the recording’s
later decay. Check successive 100–120 ms windows over the entire first second,
including low/middle/high roots and all real dynamics. A low loop seam error
will not detect this rise.

`libero.continuation.restrain_continuation` preserves the first 220 ms, then
attenuates a declared struck/plucked continuation when it rebounds over its
preceding body. Its gain is shared by stereo channels and constant across the
loop. It does not boost the source or replace its modes. Apply only to designed
extensions, preserving original files and genuine wind/bowed dynamics. Evidence
and backups: `~/Libero/demo/blue-bebop-gesture-v2/`. These are measured corrections;
the user’s listening verdict is still pending.

## Human air and ongoing motion

For winds and bowed notes, preserve performed changes in pressure, breath,
embouchure, vibrato and spectral balance. Find a useful blown/bowed region before
the performer releases; include musical natural movement rather than selecting
only the flattest/highest-energy fraction. Do not include silence or a dying breath
that periodically empties the held note. Prefer a longer viable recorded loop and
an unobtrusive same-source join over adding a pitch LFO, wow, random hiss or chorus.
Different performances/performers may be combined for an explicitly designed
ensemble, but near-copy delayed layers in a faithful solo instrument create combs.

Pan pipes originally lost up to 13.4 dB in mono. This was a recorded channel
relationship, not insufficient EQ. Using the stronger original channel retained
the actual breath without invented width. Check mono before making a source wider.
If air is brought forward, derive it from the recorded gesture and explain the
change; generic hiss is not a performer. No claim that technical motion equals
human realism without listening.

For the approved Cielo extension, keep the seven accepted entries/vowels and
performers. Long source-derived choir montages stagger compatible breaths from
independent performances; they do not count as new singers. Ellen preserves its
Ooh→Aha phrase and pause, continuing only the final Ah. Phase-locked spectral
continuation needs actual phase advance and bounded energy: random frame phases
or a fixed-phase STFT can pulse or smear a voice. The wide epic choir uses real
mixed performers and octave roles, rather than baking a major/minor chord into
every keyboard note. Long loops still repeat limited source material; disclose it.

## Verify the player's result, then preserve approval

- Native render: quiet/loud entries, repeated notes, musical chords, real low/mid/
  high register, each materially different articulation, at least several loop
  wraps and MIDI note-off. Sixty-second holds worked for these Aria bodies; Cielo
  used 110 seconds for its longer cycles.
- Inspect onset/splice/sustain separately, stereo and mono, clipping, release
  and spectral motion. A mathematically tiny seam does not guarantee an invisible
  musical repeat or a full body. Lint 0 FAIL plus explained source WARN is a
  technical threshold, not proof of warmth or realism.
- Complete mutations and compiles before final integration. Verify that each
  manifest `source_hash` equals `library.source_hash(folder)` and that all held
  body zones really contain loops, or use continuous live oscillators. Concurrent
  render-triggered recompilation can make a read-only audit see a stale bundle.
- Make a short gain-matched palette audition without changing programme gains.
  Keep source-appropriate registers and list the order/timestamps.
- Back up rejected/modified sounds; retire rejected ones from active banks.
  Compare approved untouched programmes against their saved hashes. The three
  hardware 808s stayed byte-identical during the Aria/Cielo rebuild.

## Executable examples in this repository

- `python/scripts/build_aria_prepared.py`: prepared strikes, real pedal techniques,
  measured complex modes, explicit source loops, native QA and attribution.
- `python/scripts/build_aria_mechanical.py`: true source pitch mapping, mallet
  articulations, early-body fitting and adaptive transition overrides.
- `python/scripts/build_aria_kalimba.py`: real variable take counts and SFZ offsets.
- `python/scripts/build_aria_pan.py`: recorded pipes, breath region and mono check.
- `python/scripts/build_cielo_infinite.py`: compatible real performers and preserved
  accepted vocal entries; no invented child choir.
- `python/scripts/build_aria_saw.py`: stable central live saw plus quieter detuned
  edges, gentle filter motion, no sampled loop or wow.
- `python/scripts/demo_aria_v4.py` and `verify_library_refresh_v4.py`: native audition,
  final bundle/source hash checks and approved-programme protection.

Paths identify implementations to inspect and adapt, not scripts to blindly run
over approved programmes. New acquisition and user feedback can improve them.

## Additional examples: Aria expansion and Blue

User listening feedback on 3 October 2026 explicitly approved the eight expanded
Aria voices, usually 8/10 with individual 7/10 and 9/10 ratings, and the Blue
collection as a strong current reference. Preserve their approved timbres. New
voices should expand this diversity of real excitation and body rather than
copy their EQ, harmonic ratios or modal envelope onto another source. The user
also reported that Ancia Elettrica made a major scale seem minor: approval of
timbre does not certify keyboard mapping or intervals.

The eight new Aria constructions use marimba, vibraphone (soft/hard mallets and
bow), hand chimes, tubular bells, folk harp, bowed/plucked psaltery, ocarina and
Hohner harmonica. Do not collapse them into the same attack/sustain recipe:
recorded breath motion works differently from continuing measured struck modes.
Inspect `build_aria_expansion_mallets.py` and
`build_aria_expansion_winds_plucked.py` for the actual articulations and sources.

These VCSL folders use octave labels one below sounding pitch. A harmonica file
labelled C3 sounds near 261.6 Hz, so its playback root is MIDI 60, not 48. Preserve
both written label and measured playback root in provenance. Measure low, middle
and high notes in every articulation: a global YIN ceiling of 1500 Hz can fold a
high fundamental down an octave. For bowed bars and tubular bells, verify the
physical modal family; the strongest FFT peak can be an upper mode. Correct maps
and release key intervals together, then render actual source keys natively.
`repair_aria_wind_roots.py` repairs maps without regenerating the recorded audio.

Blue distinguishes recorded Rhodes, Wurlitzer, Pianet, acoustic organ,
transistor organ, accordion, glass friction and flatwound electric guitar from
original electronic designs. The tonewheel source is a documented setBfree
emulation; it must not be labelled a recording of Hammond hardware. See
`build_blue_keys.py`, `build_blue_organic.py` and `build_blue_designed.py`.

Source velocity labels are not proof of increasing playback loudness: an author
may have peak-normalised every recording. Measure the actual engine at each
layer's representative velocity over every root, including early body and
sustain. A common gain calibration per genuine recorded dynamic can restore
response while preserving differences between notes. Keep originals unchanged,
record the offsets, and check adjacent steps; measuring only soft versus loud
at one middle key can miss a 4 dB inversion in an intermediate layer.

Keyboard correctness needs a separate native audit: play a chromatic run and
major/minor scales across region boundaries at soft, medium and loud velocity.
Measure the sounding fundamental relative to the requested MIDI note. An
on-disk root label, an accurate untransposed source and monotonic velocity
response can all coexist with incorrect playback intervals. When repacking SFZ
regions into common key cells, verify the sign of the engine's tuning offset and
account for source tuning and any global transpose exactly once. Bundle tuning
is limited to ±100 cents: a multi-semitone correction must be encoded with the
actual source root or baked into a resampled body, with loop coordinates updated.
Reject out-of-range offsets instead of silently clipping them. Fix mapping
without replacing a timbre the listener has already approved.

Optional effect chains are a separate user choice. Compression/EQ and a generated
breath or dust texture can colour a finished sound; they do not supply evidence
of an acoustic performance or replace its recorded gestures. Default chains are
off, and no pitch wow/flanger is needed to give an effect movement.

## Targeted drum refinements

When the listener approves a kit except for one instrument, protect every other
zone's compiled bytes, mapping, gains and kit defaults against a backup. A kit
compiler may normalise the entire body layer: raising one sample's peak can
quiet all the others. Preserve that common reference gain explicitly.

For the October Boom Bap revision, the requested Jazz reference was a local kit
using real Big Rusty Drums performances (CC0). Replace only the seven hat keys
with its closed, open, pedal and half-open recordings, retain all four genuine
round robins and velocity layers, and keep the original choke group. Mild 1.15×
tanh colour is applied to those recordings only, with per-articulation peak caps.

For Hip Hop, preserve the recorded open kick's identity and other kit pieces.
The first treatment added only 0.8 dB body RMS: too small for a request for a
very powerful kick. A stronger coherent low-passed body and short beater onset
from that same recording, followed by controlled crest reduction, added 4.43 dB
RMS in the first 150 ms and 4.82 dB in the 30–60 Hz band at nearly unchanged peak.
Render the same native groove before/after and an isolated hit; verify actual
clipping, source dynamics and the untouched zones. These measurements demonstrate
the intended physical change, not listener approval of the revised drums.

## Filling an approved but thin electronic palette

October feedback: Aria additions were mostly 8/10 with some 7 and 9, Blue was
also approved; Green was only 6–7/10, pleasant but thin. Treat these as this
listener’s preferences. More stereo or another layer of sub alone did not address
the requested body. Preserve the identity, then choose its missing register:

- **Ambra:** stronger FM indices and additional harmonic carriers, keeping a
  stable central pitch. Match body RMS before comparing; its first richer render
  was quieter after peak normalisation.
- **Canneto:** enrich the reed partial distribution and the 700/1700/3100 Hz
  resonant bands. Do not turn every reed into the same vowel pad.
- **Cedro:** retain the main saw and add restrained octave-up saw support with
  a small three-voice spread; measure the dry side separately from reverb.
- **Prisma:** retain the waveform morph but strengthen the central component
  when the stereo version loses too much body summed to mono.
- **Aurora:** strengthen warm harmonic FM underneath the quiet inharmonic
  resonances, preserving the glass identity instead of just brightening it.

Compare identical native musical phrases at similar RMS, plus held notes, chords
and mono summing. Keep pre-revision builds for recoverable A/B listening.
`build_green_v6.py`, `green_live_v2_design.py` and `demo_green_rich_v2.py` record
these examples. The richer revision still needs listener assessment; measurements
are not an automatic improvement in the listener’s score.

For a moving unison, a window’s spectral maximum can wander beyond the actual
oscillator cluster through phase cancellation. Check key mapping separately with
unison collapsed and drift disabled, and report both results. Bosco Largo’s
seven-voice peak wandered about 12 cents while its single-voice native control
was within 0.005 cents. Do not retune each key against that moving maximum, which
would introduce actual tuning errors into the underlying voices.

## Articulated acoustic instruments and reliable held keys

Bebop's archtop uses Shinyguitar's real pickup and microphone recordings as
separate selectable captures, with all four recorded dynamics and round robins.
The natural decay and source releases remain available; the held variant retains
the recorded strike and continues only that take's measured modes. Preserve the
original WAVs, SFZ maps, current rights grant and per-file hashes. Do not reuse a
source library's extra delayed voices as a claim of additional human performers.

Measure tuning in the body that the plugin actually sustains. An early attack
estimate initially left the microphone guitar about 36 cents flat on a low note;
calibration from the continued body, followed by native root and cell-boundary
tests at three velocities, corrected it. Keep natural-decay tuning separate from
the held variant and preserve the performed relative pitch motion.

A successful import does not establish a good sustained loop. Some Bebop brass
imports initially had loop seams around −10 to 0 dB. Repair joins from the same
performance, keep the excitation outside the loop, and render long native holds
before declaring readiness. Put real staccato, falls and mutes in selectable
articulations rather than multiplying near-duplicate presets.

Recorded drums need their physical resonance: ordinary ride and crash strikes
must overlap. A shared self-choking group cuts the previous cymbal on every hit;
reserve choking for intended closures and actual mute gestures. Verify a swung
groove and its late tails, plus headroom, after correcting the mapping.

Round robins must be heard in a native repeated-note test, not merely counted in
the manifest. In this engine `rr_reset_ms=0` resets immediately on every note,
selecting take zero again. Use a musical idle threshold such as 1500 ms, or omit
the reset to keep the random sequence running. Bebop's Rubner bass test confirms
four distinct quick-repeat takes and a reproducible restart after a long rest.
SFZ breath/key-noise groups must be separated from pitched performances before
counting takes: MTG noise samples initially inflated the apparent sax round robins.


## Approved character and interval variants

The listener singled out Mog's Sino de Lata as an interesting success. Preserve
that approved programme byte-for-byte; make named variants instead of replacing
it. The third-major and fourth-perfect versions change only oscillator two's
interval to +4 and +5 semitones. Verify both the played fundamental and the
interval partial in native renders at several pitches, as well as long holds
and chord headroom. Interval colour is intentional; a shifted sample root or
incorrect fine tune is a mapping fault.

For sampled winds, distinguish the physical source root from the key range in
which a particular performance is selected. Multiple true round robins for one
played key can come from adjacent source pitches. Use explicit per-region ranges
with `preserve_key_ranges=True`; retain each physical root and fine tune, and
exercise every take in native repeated notes. The regression fixture maps three
sources at MIDI 56, 57 and 58 to played MIDI 56 and verifies all three stay in tune.
Only measure gaps within a deliberately limited instrument range, while still
rejecting internal holes and respecting reserved articulation keys.


Test headroom at the highest recorded dynamics, not just MIDI velocity 127.
For a CC1 instrument, velocity changes loudness while the controller chooses the
recorded layer: a high-velocity chord at the default controller value may still
miss the forte recordings. Bebop's first eight-note test exposed actual clipping
in alto sax and clarinet and insufficient headroom in soprano/tenor. Balance the
new preset's output defaults and rerender both default and maximum dynamics,
keeping source performances and compiled zone audio byte-identical. Quiet brass
can be lifted only as far as the same tests allow. Document the failed initial
render separately from the corrected final evidence.

## Public replacements: pitch metadata and real differences

Check the physical octave before applying a fine-tuning estimator constrained
around the expected note. Bigcat cello's SFZ numeric keys were an octave below
the measured recording: an A1-labelled source sounded near 110 Hz (A2), while
its numeric root was 33. Searching only near the expected 55 Hz could report a
plausible small cents offset in leakage instead of exposing the wrong octave.
Inspect a broad spectrum and the harmonic family first; correct physical root
and key intervals together, then calibrate the sustained body and test native
roots, cell edges and dynamics. Do not shift independently measured harmonic
articulations or unrelated libraries merely because they share note labels.

For recorded tremolo, vibrato and ensembles, distinguish central intonation
from the strongest instantaneous spectral peak. A native A3 section tremolo had
a first-partial peak about 45 cents flat while the coherent upper-partial power
centres clustered around the expected note. Measure multiple complete sustain
cycles, compare the harmonic family and report its spread/confidence; a short
fixed window can sample different performed phases after transposition. Reject
non-finite estimates and silent cells explicitly. Do not flatten a human
performance or keep adding static corrections to chase its moving sidebands.

A replacement must retain its musical function, not just its title. For example,
use actual recorded cello harmonics for an harmonic strings programme, recorded
section tremolo for the moving strings programme, and genuine steel-string
fingerstyle/plectrum recordings for the acoustic guitar. Authored major/minor
nylon chords should document the independently recorded notes and strum timing;
do not describe assembled notes as a recorded chord performance.

Validate variation parameters themselves. Three trap-kit style labels once all
fell through to the same synthesis branch, creating identical kicks and claps.
Assert explicit style mappings and inspect authored waveform hashes and native
grooves. For compact kits, eight-note headroom tests must contain exactly eight
events, repeating the important kick/snare keys if necessary.

Infinite sustain means retaining an active musical body. An automatic loop may
select the dying tail and leave a held ensemble nearly silent after ten seconds.
Select a viable performed sustain window, join it to the same performance, and
test low, middle and high native holds through sixty seconds. If secondary
articulations force excessive shared safety attenuation, balance those actual
zones before amplifying the main programme; raising a near-silent tail can merely
raise hiss.

## Giove: continuous phrases and independent validation

The listener's priority for Trautonium is legato between MIDI keyboard notes.
Use default Legato, one voice, a moderate adjustable glide and delayed automatic
vibrato. Overlapped notes must reuse the running envelope and vibrato phase;
releasing the last-priority note returns to the previous held note. Releasing all
keys ends the phrase and permits a new attack. Test a real overlap sequence,
held-note priority, a fresh attack after rest, and zero-glide envelope continuity.
A pitch-wheel demonstration alone does not establish legato. See
`verify_giove_legato_v1.py` and `demo/giove-v1/tre-frasi-legato.flac`.

Do not silently change a whole multisample layer from automatic loops to source
loops when repairing a few cells. That removed 36 healthy steel-guitar loop
markers during the first repair. Preserve their automatic processing and opt in
only the repaired regions with `loop: {start: ..., end: ..., mode: 'source'}`.
Verify every main zone after compilation, not only the nine repaired audio files.

An octave-constrained YIN measurement cannot independently verify a physical
root. Squidpipes' long-clean map proved to be an octave below 34 measured
recordings; one recording remained ambiguous and was excluded. Use multiple
stable windows, a broad harmonic-family comparison, odd/even support and
periodicity. Record mapped and physical roots separately; exclude ambiguity
rather than converting a weak partial into a confident root.

For mallets, verify every mallet articulation and recorded dynamic separately.
Different recorded roots at pp and ff can create a missing velocity cell when
ranges are built from a global root union. A soft-mallet-only chromatic pass did
not detect the hard-mallet G4 pp gap. Native and structural coverage must include
all articulation × dynamic combinations and their cell edges. Count the actual
render events: two velocities per key mean twice as many time-indexed probes.
Report missing/non-finite measurements as failures, not only the maximum of the
remaining finite cents values. Inharmonic bars need physical-mode evidence;
narrow searches around a filename do not establish the fundamental.

Safety probes that disable attack, LFO or release are diagnostic variants.
Additionally test actual preset defaults and maximum dynamics: three register
holds through sixty seconds and exactly eight distinct notes at v127. Freeze
source hashes only after the final compile, then recheck changed presets alone.

For live Trautonium-family formants, define filter centers in absolute Hz and
keep key tracking at zero when the intended behavior is a stable vowel/formant
identity across notes and pitch-wheel bends. A pitched sample or filter whose
centers simply follow the carrier will transpose its formants and is not an
equivalent model. Validate with octave-paired notes under the same bend: compare
harmonic response ratios at fixed frequencies, not only oscillator pitch. If
CC1 controls pressure and timbre, preserve a nonzero output floor at CC1=0 so a
controller initialized at zero does not mute the patch; verify default
audibility and the measured full CC range. Model Mixtur subharmonic rows as
independent live oscillators with coherent divisors and shared glide, rather
than a frozen chord or delayed copies. Circuit/gesture profiles should be
selectable articulations with explicit per-profile parameter values and a
native equivalence test for the UI selector and MIDI keyswitch path.
