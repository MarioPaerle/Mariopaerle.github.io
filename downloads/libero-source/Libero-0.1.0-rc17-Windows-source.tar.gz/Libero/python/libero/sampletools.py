"""Editing tools for recorded material (docs/research/sample-libraries.md §7.3).

Every function takes and returns `Audio` (or plain data) and is deterministic for a seed:

- onset_trim / align_to / align_set   true-onset cutting and phase alignment across layers
- ladder                               measure and calibrate a set of dynamics layers
- release_from                         synthesise a release sample from a sustained note
- morph                                in-between dynamics layers by spectral-envelope interpolation
- freeze, granular, tape, reverse_swell, stretch_pad   design processors for hybrid layers
- split_runs                           cut a recording of several notes into single notes
"""

from __future__ import annotations

import math

import numpy as np
from scipy import signal

from . import dsp
from .audio import Audio
from .multisample import Process, align_shift, ladder_gains, true_onset


# ---------------------------------------------------------------- onsets & alignment

def onset_trim(a: Audio, pre_ms: float = 2.0, onset_db: float = -20.0) -> Audio:
    """Cut to the true onset, keeping `pre_ms` of faded pre-roll (every zone then starts alike)."""
    on = true_onset(a.data, a.sr, onset_db)
    pre = int(pre_ms * 1e-3 * a.sr)
    start = max(0, on - pre)
    out = Audio(a.data[start:], a.sr)
    k = on - start
    return out.fade_in(k / a.sr, "sine") if k > 0 else out


def align_to(a: Audio, reference: Audio, max_ms: float = 3.0, pre_ms: float = 2.0) -> tuple[Audio, int, float]:
    """Shift `a` (both assumed onset-trimmed with the same pre-roll) so its first 40 ms line up
    with `reference`. Returns (aligned audio, samples dropped (+) or padded (-), correlation)."""
    on = int(pre_ms * 1e-3 * a.sr)
    sh, c = align_shift(reference.data, a.data, a.sr, max_ms, on)
    if sh > 0:
        out = Audio(a.data[sh:], a.sr)
    elif sh < 0:
        pad = np.zeros((-sh,) + a.data.shape[1:], dtype=np.float32)
        out = Audio(np.concatenate([pad, a.data]), a.sr)
    else:
        out = a
    return out, sh, c


def align_set(layers: list[Audio], pre_ms: float = 2.0, max_ms: float = 3.0) -> tuple[list[Audio], list[dict]]:
    """Onset-trim a set of layers/takes of one note and align them to the loudest."""
    trimmed = [onset_trim(x, pre_ms) for x in layers]
    ref_i = int(np.argmax([dsp.momentary_max(x.data, x.sr) for x in trimmed]))
    out, rep = [], []
    for i, x in enumerate(trimmed):
        if i == ref_i:
            out.append(x)
            rep.append({"index": i, "shift": 0, "corr": 1.0, "reference": True})
            continue
        y, sh, c = align_to(x, trimmed[ref_i], max_ms, pre_ms)
        out.append(y)
        rep.append({"index": i, "shift": sh, "corr": round(c, 3)})
    return out, rep


# ---------------------------------------------------------------- level ladder

def ladder(layers: list[Audio], names: list[str] | None = None, peak_db: float = -3.0) -> dict:
    """Measure a dynamics ladder (softest → loudest) of one note: loudness steps, brightness steps,
    monotonicity, and the single gain that puts the loudest peak at `peak_db` (no per-file
    normalising). Returns a report; apply `gain_db` to every layer to keep their natural spread."""
    names = names or [f"L{i + 1}" for i in range(len(layers))]
    lufs = [dsp.momentary_max(x.data, x.sr) for x in layers]
    hf = []
    for x in layers:
        m = dsp.mono(x.data[: int(0.3 * x.sr)].astype(np.float64))
        S = np.abs(np.fft.rfft(m * np.hanning(len(m)))) ** 2 if len(m) > 256 else np.ones(2)
        f = np.fft.rfftfreq(len(m), 1 / x.sr) if len(m) > 256 else np.array([0.0, 1.0])
        hf.append(10 * math.log10((S[f > 4000].sum() + 1e-20) / (S.sum() + 1e-20)))
    items = [{"id": i, "root": 60, "take": 0, "axis": (i,), "lufs_max": lufs[i], "peak_db": x.peak_db}
             for i, x in enumerate(layers)]
    gains, rep = ladder_gains(items, Process(ladder="keep", peak_db=peak_db))
    steps = [round(lufs[i + 1] - lufs[i], 1) for i in range(len(lufs) - 1)]
    bsteps = [round(hf[i + 1] - hf[i], 1) for i in range(len(hf) - 1)]
    return {"layers": names, "lufs_max": [round(v, 1) for v in lufs], "steps_db": steps,
            "hf_ratio_db": [round(v, 1) for v in hf], "brightness_steps_db": bsteps,
            "monotonic_level": all(s > 0 for s in steps), "monotonic_brightness": all(s > 0 for s in bsteps),
            "gain_db": round(rep["instrument_gain_db"], 2)}


# ---------------------------------------------------------------- release synthesis

def release_from(body: Audio, kind: str = "damper", seconds: float = 0.6, at: float | None = None,
                 noise_db: float = -30.0, seed: int = 0) -> Audio:
    """A release sample made from a sustained note when none was recorded.

    kind 'damper': the string's own sound cut short (fast exponential decay, closing lowpass)
                   plus a soft felt thump; 'room': a slower, darker decay (the hall ringing out);
                   'bloom': a brief swell of the upper partials before dying (undamped strings).
    `at` = where in the body the release is taken (default: 40 % in)."""
    sr = body.sr
    t0 = body.duration * 0.4 if at is None else at
    n = int(seconds * sr)
    seg = body.trim(t0, t0 + seconds + 0.05).fit(seconds)
    t = np.arange(n) / sr
    x = seg.data.astype(np.float64)
    if kind == "damper":
        env = np.exp(-t / (seconds / 7.0))
        cut = np.geomspace(9000, 600, n)
    elif kind == "room":
        env = np.exp(-t / (seconds / 4.0))
        cut = np.geomspace(5000, 1200, n)
    elif kind == "bloom":
        env = np.exp(-t / (seconds / 5.0)) * (1 + 0.6 * np.sin(np.pi * np.clip(t / (seconds * 0.3), 0, 1)))
        cut = np.geomspace(12000, 2500, n)
    else:
        raise ValueError("kind must be 'damper', 'room' or 'bloom'")
    # time-varying lowpass in blocks
    y = np.zeros_like(x)
    zi = None
    blk = 512
    x2 = dsp.as_2d(x)
    y2 = np.zeros_like(x2)
    for s in range(0, n, blk):
        sos = signal.butter(2, min(cut[s], 0.45 * sr), fs=sr, output="sos")
        if zi is None:
            zi = np.zeros((sos.shape[0], 2, x2.shape[1]))
        y2[s:s + blk], zi = signal.sosfilt(sos, x2[s:s + blk], axis=0, zi=zi)
    y = y2[:, 0] if x.ndim == 1 else y2
    y = y * (env if y.ndim == 1 else env[:, None])
    out = Audio(y, sr).fade_in(0.003)
    if kind == "damper" and noise_db > -120:
        rng = np.random.default_rng(seed)
        k = int(0.06 * sr)
        thump = rng.standard_normal(k) * np.exp(-np.arange(k) / (0.012 * sr))
        th = Audio(thump, sr).lowpass(900).highpass(60)
        th = th.normalize_rms(out.rms_db + noise_db + 12)
        out = out.mix(th.to_stereo() if out.is_stereo else th)
    return out.fade_out(min(0.05, seconds / 4))


# ---------------------------------------------------------------- layer morph

def morph(a: Audio, b: Audio, n: int = 1, n_fft: int = 2048) -> list[Audio]:
    """`n` in-between dynamics layers from a (soft) to b (loud): the spectral envelope and level
    are interpolated in the log domain frame by frame; phases come from the nearer source.
    Align the two first (align_set), or the blend will comb."""
    sr = a.sr
    b = b.resample(sr)
    L = min(a.n, b.n)
    stereo = a.is_stereo or b.is_stereo
    xa = (a.to_stereo() if stereo else a).data[:L].astype(np.float64)
    xb = (b.to_stereo() if stereo else b).data[:L].astype(np.float64)
    xa2, xb2 = dsp.as_2d(xa), dsp.as_2d(xb)
    hop = n_fft // 4
    outs = []
    for k in range(1, n + 1):
        w = k / (n + 1)
        chans = []
        for c in range(xa2.shape[1]):
            _, _, A = signal.stft(xa2[:, c], sr, nperseg=n_fft, noverlap=n_fft - hop)
            _, _, B = signal.stft(xb2[:, c], sr, nperseg=n_fft, noverlap=n_fft - hop)
            mag = np.exp((1 - w) * np.log(np.abs(A) + 1e-9) + w * np.log(np.abs(B) + 1e-9))
            ph = np.angle(A) if w < 0.5 else np.angle(B)
            _, y = signal.istft(mag * np.exp(1j * ph), sr, nperseg=n_fft, noverlap=n_fft - hop)
            chans.append(y[:L])
        y = np.stack(chans, axis=1) if len(chans) > 1 else chans[0]
        outs.append(Audio(y, sr))
    return outs


# ---------------------------------------------------------------- design processors

def freeze(a: Audio, at: float, seconds: float = 6.0, width_s: float = 0.25, seed: int = 0) -> Audio:
    """Spectral freeze: the magnitude around time `at` (averaged over `width_s`) held for `seconds`
    with drifting random phases: a steady drone of that moment of the sound."""
    sr = a.sr
    n_fft = 4096
    hop = n_fft // 4
    rng = np.random.default_rng(seed)
    x2 = dsp.as_2d(a.data.astype(np.float64))
    i0 = int(max(0, (at - width_s / 2)) * sr)
    seg = x2[i0: i0 + max(n_fft, int(width_s * sr))]
    frames = int(seconds * sr / hop) + 4
    win = np.hanning(n_fft)
    out = np.zeros((frames * hop + n_fft, x2.shape[1]))
    for c in range(x2.shape[1]):
        _, _, S = signal.stft(seg[:, c], sr, nperseg=n_fft, noverlap=n_fft - hop)
        mag = np.mean(np.abs(S), axis=1)
        phase = rng.uniform(0, 2 * np.pi, len(mag))
        omega = 2 * np.pi * np.arange(len(mag)) * hop / n_fft
        for f in range(frames):
            phase = phase + omega + rng.normal(0, 0.3, len(mag))
            fr = np.fft.irfft(mag * np.exp(1j * phase), n_fft) * win
            out[f * hop: f * hop + n_fft, c] += fr
    out = out[n_fft: n_fft + int(seconds * sr)]
    y = out[:, 0] if a.data.ndim == 1 else out
    return Audio(y, sr).normalize_rms(a.trim(at - width_s / 2, at + width_s / 2).rms_db).fade_in(0.05).fade_out(0.2)


def granular(a: Audio, seconds: float = 8.0, grain_ms: float = 90.0, density: float = 40.0, position: float = 0.5,
             spread: float = 0.2, jitter_cents: float = 15.0, reverse_p: float = 0.2, stereo: bool = True,
             seed: int = 0) -> Audio:
    """A granular cloud: `density` grains per second of `grain_ms`, read around `position` (0..1 of
    the source) ± `spread`, each detuned by up to `jitter_cents`, some reversed, panned randomly."""
    sr = a.sr
    rng = np.random.default_rng(seed)
    src = a.to_mono().data.astype(np.float64)
    g = max(32, int(grain_ms * 1e-3 * sr))
    n = int(seconds * sr)
    out = np.zeros((n + 2 * g, 2 if stereo else 1))
    win = np.hanning(g)
    count = int(density * seconds)
    for _ in range(count):
        center = np.clip(position + rng.uniform(-spread, spread), 0, 1)
        s = int(center * max(1, len(src) - 2 * g))
        ratio = 2 ** (rng.uniform(-jitter_cents, jitter_cents) / 1200)
        span = int(g * ratio) + 2
        chunk = src[s: s + span]
        if len(chunk) < 4:
            continue
        grain = np.interp(np.linspace(0, len(chunk) - 1, g), np.arange(len(chunk)), chunk) * win
        if rng.random() < reverse_p:
            grain = grain[::-1]
        at = int(rng.uniform(0, n))
        if stereo:
            p = rng.uniform(-0.8, 0.8)
            th = (p + 1) * np.pi / 4
            out[at: at + g, 0] += grain * math.cos(th)
            out[at: at + g, 1] += grain * math.sin(th)
        else:
            out[at: at + g, 0] += grain
    y = out[:n]
    y = y[:, 0] if not stereo else y
    return Audio(y, sr).normalize_rms(a.rms_db).fade_in(0.1).fade_out(0.3)


def tape(a: Audio, wow: float = 0.3, flutter: float = 0.2, sat: float = 0.3, age: float = 0.3, seed: int = 0) -> Audio:
    """Resample through a worn tape: slow wow and fast flutter (variable read speed), saturation,
    high-frequency loss and hiss growing with `age`. Offline, so it can be baked into zones."""
    sr = a.sr
    rng = np.random.default_rng(seed)
    x2 = dsp.as_2d(a.data.astype(np.float64))
    n = len(x2)
    t = np.arange(n) / sr
    k = max(4, int(a.duration * 0.8) + 4)
    wow_c = 18 * wow * np.interp(t, np.linspace(0, t[-1] + 1e-9, k), rng.standard_normal(k))
    wow_c += 10 * wow * np.sin(2 * np.pi * 0.55 * t)
    flut = 3 * flutter * np.sin(2 * np.pi * 6.3 * t + rng.uniform(0, 6)) + 1.5 * flutter * np.sin(2 * np.pi * 11.7 * t)
    rate = 2 ** ((wow_c + flut) / 1200)
    pos = np.cumsum(rate) - rate[0]
    pos = np.clip(pos, 0, n - 1)
    y = np.stack([np.interp(pos, np.arange(n), x2[:, c]) for c in range(x2.shape[1])], axis=1)
    out = Audio(y[:, 0] if a.data.ndim == 1 else y, sr)
    if sat > 0:
        out = out.saturate(sat * 0.8)
    if age > 0:
        out = out.lowpass(16000 - 10000 * age, q=0.6).highpass(30 + 50 * age)
        out = out.noise_floor(out.rms_db - 50 + 20 * age, "pink", seed=seed)
    return out


def reverse_swell(a: Audio, seconds: float = 2.0, ir: Audio | None = None) -> Audio:
    """A reversed swell that rises into the note: the sound's reverberated tail, reversed,
    ending exactly where `a` begins (place it at -seconds before the note)."""
    from . import synth

    ir = ir or synth.impulse_response("hall", seconds=min(4.0, seconds * 1.5), sr=a.sr)
    wet = a.trim(0, min(a.duration, 1.0)).convolve(ir, mix=1.0)
    rev = wet.reverse().trim(-seconds) if wet.duration > seconds else wet.reverse()
    return rev.fade_in(min(0.3, seconds / 3), "exp").fade_out(0.01)


def stretch_pad(a: Audio, factor: float = 4.0, at: float = 0.2, seconds: float = 1.0) -> Audio:
    """Stretch a slice of the sound into a slow pad (phase vocoder), with gentle fades."""
    seg = a.trim(at, at + seconds)
    return seg.stretch(factor).fade_in(min(0.5, seg.duration * factor / 4)).fade_out(0.5)


# ---------------------------------------------------------------- note splitting

def split_runs(a: Audio, first_note: int | str | None = None, step: int = 1, min_gap_s: float = 0.25,
               threshold_db: float = -35.0) -> list[tuple[int | None, Audio]]:
    """Cut a recording of several separate notes (e.g. an Iowa chromatic run) into single notes.
    Notes are separated where the envelope drops below peak + threshold_db for `min_gap_s`.
    Each note gets its detected MIDI note, or first_note + i*step when given."""
    sr = a.sr
    m = dsp.mono(a.data.astype(np.float64))
    t, e = dsp.rms_envelope(m, sr, 0.01)
    if len(e) == 0:
        return []
    on = e > e.max() * 10 ** (threshold_db / 20)
    segs = []
    i = 0
    gap = int(min_gap_s / (t[1] - t[0])) if len(t) > 1 else 1
    while i < len(on):
        if on[i]:
            j = i
            quiet = 0
            while j < len(on) and quiet < gap:
                quiet = quiet + 1 if not on[j] else 0
                j += 1
            segs.append((int(max(0, t[i] - 0.02) * sr), int(min(a.duration, t[min(j, len(t) - 1)]) * sr)))
            i = j
        else:
            i += 1
    out = []
    base = None if first_note is None else dsp.parse_note(first_note)
    for k, (s0, s1) in enumerate(segs):
        seg = Audio(a.data[s0:s1], sr).fade_out(0.05)
        if base is not None:
            note = base + k * step
        else:
            f = seg.f0()
            note = int(round(dsp.freq_to_midi(f))) if np.isfinite(f) else None
        out.append((note, seg))
    return out
