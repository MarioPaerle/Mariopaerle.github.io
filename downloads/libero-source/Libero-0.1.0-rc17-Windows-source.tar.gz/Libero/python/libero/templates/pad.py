"""Warm pad: detuned band-limited saws, a gentle lowpass, slow vowel colour,
a breathy air bed and a seamless sustain loop."""

from libero import Sound, synth

sound = Sound(
    title="__TITLE__",
    subtitle="__SUBTITLE__",
    tags=["pad", "warm", "sustained"],
    roots=[36, 48, 60, 72, 84],
    velocities=[100],
    sample_rate=48000,
)

DETUNE = [-11.0, -4.0, 0.0, 5.0, 12.0]  # cents
PANS = [-0.7, -0.3, 0.0, 0.35, 0.75]
LOOP_S = 4.0


@sound.body
def body(ctx):
    # every voice and LFO sits on a 4 s grid, so the sustain loops with no seam
    g = synth.LoopGrid(ctx.freq, LOOP_S, ctx.sr)
    dur = 1.5 + 2 * g.seconds
    out = None
    for i, (c, p) in enumerate(zip(DETUNE, PANS)):
        f = synth.vibrato(g.cents(c), rate=g.rate(0.25 * (1 + i % 2)), cents=3.0, delay=0.0)
        v = synth.saw(f, dur, sr=ctx.sr, phase=(0.37 * i) % 1.0).pan(p)
        out = v if out is None else out.mix(v)
    out = out.lowpass(min(9000, ctx.freq * 10 + 1500), q=0.6, order=2)
    L = g.seconds
    out = synth.formant(out, [(0, "a"), (L / 2, "o"), (L, "a"), (1.5 * L, "o"), (2 * L, "a")], amount=0.35)
    return out.normalize_loudness(-18)


@sound.air
def air(ctx):
    return synth.breath(8.0, sr=ctx.sr, seed=4, brightness=0.4, motion=0.4).normalize_rms(-36)


@sound.impulse
def ir(ctx):
    return synth.impulse_response("hall", sr=ctx.sr, seed=9, t60=4.0)


sound.loop(body=True, min_seconds=3.0, region=(1.2, 1.5 + 2 * LOOP_S))
sound.defaults(amp_attack=900, amp_decay=2000, amp_sustain=0.9, amp_release=2500, rev_mode="Basilica",
               rev_mix=0.35, flt_mode="Basso", flt_cutoff=6000, lvl_air=-20, width=1.3)
