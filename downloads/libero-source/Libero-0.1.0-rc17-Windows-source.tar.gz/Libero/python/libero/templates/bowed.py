"""Bowed string: friction-driven waveguide with a wooden body, delayed
vibrato, a rosin scrape at the start and a looped sustain."""

from libero import Sound, synth

sound = Sound(
    title="__TITLE__",
    subtitle="__SUBTITLE__",
    tags=["bowed", "string", "sustained"],
    roots=[36, 43, 50, 57, 64, 71, 78],
    velocities=[100],
    sample_rate=48000,
)


@sound.body
def body(ctx):
    s = synth.bow(ctx.freq, dur=5.0, pressure=0.45, bright=0.45 + 0.25 * ctx.register, attack=0.18,
                  release=0.0, vibrato_cents=9.0, sr=ctx.sr, seed=ctx.seed)
    return s.lowpass(9000).normalize_loudness(-18)


@sound.attack
def attack(ctx):
    scrape = synth.noise("pink", 0.12, sr=ctx.sr, seed=ctx.seed).bandpass(1800, q=0.8)
    return scrape.envelope([(0, 0), (0.01, 1), (0.05, 0.3), (0.12, 0)]).normalize(-20)


@sound.impulse
def ir(ctx):
    return synth.impulse_response("hall", sr=ctx.sr, seed=4, t60=2.2)


sound.loop(body=True, min_seconds=1.0, region=(1.2, 4.9))
sound.defaults(amp_attack=120, amp_sustain=1.0, amp_release=500, rev_mode="Cappella", rev_mix=0.25,
               res_mode="Legno", res_mix=0.15)
