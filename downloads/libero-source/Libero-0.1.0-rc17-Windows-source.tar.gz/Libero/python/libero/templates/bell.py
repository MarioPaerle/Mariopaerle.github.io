"""Struck bell: an inharmonic modal body (church-bell partials) with slight
per-mode detuning for a slow warble, a hard mallet tick, and a long hall."""

from libero import Sound, synth

sound = Sound(
    title="__TITLE__",
    subtitle="__SUBTITLE__",
    tags=["bell", "mallet", "inharmonic"],
    roots=[48, 60, 72, 84],
    velocities=[64, 110],
    sample_rate=48000,
)


@sound.body
def body(ctx):
    # the bell's 'strike note' is its nominal (ratio 2), so voice the modes an octave down
    hard = 0.35 + 0.55 * ctx.vel
    b = synth.modal(ctx.freq / 2, "bell", dur=7.0 - 2.5 * ctx.register, hardness=hard, detune_cents=3.0,
                    decay_scale=1.3, sr=ctx.sr, seed=ctx.seed, stereo=True)
    return b.lowpass(9000 + 7000 * ctx.vel).normalize(-3 - 6 * (1 - ctx.vel))


@sound.attack
def attack(ctx):
    tick = synth.noise("blue", 0.02, sr=ctx.sr, seed=ctx.seed).highpass(2500)
    return tick.envelope([(0, 0), (0.0003, 1), (0.02, 0)]).normalize(-14 - 8 * (1 - ctx.vel))


@sound.impulse
def ir(ctx):
    return synth.impulse_response("hall", sr=ctx.sr, seed=2)


sound.defaults(amp_attack=0, amp_decay=6000, amp_sustain=0.0, amp_release=2500, rev_mode="Basilica",
               rev_mix=0.3, rev_decay=5.0, res_mode="Metallo", res_mix=0.08)
