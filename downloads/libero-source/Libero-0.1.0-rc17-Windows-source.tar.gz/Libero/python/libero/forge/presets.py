"""Twenty documented starting patches. Each function returns a fresh `Patch` you can edit
(`p.set('filter1.cutoff', 900)`, `p.oscs[0].unison = 5`) or use as is:

    from libero import forge
    a = forge.presets.reese_bass().render('E1', 110, 2.0)
    sound.body(forge.layer(forge.presets.pluck(), duration=1.5))

`catalog()` lists name -> (note low, note high, description). Macros are labelled in `patch.macro_labels`.
All presets are original constructions from the primitives in this library.
"""

from __future__ import annotations

from . import fx as F
from .filters import Filter
from .modulation import LFO, Env, Mod
from .osc import Noise, Osc, Sub
from .patch import Patch, Voice


def trap_808() -> Patch:
    """Trap 808 bass: sine with a fast pitch drop, long exponential tail, mild tube saturation so it
    survives small speakers. Roots 24-52 (C1-E3). Macro1 = saturation amount."""
    return Patch(
        "trap_808", description="808 sub bass: pitch-dropped sine, long decay, tube saturation.", tags=["bass", "trap", "808"],
        note_range=(24, 52),
        oscs=[Osc("sine", level=1.0), Osc("tri", level=0.18, rand_phase=0.0)],
        filters=[Filter("lp24", cutoff=2600, res=0.0)],
        envs=[Env(0.002, 1.6, 0.0, 0.28, curves=(-0.5, -0.45, -0.6)), Env(0.0, 0.12, 0.0, 0.05, curves=(0, -0.5, -0.5)), Env(), Env()],
        mods=[Mod("env2", "osc1.pitch", 0.19), Mod("env2", "osc2.pitch", 0.19), Mod("macro1", "fx1.drive", 0.5)],
        macros={"macro1": 0.0}, macro_labels={"macro1": "saturation"},
        fx=[F.Distortion("tube", drive=0.22, tone=5000.0, mix=1.0), F.EQ([("highpass", 24.0, 0, 0.7)])],
        volume_db=-6.2, vel_amp=0.3)


def reese_bass() -> Patch:
    """Reese bass: detuned saws beating against each other, dark filter drifting slowly, grit and chorus.
    Roots 24-52. Macro1 = filter brightness."""
    return Patch(
        "reese_bass", description="Detuned saw stack with phasing beat, slow filter drift, soft distortion; DnB/neuro/dark house.",
        tags=["bass", "reese", "dnb"], note_range=(24, 52),
        oscs=[Osc("saw", unison=3, detune=0.24, blend=0.9, spread=0.7), Osc("saw", unison=2, detune=0.18, level=0.7, spread=0.5)],
        sub=Sub("sine", -1, 0.35),
        filters=[Filter("lp24", cutoff=620, res=0.18, drive=0.1, keytrack=0.35)],
        envs=[Env(0.004, 0.3, 0.9, 0.25), Env(), Env(), Env()],
        lfos=[LFO("tri", rate=0.21, mode="free"), LFO("sine", rate=0.07, mode="free"), LFO(), LFO()],
        mods=[Mod("lfo1", "filter1.cutoff", 0.05), Mod("lfo2", "filter1.cutoff", 0.04), Mod("macro1", "filter1.cutoff", 0.35, bipolar=True)],
        macros={"macro1": 0.5}, macro_labels={"macro1": "brightness"},
        fx=[F.Distortion("soft", drive=0.28, tone=7000.0, mix=0.7), F.Chorus(rate=0.3, depth=2.5, mix=0.3),
            F.Compressor(-16.0, 3.0, 10.0, 150.0, 6.0, 2.0)],
        volume_db=-1.4)


def supersaw_lead() -> Patch:
    """Trance/pop supersaw lead: two 9/7-voice saw stacks, hyper, synced ping-pong delay and plate. Roots 48-96."""
    return Patch(
        "supersaw_lead", description="Wide detuned saw lead (16 voices) with hyper, 1/8 delay and plate; trance, future bass chords.",
        tags=["lead", "supersaw", "chords"], note_range=(48, 96),
        oscs=[Osc("saw", unison=9, detune=0.34, blend=0.85, spread=1.0), Osc("saw", unison=7, detune=0.28, fine=7, level=0.7, spread=0.9)],
        filters=[Filter("lp12", cutoff=5500, res=0.1, keytrack=0.6)],
        envs=[Env(0.006, 0.4, 0.85, 0.35), Env(0.01, 0.5, 0.2, 0.3), Env(), Env()],
        mods=[Mod("env2", "filter1.cutoff", 0.08), Mod("velocity", "filter1.cutoff", 0.08)],
        fx=[F.Hyper(0.3, 0.3, 6, 1.0, 0.35), F.Delay(sync="1/8", feedback=0.38, mix=0.22, mode="pingpong"),
            F.Reverb("plate", decay=1.6, mix=0.2)],
        volume_db=-4.7)


def pluck() -> Patch:
    """Pluck: saw + square with a filter that snaps shut, short body, chorus and small room. Roots 48-96."""
    return Patch(
        "pluck", description="Bright synth pluck, filter envelope closes in 250 ms; arps, melodies, EDM chords.",
        tags=["pluck", "arp"], note_range=(48, 96),
        oscs=[Osc("saw", unison=3, detune=0.1, level=0.9), Osc("square", fine=-4, level=0.5, unison=2, detune=0.08)],
        filters=[Filter("lp24", cutoff=700, res=0.12, keytrack=0.7)],
        envs=[Env(0.001, 0.55, 0.0, 0.18, curves=(0, -0.55, -0.6)), Env(0.001, 0.28, 0.0, 0.2, curves=(0, -0.7, -0.5)), Env(), Env()],
        mods=[Mod("env2", "filter1.cutoff", 0.42), Mod("velocity", "filter1.cutoff", 0.1)],
        fx=[F.Chorus(0.5, 2.5, 12.0, 2, 1.0, 0.0, 0.3), F.Reverb("room", decay=0.9, mix=0.15)], volume_db=0.0)


def warm_pad() -> Patch:
    """Warm analog-style pad: slow attack, detuned saws and triangle, drifting low-pass, chorus, phaser, hall. Roots 36-84."""
    return Patch(
        "warm_pad", description="Slow-attack warm pad with gently moving filter and hall; underlays, ambient, ballads.",
        tags=["pad", "warm"], note_range=(36, 84),
        oscs=[Osc("saw", unison=6, detune=0.22, blend=0.8, spread=0.9, level=0.8), Osc("tri", unison=2, detune=0.1, octave=-1, level=0.6)],
        filters=[Filter("lp12", cutoff=1700, res=0.08, keytrack=0.5)],
        envs=[Env(1.1, 1.0, 0.85, 1.9), Env(), Env(), Env()],
        lfos=[LFO("sine", rate=0.17, mode="free"), LFO("tri", rate=0.09, mode="free", phase=0.3), LFO(), LFO()],
        mods=[Mod("lfo1", "filter1.cutoff", 0.06), Mod("lfo2", "osc1.detune", 0.05)],
        fx=[F.Chorus(0.4, 3.0, 15.0, 3, 1.0, 0.0, 0.35), F.Phaser(0.12, 900.0, 1.0, 4, 0.2, 0.3, 0.2),
            F.Reverb("hall", decay=4.5, mix=0.32, damping=0.5)],
        volume_db=-0.4, vel_amp=0.25)


def vocal_formant_lead() -> Patch:
    """Vocal/choir lead: wavetable that morphs a-e-i-o-u (macro1 = vowel), formant filter reinforcing it,
    delayed vibrato, plate reverb. Roots 48-84."""
    return Patch(
        "vocal_formant_lead", description="Singing lead: vowel table + formant filter; macro1 picks the vowel (a e i o u).",
        tags=["lead", "vocal", "formant"], note_range=(48, 84),
        oscs=[Osc("vocal", pos=0.0, unison=3, detune=0.12, spread=0.5, level=0.9), Osc("saw", level=0.25)],
        filters=[Filter("formant", cutoff=1000.0, res=0.3, morph=0.0, mix=0.55)],
        envs=[Env(0.05, 0.3, 0.9, 0.3), Env(), Env(), Env()],
        lfos=[LFO("sine", rate=5.4, mode="trig", delay=0.15, fade=0.5), LFO(), LFO(), LFO()],
        mods=[Mod("macro1", "osc1.pos", 1.0), Mod("macro1", "filter1.morph", 1.0), Mod("lfo1", "pitch", 0.0018)],
        macros={"macro1": 0.0}, macro_labels={"macro1": "vowel a-e-i-o-u"},
        fx=[F.Chorus(0.35, 2.0, 14.0, 2, 1.0, 0.0, 0.2), F.Reverb("plate", decay=2.0, mix=0.22)], volume_db=4.7)


def fm_bell() -> Patch:
    """Bell/FM electric-piano keys: sine carrier phase-modulated by an inharmonic sine whose index decays. Roots 48-100."""
    return Patch(
        "fm_bell", description="FM bell / DX-style keys; index decays so the strike is bright and the ring is pure.",
        tags=["bell", "fm", "keys"], note_range=(48, 100),
        oscs=[Osc("sine", warp1="fm", warp1_amount=0.02, fm_src=1, level=0.9, unison=2, detune=0.05, spread=0.4),
              Osc("sine", octave=1, semi=9.67, level=0.0, rand_phase=0.0)],
        envs=[Env(0.001, 3.8, 0.0, 1.4, curves=(0, -0.35, -0.6)), Env(0.001, 1.1, 0.0, 0.5, curves=(0, -0.6, -0.5)), Env(), Env()],
        mods=[Mod("env2", "osc1.warp1", 0.22), Mod("velocity", "osc1.warp1", 0.08)],
        fx=[F.Chorus(0.25, 1.5, 12.0, 2, 0.8, 0.0, 0.2), F.Reverb("hall", decay=3.2, mix=0.25)], volume_db=3.4, vel_amp=0.5)


def lofi_keys_tape() -> Patch:
    """Lo-fi keys: soft triangle/sine electric piano through slow chorus, tape wow/flutter/saturation/age and vinyl.
    Roots 40-88. Macro1 = tape age (more wobble, darker)."""
    return Patch(
        "lofi_keys_tape", description="Dusty tape piano for lo-fi hip hop; wow, flutter, hiss, vinyl crackle.",
        tags=["keys", "lofi", "tape"], note_range=(40, 88),
        oscs=[Osc("tri", unison=2, detune=0.08, spread=0.5, level=0.8), Osc("sine", octave=1, level=0.18, warp1="fm", warp1_amount=0.08, fm_src=0)],
        filters=[Filter("lp12", cutoff=3200, res=0.05, keytrack=0.4)],
        envs=[Env(0.004, 1.3, 0.25, 0.5), Env(0.001, 0.4, 0.0, 0.3), Env(), Env()],
        mods=[Mod("env2", "filter1.cutoff", 0.1), Mod("macro1", "fx3.age", 0.7), Mod("macro1", "fx3.wow", 0.3)],
        macros={"macro1": 0.0}, macro_labels={"macro1": "tape age"},
        fx=[F.Chorus(0.28, 3.0, 15.0, 2, 1.0, 0.0, 0.35), F.Distortion("soft", drive=0.12, mix=0.5, tone=9000.0),
            F.Tape(wow=0.3, flutter=0.25, saturation=0.4, age=0.35, bump=2.0, hiss_db=-56.0),
            F.Vinyl(crackle=0.45, pops=0.25, hiss_db=-60.0, rumble_db=-60.0, wear=0.3, warp=0.0, level_db=-40.0, mono_bass=False),
            F.Reverb("room", decay=1.1, mix=0.12)], volume_db=-6.9)


def wobble_bass() -> Patch:
    """Dubstep wobble: saw+square into a resonant 24 dB low-pass swung by a 1/8-synced LFO, with grit.
    Roots 24-52. Macro1 = wobble depth; set the tempo with `p.bpm = 140`."""
    return Patch(
        "wobble_bass", description="Tempo-synced LFO wobble bass; macro1 scales the wobble depth; 'p.bpm' sets the speed.",
        tags=["bass", "wobble", "dubstep"], note_range=(24, 52), bpm=140.0,
        oscs=[Osc("saw", unison=2, detune=0.2, level=0.8), Osc("square", octave=-1, level=0.6)],
        sub=Sub("sine", -1, 0.3),
        filters=[Filter("lp24", cutoff=230, res=0.42, drive=0.25)],
        envs=[Env(0.003, 0.2, 1.0, 0.12), Env(), Env(), Env()],
        lfos=[LFO("sine", sync="1/8", mode="trig"), LFO(), LFO(), LFO()],
        mods=[Mod("lfo1", "filter1.cutoff", 0.24, aux="macro1")],
        macros={"macro1": 1.0}, macro_labels={"macro1": "wobble depth"},
        fx=[F.Distortion("hard", drive=0.18, tone=8000.0, mix=0.55), F.MultibandComp(depth=0.35), F.EQ([("highpass", 28.0, 0, 0.7)])],
        volume_db=-8.0)


def riser_whoosh() -> Patch:
    """Riser/whoosh: noise and a rising saw cluster through a band-pass that sweeps up over the note.
    The sweep length follows env1/env2 attack: use `presets.riser(seconds)` to fit it."""
    return Patch(
        "riser_whoosh", description="Build-up riser: noise + rising saw, band-pass sweep, phaser and reverb. Fit with presets.riser(seconds).",
        tags=["fx", "riser", "whoosh"], note_range=(48, 72),
        oscs=[Osc("saw", unison=8, detune=0.5, level=0.5, spread=1.0), Osc("noise_cycle", level=0.3, unison=2, detune=0.8)],
        noise=Noise("white", level=0.9, gain_db=-12.0),
        filters=[Filter("bp12", cutoff=300, res=0.35)],
        envs=[Env(2.5, 0.2, 1.0, 0.8, curves=(0.4, -0.5, -0.5)), Env(3.0, 0.2, 1.0, 0.5, curves=(0.5, 0, 0)), Env(), Env()],
        mods=[Mod("env2", "filter1.cutoff", 0.55), Mod("env2", "pitch", 0.125), Mod("env2", "osc1.detune", 0.2)],
        fx=[F.Phaser(0.3, 1200.0, 1.5, 6, 0.4, 0.3, 0.3), F.Reverb("hall", decay=3.0, mix=0.3)], volume_db=3.0)


def impact() -> Patch:
    """Cinematic impact/boom: pitch-dropped sub, a burst of filtered noise, huge reverb, compression.
    Roots 24-48; hold ~0.2 s."""
    return Patch(
        "impact", description="Hit/boom for transitions: sub drop + noise crack + 4 s hall.", tags=["fx", "impact", "boom"],
        note_range=(24, 48),
        oscs=[Osc("sine", level=1.0), Osc("tri", octave=1, level=0.25, unison=2, detune=0.3)],
        noise=Noise("pink", level=0.0, gain_db=-8.0),
        filters=[Filter("lp12", cutoff=900, res=0.0)],
        envs=[Env(0.001, 2.2, 0.0, 0.4, curves=(0, -0.5, -0.5)), Env(0.0, 0.35, 0.0, 0.2, curves=(0, -0.7, -0.5)),
              Env(0.0, 0.18, 0.0, 0.1, curves=(0, -0.7, -0.5)), Env()],
        mods=[Mod("env2", "osc1.pitch", 0.25), Mod("env2", "filter1.cutoff", 0.4), Mod("env3", "noise.level", 0.8)],
        fx=[F.Distortion("soft", drive=0.35, tone=6000.0), F.Reverb("hall", decay=4.0, mix=0.45, damping=0.5),
            F.Compressor(-18.0, 4.0, 3.0, 220.0, 6.0, 3.0)], volume_db=-6.7, vel_amp=0.3)


def sub_drop() -> Patch:
    """Sub drop: pure sine gliding down 3 octaves in ~1.2 s. Transitions; roots 24-48 (it starts 36 st above the note)."""
    return Patch(
        "sub_drop", description="Falling sine sweep (sub drop), clean.", tags=["fx", "sub", "drop"], note_range=(24, 48),
        oscs=[Osc("sine")],
        envs=[Env(0.0, 0.1, 1.0, 0.25), Env(0.0, 1.2, 0.0, 0.2, curves=(0, -0.35, -0.5)), Env(), Env()],
        mods=[Mod("env2", "osc1.pitch", 0.375)],
        fx=[F.EQ([("highpass", 22.0, 0.0, 0.7)])], volume_db=-1.0, vel_amp=0.2)


def acid_bass() -> Patch:
    """Acid 303 line: saw, diode ladder with high resonance and a fast filter envelope, legato glide. Use render_phrase."""
    return Patch(
        "acid_bass", description="TB-303-flavoured acid bass: legato glide, squelchy resonant diode ladder.", tags=["bass", "acid", "303"],
        note_range=(28, 60), voice=Voice("legato", glide=0.07, glide_shape="exp"),
        oscs=[Osc("saw", level=1.0, rand_phase=0.0)],
        filters=[Filter("diode", cutoff=420, res=0.72, drive=0.2, keytrack=0.4)],
        envs=[Env(0.002, 0.25, 0.65, 0.08), Env(0.0, 0.22, 0.0, 0.1, curves=(0, -0.6, -0.5)), Env(), Env()],
        mods=[Mod("env2", "filter1.cutoff", 0.38), Mod("velocity", "filter1.cutoff", 0.1)],
        fx=[F.Distortion("soft", drive=0.2, tone=9000.0, mix=0.6), F.Delay(sync="1/8.", feedback=0.3, mix=0.15, mode="stereo")],
        volume_db=4.5)


def pwm_strings() -> Patch:
    """PWM string ensemble: pulse-width table swept by slow LFOs, chorus-heavy, slow attack. Roots 40-88."""
    return Patch(
        "pwm_strings", description="Vintage string-machine pad using a PWM table and chorus.", tags=["pad", "strings", "pwm"],
        note_range=(40, 88),
        oscs=[Osc("pwm", pos=0.1, unison=4, detune=0.18, spread=0.9, level=0.8), Osc("saw", unison=2, detune=0.1, level=0.35)],
        filters=[Filter("lp12", cutoff=3800, res=0.05, keytrack=0.5)],
        envs=[Env(0.35, 0.8, 0.85, 0.9), Env(), Env(), Env()],
        lfos=[LFO("sine", rate=0.4, mode="free"), LFO("sine", rate=0.27, mode="free", phase=0.5), LFO(), LFO()],
        mods=[Mod("lfo1", "osc1.pos", 0.28), Mod("lfo2", "osc1.detune", 0.04)],
        fx=[F.Chorus(0.5, 3.5, 16.0, 4, 1.0, 0.0, 0.5), F.Reverb("hall", decay=3.0, mix=0.22)], volume_db=-1.2, vel_amp=0.25)


def evolving_pad() -> Patch:
    """Evolving digital pad: morphing wavetable position (slow LFOs + macro), warp and hyper, long hall. Roots 36-84."""
    return Patch(
        "evolving_pad", description="Glassy morphing pad: position and warp drift continuously; macro1 = brightness/morph.",
        tags=["pad", "ambient", "evolving"], note_range=(36, 84),
        oscs=[Osc("digital", pos=0.2, unison=5, detune=0.2, spread=1.0, warp1="remap", warp1_amount=0.1),
              Osc("fm", pos=0.1, octave=1, unison=3, detune=0.15, level=0.4, warp1="bend+-", warp1_amount=0.55)],
        filters=[Filter("lp12", cutoff=4200, res=0.1, keytrack=0.5)],
        envs=[Env(1.6, 1.0, 0.9, 2.5), Env(), Env(), Env()],
        lfos=[LFO("sine", rate=0.11, mode="free"), LFO("tri", rate=0.07, mode="free", phase=0.25), LFO("smooth", rate=0.4, mode="free"), LFO()],
        mods=[Mod("lfo1", "osc1.pos", 0.3), Mod("lfo2", "osc2.pos", 0.25), Mod("lfo3", "osc1.warp1", 0.12),
              Mod("macro1", "osc1.pos", 0.5), Mod("macro1", "filter1.cutoff", 0.15)],
        macros={"macro1": 0.3}, macro_labels={"macro1": "morph / brightness"},
        fx=[F.Hyper(0.25, 0.35, 6, 1.0, 0.3), F.Reverb("hall", decay=6.0, mix=0.4, damping=0.45)], volume_db=-4.2, vel_amp=0.25)


def organ_keys() -> Patch:
    """Drawbar-style organ with percussive click and rotary-like phaser/chorus. Roots 36-84."""
    return Patch(
        "organ_keys", description="Electric organ: additive drawbar table, key click, rotary-flavoured modulation.",
        tags=["keys", "organ"], note_range=(36, 84),
        oscs=[Osc("organ", pos=0.0, unison=2, detune=0.03, level=0.9, rand_phase=0.0), Osc("sine", octave=1, level=0.15, rand_phase=0.0)],
        filters=[Filter("lp12", cutoff=7000, res=0.0, keytrack=0.5)],
        envs=[Env(0.004, 0.2, 1.0, 0.07), Env(0.0, 0.03, 0.0, 0.02), Env(), Env()],
        mods=[Mod("env2", "filter1.cutoff", 0.15)],
        fx=[F.Distortion("tube", drive=0.12, mix=0.6, tone=9000.0), F.Phaser(0.8, 1200.0, 0.6, 4, 0.2, 0.5, 0.35),
            F.Chorus(0.9, 1.5, 9.0, 2, 1.0, 0.0, 0.3), F.Reverb("room", decay=1.0, mix=0.12)], volume_db=-1.1)


def hoover_lead() -> Patch:
    """Rave hoover: stacked saws with a pitch dive at the start, bend warp and heavy chorus. Roots 36-72."""
    return Patch(
        "hoover_lead", description="1990s rave hoover: dive-in pitch envelope, wobbling bend warp, wide unison.",
        tags=["lead", "rave", "hoover"], note_range=(36, 72),
        oscs=[Osc("saw", unison=8, detune=0.5, spread=1.0, warp1="bend+-", warp1_amount=0.6),
              Osc("saw", unison=6, detune=0.42, octave=-1, level=0.7, warp1="remap", warp1_amount=0.2)],
        filters=[Filter("lp24", cutoff=4800, res=0.2, keytrack=0.4)],
        envs=[Env(0.02, 0.4, 0.9, 0.3), Env(0.0, 0.18, 0.0, 0.1, curves=(0, -0.6, -0.5)), Env(), Env()],
        lfos=[LFO("sine", rate=3.5, mode="free"), LFO(), LFO(), LFO()],
        mods=[Mod("env2", "pitch", 0.08), Mod("lfo1", "osc1.warp1", 0.2)],
        fx=[F.Chorus(0.7, 4.0, 15.0, 4, 1.0, 0.0, 0.5), F.Distortion("soft", drive=0.25, mix=0.5), F.Reverb("plate", decay=1.5, mix=0.15)],
        volume_db=-4.5)


def brass_stab() -> Patch:
    """Synth brass stab: detuned saws, filter opens in 80 ms then settles, compressed. Roots 36-84."""
    return Patch(
        "brass_stab", description="Classic poly-synth brass: swell on the filter, firm body.", tags=["brass", "stab", "chords"],
        note_range=(36, 84),
        oscs=[Osc("saw", unison=4, detune=0.14, spread=0.7, level=0.9), Osc("saw", unison=2, detune=0.1, fine=5, level=0.6)],
        filters=[Filter("lp24", cutoff=500, res=0.1, keytrack=0.6)],
        envs=[Env(0.012, 0.3, 0.7, 0.2), Env(0.08, 0.35, 0.35, 0.25, curves=(-0.3, -0.5, -0.5)), Env(), Env()],
        mods=[Mod("env2", "filter1.cutoff", 0.34), Mod("velocity", "filter1.cutoff", 0.1)],
        fx=[F.Chorus(0.4, 2.0, 12.0, 2, 1.0, 0.0, 0.25), F.Compressor(-16.0, 3.0, 8.0, 120.0, 6.0, 2.0),
            F.Reverb("room", decay=1.0, mix=0.12)], volume_db=-0.5)


def sync_lead() -> Patch:
    """Hard-sync lead: sync warp swept by an envelope (and mod wheel); screaming, vocal, classic 80s/90s. Roots 48-88."""
    return Patch(
        "sync_lead", description="Sync sweep lead; env2 opens the sync ratio each note; modwheel adds more.",
        tags=["lead", "sync"], note_range=(48, 88),
        oscs=[Osc("saw", unison=3, detune=0.12, warp1="sync", warp1_amount=0.05, spread=0.6)],
        filters=[Filter("lp12", cutoff=7000, res=0.1, keytrack=0.5)],
        envs=[Env(0.004, 0.3, 0.85, 0.2), Env(0.0, 0.6, 0.15, 0.3, curves=(0, -0.5, -0.5)), Env(), Env()],
        lfos=[LFO("sine", rate=5.0, mode="trig", delay=0.2, fade=0.4), LFO(), LFO(), LFO()],
        mods=[Mod("env2", "osc1.warp1", 0.45), Mod("modwheel", "osc1.warp1", 0.3), Mod("lfo1", "pitch", 0.0012)],
        fx=[F.Delay(sync="1/8", feedback=0.3, mix=0.18, mode="pingpong"), F.Reverb("plate", decay=1.4, mix=0.15)], volume_db=-2.6)


def trap_hat() -> Patch:
    """Trap hi-hat: highpassed noise plus a metallic square cluster, bit-reduced for grit, ~55 ms decay.
    Any root; hold 0.01-0.05 s. Open hat: `p.set('env1.decay', 0.35)`."""
    return Patch(
        "trap_hat", description="Closed hat from white noise + metallic square cluster.", tags=["drums", "hat", "trap"],
        note_range=(60, 60),
        oscs=[Osc("square", unison=6, detune=0.9, octave=2, semi=3, level=0.18, spread=0.5)],
        noise=Noise("white", level=1.0, gain_db=-12.0),
        filters=[Filter("hp12", cutoff=7000, res=0.15)],
        envs=[Env(0.0, 0.055, 0.0, 0.04, curves=(0, -0.7, -0.6)), Env(), Env(), Env()],
        fx=[F.Distortion("bitcrush", drive=0.1, bits=7.0, mix=0.35),
            F.EQ([("highshelf", 9000.0, 2.0, 0.7), ("highpass", 5000.0, 0, 0.7)])],
        volume_db=-5.1, vel_amp=0.7)


PRESETS = {f.__name__: f for f in (
    trap_808, reese_bass, supersaw_lead, pluck, warm_pad, vocal_formant_lead, fm_bell, lofi_keys_tape, wobble_bass,
    riser_whoosh, impact, sub_drop, acid_bass, pwm_strings, evolving_pad, organ_keys, hoover_lead, brass_stab,
    sync_lead, trap_hat)}


def catalog() -> dict:
    """{name: (note_low, note_high, description)} for every preset."""
    out = {}
    for name, fn in PRESETS.items():
        p = fn()
        out[name] = (p.note_range[0], p.note_range[1], p.description)
    return out


def get(name: str) -> Patch:
    """A fresh preset by name."""
    if name not in PRESETS:
        raise KeyError(f"unknown preset '{name}'; presets: {', '.join(PRESETS)}")
    return PRESETS[name]()


def riser(duration: float = 4.0) -> Patch:
    """The riser_whoosh preset with its sweep fitted to `duration` seconds (hold the note that long)."""
    p = riser_whoosh()
    p.envs[0].attack = duration * 0.9
    p.envs[1].attack = duration
    return p
