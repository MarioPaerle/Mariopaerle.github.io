"""Sound sources: wavetable oscillators (with warp and unison), a sub oscillator and a noise source."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..audio import Audio
from . import _kernels as K
from .wavetable import get_table

WARP_MODES = {
    "none": 0, "sync": 1, "bend+": 2, "bend-": 3, "bend+-": 4, "pwm": 5, "asym+": 6, "asym-": 7,
    "mirror": 8, "remap": 9, "quantize": 10, "fm": 20, "am": 21, "rm": 22,
}
WARP_DOC = {
    "sync": "hard-sync-like: reads the table at 1..8x the pitch, restarting every cycle (amount 0..1)",
    "bend+": "phase raised to a power: stretches the start of the cycle", "bend-": "stretches the end of the cycle",
    "bend+-": "0.5 neutral, below bends -, above bends +",
    "pwm": "squeezes the cycle into the first part and holds (pulse-width feel)",
    "asym+": "stretches the first half of the cycle, squeezes the second", "asym-": "the opposite",
    "mirror": "reads the second half backwards (amount blends towards a folded cycle)",
    "remap": "sinusoidal phase distortion (Casio-style resonant sweeps)",
    "quantize": "quantises the read phase: lo-fi, stair-stepped cycle",
    "fm": "phase modulation by another oscillator (set fm_src)", "am": "amplitude modulation by another oscillator",
    "rm": "ring modulation by another oscillator",
}


def unison_cents(detune: float) -> float:
    """Half-spread of the outermost unison voices in cents for `detune` 0..1 (0.25 -> ~14 c, 1 -> 100 c)."""
    return 100.0 * float(np.clip(detune, 0.0, 1.0)) ** 1.4


@dataclass
class Osc:
    """A wavetable oscillator.

    table        Wavetable, classic table name ('saw', 'vocal', ...), Audio single cycle or array
    pos          wavetable position 0..1 (morph) - modulate with 'osc1.pos'
    warp1/warp2  phase/amplitude warp mode names (WARP_MODES): none, sync, bend+, bend-, bend+-, pwm,
                 asym+, asym-, mirror, remap, quantize, fm, am, rm; `warp1_amount`/`warp2_amount` 0..1
    fm_src       index of the oscillator (0-based, 0 = osc1) that drives fm/am/rm; default: the other one
    octave/semi/fine   tuning: octaves, semitones, cents
    unison       1..16 voices; detune 0..1 (see unison_cents); blend 0..1 (0 = loud centre only,
                 1 = all equal); spread 0..1 stereo width of the voices
    rand_phase   0..1 how random each voice's start phase is (deterministic per seed); phase: start
                 phase 0..1 of every voice; voice_phase: extra phase offset spread across voices
    level, pan   output level 0..1 and pan -1..1
    filtered     False routes it around the filters
    """

    table: object = "saw"
    pos: float = 0.0
    warp1: str = "none"
    warp1_amount: float = 0.0
    warp2: str = "none"
    warp2_amount: float = 0.0
    fm_src: int | None = None
    octave: int = 0
    semi: float = 0.0
    fine: float = 0.0
    unison: int = 1
    detune: float = 0.25
    blend: float = 0.75
    spread: float = 0.6
    rand_phase: float = 1.0
    phase: float = 0.0
    voice_phase: float = 0.0
    level: float = 1.0
    pan: float = 0.0
    filtered: bool = True
    enabled: bool = True

    def __post_init__(self):
        self.table = get_table(self.table)
        for w in (self.warp1, self.warp2):
            if w not in WARP_MODES:
                raise ValueError(f"unknown warp '{w}'; modes: {', '.join(WARP_MODES)}")
        if not 1 <= int(self.unison) <= 16:
            raise ValueError("unison must be 1..16")

    @property
    def tune_semitones(self) -> float:
        return 12.0 * self.octave + self.semi + self.fine / 100.0

    def layout(self, blend: float, spread: float, seed: int):
        """Static unison layout: voice detune offsets in [-1,1], weights, pan gains and start phases."""
        V = int(self.unison)
        rng = np.random.default_rng(seed)
        u = np.linspace(-1.0, 1.0, V) if V > 1 else np.zeros(1)
        w = blend + (1.0 - blend) * np.maximum(0.0, 1.0 - np.abs(u)) ** 2
        w = w / math.sqrt(float(np.sum(w**2)))
        order = rng.permutation(V)
        pan = (u[order] * spread) if V > 1 else np.zeros(1)
        ang = (pan + 1.0) * math.pi / 4.0
        ph0 = (self.phase + self.rand_phase * rng.random(V) + self.voice_phase * np.arange(V) / V) % 1.0
        return u, w, np.cos(ang), np.sin(ang), ph0


def _scalar(x) -> float:
    return float(np.mean(x)) if isinstance(x, np.ndarray) else float(x)


def render_osc(osc: Osc, freq: np.ndarray, pos: np.ndarray, a1: np.ndarray, a2: np.ndarray, detune,
               blend, spread, ext: np.ndarray | None, sr: int, seed: int) -> np.ndarray:
    """Run the oscillator kernel; returns (n, 2) before level/pan. `detune` is 0..1 (array or float)."""
    n = len(freq)
    u, w, pl, pr, ph0 = osc.layout(_scalar(blend), _scalar(spread), seed)
    m1, m2 = WARP_MODES[osc.warp1], WARP_MODES[osc.warp2]
    mm, am = 0, np.zeros(n)
    if m1 >= 21:
        mm, am, m1 = m1, a1, 0
    elif m2 >= 21:
        mm, am, m2 = m2, a2, 0
    if (m1 == 20 or m2 == 20 or mm) and ext is None:
        ext = np.zeros(n)
    elif ext is None:
        ext = np.zeros(n)
    dc = 100.0 * np.clip(np.broadcast_to(np.asarray(detune, dtype=np.float64), (n,)), 0.0, 1.0) ** 1.4
    f = np.minimum(np.ascontiguousarray(freq, dtype=np.float64), 0.45 * sr)
    tb = osc.table
    return K.osc_kernel(tb.mips, tb.level_harmonics(), f, np.ascontiguousarray(pos, dtype=np.float64),
                        m1, np.ascontiguousarray(a1, dtype=np.float64), m2, np.ascontiguousarray(a2, dtype=np.float64),
                        mm, np.ascontiguousarray(am, dtype=np.float64), np.ascontiguousarray(ext, dtype=np.float64),
                        np.ascontiguousarray(dc), u, w, pl, pr, ph0, float(sr))


@dataclass
class Sub:
    """Sub oscillator: one band-limited voice, `octave` below the note. shape: sine, tri, square, saw."""

    shape: str = "sine"
    octave: int = -1
    level: float = 0.0
    pan: float = 0.0
    filtered: bool = False

    def render(self, freq: np.ndarray, sr: int, seed: int) -> np.ndarray:
        o = Osc(table=self.shape, unison=1, rand_phase=0.0, octave=self.octave)
        n = len(freq)
        f = freq * 2.0 ** self.octave
        z = np.zeros(n)
        out = render_osc(o, f, z, z, z, 0.0, 1.0, 0.0, None, sr, seed)
        return out


@dataclass
class Noise:
    """Noise source. kind: 'white', 'pink', 'brown', 'blue', or 'sample' (loops a recording).

    sample    Audio of a noise/texture (vinyl crackle, breath, rain, a hit tail). It is looped with a
              crossfade and starts at a deterministic random offset. With `keytrack=True` it plays
              at speed 2^((note-root)/12) so it follows the keyboard (root = MIDI note it was
              recorded at, default 60).
    level, pan, filtered: as for Osc. `stereo` decorrelates the channels.
    """

    kind: str = "white"
    level: float = 0.0
    pan: float = 0.0
    sample: Audio | None = None
    keytrack: bool = False
    root: float = 60.0
    stereo: bool = True
    filtered: bool = True
    gain_db: float = -12.0

    def render(self, n: int, sr: int, seed: int, pitch: np.ndarray | None = None) -> np.ndarray:
        from .. import synth
        if self.kind == "sample":
            if self.sample is None:
                raise ValueError("Noise(kind='sample') needs sample=Audio")
            return self._render_sample(n, sr, seed, pitch)
        a = synth.noise(self.kind, n / sr + 0.01, sr, seed=seed, stereo=self.stereo, rms_db=self.gain_db)
        d = a.data.astype(np.float64)[:n]
        return np.stack([d, d], axis=1) if d.ndim == 1 else d

    def _render_sample(self, n: int, sr: int, seed: int, pitch) -> np.ndarray:
        s = self.sample.resample(sr) if self.sample.sr != sr else self.sample
        d = s.data.astype(np.float64)
        d = d if d.ndim == 2 else np.stack([d, d], axis=1)
        L = len(d)
        xf = max(2, min(L // 4, int(0.05 * sr)))
        body = d.copy()
        w = np.linspace(0, 1, xf)[:, None]
        body[:xf] = body[:xf] * w + d[L - xf:] * (1 - w)
        body = body[: L - xf] if L - xf > xf else body
        Lb = len(body)
        rng = np.random.default_rng(seed)
        start = rng.random() * Lb
        speed = np.ones(n)
        if self.keytrack and pitch is not None:
            speed = 2.0 ** ((pitch - self.root) / 12.0)
        pos = (start + np.cumsum(speed)) % Lb
        i0 = pos.astype(int)
        fr = (pos - i0)[:, None]
        out = body[i0] * (1 - fr) + body[(i0 + 1) % Lb] * fr
        if not self.stereo:
            m = out.mean(axis=1, keepdims=True)
            out = np.repeat(m, 2, axis=1)
        out *= 10 ** (self.gain_db / 20.0) / (float(np.sqrt(np.mean(out**2))) + 1e-9)
        return out
