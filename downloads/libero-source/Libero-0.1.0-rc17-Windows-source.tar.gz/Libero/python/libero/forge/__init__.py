"""libero.forge: a Serum-class wavetable synthesizer library for recipes (offline, numba).

    from libero import Sound, forge

    sound = Sound(title="Bass", roots=[24, 36, 48])
    sound.body(forge.layer(forge.presets.reese_bass(), duration=2.0))

Parts
    Wavetable            procedural/classic tables, formulas, harmonics, additive series, audio resynthesis
    Osc, Sub, Noise      sources: wavetable position, 14 warp modes, unison x16, sub, noise (sample-based too)
    Filter               lp/hp/bp/notch 12/24, ladder, diode, svf, comb, flanger, phaser, formant
    Env, LFO, Mod        4+ envelopes, 4+ LFOs (drawable, synced), macros, the mod matrix
    fx.*                 hyper, dimension, distortion, flanger, phaser, chorus, delay, reverb, compressor,
                         multiband (OTT), EQ, filter, tape, vinyl
    Patch                the instrument: render(note, velocity, duration) and render_phrase(notes)
    presets.*            20 documented starting patches (presets.catalog())
    layer, stack, recording   glue for @sound.body

Guide: guide('forge').
"""

from . import fx as FX  # noqa: F401
from . import fx, presets  # noqa: F401
from .filters import TYPES as FILTER_TYPES, Filter, apply_filter  # noqa: F401
from .modulation import LFO, Env, ForgeError, Mod  # noqa: F401
from .osc import WARP_DOC, WARP_MODES, Noise, Osc, Sub, unison_cents  # noqa: F401
from .patch import Patch, Voice, layer, recording, stack  # noqa: F401
from .wavetable import CLASSICS, Wavetable  # noqa: F401

__all__ = ["Wavetable", "Osc", "Sub", "Noise", "Filter", "Env", "LFO", "Mod", "Patch", "Voice", "fx", "FX", "presets",
           "layer", "stack", "recording", "ForgeError", "WARP_MODES", "FILTER_TYPES", "CLASSICS", "unison_cents",
           "apply_filter"]
