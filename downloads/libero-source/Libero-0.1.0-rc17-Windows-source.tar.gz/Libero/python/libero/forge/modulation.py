"""Modulation: envelopes, LFOs, macros and the mod matrix.

Sources (names usable in `Mod`)
    env1..envN      ADSR envelopes, unipolar 0..1. env1 is the amplitude envelope.
    lfo1..lfoN      LFOs, bipolar -1..1
    macro1..macroN  user knobs 0..1 (set on the Patch, or per render with `macros={...}`)
    velocity        0..1       note   MIDI note / 127        random   new value 0..1 for every note
    modwheel, aftertouch   0..1, constant per render via `controls={...}`

A `Mod(src, dst, amount)` adds `amount * source` to the destination's *normalised* position (0..1
across its range, like turning a knob). So amount 0.5 on 'osc1.pos' sweeps half the table;
on 'filter1.cutoff' (20 Hz..20 kHz = 10 octaves) amount 0.3 is +/-3 octaves. `bipolar=True`
maps a unipolar source to -1..1 (centred), `bipolar=False` maps a bipolar one to 0..1, None keeps
the native range. `aux` multiplies the amount by a second source (e.g. mod wheel scales an LFO).

Destinations: see `Patch.targets()`; 'oscN.pos|warp1|warp2|pitch|fine|detune|blend|spread|level|pan',
'sub.level', 'noise.level', 'filterN.cutoff|res|drive|morph|mix', 'pitch', 'volume', 'lfoN.rate'
and every FX parameter flagged modulatable as 'fxK.param' or 'fx.<kind>.param' (e.g. 'fx.delay.mix').
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
from scipy.signal import lfilter

from . import _kernels as K

SHAPES = {"sine": 0, "tri": 1, "saw": 2, "ramp": 3, "square": 4, "sh": 5, "smooth": 6, "points": 7}
MODES = {"trig": 0, "free": 1, "env": 2}


class ForgeError(ValueError):
    pass


@dataclass
class Env:
    """ADSR envelope with delay/hold and curve control (times in seconds, sustain 0..1).

    curves = (attack, decay, release), each -1..1. 0 is linear; for the attack, negative = fast
    start (log-like), positive = slow start; for decay and release negative = exponential-like fall
    (fast then slow, the natural shape), positive = slow start then drop.
    Retriggering restarts the attack from the current level (no click on fast mono lines)."""

    attack: float = 0.005
    decay: float = 0.3
    sustain: float = 0.7
    release: float = 0.25
    hold: float = 0.0
    delay: float = 0.0
    curves: tuple = (-0.3, -0.6, -0.6)

    def render(self, trig: np.ndarray, gate: np.ndarray, sr: int) -> np.ndarray:
        ca, cd, cr = self.curves
        return K.env_kernel(trig, gate, float(sr), self.delay, max(self.attack, 0.0), self.hold, max(self.decay, 1e-4),
                            float(np.clip(self.sustain, 0, 1)), max(self.release, 1e-4), ca, cd, cr)


def _beats(sync) -> float:
    """'1/4' -> 1 beat; '1/8' 0.5; '1/16t' triplet; '1/4.' dotted; a number = beats."""
    if isinstance(sync, (int, float)):
        return float(sync)
    m = re.fullmatch(r"\s*(\d+)\s*/\s*(\d+)\s*([td]?)\.?\s*", str(sync))
    if not m:
        raise ForgeError(f"bad sync '{sync}' (use '1/4', '1/8t', '1/16.' or beats as a number)")
    b = 4.0 * int(m.group(1)) / int(m.group(2))
    if m.group(3) == "t":
        b *= 2.0 / 3.0
    elif m.group(3) == "d" or str(sync).strip().endswith("."):
        b *= 1.5
    return b


@dataclass
class LFO:
    """Low-frequency oscillator, output -1..1.

    shape   'sine','tri','saw' (rising),'ramp' (falling),'square','sh' (sample & hold),'smooth' (random
            glide), or 'points' with `points=[(x, y), ...]` or [(x, y, curve), ...] (x 0..1 across one
            cycle, y -1..1, curve -1..1 bends the segment starting at that point): a drawn LFO.
    rate    Hz; or `sync='1/4'` (note value at the patch bpm; '1/8t' triplet, '1/4.' dotted, or beats)
    mode    'trig' restarts at every note, 'free' runs on a global clock, 'env' plays one cycle per note
    phase   start phase 0..1; smooth: seconds of low-pass; delay/fade: seconds before it starts / fades in
    """

    shape: str = "sine"
    rate: float = 2.0
    sync: object = None
    mode: str = "trig"
    phase: float = 0.0
    smooth: float = 0.0
    delay: float = 0.0
    fade: float = 0.0
    points: list | None = None

    def __post_init__(self):
        if self.shape not in SHAPES:
            raise ForgeError(f"LFO shape must be one of {list(SHAPES)}")
        if self.mode not in MODES:
            raise ForgeError(f"LFO mode must be one of {list(MODES)}")
        if self.shape == "points" and not self.points:
            raise ForgeError("LFO shape 'points' needs points=[(x, y), ...]")

    def rate_hz(self, bpm: float) -> float:
        if self.sync is not None:
            return (bpm / 60.0) / _beats(self.sync)
        return float(self.rate)

    def render(self, trig: np.ndarray, sr: int, bpm: float, rate_scale=None, t0: int = 0, seed: int = 0) -> np.ndarray:
        n = len(trig)
        rate = np.full(n, self.rate_hz(bpm)) if rate_scale is None else np.asarray(rate_scale, dtype=np.float64)
        if self.points:
            pts = sorted(((p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in self.points), key=lambda p: p[0])
            if pts[0][0] > 0:
                pts.insert(0, (0.0, pts[0][1], 0.0))
            if pts[-1][0] < 1:
                pts.append((1.0, pts[0][1], 0.0))
            xs, ys, cs = (np.array(c, dtype=np.float64) for c in zip(*pts))
        else:
            xs = ys = cs = np.zeros(2)
        out = K.lfo_kernel(trig, np.ascontiguousarray(rate), float(sr), SHAPES[self.shape], MODES[self.mode],
                           float(self.phase), int(t0), self.delay * sr, self.fade * sr, int(seed) & 0x7FFFFFFF,
                           xs, ys, cs)
        if self.smooth > 0:
            a = np.exp(-1.0 / (self.smooth * sr))
            out = lfilter([1 - a], [1, -a], out, zi=[out[0] * a])[0]
        return out


@dataclass
class Mod:
    """One mod-matrix row. See the module docstring for the amount/bipolar/aux semantics."""

    src: str
    dst: str
    amount: float = 1.0
    bipolar: bool | None = None
    aux: str | None = None
    curve: float = 0.0


# ---------------------------------------------------------------- destinations

_RANGES = {
    "pos": (0.0, 1.0, "lin"), "warp1": (0.0, 1.0, "lin"), "warp2": (0.0, 1.0, "lin"),
    "pitch": (-48.0, 48.0, "lin"), "fine": (-1.0, 1.0, "lin"), "detune": (0.0, 1.0, "lin"),
    "blend": (0.0, 1.0, "lin"), "spread": (0.0, 1.0, "lin"), "level": (0.0, 1.0, "lin"), "pan": (-1.0, 1.0, "lin"),
    "cutoff": (20.0, 20000.0, "log"), "res": (0.0, 1.0, "lin"), "drive": (0.0, 1.0, "lin"),
    "morph": (0.0, 1.0, "lin"), "mix": (0.0, 1.0, "lin"), "rate": (0.01, 50.0, "log"),
}
OSC_PARAMS = ("pos", "warp1", "warp2", "pitch", "fine", "detune", "blend", "spread", "level", "pan")
FILTER_PARAMS = ("cutoff", "res", "drive", "morph", "mix")
SOURCES_BASE = ("velocity", "note", "random", "modwheel", "aftertouch")


def to_norm(x, lo, hi, scale):
    x = np.asarray(x, dtype=np.float64)
    if scale == "log":
        return np.log(np.clip(x, lo, hi) / lo) / np.log(hi / lo)
    return (np.clip(x, lo, hi) - lo) / (hi - lo)


def from_norm(v, lo, hi, scale):
    if scale == "log":
        return lo * (hi / lo) ** v
    return lo + (hi - lo) * v


def static_ranges(n_osc: int, n_filters: int, n_lfos: int) -> dict:
    out = {}
    for i in range(1, n_osc + 1):
        for p in OSC_PARAMS:
            out[f"osc{i}.{p}"] = _RANGES[p]
    for i in range(1, n_filters + 1):
        for p in FILTER_PARAMS:
            out[f"filter{i}.{p}"] = _RANGES[p]
    for i in range(1, n_lfos + 1):
        out[f"lfo{i}.rate"] = _RANGES["rate"]
    out["sub.level"] = _RANGES["level"]
    out["noise.level"] = _RANGES["level"]
    out["pitch"] = _RANGES["pitch"]
    out["volume"] = _RANGES["level"]
    return out


class ModEngine:
    """Evaluates destinations: base value + sum of matrix rows, in normalised knob space."""

    def __init__(self, mods: list[Mod], sources: dict[str, np.ndarray], ranges: dict, n: int):
        self.n = n
        self.sources = sources
        self.ranges = ranges
        self.by_dst: dict[str, list[Mod]] = {}
        for m in mods:
            self.by_dst.setdefault(m.dst, []).append(m)

    def _src(self, name: str, bipolar: bool | None, curve: float = 0.0) -> np.ndarray:
        s = self.sources[name]
        native_bi = name.startswith("lfo")
        if bipolar is True and not native_bi:
            s = 2.0 * s - 1.0
        elif bipolar is False and native_bi:
            s = 0.5 * (s + 1.0)
        if curve:
            s = np.sign(s) * np.abs(s) ** (2.0 ** (2.0 * curve))
        return s

    def has(self, dst: str) -> bool:
        return dst in self.by_dst

    def value(self, dst: str, base):
        rows = self.by_dst.get(dst)
        if not rows:
            return base
        lo, hi, scale = self.ranges[dst]
        m = np.zeros(self.n)
        for r in rows:
            s = self._src(r.src, r.bipolar, r.curve)
            if r.aux:
                s = s * self._src(r.aux, False)
            m += r.amount * s
        v = np.clip(to_norm(base, lo, hi, scale) + m, 0.0, 1.0)
        return from_norm(v, lo, hi, scale)

    def arr(self, dst: str, base) -> np.ndarray:
        return np.ascontiguousarray(np.broadcast_to(np.asarray(self.value(dst, base), dtype=np.float64), (self.n,)))
