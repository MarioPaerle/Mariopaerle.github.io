"""Filters. One `Filter` object covers every type; the same engine powers the FX-rack filter.

    Filter("lp24", cutoff=800, res=0.3, drive=0.2, keytrack=0.5)

type          what                                                        cutoff means
lp12 lp24     Butterworth low-pass, 12/24 dB per octave                   -3 dB point
hp12 hp24     high-pass                                                   -3 dB point
bp12 bp24     band-pass (res narrows it)                                  centre
notch12/24    notch (band-reject)                                         centre
svf           state-variable morph: morph 0 = LP, 0.5 = BP, 1 = HP        corner / centre
ladder        Moog-style 4-pole (24 dB) with self-oscillating resonance   resonance peak
diode         diode-ladder flavour: asymmetric, softer slope, tighter res resonance peak
comb+ comb-   feedback comb, delay = 1/cutoff, res = feedback             first teeth (fundamental)
flanger       swept comb mixed with the dry signal (jet-plane notches)    delay = 1/cutoff
phaser        6-12 stage all-pass chain, morph = number of stages          notch sweep centre
formant       three vowel formants; morph 0..1 = a e i o u; res = Q;       1000 = neutral; each octave
              cutoff shifts all formants                                  of cutoff shifts them 0.5 octave

`res` 0..1 is resonance (Q from 0.7 to ~18; ladder self-oscillates near 1). `drive` 0..1 saturates
inside the filter. `keytrack` 0..1 moves the cutoff with the note (1 = follows pitch exactly,
referenced to C4). `mix` blends dry and filtered.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from . import _kernels as K
from .wavetable import VOWELS

TYPES = ("lp12", "lp24", "hp12", "hp24", "bp12", "bp24", "notch12", "notch24", "svf", "ladder", "diode",
         "comb+", "comb-", "flanger", "phaser", "formant")

_SVF = {"lp": 0, "hp": 1, "bp": 2, "notch": 3}
_VF = np.array([VOWELS[v][:3] for v in "aeiou"], dtype=np.float64)
_VQ = np.array([[9.0, 11.0, 12.0]] * 5, dtype=np.float64)
_VG = np.array([[1.0, 0.7, 0.45]] * 5, dtype=np.float64)


@dataclass
class Filter:
    type: str = "lp24"
    cutoff: float = 2000.0
    res: float = 0.0
    drive: float = 0.0
    morph: float = 0.0
    keytrack: float = 0.0
    mix: float = 1.0
    enabled: bool = True

    def __post_init__(self):
        if self.type not in TYPES:
            raise ValueError(f"unknown filter type '{self.type}'; types: {', '.join(TYPES)}")

    def response(self, sr: int = 48000, n: int = 16384, freqs: np.ndarray | None = None):
        """(freqs, dB) magnitude response measured from the impulse response (drive 0, linear types)."""
        x = np.zeros(n)
        x[0] = 1.0
        y = apply_filter(self.type, x, self.cutoff, self.res, 0.0, self.morph, sr)
        h = np.abs(np.fft.rfft(y))
        f = np.fft.rfftfreq(n, 1.0 / sr)
        return f, 20 * np.log10(np.maximum(h, 1e-9))


def _arr(v, n) -> np.ndarray:
    return np.ascontiguousarray(np.broadcast_to(np.asarray(v, dtype=np.float64), (n,)))


def apply_filter(kind: str, x: np.ndarray, cutoff, res, drive, morph, sr: int) -> np.ndarray:
    """Filter a mono (n,) or stereo (n,2) float array. Parameters are floats or per-sample arrays."""
    if x.ndim == 2:
        return np.stack([apply_filter(kind, np.ascontiguousarray(x[:, c]), cutoff, res, drive, morph, sr)
                         for c in range(x.shape[1])], axis=1)
    n = len(x)
    x = np.ascontiguousarray(x, dtype=np.float64)
    fc, rs, dr, mo = _arr(cutoff, n), _arr(res, n), _arr(drive, n), _arr(morph, n)
    sr = float(sr)
    if kind in ("lp12", "lp24", "hp12", "hp24", "bp12", "bp24", "notch12", "notch24"):
        base = kind[:-2]
        return K.svf_kernel(x, fc, rs, dr, mo, _SVF[base], 2 if kind.endswith("24") else 1, sr)
    if kind == "svf":
        return K.svf_kernel(x, fc, rs, dr, mo, 4, 1, sr)
    if kind == "ladder":
        return K.ladder_kernel(x, fc, rs, dr, sr, 0)
    if kind == "diode":
        return K.ladder_kernel(x, fc, rs, dr, sr, 1)
    if kind == "comb+":
        return K.comb_kernel(x, fc, rs, 1.0, 0, sr)
    if kind == "comb-":
        return K.comb_kernel(x, fc, rs, -1.0, 0, sr)
    if kind == "flanger":
        return K.comb_kernel(x, fc, rs, 1.0, 1, sr)
    if kind == "phaser":
        nst = int(2 + 2 * round(float(np.mean(mo)) * 5))
        return K.phaser_kernel(x, fc, 0.9 * rs, nst, np.ones(n), sr)
    if kind == "formant":
        shift = np.maximum(fc / 1000.0, 1e-3) ** 0.5
        return K.formant_kernel(x, shift, mo, rs, sr, _VF, _VQ, _VG)
    raise ValueError(f"unknown filter type '{kind}'")
