"""The FX rack. Each effect is a small dataclass; a Patch runs them in list order on the stereo sum.

    Patch(..., fx=[Hyper(mix=0.4), Distortion("tube", drive=0.3), Delay(sync="1/8", feedback=0.4),
                   Reverb("plate", decay=1.8, mix=0.2), Compressor()])

`mix` is dry/wet (equal crossfade) except for Delay and Reverb, where it is a wet send added to the
untouched dry signal. Parameters listed in `MOD` can be targets of the mod matrix as 'fxK.param'
(K = 1-based position in the rack) or 'fx.<kind>.param' ('fx.delay.mix', 'fx.reverb2.mix' for a second one).
Every effect is deterministic for a given patch seed and keeps its output finite and bounded.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import ClassVar

import numpy as np
from scipy.signal import lfilter, resample_poly, sosfilt

from .. import dsp
from . import _kernels as K
from .filters import apply_filter
from .modulation import _beats


@dataclass
class FxCtx:
    """What an effect receives besides audio: rate, length, seed, tempo and modulated parameters."""

    sr: int
    n: int
    seed: int
    bpm: float
    engine: object
    idx: int

    def p(self, name: str, base):
        if self.engine is None:
            return base
        return self.engine.value(f"fx{self.idx}.{name}", base)

    def arr(self, name: str, base) -> np.ndarray:
        return np.ascontiguousarray(np.broadcast_to(np.asarray(self.p(name, base), dtype=np.float64), (self.n,)))

    def rng(self, salt: int = 0) -> np.random.Generator:
        return np.random.default_rng((self.seed * 7919 + salt) & 0xFFFFFFFF)


def _col(v):
    v = np.asarray(v, dtype=np.float64)
    return v[:, None] if v.ndim == 1 else v


def _mix(dry, wet, m):
    m = _col(np.clip(m, 0.0, 1.0)) if np.ndim(m) else float(np.clip(m, 0.0, 1.0))
    return dry * (1.0 - m) + wet * m


def _lfo(ctx: FxCtx, rate, phase: float = 0.0, shape: str = "sine") -> np.ndarray:
    rate = np.broadcast_to(np.asarray(rate, dtype=np.float64), (ctx.n,))
    ph = np.cumsum(rate) / ctx.sr + phase
    if shape == "tri":
        return 4.0 * np.abs(ph - np.floor(ph + 0.5)) - 1.0
    return np.sin(2 * np.pi * ph)


def _safe(x: np.ndarray) -> np.ndarray:
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    return np.clip(x, -16.0, 16.0)


@dataclass
class Fx:
    enabled: bool = field(default=True, kw_only=True)
    KIND: ClassVar[str] = "fx"
    MOD: ClassVar[dict] = {}

    def process(self, x: np.ndarray, ctx: FxCtx) -> np.ndarray:  # pragma: no cover
        raise NotImplementedError

    def tail(self) -> float:
        """Seconds of ring-out after the input stops (used to size the render)."""
        return 0.0


_UNIT = (0.0, 1.0, "lin")


# ---------------------------------------------------------------- distortion

@dataclass
class Distortion(Fx):
    """Waveshaping distortion with 2x oversampling.

    mode  'tube' (asymmetric, even harmonics) | 'soft' (tanh) | 'hard' (clip) | 'diode' (asymmetric
          exponential) | 'fold' (wavefolder) | 'bitcrush' (`bits`) | 'downsample' (`rate` Hz sample-and-hold)
          | 'waveshaper' (`shaper`: callable on -1..1 or a transfer-curve array)
    drive 0..1 input gain (1 + 49*drive^2);  bias asymmetry for tube;  tone low-pass Hz after the shaper;
    gain_db output trim;  mix dry/wet."""

    mode: str = "tube"
    drive: float = 0.3
    mix: float = 1.0
    bias: float = 0.15
    tone: float = 18000.0
    bits: float = 8.0
    rate: float = 8000.0
    shaper: object = None
    oversample: int = 2
    gain_db: float = 0.0
    KIND: ClassVar[str] = "distortion"
    MOD: ClassVar[dict] = {"drive": _UNIT, "mix": _UNIT}

    def _shape(self, y, d, ctx):
        m = self.mode
        if m == "tube":
            b = self.bias
            return (np.tanh(d * y + b) - np.tanh(b)) / np.tanh(d)
        if m == "soft":
            return np.tanh(d * y) / np.tanh(d)
        if m == "hard":
            return np.clip(d * y, -1.0, 1.0)
        if m == "diode":
            z = d * y
            pos = 1.0 - np.exp(-np.maximum(z, 0.0))
            neg = -0.8 * (1.0 - np.exp(0.6 * np.minimum(z, 0.0)))
            return (pos + neg) / (1.0 - np.exp(-d))
        if m == "fold":
            return np.sin(0.5 * np.pi * d * y)
        if m == "waveshaper":
            if callable(self.shaper):
                return np.asarray(self.shaper(np.clip(d * y, -1, 1)), dtype=np.float64)
            tab = np.asarray(self.shaper, dtype=np.float64)
            return np.interp(np.clip(d * y, -1, 1), np.linspace(-1, 1, len(tab)), tab)
        raise ValueError(f"unknown distortion mode '{m}'")

    def process(self, x, ctx):
        drv = _col(ctx.p("drive", self.drive))
        d = 1.0 + 49.0 * np.clip(drv, 0, 1) ** 2
        if self.mode == "bitcrush":
            q = 2.0 ** (max(self.bits, 1.0) - 1.0)
            wet = np.round(np.clip(x * d, -1, 1) * q) / q
        elif self.mode == "downsample":
            r = max(1.0, ctx.sr / max(self.rate, 100.0))
            idx = (np.floor(np.arange(ctx.n) / r) * r).astype(int)
            wet = x[np.minimum(idx, ctx.n - 1)]
        else:
            ov = int(self.oversample)
            if ov > 1:
                up = resample_poly(x, ov, 1, axis=0)
                dd = np.repeat(d, ov, axis=0) if np.ndim(d) and d.shape[0] > 1 else d
                y = self._shape(up, dd, ctx)
                wet = resample_poly(y, 1, ov, axis=0)[: ctx.n]
                if wet.shape[0] < ctx.n:
                    wet = np.pad(wet, ((0, ctx.n - wet.shape[0]), (0, 0)))
            else:
                wet = self._shape(x, d, ctx)
        if self.tone < 0.45 * ctx.sr:
            wet = sosfilt(dsp.rbj_biquad("lowpass", self.tone, ctx.sr), wet, axis=0)
        wet = wet * dsp.undb(self.gain_db)
        return _mix(x, wet, ctx.p("mix", self.mix))


# ---------------------------------------------------------------- modulated-delay effects

def _chan_delay(x, dly_samples, fb=0.0, damp=0.0):
    return np.stack([K.mod_delay_kernel(np.ascontiguousarray(x[:, c]), np.ascontiguousarray(dly_samples[c]), fb, damp)
                     for c in range(2)], axis=1)


@dataclass
class Flanger(Fx):
    """Swept short delay with feedback. rate Hz, depth ms swing, delay ms centre, feedback -0.95..0.95
    (negative = hollow, odd-harmonic notches), stereo = right-channel LFO phase offset 0..1."""

    rate: float = 0.25
    depth: float = 2.0
    delay: float = 3.0
    feedback: float = 0.5
    stereo: float = 0.25
    mix: float = 0.5
    KIND: ClassVar[str] = "flanger"
    MOD: ClassVar[dict] = {"mix": _UNIT, "feedback": (-0.95, 0.95, "lin"), "rate": (0.01, 20.0, "log")}

    def process(self, x, ctx):
        rate = ctx.p("rate", self.rate)
        dl = [(self.delay + self.depth * _lfo(ctx, rate, ph, "tri")) * ctx.sr / 1000.0 for ph in (0.0, self.stereo)]
        fb = float(np.mean(ctx.p("feedback", self.feedback)))
        wet = _chan_delay(x, dl, float(np.clip(fb, -0.95, 0.95)), 0.2)
        m = _col(np.clip(ctx.p("mix", self.mix), 0, 1)) if np.ndim(ctx.p("mix", self.mix)) else self.mix
        return (x + m * wet) / (1.0 + 0.5 * m)

    def tail(self):
        return 0.2


@dataclass
class Chorus(Fx):
    """Classic chorus: `voices` (1..4) delays around `delay` ms, swung by `depth` ms at `rate` Hz,
    spread across the stereo field."""

    rate: float = 0.6
    depth: float = 3.0
    delay: float = 14.0
    voices: int = 2
    spread: float = 1.0
    feedback: float = 0.0
    mix: float = 0.5
    KIND: ClassVar[str] = "chorus"
    MOD: ClassVar[dict] = {"mix": _UNIT, "depth": (0.0, 10.0, "lin"), "rate": (0.01, 20.0, "log")}

    def process(self, x, ctx):
        V = int(np.clip(self.voices, 1, 4))
        rate = ctx.p("rate", self.rate)
        depth = ctx.p("depth", self.depth)
        wet = np.zeros_like(x)
        for v in range(V):
            dly = (self.delay + 1.5 * v + depth * _lfo(ctx, rate, v / V)) * ctx.sr / 1000.0
            d = _chan_delay(x, [dly, dly], self.feedback, 0.3)
            pan = (v / max(V - 1, 1) * 2 - 1) * self.spread if V > 1 else 0.0
            ang = (pan + 1) * math.pi / 4
            wet += d * np.array([math.cos(ang), math.sin(ang)]) * (1.414 / V)
        return _mix(x, wet, ctx.p("mix", self.mix))

    def tail(self):
        return 0.1


@dataclass
class Hyper(Fx):
    """Serum-style hyper/unison effect: up to 8 randomly modulated delay voices spread in stereo,
    thickening the whole sound. detune 0..1 sets the pitch-wobble depth, rate the speed, width the
    stereo spread."""

    rate: float = 0.35
    detune: float = 0.4
    voices: int = 6
    width: float = 1.0
    mix: float = 0.5
    KIND: ClassVar[str] = "hyper"
    MOD: ClassVar[dict] = {"mix": _UNIT, "detune": _UNIT, "rate": (0.01, 20.0, "log")}

    def process(self, x, ctx):
        V = int(np.clip(self.voices, 1, 8))
        rng = ctx.rng(1)
        rate = ctx.p("rate", self.rate)
        det = np.asarray(ctx.p("detune", self.detune), dtype=np.float64)
        wl = np.zeros_like(x[:, 0])
        wr = np.zeros_like(x[:, 0])
        order = rng.permutation(V)
        for v in range(V):
            base = 6.0 + 18.0 * rng.random()
            r = rate * (0.6 + 0.9 * rng.random())
            dly = (base + (0.4 + 5.0 * det) * _lfo(ctx, r, rng.random(), "tri")) * ctx.sr / 1000.0
            d = _chan_delay(x, [dly, dly], 0.0, 0.3)
            pan = ((order[v] / max(V - 1, 1)) * 2 - 1) * self.width
            ang = (pan + 1) * math.pi / 4
            wl += d[:, 0] * math.cos(ang) * 1.414 / math.sqrt(V)
            wr += d[:, 1] * math.sin(ang) * 1.414 / math.sqrt(V)
        wet = np.stack([wl, wr], axis=1)
        return _mix(x, wet, ctx.p("mix", self.mix))

    def tail(self):
        return 0.1


@dataclass
class Dimension(Fx):
    """Dimension-style widener: two gently modulated short lines cross-fed with opposite polarity.
    size 0..1 sets the delay (3-12 ms), mix the amount."""

    size: float = 0.5
    rate: float = 0.3
    mix: float = 0.6
    KIND: ClassVar[str] = "dimension"
    MOD: ClassVar[dict] = {"mix": _UNIT, "size": _UNIT}

    def process(self, x, ctx):
        size = ctx.p("size", self.size)
        base = (3.0 + 9.0 * np.asarray(size)) * ctx.sr / 1000.0
        dl = base + 0.6 * _lfo(ctx, self.rate, 0.0) * ctx.sr / 1000.0
        dr = base * 1.07 - 0.6 * _lfo(ctx, self.rate * 1.03, 0.25) * ctx.sr / 1000.0
        w = _chan_delay(x, [dl, dr], 0.0, 0.2)
        m = np.broadcast_to(np.asarray(ctx.p("mix", self.mix), dtype=np.float64), (ctx.n,))
        out = x.copy()
        out[:, 0] = x[:, 0] + (0.7 * w[:, 0] - 0.5 * w[:, 1]) * m
        out[:, 1] = x[:, 1] + (0.7 * w[:, 1] - 0.5 * w[:, 0]) * m
        return out / (1.0 + 0.4 * float(np.mean(m)))

    def tail(self):
        return 0.1


@dataclass
class Phaser(Fx):
    """All-pass phaser. rate Hz, center Hz, depth in octaves of sweep (each side), stages 2..12, feedback."""

    rate: float = 0.4
    center: float = 900.0
    depth: float = 1.5
    stages: int = 6
    feedback: float = 0.4
    stereo: float = 0.25
    mix: float = 0.5
    KIND: ClassVar[str] = "phaser"
    MOD: ClassVar[dict] = {"mix": _UNIT, "feedback": (0.0, 0.95, "lin"), "center": (50.0, 12000.0, "log"),
                           "rate": (0.01, 20.0, "log")}

    def process(self, x, ctx):
        rate = ctx.p("rate", self.rate)
        fbk = ctx.arr("feedback", self.feedback)
        cen = ctx.arr("center", self.center)
        ns = int(np.clip(self.stages, 2, 12))
        mix = ctx.arr("mix", self.mix)
        out = np.empty_like(x)
        for c, ph in enumerate((0.0, self.stereo)):
            fc = cen * 2.0 ** (self.depth * _lfo(ctx, rate, ph))
            out[:, c] = K.phaser_kernel(np.ascontiguousarray(x[:, c]), fc, fbk, ns, np.clip(mix, 0, 1), float(ctx.sr))
        return out


# ---------------------------------------------------------------- time-based

@dataclass
class Delay(Fx):
    """Stereo delay. time ms, or sync='1/8' (note value at the patch bpm; '1/8.' dotted, '1/8t' triplet).
    mode 'stereo' | 'pingpong' | 'mono'. `offset` scales the right line's time (stereo mode). The
    feedback path is band-limited by `lowpass`/`highpass` Hz so repeats darken. `mix` is the wet
    level added to the full dry signal."""

    time: float = 350.0
    sync: object = None
    feedback: float = 0.4
    mix: float = 0.3
    mode: str = "stereo"
    offset: float = 1.0
    lowpass: float = 6000.0
    highpass: float = 100.0
    KIND: ClassVar[str] = "delay"
    MOD: ClassVar[dict] = {"mix": _UNIT, "feedback": (0.0, 0.95, "lin")}

    def _ms(self, bpm):
        return 60000.0 / bpm * _beats(self.sync) if self.sync is not None else self.time

    def process(self, x, ctx):
        sr = ctx.sr
        tl = max(2.0, self._ms(ctx.bpm) * sr / 1000.0)
        tr = max(2.0, tl * (self.offset if self.mode == "stereo" else 1.0))
        a_lp = 1.0 - math.exp(-2 * math.pi * self.lowpass / sr)
        a_hp = 1.0 - math.exp(-2 * math.pi * self.highpass / sr)
        fb = np.clip(ctx.arr("feedback", self.feedback), 0.0, 0.95)
        mode = {"stereo": 0, "pingpong": 1, "mono": 2}[self.mode]
        wl, wr = K.delay_kernel(np.ascontiguousarray(x[:, 0]), np.ascontiguousarray(x[:, 1]), tl, tr, fb, mode,
                                min(a_lp, 1.0), min(a_hp, 1.0))
        wet = np.stack([wl, wr], axis=1)
        return x + wet * _col(np.clip(ctx.arr("mix", self.mix), 0, 4))

    def tail(self):
        ms = self._ms(120.0) if self.sync is not None else self.time
        fb = min(max(self.feedback, 0.0), 0.95)
        n = math.log(1e-3) / math.log(max(fb, 1e-3)) if fb > 0.01 else 1.0
        return float(min(ms * (n + 1) / 1000.0 * (self.offset if self.mode == "stereo" else 1.0), 8.0))


_REV = {
    "plate": [14.3, 17.9, 21.1, 24.7, 29.3, 33.1, 37.9, 43.1],
    "hall": [31.7, 38.3, 46.1, 53.9, 63.7, 73.1, 83.9, 97.3],
    "room": [8.9, 11.3, 13.7, 16.1, 19.3, 22.7, 27.1, 31.9],
}


@dataclass
class Reverb(Fx):
    """Algorithmic reverb (8-line FDN with input diffusion). kind 'plate' (dense, bright), 'hall'
    (large, slow build), 'room' (small). decay = RT60 seconds, size scales the delay lines (0.5..2),
    damping 0..1 darkens the tail, predelay ms, width 0..1, lowcut/highcut Hz on the wet signal.
    `mix` is the wet level added to the full dry signal."""

    kind: str = "plate"
    decay: float = 2.0
    size: float = 1.0
    damping: float = 0.4
    predelay: float = 10.0
    mix: float = 0.25
    width: float = 1.0
    lowcut: float = 120.0
    highcut: float = 9000.0
    KIND: ClassVar[str] = "reverb"
    MOD: ClassVar[dict] = {"mix": _UNIT}

    def process(self, x, ctx):
        sr = ctx.sr
        if self.kind not in _REV:
            raise ValueError(f"reverb kind must be one of {list(_REV)}")
        lens = np.round(np.array(_REV[self.kind]) * self.size * sr / 1000.0)
        g = 10.0 ** (-3.0 * lens / (sr * max(self.decay, 0.05)))
        damp = 1.0 - 0.8 * float(np.clip(self.damping, 0, 1))
        dl = np.round(np.array([142, 107, 379, 277]) * sr / 44100.0)
        wl, wr = K.fdn_kernel(np.ascontiguousarray(x[:, 0]), np.ascontiguousarray(x[:, 1]), lens, g, damp,
                              int(self.predelay * sr / 1000.0), dl, 2.0 * self.size, 0.3, float(sr))
        m, s = 0.5 * (wl + wr), 0.5 * (wl - wr) * float(np.clip(self.width, 0, 1))
        wet = np.stack([m + s, m - s], axis=1)
        if self.lowcut > 20:
            wet = sosfilt(dsp.rbj_biquad("highpass", self.lowcut, sr), wet, axis=0)
        if self.highcut < 0.45 * sr:
            wet = sosfilt(dsp.rbj_biquad("lowpass", self.highcut, sr), wet, axis=0)
        return x + wet * _col(np.clip(ctx.arr("mix", self.mix), 0, 4))

    def tail(self):
        return float(min(self.decay * 1.0 + self.predelay / 1000.0, 10.0))


# ---------------------------------------------------------------- dynamics & tone

@dataclass
class Compressor(Fx):
    """Feed-forward compressor, linked stereo. threshold dB, ratio, attack/release ms, knee dB,
    makeup dB, `detect` 'peak' or 'rms'. mix is dry/wet (parallel compression)."""

    threshold: float = -18.0
    ratio: float = 4.0
    attack: float = 5.0
    release: float = 120.0
    knee: float = 6.0
    makeup: float = 0.0
    detect: str = "peak"
    mix: float = 1.0
    KIND: ClassVar[str] = "compressor"
    MOD: ClassVar[dict] = {"mix": _UNIT}

    def process(self, x, ctx):
        l, r, _ = K.comp_kernel(np.ascontiguousarray(x[:, 0]), np.ascontiguousarray(x[:, 1]), self.threshold,
                                max(self.ratio, 1.0), max(self.knee, 0.01), self.attack / 1000.0,
                                self.release / 1000.0, float(ctx.sr), 1 if self.detect == "rms" else 0)
        wet = np.stack([l, r], axis=1) * dsp.undb(self.makeup)
        return _mix(x, wet, ctx.p("mix", self.mix))


def _lr4(x, freq, sr, kind):
    sos = dsp.rbj_biquad(kind, freq, sr, 0.7071)
    sos = np.vstack([sos, sos])
    return sosfilt(sos, x, axis=0)


@dataclass
class MultibandComp(Fx):
    """Multiband dynamics, OTT-style: each of three bands (split at `low`/`high` Hz, Linkwitz-Riley 4)
    is squashed downward above `down_db` and lifted upward below `up_db`.

    mode 'ott' (both), 'up' (upward only: raises quiet detail), 'down' (downward only). depth 0..1 is
    the dry/wet amount (OTT's Depth knob); `time` scales attack/release (1 = default, <1 faster);
    gain_db output trim. Fast and loud: great on pads, drums and lo-fi layers, in moderation."""

    mode: str = "ott"
    depth: float = 0.5
    time: float = 1.0
    low: float = 120.0
    high: float = 2500.0
    down_db: float = -20.0
    up_db: float = -36.0
    down_ratio: float = 4.0
    up_ratio: float = 3.0
    max_gain_db: float = 24.0
    gain_db: float = 0.0
    KIND: ClassVar[str] = "multiband"
    MOD: ClassVar[dict] = {"depth": _UNIT}

    def process(self, x, ctx):
        sr = ctx.sr
        lo = _lr4(x, self.low, sr, "lowpass")
        rest = _lr4(x, self.low, sr, "highpass")
        mid = _lr4(rest, self.high, sr, "lowpass")
        hi = _lr4(rest, self.high, sr, "highpass")
        lo = _lr4(lo, self.high, sr, "lowpass") + _lr4(lo, self.high, sr, "highpass")
        t = max(self.time, 0.05)
        cfg = [(lo, 3.0, 0.14), (mid, 4.0, 0.08), (hi, 3.0, 0.05)]
        down, up = (1 if self.mode in ("ott", "down") else 0), (1 if self.mode in ("ott", "up") else 0)
        out = np.zeros_like(x)
        for band, att_ms, rel in cfg:
            l, r = K.ott_band_kernel(np.ascontiguousarray(band[:, 0]), np.ascontiguousarray(band[:, 1]),
                                     self.down_db, max(self.down_ratio, 1.0), self.up_db, max(self.up_ratio, 1.0),
                                     att_ms * t / 1000.0, rel * t, float(sr), self.max_gain_db, down, up)
            out += np.stack([l, r], axis=1)
        out *= dsp.undb(self.gain_db)
        dry = lo + mid + hi
        return _mix(dry, out, ctx.p("depth", self.depth))


@dataclass
class EQ(Fx):
    """Parametric EQ: `bands` is a list of (kind, freq_hz, gain_db, q), kind in
    peak, lowshelf, highshelf, lowpass, highpass, bandpass, notch (gain ignored for the last four).
    Default: a gentle low cut at 30 Hz."""

    bands: list = field(default_factory=lambda: [("highpass", 30.0, 0.0, 0.7)])
    KIND: ClassVar[str] = "eq"

    def process(self, x, ctx):
        y = x
        for kind, f, g, q in self.bands:
            y = sosfilt(dsp.rbj_biquad(kind, f, ctx.sr, q, g), y, axis=0)
        return y


@dataclass
class FilterFx(Fx):
    """A Filter (any type of forge.filters) in the rack, e.g. a final low-pass or a formant sweep."""

    type: str = "lp12"
    cutoff: float = 8000.0
    res: float = 0.0
    drive: float = 0.0
    morph: float = 0.0
    mix: float = 1.0
    KIND: ClassVar[str] = "filter"
    MOD: ClassVar[dict] = {"cutoff": (20.0, 20000.0, "log"), "res": _UNIT, "drive": _UNIT, "morph": _UNIT, "mix": _UNIT}

    def process(self, x, ctx):
        wet = apply_filter(self.type, x, ctx.arr("cutoff", self.cutoff), ctx.arr("res", self.res),
                           ctx.arr("drive", self.drive), ctx.arr("morph", self.morph), ctx.sr)
        return _mix(x, wet, ctx.p("mix", self.mix))


@dataclass
class Utility(Fx):
    """gain_db, stereo `width` (0 mono .. 1 unchanged .. 2 wide), `pan` -1..1, and `mono_below` Hz
    (keeps bass mono; 0 = off)."""

    gain_db: float = 0.0
    width: float = 1.0
    pan: float = 0.0
    mono_below: float = 0.0
    KIND: ClassVar[str] = "utility"

    def process(self, x, ctx):
        m, s = 0.5 * (x[:, 0] + x[:, 1]), 0.5 * (x[:, 0] - x[:, 1])
        if self.mono_below > 0:
            lows = sosfilt(dsp.rbj_biquad("lowpass", self.mono_below, ctx.sr), s)
            s = s - lows
        s = s * self.width
        y = np.stack([m + s, m - s], axis=1) * dsp.undb(self.gain_db)
        ang = (self.pan + 1) * math.pi / 4
        return y * np.array([math.cos(ang), math.sin(ang)]) * math.sqrt(2)


# ---------------------------------------------------------------- lo-fi: tape and vinyl

@dataclass
class Tape(Fx):
    """Cassette/tape ageing.

    wow 0..1     slow pitch drift (about 0.6 Hz; 0.3 = +/-5 cents)
    flutter 0..1 fast pitch jitter (6-13 Hz)
    saturation 0..1  soft tape compression and odd/even harmonics
    age 0..1     high-frequency loss (16 kHz -> 3.5 kHz) and slow level dropouts
    bump dB      low-frequency head bump around 80 Hz
    hiss_db      noise floor (dBFS rms, deterministic); None = silent
    """

    wow: float = 0.25
    flutter: float = 0.2
    saturation: float = 0.35
    age: float = 0.3
    bump: float = 2.0
    hiss_db: float | None = -58.0
    mix: float = 1.0
    KIND: ClassVar[str] = "tape"
    MOD: ClassVar[dict] = {"mix": _UNIT, "wow": _UNIT, "age": _UNIT}

    def process(self, x, ctx):
        sr, n = ctx.sr, ctx.n
        rng = ctx.rng(2)
        wow = float(np.mean(ctx.p("wow", self.wow)))
        age = float(np.mean(ctx.p("age", self.age)))
        base = 14.0
        drift = np.cumsum(rng.standard_normal(n)) / math.sqrt(sr) * 0.4
        drift -= np.linspace(drift[0], drift[-1], n)
        lw = np.sin(2 * np.pi * 0.6 * np.arange(n) / sr + rng.random() * 6.28) + 0.5 * np.sin(2 * np.pi * 1.37 * np.arange(n) / sr + 1.0)
        lf = (np.sin(2 * np.pi * 6.3 * np.arange(n) / sr + 0.7) + 0.7 * np.sin(2 * np.pi * 9.7 * np.arange(n) / sr + 2.0)
              + 0.4 * np.sin(2 * np.pi * 13.1 * np.arange(n) / sr))
        dly = (base + 2.2 * wow * (lw + drift) + 0.12 * self.flutter * lf) * sr / 1000.0
        wet = _chan_delay(x, [dly, dly * 1.0004], 0.0, 0.0)
        if self.saturation > 0:
            d = 1.0 + 5.0 * self.saturation
            wet = (np.tanh(d * wet + 0.08 * self.saturation) - np.tanh(0.08 * self.saturation)) / np.tanh(d) * (1.0 - 0.2 * self.saturation)
        lp = 16000.0 - 12500.0 * age
        wet = sosfilt(np.vstack([dsp.rbj_biquad("lowpass", lp, sr, 0.6), dsp.rbj_biquad("highshelf", 4000.0, sr, 0.7, -4.0 * age)]), wet, axis=0)
        if self.bump:
            wet = sosfilt(dsp.rbj_biquad("peak", 80.0, sr, 0.9, self.bump), wet, axis=0)
        wet = sosfilt(dsp.rbj_biquad("highpass", 28.0, sr, 0.7), wet, axis=0)
        if age > 0.05:
            slow = np.convolve(rng.standard_normal(n), np.ones(int(sr * 0.08)) / (sr * 0.08), "same")
            slow = slow / (np.std(slow) + 1e-9)
            wet = wet * (1.0 - age * 0.12 * np.clip(slow, 0, 3))[:, None]
        if self.hiss_db is not None:
            h = rng.standard_normal((n, 2))
            h = sosfilt(dsp.rbj_biquad("highpass", 1500.0, sr, 0.5), h, axis=0)
            h *= dsp.undb(self.hiss_db) / (np.sqrt(np.mean(h**2)) + 1e-12)
            wet = wet + h
        return _mix(x, wet, ctx.p("mix", self.mix))


@dataclass
class Vinyl(Fx):
    """Record-player character.

    crackle 0..1  dense tiny clicks (5..150 per second);  pops 0..1  rarer, louder, duller clicks
    hiss_db       surface noise (dBFS rms);  rumble_db  motor rumble below 40 Hz
    wear 0..1     high-frequency loss (15 kHz -> 5 kHz) with a touch of saturation
    warp 0..1     slow 0.55 Hz speed wobble;  mono_bass: sum the lows to mono
    level_db      loudness of the clicks relative to full scale (rms of crackle bed)
    """

    crackle: float = 0.5
    pops: float = 0.3
    hiss_db: float = -52.0
    rumble_db: float = -55.0
    wear: float = 0.4
    warp: float = 0.1
    level_db: float = -36.0
    mono_bass: bool = True
    mix: float = 1.0
    KIND: ClassVar[str] = "vinyl"
    MOD: ClassVar[dict] = {"mix": _UNIT, "wear": _UNIT}

    def process(self, x, ctx):
        sr, n = ctx.sr, ctx.n
        rng = ctx.rng(3)
        wet = x
        if self.warp > 0:
            t = np.arange(n) / sr
            dly = (8.0 + 1.2 * self.warp * np.sin(2 * np.pi * 0.55 * t + rng.random() * 6.28)) * sr / 1000.0
            wet = _chan_delay(x, [dly, dly], 0.0, 0.0)
        w = float(np.mean(ctx.p("wear", self.wear)))
        lp = 15000.0 - 10000.0 * w
        wet = sosfilt(dsp.rbj_biquad("lowpass", lp, sr, 0.7), wet, axis=0)
        wet = wet + 0.0
        if self.wear > 0.05:
            d = 1.0 + 1.5 * w
            wet = np.tanh(d * wet) / np.tanh(d)
        out = wet.copy()
        click = np.zeros((n, 2))
        if self.crackle > 0:
            rate = 5.0 + 145.0 * self.crackle ** 1.5
            mask = rng.random((n, 2)) < rate / sr
            amp = rng.standard_normal((n, 2)) * mask * (rng.random((n, 2)) ** 3)
            click += lfilter([1.0], [1.0, -0.55], amp, axis=0)
        if self.pops > 0:
            rate = 0.3 + 2.7 * self.pops
            mask = rng.random(n) < rate / sr
            amp = (rng.standard_normal(n) * mask * 4.0)[:, None] * np.array([1.0, 0.7])
            click += lfilter([1.0], [1.0, -0.96], amp, axis=0)
        if np.any(click):
            click *= dsp.undb(self.level_db) / (np.sqrt(np.mean(click**2)) + 1e-12) if self.crackle > 0 else 1.0
            out = out + np.clip(click, -0.8, 0.8)
        if self.hiss_db is not None:
            h = rng.standard_normal((n, 2))
            h = sosfilt(dsp.rbj_biquad("highpass", 800.0, sr, 0.5), h, axis=0)
            out = out + h * dsp.undb(self.hiss_db) / (np.sqrt(np.mean(h**2)) + 1e-12)
        if self.rumble_db is not None:
            r = sosfilt(np.vstack([dsp.rbj_biquad("lowpass", 40.0, sr, 0.7)] * 2), rng.standard_normal((n, 2)), axis=0)
            out = out + r * dsp.undb(self.rumble_db) / (np.sqrt(np.mean(r**2)) + 1e-12)
        if self.mono_bass:
            m = 0.5 * (out[:, 0] + out[:, 1])
            sides = out - m[:, None]
            slow = sosfilt(dsp.rbj_biquad("lowpass", 150.0, sr, 0.7), sides, axis=0)
            out = out - slow
        return _mix(x, out, ctx.p("mix", self.mix))


FX_KINDS = {c.KIND: c for c in (Distortion, Flanger, Chorus, Hyper, Dimension, Phaser, Delay, Reverb, Compressor,
                                MultibandComp, EQ, FilterFx, Utility, Tape, Vinyl)}


def run_rack(fx: list, x: np.ndarray, sr: int, seed: int, bpm: float, engine) -> np.ndarray:
    for i, f in enumerate(fx, start=1):
        if not f.enabled:
            continue
        x = _safe(f.process(x, FxCtx(sr, len(x), seed * 31 + i, bpm, engine, i)))
    return x


def rack_tail(fx: list) -> float:
    return float(sum(f.tail() for f in fx if f.enabled)) if fx else 0.0
