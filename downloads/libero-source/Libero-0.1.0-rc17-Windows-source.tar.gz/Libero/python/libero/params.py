"""The live parameter table (SPEC §5), as data.

Shared by recipe validation (`Sound.defaults`), the compiler (manifest
`params`), the MCP `params_reference` tool and the docs. IDs are stable
forever: DAW projects store them.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Param:
    id: str
    name: str
    group: str
    kind: str  # "float" | "int" | "choice"
    lo: float = 0.0
    hi: float = 1.0
    default: float | str = 0.0
    unit: str = ""
    skew: str = "linear"  # "linear" | "log"
    choices: tuple[str, ...] = field(default_factory=tuple)
    notes: str = ""

    def range_text(self) -> str:
        if self.kind == "choice":
            return ", ".join(self.choices)
        lo = _fmt(self.lo)
        hi = _fmt(self.hi)
        s = f"{lo}..{hi}"
        if self.unit:
            s += f" {self.unit}"
        if self.kind == "int":
            s += ", step 1"
        if self.skew == "log":
            s += ", log"
        return s


def _fmt(v: float) -> str:
    return f"{v:g}" if v >= 0 else f"{v:g}"


def _f(id, name, group, lo, hi, default, unit="", skew="linear", notes=""):
    return Param(id, name, group, "float", lo, hi, default, unit, skew, (), notes)


def _i(id, name, group, lo, hi, default, unit="", notes=""):
    return Param(id, name, group, "int", lo, hi, default, unit, "linear", (), notes)


def _c(id, name, group, choices, default, notes=""):
    return Param(id, name, group, "choice", 0, len(choices) - 1, default, "", "linear", tuple(choices), notes)


PARAMS: tuple[Param, ...] = (
    # Layers
    _f("lvl_attack", "Attacco", "Layers", -60, 6, 0, "dB"),
    _f("lvl_body", "Corpo", "Layers", -60, 6, 0, "dB"),
    _f("lvl_tail", "Coda", "Layers", -60, 6, -6, "dB"),
    _f("lvl_air", "Aria", "Layers", -60, 6, -18, "dB", notes='the noise bed: "rumore di fondo"'),
    # Envelope (body)
    _f("amp_attack", "Attacco", "Envelope", 0, 5000, 2, "ms", "log"),
    _f("amp_decay", "Decadimento", "Envelope", 1, 10000, 400, "ms", "log"),
    _f("amp_sustain", "Sostegno", "Envelope", 0, 1, 1.0),
    _f("amp_release", "Rilascio", "Envelope", 1, 15000, 300, "ms", "log"),
    _f("amp_curve", "Curvatura", "Envelope", -1, 1, 0, notes="<0 = exponential-ish, >0 = logarithmic-ish"),
    _f("air_attack", "Aria · entrata", "Envelope", 0, 5000, 30, "ms", "log",
       notes="air follows note-on/off with its own AR"),
    _f("air_release", "Aria · uscita", "Envelope", 1, 15000, 800, "ms", "log"),
    _f("air_follow", "Aria · segue", "Envelope", 0, 1, 1.0,
       notes="0 = air is always on (drone bed), 1 = gated by notes"),
    # Pitch
    _i("tune", "Intonazione", "Pitch", -24, 24, 0, "st"),
    _f("fine", "Fine", "Pitch", -100, 100, 0, "cents"),
    _f("glide", "Portamento", "Pitch", 0, 2000, 0, "ms", "log"),
    _f("vel_sens", "Velocità", "Pitch", 0, 1, 0.7, notes="amplitude response to velocity"),
    _i("voices", "Voci", "Pitch", 1, 32, 16),
    _c("mode", "Modo", "Pitch", ["Poli", "Mono", "Legato"], "Poli",
       notes="Mono/Legato: one voice, last-note priority with note memory; Legato slurs overlapping notes "
             "(no retrigger, no attack layer, glides over max(glide, 25 ms), crossfades body zones)"),
    _c("dyn_mode", "Dinamica da", "Pitch", ["Velocità", "Modulazione", "Manopola"], "Velocità",
       notes="where the dynamics axis comes from: Velocità = the bundle's source (velocity unless its manifest "
             "says cc1/cc11); Modulazione = CC1; Manopola = the `dynamics` knob"),
    _f("dynamics", "Dinamica", "Pitch", 0, 1, 0.7,
       notes="position on the dynamics axis with Manopola; initial value of CC sources until they move"),
    _f("humanize", "Umano", "Pitch", 0, 1, 1.0, notes="scales the manifest humanize (0 = off)"),
    _c("osc1_wave", "Onda 1", "Oscillatori", ["Sega", "Quadra", "Triangolo", "Seno", "Rumore"], "Sega",
       notes="band-limited wavetables, alias-free; Quadra's width is osc1_pw"),
    _i("osc1_oct", "Ottava 1", "Oscillatori", -3, 3, 0),
    _i("osc1_semi", "Semitoni 1", "Oscillatori", -12, 12, 0, "st"),
    _f("osc1_fine", "Fine 1", "Oscillatori", -100, 100, 0, "cents"),
    _f("osc1_level", "Livello 1", "Oscillatori", -60, 6, -60, "dB", notes="-60 = off"),
    _f("osc1_pw", "Larghezza 1", "Oscillatori", 0.05, 0.95, 0.5, notes="pulse width (Quadra)"),
    _f("osc1_phase", "Fase L/R 1", "Oscillatori", 0, 1, 0,
       notes="right channel's phase offset, fraction of a cycle: width without unison; partial k cancels "
             "in mono where k x offset is near half a cycle (0.5 removes the odd harmonics in mono)"),
    _i("osc1_voices", "Voci 1", "Oscillatori", 1, 8, 1, notes="unison"),
    _f("osc1_detune", "Scordatura 1", "Oscillatori", 0, 1, 0.25, notes="unison spread, 60 x detune^2 cents each side"),
    _f("osc1_spread", "Apertura 1", "Oscillatori", 0, 1, 0.5, notes="unison stereo spread"),
    _c("osc2_wave", "Onda 2", "Oscillatori", ["Sega", "Quadra", "Triangolo", "Seno", "Rumore"], "Sega",
       notes="band-limited wavetables, alias-free; Quadra's width is osc2_pw"),
    _i("osc2_oct", "Ottava 2", "Oscillatori", -3, 3, 0),
    _i("osc2_semi", "Semitoni 2", "Oscillatori", -12, 12, 0, "st"),
    _f("osc2_fine", "Fine 2", "Oscillatori", -100, 100, 0, "cents"),
    _f("osc2_level", "Livello 2", "Oscillatori", -60, 6, -60, "dB", notes="-60 = off"),
    _f("osc2_pw", "Larghezza 2", "Oscillatori", 0.05, 0.95, 0.5, notes="pulse width (Quadra)"),
    _f("osc2_phase", "Fase L/R 2", "Oscillatori", 0, 1, 0,
       notes="right channel's phase offset, fraction of a cycle: width without unison; partial k cancels "
             "in mono where k x offset is near half a cycle (0.5 removes the odd harmonics in mono)"),
    _i("osc2_voices", "Voci 2", "Oscillatori", 1, 8, 1, notes="unison"),
    _f("osc2_detune", "Scordatura 2", "Oscillatori", 0, 1, 0.25, notes="unison spread, 60 x detune^2 cents each side"),
    _f("osc2_spread", "Apertura 2", "Oscillatori", 0, 1, 0.5, notes="unison stereo spread"),
    _f("sub_level", "Sub", "Oscillatori", -60, 6, -60, "dB", notes="one octave below osc1; -60 = off"),
    _c("sub_wave", "Onda sub", "Oscillatori", ["Seno", "Quadra", "Sega"], "Seno"),
    _f("osc_drift", "Deriva", "Oscillatori", 0, 1, 0.15, notes="slow analogue pitch drift, per oscillator and side (up to ±7 cents)"),
    _c("osc_retrig", "Fase", "Oscillatori", ["Libera", "Riavvia"], "Libera",
       notes="Libera: each note starts at a random phase; Riavvia: phases reset at note-on"),
    # Moto (LFO)
    _c("lfo_shape", "Forma", "Moto", ["Seno", "Triangolo", "Quadra", "Dente", "Casuale"], "Seno"),
    _f("lfo_rate", "Frequenza", "Moto", 0.02, 20, 5, "Hz", "log"),
    _f("lfo_delay", "Ritardo", "Moto", 0, 3000, 0, "ms", "log", notes="fade-in from each note's start"),
    _f("lfo_pitch", "Vibrato", "Moto", 0, 100, 0, "cents"),
    _f("lfo_cutoff", "Al filtro", "Moto", 0, 4, 0, "oct"),
    _f("lfo_amp", "Tremolo", "Moto", 0, 1, 0),
    _f("lfo_pw", "Alla larghezza", "Moto", 0, 1, 0, notes="pulse-width modulation of Quadra oscillators"),
    # Filter envelope and tracking
    _f("fenv_attack", "Filtro · attacco", "Tone", 0, 5000, 0, "ms", "log"),
    _f("fenv_decay", "Filtro · decadimento", "Tone", 1, 10000, 400, "ms", "log"),
    _f("fenv_sustain", "Filtro · sostegno", "Tone", 0, 1, 0),
    _f("fenv_release", "Filtro · rilascio", "Tone", 1, 15000, 300, "ms", "log"),
    _c("fenv_source", "Inviluppo del filtro", "Tone", ["Ampiezza", "Propria"], "Ampiezza",
       notes="what flt_env follows: the amp envelope (bundle/1 behaviour) or its own fenv_* envelope"),
    _f("flt_key", "Segue la nota", "Tone", 0, 1, 0, notes="1 = cutoff follows pitch 1:1 around C4"),
    _f("flt_vel", "Velocità al filtro", "Tone", 0, 1, 0, notes="up to +3 octaves of cutoff at velocity 127"),
    _f("flt_dyn", "Espressione timbrica", "Tone", 0, 4, 0, "oct",
       notes="CC1/Manopola sweeps the filter/formant profile around its centre; independent of note pitch"),
    _i("sub_divisor", "Divisore sub 1", "Oscillatori", 1, 24, 2),
    _f("sub2_level", "Livello sub 2", "Oscillatori", -60, 6, -60, "dB"),
    _i("sub2_divisor", "Divisore sub 2", "Oscillatori", 1, 24, 3),
    _f("sub3_level", "Livello sub 3", "Oscillatori", -60, 6, -60, "dB"),
    _i("sub3_divisor", "Divisore sub 3", "Oscillatori", 1, 24, 4),
    _f("amp_dyn", "Pressione", "Tone", 0, 1, 0,
       notes="CC1/Manopola amplitude response for live oscillators; zero leaves level unchanged"),
    _f("osc1_phase_mod", "Moto di fase 1", "Oscillatori", 0, 1, 0, notes="slow motion of osc1's L/R phase offset"),
    _f("osc2_phase_mod", "Moto di fase 2", "Oscillatori", 0, 1, 0, notes="slow motion of osc2's L/R phase offset"),
    # Articulations (bundle/2): index into the manifest's `articulations`; keyswitches move it too
    _i("artic", "Articolazione", "Pitch", 0, 15, 0, notes="active articulation: index into the manifest's list (0 = the first = default)"),
    # Tone
    _c("flt_mode", "Filtro", "Tone", ["Basso", "Banda", "Alto", "Vocale"], "Basso",
       notes="Vocale = formant (vowel via flt_cutoff)"),
    _f("flt_cutoff", "Taglio", "Tone", 20, 20000, 20000, "Hz", "log"),
    _f("flt_reso", "Risonanza", "Tone", 0, 1, 0.1),
    _f("flt_env", "Inviluppo filtro", "Tone", -1, 1, 0, notes="modulation from body envelope, ±5 octaves"),
    _f("drive", "Calore", "Tone", 0, 1, 0, notes="soft saturation pre-filter"),
    # Risonanze
    _c("res_mode", "Risonanza", "Risonanze", ["Corde", "Vetro", "Legno", "Metallo"], "Corde",
       notes="Corde = sympathetic comb strings; Vetro = inharmonic modal glass; "
             "Legno = body formants; Metallo = plate modes"),
    _f("res_tune", "Accordatura", "Risonanze", -24, 24, 0, "st",
       notes="relative to played note (Corde) or to C (others)"),
    _f("res_decay", "Durata", "Risonanze", 0, 1, 0.5),
    _f("res_bright", "Luce", "Risonanze", 0, 1, 0.5),
    _f("res_mix", "Quantità", "Risonanze", 0, 1, 0),
    # Nastro
    _f("tape_wow", "Wow", "Nastro", 0, 1, 0, notes="slow pitch drift"),
    _f("tape_flutter", "Flutter", "Nastro", 0, 1, 0, notes="fast pitch jitter"),
    _f("tape_sat", "Saturazione", "Nastro", 0, 1, 0),
    _f("tape_age", "Età", "Nastro", 0, 1, 0, notes="hiss + HF loss + slight dropouts"),
    _f("tape_mix", "Nastro", "Nastro", 0, 1, 0),
    # Eco
    _f("echo_time", "Tempo", "Eco", 10, 2000, 375, "ms", "log", notes="used when echo_sync = Libero"),
    _f("echo_feedback", "Ritorno", "Eco", 0, 0.95, 0.35),
    _f("echo_tone", "Colore", "Eco", 0, 1, 0.5, notes="dark ↔ bright in the loop"),
    _f("echo_spread", "Ampiezza", "Eco", 0, 1, 0.5, notes="ping-pong amount"),
    _f("echo_mix", "Eco", "Eco", 0, 1, 0),
    _c("echo_sync", "Sincro", "Eco", ["Tempo", "Libero"], "Tempo",
       notes="Tempo: delay = echo_div at the host BPM (120 offline); Libero: echo_time in ms. "
             "A manifest that sets echo_time without echo_sync loads as Libero"),
    _c("echo_div", "Suddivisione", "Eco",
       ["1/32", "1/16T", "1/16", "1/16.", "1/8T", "1/8", "1/8.", "1/4T", "1/4", "1/4.", "1/2", "1/1"], "1/8",
       notes="used when echo_sync = Tempo (T = triplet, . = dotted)"),
    # Sala
    _c("rev_mode", "Sala", "Sala", ["Cappella", "Basilica", "Cisterna", "Piastra", "Impronta"], "Basilica",
       notes="Impronta = convolution with the bundle's ir.wav (falls back to Basilica if absent)"),
    _f("rev_size", "Dimensione", "Sala", 0, 1, 0.6),
    _f("rev_decay", "Durata", "Sala", 0.1, 30, 3.5, "s", "log"),
    _f("rev_predelay", "Attesa", "Sala", 0, 250, 20, "ms"),
    _f("rev_damp", "Ombra", "Sala", 0, 1, 0.4, notes="high-frequency damping"),
    _f("rev_width", "Ampiezza", "Sala", 0, 1, 1.0),
    _f("rev_shimmer", "Aureola", "Sala", 0, 1, 0, notes="octave-up shimmer fed back into the tank"),
    _f("rev_mix", "Sala", "Sala", 0, 1, 0.2),
    # Output
    _f("width", "Stereo", "Output", 0, 2, 1, notes="mid/side"),
    _f("master", "Volume", "Output", -60, 6, 0, "dB"),
    # Optional EQ/compression chains. The default bypass leaves existing sounds unchanged.
    _c("caldi_mode", "Carattere", "Caldi", ["Spento", "Velluto", "Presenza", "Intimo", "Blu", "Soffio"], "Spento"),
    _f("caldi_amount", "Quantità", "Caldi", 0, 1, .65),
    _f("caldi_body", "Corpo", "Caldi", 0, 1, .5, notes="low shelf relative to the chosen chain"),
    _f("caldi_light", "Luce", "Caldi", 0, 1, .5, notes="high shelf relative to the chosen chain"),
    _f("caldi_grain", "Grana", "Caldi", 0, 1, 0, notes="quiet filtered generative texture, gated by input; no idle hiss"),
    _f("caldi_motion", "Movimento", "Caldi", 0, 1, 0, notes="slow shallow amplitude/texture movement; no pitch modulation"),
    _f("caldi_output", "Uscita", "Caldi", -12, 3, 0, "dB"),
    # Appended IDs keep the established parameter relay order stable.
    _f("lfo_pitch_cc1", "Vibrato CC1", "Motion", 0, 100, 0, "cents",
       notes="additional vibrato depth scaled by MIDI CC1; zero means CC1 adds no pitch modulation"),
    _f("vel_amp_curve", "Velocity amplitude curve", "Voice", 0, 1, 0,
       notes="blends legacy velocity response toward a high-end-shallow concave response; zero preserves existing presets"),
)

BY_ID: dict[str, Param] = {p.id: p for p in PARAMS}

# SPEC §3's example writes `reverb_mode` / `reverb_mix`; §5 is authoritative.
ALIASES: dict[str, str] = {
    "reverb_mode": "rev_mode",
    "reverb_mix": "rev_mix",
    "reverb_size": "rev_size",
    "reverb_decay": "rev_decay",
    "reverb_predelay": "rev_predelay",
    "reverb_damp": "rev_damp",
    "reverb_width": "rev_width",
    "reverb_shimmer": "rev_shimmer",
}


class ParamError(ValueError):
    pass


def canonical_id(pid: str) -> str:
    return ALIASES.get(pid, pid)


def validate_value(pid: str, value) -> float | int | str:
    """Validate one plain value; returns the normalised value (choices as their string)."""
    pid = canonical_id(pid)
    p = BY_ID.get(pid)
    if p is None:
        close = [q.id for q in PARAMS if pid.split("_")[0] == q.id.split("_")[0]]
        hint = f" (did you mean one of: {', '.join(close)}?)" if close else ""
        raise ParamError(f"unknown parameter '{pid}'{hint}")
    if p.kind == "choice":
        if isinstance(value, bool):
            raise ParamError(f"{pid}: expected one of {list(p.choices)}")
        if isinstance(value, (int, float)):
            idx = int(value)
            if idx != value or not 0 <= idx < len(p.choices):
                raise ParamError(f"{pid}: index {value} out of range 0..{len(p.choices) - 1}")
            return p.choices[idx]
        for c in p.choices:
            if str(value).strip().lower() == c.lower():
                return c
        raise ParamError(f"{pid}: '{value}' is not one of {list(p.choices)}")
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise ParamError(f"{pid}: expected a number, got {value!r}") from None
    if v != v:
        raise ParamError(f"{pid}: NaN")
    if not p.lo <= v <= p.hi:
        raise ParamError(f"{pid}: {v:g} outside {p.range_text()}")
    if p.kind == "int":
        if v != int(v):
            raise ParamError(f"{pid}: expected an integer, got {v:g}")
        return int(v)
    return v


def validate(values: dict) -> dict:
    out = {}
    errors = []
    for k, v in values.items():
        try:
            out[canonical_id(k)] = validate_value(k, v)
        except ParamError as e:
            errors.append(str(e))
    if errors:
        raise ParamError("; ".join(errors))
    return out


def defaults() -> dict:
    return {p.id: p.default for p in PARAMS}


def reference_markdown() -> str:
    lines = [
        "| id | name | range / choices | default | notes |",
        "|---|---|---|---|---|",
    ]
    group = None
    for p in PARAMS:
        if p.group != group:
            group = p.group
            lines.append(f"| **{group}** | | | | |")
        d = p.default if isinstance(p.default, str) else f"{p.default:g}"
        lines.append(f"| `{p.id}` | {p.name} | {p.range_text()} | {d} | {p.notes} |")
    lines.append("")
    lines.append(
        "Signal order per voice: attack + body(→env) + tail → drive → filter → resonator. "
        "Then summed with air → tape → echo → reverb → width → master. "
        "Choice params take their string (e.g. rev_mode='Cisterna')."
    )
    return "\n".join(lines)
