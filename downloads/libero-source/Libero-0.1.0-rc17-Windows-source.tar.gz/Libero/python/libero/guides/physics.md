# Physical modelling in Libero

`libero.physics` simulates the instrument instead of sampling it: a string, a reed and bore, a
struck bar, a room. The simulation runs offline, inside your recipe, and returns an ordinary
`Audio`; the compiler then cuts it into zones like any other. Reach for it when you want a real
instrument family with **honest velocity behaviour** (harder = brighter, not just louder),
**exact tuning across the whole range** and **continuous control** (bow pressure, blowing
pressure, strike point, inharmonicity) without recordings.

```python
from libero import Sound, physics as ph
```

## 1. The chain

Every sound is the same five-stage chain. Each stage is a function or object you can swap.

| stage | what it is | where |
|---|---|---|
| exciter | pluck shape, felt hammer, bow friction, mouth pressure, mallet | `strings.pluck/strike/bow`, `winds.*` (reed, jet, lip), `modal.Mallet` |
| resonator | waveguide string, bore, modal bank, finite-difference plate | `strings`, `winds`, `modal` |
| body | what the instrument's box/top/soundboard does to the vibration | `body.guitar() cello() violin() soundboard()`, `body.Body([...])` |
| radiation | bell highpass, directivity, distance + air absorption | `body.horn_radiation off_axis distance` |
| room | image-source early reflections + FDN tail, spring, plate | `room.shoebox_ir spring_ir plate_ir preset` |

Shortcut: `ph.presets.<instrument>()` builds the whole chain with note-dependent physics.

```python
inst = ph.presets.cello()
a = inst.render(130.8, velocity=0.7, dur=3.0, sr=48000, seed=1)       # Audio
a = inst.with_(pressure=0.75, pos=0.07).render(130.8, 0.7, 3.0)        # change model parameters
a = inst.through(room=ph.room_preset("hall"), room_mix=0.2).render(130.8, 0.7, 3.0)
```

Presets: guitar('classical'|'steel'), piano(pedal=False), cello(), violin(), clarinet(), oboe(),
saxophone(), flute(), trumpet(), trombone(), horn(), marimba(), xylophone(), vibraphone(),
glockenspiel(), bell('church'|'handbell'|'tubular'|'glass'|'gong'), timpani(), glass().
Each has `.note_range`.

## 2. Conventions

- Frequencies in Hz, times in seconds, **T60** = seconds to decay 60 dB.
- `velocity` is 0..1 (or MIDI 1..127) and drives the physics: hammer speed, bow speed, breath
  pressure, mallet speed. Do not also scale level with it; let `vel_sens` and loudness
  normalisation do that.
- `position` is a fraction of the string length measured from the bridge (pluck, hammer, bow).
- Pressures of reeds/brass are dimensionless and normalised to the closing pressure: the
  docstring of each model says where it speaks (clarinet > ~0.45, flute > ~0.85, brass > ~0.5).
- Everything is deterministic for a seed: pass `seed=ctx.seed`. Different seeds = different takes.
- Output peaks are normalised to -6 dB (`peak_db`); set loudness in the recipe with
  `normalize_loudness(-16)`.
- First call of each model compiles a numba kernel (0.1-0.5 s, cached on disk); after that a 2 s note
  takes 5-300 ms.

## 3. Recipes

Each snippet is a complete `sound.py` body layer. `ph.render_note(model, ctx.note, ctx.vel, dur,
ctx=ctx)` supplies `sr` and `seed` from the context, so takes and recompiles are reproducible.
Sustained instruments (bow, reed, brass) need loops: give them 3-4 s and ask for `sound.loop`.

### Plucked string (classical guitar)

```python
from libero import Sound, physics as ph

sound = Sound(title="Nylon", roots=[40, 47, 54, 61, 68, 75], velocities=[55, 110])

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.guitar("classical"), ctx.note, ctx.vel, 3.5, ctx=ctx)
    return a.normalize_loudness(-16)
```

Raw model for a harp-like string: `ph.pluck(freq, 4.0, decay=6.0, decay_hf=0.3, inharmonicity=2e-4,
position=0.12, hardness=0.5, pickup=0.3, seed=ctx.seed)`; `hardness` 0 = finger flesh, 1 = plectrum;
`position` 0.05 = nasal, 0.5 = hollow; `strings=2..3` with `bridge_t60` gives coupled unisons.

### Piano note

```python
from libero import Sound, physics as ph

sound = Sound(title="Grand", roots=[28, 40, 52, 64, 76, 88, 100], velocities=[45, 85, 120])

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.piano(), ctx.note, ctx.vel, 6.0, ctx=ctx)
    return a.normalize_loudness(-16)
```

Per note it sets felt hammer mass/stiffness, string impedance, inharmonicity B(note) (1e-4 at C3,
1e-2 at C7), 1/2/3 strings with coupling (prompt sound then aftersound, beating), T60 from 40 s
(A0) to 2 s (C8), a soundboard body and key noise. Tune hammer by hand:
`ph.hammer_string(f, 4.0, hammer=ph.Hammer(mass=0.003, stiffness=4.5e9, exponent=2.5, impedance=1.6), velocity=0.8)`.

### Bowed cello

```python
from libero import Sound, physics as ph

sound = Sound(title="Cello", roots=[36, 43, 50, 57, 64], velocities=[50, 100])
sound.loop(body=True, min_seconds=0.8)

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.cello(), ctx.note, ctx.vel, 4.0, ctx=ctx)
    return a.normalize_loudness(-16)
```

The bow is a friction junction: Helmholtz motion (a sawtooth at the bridge) appears when bow
pressure lies between Schelleng's minimum and maximum. `pressure` is 0..1 *inside that window*
(0.6 default): 0 = flautando/whistly, 1 = crushed/raucous. `pos` is the bow-bridge distance
(0.05 sul ponticello .. 0.15 sul tasto). Envelope: `sp, pr = ph.bow_stroke(dur, speed=0.3,
pressure=0.6, attack=0.08)` then `ph.bow(f, dur, speed=sp, pressure=pr)`; add vibrato with
`ph.pitch_modulate(a, ph.vibrato(a.duration, 5.6, 18))`.

### Clarinet

```python
from libero import Sound, physics as ph

sound = Sound(title="Clarinet", roots=[50, 57, 64, 71, 78], velocities=[50, 100])
sound.loop(body=True, min_seconds=0.8)

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.clarinet(), ctx.note, ctx.vel, 3.5, ctx=ctx)
    return a.normalize_loudness(-16)
```

Cylindrical bore = odd harmonics (hollow chalumeau), wider range of timbre from `pressure`
(0.45 breathy edge of speaking .. 0.7 bright), `zeta` (embouchure) and `stiffness` (soft reed
rounder). Raw: `ph.reed(f, 3.0, pressure=ph.breath(3.0, 0.55, attack=0.05), zeta=0.4, cutoff=2200)`.

### Oboe / double reed

```python
from libero import Sound, physics as ph

sound = Sound(title="Oboe", roots=[60, 67, 74, 81, 88], velocities=[60, 110])
sound.loop(body=True, min_seconds=0.8)

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.oboe(), ctx.note, ctx.vel, 3.5, ctx=ctx)
    return a.normalize_loudness(-16)
```

A double reed never seals (`min_opening` ~0.1), the bore is conical (full harmonic series; `apex`
and a cutoff near 2.3 x freq keep it on the fundamental), `edge` adds the reed's upper harmonics
and the radiation adds the nasal shelf/peak near 1.25 kHz. Saxophone = same model, softer:
`ph.presets.saxophone()`.

### Trumpet

```python
from libero import Sound, physics as ph

sound = Sound(title="Trumpet", roots=[55, 62, 69, 76], velocities=[45, 75, 120])
sound.loop(body=True, min_seconds=0.8)

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.trumpet(), ctx.note, ctx.vel, 3.0, ctx=ctx)
    return a.normalize_loudness(-16)
```

A lip valve (mass-spring) on a harmonic bore whose length is retuned to each note (valves);
velocity raises mouth pressure and `brassiness` (nonlinear wave steepening): pp is mellow, ff
blares. Trombone `pedal=58.3`, horn `pedal=43.65`, darker `cutoff`. Raw: `ph.brass(f, 2.5,
pressure=ph.breath(2.5, 0.75, attack=0.05), pedal=116.5, brassiness=0.5, cutoff=1800)`.

### Marimba

```python
from libero import Sound, physics as ph

sound = Sound(title="Marimba", roots=[45, 52, 59, 66, 73, 80, 87], velocities=[40, 80, 120])

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.marimba(), ctx.note, ctx.vel, 2.5, ctx=ctx)
    return a.normalize_loudness(-16)
```

Bar modes 1 : 4 : 10 (undercut tuning); strike at the centre (`position=0.5`) for a pure sine,
near 0.22 for a bright knock. Raw: `ph.mallet_strike(ph.bar(f, "vibraphone"), 4.0, velocity=ctx.vel,
mallet=ph.Mallet(hardness=0.5), position=0.3, seed=ctx.seed)`; kinds are marimba, xylophone,
vibraphone, glockenspiel, chime, kalimba, free.

### Bell

```python
from libero import Sound, physics as ph

sound = Sound(title="Bell", roots=[48, 55, 60, 67, 72], velocities=[70, 120])

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.bell("church"), ctx.note, ctx.vel, 8.0, ctx=ctx)
    return a.normalize_loudness(-17)
```

`freq` is the prime (strike note); the hum is an octave below. Every mode is a beating pair
(`beat_hz` ~1.2). `bell("handbell" | "tubular" | "glass" | "gong")` for other families. Mode
tables: `ph.bell(f, "church")` returns `Modes` you can edit (`freqs`, `t60`, `gains`).

### Timpani

```python
from libero import Sound, physics as ph

sound = Sound(title="Timpani", roots=[38, 43, 48, 53, 58], velocities=[50, 90, 125])

@sound.body
def body(ctx):
    a = ph.render_note(ph.presets.timpani(), ctx.note, ctx.vel, 4.0, ctx=ctx)
    return a.normalize_loudness(-16)
```

Membrane modes with air loading (1 : 1.5 : 1.99 : 2.44 : 2.89 of the (1,1) pitch), felt mallet at
half radius, upward pitch glide on hard hits. `ph.membrane(f, "ideal")` gives an unpitched tom.

### Room impulse response

```python
from libero import Sound, physics as ph

sound = Sound(title="Dry", roots=[60])

@sound.body
def body(ctx):
    return ph.render_note(ph.presets.guitar("steel"), ctx.note, ctx.vel, 3.0, ctx=ctx)

@sound.impulse
def ir(ctx):
    return ph.room_preset("chapel", sr=ctx.sr, seed=ctx.seed)
```

`ph.shoebox_ir((8, 6, 4), {"all": "plaster", "floor": "wood_floor", "ceiling": "acoustic_tile"},
source=(2, 3, 1.5), listener=(6, 3, 1.5), sr=ctx.sr)` returns a stereo IR: image-source early
reflections with per-wall, per-octave absorption, then an FDN tail whose RT60 per band follows
Eyring from the same absorption (`ph.room.reverberation_time` tells you the number). Also
`ph.spring_ir()` (dispersive 'boing', `length_ms`, `sections`, `decay`) and `ph.plate_ir()`
(finite-difference steel plate, stereo pickups; 2-4 s to compute). Use `dry.convolve(ir, mix=0.3)`
to bake a room into a body, but prefer `@sound.impulse` so the player can turn it.

## 4. Model cheat sheet (ranges)

**strings.** `pluck(freq, dur, velocity, decay 2-6, decay_hf 0.1-0.5, inharmonicity 1e-5..5e-4,
position 0.05-0.5, hardness 0-1, strings 1-4, detune_cents 0-2, bridge_t60, sympathetic=[Hz..])`;
`hammer_string(..., hammer=Hammer(mass 2-5 g, stiffness 1e8-1e11, exponent 2-3.5, damping 0-5,
impedance 0.4-8), inharmonicity, strings 1-3, bridge_t60)`; `bow(freq, dur, speed 0.05-0.6 m/s,
pressure 0-1, position 0.04-0.15, decay, decay_hf, mu_static 0.8-1, mu_dynamic 0.2-0.4)`.
Fundamental is exactly on `freq`; partial k sits at k f sqrt((1+B k^2)/(1+B)).

**winds.** `reed(freq, dur, pressure=gamma 0.45-0.8, bore='cylindrical'|'conical', zeta 0.2-0.8,
stiffness 0-1, min_opening 0-0.3, loss 0.005-0.06, cutoff Hz, apex 0.15-0.4, noise 0-1, edge 0-1)`;
`flute(freq, dur, pressure 0.85-1.15, jet_ratio None|0.25-0.45, cutoff, noise)`;
`brass(freq, dur, pressure 0.5-0.95, pedal Hz, lip_ratio None|0.65-1, zeta, brassiness 0-1, cutoff)`.
Pitch is corrected in a closed loop (`autotune=True`) and the model retries tuning variables
until the note locks on its fundamental.

**modal.** `bar/bell/membrane/plate(freq, ...) -> Modes`; `mallet_strike(modes, dur, velocity,
mallet=Mallet(hardness 0-1), position, pitch_glide_cents)`; `fd_plate(freq, dur, model='plate'|
'membrane'|'stiff_membrane', aspect, t60, t60_hf, strike, pickups)` (CFL-checked finite
differences; oversamples automatically; 1-5 s).

**performance.** `breath(dur, peak, attack, overshoot, tremor, swell, release)`, `bow_stroke`,
`vibrato(dur, rate, cents)`, `pitch_modulate`, `humanize(seed, amount)`, `render_note`, and
`ph.check(audio, freq)` -> `{locked, cents, harmonic_fraction, analysis_cents, ...}` to validate a note
while you design (cents within +-3, harmonic_fraction > 0.9 for a clean tone).

## 5. Making it sound real

1. **Never ship the bare resonator.** Strings need a body (`presets` include one); bars need a
   knock (presets add it); wind and bow models already carry noise: keep `noise` 0.2-0.5.
2. **Let velocity drive the physics**, not a gain: hammer speed, bow speed/pressure, breath
   pressure, mallet hardness. Soft layers should be darker and have slower attacks.
3. **Vary takes**: `takes=3` + `seed=ctx.seed` already changes string detuning jitter, noise and
   tremor; `ph.humanize(ctx.seed, 1.0)` or `render_note(..., humanise=0.5)` adds +-2 cent / +-0.6 dB
   / onset variation.
4. **Short decays belong in the model**, not in a fade: set `decay`/`t60`, `release` on envelopes.
5. **Put the room in `@sound.impulse`**, not in the body; bake only a small early-reflection
   flavour if the instrument needs it.
6. Check with `analyze` (f0 within +-3 cents, no DC, no energy above 18 kHz) and `spectrogram` of
   the attack: onset click plausible, partials clean, no stray lines above the top partial.

## 6. Troubleshooting

| symptom | cause | fix |
|---|---|---|
| silence or a faint hiss (reed, brass, flute) | blowing pressure below the oscillation threshold | raise `pressure` (clarinet > 0.45, flute > 0.85, brass > 0.5); `breath(...)` ramps from 0 so it crosses the threshold during the attack |
| note plays an octave/12th up | register jump (overblow) | lower `pressure` or `zeta`; for conical bores keep `cutoff` ~2.3 x freq and `apex` >= 0.2; leave `autotune` on and `jet_ratio`/`lip_ratio` None so the model retries |
| bow scratches/whistles or chokes | bow force outside the Helmholtz window | `pressure` 0.4-0.8; closer to the bridge needs less speed and more force; give `bow_stroke` a slower `attack` |
| NaN / inf or `diverged` error | extreme parameters (hammer too stiff for the step, `dur` huge, FD grid) | the models are guarded; shorten `dur`, lower `stiffness`/`speed`, use `min_grid` smaller; never pass negative T60 |
| detuned, depends on the delay length | integer delay lines quantise pitch | strings/winds solve a fractional allpass exactly; do not add your own `Audio.pitch` afterwards. High notes above sr/6 Hz raise a `too high` error: render at 88.2/96 kHz or use modal bars |
| piano/bell reads sharp or flat in `analyze` | inharmonic partials pull the estimator | real effect: partial 1 is exact, the heard pitch is higher (piano presets retune to the analyzer; for bells compare `ref='hum'`) |
| DC offset / rumble | bore pressure mean, hammer drift | every model removes DC; if you chain your own nonlinearity add `.remove_dc()` before compile |
| aliasing lines above the top partial | your own waveshaper after the model | apply filters after saturation; the models themselves are alias-safe below fs/2 |
| too clean, synthetic, "perfect" | no noise, body or instability | add `noise`, body (`ph.body.guitar()`), vibrato/`humanise`, `detune_cents`, `strings=2..3`, `edge` on reeds, `brassiness` on brass |
| too bright / too dull | damping | `decay_hf` (strings), `cutoff` (winds), `hardness` (plucks, mallets), body choice |
| double decay missing on the piano | unison strings not coupled | `strings=3` + `bridge_t60` ~ 0.2 x `decay` |
| early/late mismatch in a room IR | custom `rt60` far from the absorption | let it follow the absorption, or set absorption so `ph.room.reverberation_time` gives what you want |
| plate IR takes long | large sheet, thin plate | `size=(0.6, 0.5)`, `thickness_mm` 0.5-1; 2-4 s is normal |
