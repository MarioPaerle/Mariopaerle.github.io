"""Render previews with the plugin's engine through `libero-render` (SPEC §7).

A missing renderer is an error; a Python approximation would give a different preview.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from . import dsp, library
from .audio import Audio

REPO_ROOT = Path(__file__).resolve().parents[2]


class RenderError(Exception):
    pass


def find_renderer() -> Path | None:
    """$LIBERO_RENDER, then PATH, then ~/.local/bin, then a build tree inside the repo."""
    env = os.environ.get("LIBERO_RENDER")
    if env and Path(env).is_file() and os.access(env, os.X_OK):
        return Path(env)
    w = shutil.which("libero-render")
    if w:
        return Path(w)
    local = Path.home() / ".local" / "bin" / "libero-render"
    if local.is_file() and os.access(local, os.X_OK):
        return local
    for base in (REPO_ROOT / "build", REPO_ROOT / "plugin" / "build"):
        if base.is_dir():
            hits = sorted((p for p in base.rglob("libero-render") if p.is_file() and os.access(p, os.X_OK)),
                          key=lambda p: p.stat().st_mtime, reverse=True)
            if hits:
                return hits[0]
    return None


MISSING = ("libero-render is not installed, so no preview can be rendered. Build it with "
           "scripts/build.sh and install with scripts/install.sh (it goes to ~/.local/bin), or set "
           "LIBERO_RENDER to its path. Meanwhile, compile() and the analysis tools on the build/ zones "
           "(e.g. spectrogram(slug, 'build/body_n060_v100.wav')) still show what the bundle contains.")


def parse_notes(notes, default_dur: float = 1.5, gap: float = 0.35) -> list[tuple[int, float, float, int]]:
    """Accepts the CLI form "60:0:1.2:100,64:0.5:1.0:90" (pitch:start:dur:vel), or a
    sequence of pitches "48 60 72" / "C3 E3 G3" played one after another, or chords
    "60+64+67". Mixed forms are fine. Returns [(pitch, start, dur, vel)]."""
    if notes is None or notes == "":
        notes = "60"
    if isinstance(notes, (int, float)):
        notes = str(int(notes))
    if isinstance(notes, (list, tuple)):
        items = []
        for n in notes:
            items.append(":".join(str(v) for v in n) if isinstance(n, (list, tuple)) else str(n))
        notes = ",".join(items)
    out = []
    t = 0.0
    for tok in str(notes).replace(",", " ").split():
        if ":" in tok:
            parts = tok.split(":")
            p = dsp.parse_note(parts[0])
            s = float(parts[1]) if len(parts) > 1 and parts[1] else t
            d = float(parts[2]) if len(parts) > 2 and parts[2] else default_dur
            v = int(parts[3]) if len(parts) > 3 and parts[3] else 100
            out.append((p, s, d, v))
            t = max(t, s + d + gap)
        else:
            for p in tok.split("+"):
                out.append((dsp.parse_note(p), t, default_dur, 100))
            t += default_dur + gap
    for p, s, d, v in out:
        if not (0 <= p <= 127 and 1 <= v <= 127 and s >= 0 and d > 0):
            raise RenderError(f"bad note {p}:{s}:{d}:{v}")
    return out


def notes_arg(notes: list[tuple[int, float, float, int]]) -> str:
    return ",".join(f"{p}:{s:g}:{d:g}:{v}" for p, s, d, v in notes)


def cc_arg(cc) -> str:
    """'0:1:0,4:1:127' or [(time_s, controller, value), ...] → the CLI form."""
    if cc is None or cc == "":
        return ""
    if isinstance(cc, str):
        items = [tuple(x.split(":")) for x in cc.replace(" ", ",").split(",") if x]
    else:
        items = list(cc)
    out = []
    for it in items:
        t, c, v = float(it[0]), int(it[1]), float(it[2])
        if t < 0 or not 0 <= c <= 127 or not 0 <= v <= 127:
            raise RenderError(f"bad cc event {it}")
        out.append(f"{t:g}:{c}:{v:g}")
    return ",".join(out)


def render(sound: Path | str, out: Path | str, notes="60", params: dict | None = None, tail: float = 3.0,
           sr: int | None = None, block: int | None = None, timeout: float = 180.0, cc=None, bpm: float | None = None) -> dict:
    exe = find_renderer()
    if exe is None:
        raise RenderError(MISSING)
    parsed = parse_notes(notes)
    cmd = [str(exe), "--sound", str(sound), "--out", str(out), "--notes", notes_arg(parsed), "--tail", f"{tail:g}"]
    if params:
        from . import params as P

        cmd += ["--params", json.dumps(P.validate(params))]
    if sr:
        cmd += ["--sr", str(int(sr))]
    if block:
        cmd += ["--block", str(int(block))]
    if bpm:
        cmd += ["--bpm", f"{float(bpm):g}"]
    ccs = cc_arg(cc)
    if ccs:
        cmd += ["--cc", ccs]
    try:
        cp = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise RenderError(f"libero-render timed out after {timeout:.0f} s") from None
    if cp.returncode != 0:
        raise RenderError(f"libero-render failed ({cp.returncode}): {(cp.stderr or cp.stdout).strip()[-800:]}")
    for line in reversed(cp.stdout.strip().splitlines()):
        line = line.strip()
        if line.startswith("{"):
            try:
                return json.loads(line)
            except json.JSONDecodeError:
                break
    return {"out": str(out)}


@dataclass
class Preview:
    wav: Path
    audio: Audio
    info: dict
    compiled: str | None  # compile summary if a (re)compile was needed


def preview(slug: str, notes="60", params: dict | None = None, tail: float = 3.0, cc=None) -> Preview:
    """Compile if the bundle is missing or stale, render through libero-render, return the audio."""
    from .compiler import compile_sound

    if find_renderer() is None:
        raise RenderError(MISSING)
    folder = library.find_sound(slug)
    compiled = None
    man = folder / "build" / "manifest.json"
    stale = True
    if man.exists():
        try:
            stale = json.loads(man.read_text()).get("source_hash") != library.source_hash(folder)
        except json.JSONDecodeError:
            stale = True
    if stale:
        res = compile_sound(folder)
        if not res.ok:
            raise RenderError(f"compile failed: {res.error}")
        compiled = res.text()
    key = hashlib.sha1(json.dumps([notes, params, tail, cc], sort_keys=True, default=str).encode()).hexdigest()[:10]
    out_dir = library.cache_dir() / "previews" / slug
    out_dir.mkdir(parents=True, exist_ok=True)
    wav = out_dir / f"preview-{key}.wav"
    info = render(folder, wav, notes, params, tail, cc=cc)
    olds = sorted(out_dir.glob("preview-*.wav"), key=lambda p: p.stat().st_mtime, reverse=True)
    for p in olds[12:]:
        p.unlink(missing_ok=True)  # cache files we generated ourselves
    return Preview(wav, Audio.load(wav), info, compiled)
