"""`Audio`: an immutable, chainable buffer of float32 samples.

Mono is shape (n,), stereo (n, 2). Every operation returns a new `Audio`
and keeps the sample rate; nothing mutates in place. Times are in seconds,
levels in dB.

    body = load("cello_c3.wav").trim(0.05, 3.0).tune_to(48).fade_out(0.2)
"""

from __future__ import annotations

import contextvars
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
import soundfile as sf
from scipy import signal

from . import dsp

DEFAULT_SR = 48000

# Directories that relative paths in `load()` resolve against (set by the
# recipe runner and the workbench to the sound's samples/ and folder).
_search_dirs: contextvars.ContextVar[tuple[Path, ...]] = contextvars.ContextVar("libero_search_dirs", default=())


def set_search_dirs(*dirs: os.PathLike | str):
    return _search_dirs.set(tuple(Path(d) for d in dirs))


def resolve_path(path: os.PathLike | str) -> Path:
    p = Path(path).expanduser()
    if p.is_absolute():
        return p
    candidates = [d / p for d in _search_dirs.get()]
    if p.suffix == "":
        candidates += [d / (p.name + ".wav") for d in _search_dirs.get()]
    candidates += [Path.cwd() / p]
    for c in candidates:
        if c.exists():
            return c
    tried = ", ".join(str(c) for c in candidates)
    raise FileNotFoundError(f"sample '{path}' not found (tried: {tried})")


def load(path: os.PathLike | str, sr: int | None = None) -> "Audio":
    """Load an audio file (wav/aiff/flac/ogg/mp3). Relative paths resolve inside the
    sound's samples/ folder. If `sr` is given the audio is resampled to it."""
    return Audio.load(path, sr=sr)


@dataclass(frozen=True)
class LoopPoints:
    start: int
    end: int
    crossfade: int
    error_db: float  # match of the regions before start and end; < -30 dB is excellent

    def as_manifest(self) -> dict:
        return {"start": int(self.start), "end": int(self.end), "crossfade": int(self.crossfade)}


class Audio:
    __slots__ = ("data", "sr", "meta")

    def __init__(self, data, sr: int = DEFAULT_SR, meta: dict | None = None):
        a = np.asarray(data, dtype=np.float32)
        if a.ndim == 2 and a.shape[1] == 1:
            a = a[:, 0]
        if a.ndim == 2 and a.shape[1] > 2:
            a = a[:, :2]
        if a.ndim not in (1, 2):
            raise ValueError(f"audio must be (n,) or (n,2), got shape {a.shape}")
        a.setflags(write=False)
        self.data = a
        self.sr = int(sr)
        self.meta = dict(meta or {})

    # ------------------------------------------------------------ construction & io

    @classmethod
    def load(cls, path, sr: int | None = None) -> "Audio":
        p = resolve_path(path)
        data, file_sr = sf.read(str(p), dtype="float32", always_2d=False)
        a = cls(data, file_sr, {"source": str(p)})
        return a.resample(sr) if sr and sr != file_sr else a

    @classmethod
    def silence(cls, seconds: float, sr: int = DEFAULT_SR, stereo: bool = False) -> "Audio":
        n = int(round(seconds * sr))
        return cls(np.zeros((n, 2) if stereo else n), sr)

    def save(self, path, subtype: str = "FLOAT") -> Path:
        """Write a WAV (32-bit float by default). Returns the path."""
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        if not np.all(np.isfinite(self.data)):
            raise ValueError("refusing to save audio containing NaN/inf")
        sf.write(str(p), self.data, self.sr, subtype=subtype)
        return p

    def _new(self, data, sr: int | None = None) -> "Audio":
        return Audio(data, self.sr if sr is None else sr)

    # ------------------------------------------------------------ properties

    @property
    def n(self) -> int:
        return int(self.data.shape[0])

    def __len__(self) -> int:
        return self.n

    @property
    def channels(self) -> int:
        return 1 if self.data.ndim == 1 else 2

    @property
    def is_stereo(self) -> bool:
        return self.channels == 2

    @property
    def duration(self) -> float:
        return self.n / self.sr

    @property
    def peak_db(self) -> float:
        return dsp.db(np.abs(self.data).max(initial=0.0))

    @property
    def rms_db(self) -> float:
        if self.n == 0:
            return -200.0
        return dsp.db(math.sqrt(float(np.mean(self.data.astype(np.float64) ** 2))))

    def __repr__(self) -> str:
        ch = "stereo" if self.is_stereo else "mono"
        return f"<Audio {self.duration:.3f}s {self.sr}Hz {ch} peak {self.peak_db:.1f}dB rms {self.rms_db:.1f}dB>"

    def _s(self, t: float | None, default: int) -> int:
        if t is None:
            return default
        return int(round(t * self.sr)) if t >= 0 else self.n + int(round(t * self.sr))

    # ------------------------------------------------------------ editing

    def trim(self, t0: float = 0.0, t1: float | None = None) -> "Audio":
        """Keep [t0, t1) seconds. Negative times count from the end."""
        a = max(0, min(self.n, self._s(t0, 0)))
        b = max(a, min(self.n, self._s(t1, self.n)))
        return self._new(self.data[a:b])

    def trim_silence(self, threshold_db: float = -60.0, pad: float = 0.002) -> "Audio":
        """Remove leading/trailing material quieter than `threshold_db` below peak."""
        env = np.abs(dsp.mono(self.data))
        thr = env.max(initial=0) * dsp.undb(threshold_db)
        idx = np.nonzero(env > thr)[0]
        if len(idx) == 0:
            return self._new(self.data[:0])
        p = int(pad * self.sr)
        return self._new(self.data[max(0, idx[0] - p): min(self.n, idx[-1] + p + 1)])

    def pad(self, before: float = 0.0, after: float = 0.0) -> "Audio":
        b, a = int(round(before * self.sr)), int(round(after * self.sr))
        w = ((b, a),) if self.data.ndim == 1 else ((b, a), (0, 0))
        return self._new(np.pad(self.data, w))

    def fit(self, seconds: float) -> "Audio":
        """Pad with silence or cut to exactly `seconds`."""
        n = int(round(seconds * self.sr))
        return self.trim(0, n / self.sr) if n <= self.n else self.pad(after=(n - self.n) / self.sr)

    def tile(self, seconds: float) -> "Audio":
        """Repeat end-to-start until `seconds` long. A tiled noise is exactly periodic, so
        anything filtered from it (once the filters settle) loops without a seam."""
        n = int(round(seconds * self.sr))
        if self.n == 0 or n <= 0:
            return self._new(self.data[:0])
        reps = -(-n // self.n)
        d = np.concatenate([self.data] * reps)[:n]
        return self._new(d)

    def fade_in(self, seconds: float, curve: str = "sine") -> "Audio":
        """curve: 'linear' | 'sine' (equal power) | 'exp' (fast then slow)."""
        return self._fade(seconds, curve, True)

    def fade_out(self, seconds: float, curve: str = "sine") -> "Audio":
        return self._fade(seconds, curve, False)

    def _fade(self, seconds: float, curve: str, is_in: bool) -> "Audio":
        k = min(self.n, max(0, int(round(seconds * self.sr))))
        if k == 0:
            return self
        t = np.linspace(0.0, 1.0, k, endpoint=False) + 0.5 / k
        g = _curve(t, curve)
        y = self.data.astype(np.float64).copy()
        if is_in:
            y[:k] *= g if y.ndim == 1 else g[:, None]
        else:
            y[-k:] *= g[::-1] if y.ndim == 1 else g[::-1, None]
        return self._new(y)

    def gain_db(self, db: float) -> "Audio":
        return self._new(self.data.astype(np.float64) * dsp.undb(db))

    def gain(self, factor: float) -> "Audio":
        return self._new(self.data.astype(np.float64) * factor)

    def normalize(self, peak_db: float = -1.0) -> "Audio":
        """Scale so the sample peak sits at `peak_db` dBFS."""
        pk = np.abs(self.data).max(initial=0.0)
        if pk <= 0:
            return self
        return self._new(self.data.astype(np.float64) * (dsp.undb(peak_db) / pk))

    @property
    def lufs(self) -> float:
        """Integrated loudness (BS.1770, gated), LUFS."""
        return dsp.integrated_loudness(self.data, self.sr)

    @property
    def lufs_max(self) -> float:
        """Loudest 400 ms momentary loudness, LUFS — fair across decaying and sustained sounds."""
        return dsp.momentary_max(self.data, self.sr)

    def normalize_loudness(self, lufs: float = -16.0, momentary: bool = True, ceiling_db: float = -1.0) -> "Audio":
        """Scale to a loudness target (momentary max by default, else integrated). If that pushes
        the peak above `ceiling_db`, the peaks are limited, not the loudness lowered."""
        cur = self.lufs_max if momentary else self.lufs
        if cur <= -100:
            return self
        out = self.gain_db(lufs - cur)
        return out.limit(ceiling_db) if out.peak_db > ceiling_db else out

    def normalize_rms(self, rms_db: float = -18.0) -> "Audio":
        r = self.rms_db
        return self if r <= -199 else self.gain_db(rms_db - r)

    def reverse(self) -> "Audio":
        return self._new(self.data[::-1])

    def remove_dc(self, cutoff: float = 8.0) -> "Audio":
        return self._new(dsp.dc_block(self.data, self.sr, cutoff))

    def limit(self, ceiling_db: float = -1.0) -> "Audio":
        """Transparent offline peak limiter (look-ahead, bounded gain slopes)."""
        y, _ = dsp.limit(self.data, self.sr, ceiling_db)
        return self._new(y)

    def saturate(self, drive: float = 0.5) -> "Audio":
        """Gentle tanh saturation; drive 0..1. Level is compensated."""
        k = 1.0 + 8.0 * max(0.0, drive)
        x = self.data.astype(np.float64)
        return self._new(np.tanh(k * x) / np.tanh(k))

    # ------------------------------------------------------------ channels

    def to_mono(self) -> "Audio":
        return self if self.channels == 1 else self._new(self.data.astype(np.float64).mean(axis=1))

    def to_stereo(self) -> "Audio":
        return self if self.channels == 2 else self._new(np.stack([self.data, self.data], axis=1))

    def pan(self, position: float) -> "Audio":
        """Equal-power pan, -1 (left) .. +1 (right). Stereo input is balanced."""
        p = float(np.clip(position, -1, 1))
        th = (p + 1) * math.pi / 4
        gl, gr = math.cos(th) * math.sqrt(2), math.sin(th) * math.sqrt(2)
        s = self.to_stereo().data.astype(np.float64)
        return self._new(np.stack([s[:, 0] * gl, s[:, 1] * gr], axis=1))

    def widen(self, amount: float = 1.0) -> "Audio":
        """Mid/side width: 0 = mono, 1 = unchanged, 2 = double side."""
        s = self.to_stereo().data.astype(np.float64)
        m, d = (s[:, 0] + s[:, 1]) / 2, (s[:, 0] - s[:, 1]) / 2 * amount
        return self._new(np.stack([m + d, m - d], axis=1))

    def left(self) -> "Audio":
        return self if self.channels == 1 else self._new(self.data[:, 0])

    def right(self) -> "Audio":
        return self if self.channels == 1 else self._new(self.data[:, 1])

    # ------------------------------------------------------------ rate & pitch

    def resample(self, sr: int) -> "Audio":
        if sr == self.sr:
            return self
        return self._new(dsp.resample_to(self.data, self.sr, int(sr)), sr=int(sr))

    def pitch(self, semitones: float, preserve_duration: bool = False) -> "Audio":
        """Shift pitch by resampling (tape-style: +12 halves the duration).
        With preserve_duration=True the result is time-stretched back to length."""
        if abs(semitones) < 1e-9:
            return self
        ratio = 2.0 ** (-semitones / 12.0)
        y = self._new(dsp.resample_ratio(self.data, ratio))
        if preserve_duration:
            y = y.stretch(self.n / max(1, y.n))
        return y

    def speed(self, factor: float) -> "Audio":
        """Varispeed: factor 2 = twice as fast and an octave up."""
        return self.pitch(12.0 * math.log2(factor))

    def stretch(self, factor: float, n_fft: int | None = None) -> "Audio":
        """Time-stretch by `factor` (2 = twice as long) keeping pitch.

        Phase vocoder with identity phase locking (Laroche & Dolson); stereo phase
        is locked to the mid channel so the image does not smear."""
        if abs(factor - 1.0) < 1e-6:
            return self
        return self._new(_phase_vocoder(self.data, self.sr, factor, n_fft))

    def f0(self, t0: float | None = None, t1: float | None = None, fmin: float = 30.0, fmax: float = 4000.0) -> float:
        """Median fundamental (Hz) of the voiced part (YIN, refined by FFT). NaN if unpitched."""
        seg = self.trim(t0 or 0.0, t1) if (t0 or t1) else self
        f, _ = dsp.estimate_f0(seg.data, self.sr, fmin, fmax)
        if not np.isfinite(f):
            return float("nan")
        return dsp.refine_f0(seg.data, self.sr, f)

    def tune_to(self, note, t0: float | None = None, t1: float | None = None, fmin: float = 30.0,
                fmax: float = 4000.0) -> "Audio":
        """Detect f0 (optionally in [t0, t1]) and pitch-shift by resampling so it lands
        exactly on MIDI `note` (int or name like 'A3'). Duration changes accordingly."""
        target = dsp.midi_to_freq(dsp.parse_note(note))
        if t0 is None and t1 is None:
            # skip the attack: detect on the part after the first 10 % (max 0.3 s)
            t0 = min(0.3, 0.1 * self.duration)
        f = self.f0(t0, t1, fmin, fmax)
        if not np.isfinite(f):
            raise ValueError("tune_to: no stable pitch detected (is the sample pitched?)")
        st = 12.0 * math.log2(target / f)
        out = self.pitch(st)
        out.meta.update(detected_hz=f, shift_semitones=st)
        return out

    # ------------------------------------------------------------ filters

    def _biquad(self, kind: str, freq: float, q: float, gain_db: float = 0.0, order: int = 1,
                zero_phase: bool = False) -> "Audio":
        sos = np.vstack([dsp.rbj_biquad(kind, freq, self.sr, q, gain_db)] * max(1, order))
        return self._new(dsp.sosfilt(sos, self.data, zero_phase))

    def lowpass(self, freq: float, q: float = 0.7071, order: int = 1, zero_phase: bool = False) -> "Audio":
        """12 dB/oct per order (RBJ biquads in series)."""
        return self._biquad("lowpass", freq, q, 0, order, zero_phase)

    def highpass(self, freq: float, q: float = 0.7071, order: int = 1, zero_phase: bool = False) -> "Audio":
        return self._biquad("highpass", freq, q, 0, order, zero_phase)

    def bandpass(self, freq: float, q: float = 1.0, order: int = 1) -> "Audio":
        return self._biquad("bandpass", freq, q, 0, order)

    def notch(self, freq: float, q: float = 4.0) -> "Audio":
        return self._biquad("notch", freq, q)

    def peak(self, freq: float, gain_db: float, q: float = 1.0) -> "Audio":
        """Peaking EQ bell."""
        return self._biquad("peak", freq, q, gain_db)

    def lowshelf(self, freq: float, gain_db: float, q: float = 0.7071) -> "Audio":
        return self._biquad("lowshelf", freq, q, gain_db)

    def highshelf(self, freq: float, gain_db: float, q: float = 0.7071) -> "Audio":
        return self._biquad("highshelf", freq, q, gain_db)

    def tilt(self, db_per_octave: float, pivot: float = 1000.0) -> "Audio":
        """Spectral tilt around `pivot` Hz (positive = brighter), via two shelves."""
        g = db_per_octave * 3.0
        return self.lowshelf(pivot / 2.8, -g / 2).highshelf(pivot * 2.8, g / 2)

    # ------------------------------------------------------------ combination

    def _match(self, other: "Audio") -> "Audio":
        o = other.resample(self.sr) if other.sr != self.sr else other
        return o

    def convolve(self, ir: "Audio", mix: float = 1.0, normalize: bool = True) -> "Audio":
        """FFT convolution with an impulse response. Output length = n + len(ir) - 1.

        `mix` blends dry (padded) and wet. With normalize=True the wet signal is
        scaled to the dry signal's RMS so `mix` is a balance, not a level jump.
        A stereo IR makes the result stereo."""
        ir = self._match(ir)
        x = self.data.astype(np.float64)
        h = ir.data.astype(np.float64)
        if x.ndim == 1 and h.ndim == 1:
            wet = signal.oaconvolve(x, h)
        else:
            x2, h2 = dsp.as_2d(x), dsp.as_2d(h)
            if x2.shape[1] == 1:
                x2 = np.repeat(x2, 2, axis=1)
            if h2.shape[1] == 1:
                h2 = np.repeat(h2, 2, axis=1)
            wet = np.stack([signal.oaconvolve(x2[:, c], h2[:, c]) for c in range(2)], axis=1)
        if normalize:
            rw = math.sqrt(float(np.mean(wet**2)) + 1e-30)
            rd = math.sqrt(float(np.mean(x**2)) + 1e-30)
            wet *= rd / rw * math.sqrt(len(x) / len(wet))
        dry = np.zeros_like(wet)
        if dry.ndim == 2 and x.ndim == 1:
            dry[: len(x)] = x[:, None]
        else:
            dry[: len(x)] = x
        return self._new((1.0 - mix) * dry + mix * wet)

    def mix(self, *others: "Audio", gains_db: Sequence[float] | None = None) -> "Audio":
        """Sum from time zero, padding lengths. gains_db applies to others only,
        in their argument order; set the base level with self.gain_db(...).
        Supply one gain per other sound.
        """
        out = self
        for i, o in enumerate(others):
            g = gains_db[i] if gains_db else 0.0
            out = out.place(o, 0.0, g)
        return out

    def place(self, other: "Audio", at: float = 0.0, gain_db: float = 0.0) -> "Audio":
        """Mix `other` starting at `at` seconds (negative = pre-roll is cut). Extends if needed."""
        o = self._match(other)
        start = int(round(at * self.sr))
        od = o.data.astype(np.float64) * dsp.undb(gain_db)
        if start < 0:
            od = od[-start:]
            start = 0
        stereo = self.is_stereo or o.is_stereo
        base = self.to_stereo().data if stereo else self.data
        od = np.stack([od, od], axis=1) if (stereo and od.ndim == 1) else od
        n = max(len(base), start + len(od))
        y = np.zeros((n, 2) if stereo else n)
        y[: len(base)] += base
        y[start: start + len(od)] += od
        return self._new(y)

    def concat(self, *others: "Audio", crossfade: float = 0.0) -> "Audio":
        """Join end to start; `crossfade` seconds of equal-power overlap at each joint."""
        out = self
        for o in others:
            o = out._match(o)
            k = int(round(crossfade * out.sr))
            k = min(k, out.n, o.n)
            if k == 0:
                stereo = out.is_stereo or o.is_stereo
                a = out.to_stereo().data if stereo else out.data
                b = o.to_stereo().data if stereo else o.data
                out = out._new(np.concatenate([a, b]))
            else:
                out = out.fade_out(k / out.sr).place(o.fade_in(k / out.sr), (out.n - k) / out.sr)
        return out

    def __add__(self, other: "Audio") -> "Audio":
        return self.mix(other)

    def transient(self, other: "Audio", overlap_ms: float = 12.0, gain_db: float = 0.0,
                  body_delay_ms: float = 0.0) -> "Audio":
        """Attach `other` as the attack of this sound.

        Onsets are aligned; the body (self) is faded in over `overlap_ms` from its
        onset (+ optional `body_delay_ms`) so the transient owns the first
        milliseconds, and the transient keeps ringing on top of the body."""
        o = self._match(other)
        so = dsp.onset_sample(self.data, self.sr)
        oo = dsp.onset_sample(o.data, o.sr)
        k = max(1, int(overlap_ms * 1e-3 * self.sr))
        d = int(body_delay_ms * 1e-3 * self.sr)
        g = np.ones(self.n)
        a = min(self.n, so + d)
        g[:a] = 0.0
        ramp = _curve(np.linspace(0, 1, k, endpoint=False) + 0.5 / k, "sine")
        g[a: a + k] = ramp[: max(0, min(k, self.n - a))]
        body = self.data.astype(np.float64) * (g if self.data.ndim == 1 else g[:, None])
        at = (so - oo) / self.sr
        return self._new(body).place(o, at, gain_db)

    # ------------------------------------------------------------ envelopes & noise

    def envelope(self, points: Sequence[tuple[float, float]] | None = None, *,
                 adsr: tuple[float, float, float, float] | None = None,
                 release_at: float | None = None, curve: str = "exp") -> "Audio":
        """Multiply by an amplitude envelope.

        points: breakpoints [(time_s, gain), ...] with linear gain 0..1 (interpolated
                in dB when curve='exp', linearly when curve='linear').
        adsr:   (attack_s, decay_s, sustain_level, release_s); the release starts at
                `release_at` (default: duration - release_s)."""
        if adsr is not None:
            a, d, s, r = adsr
            ra = self.duration - r if release_at is None else release_at
            ads = [(0.0, 0.0), (a, 1.0), (a + d, s)]
            lvl = float(np.interp(ra, [p[0] for p in ads], [p[1] for p in ads]))
            points = [p for p in ads if p[0] < ra] + [(ra, lvl), (ra + r, 0.0)]
        if not points:
            return self
        t = np.arange(self.n) / self.sr
        pts = sorted(points, key=lambda p: p[0])
        xs = np.asarray([float(p[0]) for p in pts])
        ys = np.asarray([float(p[1]) for p in pts])
        if curve == "exp":
            floor = 1e-4
            env = np.exp(np.interp(t, xs, np.log(np.maximum(ys, floor))))
            env[env <= floor * 1.0001] = 0.0
            # exact zeros where the breakpoint says zero, fading into them linearly for the last 60 dB
            lin = np.interp(t, xs, ys)
            env = np.where(lin < 1e-3, np.minimum(env, lin * 10), env)
        else:
            env = np.interp(t, xs, ys)
        y = self.data.astype(np.float64) * (env if self.data.ndim == 1 else env[:, None])
        return self._new(y)

    def noise_floor(self, db: float = -60.0, color: str = "pink", seed: int = 0,
                    lowpass: float | None = None) -> "Audio":
        """Add a steady noise bed at `db` dBFS RMS over the whole length."""
        from . import synth

        nz = synth.noise(color, self.duration, sr=self.sr, seed=seed, stereo=self.is_stereo)
        if lowpass:
            nz = nz.lowpass(lowpass)
        nz = nz.fit(self.duration).normalize_rms(db)
        return self.place(nz, 0.0)

    def tremolo(self, rate: float = 5.0, depth: float = 0.3) -> "Audio":
        t = np.arange(self.n) / self.sr
        g = 1.0 - depth * 0.5 * (1 - np.cos(2 * math.pi * rate * t))
        y = self.data.astype(np.float64) * (g if self.data.ndim == 1 else g[:, None])
        return self._new(y)

    # ------------------------------------------------------------ analysis helpers

    def onset(self) -> float:
        """Onset time in seconds (-30 dB crossing of the 1 ms envelope)."""
        return dsp.onset_sample(self.data, self.sr) / self.sr

    def loop_points(self, min_seconds: float = 0.4, region: tuple[float, float] | None = None,
                    window: float = 0.03, max_crossfade: float = 0.25) -> LoopPoints | None:
        """Find a seamless sustain loop.

        Both points sit on rising zero crossings; the loop is chosen so the
        `window` seconds before `end` match those before `start` (normalised
        squared error, reported as `error_db`). Among near-equal matches the
        longest loop wins, which keeps chorused material from sounding stuck.
        `region` = (t0, t1) seconds limits the search (default: from the end of
        the attack to the end of the file)."""
        return _find_loop(self, min_seconds, region, window, max_crossfade)

    def bake_loop(self, lp: LoopPoints) -> "Audio":
        """Cut at `lp.end` and blend the last `crossfade` samples toward the audio just
        before `lp.start`, so a hard jump end→start is already seamless."""
        s, e, xf = lp.start, lp.end, min(lp.crossfade, lp.start, lp.end - lp.start)
        y = self.data[:e].astype(np.float64).copy()
        if xf > 0:
            t = (np.arange(xf) + 0.5) / xf
            shape = "linear" if lp.error_db < -6 else "sine"
            gin = _curve(t, shape)
            gout = _curve(1 - t, shape)
            src = self.data[s - xf: s].astype(np.float64)
            if y.ndim == 2:
                gin, gout = gin[:, None], gout[:, None]
            y[e - xf: e] = y[e - xf: e] * gout + src * gin
        return self._new(y)


# ---------------------------------------------------------------- helpers

def _curve(t: np.ndarray, curve: str) -> np.ndarray:
    t = np.clip(t, 0.0, 1.0)
    if curve == "linear":
        return t
    if curve == "sine":
        return np.sin(0.5 * math.pi * t)
    if curve == "exp":
        return (np.exp(4 * t) - 1) / (math.e**4 - 1)
    if curve == "log":
        return 1 - (np.exp(4 * (1 - t)) - 1) / (math.e**4 - 1)
    raise ValueError(f"unknown curve '{curve}'")


def _phase_vocoder(x: np.ndarray, sr: int, factor: float, n_fft: int | None) -> np.ndarray:
    x = x.astype(np.float64)
    x2 = dsp.as_2d(x)
    N = n_fft or (4096 if sr >= 44100 else 2048)
    Hs = N // 4
    Ha = Hs / factor
    win = np.hanning(N + 1)[:-1]
    n_out = int(round(len(x2) * factor))
    lead = int(round(N * factor))  # the N samples of front padding, on the output timeline
    n_frames = int(math.ceil((lead + n_out + N) / Hs)) + 1
    tail_pad = int(math.ceil(n_frames * Ha)) + 2 * N - len(x2)
    pad = np.pad(x2, ((N, max(N, tail_pad)), (0, 0)))
    ch = x2.shape[1]
    out = np.zeros((n_frames * Hs + N, ch))
    wsum = np.zeros(n_frames * Hs + N)
    omega = 2 * math.pi * np.arange(N // 2 + 1) / N
    mid = pad.mean(axis=1)

    def spec(sig, pos):
        seg = sig[pos: pos + N]
        if len(seg) < N:
            seg = np.pad(seg, (0, N - len(seg)) if seg.ndim == 1 else ((0, N - len(seg)), (0, 0)))
        return np.fft.rfft(seg * (win if seg.ndim == 1 else win[:, None]), axis=0)

    prev_pos = 0
    Xm_prev = spec(mid, 0)
    phase_prev = np.angle(Xm_prev)
    synth_phase = phase_prev.copy()
    for f in range(n_frames):
        pos = int(round(f * Ha))
        Xm = spec(mid, pos)
        X = spec(pad, pos)
        mag_m = np.abs(Xm)
        ph_m = np.angle(Xm)
        if f > 0:
            hop = pos - prev_pos
            if hop > 0:
                dphi = ph_m - phase_prev - omega * hop
                dphi = (dphi + math.pi) % (2 * math.pi) - math.pi
                inst = omega + dphi / hop
            else:
                inst = omega
            # identity phase locking: peaks advance freely, the rest follow their peak
            pk = signal.argrelmax(np.concatenate([[0], mag_m, [0]]))[0] - 1
            adv = synth_phase + inst * Hs
            if len(pk):
                edges = np.concatenate([[0], ((pk[:-1] + pk[1:]) // 2) + 1, [len(mag_m)]])
                owner = np.repeat(pk, np.diff(edges))
                synth_phase = adv[owner] + (ph_m - ph_m[owner])
            else:
                synth_phase = adv
        prev_pos = pos
        phase_prev = ph_m
        # each channel keeps its offset from the mid phase
        rot = np.exp(1j * (synth_phase - ph_m))
        Y = X * rot[:, None]
        frame = np.fft.irfft(Y, N, axis=0) * win[:, None]
        o = f * Hs
        out[o: o + N] += frame
        wsum[o: o + N] += win**2
    wsum = np.maximum(wsum, 1e-3 * wsum.max())
    y = out / wsum[:, None]
    y = y[lead: lead + n_out]
    if len(y) < n_out:
        y = np.pad(y, ((0, n_out - len(y)), (0, 0)))
    return y[:, 0] if x.ndim == 1 else y


def _find_loop(a: Audio, min_seconds: float, region, window: float, max_crossfade: float) -> LoopPoints | None:
    sr = a.sr
    m = dsp.mono(a.data.astype(np.float64))
    n = len(m)
    w = max(64, int(window * sr))
    if region is None:
        # default: from the end of the attack (envelope first within 1 dB of its max, + 50 ms,
        # at least 15 % in) to the end
        t, e = dsp.rms_envelope(m, sr, 0.02)
        att_t = t[int(np.argmax(e >= 0.9 * e.max()))] if len(e) and e.max() > 0 else 0.0
        lo = max(int((att_t + 0.05) * sr), int(0.15 * n))
        hi = n - int(0.005 * sr)
    else:
        lo, hi = int(region[0] * sr), int(min(n, region[1] * sr))
    lo = max(lo, w + 1)
    min_len = int(min_seconds * sr)
    if hi - lo < min_len + w:
        return None
    zc = np.nonzero((m[:-1] < 0) & (m[1:] >= 0))[0] + 1
    zc = zc[(zc >= lo) & (zc <= hi)]
    if len(zc) < 2:
        return None
    # end candidates: rising zero crossings in the last 20 % of the region
    tail_lo = hi - max(int(0.2 * (hi - lo)), int(0.05 * sr))
    ends = zc[zc >= tail_lo]
    if len(ends) == 0:
        return None
    if len(ends) > 24:
        ends = ends[np.linspace(0, len(ends) - 1, 24).astype(int)]
    c2 = np.concatenate([[0.0], np.cumsum(m**2)])
    best = []  # (err_db, length, s, e)
    for e in ends:
        s_hi = e - min_len
        if s_hi <= lo:
            continue
        cand = zc[(zc >= lo) & (zc <= s_hi)]
        if len(cand) == 0:
            continue
        T = m[e - w: e]
        Et = float(np.dot(T, T))
        seg = m[lo - w: s_hi]
        corr = signal.fftconvolve(seg, T[::-1], mode="valid")  # corr[j] = sum seg[j:j+w]*T
        # candidate s uses window m[s-w:s] = seg[(s-lo) : (s-lo)+w]
        j = cand - lo
        Es = c2[cand] - c2[cand - w]
        err = (Es + Et - 2 * corr[j]) / np.maximum(Es + Et, 1e-20)
        err_db = 10 * np.log10(np.maximum(err, 1e-12))
        for k in np.argsort(err_db)[:8]:
            best.append((float(err_db[k]), int(e - cand[k]), int(cand[k]), int(e)))
    if not best:
        return None
    best.sort()
    top = best[0][0]
    # prefer the longest loop among near-best candidates
    pool = [b for b in best if b[0] <= top + 1.5]
    err_db, length, s, e = max(pool, key=lambda b: b[1])
    if err_db < -35:
        xf = int(0.01 * sr)
    elif err_db < -20:
        xf = int(0.06 * sr)
    else:
        xf = int(max_crossfade * sr)
    xf = max(32, min(xf, length // 3, s))
    return LoopPoints(start=s, end=e, crossfade=xf, error_db=round(err_db, 1))
