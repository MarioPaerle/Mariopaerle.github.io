"""The library on disk (SPEC §2): sketches, saved sounds, safe file access,
and bundle validation (SPEC §4)."""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import stat
import time
from pathlib import Path

import soundfile as sf

SLUG_RE = re.compile(r"^[a-z0-9-]{1,48}$")
TEMPLATES_DIR = Path(__file__).parent / "templates"
TEXT_SUFFIXES = {".md", ".txt", ".json", ".py", ".csv", ".yaml", ".yml"}
AUDIO_SUFFIXES = {".wav", ".aif", ".aiff", ".flac", ".ogg", ".mp3", ".caf", ".m4a"}


class LibraryError(Exception):
    pass


# ---------------------------------------------------------------- locations

def home() -> Path:
    return Path(os.environ.get("LIBERO_HOME") or Path.home() / "Libero").expanduser()


def sketches_dir() -> Path:
    return _mk(home() / "sketches")


def sounds_dir() -> Path:
    return _mk(home() / "sounds")


def banks_dir() -> Path:
    return home() / "banks"


def cache_dir() -> Path:
    return _mk(home() / "cache")


def instances_dir() -> Path:
    return home() / "instances"


def trash_dir() -> Path:
    return Path(os.environ.get("LIBERO_TRASH") or Path.home() / ".Trash").expanduser()


def _mk(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def config() -> dict:
    p = home() / "config.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except (OSError, json.JSONDecodeError):
        return {}


def write_config(cfg: dict) -> None:
    p = home() / "config.json"
    _mk(p.parent)
    p.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")


TAG_COLORS = (1, 2, 3, 4)     # 0 = none; the UI names them (Pompeian red, ochre, verdigris, lapis)


def color_tag(slug: str) -> int:
    n = (config().get("tags") or {}).get(slug, 0)
    return n if n in TAG_COLORS else 0


def set_color_tag(slug: str, n: int) -> int:
    """Colour tag of a sound, kept in config.json under `tags` keyed by slug (so it survives moves)."""
    check_slug(slug)
    if n not in (0, *TAG_COLORS):
        raise LibraryError(f"colour tag must be 0 (none) or 1-{TAG_COLORS[-1]}")
    cfg = config()
    tags = dict(cfg.get("tags") or {})
    if n:
        tags[slug] = n
    else:
        tags.pop(slug, None)
    if tags:
        cfg["tags"] = tags
    else:
        cfg.pop("tags", None)
    write_config(cfg)
    return n


def check_slug(slug: str) -> str:
    if not isinstance(slug, str) or not SLUG_RE.match(slug):
        raise LibraryError(f"invalid slug {slug!r}: use 1-48 chars of a-z, 0-9 and '-'")
    return slug


# ---------------------------------------------------------------- sounds

def find_sound(slug: str) -> Path:
    """The folder of `slug` (sketches first, then saved sounds, then banks in alphabetical order)."""
    check_slug(slug)
    for base in (sketches_dir(), sounds_dir(), *_bank_dirs()):
        p = base / slug
        if (p / "sound.py").exists() or p.is_dir():
            return p
    raise LibraryError(f"no sound or sketch named '{slug}'")


def is_saved(folder: Path) -> bool:
    parent = folder.resolve().parent
    return parent == sounds_dir().resolve() or parent.parent == banks_dir().resolve()


def templates() -> list[str]:
    return sorted(p.stem for p in TEMPLATES_DIR.glob("*.py") if not p.name.startswith("_"))


def new_sound(slug: str, template: str = "plucked", title: str | None = None, subtitle: str = "") -> Path:
    """Create sketches/<slug>/ from a template recipe."""
    check_slug(slug)
    for base in (sketches_dir(), sounds_dir(), *_bank_dirs()):
        if (base / slug).exists():
            raise LibraryError(f"'{slug}' already exists in {base.parent.name + '/' if base.parent != home() else ''}{base.name}/")
    src = TEMPLATES_DIR / f"{template}.py"
    if not src.exists():
        raise LibraryError(f"unknown template '{template}'; available: {', '.join(templates())}")
    folder = sketches_dir() / slug
    (folder / "samples").mkdir(parents=True)
    title = title or slug.replace("-", " ").title()
    code = src.read_text()
    code = code.replace("__TITLE__", _py_str(title)).replace("__SUBTITLE__", _py_str(subtitle))
    (folder / "sound.py").write_text(code)
    (folder / "notes.md").write_text(
        f"# {title}\n\n{subtitle or 'Intent: (one paragraph: what this sound is and where it lives).'}\n\n"
        f"## Log\n\n- started from the `{template}` template\n")
    return folder


def _py_str(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")


def _read_meta(folder: Path) -> dict:
    meta = {"title": folder.name, "subtitle": "", "tags": []}
    man = folder / "build" / "manifest.json"
    if man.exists():
        try:
            m = json.loads(man.read_text())
            meta.update({k: m.get(k, meta[k]) for k in ("title", "subtitle", "tags")})
            meta["compiled_at"] = m.get("compiled_at")
            return meta
        except (OSError, json.JSONDecodeError):
            pass
    sp = folder / "sound.py"
    if sp.exists():
        txt = sp.read_text(errors="replace")
        for key in ("title", "subtitle"):
            mm = re.search(rf'{key}\s*=\s*"([^"]*)"', txt)
            if mm:
                meta[key] = mm.group(1)
    return meta


def list_sounds() -> list[dict]:
    out = []
    bases = [(sketches_dir(), False, "prove"), (sounds_dir(), True, "mie")] + [(b, True, b.name) for b in _bank_dirs()]
    for base, saved, bank in bases:
        for p in sorted(base.iterdir()):
            if not p.is_dir() or not SLUG_RE.match(p.name):
                continue
            m = _read_meta(p)
            out.append({
                "slug": p.name, "saved": saved, "path": str(p), "title": m["title"], "subtitle": m["subtitle"],
                "tags": m.get("tags", []), "compiled": (p / "build" / "manifest.json").exists(),
                "figure": (p / "figure.svg").exists(), "bank": bank, "color_tag": color_tag(p.name),
            })
    return out


def save_sound(slug: str) -> Path:
    """Move a sketch into the library (sketches/<slug> → sounds/<slug>)."""
    src = sketches_dir() / check_slug(slug)
    if not src.is_dir():
        if any((b / slug).is_dir() for b in (sounds_dir(), *_bank_dirs())):
            raise LibraryError(f"'{slug}' is already saved")
        raise LibraryError(f"no sketch named '{slug}'")
    dst = sounds_dir() / slug
    if dst.exists():
        raise LibraryError(f"sounds/{slug} already exists; discard or rename one of them first")
    os.replace(src, dst)
    return dst


def discard_sound(slug: str, allow_saved: bool = False) -> Path:
    """Move a sketch (or, with allow_saved, a saved sound) to the Trash. Never deletes."""
    check_slug(slug)
    src = sketches_dir() / slug
    if not src.is_dir():
        if allow_saved and (sounds_dir() / slug).is_dir():
            src = sounds_dir() / slug
        else:
            raise LibraryError(f"no sketch named '{slug}'" + ("" if allow_saved else " (saved sounds are not discarded)"))
    trash = _mk(trash_dir())
    dst = trash / f"libero-{slug}"
    if dst.exists():
        dst = trash / f"libero-{slug}-{time.strftime('%Y%m%d-%H%M%S')}"
    try:
        os.rename(src, dst)
    except OSError:
        shutil.move(str(src), str(dst))
    return dst


# ---------------------------------------------------------------- files inside a sound

def safe_path(folder: Path, rel: str, write: bool = False) -> Path:
    """Resolve `rel` inside `folder`, refusing anything that escapes it.
    For writes only sound.py, notes.md, figure.svg and samples/** are allowed."""
    if not isinstance(rel, str) or not rel.strip():
        raise LibraryError("empty path")
    rp = Path(rel)
    if rp.is_absolute() or any(part in ("..", "") for part in rp.parts) or "\x00" in rel:
        raise LibraryError(f"path {rel!r} must be relative to the sound folder, without '..'")
    root = folder.resolve()
    target = (root / rp).resolve()
    if target != root and root not in target.parents:
        raise LibraryError(f"path {rel!r} escapes the sound folder")
    if write:
        top = rp.parts[0]
        if len(rp.parts) == 1 and top in ("sound.py", "notes.md", "figure.svg"):
            return target
        if top == "samples" and len(rp.parts) >= 2:
            return target
        raise LibraryError("writable files: sound.py, notes.md, figure.svg, samples/<file>")
    return target


def read_file(slug: str, rel: str) -> str:
    p = safe_path(find_sound(slug), rel)
    if not p.is_file():
        raise LibraryError(f"{rel} does not exist in '{slug}'")
    if p.suffix.lower() in AUDIO_SUFFIXES:
        raise LibraryError(f"{rel} is audio; use analyze/spectrogram/waveform to inspect it")
    if p.stat().st_size > 512_000:
        raise LibraryError(f"{rel} is larger than 500 KB")
    return p.read_text(errors="replace")


def write_file(slug: str, rel: str, content: str) -> Path:
    folder = find_sound(slug)
    p = safe_path(folder, rel, write=True)
    if Path(rel).parts[0] == "samples" and p.suffix.lower() not in TEXT_SUFFIXES:
        raise LibraryError(f"only text files ({', '.join(sorted(TEXT_SUFFIXES))}) can be written into samples/")
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(content)
    os.replace(tmp, p)
    return p


def sample_path(folder: Path, name: str, must_exist: bool = True) -> Path:
    """samples/<name> (adds .wav when no suffix). Paths containing '/' are taken
    relative to the sound folder (e.g. 'build/body_n060_v100.wav')."""
    if "/" in name:
        p = safe_path(folder, name)
    else:
        p = safe_path(folder, f"samples/{name}")
        if p.suffix == "" or (not p.exists() and p.suffix.lower() not in AUDIO_SUFFIXES):
            p = p.with_name(p.name + ".wav")
    if must_exist and not p.exists():
        avail = ", ".join(s["name"] for s in list_samples(folder)[:30]) or "none"
        raise LibraryError(f"sample '{name}' not found (available: {avail})")
    return p


def out_sample_path(folder: Path, name: str) -> Path:
    stem = Path(name).stem if name.lower().endswith(".wav") else name
    if not re.match(r"^[A-Za-z0-9_.-]{1,80}$", stem) or stem.startswith("."):
        raise LibraryError(f"bad sample name {name!r}: letters, digits, '_', '-', '.' only")
    return safe_path(folder, f"samples/{stem}.wav", write=True)


def list_samples(folder: Path) -> list[dict]:
    d = folder / "samples"
    out = []
    if not d.is_dir():
        return out
    for p in sorted(d.rglob("*")):
        if not p.is_file() or p.name.startswith(".") or "__pycache__" in p.parts:
            continue
        rel = str(p.relative_to(d))
        item = {"name": rel, "bytes": p.stat().st_size}
        if p.suffix.lower() in AUDIO_SUFFIXES:
            try:
                info = sf.info(str(p))
                item.update(seconds=round(info.duration, 3), sr=info.samplerate, channels=info.channels)
            except RuntimeError:
                item["unreadable"] = True
        out.append(item)
    return out


# ---------------------------------------------------------------- hashing

_DIGESTS: dict | None = None


def file_digest(p: Path) -> bytes:
    """sha256 of a file's bytes, memoised by (path, size, mtime) in cache/digests.json so large
    sample sets are not re-read on every compile."""
    global _DIGESTS
    st = p.stat()
    key = f"{p.resolve()}|{st.st_size}|{st.st_mtime_ns}"
    if st.st_size < 1 << 20:
        return hashlib.sha256(p.read_bytes()).digest()
    memo = cache_dir() / "digests.json"
    if _DIGESTS is None:
        try:
            _DIGESTS = json.loads(memo.read_text())
        except (OSError, json.JSONDecodeError):
            _DIGESTS = {}
    hx = _DIGESTS.get(key)
    if hx is None:
        h = hashlib.sha256()
        with open(p, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 22), b""):
                h.update(chunk)
        hx = h.hexdigest()
        _DIGESTS[key] = hx
        try:
            tmp = memo.with_name(f"digests.{os.getpid()}.tmp")
            tmp.write_text(json.dumps(_DIGESTS))
            os.replace(tmp, memo)
        except OSError:
            pass
    return bytes.fromhex(hx)


def sample_files(folder: Path) -> list[Path]:
    sd = folder / "samples"
    if not sd.is_dir():
        return []
    return [p for p in sorted(sd.rglob("*"))
            if p.is_file() and not p.name.startswith(".") and "__pycache__" not in p.parts]


def source_hash(folder: Path) -> str:
    """sha256 over sound.py and every file under samples/ (paths and content digests)."""
    h = hashlib.sha256()
    sp = folder / "sound.py"
    h.update(b"sound.py\0")
    h.update(sp.read_bytes() if sp.exists() else b"")
    for p in sample_files(folder):
        h.update(str(p.relative_to(folder)).encode() + b"\0")
        h.update(file_digest(p))
    return h.hexdigest()


# ---------------------------------------------------------------- bundle validation (SPEC §4)

BUNDLE_V1 = "libero.bundle/1"
BUNDLE_V2 = "libero.bundle/2"
MAX_TAKES = 32
ZONE_V2_FIELDS = ("dyn", "tune_cents", "rt_decay", "rt_min_db", "onset_ms", "one_shot", "choke_group", "chokes",
                  "articulation")
MANIFEST_V2_FIELDS = ("dynamics", "humanize", "rr_reset_ms", "onset_ms", "one_shot", "articulations")
MAX_ARTICULATIONS = 16
OSC_LEVELS = ("osc1_level", "osc2_level", "sub_level")


def oscillators_on(params: dict) -> bool:
    """True when a sound's default params turn at least one live oscillator on."""
    return any(_num(params.get(k, -60)) and params.get(k, -60) > -59.9 for k in OSC_LEVELS)
DYN_SOURCES = ("velocity", "cc1", "cc11")


def bundle_uses_v2(m: dict, build: Path | None = None) -> bool:
    """True when a manifest needs `libero.bundle/2`: any v2 zone/manifest field, more than 8
    takes, or zone files that are not 32-bit float WAV (FLAC, PCM WAV)."""
    if any(k in m for k in MANIFEST_V2_FIELDS):
        return True
    if "body" not in {z.get("layer") for z in m.get("zones", [])}:
        return True   # oscillator-only (or no body): bundle/2
    for z in m.get("zones", []):
        take = z.get("take", 0)
        if any(k in z for k in ZONE_V2_FIELDS) or (isinstance(take, int) and not isinstance(take, bool) and take >= 8):
            return True
        if not str(z.get("file", "")).lower().endswith(".wav"):
            return True
        if build is not None and (build / z["file"]).exists():
            if sf.info(str(build / z["file"])).subtype != "FLOAT":
                return True
    return False


def validate_articulations(arts) -> list[str]:
    """Problems with a manifest `articulations` list (ids unique, names, keys unique MIDI notes, <= 16)."""
    if not isinstance(arts, list) or not arts:
        return ["articulations must be a non-empty list"]
    probs: list[str] = []
    if len(arts) > MAX_ARTICULATIONS:
        probs.append(f"at most {MAX_ARTICULATIONS} articulations (the `artic` parameter's range)")
    ids, keys = set(), set()
    for i, a in enumerate(arts):
        if not isinstance(a, dict):
            probs.append(f"articulation {i} must be an object")
            continue
        aid = a.get("id")
        if not isinstance(aid, str) or not re.fullmatch(r"[a-z0-9_]+", aid):
            probs.append(f"articulation {i}: id must be a lowercase [a-z0-9_] string, got {aid!r}")
        elif aid in ids:
            probs.append(f"articulation id {aid!r} is not unique")
        ids.add(aid)
        if not isinstance(a.get("name"), str) or not a["name"]:
            probs.append(f"articulation {aid!r}: name must be a non-empty string")
        k = a.get("key")
        if k is not None:
            if isinstance(k, bool) or not isinstance(k, int) or not 0 <= k <= 127:
                probs.append(f"articulation {aid!r}: key must be a MIDI note 0..127 or null, got {k!r}")
            elif k in keys:
                probs.append(f"articulation {aid!r}: key {k} is already another articulation's keyswitch")
            else:
                keys.add(k)
        profile = a.get("params")
        if profile is not None:
            if not isinstance(profile, dict):
                probs.append(f"articulation {aid!r}: params must be an object of live parameter overrides")
            else:
                allowed = {"osc1_wave", "osc1_level", "osc2_wave", "osc2_level", "sub_wave",
                           "sub_level", "sub_divisor", "sub2_level", "sub2_divisor", "sub3_level",
                           "sub3_divisor", "flt_mode", "flt_cutoff", "flt_reso", "flt_dyn", "drive",
                           "amp_dyn", "amp_attack", "amp_release", "glide", "lfo_pitch", "lfo_pitch_cc1",
                           "vel_amp_curve", "lfo_rate", "lfo_delay"}
                extra = set(profile) - allowed
                if extra:
                    probs.append(f"articulation {aid!r}: unsupported live profile parameters {sorted(extra)}")
                from . import params as P
                try:
                    P.validate(profile)
                except P.ParamError as e:
                    probs.append(f"articulation {aid!r}: {e}")
    return probs


def _num(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and v == v


def validate_bundle(build: Path) -> list[str]:
    """Check a compiled bundle against SPEC §4 (formats libero.bundle/1 and /2).
    Returns a list of problems (empty = valid)."""
    from . import params as P

    build = Path(build)
    probs: list[str] = []
    mp = build / "manifest.json"
    if not mp.exists():
        return [f"{mp} missing"]
    try:
        m = json.loads(mp.read_text())
    except json.JSONDecodeError as e:
        return [f"manifest.json is not valid JSON: {e}"]
    fmt = m.get("format")
    if fmt not in (BUNDLE_V1, BUNDLE_V2):
        probs.append(f"format must be '{BUNDLE_V1}' or '{BUNDLE_V2}', got {fmt!r}")
    for k, typ in (("slug", str), ("title", str), ("subtitle", str), ("tags", list), ("description", str),
                   ("sample_rate", int), ("compiled_at", str), ("source_hash", str), ("zones", list),
                   ("params", dict)):
        if not isinstance(m.get(k), typ):
            probs.append(f"'{k}' missing or not {typ.__name__}")
    if probs:
        return probs
    v2 = fmt == BUNDLE_V2
    if not v2 and bundle_uses_v2(m, build):
        probs.append(f"uses bundle/2 features (dyn, tune_cents, rt_*, dynamics, humanize, rr_reset_ms, "
                     f"> 8 takes or non-float zone files) but declares {BUNDLE_V1}")
    if not SLUG_RE.match(m["slug"]):
        probs.append(f"bad slug {m['slug']!r}")
    if not re.fullmatch(r"[0-9a-f]{64}", m["source_hash"]):
        probs.append("source_hash is not a sha256 hex digest")

    # manifest-level v2 fields
    dyn_m = m.get("dynamics")
    if dyn_m is not None:
        if not isinstance(dyn_m, dict):
            probs.append("dynamics must be an object")
        else:
            if dyn_m.get("source", "velocity") not in DYN_SOURCES:
                probs.append(f"dynamics.source must be one of {DYN_SOURCES}")
            vc = dyn_m.get("velocity_curve", 1.0)
            if not _num(vc) or not 0.1 <= vc <= 10:
                probs.append("dynamics.velocity_curve must be a number in 0.1..10 (dyn = (vel/127)^curve)")
            xf = dyn_m.get("crossfade")
            if xf is not None and (not _num(xf) or not 0 <= xf <= 1):
                probs.append("dynamics.crossfade must be a number in 0..1 (0 = hard layer switch)")
    hz = m.get("humanize")
    if hz is not None:
        if not isinstance(hz, dict):
            probs.append("humanize must be an object")
        else:
            for k, hi in (("cents", 50), ("ms", 50), ("db", 12)):
                v = hz.get(k, 0)
                if not _num(v) or not 0 <= v <= hi:
                    probs.append(f"humanize.{k} must be a number in 0..{hi}")
            extra = set(hz) - {"cents", "ms", "db"}
            if extra:
                probs.append(f"humanize: unknown keys {sorted(extra)}")
    rr = m.get("rr_reset_ms")
    if rr is not None and (not _num(rr) or rr < 0):
        probs.append("rr_reset_ms must be a number >= 0")
    om = m.get("onset_ms")
    if om is not None and (not _num(om) or not 0 <= om <= 1000):
        probs.append("onset_ms must be a number in 0..1000 (pre-roll skipped at note-on)")
    if "one_shot" in m and not isinstance(m["one_shot"], bool):
        probs.append("one_shot must be true or false")
    for k in ("credits",):
        if k in m and not isinstance(m[k], list):
            probs.append(f"{k} must be a list")
    if "license" in m and not isinstance(m["license"], str):
        probs.append("license must be a string")

    arts = m.get("articulations")
    art_ids: set = set()
    ks_keys: set = set()
    if arts is not None:
        ap = validate_articulations(arts)
        probs += [f"articulations: {p}" for p in ap]
        if not ap:
            art_ids = {a["id"] for a in arts}
            ks_keys = {a["key"] for a in arts if a.get("key") is not None}

    sr = m["sample_rate"]
    by_layer: dict[str, list[dict]] = {}
    for i, z in enumerate(m["zones"]):
        where = f"zone {i} ({z.get('file')})"
        if z.get("layer") not in ("body", "attack", "tail", "air"):
            probs.append(f"{where}: bad layer {z.get('layer')!r}")
            continue
        for k in ("file", "root", "pitched", "lo", "hi", "vel_lo", "vel_hi", "gain_db", "loop"):
            if k not in z:
                probs.append(f"{where}: missing '{k}'")
        if any(k not in z for k in ("file", "lo", "hi", "vel_lo", "vel_hi")):
            continue
        if not (0 <= z["lo"] <= z["hi"] <= 127):
            probs.append(f"{where}: key range {z['lo']}..{z['hi']} invalid")
        if not (1 <= z["vel_lo"] <= z["vel_hi"] <= 127):
            probs.append(f"{where}: velocity range {z['vel_lo']}..{z['vel_hi']} invalid")
        if "dyn" in z:
            d = z["dyn"]
            if not (isinstance(d, list) and len(d) == 2 and all(_num(x) for x in d) and 0 <= d[0] < d[1] <= 1):
                probs.append(f"{where}: dyn must be [lo, hi] with 0 <= lo < hi <= 1, got {d!r}")
                continue
        if "onset_ms" in z and (not _num(z["onset_ms"]) or not 0 <= z["onset_ms"] <= 1000):
            probs.append(f"{where}: onset_ms must be a number in 0..1000")
        if "onset_ms" in z and z["layer"] == "air":
            probs.append(f"{where}: onset_ms does not apply to air")
        if "tune_cents" in z and (not _num(z["tune_cents"]) or abs(z["tune_cents"]) > 100):
            probs.append(f"{where}: tune_cents must be a number within ±100")
        for k, ok in (("rt_decay", lambda v: v >= 0), ("rt_min_db", lambda v: -120 <= v <= 0)):
            if k in z:
                if z["layer"] != "tail":
                    probs.append(f"{where}: {k} only applies to tail zones")
                elif not _num(z[k]) or not ok(z[k]):
                    probs.append(f"{where}: bad {k} {z[k]!r} (rt_decay dB/s >= 0, rt_min_db in -120..0)")
        if not _num(z.get("gain_db", 0.0)):
            probs.append(f"{where}: gain_db must be a number")
        f = build / z["file"]
        if Path(z["file"]).name != z["file"]:
            probs.append(f"{where}: file must be a bare name inside build/")
        if not f.exists():
            probs.append(f"{where}: {z['file']} missing")
            continue
        info = sf.info(str(f))
        if info.samplerate != sr:
            probs.append(f"{where}: sample rate {info.samplerate} != manifest {sr}")
        if info.channels not in (1, 2):
            probs.append(f"{where}: {info.channels} channels")
        if v2:
            if (info.format, info.subtype) not in (("WAV", "FLOAT"), ("WAV", "PCM_24"), ("WAV", "PCM_16"),
                                                   ("FLAC", "PCM_24"), ("FLAC", "PCM_16")):
                probs.append(f"{where}: {info.format}/{info.subtype}; bundle/2 zones are WAV float/24/16 or FLAC 24/16")
        elif info.subtype != "FLOAT":
            probs.append(f"{where}: WAV subtype {info.subtype}, expected FLOAT (32-bit float)")
        lp = z.get("loop")
        if lp is not None:
            if not all(isinstance(lp.get(k), int) for k in ("start", "end", "crossfade")):
                probs.append(f"{where}: loop needs integer start/end/crossfade")
            elif not (0 <= lp["start"] < lp["end"] <= info.frames and 0 <= lp["crossfade"] <= lp["end"] - lp["start"]):
                probs.append(f"{where}: loop {lp} outside the file ({info.frames} frames)")
        if z["layer"] == "air" and (z["lo"], z["hi"]) != (0, 127):
            probs.append(f"{where}: unpitched zones must cover 0..127")
        if "one_shot" in z and not isinstance(z["one_shot"], bool):
            probs.append(f"{where}: one_shot must be true or false")
        if "articulation" in z:
            if z["layer"] == "air":
                probs.append(f"{where}: air has no articulation")
            elif z["articulation"] not in art_ids:
                probs.append(f"{where}: articulation {z['articulation']!r} is not in the manifest's articulations")
        for k in sorted(ks_keys):
            if z["layer"] != "air" and z["lo"] <= k <= z["hi"]:
                probs.append(f"{where}: keyswitch key {k} lies inside the zone's playing range {z['lo']}..{z['hi']}")
        cg = z.get("choke_group")
        if cg is not None and (isinstance(cg, bool) or not isinstance(cg, int) or cg < 1):
            probs.append(f"{where}: choke_group must be an integer >= 1")
        ck = z.get("chokes")
        if ck is not None and (not isinstance(ck, list)
                               or not all(isinstance(g, int) and not isinstance(g, bool) and g >= 1 for g in ck)):
            probs.append(f"{where}: chokes must be a list of integers >= 1")
        take = z.get("take", 0)
        if isinstance(take, bool) or not isinstance(take, int) or not 0 <= take < (MAX_TAKES if v2 else 8):
            probs.append(f"{where}: take must be an integer 0..{(MAX_TAKES if v2 else 8) - 1}, got {take!r}")
            continue
        if take and z["layer"] == "air":
            probs.append(f"{where}: air has no takes")
        by_layer.setdefault(z["layer"], []).append(z)
    if "body" not in by_layer:
        if not v2:
            probs.append("no body zones (bundle/1 requires them)")
        elif not oscillators_on(m["params"]):
            probs.append("no body zones and no oscillator turned on in params (set osc1_level, osc2_level or "
                         "sub_level above -60)")
    partitions = []
    for layer0, zs0 in by_layer.items():
        for a_ in dict.fromkeys(z.get("articulation") for z in zs0):
            partitions.append((layer0 + (f"[{a_}]" if a_ else ""), [z for z in zs0 if z.get("articulation") == a_]))
    for layer, zs in partitions:
        # Round-robin takes: zones with identical key, velocity and dyn ranges form one group whose
        # takes must be exactly 0..N-1. Coverage is then checked on take 0.
        def gkey(z):
            return (z["lo"], z["hi"], z["vel_lo"], z["vel_hi"], tuple(z.get("dyn", ())))

        groups: dict[tuple, list[int]] = {}
        for z in zs:
            groups.setdefault(gkey(z), []).append(z.get("take", 0))
        for (lo, hi, vlo, vhi, dyn), tk in groups.items():
            if sorted(tk) != list(range(len(tk))):
                rng = f"vel {vlo}..{vhi}" + (f" dyn {list(dyn)}" if dyn else "")
                probs.append(f"{layer} keys {lo}..{hi} {rng}: takes {sorted(tk)} are not 0..{len(tk) - 1}")
        zs = [z for z in zs if z.get("take", 0) == 0]
        # Dynamics layers: zones sharing key and velocity ranges with a dyn range must tile 0..1.
        cells: dict[tuple, list[tuple]] = {}
        for z in zs:
            if "dyn" in z:
                cells.setdefault((z["lo"], z["hi"], z["vel_lo"], z["vel_hi"]), []).append(tuple(z["dyn"]))
        bad_dyn = []
        for key_, iv in cells.items():
            edge, ok = 0.0, True
            for lo_, hi_ in sorted(iv):
                if abs(lo_ - edge) > 1e-6:
                    ok = False
                    break
                edge = hi_
            if not ok or abs(edge - 1.0) > 1e-6:
                bad_dyn.append(key_)
        if bad_dyn:
            k0 = bad_dyn[0]
            probs.append(f"{layer}: dyn ranges do not tile 0..1 in {len(bad_dyn)} key/velocity groups, "
                         f"e.g. keys {k0[0]}..{k0[1]} vel {k0[2]}..{k0[3]}")
        # every (key, velocity) covered exactly once (a set of dyn layers counts once)
        grid = [[0] * 128 for _ in range(128)]
        seen_cells = set()
        for z in zs:
            ck = (z["lo"], z["hi"], z["vel_lo"], z["vel_hi"])
            if "dyn" in z:
                if ck in seen_cells:
                    continue
                seen_cells.add(ck)
            for k in range(z["lo"], z["hi"] + 1):
                for v in range(z["vel_lo"], z["vel_hi"] + 1):
                    grid[k][v] += 1
        # A bundle may declare a limited musical range with
        # edge_fill=False. Validate every key inside that range, while leaving
        # notes outside its declared min/max unassigned. Keys outside a map are
        # not missing samples; edge_fill=True already expands ordinary maps.
        mapped_lo = min((z["lo"] for z in zs), default=0)
        mapped_hi = max((z["hi"] for z in zs), default=127)
        gaps = [(k, v) for k in range(mapped_lo, mapped_hi + 1) for v in range(1, 128)
                if grid[k][v] == 0 and k not in ks_keys]
        if not any(z.get("pitched") for z in zs):
            gaps = [(k, v) for k, v in gaps if any(grid[k])]   # a kit leaves keys unmapped; its mapped keys stay whole
        over = [(k, v) for k in range(128) for v in range(1, 128) if grid[k][v] > 1]
        if gaps:
            probs.append(f"{layer}: {len(gaps)} (key, velocity) cells uncovered, e.g. {gaps[0]}")
        if over:
            probs.append(f"{layer}: {len(over)} (key, velocity) cells covered twice, e.g. {over[0]}")
    air = by_layer.get("air", [])
    if len(air) > 1:
        probs.append("air must have exactly one zone")
    if air and air[0].get("pitched"):
        probs.append("air must be unpitched")
    ir = m.get("ir")
    if ir is not None and not (build / ir).exists():
        probs.append(f"ir {ir} missing")
    fig = m.get("figure")
    if fig is not None and not (build / fig).exists():
        probs.append(f"figure {fig} missing")
    for k, v in m["params"].items():
        try:
            P.validate_value(k, v)
        except P.ParamError as e:
            probs.append(f"params: {e}")
        if k not in P.BY_ID:
            probs.append(f"params: '{k}' is not a §5 id")
    return probs


# ---------------------------------------------------------------- banks (SPEC §2.4)

BANK_FORMAT = "libero.bank/1"
BANK_EXT = ".liberobank"
_PACK_FILES = ("figure.svg", "notes.md", "sound.py", "sample-edits.json", "SOUND-DATA-TERMS.md", "samples/ATTRIBUTION.md",
               "samples/credits.json", "samples/TERMS.md")


def _pack_sound_files(folder: Path) -> list[Path]:
    """Runtime files, recipe and source terms; raw recording folders stay private."""
    files = [p for p in sorted((folder / "build").rglob("*"))
             if p.is_file() and not p.name.startswith(".")]
    files.extend(folder / name for name in _PACK_FILES if (folder / name).is_file())
    files.extend(p for p in sorted((folder / "samples/licenses").rglob("*"))
                 if p.is_file() and not p.name.startswith("."))
    return files


def _bank_dirs() -> list[Path]:
    b = banks_dir()
    if not b.is_dir():
        return []
    return [p for p in sorted(b.iterdir()) if p.is_dir() and (p / "bank.json").exists()]


def _bank_meta(folder: Path) -> dict:
    try:
        m = json.loads((folder / "bank.json").read_text())
    except (OSError, json.JSONDecodeError):
        return {}
    return m if isinstance(m, dict) else {}


def _bank_folder(bank: str) -> Path:
    check_slug(bank)
    p = banks_dir() / bank
    if not (p / "bank.json").exists():
        raise LibraryError(f"no bank named '{bank}' (see bank_list)")
    return p


def _sound_dirs(folder: Path) -> list[Path]:
    return [p for p in sorted(folder.iterdir()) if p.is_dir() and SLUG_RE.match(p.name)]


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _sound_credits(folder: Path) -> list[dict]:
    from . import licenses

    out = []
    for p in _sound_dirs(folder):
        out += licenses.read_credits(p)
    return out


def bank_license(folder: Path) -> str:
    """The bank's licence: that of its most restrictive source (empty bank: original work)."""
    from . import licenses

    return licenses.bundle_license(_sound_credits(folder))[0]


def _write_bank(folder: Path, meta: dict) -> None:
    (folder / "bank.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False) + "\n")


def _complete_meta(folder: Path, meta: dict, stamp: str) -> dict:
    """bank.json with every field of libero.bank/1; missing ones get defaults (older files lack some)."""
    return {"format": BANK_FORMAT, "slug": folder.name,
            "title": meta.get("title") or folder.name.replace("-", " ").title(),
            "subtitle": meta.get("subtitle") or "", "description": meta.get("description") or "",
            "version": meta.get("version") or "1.0.0", "author": meta.get("author") or "",
            "license": bank_license(folder), "created": meta.get("created") or stamp,
            "updated": meta.get("updated") or stamp, "figure": meta.get("figure") or None}


def bank_refresh(bank: str, touch: bool = True) -> dict:
    """Recompute the derived fields (licence, updated) of an installed bank and write bank.json."""
    folder = _bank_folder(bank)
    meta = _complete_meta(folder, _bank_meta(folder), _now())
    if touch:
        meta["updated"] = _now()
    _write_bank(folder, meta)
    return meta


def bank_migrate() -> list[str]:
    """Bring every installed bank.json to the libero.bank/1 schema (idempotent). Returns the slugs changed."""
    changed = []
    for d in _bank_dirs():
        old = _bank_meta(d)
        st = (d / "bank.json").stat()
        stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(getattr(st, "st_birthtime", st.st_mtime)))
        meta = _complete_meta(d, old, stamp)
        if meta != old:
            _write_bank(d, meta)
            changed.append(d.name)
    return changed


def check_bank_meta(meta: dict, slug: str) -> None:
    if meta.get("format") != BANK_FORMAT or meta.get("slug") != slug:
        raise LibraryError(f"bank.json is not {BANK_FORMAT} for '{slug}'")
    if not isinstance(meta.get("title"), str) or not meta["title"].strip():
        raise LibraryError("bank.json has no title")
    if not re.fullmatch(r"\d+\.\d+\.\d+", str(meta.get("version", ""))):
        raise LibraryError(f"bank.json version {meta.get('version')!r} is not semver (x.y.z)")


def bank_create(slug: str, title: str, subtitle: str = "", description: str = "", author: str = "",
                license: str = "", version: str = "1.0.0") -> Path:
    """Create banks/<slug>/bank.json. Refuses to overwrite. `license` is derived from the sounds and
    recomputed as they come in; the argument is only the initial value."""
    check_slug(slug)
    if slug in ("mie", "prove"):
        raise LibraryError(f"'{slug}' is a built-in bank name")
    folder = banks_dir() / slug
    if folder.exists():
        raise LibraryError(f"bank '{slug}' already exists")
    folder.mkdir(parents=True)
    now = _now()
    meta = {"format": BANK_FORMAT, "slug": slug, "title": title or slug.replace("-", " ").title(),
            "subtitle": subtitle, "description": description, "version": version, "author": author,
            "license": license or "original work", "created": now, "updated": now, "figure": None}
    _write_bank(folder, meta)
    return folder


def bank_edit(bank: str, title: str | None = None, subtitle: str | None = None,
              description: str | None = None, author: str | None = None, version: str | None = None) -> dict:
    """Change a bank's title, subtitle, description, author or version (the slug never changes)."""
    folder = _bank_folder(bank)
    meta = _complete_meta(folder, _bank_meta(folder), _now())
    for k, v in (("title", title), ("subtitle", subtitle), ("description", description), ("author", author),
                 ("version", version)):
        if v is not None:
            meta[k] = v if k == "description" else v.strip()
    check_bank_meta(meta, bank)
    meta["updated"] = _now()
    _write_bank(folder, meta)
    return meta


def bank_list() -> list[dict]:
    """Installed banks, then the built-in Mie (sounds/) and Prove (sketches/)."""
    def count(d: Path) -> int:
        return sum(1 for p in _sound_dirs(d) if (p / "build" / "manifest.json").exists())

    out = []
    for d in _bank_dirs():
        m = _bank_meta(d)
        out.append({"slug": d.name, "title": m.get("title") or d.name, "subtitle": m.get("subtitle", ""),
                    "description": m.get("description", ""), "version": m.get("version", ""),
                    "author": m.get("author", ""), "license": m.get("license", ""),
                    "created": m.get("created", ""), "updated": m.get("updated", ""), "count": count(d), "path": str(d), "builtin": False})
    out.append({"slug": "mie", "title": "Mie", "subtitle": "", "count": count(sounds_dir()),
                "path": str(sounds_dir()), "builtin": True})
    out.append({"slug": "prove", "title": "Prove", "subtitle": "", "count": count(sketches_dir()),
                "path": str(sketches_dir()), "builtin": True})
    return out


def bank_add(sound_slug: str, bank: str) -> Path:
    """Move a saved sound into a bank (`mie` moves it back to sounds/). Never overwrites."""
    src = find_sound(sound_slug)
    if not is_saved(src):
        raise LibraryError(f"'{sound_slug}' is a sketch: save it first")
    dst_dir = sounds_dir() if bank == "mie" else _bank_folder(bank)
    if src.resolve().parent == dst_dir.resolve():
        return src
    dst = dst_dir / src.name
    if dst.exists():
        raise LibraryError(f"{dst} already exists")
    os.rename(src, dst)
    _repoint_favorite(src, dst, sound_slug)
    for d in (src.parent, dst_dir):
        if d.parent == banks_dir() and (d / "bank.json").exists():
            bank_refresh(d.name)
    return dst


def _repoint_favorite(old: Path, new: Path, slug: str) -> None:
    p = home() / "config.json"
    cfg = config()
    favs = cfg.get("favorites")
    if not isinstance(favs, list):
        return
    changed = False
    for f in favs:
        if isinstance(f, dict) and f.get("path") == str(old):
            f["path"] = str(new)
            changed = True
    if changed:
        p.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")


def _sound_license_class(folder: Path) -> str:
    from . import licenses

    return licenses.bundle_license(licenses.read_credits(folder))[1]


def bank_pack(bank: str, out_path: str | os.PathLike | None = None) -> Path:
    """Zip a bank into <bank>.liberobank: bank.json and, per sound, build/, figure.svg, notes.md, sound.py and
    the credits (samples/ATTRIBUTION.md, credits.json). Source audio and caches stay out. Refuses a bank that
    holds a sound whose licence forbids sharing (non-commercial, private, unknown terms)."""
    import zipfile

    from . import licenses

    folder = _bank_folder(bank)
    sounds = _sound_dirs(folder)
    blocked = [f"{p.name} ({licenses.LABELS.get(c, c)})" for p in sounds
               if (c := _sound_license_class(p)) not in licenses.SHIPPABLE]
    if blocked:
        raise LibraryError("cannot pack: these sounds must not be shared: " + ", ".join(blocked))
    out = Path(out_path).expanduser() if out_path else Path.cwd() / f"{bank}{BANK_EXT}"
    if out.is_dir():
        out = out / f"{bank}{BANK_EXT}"
    out.parent.mkdir(parents=True, exist_ok=True)
    meta = _complete_meta(folder, _bank_meta(folder), _now())
    files = []
    if meta.get("figure"):
        files.append(folder / str(meta["figure"]))
    for snd in sounds:
        files.extend(_pack_sound_files(snd))
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{bank}/bank.json", json.dumps(meta, indent=2, ensure_ascii=False) + "\n")
        for f in files:
            if f.is_file():
                z.write(f, f"{bank}/{f.relative_to(folder).as_posix()}")
    return out


def _version_key(v: str) -> tuple[int, ...]:
    if not re.fullmatch(r"\d+\.\d+\.\d+", str(v or "")):
        raise LibraryError(f"invalid bank version {v!r}; expected x.y.z")
    return tuple(int(x) for x in v.split("."))


def _pack_plan(pack_path: str | os.PathLike) -> dict:
    """Preflight an archive without changing the installed library."""
    import zipfile

    pack = Path(pack_path).expanduser()
    if not pack.is_file():
        raise LibraryError(f"no such file: {pack}")
    try:
        z = zipfile.ZipFile(pack)
    except (OSError, zipfile.BadZipFile) as e:
        raise LibraryError(f"{pack.name} is not a bank pack") from e
    with z:
        infos = z.infolist()
        if not infos:
            raise LibraryError("empty bank pack")
        seen: set[str] = set()
        roots: set[str] = set()
        total = 0
        for info in infos:
            name = info.filename
            if (not name or "\\" in name or "\x00" in name or name.startswith("/")
                    or re.match(r"^[A-Za-z]:", name)):
                raise LibraryError(f"unsafe path in pack: {name!r}")
            clean = name[:-1] if name.endswith("/") else name
            parts = clean.split("/")
            if not clean or any(p in ("", ".", "..") for p in parts):
                raise LibraryError(f"unsafe path in pack: {name!r}")
            normalized = "/".join(parts).casefold()
            if normalized in seen:
                raise LibraryError(f"duplicate path in pack: {normalized}")
            seen.add(normalized)
            if info.is_dir() and info.file_size != 0:
                raise LibraryError(f"invalid directory entry in pack: {name}")
            mode = info.external_attr >> 16
            file_type = stat.S_IFMT(mode)
            if stat.S_ISLNK(mode):
                raise LibraryError(f"symbolic links are not allowed in pack: {name}")
            if file_type and file_type not in (stat.S_IFREG, stat.S_IFDIR):
                raise LibraryError(f"unsupported file type in pack: {name}")
            total += info.file_size
            if total > (1 << 63) - 1:
                raise LibraryError("uncompressed pack size overflows supported range")
            roots.add(parts[0])
        # Reject a file used as a parent directory (e.g. a plus a/b).
        dir_names = {i.filename.rstrip("/").casefold() for i in infos if i.is_dir()}
        files = seen - dir_names
        for n in files:
            if any(child.startswith(n + "/") for child in seen):
                raise LibraryError(f"file/directory path collision in pack: {n}")
        if len(roots) != 1:
            raise LibraryError("a bank pack holds exactly one bank folder")
        slug = check_slug(roots.pop())
        try:
            meta = json.loads(z.read(f"{slug}/bank.json"))
        except (KeyError, json.JSONDecodeError) as e:
            raise LibraryError("the pack has no valid bank.json") from e
        check_bank_meta(meta, slug)
        archive_names = {i.filename for i in infos}
        sound_slugs = {n.split("/")[1] for n in archive_names if n.startswith(slug + "/") and len(n.split("/")) >= 3
                       and SLUG_RE.fullmatch(n.split("/")[1])
                       and f"{slug}/{n.split('/')[1]}/build/manifest.json" in archive_names}
        return {"pack": pack, "slug": slug, "meta": meta, "entries": infos,
                "compressed_bytes": pack.stat().st_size, "uncompressed_bytes": total,
                "sound_count": len(sound_slugs), "sound_slugs": sorted(sound_slugs)}


def _bank_warnings(plan: dict) -> list[str]:
    import zipfile
    slug, meta = plan["slug"], plan["meta"]
    warnings = []
    dst = banks_dir() / slug
    if dst.exists():
        try:
            old = _bank_meta(dst)
            check_bank_meta(old, slug)
        except LibraryError as e:
            raise LibraryError(f"installed bank '{slug}' has invalid metadata: {e}") from e
        plan["installed_version"] = old["version"]
        if _version_key(meta["version"]) <= _version_key(old["version"]):
            plan["action"] = "already_installed"
        else:
            plan["action"] = "update"
            warnings.append("Updating replaces the installed bank as a whole, including sounds or edits you added to it.")
    else:
        plan["installed_version"] = ""
        plan["action"] = "install"
    if plan["sound_count"] == 0:
        warnings.append("This bank contains no sounds.")
    sound_slugs = plan["sound_slugs"]
    locations = [(other, other.name) for other in _bank_dirs() if other.name != slug]
    locations.append((sounds_dir(), "Mie"))
    with zipfile.ZipFile(plan["pack"]) as z:
        for base, label in locations:
            if not base.is_dir():
                continue
            for snd in _sound_dirs(base):
                if not (snd / "build" / "manifest.json").is_file():
                    continue
                if snd.name in sound_slugs:
                    incoming = f"{slug}/{snd.name}/build/manifest.json"
                    same = False
                    try:
                        im = json.loads(z.read(incoming))
                        om = json.loads((snd / "build/manifest.json").read_text())
                        same = bool(im.get("source_hash")) and im.get("source_hash") == om.get("source_hash")
                    except (OSError, ValueError, KeyError):
                        pass
                    warnings.append(f"Sound slug '{snd.name}' also exists in bank '{label}'" +
                                    (" with matching source hash." if same else " with different or unknown source hash."))
    return warnings


def bank_inspect(pack_path: str | os.PathLike) -> dict:
    """Inspect a bank pack and report the action without installing it."""
    import tempfile
    plan = _pack_plan(pack_path)
    with tempfile.TemporaryDirectory(dir=_mk(banks_dir()), prefix=".inspect-") as tmp:
        _extract_and_validate(plan, Path(tmp))
    warnings = _bank_warnings(plan)
    return {"ok": True, "code": "OK" if plan["action"] != "already_installed" else
            ("SAME_VERSION" if plan["meta"]["version"] == plan["installed_version"] else "DOWNGRADE"),
            "path": str(plan["pack"]), "bank": {k: plan["meta"].get(k) for k in ("slug", "title", "version")},
            "installedVersion": plan["installed_version"], "action": plan["action"],
            "soundCount": plan["sound_count"], "compressedBytes": plan["compressed_bytes"],
            "uncompressedBytes": plan["uncompressed_bytes"], "warnings": warnings}


def bank_install(pack_path: str | os.PathLike) -> Path:
    """Validate and transactionally install a .liberobank into banks/."""
    import tempfile
    plan = _pack_plan(pack_path)
    _bank_warnings(plan)
    if plan["action"] == "already_installed":
        reason = "already installed" if plan["meta"]["version"] == plan["installed_version"] else "newer version installed"
        raise LibraryError(f"bank '{plan['slug']}' {plan['installed_version']} is {reason} (pack is {plan['meta']['version']})")
    banks = _mk(banks_dir())
    slug, dst = plan["slug"], banks / plan["slug"]
    tmp = Path(tempfile.mkdtemp(dir=banks, prefix=".install-"))
    backup = None
    try:
        staged = _extract_and_validate(plan, tmp)
        if dst.exists():
            backup = banks / f".backup-{slug}-{time.time_ns()}"
            os.replace(dst, backup)
        try:
            os.replace(staged, dst)
        except OSError:
            if backup is not None:
                os.replace(backup, dst)
                backup = None
            raise
        if backup is not None:
            try:
                trash = _mk(trash_dir())
                target = trash / f"libero-bank-{slug}-{time.strftime('%Y%m%d-%H%M%S')}"
                if target.exists():
                    target = target.with_name(target.name + f"-{time.time_ns()}")
                os.replace(backup, target)
                backup = None
            except OSError:
                # Successful install; leave the recoverable backup in banks/.
                pass
        return dst
    except Exception as install_error:
        if backup is not None and not dst.exists():
            try:
                os.replace(backup, dst)
                backup = None
            except OSError as restore_error:
                raise LibraryError(f"install failed and the previous bank remains recoverable at {backup}; "
                                   f"automatic restore also failed: {restore_error}") from install_error
        raise
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _extract_and_validate(plan: dict, tmp: Path) -> Path:
    """Extract already-preflighted entries and validate every runtime sound bundle."""
    import zipfile
    with zipfile.ZipFile(plan["pack"]) as z:
        for info in plan["entries"]:
            target = tmp.joinpath(*info.filename.rstrip("/").split("/"))
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, target.open("wb") as out:
                    shutil.copyfileobj(src, out)
    slug = plan["slug"]
    staged = tmp / slug
    if not (staged / "bank.json").is_file():
        raise LibraryError("staged bank has no bank.json")
    try:
        staged_meta = json.loads((staged / "bank.json").read_text())
    except (OSError, json.JSONDecodeError) as e:
        raise LibraryError("staged bank.json is invalid") from e
    check_bank_meta(staged_meta, slug)
    if staged_meta != plan["meta"]:
        raise LibraryError("bank.json changed between archive preflight and extraction")
    sounds = _sound_dirs(staged)
    if len(sounds) != plan["sound_count"]:
        raise LibraryError("bank must contain valid sound bundles")
    for sound in sounds:
        issues = validate_bundle(sound / "build")
        if issues:
            raise LibraryError(f"invalid bundle '{sound.name}': " + "; ".join(issues[:8]))
        build = sound / "build"
        manifest = json.loads((build / "manifest.json").read_text())
        if manifest.get("slug") != sound.name:
            raise LibraryError(f"bundle slug does not match folder '{sound.name}'")
        for key in ("ir", "figure"):
            rel = manifest.get(key)
            if rel is not None:
                p = (build / rel).resolve()
                if build.resolve() not in p.parents or not p.is_file():
                    raise LibraryError(f"bundle '{sound.name}' has unsafe or missing {key} path")
        _validate_sample_edits(sound, manifest)
    return staged


def _validate_sample_edits(sound: Path, manifest: dict) -> None:
    """Validate optional editor overrides against the exact compiled zones they target."""
    sidecar_path = sound / "sample-edits.json"
    if not sidecar_path.exists():
        return
    if not sidecar_path.is_file() or sidecar_path.stat().st_size > 1_048_576:
        raise LibraryError(f"sound '{sound.name}' has an invalid or oversized sample-edits.json")
    try:
        data = json.loads(sidecar_path.read_text())
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise LibraryError(f"sound '{sound.name}' has invalid sample-edits.json") from exc
    edits = data.get("edits") if isinstance(data, dict) and data.get("format") == "libero.sample-edits/1" else None
    if not isinstance(edits, dict) or len(edits) > 4096:
        raise LibraryError(f"sound '{sound.name}' has invalid sample edit records")
    zones = manifest.get("zones")
    if not isinstance(zones, list):
        raise LibraryError(f"sound '{sound.name}' has no zone list")
    by_file: dict[str, list[dict]] = {}
    for zone in zones:
        if isinstance(zone, dict) and isinstance(zone.get("file"), str):
            by_file.setdefault(zone["file"], []).append(zone)
    source_hash = manifest.get("source_hash", "")
    for filename, edit in edits.items():
        if (not isinstance(filename, str) or Path(filename).name != filename or filename in (".", "..")
                or "/" in filename or "\\" in filename or "\x00" in filename
                or not isinstance(edit, dict) or edit.get("enabled") is not True):
            raise LibraryError(f"sound '{sound.name}' has an invalid sample edit key or record")
        matches = [z for z in by_file.get(filename, []) if z.get("layer") == "body" and z.get("pitched", True)]
        if not matches:
            raise LibraryError(f"sample edit in '{sound.name}' references an unknown/non-pitched zone")
        # Existing format keys by compiled filename; require its stored zone signature to
        # match one exact mapping so a reused filename cannot silently edit another zone.
        def same_signature(z: dict) -> bool:
            return (edit.get("source_hash") == source_hash and
                    all(edit.get(k) == z.get(k, 0 if k == "take" else None)
                        for k in ("root", "lo", "hi", "vel_lo", "vel_hi", "take")) and
                    (edit.get("articulation") or "") == (z.get("articulation") or "") and
                    edit.get("dyn") == z.get("dyn"))
        zone = next((z for z in matches if same_signature(z)), None)
        if zone is None:
            raise LibraryError(f"sample edit in '{sound.name}' is stale or does not match its zone")
        try:
            values = [float(edit[k]) for k in ("start_s", "end_s", "loop_start_s", "loop_end_s", "crossfade_ms")]
        except (KeyError, TypeError, ValueError, OverflowError) as exc:
            raise LibraryError(f"sample edit in '{sound.name}' has missing bounds") from exc
        start, end, loop_start, loop_end, crossfade = values
        if not all(math.isfinite(x) for x in values) or start < 0 or end - start < .05 or crossfade < 0 or crossfade > 500:
            raise LibraryError(f"sample edit in '{sound.name}' has non-finite or invalid bounds")
        audio_path = sound / "build" / filename
        try:
            info = sf.info(str(audio_path))
        except (RuntimeError, OSError) as exc:
            raise LibraryError(f"sample edit in '{sound.name}' references unreadable audio") from exc
        duration = info.frames / info.samplerate
        if end > duration + 1e-8:
            raise LibraryError(f"sample edit in '{sound.name}' exceeds its sample duration")
        if edit.get("loop_enabled") is True and (loop_start < start or loop_end - loop_start < .05 or loop_end > end):
            raise LibraryError(f"sample edit in '{sound.name}' has loop bounds outside its crop")


INFO_KEYS = ("format", "slug", "title", "subtitle", "tags", "description", "figure", "accent", "license",
             "articulations")


def light_info(manifest: dict) -> dict:
    """The few manifest fields a library listing needs (written as build/info.json)."""
    return {k: manifest[k] for k in INFO_KEYS if k in manifest}


def write_light_info(build_dir) -> bool:
    """(Re)write build/info.json from an existing manifest; True if written."""
    from pathlib import Path
    build_dir = Path(build_dir)
    m = build_dir / "manifest.json"
    if not m.exists():
        return False
    (build_dir / "info.json").write_text(json.dumps(light_info(json.loads(m.read_text())), ensure_ascii=False))
    return True
