"""Library previews: a few seconds of every sound, rendered at compile time (SPEC §4 `preview.m4a`).

`make_preview(folder)` plays a short phrase through `libero-render` with the sound's own
defaults, evens the loudness out to about -16 LUFS and writes `build/preview.m4a` (AAC, ~50 KB;
`build/preview.wav`, mono 22 kHz, where AAC encoding is unavailable). The plugin's library shows a
play button on every tile and streams this file; nothing is loaded into the engine.

What is played depends only on the manifest:
  - pitched sounds: an arpeggio and a chord in the main register of the sound's zones
    (a bass gets a short riff of roots and fifths);
  - drum kits (tags `drums`, or choke groups): a 2-bar groove from the playable octave;
  - one-shot banks (unpitched, not a kit): the main hits one after another;
  - oscillator-only sounds: the pitched phrase in a register taken from the tags.
"""

from __future__ import annotations

import json
import shutil
import statistics
import subprocess
import tempfile
from pathlib import Path

from . import render as R

TARGET_LUFS = -16.0
MAX_SECONDS = 6.0
RATE = 44100
SUSTAINED_TAGS = {"pad", "choir", "strings", "string-section", "bowed", "wind", "brass", "flute", "reed",
                  "organ", "lead", "drone", "vocal", "ensemble"}


def _first_articulation(manifest: dict) -> str | None:
    arts = manifest.get("articulations") or []
    return arts[0].get("id") if arts else None


def _body_zones(manifest: dict) -> list[dict]:
    art = _first_articulation(manifest)
    zs = [z for z in manifest.get("zones", []) if z.get("layer") in ("body", "attack")]
    if art is not None:
        zs = [z for z in zs if z.get("articulation") in (None, art)]
    return zs


def _fmt(notes: list[tuple[int, float, float, int]]) -> str:
    return ",".join(f"{p}:{s:.3f}:{d:.3f}:{v}" for p, s, d, v in sorted(notes, key=lambda n: n[1]))


def _window(keys: list[int]) -> list[int]:
    """The 12-key window holding most mapped keys (lowest on ties): the playable octave."""
    ks = sorted(set(keys))
    best: list[int] = []
    for k in ks:
        w = [x for x in ks if k <= x < k + 12]
        if len(w) > len(best):
            best = w
    return best


def _pitched_phrase(c: int, top: int, sustained: bool) -> tuple[list, float]:
    """(notes, seconds of notes). c = main-register root, top = highest playable key."""
    if c + 12 > top:
        c -= 12
    notes: list[tuple[int, float, float, int]] = []
    if c < 48:  # bass: a short riff
        step, dur = 0.5, (0.9 if sustained else 0.55)
        for i, off in enumerate((0, 0, 7, 12, 10, 0)):
            notes.append((c + off, i * step, dur, 100 if i % 2 == 0 else 88))
        return notes, 6 * step + 0.2
    if sustained:
        step, dur = 0.5, 1.1
        for i, off in enumerate((0, 4, 7, 12)):
            notes.append((c + off, i * step, dur, 96))
        for off in (0, 7, 12, 16):
            notes.append((c + off, 2.2, 2.0, 100))
        return notes, 4.2
    step, dur = 0.4, 0.6
    for i, off in enumerate((0, 4, 7, 12)):
        notes.append((c + off, i * step, dur, 96))
    for off in (0, 7, 12, 16):
        notes.append((c + off, 1.8, 1.5, 100))
    return notes, 3.3


def _groove(L: list[int]) -> tuple[list, float]:
    n = len(L)
    kick, snare, hat = L[0], L[min(2, n - 1)], L[min(5, n - 1)]
    beat = 60.0 / 110.0
    sixteenth = beat / 4
    kicks = {0: (0, 6, 10), 1: (0, 7, 10, 14)}
    snares = (4, 12)
    notes = []
    for bar in (0, 1):
        t0 = bar * 16 * sixteenth
        for s in range(0, 16, 2):
            notes.append((hat, t0 + s * sixteenth, 0.1, 78 if s % 4 == 0 else 58))
        for s in kicks[bar]:
            notes.append((kick, t0 + s * sixteenth, 0.2, 110))
        for s in snares:
            notes.append((snare, t0 + s * sixteenth, 0.2, 105))
    return notes, 32 * sixteenth


def _hits(L: list[int]) -> tuple[list, float]:
    pick = L if len(L) <= 8 else [L[round(i * (len(L) - 1) / 7)] for i in range(8)]
    notes = [(k, i * 0.55, 0.5, 100 if i % 2 == 0 else 90) for i, k in enumerate(pick)]
    return notes, len(pick) * 0.55


def plan(manifest: dict) -> tuple[str, str]:
    """(notes in the CLI form, kind) for a compiled manifest."""
    tags = {t.lower() for t in manifest.get("tags", [])}
    zones = _body_zones(manifest)
    pitched = [z for z in zones if z.get("pitched")]
    if not zones:  # oscillator-only
        if tags & {"bass", "sub"}:
            c = 36
        elif tags & {"lead", "pluck"}:
            c = 60
        elif "pad" in tags:
            c = 52
        else:
            c = 57
        notes, _ = _pitched_phrase(c, 84, bool(tags & {"pad", "lead"}))
        return _fmt(notes), "oscillator"
    if len(pitched) * 2 >= len(zones):
        roots = sorted({z["root"] for z in pitched})
        c = min(roots, key=lambda r: abs(r - statistics.median(roots)))
        top = max(z.get("hi", z["root"]) for z in pitched)
        top = min(top, 108)
        sustained = bool(tags & SUSTAINED_TAGS) or any(z.get("loop") for z in pitched)
        notes, _ = _pitched_phrase(c, top, sustained)
        return _fmt(notes), "pitched"
    keys = [z["root"] for z in zones if not z.get("pitched")]
    L = _window(keys)
    kit = "drums" in tags or any(z.get("choke_group") for z in zones)
    notes, _ = _groove(L) if kit else _hits(L)
    return _fmt(notes), "kit" if kit else "hits"


def _encode(audio, out_dir: Path) -> Path:
    """AAC in an .m4a through afconvert (macOS); otherwise a small mono WAV."""
    out_dir.mkdir(parents=True, exist_ok=True)
    afconvert = shutil.which("afconvert")
    with tempfile.TemporaryDirectory(prefix="libero-preview-") as tmp:
        wav = Path(tmp) / "p.wav"
        audio.save(wav, subtype="PCM_16")
        if afconvert:
            m4a = Path(tmp) / "p.m4a"
            cp = subprocess.run([afconvert, "-f", "m4af", "-d", "aac", "-b", "96000", str(wav), str(m4a)],
                                capture_output=True, text=True)
            if cp.returncode == 0 and m4a.exists() and m4a.stat().st_size > 1000:
                final = out_dir / "preview.m4a"
                (out_dir / "preview.wav").unlink(missing_ok=True)
                shutil.move(str(m4a), str(final))
                return final
        small = Path(tmp) / "small.wav"
        audio.to_mono().resample(22050).save(small, subtype="PCM_16")
        final = out_dir / "preview.wav"
        (out_dir / "preview.m4a").unlink(missing_ok=True)
        shutil.move(str(small), str(final))
        return final


def make_preview(folder: Path | str) -> Path | None:
    """Render and write <folder>/build/preview.m4a (or .wav). None when there is nothing to play."""
    from .audio import Audio

    folder = Path(folder)
    build = folder / "build" if (folder / "build" / "manifest.json").exists() else folder
    mp = build / "manifest.json"
    if not mp.exists():
        return None
    manifest = json.loads(mp.read_text())
    notes, _kind = plan(manifest)
    if R.find_renderer() is None:
        raise R.RenderError(R.MISSING)
    with tempfile.TemporaryDirectory(prefix="libero-preview-") as tmp:
        wav = Path(tmp) / "r.wav"
        R.render(build, wav, notes, None, tail=1.5, sr=RATE, timeout=240.0)
        a = Audio.load(wav)
    a = a.to_stereo() if not a.is_stereo else a
    if a.duration > MAX_SECONDS:
        a = a.trim(0.0, MAX_SECONDS)
    a = a.fade_out(0.35 if a.duration >= MAX_SECONDS - 1e-6 else 0.1)
    a = a.normalize_loudness(TARGET_LUFS, momentary=False, ceiling_db=-1.0)
    return _encode(a, build)


def preview_all(roots: list[Path] | None = None, skip: tuple[str, ...] = (), force: bool = False,
                jobs: int = 3, log=print) -> dict:
    """Previews for every compiled sound under `roots` (default: banks/*/*, sounds/*, sketches/*)."""
    from . import library

    home = library.home()
    if roots is None:
        roots = [*sorted((home / "banks").glob("*/*")), *sorted((home / "sounds").glob("*")),
                 *sorted((home / "sketches").glob("*"))]
    todo, skipped = [], []
    for f in roots:
        if not (f / "build" / "manifest.json").exists():
            continue
        if any(s in f.parts for s in skip):
            skipped.append(str(f))
        elif not force and ((f / "build" / "preview.m4a").exists() or (f / "build" / "preview.wav").exists()):
            skipped.append(str(f))
        else:
            todo.append(f)
    done, failed = [], []

    def one(f: Path):
        try:
            p = make_preview(f)
            log(f"{f.relative_to(home)}: {p.name if p else '-'} {p.stat().st_size // 1024 if p else 0} KB")
            return f, None
        except Exception as e:  # keep going: one broken sound must not stop the library
            log(f"{f.relative_to(home)}: FAILED {str(e)[:200]}")
            return f, str(e)[:200]

    from concurrent.futures import ThreadPoolExecutor

    with ThreadPoolExecutor(max_workers=max(1, jobs)) as ex:
        for f, err in ex.map(one, todo):
            (failed.append((str(f), err)) if err else done.append(str(f)))
    return {"done": len(done), "skipped": len(skipped), "failed": failed}
