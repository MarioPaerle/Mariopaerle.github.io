"""`libero lint`: objective checks the agent runs instead of listening.

Reads a compiled bundle and reports, in a few lines, what a careful editor would catch:
coverage and format problems, tuning spread between layers of a key and off the keyboard's
curve, level and brightness ladders, onset alignment, clicks at starts/ends/loop seams, DC,
aliasing, silent zones, round robins that are too similar, missing releases, loudness outliers,
noise-floor jumps and truncated tails. Each finding is FAIL (fix it), WARN (look at it) or INFO.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import soundfile as sf

from . import dsp, families, library
from .multisample import align_shift, true_onset

HEAD_S = 1.5


@dataclass
class Finding:
    level: str  # FAIL | WARN | INFO
    check: str
    text: str

    def line(self) -> str:
        return f"{self.level:<4} {self.check:<11} {self.text}"


@dataclass
class ZoneData:
    z: dict
    head: np.ndarray        # mono, first HEAD_S seconds
    tail: np.ndarray        # mono, last 0.1 s
    frames: int
    sr: int
    peak_db: float
    lufs_max: float
    onset: int
    hf_db: float
    f0_cents: float | None
    dc_db: float
    above18k_db: float
    loop_seam_db: float | None
    loop_step: float | None
    edge_start: float
    edge_end: float
    floor_db: float


def _load(build: Path, z: dict, family_pitched: bool) -> ZoneData:
    f = build / z["file"]
    info = sf.info(str(f))
    sr = info.samplerate
    n_head = min(info.frames, int(HEAD_S * sr))
    head2, _ = sf.read(str(f), frames=n_head, dtype="float64", always_2d=True)
    tail2, _ = sf.read(str(f), start=max(0, info.frames - int(0.1 * sr)), dtype="float64", always_2d=True)
    head = head2.mean(axis=1)
    tail = tail2.mean(axis=1)
    pk = float(np.abs(head2).max(initial=0.0))
    # peak over the whole file only when short; long files peak in the head for struck/plucked sounds
    peak_db = dsp.db(max(pk, float(np.abs(tail2).max(initial=0.0))))
    lufs = dsp.momentary_max(head2, sr) if n_head > int(0.05 * sr) else -120.0
    onset = true_onset(head, sr)
    seg = head[: int(0.3 * sr)]
    if len(seg) > 256:
        S = np.abs(np.fft.rfft(seg * np.hanning(len(seg)))) ** 2
        fr = np.fft.rfftfreq(len(seg), 1 / sr)
        hf = 10 * math.log10((S[fr > 4000].sum() + 1e-20) / (S.sum() + 1e-20))
        a18 = 10 * math.log10((S[fr > 18000].sum() + 1e-20) / (S.sum() + 1e-20))
    else:
        hf, a18 = -120.0, -120.0
    cents = None
    if z.get("pitched") and z["layer"] == "body" and family_pitched and n_head > int(0.4 * sr):
        body = head[int(0.15 * sr):]
        f0, voiced = dsp.estimate_f0(body, sr, 25.0, 5000.0)
        if np.isfinite(f0) and voiced > 0.3:
            f0 = dsp.refine_f0(body, sr, f0)
            c = 1200 * math.log2(f0 / dsp.midi_to_freq(z["root"])) + z.get("tune_cents", 0.0)
            if abs(c) < 60:
                cents = c
    dc = dsp.db(abs(float(head.mean()))) if len(head) else -200.0
    seam = step = None
    lp = z.get("loop")
    if lp and lp["start"] < int(0.02 * sr):
        # whole-file loop (air): only the wrap step matters
        a0, _ = sf.read(str(f), frames=2, dtype="float64", always_2d=True)
        b0, _ = sf.read(str(f), start=lp["end"] - 64, frames=64, dtype="float64", always_2d=True)
        local = float(np.percentile(np.abs(np.diff(b0.mean(axis=1))), 99)) + 1e-9
        step = abs(float(a0.mean(axis=1)[0]) - float(b0.mean(axis=1)[-1])) / local
        seam = -120.0
    elif lp:
        s, e = lp["start"], lp["end"]
        w = int(0.02 * sr)
        a_, _ = sf.read(str(f), start=max(0, s - w), frames=w + 1, dtype="float64", always_2d=True)
        b_, _ = sf.read(str(f), start=max(0, e - w), frames=w, dtype="float64", always_2d=True)
        a_, b_ = a_.mean(axis=1), b_.mean(axis=1)
        n = min(len(a_) - 1, len(b_))
        if n > 8:
            err = np.sum((a_[:n] - b_[:n]) ** 2) / (np.sum(a_[:n] ** 2) + np.sum(b_[:n] ** 2) + 1e-20)
            seam = 10 * math.log10(err + 1e-12)
            local = float(np.percentile(np.abs(np.diff(b_)), 99)) + 1e-9
            step = abs(float(a_[n]) - float(b_[-1])) / local
    edge_start = abs(float(head[0])) / (pk + 1e-12) if len(head) else 0.0
    edge_end = abs(float(tail[-1])) / (pk + 1e-12) if len(tail) and not lp else 0.0
    _, env = dsp.rms_envelope(head, sr, 0.05) if len(head) > sr // 10 else (None, np.array([1e-9]))
    floor = dsp.db(float(np.percentile(env, 5)))
    return ZoneData(z, head, tail, info.frames, sr, peak_db, lufs, onset, hf, cents, dc, a18, seam, step,
                    edge_start, edge_end, floor)


def _family(manifest: dict) -> str | None:
    for t in manifest.get("tags", []):
        try:
            return families.name(t) if t in families.FAMILIES or t in families.ALIASES else None
        except ValueError:
            continue
    return None


XF_CORR_MIN = 0.95


def _onset_offsets(ds: list[ZoneData], crossfade: float) -> tuple[float, float]:
    """Performed timing spread and phase-alignment shift, in milliseconds.

    Independent takes are selected, not summed. Their carrier phase cannot
    establish a playback delay. Correlation matters only across dynamics
    that can actually be crossfaded; envelope timing remains visible separately.
    """
    if len(ds) < 2:
        return 0.0, 0.0
    timing = [d.onset / d.sr * 1000 for d in ds]
    spread = max(timing) - min(timing)
    if crossfade <= 0:
        return spread, 0.0
    axis = lambda d: tuple(d.z.get("dyn") or (d.z["vel_lo"], d.z["vel_hi"]))
    ref = max(ds, key=lambda d: (axis(d), -d.z.get("take", 0)))
    worst = 0.0
    for d in ds:
        if axis(ref) == axis(d):
            continue
        sh, c = align_shift(ref.head, d.head, d.sr, 5.0, ref.onset)
        if c >= 0.5:
            worst = max(worst, abs(sh) / d.sr * 1000)
    return spread, worst


def _xf_pair_weights(xf: float) -> tuple[float, float]:
    """Weights of (lower, upper) layer in the middle of the gap between their centres."""
    if xf <= 0:
        return 0.0, 1.0
    return math.cos(math.pi / 4), math.sin(math.pi / 4)


def dyn_crossfade_correlation(build: Path, zones: list[dict], xf: float, n_keys: int = 3,
                              win_s: float = 0.6) -> list[tuple[int, float]]:
    """Render-vs-raw correlation at a mid velocity: for up to `n_keys` keys, the engine's mix of the
    two dynamics layers at the middle of their gap (weights per `xf`, 1.0 = the legacy full-gap
    blend) against the raw layer that dominates it. Returns [(root, corr)]. Hard switching gives 1."""
    cells: dict[tuple, dict[tuple, dict]] = {}
    for z in zones:
        if z.get("layer") != "body" or "dyn" not in z or z.get("take", 0) != 0:
            continue
        cells.setdefault((z.get("articulation"), z["root"], z["lo"], z["hi"], z["vel_lo"], z["vel_hi"]), {})[tuple(z["dyn"])] = z
    keys = [k for k, v in sorted(cells.items(), key=lambda kv: (kv[0][0] or "",) + kv[0][1:]) if len(v) >= 2]
    if not keys:
        return []
    step = max(1, len(keys) // n_keys)
    out = []
    for k in keys[step // 2::step][:n_keys]:
        layers = [v for _, v in sorted(cells[k].items())]
        i = (len(layers) - 1) // 2
        sigs = []
        for z in layers[i:i + 2]:
            f = build / z["file"]
            info = sf.info(str(f))
            x, _ = sf.read(str(f), frames=min(info.frames, int(1.5 * info.samplerate)), dtype="float64", always_2d=True)
            x = x.mean(axis=1)
            o = true_onset(x, info.samplerate)
            sigs.append(x[o: o + int(win_s * info.samplerate)])
        n = min(len(s_) for s_ in sigs)
        if n < 1000:
            continue
        a, b = sigs[0][:n], sigs[1][:n]
        wa, wb = _xf_pair_weights(xf)
        mix = wa * a + wb * b
        corr = lambda u, v: float(np.dot(u, v) / (math.sqrt(float(np.dot(u, u) * np.dot(v, v))) + 1e-20))
        out.append((k[1], max(corr(mix, a), corr(mix, b))))
    return out


def lint_bundle(build: Path | str) -> list[Finding]:
    build = Path(build)
    out: list[Finding] = []
    for p in library.validate_bundle(build):
        out.append(Finding("FAIL", "bundle", p))
    mp = build / "manifest.json"
    if not mp.exists():
        return out
    m = json.loads(mp.read_text())
    fam = _family(m)
    fam_rules = families.get(fam)["lint"] if fam else {"release": False, "min_layers": 1, "max_step_db": 10,
                                                        "rr_min": 1}
    pitched_family = fam not in ("percussion",)
    zones = [z for z in m.get("zones", []) if (build / z["file"]).exists()]
    data = [_load(build, z, pitched_family) for z in zones]
    body = [d for d in data if d.z["layer"] == "body"]

    # silent, DC, aliasing, clicks, truncation
    for d in data:
        name = d.z["file"]
        if d.peak_db < -60:
            out.append(Finding("FAIL", "silent", f"{name}: peak {d.peak_db:.0f} dBFS"))
        if d.dc_db > -40:
            out.append(Finding("WARN", "dc", f"{name}: DC offset {d.dc_db:.0f} dB"))
        if d.above18k_db > -40 and d.z["layer"] == "body":
            out.append(Finding("WARN", "aliasing", f"{name}: {d.above18k_db:.0f} dB of the attack above 18 kHz"))
        if d.edge_start > 0.05:
            out.append(Finding("FAIL", "click", f"{name}: starts on a step ({d.edge_start:.0%} of peak): fade in"))
        if d.edge_end > 0.02 and d.z["layer"] != "air":
            out.append(Finding("FAIL", "click", f"{name}: ends on a step ({d.edge_end:.0%} of peak): fade out"))
        if d.loop_seam_db is not None:
            if d.loop_seam_db > -20 or (d.loop_step or 0) > 3:
                out.append(Finding("FAIL", "loop", f"{name}: loop seam {d.loop_seam_db:.0f} dB, jump ×{d.loop_step:.1f}"))
            loop_s = (d.z["loop"]["end"] - d.z["loop"]["start"]) / d.sr
            if loop_s < 1.0 and d.z["layer"] == "body" and fam not in ("synth", None):
                out.append(Finding("WARN", "loop", f"{name}: loop only {loop_s:.2f} s (cycles audibly under ~2 s)"))

    # per key: tuning spread, ladders, onset alignment, takes
    groups: dict[tuple, list[ZoneData]] = {}
    for d in body:
        groups.setdefault((d.z.get("articulation"), d.z["root"], d.z["lo"], d.z["hi"]), []).append(d)
    layer_counts = []
    xf_field = (m.get("dynamics") or {}).get("crossfade")
    xf = 1.0 if xf_field is None else float(xf_field)
    ladder_bad, bright_bad, step_bad, onset_bad, onset_timing, tune_bad, rr_same = [], [], [], [], [], [], []
    for (art, root, lo, hi), ds in sorted(groups.items(), key=lambda kv: (kv[0][0] or "",) + kv[0][1:]):
        nn = lambda r, art=art: dsp.note_name(r) + (f"[{art}]" if art else "")   # per articulation
        axis = lambda d: tuple(d.z.get("dyn") or (d.z["vel_lo"], d.z["vel_hi"]))
        by_axis: dict[tuple, list[ZoneData]] = {}
        for d in ds:
            by_axis.setdefault(axis(d), []).append(d)
        layer_counts.append(len(by_axis))
        ladder = [sorted(v, key=lambda d: d.z.get("take", 0))[0] for _, v in sorted(by_axis.items())]
        lv = [d.lufs_max for d in ladder]
        hf = [d.hf_db for d in ladder]
        if len(ladder) > 1:
            steps = np.diff(lv)
            if np.any(steps < -0.5):
                ladder_bad.append(f"{nn(root)} {' '.join(f'{v:.0f}' for v in lv)}")
            if np.any(steps > fam_rules["max_step_db"]):
                step_bad.append(f"{nn(root)} +{steps.max():.1f} dB")
            if hf[-1] - hf[0] < 1.0:
                bright_bad.append(nn(root))
        if len(ds) > 1:
            timing, worst = _onset_offsets(ds, xf)
            if timing > 1.0:
                onset_timing.append(f"{nn(root)} {timing:.1f} ms")
            if worst > 1.0:
                onset_bad.append(f"{nn(root)} {worst:.1f} ms")
        cs = [d.f0_cents for d in ds if d.f0_cents is not None]
        if len(cs) > 1 and max(cs) - min(cs) > 8:
            tune_bad.append(f"{nn(root)} {max(cs) - min(cs):.0f} c")
        for _, v in by_axis.items():
            if len(v) > 1:
                x = [d.head[d.onset: d.onset + int(0.5 * d.sr)] for d in v]
                n = min(len(t) for t in x)
                if n > 1000:
                    for i in range(len(x) - 1):
                        a, b = x[i][:n], x[i + 1][:n]
                        c = float(np.dot(a, b) / (math.sqrt(float(np.dot(a, a) * np.dot(b, b))) + 1e-20))
                        if c > 0.98:
                            rr_same.append(f"{nn(root)} takes {i}/{i + 1} corr {c:.3f}")
    def _cap(lst, k=6):
        return ", ".join(lst[:k]) + (f" … (+{len(lst) - k})" if len(lst) > k else "")
    if ladder_bad:
        out.append(Finding("FAIL", "ladder", f"level not rising with dynamics on {len(ladder_bad)} keys: {_cap(ladder_bad)}"))
    if step_bad:
        out.append(Finding("WARN", "ladder", f"dynamics steps above {fam_rules['max_step_db']} dB: {_cap(step_bad)}"))
    if bright_bad:
        out.append(Finding("WARN", "brightness", f"soft and loud layers equally bright on {len(bright_bad)} keys "
                                                 f"({_cap(bright_bad)}): the layers are one sound at two volumes"))
    if onset_bad:
        out.append(Finding("FAIL", "onset", f"crossfaded dynamics have phase-alignment shifts (> 1 ms) on {len(onset_bad)} keys: "
                                            f"{_cap(onset_bad)}"))
    if onset_timing:
        out.append(Finding("WARN", "onset", f"performed onset timing differs (> 1 ms) on {len(onset_timing)} keys: "
                                             f"{_cap(onset_timing)}; inspect leading silence versus natural attack/gestures"))
    if tune_bad:
        out.append(Finding("WARN", "tuning", f"layers of a key disagree by > 8 cents: {_cap(tune_bad)}"))
    if rr_same:
        out.append(Finding("WARN", "takes", f"round robins nearly identical: {_cap(rr_same)}"))
    if layer_counts and min(layer_counts) < fam_rules["min_layers"]:
        out.append(Finding("WARN", "layers", f"{min(layer_counts)} dynamics layer(s) on some keys; the {fam} "
                                             f"family wants >= {fam_rules['min_layers']}"))
    takes = 1 + max((d.z.get("take", 0) for d in body), default=0)
    if takes < fam_rules["rr_min"]:
        out.append(Finding("WARN", "takes", f"{takes} take(s); the {fam} family wants >= {fam_rules['rr_min']} round robins"))

    # dynamics crossfade: summing two different strikes smears (chorus/flange); flag it
    if xf > 0:
        cs = dyn_crossfade_correlation(build, [d.z for d in body], xf)
        low = [f"{dsp.note_name(r)} {c:.2f}" for r, c in cs if c < XF_CORR_MIN]
        if low:
            out.append(Finding("WARN", "crossfade", f"render-vs-raw correlation < {XF_CORR_MIN} at a mid velocity on "
                                                   f"{len(low)}/{len(cs)} keys ({_cap(low)}): the blended layers are "
                                                   f"not phase-aligned; lower dynamics.crossfade "
                                                   f"(sound.performance(dyn_crossfade=0) = hard layer switch)"))

    # keyboard-wide tuning curve and loudness of the top layer (per articulation: each is its own keyboard)
    arts = sorted({k[0] for k in groups}, key=lambda x: x or "")
    jumps, spreads, odd, tops_n, lufs_all = [], [], [], 0, []
    for art in arts:
        tag = f"[{art}]" if art else ""
        med = {}
        for (a_, root, _, _), ds in groups.items():
            cs = [d.f0_cents for d in ds if d.f0_cents is not None]
            if a_ == art and cs:
                med[root] = float(np.median(cs))
        roots = sorted(med)
        for i, r in enumerate(roots):
            nb = [med[q] for q in roots[max(0, i - 2): i + 3] if q != r]
            if len(nb) >= 2 and abs(med[r] - np.median(nb)) > 10:
                jumps.append(f"{dsp.note_name(r)}{tag} {med[r] - np.median(nb):+.0f} c")
        if roots:
            spreads.append(max(med.values()) - min(med.values()))
        tops = []
        for (a_, root, _, _), ds in sorted(groups.items(), key=lambda kv: (kv[0][0] or "",) + kv[0][1:]):
            if a_ != art:
                continue
            best = max(ds, key=lambda d: tuple(d.z.get("dyn") or (d.z["vel_lo"], d.z["vel_hi"])))
            tops.append((root, best.lufs_max))
        if len(tops) >= 3:
            vals = np.array([v for _, v in tops])
            sm = np.array([np.median(vals[max(0, i - 2): i + 3]) for i in range(len(vals))])
            odd += [f"{dsp.note_name(r)}{tag} {v - s_:+.1f} dB" for (r, v), s_ in zip(tops, sm) if abs(v - s_) > 3]
            lufs_all += list(vals)
            tops_n += len(tops)
    if jumps:
        out.append(Finding("WARN", "tuning", f"keys off the keyboard's tuning curve: {_cap(jumps)}"))
    if spreads:
        spread = max(spreads)
        out.append(Finding("INFO", "tuning", f"tuning spans {spread:.0f} cents bottom to top "
                                             f"({'stretch-tuned' if spread > 10 else 'equal-tempered'})"))
    if odd:
        out.append(Finding("WARN", "loudness", f"top layer jumps > 3 dB from its neighbours: {_cap(odd)}"))
    if lufs_all:
        out.append(Finding("INFO", "loudness", f"top layer {min(lufs_all):.0f}..{max(lufs_all):.0f} LUFS (momentary max) "
                                               f"across {tops_n} keys"))
    floors = [d.floor_db for d in body if d.frames > d.sr]
    if floors and max(floors) - min(floors) > 12:
        out.append(Finding("INFO", "noise", f"noise floor varies {min(floors):.0f}..{max(floors):.0f} dB between zones"))

    # releases
    has_tail = any(d.z["layer"] == "tail" for d in data)
    if fam_rules["release"] and not has_tail:
        out.append(Finding("WARN", "release", f"no release layer; a {fam} needs one (recorded, or "
                                              f"sampletools.release_from)"))
    for d in data:
        if d.z["layer"] == "tail" and "rt_decay" not in d.z and fam_rules["release"]:
            out.append(Finding("INFO", "release", "tail zones have no rt_decay (release level ignores held time)"))
            break
    if not any(f.level in ("FAIL", "WARN") for f in out):
        out.append(Finding("INFO", "summary", "clean"))
    return out


def lint_text(build: Path | str, name: str = "") -> str:
    fs = lint_bundle(build)
    nf = sum(f.level == "FAIL" for f in fs)
    nw = sum(f.level == "WARN" for f in fs)
    head = f"lint {name or Path(build).parent.name}: {nf} fail, {nw} warn"
    order = {"FAIL": 0, "WARN": 1, "INFO": 2}
    return head + "\n" + "\n".join(f.line() for f in sorted(fs, key=lambda f: order[f.level]))
