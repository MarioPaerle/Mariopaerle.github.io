"""Shared helpers for the physical-modelling toolkit: filter design for delay loops,
tuning, output conditioning and closed-loop pitch correction."""

from __future__ import annotations

import math
from typing import Callable

import numpy as np

from .. import dsp
from ..audio import DEFAULT_SR, Audio

C_AIR = 343.0  # speed of sound in air at 20 C, m/s


def freq_of(note) -> float:
    """MIDI note number, note name ('A4') or frequency in Hz (floats >= 20 are Hz) -> Hz."""
    if isinstance(note, str):
        return dsp.midi_to_freq(dsp.parse_note(note))
    note = float(note)
    return note if note >= 20.0 else dsp.midi_to_freq(note)


def check_freq(freq: float, sr: int, max_ratio: float = 6.0) -> float:
    freq = float(freq)
    if not np.isfinite(freq) or freq <= 0:
        raise ValueError(f"freq must be a positive number, got {freq}")
    if freq * max_ratio > sr:
        raise ValueError(f"freq {freq:.0f} Hz is too high for a delay-line model at {sr} Hz (max {sr / max_ratio:.0f} Hz)")
    if freq < 15:
        raise ValueError("freq below 15 Hz")
    return freq


def velocity01(v) -> float:
    """Accept 0..1 or MIDI 1..127 velocity; return 0..1."""
    v = float(v)
    return float(np.clip(v / 127.0 if v > 1.0 else v, 0.0, 1.0))


# ------------------------------------------------------------------ first-order sections

def allpass_phase_delay(a, f: float, sr: float):
    """Phase delay in samples of (a + z^-1)/(1 + a z^-1) at frequency f (scalar or array a)."""
    w = 2 * np.pi * f / sr
    z = np.exp(-1j * w)
    a = np.asarray(a, dtype=np.float64)
    return -np.angle((a + z) / (1 + a * z)) / w


def solve_allpass(delay: float, f: float, sr: float) -> float:
    """Coefficient a whose first-order allpass has phase delay `delay` (samples) at f."""
    lo, hi = -0.95, 0.95  # delay decreases with a
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if allpass_phase_delay(mid, f, sr) > delay:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def onepole_gain(g: float, p: float, f, sr: float):
    """|H| of y[n] = (1-p) g x[n] + p y[n-1]."""
    w = 2 * np.pi * np.asarray(f) / sr
    return g * (1 - p) / np.sqrt(1 - 2 * p * np.cos(w) + p * p)


def onepole_phase_delay(g: float, p: float, f: float, sr: float) -> float:
    w = 2 * np.pi * f / sr
    h = g * (1 - p) / (1 - p * np.exp(-1j * w))
    return float(-np.angle(h) / w)


def fit_onepole(f_a: float, gain_a: float, f_b: float, gain_b: float, sr: float) -> tuple[float, float]:
    """One-pole lowpass (g, p) with |H(f_a)| = gain_a and |H(f_b)| = gain_b (f_b > f_a).
    If gain_b >= gain_a (no extra high-frequency loss) it degrades to a flat gain."""
    gain_a = float(np.clip(gain_a, 1e-6, 0.99999))
    gain_b = float(np.clip(gain_b, 1e-9, 0.99999))
    if gain_b >= gain_a:
        return gain_a, 0.0
    target = gain_b / gain_a

    def ratio(p):
        return onepole_gain(1.0, p, f_b, sr) / onepole_gain(1.0, p, f_a, sr)

    lo, hi = 0.0, 0.995  # ratio falls as p rises
    if ratio(hi) > target:
        p = hi
    else:
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if ratio(mid) > target:
                lo = mid
            else:
                hi = mid
        p = 0.5 * (lo + hi)
    g = gain_a / onepole_gain(1.0, p, f_a, sr)
    if g > 1.0:
        g = 1.0
    return float(g), float(p)


def t60_to_trip_gain(t60: float, period_s: float) -> float:
    """Amplitude factor per round trip of length period_s for a decay of t60 seconds (-60 dB)."""
    return float(10.0 ** (-3.0 * period_s / max(t60, 1e-4)))


# ------------------------------------------------------------------ output conditioning

def finish(x: np.ndarray, sr: int, peak_db: float | None = -6.0, dc_hz: float = 15.0, meta: dict | None = None) -> Audio:
    """Replace non-finite samples, remove DC, optionally normalise the peak, wrap as Audio."""
    x = np.asarray(x, dtype=np.float64)
    if x.ndim == 1:
        if not np.all(np.isfinite(x)):
            raise FloatingPointError("physical model diverged (NaN/inf); reduce drive or damping extremes")
        if dc_hz and len(x) > 64:
            x = dsp.dc_block(x, sr, dc_hz)
        pk = float(np.abs(x).max(initial=0.0))
    else:
        x = np.stack([dsp.dc_block(x[:, c], sr, dc_hz) if dc_hz else x[:, c] for c in range(x.shape[1])], axis=1)
        pk = float(np.abs(x).max(initial=0.0))
    if peak_db is not None and pk > 1e-12:
        x = x * (dsp.undb(peak_db) / pk)
    return Audio(x, sr, meta)


def measure_f0(x: np.ndarray, sr: int, guess: float, t0: float = 0.25, t1: float = 0.95) -> float:
    """Sharp f0 of the steady part of x near `guess`: autocorrelation lag, refined by the
    harmonic-FFT estimator when the two agree (they disagree for strongly inhomogeneous spectra)."""
    n = len(x)
    seg = np.asarray(x[int(t0 * n): int(t1 * n)], dtype=np.float64)
    if len(seg) < 4096 or np.abs(seg).max() < 1e-9:
        return float("nan")
    _, cents, r1 = pitch_lock(x, sr, guess, t0, t1)
    if r1 < 0.3:
        return float("nan")
    f_lag = guess * 2.0 ** (cents / 1200.0)
    f_ref = dsp.refine_f0(seg[: 4 * sr], sr, f_lag)
    if np.isfinite(f_ref) and abs(1200.0 * math.log2(f_ref / f_lag)) < 8.0:
        return float(f_ref)
    return float(f_lag)


def analysis_f0(audio: Audio) -> float:
    """The f0 that `libero.analysis.features` reports for `audio` (NaN if unvoiced): what the compile
    summary and the tuning checks see, including the pull of inharmonic partials."""
    from .. import analysis
    return float(analysis.features(audio).get("f0_hz", float("nan")))


def pitch_lock(x: np.ndarray, sr: int, freq: float, t0: float = 0.4, t1: float = 0.95) -> tuple[bool, float, float]:
    """Is the steady part of x periodic at `freq`? Returns (locked, cents_error, autocorrelation).

    Uses the normalised autocorrelation: the best lag within +-10% of the target period must
    be strongly correlated and no half-period lag may be nearly as strong (octave-up overblow)."""
    n = len(x)
    seg = np.asarray(x[int(t0 * n): int(t1 * n)], dtype=np.float64)
    T = sr / freq
    if len(seg) < 6 * T or np.abs(seg).max() < 1e-7:
        return False, 0.0, 0.0
    seg = seg - seg.mean()
    m = 1 << int(math.ceil(math.log2(2 * len(seg))))
    F = np.fft.rfft(seg, m)
    r = np.fft.irfft(F * np.conj(F), m)[: len(seg) // 2]
    r = r / (r[0] + 1e-30)
    lo, hi = int(0.9 * T), int(1.1 * T) + 2
    k = lo + int(np.argmax(r[lo:hi]))
    r1 = float(r[k])
    if 1 <= k < len(r) - 1:
        a, b, c = r[k - 1], r[k], r[k + 1]
        den = a - 2 * b + c
        d = 0.5 * (a - c) / den if den != 0 else 0.0
    else:
        d = 0.0
    lag = k + float(np.clip(d, -1, 1))
    cents = 1200.0 * math.log2(T / lag)
    h0, h1 = int(0.42 * T), int(0.58 * T) + 1
    half = float(r[h0:h1].max()) if h1 > h0 else 0.0
    return bool(r1 > 0.8 and half < 0.96 * r1 and abs(cents) < 100), cents, r1


def autotune(render: Callable[[float], np.ndarray], freq: float, sr: int, iters: int = 5,
             tol_cents: float = 0.4, t0: float = 0.4, t1: float = 0.95) -> tuple[np.ndarray, float]:
    """Closed-loop tuning for self-sustained models (bow, reed, flute, lip).

    `render(f_model)` returns samples. The measured pitch of the steady part is compared with
    `freq` and the model frequency corrected by the error, up to `iters` times. Only renders that
    stay periodic at the target pitch are eligible (a self-sustained oscillator can jump register
    when its length changes); the closest one wins. Returns (samples, model frequency).
    Deterministic because `render` is."""
    fm = freq
    y = render(fm)
    best = None
    for it in range(iters + 1):
        ok, c_lag, _ = pitch_lock(y, sr, freq, t0, t1)
        m = measure_f0(y, sr, freq, t0, t1)
        err = 1200.0 * math.log2(m / freq) if np.isfinite(m) else c_lag
        if ok and (best is None or abs(err) < abs(best[2])):
            best = (y, fm, err)
        if abs(err) < tol_cents or it == iters or not np.isfinite(err):
            break
        fm = fm * 2.0 ** (-err / 1200.0)
        y = render(fm)
        if not pitch_lock(y, sr, freq, t0, t1)[0]:
            break
    return (best[0], best[1]) if best is not None else (y, fm)


def sawtooth_like(y: np.ndarray, sr: int, freq: float, t0: float = 0.4, t1: float = 0.95) -> bool:
    """True if the steady spectrum falls with harmonic number like a Helmholtz sawtooth (1/k): the
    2nd and 3rd harmonics clearly below the fundamental and the 3rd not above the 2nd."""
    n = len(y)
    x = np.asarray(y[int(t0 * n): int(t1 * n)], dtype=np.float64)
    if len(x) < 4096:
        return False
    S = np.abs(np.fft.rfft(x * np.hanning(len(x)), 1 << 17))
    fr = np.fft.rfftfreq(1 << 17, 1.0 / sr)
    h = [S[(fr > freq * k * 0.97) & (fr < freq * k * 1.03)].max(initial=1e-30) for k in (1, 2, 3)]
    d2, d3 = 20 * math.log10(h[1] / h[0]), 20 * math.log10(h[2] / h[0])
    return bool(d2 < -2.5 and d3 < -5.0 and d3 < d2 + 1.0)


def harmonic_fraction(y: np.ndarray, sr: int, freq: float, t0: float = 0.4, t1: float = 0.95, kmax: int = 12) -> float:
    """Share of the steady spectrum's power (0.7 f .. (kmax+0.5) f) that sits within +-2.5% of the harmonics of
    `freq`. A clean self-sustained note is > 0.9; a note that mixes in an inharmonic mode is much lower."""
    n = len(y)
    x = np.asarray(y[int(t0 * n): int(t1 * n)], dtype=np.float64)
    if len(x) < 4096:
        return 0.0
    P = np.abs(np.fft.rfft(x * np.hanning(len(x)), 1 << 17)) ** 2
    fr = np.fft.rfftfreq(1 << 17, 1.0 / sr)
    total = P[(fr > 0.7 * freq) & (fr < (kmax + 0.5) * freq)].sum()
    harm = 0.0
    for k in range(1, kmax + 1):
        if k * freq < 0.48 * sr:
            harm += P[(fr > freq * k * 0.975) & (fr < freq * k * 1.025)].sum()
    return float(harm / (total + 1e-30))


def locked(cands, run, freq: float, sr: int, tune: bool = True, accept=None):
    """Render with the first candidate (a model-specific tuning variable) whose output is periodic at `freq`
    (no overblow, no subharmonic), passes the optional `accept(y)` test, and stays so after closed-loop pitch
    correction (to within 8 cents). Each candidate costs one render until one passes, so a note that speaks
    at once is as cheap as before. Otherwise the most periodic candidate is returned. The same note with
    the same inputs always picks the same candidate."""
    best = None
    for c in cands:
        y0 = run(freq, c)
        ok, cents, r1 = pitch_lock(y0, sr, freq)
        acc = accept is None or accept(y0)
        if ok and acc and abs(cents) < 60.0:
            y, _ = autotune(lambda f: run(f, c), freq, sr) if tune else (y0, freq)
            ok2, c2, _ = pitch_lock(y, sr, freq)
            if ok2 and abs(c2) < 8.0 and (accept is None or accept(y)):
                return y
        score = r1 - abs(cents) / 100.0 - (0.0 if acc else 0.5)
        if best is None or score > best[1]:
            best = (c, score, y0)
    y, _ = autotune(lambda f: run(f, best[0]), freq, sr) if tune else (best[2], freq)
    return y


def smooth_noise(n: int, sr: int, rate_hz: float, rng: np.random.Generator) -> np.ndarray:
    """Band-limited random signal with unit RMS, fluctuating at about rate_hz."""
    if n <= 0:
        return np.zeros(0)
    k = max(2, int(n * rate_hz / sr) + 3)
    pts = rng.standard_normal(k)
    x = np.interp(np.linspace(0, k - 1, n), np.arange(k), pts)
    return x / (np.std(x) + 1e-12)


def as_control(x, n: int, name: str = "control") -> np.ndarray:
    """Scalar or array -> float64 array of length n (arrays are resampled linearly)."""
    if np.isscalar(x):
        return np.full(n, float(x))
    x = np.asarray(x, dtype=np.float64)
    if x.ndim != 1 or len(x) == 0:
        raise ValueError(f"{name} must be a scalar or a 1-D array")
    if len(x) == n:
        return x
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x)


def octave_bands() -> np.ndarray:
    return np.array([125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0])


__all__ = ["DEFAULT_SR"]
