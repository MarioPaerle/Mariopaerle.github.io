"""Wind instruments: single and double reed, flute (jet), brass (lip reed).

All models are dimensionless McIntyre-Schumacher-Woodhouse waveguide loops: a memoryless (reed)
or second-order (lip) nonlinear junction plus a bore delay loop with a one-pole reflection filter
(bell + tone-hole cutoff). Pressures are normalised to the reed's closing pressure:

    gamma  mouth pressure / closing pressure. Clarinet oscillation threshold 1/3; playing 0.4-0.7.
    zeta   embouchure/bore-impedance ratio (reed opening x bore admittance), 0.2-0.8.

The pitch of a self-sustained oscillator depends on blowing pressure, so every model measures its
own output and corrects the bore length (`autotune=True`, default): notes land within a few cents.
Breath noise is injected both into the pressure (turbulence modulating the reed) and into the
output, scaled by the flow, as in real instruments.
"""

from __future__ import annotations

import math

import numpy as np
from scipy import signal

from ..audio import DEFAULT_SR, Audio
from . import _common as cm
from ._kernels import flute_kernel, lip_kernel, reed_kernel


def _bore_filter(f0: float, sr: int, loss: float, cutoff: float):
    """One-pole lowpass (gain, pole) for the bell/tone-hole reflection: amplitude 1-loss at low
    frequency, 3 dB lower at `cutoff`."""
    g0 = 1.0 - loss
    fc = max(cutoff, 1.2 * f0)
    fc = min(fc, 0.45 * sr)
    return cm.fit_onepole(min(f0, 0.3 * fc), g0, fc, g0 * 0.7071, sr)


def _noise(n: int, sr: int, rng, cutoff: float = 5000.0) -> np.ndarray:
    x = rng.standard_normal(n)
    sos = signal.butter(2, cutoff, fs=sr, output="sos")
    x = signal.sosfilt(sos, x)
    return x / (np.std(x) + 1e-12)


def _split(f: float, sr: int, total: float, lp_g: float, lp_p: float, extra_delay: float = 0.0):
    """Integer delay D and allpass coefficient making the loop's phase delay at f equal `total`."""
    R = total - cm.onepole_phase_delay(lp_g, lp_p, f, sr) - extra_delay
    D = int(math.floor(R - 0.5))
    if D < 4:
        raise ValueError(f"{f:.0f} Hz is too high for this bore model at {sr} Hz")
    return D, cm.solve_allpass(R - D, f, sr)


def _early_ok(y: np.ndarray, sr: int, freq: float) -> bool:
    """The note must already be on its fundamental shortly after the attack (no register jump mid-note)."""
    ok, cents, _ = cm.pitch_lock(y, sr, freq, 0.15, 0.4)
    return bool(ok and abs(cents) < 60.0)


def reed(freq: float, dur: float = 2.0, *, pressure=0.5, bore: str = "cylindrical", zeta=0.4, stiffness: float = 0.5,
         min_opening: float = 0.0, loss: float = 0.02, cutoff: float | None = None, apex: float = 0.25,
         noise: float = 0.3, edge: float = 0.0, autotune: bool = True, sr: int = DEFAULT_SR, seed: int = 0,
         peak_db: float | None = -6.0) -> Audio:
    """Single/double reed on a cylindrical or conical bore.

    pressure   mouth pressure gamma: scalar or array over time (see `performance.breath`).
               Below ~0.33 (cylinder) it stays silent; 0.4-0.7 is the playing range, close to 1 the
               reed beats and the tone gets harsh.
    bore       'cylindrical' (clarinet: closed-open, odd harmonics, plays f = c/4L) or 'conical'
               (sax, oboe, bassoon: full harmonic series, f = c/2(L + apex distance)).
    zeta       embouchure parameter, scalar or array: large = open, loud, buzzy; small = pinched,
               quiet, dull and needs more pressure. 0.2-0.8.
    stiffness  0 very soft reed (opening closes gradually, round mellow tone) .. 1 stiff (the ideal
               square-root law: bright, edgy). Sets the curvature of the reed flow law.
    min_opening  0..0.3 fraction of the channel that stays open when the reed is fully closed: ~0 single
               reed, 0.05-0.15 double reed (oboe/bassoon reeds never seal): keeps it speaking at high
               pressure and adds the nasal edge.
    loss       bore loss per round trip at low frequency (0.005 very resonant .. 0.06 damped).
    cutoff     Hz above which the bell/tone-hole lattice stops reflecting. Default: 2500 (cylindrical),
               2.3 x freq (conical: the bore must damp its own 3rd and higher modes or the cone
               overblows; keep it between 2 and 2.7 x freq). Lower = darker, rounder.
    apex       conical bore only: distance from reed to cone apex as a fraction of the total cone
               length (0.15 - 0.4). Larger = softer and more stable; below ~0.15 the tube overblows
               onto its second mode.
    noise      0..1 breath noise: turbulence added to the pressure and the radiated sound.
    edge       0..1 reed edge: a level-tracking asymmetric soft saturation (tanh) applied to the
               radiated sound (double reeds, saxophone mouthpieces and the tone-hole lattice add energy in
               harmonics 2-8 that a one-loop quasi-static reed under-produces on a cone). 0 = the model's
               own spectrum (clarinet), 0.4-0.7 oboe/sax; it brightens with level like the real thing.
    Output is the pressure radiated by the bell (the open-end transmission, a gentle highpass)."""
    freq = cm.check_freq(freq, sr, max_ratio=12.0)
    n = int(round(dur * sr))
    rng = np.random.default_rng(seed)
    gam = cm.as_control(pressure, n, "pressure")
    zet = cm.as_control(zeta, n, "zeta")
    if not 0.0 <= stiffness <= 1.0:
        raise ValueError("stiffness must be 0..1")
    m = 0.4 + 0.6 * stiffness  # reed-flow curvature exponent, 0.4 .. 1.0
    conical = bore.startswith("con")
    nz = _noise(n, sr, rng)
    noise_gain = noise * 0.05 * max(float(np.mean(gam)), 0.2)
    hiss_nz = _noise(n, sr, np.random.default_rng(seed + 7), 7000.0)

    def run(f, cand=(2.3, 1.0, 1.0), nn=n, gg=gam, zz=zet, noi=nz):
        cr, am, ps = cand
        gg = gg * ps
        lp_g, lp_p = _bore_filter(f, sr, loss, cutoff if cutoff is not None else (cr * f if conical else 2500.0))
        if conical:
            tau = float(np.clip(apex * am, 0.005, 0.45)) / (2.0 * f)
            w = 2 * math.pi * f
            total = sr / f - sr * 2.0 * math.atan(w * tau) / w
            kap = np.full(nn, 1.0 / (2.0 * sr * tau))
        else:
            total = sr / (2.0 * f)
            kap = np.zeros(nn)
        D, a = _split(f, sr, total, lp_g, lp_p)
        y, u, _ = reed_kernel(nn, D, a, lp_g, lp_p, 0.0, gg, zz, kap, noi, noise_gain, m, float(min_opening), 0.9995)
        return y + hiss_nz[:nn] * np.abs(u) * noise * 0.08

    if conical and cutoff is None:
        cands = [(cr, am, ps) for ps in (1.0, 0.9, 1.1) for am in (1.0, 0.8, 1.25) for cr in (2.3, 2.1, 2.5, 2.0, 2.7)]
    else:
        cands = [(2.3, 1.0, 1.0)]
    y = cm.locked(cands, lambda f, c: run(f, c), freq, sr, autotune,
                  accept=(lambda y: cm.harmonic_fraction(y, sr, freq) > 0.9 and _early_ok(y, sr, freq)) if conical else None)
    if edge > 0:
        y = _edge(y, edge)
    return cm.finish(y, sr, peak_db)


def _edge(y: np.ndarray, amount: float) -> np.ndarray:
    """Level-tracking soft saturation + asymmetric term (see `reed`). The drive follows the local
    RMS (40 ms), so the sound gets brighter as it gets louder and silence stays silent."""
    from scipy import ndimage
    env = np.sqrt(ndimage.uniform_filter1d(y * y, 1920, mode="nearest")) + 1e-9
    x = y / env
    d = 1.0 + 3.0 * amount
    z = np.tanh(d * (x + 0.55 * amount))
    return (z - np.mean(z)) * env


def flute(freq: float, dur: float = 2.0, *, pressure=0.9, jet_ratio: float | None = None, jet_reflection: float = 0.5,
          end_reflection: float = 0.5, cutoff: float = 4000.0, noise: float = 0.4, autotune: bool = True,
          sr: int = DEFAULT_SR, seed: int = 0, peak_db: float | None = -6.0) -> Audio:
    """Air-jet flute (concert flute, recorder-like at jet_ratio ~ 0.4, shakuhachi-like with noise=1).

    pressure        breath pressure, scalar or array (0.8 soft .. 1.1 hard; the flute speaks
                    above ~0.75; too hard overblows towards noise). Use `performance.breath` for a natural onset.
    jet_ratio       jet transit delay / bore delay (0.25 .. 0.45). None (default) picks, by trial
                    renders, the first value around 0.35 at which this note speaks cleanly on its
                    fundamental: the flute only speaks in narrow jet-delay windows that move with
                    pitch. Give a number to force it (small = edgy, large = breathy).
    jet_reflection  how strongly the bore's returning wave steers the jet (0.3-0.7).
    end_reflection  fraction of the returning wave fed straight back (0.3-0.7): more = more
                    resonant, purer, slower to speak.
    cutoff          Hz, lowpass in the bore (open end): 2500 dark alto flute .. 6000 piccolo.
    noise           0..1 breath/chiff noise injected into the jet."""
    freq = cm.check_freq(freq, sr, max_ratio=8.0)
    n = int(round(dur * sr))
    rng = np.random.default_rng(seed)
    br = cm.as_control(pressure, n, "pressure")
    nz = _noise(n, sr, rng, 6000.0) * (0.12 * noise) * br
    p = math.exp(-2 * math.pi * cutoff / sr)

    def run(f, jr, nn=n, bb=br, zz=nz):
        Db = max(1.5 * sr / f - 2.0, 6.0)
        return flute_kernel(nn, Db, max(jr * Db, 2.5), -1.0, p, bb, zz, jet_reflection, end_reflection, 0.995)

    cands = [jet_ratio] if jet_ratio is not None else [0.35, 0.33, 0.37, 0.31, 0.39, 0.41, 0.29, 0.43]
    y = cm.locked(cands, lambda f, c: run(f, c), freq, sr, autotune)
    return cm.finish(y, sr, peak_db)


def _lip_coeffs(f_lip: float, q: float, sr: int):
    b, a = signal.iirfilter(2, f_lip, btype="low", ftype="butter", fs=sr)
    w0 = 2 * math.pi * f_lip / sr
    alpha = math.sin(w0) / (2 * q)
    c = math.cos(w0)
    b0 = (1 - c) / 2
    b1 = 1 - c
    a0 = 1 + alpha
    return (np.array([b0, b1, b0]) / a0, np.array([-2 * c, 1 - alpha]) / a0)


def brass(freq: float, dur: float = 2.0, *, pressure=0.5, pedal: float = 116.5, register: int | None = None,
          lip_ratio: float | None = None, lip_q: float = 5.0, zeta=0.5, lip_opening: float = 0.6, brassiness: float = 0.3,
          loss: float = 0.03, cutoff: float = 1800.0, noise: float = 0.2, kick: float = 1.0, autotune: bool = True,
          sr: int = DEFAULT_SR, seed: int = 0, peak_db: float | None = -6.0) -> Audio:
    """Lip-reed brass (trumpet, trombone, horn, tuba): mass-spring lip valve on a harmonic bore.

    pressure     mouth pressure (0.3 pp .. 0.9 ff), scalar or array (see `performance.breath`).
    pedal        pedal-tone frequency of the tube (Hz): trumpet 116.5 (Bb), trombone 58.3, horn 43.7,
                 tuba 29. The played note is partial `register` of this tube (chosen from freq/pedal
                 if not given) and the bore length is re-tuned to land exactly on `freq`, like a
                 valve/slide.
    lip_ratio    lip resonance / played pitch. The lips must sit below the note (0.65-1.0) to buzz. None
                 (default) picks, by trial renders, the value where this note locks cleanly.
    lip_q        lip resonance quality (3 loose/buzzy .. 10 focused).
    zeta         valve admittance, 0.2-0.8 (mouthpiece size: bigger = louder, rougher).
    lip_opening  rest opening of the lips, 0.3 tight .. 1 open.
    brassiness   0..1 nonlinear steepening in the bore (shock-forming at fortissimo): the spectrum
                 brightens with level ('cuivre'). 0 = linear, 0.3 typical, 1 = blaring.
    loss, cutoff bore loss per round trip and the bell cutoff Hz (trumpet 1500-2000, trombone
                 800-1200, horn 500-800, tuba 300-500).
    Output is the bell radiation."""
    freq = cm.check_freq(freq, sr, max_ratio=12.0)
    n = int(round(dur * sr))
    rng = np.random.default_rng(seed)
    gam = cm.as_control(pressure, n, "pressure")
    zet = cm.as_control(zeta, n, "zeta")
    reg = register or max(2, int(round(freq / pedal)))
    nz = _noise(n, sr, rng, 4000.0)
    noise_gain = noise * 0.03 * max(float(np.mean(gam)), 0.2)
    h0 = np.full(n, lip_opening)

    def run(f, lr, nn=n, gg=gam, zz=zet, hh=h0, noi=nz):
        lp_g, lp_p = _bore_filter(f / 2.0, sr, loss, cutoff)
        D, a = _split(f, sr, reg * sr / f, lp_g, lp_p)
        lb, la = _lip_coeffs(min(f * lr, 0.4 * sr), lip_q, sr)
        y, _ = lip_kernel(nn, D, lp_g, lp_p, a, math.exp(-2 * math.pi * 0.35 * (f / reg) / sr), gg, zz, hh, lb, la,
                          1.0, brassiness * 0.35, 3.0, noi, noise_gain, kick)
        return y

    cands = [lip_ratio] if lip_ratio is not None else [0.85, 0.8, 0.9, 0.75, 0.95, 0.7, 1.0, 0.65]
    y = cm.locked(cands, lambda f, c: run(f, c), freq, sr, autotune)
    return cm.finish(y, sr, peak_db)
