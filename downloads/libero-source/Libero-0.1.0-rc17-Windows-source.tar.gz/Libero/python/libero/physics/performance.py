"""Performance helpers: natural control signals for the self-sustained models, vibrato and
humanisation, and `render_note`, the pattern that plugs any model into `@sound.body`.

    breath(dur, peak, ...)       mouth-pressure curve with a tongued onset, overshoot, tremor, release
    bow_stroke(dur, ...)         (speed, pressure) curves with a Guettler-style attack
    vibrato(dur, ...)            pitch curve in cents; `pitch_modulate(audio, cents)` applies it
    humanize(seed, amount)       reproducible micro-variations per take: pitch, level, brightness, onset
    render_note(model, note, velocity, dur, ctx=ctx)   -> Audio for a sound-recipe body

    @sound.body
    def body(ctx):
        return ph.render_note(ph.presets.clarinet(), ctx.note, ctx.vel, 3.0, ctx=ctx)
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy import interpolate

from ..audio import DEFAULT_SR, Audio
from . import _common as cm


def _smooth(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


def breath(dur: float, peak: float = 0.6, *, attack: float = 0.06, release: float = 0.15, sustain: float = 1.0,
           overshoot: float = 0.08, tremor: float = 0.02, swell: float = 0.0, start: float = 0.0,
           sr: int = DEFAULT_SR, seed: int = 0) -> np.ndarray:
    """Mouth/breath pressure over time (array of length dur*sr) for `physics.winds` models.

    peak       the pressure reached (same units as the model's `pressure`: gamma for reeds, breath for
               flute, mouth pressure for brass).
    attack     s to rise from `start` to the peak; a tongued start is 0.02-0.04, a soft breath 0.1-0.25.
    overshoot  fraction by which the tongue attack overshoots the sustain level before settling (0..0.3).
    sustain    level after the attack relative to `peak` (0.7..1).
    tremor     relative random fluctuation of a steady blow (0.01-0.04): makes held notes alive.
    swell      slow rise or fall of the sustained level over the note (+0.2 crescendo, -0.2 diminuendo).
    release    s from the end of the note to zero."""
    n = int(round(dur * sr))
    t = np.arange(n) / sr
    t_end = max(dur - release, attack + 0.01)
    up = start + (1.0 - start) * _smooth(t / max(attack, 1e-3))
    settle = np.exp(-np.maximum(t - attack, 0.0) / 0.08)
    body = sustain + (1.0 - sustain) * settle + overshoot * settle * _smooth(t / max(attack, 1e-3))
    sw = 1.0 + swell * np.clip((t - attack) / max(t_end - attack, 0.1), 0.0, 1.0)
    down = 1.0 - _smooth((t - t_end) / max(release, 1e-3))
    rng = np.random.default_rng(seed)
    trem = 1.0 + tremor * cm.smooth_noise(n, sr, 6.0, rng)
    return peak * up * body * sw * trem * down


def bow_stroke(dur: float, speed: float = 0.25, pressure: float = 0.6, *, attack: float = 0.08,
               release: float = 0.12, pressure_ramp: float = 1.6, start_pressure: float = 0.55,
               sr: int = DEFAULT_SR, seed: int = 0) -> tuple[np.ndarray, np.ndarray]:
    """(speed m/s, pressure 0..1) arrays for `strings.bow`: a single bow stroke.

    Speed ramps in over `attack` s; pressure starts at `start_pressure` x its final value and ramps
    over `pressure_ramp` x attack (too fast a force ramp gives a crunchy 'scratch', too slow a
    whistle): the gentle attack the Guettler diagram asks for. The stroke ends by slowing over
    `release` s. A little bow-speed wobble (1/f) keeps it from sounding mechanical."""
    n = int(round(dur * sr))
    t = np.arange(n) / sr
    t_end = max(dur - release, attack + 0.02)
    rng = np.random.default_rng(seed)
    sp = speed * _smooth(t / max(attack, 1e-3)) * (1.0 - _smooth((t - t_end) / max(release, 1e-3)))
    sp = sp * (1.0 + 0.03 * cm.smooth_noise(n, sr, 3.0, rng))
    pr = pressure * (start_pressure + (1 - start_pressure) * _smooth(t / max(attack * pressure_ramp, 1e-3)))
    return sp, np.clip(pr, 0.0, 1.0)


def vibrato(dur: float, rate: float = 5.5, depth_cents: float = 20.0, *, onset: float = 0.35, ramp: float = 0.5,
            irregularity: float = 0.12, sr: int = DEFAULT_SR, seed: int = 0) -> np.ndarray:
    """Vibrato as an array of cents over time (mean 0): sinusoid with slowly wandering rate and depth,
    starting after `onset` s and growing over `ramp` s. Violin 5.5-6.5 Hz +-15-30 cents, voice 5-6 Hz."""
    n = int(round(dur * sr))
    t = np.arange(n) / sr
    rng = np.random.default_rng(seed)
    wob = cm.smooth_noise(n, sr, 0.7, rng)
    rate_t = rate * (1.0 + irregularity * wob)
    ph = 2 * math.pi * np.cumsum(rate_t) / sr + rng.uniform(0, 2 * math.pi)
    depth = depth_cents * (1.0 + irregularity * cm.smooth_noise(n, sr, 0.5, rng)) * _smooth((t - onset) / max(ramp, 1e-3))
    return depth * np.sin(ph)


def pitch_modulate(audio: Audio, cents) -> Audio:
    """Warp `audio` so its pitch follows `cents` (scalar or array over time, e.g. from `vibrato`).
    Cubic interpolation; duration is preserved."""
    x = audio.data.astype(np.float64)
    n = x.shape[0]
    c = cm.as_control(cents, n, "cents")
    ratio = 2.0 ** (c / 1200.0)
    pos = np.clip(np.cumsum(ratio) - ratio[0], 0, n - 1)
    idx = np.arange(n)
    if x.ndim == 1:
        y = interpolate.interp1d(idx, x, kind="cubic", assume_sorted=True)(pos)
    else:
        y = np.stack([interpolate.interp1d(idx, x[:, k], kind="cubic", assume_sorted=True)(pos) for k in range(2)], axis=1)
    return Audio(y, audio.sr)


@dataclass(frozen=True)
class Humanize:
    """Seeded micro-variations; apply with `apply` or read the fields to steer a model."""
    pitch_cents: float
    gain_db: float
    brightness: float  # 0.85 .. 1.15 multiplier for spectral tilt / hardness-type parameters
    onset_ms: float

    def apply(self, audio: Audio) -> Audio:
        out = audio.gain_db(self.gain_db)
        if abs(self.pitch_cents) > 0.05:
            out = out.pitch(self.pitch_cents / 100.0)
        if self.onset_ms > 0:
            out = out.pad(before=self.onset_ms / 1000.0)
        return out


def humanize(seed: int = 0, amount: float = 1.0) -> Humanize:
    """Reproducible performance variation for a take: pitch +-2 cents, level +-0.6 dB, brightness +-8%,
    onset 0..8 ms late, all scaled by `amount` (0 = identical takes)."""
    r = np.random.default_rng(int(seed) + 7919)
    return Humanize(float(r.normal(0, 1.0) * 1.2 * amount), float(r.normal(0, 0.35) * amount),
                    float(1.0 + r.normal(0, 0.05) * amount), float(abs(r.normal(0, 3.0)) * amount))


def render_note(model, note, velocity=None, dur: float | None = None, *, ctx=None, sr: int | None = None, seed: int | None = None,
                humanise: float = 0.0, **overrides) -> Audio:
    """Render one note of a physical model: the glue between `physics` and a sound recipe.

        @sound.body
        def body(ctx):
            return ph.render_note(ph.presets.piano(), ctx.note, ctx.vel, 4.0, ctx=ctx)

    model      an `Instrument` (see `physics.presets`) or any callable f(freq, velocity, dur, sr, seed) -> Audio.
    note       MIDI number, name ('A3'), Hz, or a `Ctx` (then velocity comes from it and the third
               argument is the duration: `render_note(model, ctx, 3.0)`).
    velocity   0..1 or MIDI 1..127 (default: ctx.vel, else 0.7).
    dur        seconds of sound wanted; models add their natural release/ring tail on top where it
               applies (strings and struck bodies ring for `dur` in total).
    ctx        the recipe `Ctx`: supplies sr and seed (so takes differ and recompiles are identical).
    humanise   0..1 amount of per-take pitch/level/onset variation, seeded by ctx.seed.
    overrides  model parameters for this note only (e.g. pressure=0.6, decay=3.0)."""
    if hasattr(note, "freq") and hasattr(note, "sr"):  # render_note(model, ctx, dur)
        ctx = note
        note = ctx.note
        if dur is None and velocity is not None:
            dur = velocity
        velocity = ctx.vel
    if velocity is None:
        velocity = ctx.vel if ctx is not None else 0.7
    if dur is None:
        dur = 2.0
    sr = sr or (ctx.sr if ctx is not None else DEFAULT_SR)
    seed = seed if seed is not None else (ctx.seed if ctx is not None else 0)
    f = cm.freq_of(note)
    v = cm.velocity01(velocity)
    if hasattr(model, "render"):
        a = model.render(f, v, dur, sr=sr, seed=seed, **overrides)
    else:
        a = model(f, v, dur, sr, seed, **overrides)
    if humanise > 0:
        a = humanize(seed, humanise).apply(a)
    return a


def check(audio: Audio, freq: float) -> dict:
    """Validate a rendered note against the pitch it should have: `cents` (steady-state error from
    autocorrelation; +-3 is the target), `locked` (periodic at `freq`, not overblown), `harmonic_fraction`
    (share of spectral power on the harmonics: > 0.9 for a clean tone), `analysis_cents` (what
    `analysis.features` reads), `peak_db`, `finite`. Use it in a loop while designing a physical
    sound; all numbers come from the steady part of the note."""
    x = audio.data if audio.channels == 1 else audio.data.mean(axis=1)
    ok, c, r = cm.pitch_lock(x, audio.sr, freq, 0.3, 0.9)
    f_an = cm.analysis_f0(audio)
    return {
        "finite": bool(np.all(np.isfinite(audio.data))),
        "peak_db": round(float(audio.peak_db), 2),
        "locked": bool(ok),
        "cents": round(float(c), 2),
        "autocorr": round(float(r), 3),
        "harmonic_fraction": round(cm.harmonic_fraction(x, audio.sr, freq, 0.3, 0.9), 3),
        "analysis_cents": None if not np.isfinite(f_an) else round(1200.0 * math.log2(f_an / freq), 2),
    }
