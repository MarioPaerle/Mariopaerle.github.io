"""Bodies and radiation: what happens to the vibration between the bridge (or the bore) and the air.

    Body            parallel bank of resonances (air/Helmholtz mode, top-plate modes, bridge hill,
                    dense soundboard) applied to a string's bridge force by convolution
    horn_radiation  highpass radiation of a bell/horn (low frequencies are reflected, not radiated)
    off_axis        piston-aperture directivity at an angle
    distance        1/r level, propagation delay and ISO 9613-1 air absorption

Body presets use modes from measurements in the literature (approximate): classical/steel guitar
(air ~98 Hz, top ~200 Hz, ...), violin (A0 ~280 Hz, B1- ~480, B1+ ~560, bridge hill ~2.8 kHz),
cello (A0 ~100 Hz, B1- ~190, B1+ ~270, bridge hill ~1.5 kHz), piano soundboard (dense, 60 modes per
octave, T60 0.15-0.5 s). A `Body` is data: edit `.modes` or build your own from (freq, Q, gain).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
from scipy import signal

from .. import dsp
from ..audio import DEFAULT_SR, Audio
from . import _common as cm
from ._kernels import modal_kernel


@dataclass
class Body:
    """modes: list of (freq Hz, Q, peak gain dB). T60 = 2.2 Q / f. Each resonance rises to its gain (dB re 1)
    while the unfiltered path sits at `direct` dB, so gain - direct is how far it stands above the floor.
    `highpass` Hz removes sub-resonance rumble (a top plate can't radiate below its air mode)."""
    modes: list = field(default_factory=list)
    direct: float = -6.0
    highpass: float = 40.0
    name: str = ""

    def with_(self, **kw) -> "Body":
        d = dict(modes=list(self.modes), direct=self.direct, highpass=self.highpass, name=self.name)
        d.update(kw)
        return Body(**d)

    def scaled(self, pitch: float = 1.0) -> "Body":
        """Shift every resonance by a factor (a bigger/smaller instrument of the same design)."""
        return self.with_(modes=[(f * pitch, q, g) for f, q, g in self.modes])

    def ir(self, sr: int = DEFAULT_SR, dur: float | None = None, seed: int = 0) -> Audio:
        """Impulse response: direct path + modal bank, normalised so its magnitude response has a
        median of 0 dB between 100 Hz and 4 kHz (a body colours, it does not amplify)."""
        modes = self.modes
        if not modes:
            return Audio(np.array([1.0]), sr)
        tmax = max(2.2 * q / f for f, q, g in modes)
        dur = dur or float(np.clip(tmax * 1.05, 0.05, 1.5))
        n = int(dur * sr)
        freqs = np.array([f for f, q, g in modes])
        t60 = np.array([2.2 * q / f for f, q, g in modes])
        rng = np.random.default_rng(seed)
        sign = np.where(rng.random(len(freqs)) < 0.5, -1.0, 1.0) if len(freqs) > 6 else np.ones(len(freqs))
        w = 2 * math.pi * freqs / sr
        r = 10.0 ** (-3.0 / (t60 * sr))
        z = np.exp(-1j * w)
        peak = 1.0 / np.abs(1.0 - 2 * r * np.cos(w) * z + r * r * z * z)  # resonator peak for b = 1
        # each mode's peak magnitude is exactly its gain (dB, re 1; the direct path sits at `direct`)
        gains = np.array([dsp.undb(g) for f, q, g in modes]) / peak / np.maximum(np.sin(w), 1e-6) * sign
        h = modal_kernel(n, freqs, t60, gains, np.ones(1), float(sr))
        h[0] += dsp.undb(self.direct)
        if self.highpass:
            sos = signal.butter(2, self.highpass, "highpass", fs=sr, output="sos")
            h = signal.sosfilt(sos, h)
        H = np.abs(np.fft.rfft(h, 1 << 15))
        fr = np.fft.rfftfreq(1 << 15, 1.0 / sr)
        band = (fr > 100) & (fr < 4000)
        h = h / (np.median(H[band]) + 1e-12)
        return Audio(h, sr)

    def apply(self, audio: Audio, mix: float = 1.0, seed: int = 0) -> Audio:
        """Pass `audio` through the body (convolution). mix 0 = dry, 1 = fully through the body."""
        ir = self.ir(audio.sr, seed=seed).data.astype(np.float64)
        x = audio.data.astype(np.float64)
        y = signal.oaconvolve(x, ir, axes=0)[: len(x)] if x.ndim == 1 else \
            np.stack([signal.oaconvolve(x[:, c], ir)[: len(x)] for c in range(2)], axis=1)
        out = (1.0 - mix) * x + mix * y
        return Audio(out, audio.sr)


# ------------------------------------------------------------------ presets

def guitar(kind: str = "classical") -> Body:
    """Guitar top + back + air: 'classical' (nylon, lower/broader) or 'steel' (brighter top, more highs)."""
    if kind not in ("classical", "steel"):
        raise ValueError("kind must be 'classical' or 'steel'")
    s = 1.0 if kind == "classical" else 1.06
    modes = [(98 * s, 22, 6), (196 * s, 26, 7), (283 * s, 24, 3), (375 * s, 22, 2), (438 * s, 20, 2),
             (520 * s, 20, 1), (615 * s, 18, 1), (740 * s, 16, 0), (905 * s, 15, 0), (1100, 14, -1),
             (1420, 12, -1), (1850, 10, -1), (2450, 8, -1 if kind == "classical" else 1),
             (3100, 7, -2 if kind == "classical" else 0), (4100, 6, -3)]
    return Body(modes, direct=-8.0, highpass=60.0, name=f"guitar/{kind}")


def violin() -> Body:
    """Violin: air mode A0 ~280, main wood/top ~460 (B1-), ~550 (B1+), corpus modes, bridge hill 2-4 kHz."""
    modes = [(280, 35, 6), (405, 28, 2), (465, 30, 8), (560, 28, 7), (700, 24, 3), (830, 22, 2),
             (1000, 20, 2), (1200, 18, 1), (1500, 16, 1), (1900, 14, 2), (2400, 6, 5), (3000, 5, 6),
             (3700, 5, 3), (4600, 6, 0), (5600, 7, -2)]
    return Body(modes, direct=-10.0, highpass=180.0, name="violin")


def cello() -> Body:
    """Cello: air ~100 Hz, top ~190 (B1-), ~270 (B1+), 400-900 corpus, bridge hill ~1.5 kHz (broad)."""
    modes = [(100, 30, 7), (135, 26, 2), (190, 28, 8), (270, 26, 6), (330, 24, 3), (410, 22, 3), (520, 20, 2),
             (650, 18, 2), (800, 16, 2), (1000, 12, 2), (1300, 6, 4), (1650, 5, 5), (2100, 6, 2), (2800, 7, 0),
             (3700, 8, -2)]
    return Body(modes, direct=-9.0, highpass=50.0, name="cello")


def soundboard(size: float = 1.0, density: int = 140, t60: float = 0.35, seed: int = 3) -> Body:
    """Piano soundboard: a dense random set of modes (log-spaced 55 Hz..7 kHz, with a mid-range
    emphasis and a slow low-frequency rolloff), T60 from 0.5*t60 (low) down to 0.25*t60 (high).
    `size` scales all frequencies (1 grand, 1.3 small upright, 0.8 concert grand)."""
    rng = np.random.default_rng(seed)
    f = np.exp(rng.uniform(math.log(55), math.log(7000), density)) / size
    f.sort()
    q = np.clip(f * t60 * np.interp(np.log(f), [math.log(55), math.log(7000)], [0.5, 0.25]) / 2.2, 3, 60)
    g = -3.0 * np.abs(np.log2(f / 700.0)) + rng.normal(0, 2.0, density)
    return Body([(float(a), float(b), float(c)) for a, b, c in zip(f, q, g)], direct=-2.0, highpass=40.0,
                name="soundboard")


def tube_resonance(freq: float, q: float = 30.0, gain_db: float = 8.0, n: int = 1) -> Body:
    """Resonator tube under a bar (marimba/vibraphone): a resonance at `freq` (and optionally odd
    harmonics, weaker)."""
    modes = [(freq * (2 * k + 1), q * (1 + k), gain_db - 6 * k) for k in range(n)]
    return Body(modes, direct=0.0, highpass=0.0, name="tube")


def formants(freqs, qs, gains_db, direct_db: float = 0.0, name: str = "formants") -> Body:
    """Radiation/bore formants as a body: (freq, Q, gain dB) per resonance (oboe nasal formants ~1.1
    and ~3 kHz, bassoon ~500 Hz, ...)."""
    return Body(list(zip(freqs, qs, gains_db)), direct=direct_db, highpass=0.0, name=name)


# ------------------------------------------------------------------ radiation

def horn_radiation(audio: Audio, cutoff: float = 1500.0, order: int = 1, dry: float = 0.12) -> Audio:
    """A bell radiates the high frequencies and reflects the low ones: a highpass at the bell's
    cutoff (trumpet 1500-2000 Hz, trombone 900-1200, horn 500-800, tuba 300-500). `dry` keeps a
    little of the unfiltered sound (the bore also leaks through the tone holes / mouthpiece)."""
    hp = audio.highpass(cutoff, order=order)
    return audio.gain(dry).mix(hp).normalize_rms(audio.rms_db)


def off_axis(audio: Audio, angle_deg: float, radius_m: float = 0.05) -> Audio:
    """Directivity of a circular aperture (bell, tone-hole lattice, speaker-like radiator) at
    `angle_deg` from its axis: D(f) = 2 J1(ka sin t)/(ka sin t). High frequencies fall away off axis."""
    from scipy.special import j1
    x = audio.data.astype(np.float64)
    n = x.shape[0]
    nfft = 1 << int(math.ceil(math.log2(n + 1)))
    fr = np.fft.rfftfreq(nfft, 1.0 / audio.sr)
    arg = 2 * math.pi * fr / cm.C_AIR * radius_m * math.sin(math.radians(angle_deg))
    D = np.where(arg < 1e-6, 1.0, 2 * j1(arg) / np.where(arg < 1e-6, 1.0, arg))
    D = np.abs(D) * np.where(arg > 3.83, 0.5, 1.0)  # past the first null the lobes are weak
    if x.ndim == 1:
        y = np.fft.irfft(np.fft.rfft(x, nfft) * D, nfft)[:n]
    else:
        y = np.stack([np.fft.irfft(np.fft.rfft(x[:, c], nfft) * D, nfft)[:n] for c in range(2)], axis=1)
    return Audio(y, audio.sr)


def air_absorption_db_per_m(freq, temperature_c: float = 20.0, humidity: float = 50.0, pressure_kpa: float = 101.325):
    """ISO 9613-1 pure-tone attenuation in dB/m (freq in Hz, array ok)."""
    f = np.asarray(freq, dtype=np.float64)
    T = temperature_c + 273.15
    T0, T01, pr = 293.15, 273.16, 101.325
    C = -6.8346 * (T01 / T) ** 1.261 + 4.6151
    h = humidity * 10**C * (pr / pressure_kpa)
    frO = (pressure_kpa / pr) * (24 + 4.04e4 * h * (0.02 + h) / (0.391 + h))
    frN = (pressure_kpa / pr) * (T / T0) ** -0.5 * (9 + 280 * h * math.exp(-4.170 * ((T / T0) ** (-1 / 3) - 1)))
    a = 8.686 * f**2 * (1.84e-11 * (pr / pressure_kpa) * (T / T0) ** 0.5
                        + (T / T0) ** -2.5 * (0.01275 * math.exp(-2239.1 / T) / (frO + f**2 / frO)
                                              + 0.1068 * math.exp(-3352.0 / T) / (frN + f**2 / frN)))
    return a


def distance(audio: Audio, meters: float, *, reference: float = 1.0, temperature_c: float = 20.0,
             humidity: float = 50.0, delay: bool = False) -> Audio:
    """Listener at `meters` from the source: spherical spreading (gain reference/meters), air
    absorption (ISO 9613-1: 10 m at 50% RH loses ~1 dB at 4 kHz, ~4 dB at 8 kHz, ~12 dB at 16 kHz) and
    optionally the propagation delay (c = 343 m/s)."""
    if meters <= 0:
        raise ValueError("meters must be positive")
    x = audio.data.astype(np.float64)
    n = x.shape[0]
    nfft = 1 << int(math.ceil(math.log2(n + 1)))
    fr = np.fft.rfftfreq(nfft, 1.0 / audio.sr)
    att = 10 ** (-air_absorption_db_per_m(fr, temperature_c, humidity) * max(meters - reference, 0.0) / 20.0)
    g = reference / meters
    if x.ndim == 1:
        y = np.fft.irfft(np.fft.rfft(x, nfft) * att, nfft)[:n] * g
    else:
        y = np.stack([np.fft.irfft(np.fft.rfft(x[:, c], nfft) * att, nfft)[:n] for c in range(2)], axis=1) * g
    out = Audio(y, audio.sr)
    if delay:
        out = out.pad(before=meters / cm.C_AIR)
    return out
