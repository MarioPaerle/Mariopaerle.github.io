"""Physical-modelling toolkit: exciter -> resonator -> body -> radiation -> room.

    from libero import physics as ph

    ph.presets.cello().render(130.8, 0.7, 3.0)                # a whole instrument
    ph.render_note(ph.presets.piano(), ctx.note, ctx.vel, 4.0, ctx=ctx)   # inside @sound.body
    ph.pluck(220, 3.0, decay=4, inharmonicity=3e-5)           # one model, raw
    ph.room.preset("hall")                                    # stereo IR for @sound.impulse

Modules
    strings      waveguide strings: pluck, strike (hammer), bow; unisons, sympathetic strings
    winds        reed (single/double, cylindrical/conical), flute (jet), brass (lip reed)
    modal        bars, bells, glass, plates, membranes, mallets, finite-difference plates
    body         guitar/violin/cello/soundboard bodies, horn radiation, directivity, distance
    room         image-source + FDN rooms, spring and plate reverbs (IRs)
    performance  breath/bow envelopes, vibrato, humanisation, render_note, check (validate a note)
    presets      ready instruments with note-dependent physics

Everything returns `libero.Audio`, is deterministic for a given seed, and is tuned analytically or
by closed-loop correction (see each docstring). The first call of each model compiles (and caches)
its numba kernel (about 0.1-0.5 s, once per machine); a 2 s note then takes 5-300 ms. Guide: `guide('physics')`.
"""

from . import body, modal, performance, presets, room, strings, winds  # noqa: F401
from .body import Body, distance, horn_radiation, off_axis  # noqa: F401
from .modal import Mallet, Modes, bar, bell, fd_plate, membrane, plate  # noqa: F401
from .modal import strike as mallet_strike  # noqa: F401
from .performance import (Humanize, bow_stroke, breath, check, humanize, pitch_modulate, render_note,  # noqa: F401
                          vibrato)
from .presets import Instrument  # noqa: F401
from .room import plate_ir, preset as room_preset, shoebox_ir, spring_ir  # noqa: F401
from .strings import Hammer, bow, pluck  # noqa: F401
from .strings import strike as hammer_string  # noqa: F401
from .winds import brass, flute, reed  # noqa: F401

__all__ = [
    "body", "modal", "performance", "presets", "room", "strings", "winds",
    "pluck", "hammer_string", "bow", "Hammer", "reed", "flute", "brass",
    "bar", "bell", "membrane", "plate", "Modes", "Mallet", "mallet_strike", "fd_plate",
    "Body", "horn_radiation", "off_axis", "distance",
    "shoebox_ir", "room_preset", "spring_ir", "plate_ir",
    "breath", "bow_stroke", "vibrato", "pitch_modulate", "humanize", "Humanize", "render_note", "check",
    "Instrument",
]
