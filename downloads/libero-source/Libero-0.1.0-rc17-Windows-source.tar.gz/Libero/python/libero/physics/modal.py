"""Struck and modal instruments: bars, bells, glass, plates, membranes (timpani), and 2-D
finite-difference plates/membranes for special cases.

A `Modes` object is a list of (frequency, T60, gain) triples. `strike` drives it with a mallet
(contact force pulse whose duration follows from the mallet's hardness and the velocity, Hertz:
T_c ~ v^-0.2) at a position on the object (mode-shape weights), and returns an `Audio`.

Mode tables follow the literature:
    free-free bar      f_n/f_1 = 1, 2.757, 5.404, 8.933, 13.34  (Euler-Bernoulli)
    marimba bar        1 : 4 : 10 (undercut tuning), vibraphone 1 : 4 : ~10, xylophone 1 : 3 : 6
    circular membrane  Bessel zeros j_mn (ideal) or measured timpani 1 : 1.5 : 1.99 : 2.44 : 2.89
    church bell        hum 0.5, prime 1, tierce 1.19, quint 1.5, nominal 2, ... each mode split in a
                       near-degenerate pair that beats (asymmetry)
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy import signal, special

from ..audio import DEFAULT_SR, Audio
from . import _common as cm
from ._kernels import fd_plate_kernel, modal_kernel


@dataclass
class Modes:
    """Modal description: freqs Hz, t60 s (time to decay 60 dB), gains (relative), and `weights`
    (n_modes,) giving each mode's shape value at the strike point when known."""
    freqs: np.ndarray
    t60: np.ndarray
    gains: np.ndarray
    shape: object = None  # callable(position) -> weights, or None
    name: str = ""

    def __post_init__(self):
        self.freqs = np.asarray(self.freqs, dtype=np.float64)
        self.t60 = np.asarray(self.t60, dtype=np.float64)
        self.gains = np.asarray(self.gains, dtype=np.float64)
        if not (len(self.freqs) == len(self.t60) == len(self.gains)):
            raise ValueError("freqs, t60 and gains must have the same length")

    def __len__(self):
        return len(self.freqs)

    def scaled(self, pitch: float = 1.0, decay: float = 1.0) -> "Modes":
        return Modes(self.freqs * pitch, self.t60 * decay, self.gains, self.shape, self.name)

    def split_pairs(self, beat_hz: float = 1.0, seed: int = 0, spread: float = 0.6) -> "Modes":
        """Every mode becomes two near-degenerate partials `beat_hz` (x random 0.4..1.6, lower
        for higher modes' relative depth) apart, equal gain: slow beating like a real bell."""
        rng = np.random.default_rng(seed)
        d = beat_hz * (1.0 - spread + 2 * spread * rng.random(len(self.freqs)))
        f = np.concatenate([self.freqs - d / 2, self.freqs + d / 2])
        t = np.concatenate([self.t60, self.t60])
        g = np.concatenate([self.gains, self.gains]) / math.sqrt(2)
        shape = None
        if self.shape is not None:
            base = self.shape
            shape = lambda pos: np.concatenate([base(pos), base(pos)])
        return Modes(f, t, g, shape, self.name)


def decay_law(freqs, t60_ref: float, f_ref: float | None = None, exponent: float = 1.0, floor: float = 0.01):
    """T60 falling with frequency: t60 = t60_ref (f_ref/f)^exponent. Wood 1-2, metal 0.3-1, glass 0.2-0.5."""
    freqs = np.asarray(freqs, dtype=np.float64)
    f_ref = f_ref or float(freqs[0])
    return np.maximum(t60_ref * (f_ref / freqs) ** exponent, floor)


# ------------------------------------------------------------------ bars

_BETA_L = np.array([4.73004, 7.85320, 10.99561, 14.13717, 17.27876, 20.42035, 23.56194])


def _free_bar_shape(x: float, n: int) -> float:
    b = _BETA_L[n] if n < len(_BETA_L) else (n + 0.5) * math.pi
    s = (math.cosh(b) - math.cos(b)) / (math.sinh(b) - math.sin(b))
    bx = b * x
    return math.cosh(bx) + math.cos(bx) - s * (math.sinh(bx) + math.sin(bx))


_BAR_RATIOS = {
    "free": [1.0, 2.757, 5.404, 8.933, 13.34, 18.64],
    "marimba": [1.0, 4.0, 10.0, 18.6],
    "xylophone": [1.0, 3.0, 6.0, 10.4],
    "vibraphone": [1.0, 4.0, 10.0, 19.1],
    "glockenspiel": [1.0, 2.757, 5.404, 8.933, 13.34],
    "chime": [1.0, 2.757, 5.404, 8.933, 13.34],
    "kalimba": [1.0, 6.267, 17.55, 34.39],
}
# relative T60 of mode k (fraction of the fundamental's), relative gain
_BAR_DECAY = {"marimba": [1.0, 0.25, 0.08, 0.03], "xylophone": [1.0, 0.3, 0.1, 0.04],
              "vibraphone": [1.0, 0.35, 0.1, 0.05], "free": [1.0, 0.6, 0.35, 0.2, 0.12, 0.08],
              "glockenspiel": [1.0, 0.6, 0.35, 0.2, 0.12], "chime": [1.0, 0.7, 0.45, 0.3, 0.2],
              "kalimba": [1.0, 0.25, 0.06, 0.02]}
_BAR_T60 = {"marimba": (1.15, 0.5), "xylophone": (0.6, 0.5), "vibraphone": (5.0, 0.4),
            "free": (3.0, 0.4), "glockenspiel": (4.0, 0.4), "chime": (5.0, 0.4), "kalimba": (2.0, 0.6)}


def bar(freq: float, kind: str = "marimba", *, t60: float | None = None, damping_exponent: float | None = None,
        resonator: float = 0.0) -> Modes:
    """Tuned or free bar. kind: marimba | xylophone | vibraphone | glockenspiel | chime | kalimba | free.

    freq      fundamental, Hz.
    t60       T60 of the fundamental in seconds. Defaults by kind (marimba 1.15 s at A3, scaling by
              (220/f)^0.5 - low bars ring longer; vibraphone 5 s; xylophone 0.6 s).
    resonator 0..1 adds a tube resonance at the fundamental (marimba/vibraphone resonator tubes:
              longer, stronger fundamental, ~+40% T60).
    Mode shapes are the free-free beam's, so a mallet at the centre excites mainly the fundamental and
    a mallet near a node (0.22 of the length) excites the upper modes."""
    kind = kind.lower()
    if kind not in _BAR_RATIOS:
        raise ValueError(f"bar kind must be one of {sorted(_BAR_RATIOS)}")
    r = np.array(_BAR_RATIOS[kind])
    base, _ = _BAR_T60[kind]
    t1 = t60 if t60 is not None else base * (220.0 / freq) ** 0.5
    t = t1 * np.array(_BAR_DECAY[kind])
    f = freq * r
    g = np.ones(len(r)) * (1.0 / np.arange(1, len(r) + 1) ** 0.3)
    if resonator > 0:
        t = t.copy()
        t[0] *= 1 + 0.4 * resonator
        g = g.copy()
        g[0] *= 1 + 0.8 * resonator
    mode_ids = list(range(len(r)))
    shape = lambda x: np.array([_free_bar_shape(float(np.clip(x, 0.02, 0.98)), i) / _free_bar_shape(0.5 if i % 2 == 0 else 0.15, i)
                                for i in mode_ids])
    shape_fn = lambda pos: np.abs(shape(pos))
    return Modes(f, t, g, shape_fn, f"bar/{kind}")


# ------------------------------------------------------------------ bells, glass

_BELLS = {
    # ratio to the prime; t60 s at prime ~ 440 Hz equivalent; gain
    "church": [(0.5, 2.0, 0.6), (1.0, 1.0, 1.0), (1.19, 0.8, 0.7), (1.5, 0.55, 0.5), (2.0, 0.45, 0.9),
               (2.5, 0.35, 0.5), (2.67, 0.3, 0.45), (3.0, 0.25, 0.35), (4.0, 0.2, 0.3), (5.33, 0.12, 0.2),
               (6.8, 0.08, 0.15), (8.4, 0.05, 0.1)],
    "handbell": [(1.0, 1.0, 1.0), (2.4, 0.5, 0.7), (3.0, 0.45, 0.5), (4.1, 0.3, 0.45), (5.9, 0.15, 0.3),
                 (7.6, 0.1, 0.2), (9.8, 0.06, 0.15)],
    "tubular": [(1.0, 1.0, 1.0), (2.76, 0.7, 0.55), (5.40, 0.45, 0.35), (8.93, 0.3, 0.25), (13.34, 0.2, 0.15)],
    "glass": [(1.0, 1.0, 1.0), (2.32, 0.6, 0.42), (4.25, 0.35, 0.22), (6.63, 0.2, 0.12), (9.38, 0.12, 0.07),
              (12.6, 0.08, 0.04)],
    "gong": [(1.0, 1.0, 1.0), (1.3, 0.9, 0.7), (1.72, 0.8, 0.8), (2.11, 0.7, 0.6), (2.6, 0.6, 0.6),
             (3.1, 0.5, 0.5), (3.9, 0.4, 0.4), (4.7, 0.35, 0.35), (5.6, 0.3, 0.3), (7.3, 0.2, 0.2)],
}


def bell(freq: float, kind: str = "church", *, t60: float | None = None, beat_hz: float = 1.2, seed: int = 0,
         ref: str = "prime") -> Modes:
    """Bell-like object; `freq` is the prime (the pitch heard as the strike note) and, for 'church',
    the hum sits an octave below. kind: church | handbell | tubular | glass | gong.

    t60      T60 of the prime, s. Defaults: church 12 (scaled by (440/f)^0.5), handbell 4, tubular 6,
             glass 8, gong 10. Upper modes decay faster by the table.
    beat_hz  near-degenerate pair splitting (0 disables): 0.5-3 Hz is typical; heavier bells beat slower.
    ref      which partial `freq` names: 'prime' (default, the strike note) or 'hum' (church: the octave below;
             `analysis.features` reports the hum as f0 for church bells).
    Partial ratios carry +-0.1% manufacturing scatter from `seed`."""
    kind = kind.lower()
    if ref not in ("prime", "hum"):
        raise ValueError("ref must be 'prime' or 'hum'")
    if ref == "hum":
        freq = freq * 2.0
    if kind not in _BELLS:
        raise ValueError(f"bell kind must be one of {sorted(_BELLS)}")
    base = {"church": 12.0, "handbell": 4.0, "tubular": 6.0, "glass": 8.0, "gong": 10.0}[kind]
    t1 = t60 if t60 is not None else base * (440.0 / freq) ** 0.5
    rng = np.random.default_rng(seed)
    tab = np.array(_BELLS[kind])
    f = freq * tab[:, 0] * (1 + 0.001 * rng.standard_normal(len(tab)))
    m = Modes(f, t1 * tab[:, 1], tab[:, 2], None, f"bell/{kind}")
    return m.split_pairs(beat_hz, seed) if beat_hz > 0 else m


# ------------------------------------------------------------------ plates and membranes

def plate(freq: float, aspect: float = 1.0, *, t60: float = 3.0, n_modes: int = 24, damping_exponent: float = 0.6,
          strike: tuple[float, float] = (0.3, 0.37), seed: int = 0) -> Modes:
    """Rectangular simply-supported plate (thin steel sheet, cymbal-ish, thunder sheet).

    freq    frequency of the lowest (1,1) mode; f_mn = freq (m^2 + (n aspect)^2) / (1 + aspect^2),
            with aspect = width/height > 0. Modes are dense and inharmonic; `t60` is for the lowest,
            higher modes decay as f^-damping_exponent."""
    f11 = 1.0 + aspect**2
    ms = [(m, n) for m in range(1, 9) for n in range(1, 9)]
    ms.sort(key=lambda mn: mn[0] ** 2 + (mn[1] * aspect) ** 2)
    ms = ms[:n_modes]
    f = np.array([freq * (m**2 + (n * aspect) ** 2) / f11 for m, n in ms])
    t = decay_law(f, t60, freq, damping_exponent)
    g = 1.0 / np.sqrt(np.arange(1, len(f) + 1))

    def shape(pos):
        x, y = pos
        return np.array([abs(math.sin(m * math.pi * x) * math.sin(n * math.pi * y)) for m, n in ms]) * 1.5

    return Modes(f, t, g, shape, "plate")


def membrane(freq: float, kind: str = "timpani", *, t60: float = 2.5, air_loading: float = 1.0, n_modes: int = 14,
             damping_exponent: float = 0.8, strike_radius: float = 0.5) -> Modes:
    """Circular membrane. `freq` is the frequency of the (1,1) mode, the pitch that is heard.

    kind 'ideal'   Bessel zeros: (0,1) 0.63, (1,1) 1, (2,1) 1.34, (0,2) 1.44, (3,1) 1.67, (1,2) 1.83 ...
                   an inharmonic drum (tom, snare batter).
    kind 'timpani' air loading and the kettle shift the modes towards the measured timpani set
                   (1,1) : (2,1) : (3,1) : (4,1) : (5,1) = 1 : 1.5 : 1.99 : 2.44 : 2.89, which is why a
                   timpani sounds pitched; `air_loading` 0..1 blends ideal -> measured. The (0,1)
                   'thump' sits near 0.85 of the pitch and decays fast.
    Mode shapes are J_m(j_mn r) cos(m theta): striking at the centre excites only m = 0; at about
    `strike_radius` = 0.5..0.75 of the radius the pitched modes speak."""
    zeros = []
    for m in range(0, 8):
        for n, z in enumerate(special.jn_zeros(m, 4), start=1):
            zeros.append((z, m, n))
    zeros.sort()
    zeros = zeros[:n_modes]
    ratios = np.array([z / 3.8317 for z, m, n in zeros])  # relative to (1,1)
    order = [(m, n) for z, m, n in zeros]
    if kind == "timpani":
        meas = {(1, 1): 1.0, (2, 1): 1.50, (3, 1): 1.99, (4, 1): 2.44, (5, 1): 2.89, (6, 1): 3.34,
                (0, 1): 0.85, (1, 2): 2.29, (2, 2): 2.83, (0, 2): 1.83}
        for i, mn in enumerate(order):
            if mn in meas:
                ratios[i] = (1 - air_loading) * ratios[i] + air_loading * meas[mn]
    elif kind != "ideal":
        raise ValueError("membrane kind must be 'timpani' or 'ideal'")
    f = freq * ratios
    t = decay_law(f, t60, freq, damping_exponent)
    for i, mn in enumerate(order):
        if mn == (0, 1):
            t[i] *= 0.25
    g = np.ones(len(f))

    def shape(pos):
        r, th = pos if isinstance(pos, (tuple, list)) else (pos, 0.0)
        return np.array([abs(special.jv(m, z * float(np.clip(r, 0, 1))) * math.cos(m * th))
                         for z, m, n in zeros]) / 0.5

    m = Modes(f, t, g, shape, f"membrane/{kind}")
    m._default_pos = strike_radius
    return m


# ------------------------------------------------------------------ mallets and rendering

@dataclass
class Mallet:
    """Contact model. hardness 0 (yarn, soft felt: 6-12 ms contact, dark) .. 1 (steel, hard plastic:
    0.2-0.5 ms, bright). Contact time shortens with velocity as v^-0.2 (Hertz). `mass` only scales
    how strongly a heavy mallet lingers (extends contact up to 30%)."""
    hardness: float = 0.5
    mass: float = 0.05

    def contact_time(self, velocity: float) -> float:
        t = 0.0002 * (60.0 ** (1.0 - self.hardness))
        t *= (max(velocity, 0.05) / 0.6) ** -0.2
        t *= 1.0 + 0.3 * min(self.mass / 0.1, 1.0)
        return float(np.clip(t, 1e-4, 0.03))

    def pulse(self, velocity: float, sr: int) -> np.ndarray:
        Tc = self.contact_time(velocity)
        n = max(3, int(round(Tc * sr)))
        x = np.sin(np.linspace(0, math.pi, n)) ** 1.5
        return x * velocity


def strike(modes: Modes, dur: float = 3.0, *, velocity: float = 0.7, mallet: Mallet | None = None,
           position=None, excitation: Audio | np.ndarray | None = None, pitch_glide_cents: float = 0.0,
           glide_tau: float = 0.12, sr: int = DEFAULT_SR, seed: int = 0, peak_db: float | None = -6.0) -> Audio:
    """Render `modes` struck by a mallet.

    velocity   0..1. Louder = shorter contact = brighter (Hertz), plus more level.
    mallet     `Mallet(hardness, mass)`; default mid-hard.
    position   where it is struck: bars x in 0..1 along the length (0.5 centre: only the fundamental;
               0.22 near the first node: upper modes speak), plates (x, y) in 0..1, membranes radius
               0..1 from the centre (or (r, theta)). None = the object's natural spot.
    excitation an `Audio`/array used instead of the mallet pulse (e.g. a recorded stick hit).
    pitch_glide_cents  initial sharpness decaying with `glide_tau` seconds (tension modulation of
               timpani/tom: ~20-40 cents on strong hits).
    Output peak normalised to `peak_db`."""
    n = int(round(dur * sr))
    mal = mallet or Mallet()
    v = cm.velocity01(velocity)
    g = modes.gains.copy()
    if modes.shape is not None:
        pos = position
        if pos is None:
            pos = getattr(modes, "_default_pos", None)
            if pos is None:
                pos = 0.3 if modes.name.startswith("bar") else (0.3, 0.37)
        if modes.name.startswith("membrane") and not isinstance(pos, (tuple, list)):
            pos = (float(pos), 0.0)
        w = np.asarray(modes.shape(pos))
        g = g * (w / (np.max(w) + 1e-12)) ** 1.0
    if excitation is None:
        exc = mal.pulse(v, sr)
    else:
        exc = np.asarray(excitation.resample(sr).to_mono().data if isinstance(excitation, Audio) else excitation,
                         dtype=np.float64)
    y = modal_kernel(n, modes.freqs, modes.t60, g, np.ascontiguousarray(exc), float(sr))
    if pitch_glide_cents:
        y = _glide(y, sr, pitch_glide_cents * (0.4 + 0.6 * v), glide_tau)
    return cm.finish(y, sr, peak_db)


def _glide(y: np.ndarray, sr: int, cents: float, tau: float) -> np.ndarray:
    """Time-warp so that the pitch starts `cents` sharp and relaxes exponentially."""
    n = len(y)
    t = np.arange(n) / sr
    ratio = 2.0 ** ((cents / 1200.0) * np.exp(-t / tau))
    pos = np.cumsum(ratio) - ratio[0]
    pos = np.clip(pos, 0, n - 1)
    return np.interp(pos, np.arange(n), y)


# ------------------------------------------------------------------ finite-difference plates

def fd_plate(freq: float, dur: float = 3.0, *, model: str = "plate", aspect: float = 1.3, t60: float = 3.0,
             t60_hf: float | None = None, stiffness_ratio: float = 0.0, clamped: bool = False,
             strike: tuple[float, float] = (0.3, 0.4), pickups=((0.65, 0.55),), hardness: float = 0.6,
             velocity: float = 0.7, min_grid: int = 20, sr: int = DEFAULT_SR, seed: int = 0,
             peak_db: float | None = -6.0) -> Audio:
    """2-D finite-difference plate or membrane (rectangle, fixed/simply supported edges).

    model      'plate' (Kirchhoff bending: gong/sheet/cymbal-like, dispersive, modes ~ m^2+n^2),
               'membrane' (tension only: drum skin, modes ~ sqrt(m^2+n^2)) or 'stiff_membrane'
               (both; `stiffness_ratio` 0..1 = share of the lowest mode due to bending).
    freq       frequency of the lowest (1,1) mode in Hz.
    aspect     width/height of the rectangle.
    t60        T60 of the lowest mode; t60_hf the T60 at 8x that frequency (default t60/4):
               higher modes lose energy faster (frequency-dependent damping).
    strike, pickups  positions as fractions of the width/height. Several pickups give a multichannel
               result; `fd_plate` returns the first (mono) - use `plate_reverb` for stereo.
    min_grid   minimum grid points on the short side. The scheme is run at the stability limit
               (CFL-checked: h^2 >= c^2 k^2 + sqrt(c^4 k^4 + 16 kappa^2 k^2)); if that grid is too coarse the
               simulation is oversampled by an integer factor and decimated. Modes above about
               1/4 of the grid's Nyquist are numerically dispersed.
    Cost ~ grid cells x steps; typical 1-3 s."""
    res = _fd_run(freq, dur, model, aspect, t60, t60_hf, stiffness_ratio, clamped, strike, pickups, hardness,
                  velocity, min_grid, sr)
    return cm.finish(res[0], sr, peak_db)


def _fd_params(freq, model, aspect, stiffness_ratio):
    """Return (kappa, c) for a unit-width plate whose (1,1) mode is at `freq`."""
    w1 = 2 * math.pi * freq
    geo = math.pi**2 * (1.0 + aspect**2)  # xi_11 (wavenumber squared) for Lx = 1, Ly = 1/aspect
    if model == "plate":
        return w1 / geo, 0.0
    if model == "membrane":
        return 0.0, w1 / math.sqrt(geo)
    if model == "stiff_membrane":
        b = float(np.clip(stiffness_ratio, 0.0, 1.0))
        # w^2 = kappa^2 xi^2 + c^2 xi ; share b of w^2 from bending
        return math.sqrt(b) * w1 / geo, math.sqrt(1.0 - b) * w1 / math.sqrt(geo)
    raise ValueError("model must be 'plate', 'membrane' or 'stiff_membrane'")


def _fd_run(freq, dur, model, aspect, t60, t60_hf, stiffness_ratio, clamped, strike, pickups, hardness, velocity,
            min_grid, sr, impulse=False, in_pos=None, loss_ref=None):
    if freq <= 0 or aspect <= 0:
        raise ValueError("freq and aspect must be positive")
    Lx = 1.0
    t60_hf = t60_hf or t60 / 4.0
    over = 1
    while True:
        k = 1.0 / (sr * over)
        nx = 400
        while nx > 4:
            # integer grid; the rectangle's aspect becomes nx/ny exactly, the lowest mode stays at `freq`
            ny = max(int(round(nx / aspect)), 4)
            asp = nx / ny
            kappa, c = _fd_params(freq, model, asp, stiffness_ratio)
            h = Lx / nx

            def xi(f):
                w = 2 * math.pi * f
                if kappa > 0 and c > 0:
                    return (-c * c + math.sqrt(c**4 + 4 * kappa**2 * w * w)) / (2 * kappa**2)
                return w / kappa if kappa > 0 else w * w / (c * c)
            fa, fb = loss_ref if loss_ref else (freq, 8 * freq)
            x1, x2 = xi(fa), xi(fb)
            s1, s2 = 6.91 / t60, 6.91 / t60_hf
            sigma1 = max((s2 - s1) / (x2 - x1), 0.0)
            sigma0 = max(s1 - sigma1 * x1, 0.0)
            a_ = c * c * k * k + 4 * sigma1 * k
            if 16 * kappa**2 * k * k / h**4 + 2 * a_ / h**2 <= 0.98:
                break
            nx -= 1
        if min(nx, ny) >= min_grid or over >= 64:
            break
        over *= 2
    if nx <= 4:
        raise ValueError("no stable grid: check freq/aspect")
    n = int(round(dur * sr * over))
    if nx * ny * n > 2.5e10:
        raise ValueError("finite-difference plate too expensive: lower freq, dur or min_grid")
    v = cm.velocity01(velocity)
    Tc = Mallet(hardness).contact_time(v)
    m = max(3, int(Tc * sr * over))
    exc = np.sin(np.linspace(0, math.pi, m)) ** 2 * v
    if impulse:
        exc = np.zeros(1)
        exc[0] = 1.0
    sp = in_pos if in_pos is not None else strike
    ex = int(np.clip(round(sp[0] * nx), 1, nx - 1))
    ey = int(np.clip(round(sp[1] * ny), 1, ny - 1))
    outs = np.array([[int(np.clip(round(p[0] * nx), 1, nx - 1)), int(np.clip(round(p[1] * ny), 1, ny - 1))]
                     for p in pickups], dtype=np.float64)
    res = fd_plate_kernel(n, nx, ny, k, h, kappa, c, sigma0, sigma1, exc, ex, ey, outs, bool(clamped))
    if not np.all(np.isfinite(res)):
        raise FloatingPointError("finite-difference scheme diverged")
    if over > 1:
        res = signal.resample_poly(res, 1, over, axis=1)
    want = int(round(dur * sr))
    res = res[:, :want]
    # displacement -> velocity-like (bridge force) for a livelier, less bass-heavy sound
    return np.diff(res, axis=1, prepend=0.0)
