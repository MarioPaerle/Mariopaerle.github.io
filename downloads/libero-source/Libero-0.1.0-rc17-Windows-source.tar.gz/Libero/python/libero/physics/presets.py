"""Ready-made instruments: exciter + resonator + body + radiation (+ room) with note-dependent
physical parameters. Every preset is an `Instrument`:

    inst = presets.cello()
    audio = inst.render(freq=130.8, velocity=0.7, dur=3.0, sr=48000, seed=1)
    audio = inst.with_(decay=3.0, pressure=0.7).render(...)       # change model parameters
    audio = inst.through(room=room.preset("hall"), room_mix=0.25).render(...)
    # in a recipe:  ph.render_note(inst, ctx.note, ctx.vel, 3.0, ctx=ctx)

Velocity is 0..1 and drives the physics (hammer speed, bow speed, blowing pressure, mallet speed),
so louder notes are also brighter, as on the real instrument. Output peaks are normalised
(`peak_db`, default -6 dB): set loudness in the recipe (`normalize_loudness`).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Callable

import numpy as np

from .. import dsp
from ..audio import DEFAULT_SR, Audio
from . import _common as cm
from . import body as bodymod
from . import modal, performance as perf, strings, winds


@dataclass(frozen=True)
class Instrument:
    """A model (`fn`) with default parameters, an optional body, radiation filters, distance and room."""
    name: str
    fn: Callable
    params: dict = field(default_factory=dict)
    body: object = None
    body_mix: float = 1.0
    radiation: tuple = ()
    distance_m: float | None = None
    room: object = None  # Audio impulse response
    room_mix: float = 0.25
    note_range: tuple = (21, 108)
    retune: bool = True  # final +-50 cent correction so `analysis.features` reads the note (pitched instruments)

    def with_(self, **params) -> "Instrument":
        """Copy with model parameters changed (see the model function's docstring)."""
        return replace(self, params={**self.params, **params})

    def through(self, *, body="keep", body_mix=None, radiation=None, distance_m="keep", room="keep",
                room_mix=None) -> "Instrument":
        """Copy with a different body (`physics.body.Body` or None), radiation callables (Audio -> Audio),
        distance (m) or room impulse response (Audio) and its dry/wet mix."""
        return replace(
            self,
            body=self.body if body == "keep" else body,
            body_mix=self.body_mix if body_mix is None else body_mix,
            radiation=self.radiation if radiation is None else tuple(radiation),
            distance_m=self.distance_m if distance_m == "keep" else distance_m,
            room=self.room if room == "keep" else room,
            room_mix=self.room_mix if room_mix is None else room_mix,
        )

    def render(self, freq: float, velocity: float = 0.7, dur: float = 2.0, sr: int = DEFAULT_SR, seed: int = 0,
               peak_db: float | None = -6.0, retune: bool = True, **over) -> Audio:
        freq = cm.freq_of(freq)
        v = cm.velocity01(velocity)
        p = {**self.params, **over}
        a = self.fn(freq, v, dur, sr, seed, **p)
        if self.body is not None and self.body_mix > 0:
            a = self.body.apply(a, self.body_mix, seed=seed)
        for r in self.radiation:
            a = r(a)
        if self.distance_m:
            a = bodymod.distance(a, self.distance_m)
        if self.room is not None and self.room_mix > 0:
            a = a.convolve(self.room, mix=self.room_mix)
        if self.retune and retune and freq < 3000.0:
            m = cm.analysis_f0(a)
            if np.isfinite(m):
                err = 1200.0 * math.log2(m / freq)
                if 1.0 < abs(err) <= 50.0:
                    a = a.pitch(-err / 100.0)
        return cm.finish(a.data.astype(np.float64), sr, peak_db)


def _reg(freq: float, lo: float, hi: float) -> float:
    return float(np.clip(math.log2(freq / lo) / math.log2(hi / lo), 0.0, 1.0))


def _interp(note: float, pts) -> float:
    xs, ys = zip(*pts)
    return float(np.interp(note, xs, ys))


def _click(sr: int, ms: float, fc: float, level_db: float, seed: int, n: int) -> np.ndarray:
    """Short band-limited noise burst (pick, finger, key or hammer noise)."""
    rng = np.random.default_rng(seed + 101)
    k = max(8, int(ms * 1e-3 * sr))
    x = rng.standard_normal(k) * np.exp(-np.arange(k) / (0.3 * k))
    from scipy import signal
    sos = signal.butter(2, [max(fc * 0.5, 50), min(fc * 1.6, 0.45 * sr)], "bandpass", fs=sr, output="sos")
    x = signal.sosfilt(sos, x)
    x = x / (np.abs(x).max() + 1e-12) * dsp.undb(level_db)
    out = np.zeros(n)
    out[: min(n, k)] = x[:n]
    return out


def _tail_dur(dur: float, extra: float = 0.0) -> float:
    return dur + extra


# ------------------------------------------------------------------ plucked strings

def _guitar(f, v, dur, sr, seed, *, kind="classical", decay=None, click_db=-34.0, **kw):
    r = _reg(f, 82.4, 700.0)
    steel = kind == "steel"
    p = dict(
        decay=(decay if decay is not None else (5.0 if steel else 3.6) * (1.0 - 0.65 * r)),
        decay_hf=(0.3 if steel else 0.14) * (0.75 + 0.5 * v),
        inharmonicity=(1.6e-5 if steel else 1.0e-5) * (1 + 6 * r),
        position=0.16 if steel else 0.19,
        hardness=(0.85 if steel else 0.38 + 0.3 * v),
        velocity=v,
    )
    p.update(kw)
    a = strings.pluck(f, dur, sr=sr, seed=seed, peak_db=None, **p)
    x = a.data.astype(np.float64)
    x = x / (np.abs(x).max() + 1e-12)
    x = x + _click(sr, 6.0 if steel else 9.0, 3000.0 if steel else 1800.0, click_db + 10 * (v - 0.5), seed, len(x))
    return Audio(x, sr)


def guitar(kind: str = "classical") -> Instrument:
    """Guitar. kind 'classical' (nylon: darker, finger-plucked, rounded) or 'steel' (plectrum, brighter,
    longer). Decay shortens up the neck; body = guitar top/air modes. Parameters: decay, decay_hf,
    inharmonicity, position, hardness, click_db. Range E2-B5."""
    return Instrument(f"guitar/{kind}", _guitar, {"kind": kind}, bodymod.guitar(kind), 1.0, note_range=(40, 88))


# ------------------------------------------------------------------ piano

_B_TABLE = [(21, 2.5e-4), (36, 1.6e-4), (48, 1.2e-4), (60, 3.0e-4), (72, 8.0e-4), (84, 3.2e-3), (96, 1.0e-2), (108, 2.5e-2)]


def piano_inharmonicity(note: float) -> float:
    """Typical piano B(note): ~1.2e-4 around C3, rising to 3e-4 at C4, 1e-2 at C7 and 2.5e-2 at C8; slightly
    higher again in the shortest bass strings (log interpolation of measured ranges)."""
    xs, ys = zip(*_B_TABLE)
    return float(math.exp(np.interp(note, xs, np.log(ys))))


def _piano(f, v, dur, sr, seed, *, pedal=False, tune_to_analysis=True, decay=None, strings_n=None, **kw):
    n = 69 + 12 * math.log2(f / 440.0)
    ns = strings_n or (1 if n < 33 else 2 if n < 46 else 3)
    hm = _interp(n, [(21, 0.0058), (36, 0.0049), (60, 0.0030), (96, 0.0022), (108, 0.0020)])
    pexp = _interp(n, [(21, 2.2), (36, 2.3), (60, 2.6), (96, 3.0), (108, 3.2)])
    F0 = _interp(n, [(21, 8.0), (36, 10.0), (60, 15.0), (96, 22.0), (108, 25.0)])  # N at 0.5 mm compression
    K = F0 / 0.0005**pexp
    Z = math.exp(_interp(n, [(21, math.log(8.0)), (36, math.log(5.0)), (60, math.log(1.6)), (96, math.log(0.55)), (108, math.log(0.4))]))
    t60 = decay if decay is not None else float(np.clip(16.0 * math.exp(-(n - 60) / 28.0), 1.2, 40.0))
    p = dict(
        hammer=strings.Hammer(hm, K, pexp, 1.0, 1.0, Z),
        velocity=v, decay=t60, decay_hf=0.22 + 0.1 * v, inharmonicity=piano_inharmonicity(n),
        position=_interp(n, [(21, 0.125), (60, 0.118), (108, 0.095)]), strings=ns,
        detune_cents=0.35 + 0.7 * (1 - abs(n - 66) / 50.0), bridge_t60=0.2 * t60 + 0.3,
    )
    if pedal:
        p["sympathetic"] = [f * k for k in (0.5, 1.5, 2.0, 3.0, 4.0) if f * k < 4500]
        p["sympathetic_t60"] = 8.0
    p.update(kw)
    fm = f
    for _ in range(3 if tune_to_analysis and f < 3000 else 1):
        a = strings.strike(fm, dur, sr=sr, seed=seed, peak_db=None, **p)
        if not (tune_to_analysis and f < 3000):
            break
        m = cm.analysis_f0(a)
        if not np.isfinite(m) or abs(1200 * math.log2(m / f)) < 1.0:
            break
        fm *= f / m
    x = a.data.astype(np.float64)
    x = x / (np.abs(x).max() + 1e-12)
    x = x + _click(sr, 14.0, 250.0 + 12 * max(n - 21, 0), -30.0 + 10 * (v - 0.5), seed, len(x))
    return Audio(x, sr)


def piano(pedal: bool = False) -> Instrument:
    """Grand piano: per-note felt hammer (mass, stiffness, exponent), string impedance, inharmonicity
    B(note), 1/2/3 coupled strings with slight detuning and bridge coupling (prompt sound + aftersound,
    beating), T60 falling from 40 s (A0) to 2 s (C8), strike point ~1/8, soundboard body, hammer/key
    thump. pedal=True adds undamped sympathetic strings (octave, fifth, ...). Range A0-C8.
    Tuning: a piano's partials are stretched (f_k = k f sqrt(1 + B k^2)), so the pitch heard is a little
    above the lowest partial; by default the fundamental is lowered until the pitch estimator of
    `analysis.features` reads the note's frequency (tune_to_analysis=False keeps partial 1 exactly on it).
    Parameters: decay, decay_hf, inharmonicity, bridge_t60, detune_cents, position, hammer (Hammer)."""
    return Instrument("piano", _piano, {"pedal": pedal}, bodymod.soundboard(), 0.85, note_range=(21, 108), retune=True)


# ------------------------------------------------------------------ bowed strings

def _bowed(f, v, dur, sr, seed, *, pos=0.1, decay=1.5, dhf=0.15, vib=True, vib_rate=5.6, vib_cents=16.0,
           pressure=None, speed=None, attack=None, B=5e-5, noise=0.3, **kw):
    sp, pr = perf.bow_stroke(dur + 0.1, speed if speed is not None else 0.10 + 0.32 * v,
                             pressure if pressure is not None else 0.55 + 0.1 * v,
                             attack=attack if attack is not None else 0.11 - 0.05 * v, release=0.12, sr=sr, seed=seed)
    a = strings.bow(f, dur + 0.1, speed=sp, pressure=pr, position=pos, decay=decay, decay_hf=dhf, inharmonicity=B,
                    noise=noise, sr=sr, seed=seed, peak_db=None, **kw)
    if vib and vib_cents > 0:
        a = perf.pitch_modulate(a, perf.vibrato(a.duration, vib_rate, vib_cents, sr=sr, seed=seed))
    return a


def cello(vibrato: bool = True) -> Instrument:
    """Cello (C2-C5): friction-bowed string (Helmholtz motion), Schelleng-window pressure, bow-stroke
    envelope, vibrato, cello body. Parameters: speed, pressure, pos (bow-bridge distance), decay, dhf,
    vib_rate, vib_cents, noise, attack."""
    return Instrument("cello", _bowed, {"pos": 0.11, "decay": 2.0, "dhf": 0.14, "vib": vibrato},
                      bodymod.cello(), 1.0, note_range=(36, 72))


def violin(vibrato: bool = True) -> Instrument:
    """Violin (G3-E7): bowed string with a violin body (A0/B1 modes and bridge hill)."""
    return Instrument("violin", _bowed, {"pos": 0.09, "decay": 1.2, "dhf": 0.18, "vib": vibrato, "vib_cents": 20.0,
                                         "vib_rate": 6.0, "B": 4e-5},
                      bodymod.violin(), 1.0, note_range=(55, 100))


# ------------------------------------------------------------------ winds

def _envelope(dur, peak, v, sr, seed, *, attack=None, tremor=0.02, overshoot=0.06, release=0.12, swell=0.0):
    return perf.breath(dur, peak, attack=attack if attack is not None else 0.05 + 0.05 * (1 - v), release=release,
                       overshoot=overshoot, tremor=tremor, swell=swell, sr=sr, seed=seed)


def _clarinet(f, v, dur, sr, seed, *, peak=None, attack=None, vib=False, **kw):
    g = peak if peak is not None else 0.47 + 0.2 * v
    env = _envelope(dur, g, v, sr, seed, attack=attack)
    a = winds.reed(f, dur, pressure=env, bore="cylindrical", zeta=0.4 + 0.1 * v, stiffness=0.55, loss=0.02,
                   cutoff=2200.0, noise=0.25, sr=sr, seed=seed, peak_db=None, **kw)
    return a


def clarinet() -> Instrument:
    """Bb/C clarinet: single reed on a cylindrical bore (odd harmonics, 12th overblow), breath noise.
    Velocity -> mouth pressure 0.47..0.67. Range D3-C7. Parameters: peak (pressure), zeta, stiffness,
    cutoff, noise, attack."""
    return Instrument("clarinet", _clarinet, {}, None, 0.0, note_range=(50, 96))


def _oboe(f, v, dur, sr, seed, *, peak=None, attack=None, vib=True, **kw):
    g = peak if peak is not None else 0.66 + 0.16 * v
    env = _envelope(dur, g, v, sr, seed, attack=attack, tremor=0.03)
    t = float(np.clip((f - 233.0) / 207.0, 0.0, 1.0))  # brighter up the range: low notes keep their fundamental
    a = winds.reed(f, dur, pressure=env, bore="conical", zeta=0.75, stiffness=0.8, min_opening=0.1, loss=0.03,
                   noise=0.15, edge=0.55 + 0.45 * t, sr=sr, seed=seed, peak_db=None, **kw)
    a = a.highshelf(800, 7.0 + 5.0 * t, 0.7).peak(1250, 5.0, 1.8)
    if vib:
        a = perf.pitch_modulate(a, perf.vibrato(a.duration, 5.4, 9.0, onset=0.4, sr=sr, seed=seed))
    return a


def _sax_radiation(a: Audio) -> Audio:
    return a.highshelf(700, 4.0, 0.7).peak(900, 2.0, 1.5)


def oboe() -> Instrument:
    """Oboe: double reed (channel never seals: min_opening 0.1) on a conical bore, reed edge brightening,
    a high shelf and a nasal peak (~1.25 kHz) as the radiation, light vibrato. Range Bb3-A6. Parameters: peak, zeta,
    min_opening, apex, noise."""
    return Instrument("oboe", _oboe, {}, None, 0.0, note_range=(58, 93))


def _sax(f, v, dur, sr, seed, *, peak=None, attack=None, vib=False, **kw):
    g = peak if peak is not None else 0.6 + 0.2 * v
    env = _envelope(dur, g, v, sr, seed, attack=attack, tremor=0.03)
    return winds.reed(f, dur, pressure=env, bore="conical", zeta=0.6, stiffness=0.5, loss=0.03, apex=0.28, noise=0.35, edge=0.5,
                      sr=sr, seed=seed, peak_db=None, **kw)


def saxophone() -> Instrument:
    """Alto/tenor-like saxophone: single reed on a conical bore; softer and rounder than the oboe."""
    return Instrument("saxophone", _sax, {}, None, 0.0, radiation=(_sax_radiation,), note_range=(46, 85))


def _flute(f, v, dur, sr, seed, *, peak=None, attack=None, vib=True, **kw):
    g = peak if peak is not None else 0.92 + 0.14 * v
    env = _envelope(dur, g, v, sr, seed, attack=attack if attack is not None else 0.08 + 0.05 * (1 - v), tremor=0.012,
                    overshoot=0.03)
    a = winds.flute(f, dur, pressure=env, noise=0.55, sr=sr, seed=seed, peak_db=None, **kw)
    if vib:
        a = perf.pitch_modulate(a, perf.vibrato(a.duration, 5.0, 8.0, onset=0.5, sr=sr, seed=seed))
    return a


def flute() -> Instrument:
    """Concert flute: air jet + bore, breath noise, chiff at the attack. Range C4-C7. Parameters: peak
    (breath), jet_ratio (None = auto), noise, cutoff, attack."""
    return Instrument("flute", _flute, {}, None, 0.0, note_range=(60, 96))


def _brass(f, v, dur, sr, seed, *, pedal=116.5, cutoff=1800.0, peak=None, attack=None, vib=False, **kw):
    g = peak if peak is not None else 0.56 + 0.3 * v
    env = _envelope(dur, g, v, sr, seed, attack=attack if attack is not None else 0.03 + 0.04 * (1 - v), tremor=0.02,
                    overshoot=0.35)
    a = winds.brass(f, dur, pressure=env, pedal=pedal, cutoff=cutoff, brassiness=0.05 + 0.85 * v**1.5, noise=0.2,
                    sr=sr, seed=seed, peak_db=None, **kw)
    return bodymod.horn_radiation(a, cutoff * 0.8, dry=0.25)


def trumpet() -> Instrument:
    """Bb trumpet: lip-reed valve on a harmonic bore (pedal 116.5 Hz), bell radiation, brassiness that
    grows with dynamic (nonlinear steepening: pp is mellow, ff blares). Range E3-C6."""
    return Instrument("trumpet", _brass, {"pedal": 116.5, "cutoff": 1800.0}, None, 0.0, note_range=(52, 84))


def trombone() -> Instrument:
    """Bb tenor trombone (pedal 58.3 Hz, darker bell cutoff ~1 kHz). Range E2-C5."""
    return Instrument("trombone", _brass, {"pedal": 58.3, "cutoff": 1000.0}, None, 0.0, note_range=(40, 72))


def horn() -> Instrument:
    """French horn in F (pedal 43.65 Hz, bell cutoff ~700 Hz, mellow). Range F2-F5."""
    return Instrument("horn", _brass, {"pedal": 43.65, "cutoff": 700.0}, None, 0.0, note_range=(41, 77))


# ------------------------------------------------------------------ struck

def _bar(f, v, dur, sr, seed, *, kind="marimba", hardness=None, position=0.3, resonator=0.8, t60=None, **kw):
    m = modal.bar(f, kind, t60=t60, resonator=resonator)
    hard = hardness if hardness is not None else {"marimba": 0.35, "xylophone": 0.8, "vibraphone": 0.5,
                                                   "glockenspiel": 0.95, "chime": 0.6, "kalimba": 0.6}[kind] + 0.2 * (v - 0.5)
    a = modal.strike(m, dur, velocity=v, mallet=modal.Mallet(float(np.clip(hard, 0, 1)), 0.05), position=position,
                     sr=sr, seed=seed, peak_db=None, **kw)
    x = a.data.astype(np.float64)
    x = x / (np.abs(x).max() + 1e-12)
    fc = {"marimba": 2200.0, "xylophone": 3500.0, "vibraphone": 3000.0, "glockenspiel": 6000.0}.get(kind, 2500.0)
    x = x + _click(sr, 5.0, fc, -30.0 + 16.0 * (hard - 0.5) + 10.0 * (v - 0.5), seed, len(x))
    return Audio(x, sr)


def marimba() -> Instrument:
    """Rosewood marimba bar tuned 1 : 4 : 10 (undercut), resonator tube. Velocity -> mallet speed
    (harder hits: shorter contact, brighter). Range C2-C7. Parameters: hardness, position (0.5 centre = pure
    fundamental, 0.22 = bright), resonator, t60."""
    return Instrument("marimba", _bar, {"kind": "marimba"}, None, 0.0, note_range=(45, 96))


def xylophone() -> Instrument:
    """Xylophone bar tuned 1 : 3 : 6, hard mallet, short."""
    return Instrument("xylophone", _bar, {"kind": "xylophone", "resonator": 0.3}, None, 0.0, note_range=(65, 108), retune=False)


def vibraphone() -> Instrument:
    """Aluminium vibraphone bar 1 : 4 : 10, long ring (motor off), resonator tubes."""
    return Instrument("vibraphone", _bar, {"kind": "vibraphone"}, None, 0.0, note_range=(53, 89))


def glockenspiel() -> Instrument:
    """Steel glockenspiel bar (untuned free-free ratios 1 : 2.76 : 5.4), hard mallet."""
    return Instrument("glockenspiel", _bar, {"kind": "glockenspiel", "resonator": 0.0}, None, 0.0, note_range=(79, 108), retune=False)


def _bell(f, v, dur, sr, seed, *, kind="church", hardness=0.8, t60=None, beat_hz=1.2, ref="prime", **kw):
    m = modal.bell(f, kind, t60=t60, beat_hz=beat_hz, seed=seed, ref=ref)
    a = modal.strike(m, dur, velocity=v, mallet=modal.Mallet(hardness, 0.2), sr=sr, seed=seed, peak_db=None, **kw)
    x = a.data.astype(np.float64)
    x = x / (np.abs(x).max() + 1e-12)
    x = x + _click(sr, 4.0, 3500.0, -26.0 + 10.0 * (v - 0.5), seed, len(x))
    return Audio(x, sr)


def bell(kind: str = "church") -> Instrument:
    """Bell. kind: church (hum/prime/tierce/quint/nominal ... with beating pairs), handbell, tubular, glass,
    gong. `freq` is the prime (the strike note, heard an octave above the hum for church). Parameters:
    t60, beat_hz, hardness, ref ('prime' | 'hum')."""
    return Instrument(f"bell/{kind}", _bell, {"kind": kind}, None, 0.0, note_range=(36, 96), retune=False)


def _timpani(f, v, dur, sr, seed, *, radius=0.5, t60=None, glide=30.0, hardness=0.3, **kw):
    t = t60 if t60 is not None else float(np.clip(3.0 * (110.0 / f) ** 0.5, 0.8, 5.0))
    m = modal.membrane(f, "timpani", t60=t, strike_radius=radius)
    return modal.strike(m, dur, velocity=v, mallet=modal.Mallet(hardness, 0.1), position=radius, pitch_glide_cents=glide,
                        sr=sr, seed=seed, peak_db=None, **kw)


def timpani() -> Instrument:
    """Timpani: circular membrane with air loading (modes 1 : 1.5 : 2 : 2.44 : 2.9 so it is pitched),
    felt mallet at half radius, tension-modulation pitch glide on strong hits. `freq` is the (1,1) pitch.
    Range D2-C4. Parameters: radius, t60, glide (cents), hardness."""
    return Instrument("timpani", _timpani, {}, None, 0.0, note_range=(38, 60), retune=False)


def _glass(f, v, dur, sr, seed, **kw):
    return _bell(f, v, dur, sr, seed, kind="glass", hardness=0.9, **kw)


def glass() -> Instrument:
    """Struck wine glass / glass bowl: very pure, long, widely spaced modes (1 : 2.32 : 4.25 : 6.6)."""
    return Instrument("glass", _glass, {}, None, 0.0, note_range=(60, 100), retune=False)


ALL = {"guitar": guitar, "piano": piano, "cello": cello, "violin": violin, "clarinet": clarinet, "oboe": oboe,
       "saxophone": saxophone, "flute": flute, "trumpet": trumpet, "trombone": trombone, "horn": horn,
       "marimba": marimba, "xylophone": xylophone, "vibraphone": vibraphone, "glockenspiel": glockenspiel,
       "bell": bell, "timpani": timpani, "glass": glass}
