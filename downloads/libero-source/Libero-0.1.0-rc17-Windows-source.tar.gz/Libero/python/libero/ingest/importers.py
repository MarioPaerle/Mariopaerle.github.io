"""Turn a real library into a Libero sound folder whose recipe uses `sound.multisample`.

`import_sfz` reads an SFZ structurally; `import_wav_set` reads a folder of note-named files
(VCSL, TinySOL, your own recordings). Both pick dynamics layers, roots and round robins to fit a
memory budget, link (not copy) the chosen files into samples/, write samples/map.json, a
sound.py from the family preset, notes and credits.
"""

from __future__ import annotations

import datetime as _dt
import json
import os
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import soundfile as sf

from .. import dsp, families, library, licenses
from .sfz import parse_sfz, take_index

AUDIO_EXT = (".wav", ".flac", ".aif", ".aiff", ".ogg")
DEFAULT_BUDGET_MB = 600.0  # RAM of the compiled bundle (float32 in the engine)


class ImportError_(ValueError):
    pass


@dataclass
class Pick:
    """One chosen source file with its mapping (before planning)."""
    path: Path
    root: int
    vel: tuple[int, int]
    take: int = 0
    lo: int | None = None
    hi: int | None = None
    tune_cents: float = 0.0
    gain_db: float = 0.0
    loop: dict | None = None
    offset: int = 0
    end: int | None = None
    rt_decay: float | None = None
    pitched: bool = True
    seconds: float = 0.0
    channels: int = 2
    extra: dict = field(default_factory=dict)


# ---------------------------------------------------------------- selection helpers

def pick_even(items: list, k: int) -> list:
    if k <= 0 or k >= len(items):
        return list(items)
    idx = sorted({int(round(i)) for i in np.linspace(0, len(items) - 1, k)})
    return [items[i] for i in idx]


def pick_roots(roots: list[int], step: int) -> list[int]:
    rs = sorted(set(roots))
    if step <= 1 or len(rs) <= 2:
        return rs
    out = [rs[0]]
    for r in rs[1:-1]:
        if r - out[-1] >= step:
            out.append(r)
    if rs[-1] - out[-1] < step and len(out) > 1 and rs[-1] - out[-2] <= 2 * step:
        out[-1] = rs[-1]
    else:
        out.append(rs[-1])
    return out


def estimate_mb(picks: list[Pick], family: str, sr: int = 48000) -> float:
    proc = families.get(family)["process"]
    cap = proc.get("max_seconds")
    total = 0.0
    for p in picks:
        secs = p.seconds
        if cap is not None:
            if isinstance(cap, (int, float)):
                secs = min(secs, float(cap))
            else:
                pts = sorted((a, b) for a, b in cap)
                secs = min(secs, float(np.interp(p.root, [a for a, _ in pts], [b for _, b in pts])))
        total += secs * sr * p.channels * 4
    return total / 1e6


def fit_budget(body: list[Pick], family: str, layers: int, root_step: int, takes: int, budget_mb: float,
               quality: str = "slow") -> tuple[list[Pick], dict, list[str]]:
    """Choose dynamics layers, roots and takes; shrink (layers first, then root spacing) to the budget."""
    fam = families.get(family)
    notes: list[str] = []
    vel_sets = sorted({p.vel for p in body}, key=lambda v: (v[0] + v[1]) / 2)
    all_roots = sorted({p.root for p in body})
    max_take = max((p.take for p in body), default=0) + 1
    n_layers = layers or min(len(vel_sets), fam["layers"][quality])
    n_takes = takes or min(max_take, fam["takes"][quality])
    step = root_step
    min_layers = max(1, min(len(vel_sets), fam["lint"]["min_layers"]))

    def select(nl, st, nt):
        keep_v = set(pick_even(vel_sets, nl))
        keep_r = set(pick_roots(all_roots, st)) if st else set(all_roots)
        return [p for p in body if p.vel in keep_v and p.root in keep_r and p.take < nt]

    chosen = select(n_layers, step, n_takes)
    mb = estimate_mb(chosen, family)
    while mb > budget_mb:
        if n_takes > 1:
            n_takes -= 1
        elif n_layers > min_layers:
            n_layers -= 1
        else:
            gaps = np.diff(all_roots) if len(all_roots) > 1 else [12]
            base = int(max(1, np.median(gaps)))
            step = max(step, base) + base
            if step > 12:
                break
        chosen = select(n_layers, step, n_takes)
        mb = estimate_mb(chosen, family)
    if mb > budget_mb:
        notes.append(f"still {mb:.0f} MB over a {budget_mb:.0f} MB budget at the minimum settings")
    info = {"layers": n_layers, "of_layers": len(vel_sets), "roots": len({p.root for p in chosen}),
            "of_roots": len(all_roots), "takes": n_takes, "of_takes": max_take, "estimated_mb": round(mb, 1)}
    if n_layers < len(vel_sets) or info["roots"] < len(all_roots) or n_takes < max_take:
        notes.append(f"kept {n_layers}/{len(vel_sets)} dynamics layers, {info['roots']}/{len(all_roots)} roots, "
                     f"{n_takes}/{max_take} takes → ≈{mb:.0f} MB in memory")
    return chosen, info, notes


# ---------------------------------------------------------------- writing the sound

def _link_into(folder: Path, src: Path, rel: str) -> str:
    dst = folder / "samples" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.exists():
        try:
            os.link(src, dst)
        except OSError:
            shutil.copyfile(src, dst)
    return rel


def credit_for_path(path: Path) -> dict | None:
    """A structured credit when `path` lies inside a fetched catalogue library."""
    from .catalog import BY_ID
    from .fetcher import libraries_dir

    try:
        rel = Path(path).resolve().relative_to(libraries_dir().resolve())
    except ValueError:
        return None
    sid = rel.parts[0]
    src = BY_ID.get(sid)
    if not src:
        return None
    idx = libraries_dir() / sid / "_index.json"
    retrieved = json.loads(idx.read_text()).get("retrieved") if idx.exists() else _dt.date.today().isoformat()
    return {"source": src.name, "id": src.id, "author": src.author, "license": src.license,
            "license_class": src.license_class, "url": src.url, "retrieved": retrieved}


def _regions(picks: list[Pick], folder: Path, prefix: str, base: Path | None, keep_ranges: bool) -> list[dict]:
    out = []
    for p in picks:
        try:
            rel = str(p.path.resolve().relative_to(base.resolve())) if base else p.path.name
        except ValueError:
            rel = p.path.name
        rel = f"{prefix}/{rel}"
        _link_into(folder, p.path, rel)
        r = {"file": rel, "root": p.root, "vel": list(p.vel)}
        if p.take:
            r["take"] = p.take
        if keep_ranges and p.lo is not None:
            r["lo"], r["hi"] = p.lo, p.hi
        if abs(p.tune_cents) > 0.01:
            r["tune_cents"] = p.tune_cents
        if abs(p.gain_db) > 0.01:
            r["gain_db"] = round(p.gain_db, 2)
        if p.loop:
            r["loop"] = p.loop
        if p.offset:
            r["offset"] = p.offset
        if p.end:
            r["end"] = p.end
        if p.rt_decay is not None:
            r["rt_decay"] = p.rt_decay
        if not p.pitched:
            r["pitched"] = False
        out.append(r)
    return out


def write_sound(slug: str, title: str, subtitle: str, family: str, body: list[dict], tail: list[dict],
                credit: dict | None, notes_extra: list[str], defaults_extra: dict | None = None,
                quality: str = "slow", source_desc: str = "") -> Path:
    fam = families.get(family)
    fname = families.name(family)
    folder = library.sketches_dir() / slug
    (folder / "samples").mkdir(parents=True, exist_ok=True)
    (folder / "samples" / "map.json").write_text(json.dumps({"body": body, "tail": tail}, indent=1) + "\n")
    perf = {"humanize": fam["humanize"], "rr_reset_ms": fam["rr_reset_ms"], **fam.get("performance", {})}
    defaults = {**fam["defaults"], **(defaults_extra or {})}
    if not tail:
        defaults.pop("lvl_tail", None)
    tail_proc = {"tune": "none", "align_ms": 0.0, "ladder": "keep", "max_seconds": 4.0}
    code = f'''"""{title} — {subtitle or fname}. Recorded {fname} imported from {source_desc or 'a sample library'}."""

import json
from pathlib import Path

from libero import Sound

MAP = json.loads((Path(__file__).parent / "samples" / "map.json").read_text())

sound = Sound(title={title!r}, subtitle={subtitle!r}, tags={[fname, "sampled"]!r}, sample_rate=48000)

sound.multisample("body", MAP["body"], process={fam["process"]!r})
if MAP.get("tail"):
    sound.multisample("tail", MAP["tail"], process={tail_proc!r})

sound.performance({", ".join(f"{k}={v!r}" for k, v in perf.items())})
sound.defaults({", ".join(f"{k}={v!r}" for k, v in defaults.items())})
'''
    (folder / "sound.py").write_text(code)
    lines = [f"# {title}", "", f"{subtitle or fname.capitalize()}: recorded {fname} imported from "
             f"{source_desc or 'a sample library'}, edited by the Libero compiler (true-onset trim, "
             f"phase-aligned layers, calibrated level ladder).", "", "## Import", ""]
    lines += [f"- {n}" for n in notes_extra]
    if credit:
        lines += ["", "## Source", "", f"{credit['source']} by {credit.get('author', '?')}, {credit['license']} "
                  f"<{credit.get('url', '')}>"]
    (folder / "notes.md").write_text("\n".join(lines) + "\n")
    if credit:
        licenses.add_credit(folder, credit)
        from ..download import attribute

        attribute(folder, "(library)", f"{credit['source']} by {credit.get('author', '?')}, {credit['license']} "
                                      f"<{credit.get('url', '')}>")
    return folder


def _new_folder(slug: str, replace: bool) -> None:
    library.check_slug(slug)
    for base in (library.sketches_dir(), library.sounds_dir(), *library._bank_dirs()):
        if (base / slug).exists():
            if replace and base == library.sketches_dir():
                library.discard_sound(slug)
            else:
                raise ImportError_(f"'{slug}' already exists in {base.name}/ (pass replace=True for a sketch)")


def _info(p: Path) -> tuple[float, int]:
    try:
        i = sf.info(str(p))
        return i.duration, i.channels
    except RuntimeError:
        return 0.0, 2


# ---------------------------------------------------------------- SFZ

def import_sfz(slug: str, sfz_path: str | Path, family: str = "piano", title: str = "", subtitle: str = "",
               layers: int = 0, root_step: int = 0, takes: int = 0, budget_mb: float = DEFAULT_BUDGET_MB,
               quality: str = "slow", releases: bool = True, credit: dict | None = None,
               replace: bool = False) -> dict:
    """Import an SFZ instrument as a sketch. Returns a compact report."""
    sfz_path = Path(sfz_path).expanduser().resolve()
    if not sfz_path.exists():
        raise ImportError_(f"{sfz_path} does not exist")
    families.get(family)
    ins = parse_sfz(sfz_path)
    notes = list(ins.warnings)
    tk = take_index(ins.regions)
    body, tails = [], []
    missing = 0
    for r, t in zip(ins.regions, tk):
        if not r.sample.exists():
            missing += 1
            continue
        secs, ch = _info(r.sample)
        loop = None
        if r.loop_mode in ("loop_continuous", "loop_sustain") and r.loop_start is not None and r.loop_end:
            loop = {"start": r.loop_start, "end": r.loop_end}
        p = Pick(r.sample, r.root, (r.lovel, r.hivel), t, r.lokey, r.hikey, r.tune_cents, r.gain_db, loop,
                 r.offset, r.end, r.rt_decay, True, secs, ch, {"group": r.group_id, "release": r.ampeg_release})
        (tails if r.trigger == "release" else body).append(p)
    if missing:
        notes.append(f"{missing} regions point to files that are not on disk (not in the fetched subset) — left out")
    if not body:
        raise ImportError_("no body regions with files on disk" + (f" ({missing} missing)" if missing else ""))
    chosen, info, budget_notes = fit_budget(body, family, layers, root_step, takes, budget_mb, quality)
    notes += budget_notes
    reduced_roots = info["roots"] < info["of_roots"]
    # release sets: keep the one covering most keys at all velocities
    tail_chosen = []
    if releases and tails:
        sets: dict[str, list[Pick]] = {}
        for p in tails:
            sets.setdefault(p.extra["group"].split(".")[0], []).append(p)
        def score(ps):
            full_vel = sum(1 for p in ps if p.vel == (1, 127))
            return (len({p.root for p in ps}), full_vel)
        best = max(sets.values(), key=score)
        tail_chosen = [p for p in best if p.take == 0]
        dropped = len(tails) - len(best)
        if dropped:
            notes.append(f"kept one release set ({len(best)} regions); {dropped} overlapping release regions "
                         f"(other sets, e.g. string resonance) left out")
        vels = {p.vel for p in tail_chosen}
        if len(vels) > 1:
            top = max(vels, key=lambda v: v[1] - v[0])
            tail_chosen = [p for p in tail_chosen if p.vel == top]
    credit = credit or credit_for_path(sfz_path)
    base = sfz_path.parent
    _new_folder(slug, replace)
    folder = library.sketches_dir() / slug
    (folder / "samples").mkdir(parents=True, exist_ok=True)
    prefix = credit["id"] if credit and credit.get("id") else "src"
    body_regions = _regions(chosen, folder, prefix, base, keep_ranges=not reduced_roots)
    tail_regions = _regions(tail_chosen, folder, prefix, base, keep_ranges=True)
    rel_ms = [p.extra.get("release") for p in chosen if p.extra.get("release")]
    extra_defaults = {}
    if len(rel_ms) > len(chosen) / 2:  # only when the library states a release for most regions
        extra_defaults["amp_release"] = int(np.clip(np.median(rel_ms) * 1000, 60, 4000))
    title = title or sfz_path.stem.replace("_", " ")
    write_sound(slug, title, subtitle, family, body_regions, tail_regions, credit,
                notes + [f"from `{sfz_path.name}`; family preset `{families.name(family)}`"], extra_defaults,
                quality, credit["source"] if credit else sfz_path.name)
    if ins.unsupported:
        notes.append(f"opcodes not mapped (live engine territory): {', '.join(sorted(ins.unsupported)[:12])}")
    return {"slug": slug, "folder": str(folder), "body_regions": len(body_regions), "tail_regions": len(tail_regions),
            **info, "license": credit["license"] if credit else "unknown (add a credit)",
            "license_class": credit["license_class"] if credit else "unknown", "notes": notes,
            "next": f"compile('{slug}') then lint('{slug}') and preview('{slug}')"}


# ---------------------------------------------------------------- WAV sets

DYN_WORDS = {"pppp": 1, "ppp": 2, "pp": 3, "p": 4, "mp": 5, "mf": 6, "f": 7, "ff": 8, "fff": 9, "ffff": 10,
             "soft": 3, "quiet": 3, "med": 6, "medium": 6, "mid": 6, "loud": 8, "hard": 8}
_NOTE_TOK = re.compile(r"^([A-Ga-g])(#|b|s|sharp)?(-?\d)$")
_RR_TOK = re.compile(r"^(?:rr|RR|Rr|take|t)(\d+)$")
_VEL_TOK = re.compile(r"^(?:v|vl|vel|V|VL|L|dyn)(\d+)$")


def parse_name(stem: str) -> dict:
    """Guess note / dynamic / round robin / release from a file name like
    'Marimba_hit_Outrigger_C#4_loud_01' or 'Vn-ord-A4-ff-4c-N'."""
    toks = [t for t in re.split(r"[_\-\s.]+", stem) if t]
    out: dict = {}
    for i, t in enumerate(toks):
        m = _NOTE_TOK.match(t)
        if m and "note" not in out:
            acc = {"#": "#", "s": "#", "sharp": "#", "b": "b", None: ""}[m.group(2)]
            out["note"] = dsp.parse_note(m.group(1).upper() + acc + m.group(3))
            continue
        low = t.lower()
        if low in DYN_WORDS and "dyn" not in out:
            out["dyn"] = DYN_WORDS[low]
            out["dyn_label"] = low
            continue
        m = _VEL_TOK.match(t)
        if m and "dyn" not in out:
            out["dyn"] = int(m.group(1))
            out["dyn_label"] = t
            continue
        m = _RR_TOK.match(t)
        if m:
            out["rr"] = int(m.group(1))
            continue
        if low in ("rel", "release", "releases", "relrel"):
            out["release"] = True
        if re.fullmatch(r"\d{1,2}", t) and i == len(toks) - 1 and "rr" not in out:
            out["rr"] = int(t)
    return out


def import_wav_set(slug: str, folder: str | Path, family: str = "plucked", pattern: str = "", include: str = "",
                   exclude: str = "", title: str = "", subtitle: str = "", layers: int = 0, root_step: int = 0,
                   takes: int = 0, budget_mb: float = DEFAULT_BUDGET_MB, quality: str = "slow",
                   credit: dict | None = None, replace: bool = False) -> dict:
    """Import a folder of note-named audio files. `pattern` is an optional regex with named groups
    note, dyn, rr (e.g. r'_(?P<note>[A-G]#?\\d)_(?P<dyn>pp|mf|ff)'); otherwise names are parsed by
    parse_name. include/exclude are substrings (comma-separated) filtering file paths, e.g. a mic
    name. Files under a 'Releases'/'rel' folder or with 'rel' in the name become the tail."""
    root_dir = Path(folder).expanduser().resolve()
    if not root_dir.is_dir():
        raise ImportError_(f"{root_dir} is not a folder")
    families.get(family)
    inc = [s.strip().lower() for s in include.split(",") if s.strip()]
    exc = [s.strip().lower() for s in exclude.split(",") if s.strip()]
    rx = re.compile(pattern) if pattern else None
    items, skipped = [], 0
    for p in sorted(root_dir.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in AUDIO_EXT:
            continue
        rel = str(p.relative_to(root_dir)).lower()
        if inc and not all(s in rel for s in inc):
            continue
        if any(s in rel for s in exc):
            continue
        if rx:
            m = rx.search(p.stem)
            if not m:
                skipped += 1
                continue
            g = m.groupdict()
            info = {"note": dsp.parse_note(g["note"]) if g.get("note") else None}
            if g.get("dyn"):
                d = g["dyn"]
                info["dyn"] = int(d) if d.isdigit() else DYN_WORDS.get(d.lower(), 5)
            if g.get("rr"):
                info["rr"] = int(g["rr"])
        else:
            info = parse_name(p.stem)
        if info.get("note") is None:
            skipped += 1
            continue
        info["release"] = info.get("release") or any(part.lower() in ("releases", "release", "rel")
                                                      for part in p.relative_to(root_dir).parts[:-1])
        items.append((p, info))
    if not items:
        raise ImportError_(f"no note-named audio files found in {root_dir}")
    notes = [f"{len(items)} files mapped" + (f", {skipped} skipped (no note in the name)" if skipped else "")]
    body_items = [(p, i) for p, i in items if not i.get("release")]
    tail_items = [(p, i) for p, i in items if i.get("release")]
    dyn_levels = sorted({i.get("dyn", 5) for _, i in body_items})
    edges = np.linspace(1, 128, len(dyn_levels) + 1).round().astype(int)
    vel_of = {d: (int(edges[k]), int(edges[k + 1] - 1)) for k, d in enumerate(dyn_levels)}
    vel_of_last = {d: (a, min(127, b)) for d, (a, b) in vel_of.items()}
    rr_levels = sorted({i.get("rr", 0) for _, i in body_items})
    take_of = {r: k for k, r in enumerate(rr_levels)}
    body = []
    for p, i in body_items:
        secs, ch = _info(p)
        body.append(Pick(p, i["note"], vel_of_last[i.get("dyn", 5)], take_of[i.get("rr", 0)], seconds=secs, channels=ch))
    # identical (root, vel, take) duplicates (e.g. several mics) → keep the first
    seen, dedup = set(), []
    for b in body:
        k = (b.root, b.vel, b.take)
        if k in seen:
            continue
        seen.add(k)
        dedup.append(b)
    if len(dedup) < len(body):
        notes.append(f"{len(body) - len(dedup)} duplicate files for the same note/dynamic/take left out "
                     f"(filter a mic with include=...)")
    chosen, info, budget_notes = fit_budget(dedup, family, layers, root_step, takes, budget_mb, quality)
    notes += budget_notes
    tails = []
    tseen = set()
    for p, i in tail_items:
        if i["note"] in tseen:
            continue
        tseen.add(i["note"])
        secs, ch = _info(p)
        tails.append(Pick(p, i["note"], (1, 127), 0, rt_decay=10.0, seconds=secs, channels=ch))
    credit = credit or credit_for_path(root_dir)
    _new_folder(slug, replace)
    dst = library.sketches_dir() / slug
    (dst / "samples").mkdir(parents=True, exist_ok=True)
    prefix = credit["id"] if credit and credit.get("id") else "src"
    body_regions = _regions(chosen, dst, prefix, root_dir, keep_ranges=False)
    tail_regions = _regions(tails, dst, prefix, root_dir, keep_ranges=False)
    title = title or root_dir.name
    write_sound(slug, title, subtitle, family, body_regions, tail_regions, credit,
                notes + [f"from folder `{root_dir.name}`; family preset `{families.name(family)}`"], None,
                quality, credit["source"] if credit else root_dir.name)
    return {"slug": slug, "folder": str(dst), "body_regions": len(body_regions), "tail_regions": len(tail_regions),
            **info, "dynamics_levels": [next((i.get("dyn_label") for _, i in body_items if i.get("dyn", 5) == d
                                               and i.get("dyn_label")), str(d)) for d in dyn_levels],
            "license": credit["license"] if credit else "unknown (add a credit)",
            "license_class": credit["license_class"] if credit else "unknown", "notes": notes,
            "next": f"compile('{slug}') then lint('{slug}') and preview('{slug}')"}
