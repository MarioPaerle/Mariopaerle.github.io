"""Per-family recipes for sampled instruments (docs/research/sample-libraries.md §7.5):
root spacing, dynamics layers, round robins, loop and length policy, release, humanize and
starting live parameters. Importers use them as defaults; `family_preset()` gives the agent
a complete skeleton so a good instrument takes a few calls, not a design session."""

from __future__ import annotations

import json

FAMILIES: dict[str, dict] = {
    "piano": {
        "dyn_crossfade": 0,   # 0 = switch layers; "aligned" = 0.3 if the layers are phase-aligned, else 0
        "what": "piano, keyed struck strings (grand, upright, harpsichord, celesta)",
        "root_spacing": {"fast": 7, "slow": 3}, "layers": {"fast": 3, "slow": 8}, "takes": {"fast": 1, "slow": 2},
        "loop": "none", "max_seconds": [[21, 10.0], [64, 7.0], [108, 3.5]], "release": "recorded hammer/damper "
        "releases as tail with rt_decay 8-15 dB/s (or sampletools.release_from)",
        "process": {"max_step_db": 9.5, "tune": "smooth", "ladder": "smooth", "peak_db": -9.0, "align_ms": 5.0, "loop": "none",
                    "max_seconds": [[21, 10.0], [64, 7.0], [108, 3.5]], "end_db": -62.0},
        "humanize": {"cents": 1.0, "ms": 2.0, "db": 0.4}, "rr_reset_ms": 2000,
        "defaults": {"amp_attack": 0, "amp_decay": 10000, "amp_sustain": 1.0, "amp_release": 280, "vel_sens": 0.3,
                     "rev_mode": "Basilica", "rev_mix": 0.16, "rev_decay": 2.6, "res_mode": "Corde", "res_mix": 0.06,
                     "lvl_tail": -4},
        "lint": {"release": True, "min_layers": 3, "max_step_db": 10, "rr_min": 1},
    },
    "plucked": {
        "dyn_crossfade": 0,   # 0 = switch layers; "aligned" = 0.3 if the layers are phase-aligned, else 0
        "what": "harp, guitar, lyre, lute, zither, harpsichord-like plucks",
        "root_spacing": {"fast": 5, "slow": 3}, "layers": {"fast": 2, "slow": 4}, "takes": {"fast": 2, "slow": 4},
        "loop": "none", "max_seconds": [[28, 8.0], [96, 3.0]], "release": "short string-noise release",
        "process": {"max_step_db": 7.5, "tune": "detect", "ladder": "smooth", "align_ms": 3.0, "loop": "none",
                    "max_seconds": [[28, 8.0], [96, 3.0]]},
        "humanize": {"cents": 2.0, "ms": 3.0, "db": 0.6}, "rr_reset_ms": 1500,
        "defaults": {"amp_attack": 0, "amp_decay": 8000, "amp_sustain": 1.0, "amp_release": 350, "vel_sens": 0.5,
                     "rev_mode": "Cappella", "rev_mix": 0.2, "res_mode": "Corde", "res_mix": 0.1},
        "lint": {"release": False, "min_layers": 2, "max_step_db": 8, "rr_min": 2},
    },
    "mallet": {
        "dyn_crossfade": 0,   # 0 = switch layers; "aligned" = 0.3 if the layers are phase-aligned, else 0
        "what": "marimba, vibraphone, xylophone, glockenspiel, bells, kalimba",
        "root_spacing": {"fast": 4, "slow": 3}, "layers": {"fast": 3, "slow": 5}, "takes": {"fast": 2, "slow": 4},
        "loop": "none", "max_seconds": [[36, 6.0], [108, 2.5]], "release": "damper choke (optional)",
        "process": {"max_step_db": 7.5, "tune": "detect", "ladder": "smooth", "align_ms": 3.0, "loop": "none",
                    "max_seconds": [[36, 6.0], [108, 2.5]]},
        "humanize": {"cents": 1.5, "ms": 2.0, "db": 0.6}, "rr_reset_ms": 1500,
        "defaults": {"amp_attack": 0, "amp_decay": 6000, "amp_sustain": 1.0, "amp_release": 600, "vel_sens": 0.5,
                     "rev_mode": "Cappella", "rev_mix": 0.2},
        "lint": {"release": False, "min_layers": 3, "max_step_db": 8, "rr_min": 2},
    },
    "bowed": {
        "dyn_crossfade": "aligned",   # 0 = switch layers; "aligned" = 0.3 if the layers are phase-aligned, else 0
        "what": "violin, viola, cello, double bass, sections, erhu (sustained articulations)",
        "root_spacing": {"fast": 3, "slow": 3}, "layers": {"fast": 2, "slow": 3}, "takes": {"fast": 1, "slow": 2},
        "loop": "auto (>= 3 s)", "max_seconds": 12.0, "release": "light release trigger (room/bow lift)",
        "process": {"max_step_db": 9.5, "tune": "detect", "ladder": "smooth", "align_ms": 3.0, "loop": "auto", "loop_min_s": 3.0,
                    "max_seconds": 12.0},
        "humanize": {"cents": 3.0, "ms": 4.0, "db": 0.5}, "rr_reset_ms": 1500,
        "defaults": {"amp_attack": 60, "amp_sustain": 1.0, "amp_release": 450, "vel_sens": 0.4,
                     "rev_mode": "Basilica", "rev_mix": 0.22, "dyn_mode": "Modulazione"},
        "performance": {"dynamics_source": "cc1"},
        "lint": {"release": False, "min_layers": 2, "max_step_db": 10, "rr_min": 1},
    },
    "wind": {
        "dyn_crossfade": "aligned",   # 0 = switch layers; "aligned" = 0.3 if the layers are phase-aligned, else 0
        "what": "flute, oboe, clarinet, bassoon, saxophone, recorder, pipes",
        "root_spacing": {"fast": 3, "slow": 3}, "layers": {"fast": 2, "slow": 3}, "takes": {"fast": 1, "slow": 2},
        "loop": "auto (>= 2 s)", "max_seconds": 10.0, "release": "breath/tongue release",
        "process": {"max_step_db": 9.5, "tune": "detect", "ladder": "smooth", "align_ms": 3.0, "loop": "auto", "loop_min_s": 2.0,
                    "max_seconds": 10.0},
        "humanize": {"cents": 3.0, "ms": 4.0, "db": 0.5}, "rr_reset_ms": 1500,
        "defaults": {"amp_attack": 30, "amp_sustain": 1.0, "amp_release": 250, "vel_sens": 0.4,
                     "rev_mode": "Cappella", "rev_mix": 0.2, "dyn_mode": "Modulazione"},
        "performance": {"dynamics_source": "cc1"},
        "lint": {"release": False, "min_layers": 2, "max_step_db": 10, "rr_min": 1},
    },
    "brass": {
        "dyn_crossfade": "aligned",   # 0 = switch layers; "aligned" = 0.3 if the layers are phase-aligned, else 0
        "what": "horn, trumpet, trombone, tuba",
        "root_spacing": {"fast": 3, "slow": 3}, "layers": {"fast": 3, "slow": 4}, "takes": {"fast": 1, "slow": 3},
        "loop": "auto (>= 2 s)", "max_seconds": 10.0, "release": "bell/room release",
        "process": {"max_step_db": 9.5, "tune": "detect", "ladder": "smooth", "align_ms": 3.0, "loop": "auto", "loop_min_s": 2.0,
                    "max_seconds": 10.0},
        "humanize": {"cents": 3.0, "ms": 4.0, "db": 0.6}, "rr_reset_ms": 1500,
        "defaults": {"amp_attack": 20, "amp_sustain": 1.0, "amp_release": 300, "vel_sens": 0.4,
                     "rev_mode": "Basilica", "rev_mix": 0.22, "dyn_mode": "Modulazione"},
        "performance": {"dynamics_source": "cc1"},
        "lint": {"release": False, "min_layers": 3, "max_step_db": 10, "rr_min": 1},
    },
    "voice": {
        "what": "choir, solo voice (per vowel)",
        "root_spacing": {"fast": 4, "slow": 3}, "layers": {"fast": 2, "slow": 3}, "takes": {"fast": 1, "slow": 2},
        "loop": "auto (>= 3 s)", "max_seconds": 12.0, "release": "consonant/breath release",
        "process": {"max_step_db": 9.5, "tune": "detect", "ladder": "smooth", "align_ms": 3.0, "loop": "auto", "loop_min_s": 3.0,
                    "max_seconds": 12.0},
        "humanize": {"cents": 4.0, "ms": 5.0, "db": 0.6}, "rr_reset_ms": 1500,
        "defaults": {"amp_attack": 120, "amp_sustain": 1.0, "amp_release": 900, "rev_mode": "Basilica",
                     "rev_mix": 0.3},
        "lint": {"release": False, "min_layers": 2, "max_step_db": 10, "rr_min": 1},
    },
    "percussion": {
        "dyn_crossfade": 0,   # 0 = switch layers; "aligned" = 0.3 if the layers are phase-aligned, else 0
        "what": "drums, hits, hand percussion (unpitched or barely pitched)",
        "root_spacing": {"fast": 0, "slow": 0}, "layers": {"fast": 4, "slow": 8}, "takes": {"fast": 4, "slow": 8},
        "loop": "none", "max_seconds": 6.0, "release": "choke/room tail",
        "process": {"max_step_db": 7.5, "tune": "none", "ladder": "smooth", "align_ms": 2.0, "loop": "none", "max_seconds": 6.0},
        "humanize": {"cents": 3.0, "ms": 3.0, "db": 0.8}, "rr_reset_ms": 1000,
        "defaults": {"amp_attack": 0, "amp_sustain": 1.0, "amp_release": 400, "vel_sens": 0.5, "rev_mode": "Cappella",
                     "rev_mix": 0.15},
        "lint": {"release": False, "min_layers": 3, "max_step_db": 8, "rr_min": 4},
    },
    "pad": {
        "what": "evolving pads, drones, textures (hybrid, often synthetic sources)",
        "root_spacing": {"fast": 12, "slow": 6}, "layers": {"fast": 1, "slow": 2}, "takes": {"fast": 1, "slow": 2},
        "loop": "auto (>= 4 s) or frozen", "max_seconds": 16.0, "release": "long release (seconds)",
        "process": {"max_step_db": 11.5, "tune": "detect", "ladder": "keep", "align_ms": 0.0, "loop": "auto", "loop_min_s": 4.0,
                    "max_seconds": 16.0},
        "humanize": {"cents": 2.0, "ms": 0.0, "db": 0.3}, "rr_reset_ms": 3000,
        "defaults": {"amp_attack": 900, "amp_sustain": 0.9, "amp_release": 2500, "rev_mode": "Basilica",
                     "rev_mix": 0.35},
        "lint": {"release": False, "min_layers": 1, "max_step_db": 12, "rr_min": 1},
    },
    "cinematic": {
        "what": "hits, braams, risers, reverse swells",
        "root_spacing": {"fast": 12, "slow": 6}, "layers": {"fast": 2, "slow": 3}, "takes": {"fast": 2, "slow": 4},
        "loop": "none", "max_seconds": 12.0, "release": "the tail is the sound",
        "process": {"max_step_db": 11.5, "tune": "detect", "ladder": "keep", "align_ms": 2.0, "loop": "none", "max_seconds": 12.0},
        "humanize": {"cents": 3.0, "ms": 2.0, "db": 0.5}, "rr_reset_ms": 2000,
        "defaults": {"amp_attack": 0, "amp_sustain": 1.0, "amp_release": 1500, "rev_mode": "Cisterna",
                     "rev_mix": 0.3},
        "lint": {"release": False, "min_layers": 1, "max_step_db": 12, "rr_min": 1},
    },
    "synth": {
        "what": "Serum-class synth sounds: a short loopable cycle or texture, everything else live",
        "root_spacing": {"fast": 12, "slow": 12}, "layers": {"fast": 1, "slow": 2}, "takes": {"fast": 1, "slow": 1},
        "loop": "auto (seamless cycles)", "max_seconds": 4.0, "release": "live envelope",
        "process": {"max_step_db": 11.5, "tune": "detect", "ladder": "keep", "align_ms": 0.0, "loop": "auto", "loop_min_s": 0.5,
                    "max_seconds": 4.0},
        "humanize": {"cents": 0.0, "ms": 0.0, "db": 0.0}, "rr_reset_ms": 0,
        "defaults": {"amp_attack": 5, "amp_sustain": 0.8, "amp_release": 300},
        "lint": {"release": False, "min_layers": 1, "max_step_db": 12, "rr_min": 1},
    },
}

ALIASES = {"keys": "piano", "struck": "piano", "harp": "plucked", "guitar": "plucked", "strings": "bowed",
           "woodwind": "wind", "winds": "wind", "choir": "voice", "drums": "percussion", "hybrid": "pad",
           "mallets": "mallet", "hit": "cinematic", "fx": "cinematic"}


def dyn_crossfade_default(family: str | None) -> float | str | None:
    """0 (hard switch), "aligned" (0.3 when measured phase-aligned, else 0) or None (legacy blend)."""
    if not family:
        return None
    try:
        return get(family).get("dyn_crossfade")
    except ValueError:
        return None


def of_tags(tags) -> str | None:
    """The family a sound's tags name (first tag that is a family or alias), else None."""
    for t in tags or []:
        if t in FAMILIES or t in ALIASES:
            return name(t)
    return None


def get(family: str) -> dict:
    f = ALIASES.get(family, family)
    if f not in FAMILIES:
        raise ValueError(f"family must be one of {sorted(FAMILIES)}")
    return FAMILIES[f]


def name(family: str) -> str:
    return ALIASES.get(family, family)


def skeleton(family: str, quality: str = "slow") -> str:
    """A complete sound.py for a recorded instrument of this family (regions from samples/map.json)."""
    fam = get(family)
    fname = name(family)
    perf = {"humanize": fam["humanize"], "rr_reset_ms": fam["rr_reset_ms"], **fam.get("performance", {})}
    perf_args = ", ".join(f"{k}={v!r}" for k, v in perf.items())
    return f'''"""<Title> — recorded {fname} ({fam["what"]})."""

import json
from pathlib import Path

from libero import Sound, synth

MAP = json.loads((Path(__file__).parent / "samples" / "map.json").read_text())

sound = Sound(title="<Title>", subtitle="<subtitle>", tags=["{fname}", "sampled"], sample_rate=48000)

# regions: [{{"file", "root", "vel": [lo, hi] | "dyn": [lo, hi], "take", "tune_cents", "gain_db", ...}}]
sound.multisample("body", MAP["body"], process={json.dumps(fam["process"])})
if MAP.get("tail"):
    sound.multisample("tail", MAP["tail"], process={{"tune": "none", "ladder": "keep", "align_ms": 0}})

sound.performance({perf_args})
sound.defaults({", ".join(f"{k}={v!r}" for k, v in fam["defaults"].items())})
'''


def preset_text(family: str, quality: str = "slow") -> str:
    fam = get(family)
    q = quality if quality in ("fast", "slow") else "slow"
    lines = [f"# {name(family)} — {fam['what']}", "",
             f"- roots: every {fam['root_spacing'][q] or '—'} semitones ({q}); dynamics layers: {fam['layers'][q]}; "
             f"round robins: {fam['takes'][q]}",
             f"- loop: {fam['loop']}; length cap: {fam['max_seconds']}",
             f"- release: {fam['release']}",
             f"- humanize: {fam['humanize']}, rr_reset_ms {fam['rr_reset_ms']}",
             f"- process: {json.dumps(fam['process'])}",
             f"- starting live params: {json.dumps(fam['defaults'], ensure_ascii=False)}",
             "", "Import with import_sfz / import_wav_set(family=...) — they apply this preset — or start "
             "from this skeleton (regions in samples/map.json):", "", "```python", skeleton(family, q), "```"]
    return "\n".join(lines)
