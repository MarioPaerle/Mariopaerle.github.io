"""Figure checks (SPEC §8) and rasterisation, so the designer can see its drawing."""

from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

SVG_NS = "http://www.w3.org/2000/svg"
FORBIDDEN_TAGS = {"script", "image", "foreignObject", "iframe", "embed", "object", "audio", "video", "canvas"}


def _local(tag: str) -> str:
    return tag.split("}", 1)[1] if "}" in tag else tag


def validate_svg(text: str) -> list[str]:
    """Problems that break SPEC §8 (empty list = valid)."""
    probs: list[str] = []
    if len(text.encode()) > 400_000:
        probs.append(f"figure is {len(text.encode()) // 1000} KB; keep it under ~200 KB (simplify paths)")
    if re.search(r"<!DOCTYPE|<!ENTITY", text, re.I):
        return probs + ["no DOCTYPE/ENTITY declarations allowed"]
    try:
        root = ET.fromstring(text)
    except ET.ParseError as e:
        return probs + [f"not well-formed XML: {e}"]
    if _local(root.tag) != "svg":
        return probs + ["root element must be <svg>"]
    if not root.tag.startswith("{" + SVG_NS):
        probs.append('missing xmlns="http://www.w3.org/2000/svg"')
    vb = re.sub(r"[\s,]+", " ", (root.get("viewBox") or "").strip())
    if vb != "0 0 512 512":
        probs.append(f'viewBox must be "0 0 512 512" (got "{root.get("viewBox")}")')
    for el in root.iter():
        tag = _local(el.tag)
        if tag in FORBIDDEN_TAGS:
            probs.append(f"<{tag}> is not allowed (no scripts, raster images or embedded documents)")
        for k, v in el.attrib.items():
            kl = _local(k).lower()
            if kl.startswith("on"):
                probs.append(f"event handler attribute {kl} on <{tag}>")
            if kl == "href" and not v.strip().startswith("#"):
                probs.append(f"<{tag}> references '{v[:60]}': only local #ids are allowed")
            if "url(" in v and re.search(r"url\(\s*['\"]?(?!#)", v):
                probs.append(f"<{tag}> {kl} uses an external url(): only url(#id) is allowed")
            if "javascript:" in v.lower():
                probs.append(f"javascript: URL in <{tag}>")
        if tag == "style" and el.text:
            if "@import" in el.text or re.search(r"url\(\s*['\"]?(?!#)", el.text):
                probs.append("<style> may not @import or load external url()s (fonts included)")
    return sorted(set(probs))


def rasterize(text: str, size: int = 512, background: str = "#f3eee3") -> bytes:
    """PNG bytes of the SVG (resvg; falls back to macOS Quick Look)."""
    try:
        import resvg_py

        return bytes(resvg_py.svg_to_bytes(svg_string=text, width=size, height=size, background=background))
    except ImportError:
        pass
    ql = shutil.which("qlmanage")
    if not ql:
        raise RuntimeError("no SVG rasteriser: install resvg-py (uv sync --extra svg)")
    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / "figure.svg"
        src.write_text(text)
        subprocess.run([ql, "-t", "-s", str(size), "-o", td, str(src)], capture_output=True, timeout=30)
        out = Path(td) / "figure.svg.png"
        if not out.exists():
            raise RuntimeError("Quick Look could not render the SVG")
        return out.read_bytes()
