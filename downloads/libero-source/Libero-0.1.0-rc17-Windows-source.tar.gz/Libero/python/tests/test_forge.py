"""libero.forge: aliasing, tuning, wavetables, unison, filters, modulation, FX, voices, presets, guide."""

import asyncio
import math
import re
import time
from pathlib import Path

import numpy as np
import pytest

from libero import Audio, Sound, dsp, forge
from libero.forge import (FX, LFO, Env, Filter, ForgeError, Mod, Noise, Osc, Patch, Sub, Voice, Wavetable,
                          unison_cents)
from libero.forge import _kernels as K
from libero.forge.fx import FxCtx
from libero.forge.modulation import ModEngine, static_ranges
from libero.recipe import Ctx

SR = 48000
FLAT = Env(0.0, 0.1, 1.0, 0.05)


@pytest.fixture(scope="module", autouse=True)
def warm():
    """Compile every numba kernel once so the timing test measures rendering."""
    p = Patch("w", oscs=[Osc("saw", unison=2, warp1="fm", warp1_amount=0.1, warp2="sync", warp2_amount=0.1)],
              filters=[Filter(t, cutoff=1000) for t in ("lp12",)],
              lfos=[LFO("sh", mode="env"), LFO(), LFO(), LFO()], mods=[Mod("lfo1", "osc1.pos", 0.1)],
              fx=[FX.Hyper(), FX.Delay(), FX.Reverb(), FX.Compressor(), FX.MultibandComp(), FX.Phaser(), FX.Flanger(),
                  FX.Tape(), FX.Vinyl()])
    p.render(60, 100, 0.2, SR)
    for t in forge.FILTER_TYPES:
        Filter(t).response(SR, 1024)


def cents(a, b):
    return 1200.0 * math.log2(a / b)


def mono(a: Audio) -> np.ndarray:
    return dsp.mono(a.data.astype(np.float64))


def peak_freq(x, sr, guess, span=0.05):
    n = len(x) * 4
    X = np.abs(np.fft.rfft(x * np.hanning(len(x)), n))
    f = np.fft.rfftfreq(n, 1 / sr)
    m = (f > guess * (1 - span)) & (f < guess * (1 + span))
    i = np.flatnonzero(m)[np.argmax(X[m])]
    a, b, c = np.log(X[i - 1] + 1e-30), np.log(X[i] + 1e-30), np.log(X[i + 1] + 1e-30)
    d = 0.5 * (a - c) / (a - 2 * b + c)
    return (i + d) * sr / n


def plain(osc, **kw):
    return Patch("t", oscs=[osc], envs=[FLAT, Env(), Env(), Env()], volume_db=0.0, safe=False, **kw)


# ---------------------------------------------------------------- oscillator quality

@pytest.mark.parametrize("note", [108, 100, 93, 84])
def test_saw_does_not_alias(note):
    f0 = dsp.midi_to_freq(note)
    a = plain(Osc("saw", rand_phase=0.0)).render(note, 100, 1.0, SR, tail=0.0)
    x = mono(a)[int(0.2 * SR):int(0.9 * SR)]
    X = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2
    fr = np.fft.rfftfreq(len(x), 1 / SR)
    df = fr[1]
    mask = np.zeros(len(X), bool)
    k = 1
    while k * f0 < SR / 2:
        mask |= np.abs(fr - k * f0) < 10 * df
        k += 1
    assert 10 * np.log10(X[~mask].sum() / X.sum()) < -60


def test_naive_table_would_alias_but_mips_do_not():
    wt = Wavetable.classic("saw")
    top = wt.mips[0, 0]
    low = wt.mips[-4, 0]
    assert np.abs(np.fft.rfft(low))[10:].max() < 1e-6 * np.abs(np.fft.rfft(top)).max() + 1e-6
    assert wt.mips.shape[0] >= 18 and wt.mips.dtype == np.float32


@pytest.mark.parametrize("note", [24, 36, 48, 60, 69, 84, 100])
def test_tuning_within_one_cent(note):
    a = plain(Osc("sine", rand_phase=0.0)).render(note, 100, 1.0, SR, tail=0.0)
    f = peak_freq(mono(a)[2000:], SR, dsp.midi_to_freq(note), 0.04)
    assert abs(cents(f, dsp.midi_to_freq(note))) < 0.5


def test_osc_tuning_offsets():
    a = plain(Osc("sine", rand_phase=0.0, octave=1, semi=7, fine=-23)).render(48, 100, 1.0, SR, tail=0.0)
    want = dsp.midi_to_freq(48 + 12 + 7 - 0.23)
    assert abs(cents(peak_freq(mono(a)[2000:], SR, want, 0.05), want)) < 0.5


def test_pitch_modulation_is_exact_in_semitones():
    p = plain(Osc("sine", rand_phase=0.0))
    p.mods = [Mod("macro1", "pitch", 0.125)]
    a = p.render(60, 100, 1.0, SR, tail=0.0, macros={"macro1": 1.0})
    want = dsp.midi_to_freq(72)
    assert abs(cents(peak_freq(mono(a)[2000:], SR, want, 0.05), want)) < 0.5


def test_unison_detune_spread():
    note = 45
    f0 = dsp.midi_to_freq(note)
    for det in (0.3, 0.6):
        o = Osc("sine", unison=5, detune=det, rand_phase=0.0, blend=1.0)
        a = plain(o).render(note, 100, 4.0, SR, tail=0.0)
        x = mono(a)[SR // 2:]
        n = len(x) * 4
        X = np.abs(np.fft.rfft(x * np.hanning(len(x)), n))
        fr = np.fft.rfftfreq(len(x) * 4, 1 / SR)
        m = (fr > f0 * 0.95) & (fr < f0 * 1.05)
        pk = [i for i in np.flatnonzero(m)[1:-1] if X[i] > X[i - 1] and X[i] > X[i + 1] and X[i] > 0.2 * X[m].max()]
        got = sorted(cents(fr[i], f0) for i in pk)
        c = unison_cents(det)
        want = [c * u for u in (-1, -0.5, 0, 0.5, 1)]
        assert len(got) == 5
        assert max(abs(g - w) for g, w in zip(got, want)) < 1.5


def test_unison_cents_curve_and_limits():
    assert unison_cents(0) == 0 and abs(unison_cents(1) - 100) < 1e-9
    assert unison_cents(0.5) < unison_cents(0.8)
    with pytest.raises(ValueError):
        Osc("saw", unison=17)


def test_stereo_spread_and_random_phase_seed():
    wide = plain(Osc("saw", unison=8, spread=1.0)).render(48, 100, 0.5, SR, seed=3)
    narrow = plain(Osc("saw", unison=8, spread=0.0)).render(48, 100, 0.5, SR, seed=3)
    cw = np.corrcoef(wide.data[:, 0], wide.data[:, 1])[0, 1]
    cn = np.corrcoef(narrow.data[:, 0], narrow.data[:, 1])[0, 1]
    assert cn > 0.999 and cw < 0.9
    a = plain(Osc("saw", unison=4)).render(48, 100, 0.3, SR, seed=1, tail=0.0)
    b = plain(Osc("saw", unison=4)).render(48, 100, 0.3, SR, seed=2, tail=0.0)
    assert not np.allclose(a.data, b.data)
    c = plain(Osc("saw", unison=4, rand_phase=0.0, spread=0.0)).render(48, 100, 0.3, SR, seed=1, tail=0.0)
    d = plain(Osc("saw", unison=4, rand_phase=0.0, spread=0.0)).render(48, 100, 0.3, SR, seed=2, tail=0.0)
    assert np.allclose(c.data, d.data)


def test_blend_weights_centre_voice():
    o0 = Osc("saw", unison=5, blend=0.0)
    u, w, *_ = o0.layout(0.0, 0.5, 0)
    assert w[2] > 0.9 and w[0] < 1e-6
    u, w, *_ = o0.layout(1.0, 0.5, 0)
    assert np.allclose(w, w[0])


# ---------------------------------------------------------------- wavetables

def test_wavetable_morph_is_continuous():
    for name in ("sine_saw", "pwm", "vocal", "supersaw", "fm"):
        wt = Wavetable.classic(name)
        a = plain(Osc(wt, pos=0.40, rand_phase=0.0)).render(48, 100, 0.2, SR, tail=0.0)
        b = plain(Osc(wt, pos=0.402, rand_phase=0.0)).render(48, 100, 0.2, SR, tail=0.0)
        assert np.corrcoef(mono(a)[2000:], mono(b)[2000:])[0, 1] > 0.99, name
    p = plain(Osc("sine_saw", rand_phase=0.0))
    p.lfos = [LFO("saw", rate=1.0)]
    p.mods = [Mod("lfo1", "osc1.pos", 0.5, bipolar=False)]
    x = mono(p.render(48, 100, 1.0, SR, tail=0.0))
    assert np.max(np.abs(np.diff(x))) < 0.5


def test_classic_tables_all_build_and_are_normalised():
    from libero.forge import CLASSICS
    for name in CLASSICS:
        wt = Wavetable.classic(name)
        assert np.isfinite(wt.frames).all() and abs(wt.frames).max(axis=1).min() > 0.99, name
        assert wt.frames.shape[1] == 2048


def test_from_harmonics_and_additive():
    wt = Wavetable.from_harmonics([[0, 0, 1.0]])
    a = plain(Osc(wt, rand_phase=0.0)).render(48, 100, 1.0, SR, tail=0.0)
    f = dsp.midi_to_freq(48)
    assert abs(cents(peak_freq(mono(a)[2000:], SR, 3 * f, 0.05), 3 * f)) < 1.0
    wt2 = Wavetable.from_additive(lambda k, p: 1.0 / k * (k <= 2 + 20 * p), harmonics=32, frames=8)
    assert wt2.n_frames == 8
    s0, s1 = np.abs(np.fft.rfft(wt2.frame(0)))[:30], np.abs(np.fft.rfft(wt2.frame(1)))[:30]
    assert s1[10] > 20 * s0[10]


def test_from_formula_is_bandlimited_and_position_dependent():
    wt = Wavetable.from_formula(lambda ph, pos: np.where(ph < 0.5 - 0.4 * pos, 1.0, -1.0), frames=6)
    spec = np.abs(np.fft.rfft(wt.frames[0]))
    assert spec[1000:].max() < 1e-3 * spec[1:3].max() + 1e-9 or spec[1024] < 1e-6
    assert not np.allclose(wt.frames[0], wt.frames[-1])
    scalar = Wavetable.from_formula(lambda ph, pos: math.sin(2 * math.pi * ph) * (1 - pos), frames=3)
    assert scalar.n_frames == 3


def test_from_audio_cycle_resynthesis_keeps_pitch_and_spectrum():
    f = 220.0
    t = np.arange(SR) / SR
    x = sum(np.sin(2 * np.pi * f * k * t) / k for k in range(1, 9))
    src = Audio(0.3 * x, SR)
    wt = Wavetable.from_audio(src, frames=8, mode="cycle", f0=f)
    a = plain(Osc(wt, pos=0.5, rand_phase=0.0)).render(dsp.freq_to_midi(f), 100, 1.0, SR, tail=0.0)
    y = mono(a)[4000:]
    assert abs(cents(peak_freq(y, SR, f, 0.03), f)) < 1.0
    s = np.abs(np.fft.rfft(y * np.hanning(len(y))))
    fr = np.fft.rfftfreq(len(y), 1 / SR)
    amp = [s[np.argmin(abs(fr - k * f))] for k in (1, 2, 3, 4)]
    assert amp[1] / amp[0] == pytest.approx(0.5, rel=0.15) and amp[3] / amp[0] == pytest.approx(0.25, rel=0.2)
    one = Wavetable.from_cycle(Audio(np.sin(2 * np.pi * np.arange(300) / 300), SR))
    assert one.n_frames == 1
    auto = Wavetable.from_audio(src, frames=6)
    assert auto.n_frames == 6
    sl = Wavetable.from_audio(Audio(np.random.default_rng(0).standard_normal(SR), SR), frames=10, mode="window")
    assert sl.n_frames == 10
    sp = Wavetable.from_audio(src, frames=5, mode="spectral", f0=f)
    assert np.isfinite(sp.frames).all()


def test_wavetable_validation():
    with pytest.raises(ValueError):
        Wavetable.classic("nope")
    with pytest.raises(ValueError):
        Wavetable(np.array([[np.nan] * 16]))
    with pytest.raises(ValueError):
        Osc("saw", warp1="bogus")


@pytest.mark.parametrize("mode", list(forge.WARP_MODES))
def test_warp_modes_render_and_change_the_sound(mode):
    base = plain(Osc("saw", rand_phase=0.0, fm_src=1), ).render(48, 100, 0.3, SR, tail=0.0)
    o = Osc("saw", rand_phase=0.0, warp1=mode, warp1_amount=0.6, fm_src=1)
    p = Patch("t", oscs=[o, Osc("sine", octave=1, level=0.0, rand_phase=0.0)], envs=[FLAT, Env(), Env(), Env()],
              volume_db=0.0, safe=False)
    a = p.render(48, 100, 0.3, SR, tail=0.0)
    assert np.isfinite(a.data).all() and np.abs(a.data).max() < 4
    if mode != "none":
        assert not np.allclose(a.data[4000:], base.data[4000:], atol=1e-3)
    else:
        assert np.allclose(a.data[4000:], base.data[4000:], atol=1e-4)


def test_sync_raises_brightness_and_fm_adds_sidebands():
    def centroid(a):
        x = mono(a)[2000:]
        X = np.abs(np.fft.rfft(x * np.hanning(len(x))))
        f = np.fft.rfftfreq(len(x), 1 / SR)
        return float((X * f).sum() / X.sum())

    plainsaw = plain(Osc("saw", rand_phase=0.0)).render(48, 100, 0.5, SR, tail=0.0)
    sync = plain(Osc("saw", rand_phase=0.0, warp1="sync", warp1_amount=0.5)).render(48, 100, 0.5, SR, tail=0.0)
    assert centroid(sync) > 1.3 * centroid(plainsaw)
    p = Patch("t", oscs=[Osc("sine", rand_phase=0.0, warp1="fm", warp1_amount=0.4, fm_src=1),
                         Osc("sine", rand_phase=0.0, octave=1, level=0.0)], envs=[FLAT, Env(), Env(), Env()],
              volume_db=0.0, safe=False)
    fm = p.render(48, 100, 0.5, SR, tail=0.0)
    assert centroid(fm) > 1.5 * centroid(plain(Osc("sine", rand_phase=0.0)).render(48, 100, 0.5, SR, tail=0.0))


def test_osc_fm_cycle_is_rejected():
    p = Patch("t", oscs=[Osc("sine", warp1="fm", warp1_amount=0.3, fm_src=1), Osc("sine", warp1="fm", warp1_amount=0.3, fm_src=0)])
    with pytest.raises(ForgeError):
        p.render(60, 100, 0.1, SR)


def test_sub_and_noise_sources():
    p = Patch("t", oscs=[Osc("saw", level=0.0)], sub=Sub("sine", -1, 1.0), envs=[FLAT, Env(), Env(), Env()], volume_db=0.0, safe=False)
    a = p.render(60, 100, 1.0, SR, tail=0.0)
    assert abs(cents(peak_freq(mono(a)[2000:], SR, dsp.midi_to_freq(48), 0.05), dsp.midi_to_freq(48))) < 0.5
    n = Patch("t", oscs=[Osc("saw", level=0.0)], noise=Noise("pink", level=1.0), envs=[FLAT, Env(), Env(), Env()])
    a = n.render(60, 100, 0.5, SR, tail=0.0)
    assert a.rms_db > -40


def test_sample_based_noise_oscillator():
    rng = np.random.default_rng(1)
    rec = Audio(rng.standard_normal(SR // 2) * np.exp(-np.arange(SR // 2) / 8000.0), SR)
    p = Patch("t", oscs=[Osc("saw", level=0.0)], noise=Noise("sample", level=1.0, sample=rec, keytrack=True, root=60),
              envs=[FLAT, Env(), Env(), Env()])
    a = p.render(72, 100, 1.0, SR, tail=0.0, seed=2)
    b = p.render(72, 100, 1.0, SR, tail=0.0, seed=2)
    assert a.n == SR and np.allclose(a.data, b.data) and a.rms_db > -50
    with pytest.raises(ValueError):
        Patch("t", noise=Noise("sample", level=1.0)).render(60, 100, 0.1, SR)


# ---------------------------------------------------------------- filters

def _edge(f, db, fc, rising):
    idx = np.flatnonzero((f > fc * 0.3) & (f < fc * 3))
    d = db[idx] + 3.0103
    s = np.flatnonzero(np.diff(np.sign(d)) != 0)
    assert len(s), "no -3 dB crossing"
    j = idx[s[0]]
    return f[j] + (f[j + 1] - f[j]) * (-d[s[0]]) / (d[s[0] + 1] - d[s[0]])


@pytest.mark.parametrize("kind", ["lp12", "lp24", "hp12", "hp24"])
@pytest.mark.parametrize("fc", [300.0, 1000.0, 5000.0])
def test_filter_cutoff_within_5_percent(kind, fc):
    f, db = Filter(kind, cutoff=fc).response(SR, 32768)
    assert abs(_edge(f, db, fc, kind.startswith("hp")) - fc) / fc < 0.05
    i = np.argmin(abs(f - (fc * 2 if kind.startswith("lp") else fc / 2)))
    assert db[i] < (-20 if kind.endswith("12") and False else -10)
    if kind.endswith("24"):
        assert db[i] < -20


@pytest.mark.parametrize("kind,res", [("bp12", 0.5), ("bp24", 0.5), ("svf", 0.5)])
def test_band_filters_peak_at_cutoff(kind, res):
    f = Filter(kind, cutoff=1500.0, res=res, morph=0.5)
    fr, db = f.response(SR, 32768)
    m = (fr > 100) & (fr < 10000)
    assert abs(fr[m][np.argmax(db[m])] - 1500) / 1500 < 0.05


@pytest.mark.parametrize("kind", ["notch12", "notch24"])
def test_notch_centre(kind):
    fr, db = Filter(kind, cutoff=2000.0, res=0.6).response(SR, 32768)
    m = (fr > 300) & (fr < 8000)
    assert abs(fr[m][np.argmin(db[m])] - 2000) / 2000 < 0.05 and db[m].min() < -40


def test_ladder_resonance_peak_and_slope():
    fr, db = Filter("ladder", cutoff=1000.0, res=0.9).response(SR, 32768)
    m = (fr > 100) & (fr < 8000)
    assert abs(fr[m][np.argmax(db[m])] - 1000) / 1000 < 0.05 and db[m].max() - db[1] > 12
    f0, d0 = Filter("ladder", cutoff=1000.0, res=0.0).response(SR, 32768)
    assert d0[np.argmin(abs(f0 - 8000))] < -45


def test_diode_comb_phaser_flanger_formant_respond():
    fr, db = Filter("diode", cutoff=800.0, res=0.6).response(SR, 32768)
    assert db[np.argmin(abs(fr - 200))] > db[np.argmin(abs(fr - 6000))] + 20
    fr, db = Filter("comb+", cutoff=1000.0, res=0.8).response(SR, 32768)
    m = (fr > 500) & (fr < 1500)
    assert abs(fr[m][np.argmax(db[m])] - 1000) / 1000 < 0.05
    fr, db = Filter("comb-", cutoff=1000.0, res=0.8).response(SR, 32768)
    m = (fr > 50) & (fr < 700)
    assert abs(fr[m][np.argmax(db[m])] - 500) / 500 < 0.06
    for kind in ("phaser", "flanger"):
        fr, db = Filter(kind, cutoff=1500.0, res=0.4, morph=0.5).response(SR, 16384)
        assert np.isfinite(db).all() and db.max() - db.min() > 6
    fr, db = Filter("formant", cutoff=1000.0, res=0.5, morph=0.0).response(SR, 32768)
    m = (fr > 300) & (fr < 1400)
    assert 700 < fr[m][np.argmax(db[m])] < 900
    fr, db = Filter("formant", cutoff=1000.0, res=0.5, morph=1.0).response(SR, 32768)
    m = (fr > 150) & (fr < 1400)
    assert fr[m][np.argmax(db[m])] < 450


def test_filter_drive_saturates_and_stays_bounded():
    x = np.sin(2 * np.pi * 200 * np.arange(SR // 2) / SR)
    for kind in ("lp24", "ladder", "diode", "svf"):
        y0 = forge.apply_filter(kind, x, 1000.0, 0.3, 0.0, 0.0, SR)
        y1 = forge.apply_filter(kind, x * 4, 1000.0, 0.8, 1.0, 0.0, SR)
        assert np.isfinite(y1).all() and np.abs(y1).max() < 20
        assert np.abs(y0).max() < 3


def test_filter_in_patch_changes_spectrum_and_keytracks():
    def tilt(a):
        x = mono(a)[4000:]
        X = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2
        f = np.fft.rfftfreq(len(x), 1 / SR)
        return 10 * np.log10(X[(f > 6000) & (f < 12000)].sum() / X[(f > 300) & (f < 600)].sum())

    o = Osc("saw", rand_phase=0.0)
    open_ = plain(o, filters=[Filter("lp24", cutoff=15000)]).render(48, 100, 0.5, SR, tail=0.0)
    shut = plain(o, filters=[Filter("lp24", cutoff=800)]).render(48, 100, 0.5, SR, tail=0.0)
    assert tilt(open_) - tilt(shut) > 30
    kt = plain(Osc("noise_cycle", rand_phase=0.0), filters=[Filter("lp12", cutoff=1000, keytrack=1.0)])
    lo, hi = kt.render(36, 100, 0.5, SR, tail=0.0), kt.render(72, 100, 0.5, SR, tail=0.0)
    cl = (np.abs(np.fft.rfft(mono(lo))) * np.fft.rfftfreq(len(mono(lo)), 1 / SR)).sum()
    ch = (np.abs(np.fft.rfft(mono(hi))) * np.fft.rfftfreq(len(mono(hi)), 1 / SR)).sum()
    assert ch > cl


def test_dual_filter_routing_serial_and_parallel():
    o = Osc("noise_cycle", rand_phase=0.0)
    fl = [Filter("lp12", cutoff=500), Filter("hp12", cutoff=2000)]
    ser = plain(o, filters=fl).render(60, 100, 0.4, SR, tail=0.0)
    par = plain(o, filters=fl, filter_routing="parallel").render(60, 100, 0.4, SR, tail=0.0)
    assert ser.rms_db < par.rms_db - 10
    with pytest.raises(ForgeError):
        Patch("t", filters=[Filter(), Filter(), Filter()])


# ---------------------------------------------------------------- modulation

def test_env_shape_and_curves():
    e = Env(0.1, 0.2, 0.5, 0.3, curves=(0, 0, 0))
    n = int(1.2 * SR)
    trig = np.zeros(n, np.uint8)
    trig[0] = 1
    gate = np.zeros(n, np.uint8)
    gate[: int(0.6 * SR)] = 1
    y = e.render(trig, gate, SR)
    at = lambda t: y[int(t * SR)]
    assert at(0.05) == pytest.approx(0.5, abs=0.02) and at(0.1) == pytest.approx(1.0, abs=0.02)
    assert at(0.2) == pytest.approx(0.75, abs=0.02) and at(0.5) == pytest.approx(0.5, abs=0.01)
    assert at(0.75) == pytest.approx(0.25, abs=0.02) and at(1.0) < 0.001
    ex = Env(0.01, 0.5, 0.0, 0.1, curves=(0, -0.8, 0)).render(trig, gate, SR)
    lin = Env(0.01, 0.5, 0.0, 0.1, curves=(0, 0, 0)).render(trig, gate, SR)
    assert ex[int(0.15 * SR)] < lin[int(0.15 * SR)] - 0.1
    r = Env(0.01, 0.1, 1.0, 0.2, hold=0.05, delay=0.05).render(trig, gate, SR)
    assert r[int(0.02 * SR)] == 0.0 and r[int(0.12 * SR)] > 0.99


def test_env_retrigger_starts_from_current_level():
    e = Env(0.05, 0.1, 0.6, 0.1)
    n = SR
    trig = np.zeros(n, np.uint8)
    trig[0] = 1
    trig[int(0.3 * SR)] = 1
    gate = np.ones(n, np.uint8)
    y = e.render(trig, gate, SR)
    k = int(0.3 * SR)
    assert abs(y[k + 1] - y[k - 1]) < 0.05


def test_lfo_shapes_sync_modes_and_points():
    n = 2 * SR
    trig = np.zeros(n, np.uint8)
    trig[0] = 1
    for shape in ("sine", "tri", "saw", "ramp", "square", "sh", "smooth"):
        y = LFO(shape, rate=3.0, mode="free").render(trig, SR, 120.0)
        assert y.min() >= -1.0001 and y.max() <= 1.0001 and np.isfinite(y).all(), shape
    assert LFO(sync="1/4").rate_hz(120) == pytest.approx(2.0)
    assert LFO(sync="1/8t").rate_hz(120) == pytest.approx(6.0)
    assert LFO(sync="1/4.").rate_hz(120) == pytest.approx(4 / 3)
    assert LFO(sync=2.0).rate_hz(60) == pytest.approx(0.5)
    y = LFO("sine", sync="1/4").render(trig, SR, 120.0)
    assert int(np.sum((y[:-1] < 0) & (y[1:] >= 0))) in (3, 4)
    pts = LFO("points", rate=1.0, points=[(0, -1), (0.5, 1, 0.0), (1, -1)]).render(trig, SR, 120.0)
    assert pts[SR // 2] == pytest.approx(1.0, abs=0.01) and pts[0] == pytest.approx(-1.0, abs=0.01)
    t2 = np.zeros(n, np.uint8)
    t2[0] = t2[int(0.7 * SR)] = 1
    ty = LFO("saw", rate=1.0, mode="trig").render(t2, SR, 120.0)
    assert ty[int(0.7 * SR) + 2] < -0.99
    ey = LFO("saw", rate=2.0, mode="env").render(t2, SR, 120.0)
    assert ey[int(0.6 * SR)] > 0.99 and ey[int(0.69 * SR)] > 0.99
    d = LFO("square", rate=1.0, delay=0.5, mode="free").render(trig, SR, 120.0)
    assert np.all(d[: SR // 2 - 5] == 0)
    sm = LFO("square", rate=5.0, smooth=0.02).render(trig, SR, 120.0)
    assert np.max(np.abs(np.diff(sm))) < 0.2
    with pytest.raises(ForgeError):
        LFO("points")
    with pytest.raises(ForgeError):
        LFO(sync="banana").rate_hz(120)


def test_lfo_free_vs_trig_phase_and_determinism():
    n = SR
    tr = np.zeros(n, np.uint8)
    tr[0] = tr[SR // 3] = 1
    a = LFO("sh", rate=4.0).render(tr, SR, 120.0, seed=5)
    b = LFO("sh", rate=4.0).render(tr, SR, 120.0, seed=5)
    c = LFO("sh", rate=4.0).render(tr, SR, 120.0, seed=6)
    assert np.array_equal(a, b) and not np.array_equal(a, c)


def _engine(mods, src, n=10):
    return ModEngine(mods, src, static_ranges(2, 2, 4), n)


def test_mod_matrix_amount_scaling_bipolar_aux_curve():
    one, half = np.ones(10), np.full(10, 0.5)
    e = _engine([Mod("macro1", "filter1.cutoff", 0.1)], {"macro1": one})
    assert e.value("filter1.cutoff", 1000.0)[0] == pytest.approx(1000.0 * 1000.0 ** 0.1, rel=1e-9)
    e = _engine([Mod("macro1", "filter1.cutoff", 0.1, bipolar=True)], {"macro1": half})
    assert e.value("filter1.cutoff", 1000.0)[0] == pytest.approx(1000.0, rel=1e-9)
    e = _engine([Mod("lfo1", "osc1.pos", 0.5, bipolar=False)], {"lfo1": -np.ones(10)})
    assert e.value("osc1.pos", 0.5)[0] == pytest.approx(0.5)
    e = _engine([Mod("lfo1", "osc1.pos", 0.5)], {"lfo1": np.ones(10)})
    assert e.value("osc1.pos", 0.5)[0] == pytest.approx(1.0)
    e = _engine([Mod("lfo1", "osc1.pos", 0.4, aux="macro1")], {"lfo1": np.ones(10), "macro1": half})
    assert e.value("osc1.pos", 0.2)[0] == pytest.approx(0.4)
    e = _engine([Mod("a", "osc1.pos", 0.3), Mod("b", "osc1.pos", 0.4)], {"a": np.ones(10), "b": np.ones(10)})
    assert e.value("osc1.pos", 0.0)[0] == pytest.approx(0.7)
    e = _engine([Mod("a", "osc1.pos", 5.0)], {"a": np.ones(10)})
    assert e.value("osc1.pos", 0.0)[0] == 1.0
    assert e.value("osc2.pos", 0.3) == 0.3
    e = _engine([Mod("a", "osc1.pitch", 0.125)], {"a": np.ones(10)})
    assert e.value("osc1.pitch", 0.0)[0] == pytest.approx(12.0)


def test_mod_matrix_routes_to_every_parameter_kind():
    o1 = Osc("sine_saw", warp1="bend+", warp1_amount=0.1, warp2="asym+", warp2_amount=0.1, unison=3, rand_phase=0.0)
    p = Patch("t", oscs=[o1, Osc("saw")], sub=Sub("sine", -1, 0.2), noise=Noise("white", level=0.1),
              filters=[Filter("lp12", cutoff=2000), Filter("hp12", cutoff=100)],
              fx=[FX.Delay(), FX.Reverb(), FX.Chorus()], envs=[FLAT, Env(), Env(), Env()])
    for dst in ["osc1.pos", "osc1.warp1", "osc1.warp2", "osc1.pitch", "osc1.fine", "osc1.detune", "osc1.blend", "osc1.spread",
                "osc1.level", "osc1.pan", "osc2.pos", "sub.level", "noise.level", "filter1.cutoff", "filter1.res",
                "filter1.drive", "filter2.cutoff", "filter2.mix", "pitch", "volume", "lfo1.rate", "fx.delay.mix",
                "fx.reverb.mix", "fx.chorus.depth", "fx2.mix", "fx1.feedback"]:
        q = p.mod("macro1" if dst == "lfo1.rate" else "lfo1", dst, 0.2)
        a = q.render(60, 100, 0.2, SR, seed=1, tail=0.05)
        assert np.isfinite(a.data).all(), dst
    for dst in ["osc1.pos", "osc1.warp1", "osc1.pitch", "osc1.detune", "filter1.cutoff", "volume", "osc1.level", "osc1.pan"]:
        base = p.render(60, 100, 0.3, SR, seed=1, tail=0.0)
        mod = p.mod("macro1", dst, -0.3 if dst in ("volume", "osc1.level") else 0.3).render(60, 100, 0.3, SR, seed=1, tail=0.0, macros={"macro1": 1.0})
        assert not np.allclose(base.data, mod.data, atol=1e-4), dst
    zero = p.mod("macro1", "osc1.pos", 0.5).render(60, 100, 0.3, SR, seed=1, tail=0.0, macros={"macro1": 0.0})
    assert np.allclose(zero.data, p.render(60, 100, 0.3, SR, seed=1, tail=0.0).data)


def test_mod_matrix_errors_and_targets():
    p = Patch("t", oscs=[Osc("saw")], fx=[FX.Delay(), FX.Delay()])
    with pytest.raises(ForgeError, match="Close matches"):
        p.mod("lfo1", "filter1.cutof", 0.5)
    with pytest.raises(ForgeError, match="source"):
        p.mod("lfo9", "osc1.pos", 0.5)
    with pytest.raises(ForgeError):
        p.mod("lfo1", "fx.delay3.mix", 0.5)
    t = p.targets()
    assert "osc1.pos" in t and "fx.delay2.mix" in t and "fx1.feedback" in t and "osc2.pos" not in t
    assert "env4" in p.sources() and "macro1" in p.sources() and "velocity" in p.sources()


def test_envelope_to_filter_sweeps_the_spectrum_over_time():
    p = Patch("t", oscs=[Osc("noise_cycle", rand_phase=0.0)], filters=[Filter("lp24", cutoff=300)],
              envs=[FLAT, Env(0.0, 0.3, 0.0, 0.1, curves=(0, -0.5, 0)), Env(), Env()], volume_db=0.0, safe=False)
    p.mods = [Mod("env2", "filter1.cutoff", 0.45)]
    x = mono(p.render(48, 100, 0.6, SR, tail=0.0))

    def cen(seg):
        X = np.abs(np.fft.rfft(seg * np.hanning(len(seg))))
        return (X * np.fft.rfftfreq(len(seg), 1 / SR)).sum() / X.sum()

    assert cen(x[200:3000]) > 2 * cen(x[int(0.45 * SR):int(0.55 * SR)])


def test_velocity_note_random_and_macro_sources():
    p = Patch("t", oscs=[Osc("saw", level=0.0)], sub=Sub("sine", 0, 1.0), envs=[FLAT, Env(), Env(), Env()], vel_amp=0.0,
              volume_db=0.0, safe=False)
    p.mods = [Mod("velocity", "volume", -0.5, bipolar=False)]
    # volume base 1.0 -> velocity 1 lowers by 0.5, velocity 0 keeps 1.0 (clipped norm)
    lo = p.render(60, 20, 0.2, SR, tail=0.0).rms_db
    hi = p.render(60, 127, 0.2, SR, tail=0.0).rms_db
    assert lo > hi + 3
    r1 = p.mod("random", "volume", -0.5).render(60, 100, 0.2, SR, seed=1, tail=0.0)
    r2 = p.mod("random", "volume", -0.5).render(60, 100, 0.2, SR, seed=2, tail=0.0)
    assert abs(r1.rms_db - r2.rms_db) > 0.05
    k = p.mod("note", "volume", -0.5)
    assert k.render(36, 100, 0.2, SR, tail=0.0).rms_db > k.render(100, 100, 0.2, SR, tail=0.0).rms_db + 2
    w = p.mod("modwheel", "volume", -0.8)
    assert w.render(60, 100, 0.2, SR, tail=0.0, controls={"modwheel": 1.0}).rms_db < w.render(60, 100, 0.2, SR, tail=0.0).rms_db - 5


def test_lfo_rate_modulation_and_synced_lfo_in_patch():
    base = Patch("t", oscs=[Osc("sine", rand_phase=0.0)], lfos=[LFO("sine", rate=2.0, mode="free"), LFO(), LFO(), LFO()],
                 mods=[Mod("lfo1", "osc1.pitch", 0.01)], envs=[FLAT, Env(), Env(), Env()])
    a = base.render(60, 100, 0.5, SR, tail=0.0)
    b = base.mod("macro1", "lfo1.rate", 0.2).render(60, 100, 0.5, SR, tail=0.0, macros={"macro1": 1.0})
    assert not np.allclose(a.data, b.data)


# ---------------------------------------------------------------- fx

def run_fx(fx, x, sr=SR, n=None, idx=1, bpm=120.0):
    x = np.asarray(x, dtype=np.float64)
    return fx.process(x, FxCtx(sr, len(x), 7, bpm, None, idx))


def noise_in(n=SR, level=0.3, seed=0):
    return np.random.default_rng(seed).standard_normal((n, 2)) * level


def all_fx():
    return [
        FX.Distortion("tube"), FX.Distortion("soft", drive=1.0), FX.Distortion("hard", drive=1.0), FX.Distortion("diode", drive=1.0),
        FX.Distortion("fold", drive=1.0), FX.Distortion("bitcrush", bits=4.0), FX.Distortion("downsample", rate=4000.0),
        FX.Distortion("waveshaper", shaper=lambda x: np.sin(3 * x)), FX.Distortion("waveshaper", shaper=[-1, 0, 1]),
        FX.Flanger(feedback=0.9), FX.Flanger(feedback=-0.9), FX.Chorus(voices=4), FX.Hyper(voices=8), FX.Dimension(),
        FX.Phaser(feedback=0.9, stages=12), FX.Delay(feedback=0.95), FX.Delay(mode="pingpong", feedback=0.95),
        FX.Delay(sync="1/16", mode="mono"), FX.Reverb("plate", decay=20.0), FX.Reverb("hall", decay=20.0, size=2.0),
        FX.Reverb("room", decay=0.2, size=0.5), FX.Compressor(ratio=20.0, threshold=-40.0), FX.MultibandComp(depth=1.0),
        FX.MultibandComp(mode="up", depth=1.0), FX.MultibandComp(mode="down"),
        FX.EQ([("peak", 1000.0, 18.0, 4.0), ("lowshelf", 100.0, 12.0, 0.7), ("highshelf", 8000.0, -12.0, 0.7)]),
        FX.FilterFx("ladder", cutoff=800.0, res=1.0, drive=1.0), FX.FilterFx("comb+", cutoff=300.0, res=1.0),
        FX.Utility(width=2.0, mono_below=150.0), FX.Tape(wow=1.0, flutter=1.0, saturation=1.0, age=1.0),
        FX.Vinyl(crackle=1.0, pops=1.0, wear=1.0, warp=1.0),
    ]


@pytest.mark.parametrize("i", range(len(all_fx())))
def test_every_fx_is_finite_and_bounded(i):
    fx = all_fx()[i]
    x = np.clip(noise_in(SR, 0.6, 1), -1, 1)
    y = run_fx(fx, x)
    assert y.shape == x.shape and np.isfinite(y).all()
    assert np.abs(y).max() < 40, fx
    silent = run_fx(fx, np.zeros((SR // 2, 2)))
    assert np.isfinite(silent).all() and np.abs(silent).max() < 2.0


def test_fx_deterministic_per_seed():
    x = noise_in(SR // 2)
    for fx in (FX.Hyper(), FX.Tape(), FX.Vinyl()):
        assert np.array_equal(run_fx(fx, x), run_fx(fx, x))
    a = FX.Vinyl().process(np.zeros((SR // 2, 2)), FxCtx(SR, SR // 2, 1, 120, None, 1))
    b = FX.Vinyl().process(np.zeros((SR // 2, 2)), FxCtx(SR, SR // 2, 2, 120, None, 1))
    assert not np.array_equal(a, b)


def test_distortion_character_and_bitcrush_levels():
    s = np.sin(2 * np.pi * 1000 * np.arange(SR // 2) / SR)[:, None] * np.ones(2) * 0.5

    def h(y, k):
        X = np.abs(np.fft.rfft(y[:, 0] * np.hanning(len(y))))
        f = np.fft.rfftfreq(len(y), 1 / SR)
        return X[np.argmin(abs(f - k * 1000))]

    tube = run_fx(FX.Distortion("tube", drive=0.5, tone=24000.0), s)
    soft = run_fx(FX.Distortion("soft", drive=0.5, tone=24000.0), s)
    assert h(tube, 2) > 10 * h(soft, 2) and h(soft, 3) > 10 * h(soft, 2)
    bc = run_fx(FX.Distortion("bitcrush", bits=4.0, drive=0.0, tone=24000.0), s)
    assert len(np.unique(np.round(bc[:, 0], 6))) <= 17
    ds = run_fx(FX.Distortion("downsample", rate=4000.0, tone=24000.0, drive=0.0), s)
    assert len(np.unique(np.round(ds[:, 0], 6))) < 0.2 * len(ds) / 4
    dry = run_fx(FX.Distortion("hard", drive=1.0, mix=0.0), s)
    assert np.allclose(dry, s)


def test_delay_time_feedback_and_pingpong():
    x = np.zeros((SR, 2))
    x[0, 0] = 1.0
    y = run_fx(FX.Delay(time=100.0, feedback=0.5, mix=1.0, mode="mono", offset=1.0, lowpass=20000.0, highpass=1.0), x)
    echoes = np.flatnonzero(np.abs(y[:, 0]) > 0.05)
    assert abs(int(echoes[1] if echoes[0] == 0 else echoes[0]) - 4800) <= 1
    p1 = y[9600, 0] / y[4800, 0]
    assert 0.45 < p1 < 0.55
    pp = run_fx(FX.Delay(time=100.0, feedback=0.6, mix=1.0, mode="pingpong", lowpass=20000.0, highpass=1.0), x)
    assert abs(pp[4800, 0]) > 0.2 and abs(pp[4800, 1]) < 0.01 and abs(pp[9600, 1]) > 0.1 and abs(pp[9600, 0]) < 0.01
    sy = run_fx(FX.Delay(sync="1/8", mix=1.0, mode="mono"), x, bpm=120.0)
    assert abs(int(np.argmax(np.abs(sy[100:, 0]))) + 100 - 12000) <= 1


def test_reverb_decay_time_and_level():
    imp = np.zeros((2 * SR, 2))
    imp[0] = 1.0
    for kind, decay in (("plate", 1.0), ("hall", 2.0), ("room", 0.6)):
        y = run_fx(FX.Reverb(kind, decay=decay, damping=0.0, mix=1.0, lowcut=0.0, highcut=22000.0, predelay=0.0), imp)
        e = np.cumsum((y[:, 0] ** 2)[::-1])[::-1]
        db = 10 * np.log10(e / e[0] + 1e-30)
        t5, t25 = np.argmax(db < -5) / SR, np.argmax(db < -25) / SR
        rt60 = 3.0 * (t25 - t5)
        assert 0.6 * decay < rt60 < 1.5 * decay, (kind, rt60)
    x = noise_in(SR, 0.2)
    w = run_fx(FX.Reverb("plate", decay=1.5, mix=1.0), x) - x
    assert -10 < 20 * np.log10(w.std() / x.std()) < 8
    wet0 = run_fx(FX.Reverb(mix=0.0), x)
    assert np.allclose(wet0, x)


def test_compressor_gain_and_multiband():
    t = np.arange(SR) / SR
    s = (10 ** (-6 / 20)) * np.sin(2 * np.pi * 1000 * t)[:, None] * np.ones(2)
    y = run_fx(FX.Compressor(threshold=-18.0, ratio=4.0, attack=1.0, release=50.0, knee=0.0), s)
    lvl = 20 * np.log10(np.abs(y[SR // 2:, 0]).max())
    assert lvl == pytest.approx(-15.0, abs=0.8)
    assert np.allclose(run_fx(FX.Compressor(mix=0.0), s), s)
    quiet = 10 ** (-50 / 20) * np.sin(2 * np.pi * 500 * t)[:, None] * np.ones(2)
    up = run_fx(FX.MultibandComp(depth=1.0), quiet)
    assert 20 * np.log10(up[SR // 2:].std() / quiet[SR // 2:].std()) > 10
    loud = 10 ** (-3 / 20) * np.sin(2 * np.pi * 500 * t)[:, None] * np.ones(2)
    dn = run_fx(FX.MultibandComp(depth=1.0), loud)
    assert dn[SR // 2:].std() < loud[SR // 2:].std() * 0.8
    d0 = run_fx(FX.MultibandComp(depth=0.0), loud)
    assert d0[SR // 2:].std() == pytest.approx(loud[SR // 2:].std(), rel=0.05)


def test_eq_gain_at_frequency():
    t = np.arange(SR) / SR
    s = 0.1 * np.sin(2 * np.pi * 1000 * t)[:, None] * np.ones(2)
    y = run_fx(FX.EQ([("peak", 1000.0, 6.0, 1.0)]), s)
    assert 20 * np.log10(y[SR // 2:].std() / s[SR // 2:].std()) == pytest.approx(6.0, abs=0.3)
    y = run_fx(FX.EQ([("highpass", 4000.0, 0, 0.7)]), s)
    assert y[SR // 2:].std() < 0.1 * s.std()


def test_modulated_effects_widen_and_move():
    m = np.random.default_rng(3).standard_normal(SR) * 0.3
    x = np.stack([m, m], axis=1)
    for fx in (FX.Hyper(mix=1.0), FX.Chorus(mix=1.0, voices=3), FX.Dimension(mix=1.0)):
        y = run_fx(fx, x)
        assert np.corrcoef(y[:, 0], y[:, 1])[0, 1] < 0.97, fx
    t = np.arange(SR) / SR
    tone = 0.3 * np.sin(2 * np.pi * 800 * t)
    st = np.stack([tone, tone], axis=1)
    ph = run_fx(FX.Phaser(mix=1.0, depth=1.0, rate=1.0), st)
    assert ph[SR // 4:].std() < tone.std() * 0.99 or ph[SR // 4:].std() != tone.std()


def test_tape_wow_changes_pitch_and_vinyl_crackles():
    t = np.arange(2 * SR) / SR
    tone = np.sin(2 * np.pi * 1000 * t)[:, None] * np.ones(2) * 0.3
    still = run_fx(FX.Tape(wow=0.0, flutter=0.0, saturation=0.0, age=0.0, bump=0.0, hiss_db=None), tone)
    wob = run_fx(FX.Tape(wow=0.8, flutter=0.0, saturation=0.0, age=0.0, bump=0.0, hiss_db=None), tone)

    def f_track(y):
        out = []
        for s in range(SR // 2, 2 * SR - SR // 4, SR // 8):
            out.append(peak_freq(y[s:s + SR // 4, 0], SR, 1000.0, 0.05))
        return np.array(out)

    assert np.std([cents(f, 1000.0) for f in f_track(still)]) < 0.5
    assert np.std([cents(f, 1000.0) for f in f_track(wob)]) > 1.5
    assert wob.shape == tone.shape
    quiet = np.zeros((SR, 2))
    v = run_fx(FX.Vinyl(crackle=0.6, pops=0.0, hiss_db=None, rumble_db=None, wear=0.0, warp=0.0), quiet)
    kurt = float(np.mean(v[:, 0] ** 4) / np.mean(v[:, 0] ** 2) ** 2)
    assert kurt > 8 and np.abs(v).max() < 0.9
    off = run_fx(FX.Vinyl(crackle=0.0, pops=0.0, hiss_db=None, rumble_db=None, wear=0.0, warp=0.0), quiet)
    assert np.abs(off).max() < 1e-9
    a = run_fx(FX.Tape(hiss_db=-40.0), np.zeros((SR, 2)))
    assert a.std() > 1e-3


def test_fx_param_modulation_through_matrix():
    p = Patch("t", oscs=[Osc("saw", level=1.0)], fx=[FX.Delay(time=120.0, mix=0.0, feedback=0.4), FX.Reverb(mix=0.0)],
              envs=[FLAT, Env(), Env(), Env()])
    dry = p.render(60, 100, 0.3, SR, tail=0.6, seed=1)
    wet = p.mod("macro1", "fx.delay.mix", 0.5).render(60, 100, 0.3, SR, tail=0.6, seed=1, macros={"macro1": 1.0})
    assert not np.allclose(dry.data, wet.data)
    wet2 = p.mod("macro1", "fx2.mix", 0.5).render(60, 100, 0.3, SR, tail=0.6, seed=1, macros={"macro1": 1.0})
    assert not np.allclose(dry.data, wet2.data)


# ---------------------------------------------------------------- voices, rendering, presets

def test_determinism_and_stereo_output():
    p = forge.presets.supersaw_lead()
    a = p.render(60, 100, 0.5, SR, seed=4)
    b = p.render(60, 100, 0.5, SR, seed=4)
    c = p.render(60, 100, 0.5, SR, seed=5)
    assert a.is_stereo and a.sr == SR and np.array_equal(a.data, b.data) and not np.array_equal(a.data, c.data)
    assert a.data.dtype == np.float32 and np.isfinite(a.data).all()
    assert p.render("C4", 100, 0.5, SR, seed=4).n == a.n


def test_render_speed_two_osc_eight_unison_filter_fx():
    p = Patch("speed", oscs=[Osc("saw", unison=8, detune=0.3), Osc("square", unison=8, detune=0.2, octave=-1)],
              filters=[Filter("lp24", cutoff=2500, res=0.3, drive=0.2)],
              lfos=[LFO("sine", rate=3.0), LFO(), LFO(), LFO()], mods=[Mod("lfo1", "filter1.cutoff", 0.1), Mod("env2", "osc1.pos", 0.1)],
              fx=[FX.Hyper(), FX.Distortion("tube"), FX.Delay(), FX.Reverb("plate", decay=1.5), FX.Compressor()])
    p.render(48, 100, 2.0, SR)
    t = min(_time(lambda: p.render(48, 100, 2.0, SR, seed=2)) for _ in range(3))
    assert t < 1.0, t


def _time(fn):
    t = time.perf_counter()
    fn()
    return time.perf_counter() - t


def test_tail_and_duration_handling():
    p = Patch("t", oscs=[Osc("sine")], envs=[Env(0.0, 0.1, 1.0, 0.5), Env(), Env(), Env()])
    a = p.render(60, 100, 1.0, SR, tail=0.5)
    assert a.n == int(1.5 * SR)
    auto = p.render(60, 100, 1.0, SR)
    assert 1.0 < auto.duration < 2.2
    assert abs(auto.data[-1]).max() < 1e-3
    with pytest.raises(ForgeError):
        p.render_phrase([])


def test_phrase_poly_overlaps_and_mono_retriggers():
    notes = [(60, 0.0, 0.5), (64, 0.25, 0.5), (67, 0.5, 0.5)]
    p = Patch("t", oscs=[Osc("saw")], envs=[Env(0.005, 0.2, 0.8, 0.3), Env(), Env(), Env()], volume_db=-6.0)
    poly = p.render_phrase(notes, SR, seed=1)
    assert np.isfinite(poly.data).all() and poly.duration > 1.0
    mono_p = Patch("t", oscs=[Osc("saw")], envs=[Env(0.005, 0.2, 0.8, 0.3), Env(), Env(), Env()], voice=Voice("mono"))
    m = mono_p.render_phrase(notes, SR, seed=1)
    assert np.isfinite(m.data).all()
    seq = p.render_phrase([(60, 0.3), (62, 0.3)], SR, sequential=True)
    assert seq.duration > 0.6


def test_legato_glide_slides_and_hits_the_target():
    p = Patch("t", oscs=[Osc("sine", rand_phase=0.0)], envs=[Env(0.0, 0.1, 1.0, 0.1), Env(), Env(), Env()],
              voice=Voice("legato", glide=0.2, glide_shape="linear"), volume_db=0.0, safe=False)
    a = p.render_phrase([(60, 0.0, 0.6), (72, 0.5, 0.6)], SR, tail=0.1)
    x = mono(a)
    f_early = peak_freq(x[int(0.52 * SR):int(0.58 * SR)], SR, 400.0, 0.9)
    f_late = peak_freq(x[int(0.85 * SR):int(1.05 * SR)], SR, 523.25, 0.05)
    assert 262 < f_early < 520 and abs(cents(f_late, 523.25)) < 2
    f_first = peak_freq(x[int(0.1 * SR):int(0.4 * SR)], SR, 261.63, 0.05)
    assert abs(cents(f_first, 261.63)) < 1
    # legato overlap does not retrigger the envelope: no amplitude dip at the second note
    env_dip = np.abs(x[int(0.5 * SR):int(0.55 * SR)]).max() / np.abs(x[int(0.4 * SR):int(0.45 * SR)]).max()
    assert env_dip > 0.8
    p2 = Patch("t", oscs=[Osc("sine", rand_phase=0.0)], envs=[Env(0.05, 0.1, 1.0, 0.1), Env(), Env(), Env()],
               voice=Voice("mono", glide=0.0), volume_db=0.0, safe=False)
    a2 = p2.render_phrase([(60, 0.0, 0.6), (72, 0.5, 0.6)], SR, tail=0.1)
    assert np.abs(mono(a2)[int(0.5 * SR):int(0.51 * SR)]).max() < 0.9  # attack restarted from the held level


def test_set_copy_and_describe():
    p = forge.presets.pluck()
    q = p.set("filter1.cutoff", 1234.0).set("osc1.warp1", "sync").set("osc1.warp1", 0.3).set("env2.attack", 0.3)
    q = q.set("fx.reverb.mix", 0.5).set("macro1", 0.7).set("bpm", 90)
    assert p.filters[0].cutoff != 1234.0 and q.filters[0].cutoff == 1234.0
    assert q.oscs[0].warp1 == "sync" and q.oscs[0].warp1_amount == 0.3 and q.envs[1].attack == 0.3
    assert q.fx[1].mix == 0.5 and q.macros["macro1"] == 0.7 and q.bpm == 90
    with pytest.raises(ForgeError):
        p.set("filter9.cutoff", 1)
    with pytest.raises(ForgeError):
        p.set("osc1.nonsense", 1)
    assert "filter1" in p.describe() and "osc1" in p.describe()


def test_twenty_presets_render_cleanly():
    cat = forge.presets.catalog()
    assert len(cat) == 20
    for name, (lo, hi, desc) in cat.items():
        p = forge.presets.get(name)
        assert desc and p.description and p.tags
        note = lo + 12 if lo != hi else 60
        dur = 3.0 if name == "riser_whoosh" else (0.04 if name == "trap_hat" else 1.0)
        a = p.render(note, 100, dur, SR, seed=3)
        assert a.is_stereo and np.isfinite(a.data).all(), name
        assert -14 < a.peak_db <= -0.9 and a.rms_db > -40, (name, a.peak_db, a.rms_db)
        b = p.render(note, 100, dur, SR, seed=3)
        assert np.array_equal(a.data, b.data), name
    with pytest.raises(KeyError):
        forge.presets.get("nope")
    for name in ("acid_bass", "trap_808"):
        p = forge.presets.get(name)
        ph = p.render_phrase([(36, 0.0, 0.3), (39, 0.25, 0.3), (43, 0.5, 0.3)], SR, seed=1)
        assert np.isfinite(ph.data).all()


def test_preset_behaviours():
    p = forge.presets.trap_808()
    a = p.render(36, 110, 1.0, SR, seed=1)
    x = mono(a)
    f_late = peak_freq(x[int(0.5 * SR):int(0.9 * SR)], SR, dsp.midi_to_freq(36), 0.08)
    assert abs(cents(f_late, dsp.midi_to_freq(36))) < 15
    zc = lambda seg: np.sum((seg[:-1] < 0) & (seg[1:] >= 0)) / (len(seg) / SR)
    assert zc(x[int(0.001 * SR):int(0.02 * SR)]) > 1.3 * zc(x[int(0.5 * SR):int(0.9 * SR)])  # pitch drop starts above the root
    v = forge.presets.vocal_formant_lead()
    a0 = v.render(60, 100, 0.8, SR, macros={"macro1": 0.0}, seed=1)
    a1 = v.render(60, 100, 0.8, SR, macros={"macro1": 1.0}, seed=1)
    assert not np.allclose(a0.data[:48000], a1.data[:48000])
    r = forge.presets.riser(2.0).render(60, 100, 2.0, SR, seed=1)
    x = mono(r)
    q1, q4 = np.abs(x[:SR // 2]).mean(), np.abs(x[int(1.4 * SR):int(1.9 * SR)]).mean()
    assert q4 > 2 * q1
    w = forge.presets.wobble_bass().render(36, 100, 1.0, SR, seed=1)
    assert np.isfinite(w.data).all()


# ---------------------------------------------------------------- recipe integration

def test_layer_in_a_recipe_and_layering_with_a_recording(tmp_path):
    s = Sound(title="Forge test", roots=[48, 60], velocities=[60, 120], seed=3)
    s.body(forge.layer(forge.presets.pluck(), duration=0.4, normalize_db=-3.0))
    a = s.render("body", 60, 120)
    assert a.is_stereo and a.peak_db == pytest.approx(-3.0, abs=0.2) and a.sr == s.sample_rate
    b = s.render("body", 60, 120)
    assert np.array_equal(a.data, b.data)
    assert not np.array_equal(a.data, s.render("body", 60, 60).data)
    lo, hi = s.render("body", 48, 100), s.render("body", 60, 100)
    assert lo.rms_db != hi.rms_db

    rec = Audio(0.2 * np.sin(2 * np.pi * 261.63 * np.arange(SR) / SR), SR)
    (tmp_path / "samples").mkdir()
    rec.save(tmp_path / "samples" / "tone.wav")
    s2 = Sound(title="Layered", roots=[60])
    s2.folder = tmp_path
    s2.body(forge.stack(forge.layer(forge.presets.pluck(), duration=0.4), forge.recording("tone.wav", root=60, gain_db=-6),
                        gains_db=[0.0, 0.0]))
    out = s2.render("body", 72, 100)
    assert out.duration >= 0.9 and np.isfinite(out.data).all()
    s3 = Sound(title="Dyn", roots=[60], velocities=[100])
    s3.body(forge.layer(forge.presets.warm_pad(), duration=lambda c: 0.5, macros=lambda c: {"macro1": 0.2},
                        velocity=lambda c: 90, gain_db=-3))
    assert np.isfinite(s3.render("body", 60, 100).data).all()


# ---------------------------------------------------------------- guide and MCP

GUIDE = Path(forge.__file__).resolve().parent.parent / "guides" / "forge.md"


def test_guide_recipes_run():
    text = GUIDE.read_text()
    blocks = re.findall(r"```python\n(.*?)```", text, re.S)
    assert len(blocks) >= 10
    for code in blocks:
        ns = {"np": np}
        exec(compile(code, "forge-guide", "exec"), ns)


def test_guide_topic_served_and_documented():
    from libero import mcp_server
    out = asyncio.run(mcp_server.mcp.call_tool("guide", {"topic": "forge"}))
    text = out[0][0].text if isinstance(out, tuple) else out.content[0].text
    assert "Wavetable" in text and "Cookbook" in text
    for name in forge.presets.PRESETS:
        assert name in text, name
    sd = (GUIDE.parent / "sound_design.md").read_text()
    assert 'guide("forge")' in sd or "guide('forge')" in sd
