import json
import textwrap

import numpy as np
import pytest
import soundfile as sf

from libero import library
from libero.compiler import compile_sound
from libero.multisample import MultiSpec, Process, Region, edit_region, plan_regions, true_onset
from conftest import make_multisample


def _sound(folder, regs, process=None, extra=""):
    code = f"""
        from libero import Sound
        sound = Sound(title="Rec", tags=["plucked"])
        sound.multisample("body", {regs!r}, process={process or {}!r})
        {extra}
    """
    (folder / "sound.py").write_text(textwrap.dedent(code))


def test_plan_regions_fills_keys_and_maps_dynamics():
    regs = [Region.from_any({"file": f"n{r}_{v}.wav", "root": r, "vel": vr}, "body")
            for r in (40, 52, 64) for v, vr in (("p", (1, 50)), ("f", (70, 127)))]
    zs = plan_regions(MultiSpec("body", regs))
    by = {}
    for z in zs:
        by.setdefault(tuple(z["dyn"]), []).append((z["lo"], z["hi"]))
    assert len(by) == 2
    dyns = sorted(by)
    assert dyns[0][0] == 0.0 and dyns[-1][1] == 1.0 and abs(dyns[0][1] - dyns[1][0]) < 1e-9
    for ranges in by.values():
        ranges.sort()
        assert ranges[0][0] == 0 and ranges[-1][1] == 127
        assert all(b[0] == a[1] + 1 for a, b in zip(ranges, ranges[1:]))
    # one velocity layer stays a velocity zone
    zs1 = plan_regions(MultiSpec("body", regs[:1]))
    assert "dyn" not in zs1[0] and (zs1[0]["vel_lo"], zs1[0]["vel_hi"]) == (1, 127)


def test_explicit_rr_key_ranges_allow_distinct_physical_roots():
    # A played key can have RR takes sampled at neighboring pitches; the
    # explicit key range selects the played note while root preserves source
    # pitch for the engine's correct transposition.
    regs = [
        Region.from_any({"file": f"rr{i}.wav", "root": 56 + i, "lo": 56, "hi": 56,
                         "take": i, "vel": (1, 127)}, "body")
        for i in range(3)
    ]
    zones = plan_regions(MultiSpec("body", regs, process=Process(preserve_key_ranges=True)))
    assert [(z["root"], z["lo"], z["hi"], z["take"]) for z in zones] == [
        (56, 56, 56, 0), (57, 56, 56, 1), (58, 56, 56, 2)
    ]


def test_bad_regions_are_rejected():
    with pytest.raises(ValueError):
        Region.from_any({"file": "x.wav", "root": 60, "bogus": 1}, "body")
    with pytest.raises(ValueError):
        Region.from_any({"file": "x.wav", "rt_decay": 3}, "body")
    with pytest.raises(ValueError):
        Process.from_any({"tune": "sometimes"})


def test_twenty_genuine_takes_compile_and_play_in_native_engine():
    """A real library can exceed sixteen takes; retain and exercise all of them."""
    from libero import Sound, render
    from libero.recipe import RecipeError

    Sound(title="Boundary", takes=32)
    with pytest.raises(RecipeError):
        Sound(title="Boundary", takes=33)
    with pytest.raises(ValueError):
        Region.from_any({"file": "x.wav", "root": 60, "take": 32}, "body")
    folder = library.new_sound("twenty-takes", "plucked")
    samples = folder / "samples"
    regs = []
    sr = 48000
    t = np.arange(int(.45 * sr)) / sr
    for take in range(20):
        name = f"take-{take}.wav"
        # Distinct levels permit identification without exposing a test-only
        # take selector. Instrument calibration must preserve their contrasts.
        sf.write(samples / name, (.04 + .003 * take) * np.sin(2*np.pi*261.625565*t), sr, subtype="PCM_24")
        regs.append({"file": name, "root": 60, "take": take, "one_shot": True})
    _sound(folder, regs, {"tune": "none", "ladder": "keep", "align_ms": 0, "loop": "none"},
           "sound.performance(rr_reset_ms=1500, one_shot=True, humanize={'cents':0,'ms':0,'db':0})\n"
           "        sound.defaults(amp_attack=0, amp_release=10, rev_mix=0, lvl_attack=-60, lvl_tail=-60, lvl_air=-60)")
    result = compile_sound(folder, jobs=1)
    assert result.ok, result.error
    assert library.validate_bundle(folder / "build") == []
    manifest = json.loads((folder / "build/manifest.json").read_text())
    assert {z.get("take", 0) for z in manifest["zones"] if z["layer"] == "body"} == set(range(20))
    # The already-shipped native engine uses dynamically sized take groups.
    # Its deterministic random cycle must reach beyond the old sixteen limit.
    if render.find_renderer() is None:
        pytest.skip("native renderer unavailable; compiler assertion completed")
    file = folder / "twenty-native.wav"
    render.render(folder, file, [(60, i*.65, .35, 100) for i in range(200)], {}, tail=.1)
    x, sr = sf.read(file, always_2d=True)
    signatures = {round(float(np.sqrt(np.mean(x[round((i*.65+.08)*sr):round((i*.65+.25)*sr)]**2))), 4)
                  for i in range(200)}
    assert len(signatures) > 16, f"native engine reached only {len(signatures)} distinct takes"


def test_true_onset_finds_the_note_not_the_noise():
    from conftest import fake_recording

    a = fake_recording(60, -20, 0.3, pre_s=0.050, stereo=False)
    on = true_onset(a.data, a.sr)
    assert abs(on - int(0.050 * a.sr)) < int(0.002 * a.sr)


def test_multisample_compiles_to_calibrated_aligned_bundle():
    folder = library.new_sound("rec", "plucked")
    regs = make_multisample(folder, takes=2)
    _sound(folder, regs, {"tune": "detect", "max_seconds": 2.0},
           'sound.performance(humanize={"cents": 2, "ms": 3, "db": 0.5}, rr_reset_ms=1200)')
    res = compile_sound(folder)
    assert res.ok, res.error
    build = folder / "build"
    assert library.validate_bundle(build) == []
    m = json.loads((build / "manifest.json").read_text())
    assert m["format"] == "libero.bundle/2"
    assert m["dynamics"]["source"] == "velocity" and m["humanize"]["ms"] == 3 and m["rr_reset_ms"] == 1200
    body = [z for z in m["zones"] if z["layer"] == "body"]
    assert len(body) == 4 * 2 * 2 and all(z["file"].endswith(".flac") for z in body)
    assert {z["take"] for z in body} == {0, 1}
    # every file: starts with the fixed faded pre-roll, capped length, peak ≤ -0.3 dBFS
    onsets, peaks = [], {}
    for z in body:
        x, sr = sf.read(str(build / z["file"]), always_2d=True)
        assert len(x) <= 2.0 * sr + 0.004 * sr  # cap, plus at most the alignment padding
        assert abs(x[0]).max() < 1e-3
        onsets.append(true_onset(x.mean(axis=1), sr))
        peaks.setdefault(z["root"], {})[tuple(z["dyn"])] = 20 * np.log10(abs(x).max())
    assert max(onsets) - min(onsets) < int(0.0015 * sr)  # 4 ms of jitter in the sources is gone
    # natural ladder kept: the soft layer stays ~12 dB under the loud one (no per-file normalising)
    for root, d in peaks.items():
        lo, hi = sorted(d)
        assert 8 < d[hi] - d[lo] < 16
    top = max(max(d.values()) for d in peaks.values())
    assert -6.5 < top < -5.5  # default peak_db -6
    # recompiling is served from the caches
    res2 = compile_sound(folder)
    assert res2.ok


@pytest.mark.parametrize("transpose", [-300, 300])
def test_semitone_repacking_cannot_silently_clip_tuning(transpose):
    # A common key cell differs by three semitones from its actual recording.
    # Truncating this offset to ±100 creates wrong intervals on a playable key.
    from conftest import fake_recording
    folder = library.new_sound("repacked", "plucked")
    (folder / "samples").mkdir(exist_ok=True)
    fake_recording(60, -10, .5).save(folder / "samples" / "c.wav")
    _sound(folder, [{"file": "c.wav", "root": 60 + transpose // 100,
                     "tune_cents": transpose}], {"tune": "source"})
    res = compile_sound(folder)
    assert not res.ok
    assert "bundle limit ±100" in res.error and "never silently clipped" in res.error
    assert not (folder / "build" / "manifest.json").exists()


def test_detect_tuning_writes_tune_cents():
    folder = library.new_sound("tun", "plucked")
    (folder / "samples").mkdir(exist_ok=True)
    from conftest import fake_recording

    fake_recording(57, -10, 0.5, detune_cents=18, seed=4).save(folder / "samples" / "a.wav")
    _sound(folder, [{"file": "a.wav", "root": 57}], {"tune": "detect"})
    res = compile_sound(folder)
    assert res.ok, res.error
    z = json.loads((folder / "build" / "manifest.json").read_text())["zones"][0]
    assert z["tune_cents"] == pytest.approx(-18, abs=2)


def test_tail_keeps_its_level_under_the_body_and_rt_fields():
    folder = library.new_sound("tl", "plucked")
    regs = make_multisample(folder, roots=(60,), layers=((1, 127, -6, 0.7),))
    from libero import synth

    synth.noise("pink", 0.3, seed=1).fade_out(0.2).gain_db(-40).save(folder / "samples" / "rel.wav")
    _sound(folder, regs, {}, 'sound.multisample("tail", [{"file": "rel.wav", "root": 60, "rt_decay": 8, '
                             '"rt_min_db": -30}])')
    res = compile_sound(folder)
    assert res.ok, res.error
    m = json.loads((folder / "build" / "manifest.json").read_text())
    tail = [z for z in m["zones"] if z["layer"] == "tail"][0]
    assert tail["rt_decay"] == 8 and tail["rt_min_db"] == -30
    x, _ = sf.read(str(folder / "build" / tail["file"]))
    assert 20 * np.log10(abs(x).max()) < -25  # not normalised up to the body's level


def test_synthesised_dynamics_layers():
    folder = library.new_sound("dy", "plucked")
    (folder / "sound.py").write_text(textwrap.dedent("""
        from libero import Sound, synth
        sound = Sound(title="Dyn", roots=[48, 72], dynamics=[0.3, 0.9])
        @sound.body
        def body(ctx):
            return synth.karplus(ctx.freq, 1.0, bright=ctx.dyn, sr=ctx.sr, seed=ctx.seed).gain_db(-20 * (1 - ctx.dyn))
    """))
    res = compile_sound(folder)
    assert res.ok, res.error
    m = json.loads((folder / "build" / "manifest.json").read_text())
    assert m["format"] == "libero.bundle/2"
    dyns = sorted({tuple(z["dyn"]) for z in m["zones"]})
    assert dyns == [(0.0, 0.6), (0.6, 1.0)]
    assert library.validate_bundle(folder / "build") == []


def test_region_loop_none_beats_auto_loop():
    from libero.audio import Audio
    sr = 48000
    t = np.arange(int(6 * sr)) / sr
    x = 0.3 * np.sin(2 * np.pi * 440 * t) * np.minimum(1, t * 50)
    audio = Audio(x.astype(np.float32), sr)
    proc = Process(loop="auto", loop_min_s=1.0, max_seconds=6.0)
    _, facts = edit_region(audio, Region(file="x.wav", root=69), proc, sr)
    assert facts["loop"] is not None  # sanity: auto finds a loop in a steady tone
    _, facts = edit_region(audio, Region(file="x.wav", root=69, loop="none"), proc, sr)
    assert facts["loop"] is None


def test_short_source_hold_can_coexist_with_automatic_loops():
    from libero.audio import Audio

    sr = 48000
    t = np.arange(int(1.2 * sr)) / sr
    audio = Audio(.1 * np.sin(2 * np.pi * 220 * t), sr)
    proc = Process(loop="auto", loop_min_s=2, pre_ms=0, end_db=-100, fade_ms=0)
    markers = {"start": int(.3 * sr), "end": int(1.1 * sr)}
    # Legacy auto analysis still ignores unmarked source suggestions and cannot
    # invent a two-second sustain from this short recording.
    _, legacy = edit_region(audio, Region(file="short.wav", root=57, loop=markers), proc, sr)
    assert legacy["loop"] is None
    _, held = edit_region(audio, Region(file="short.wav", root=57,
                                      loop={**markers, "mode": "source"}), proc, sr)
    assert held["loop"] is not None
    assert held["loop"]["end"] - held["loop"]["start"] == markers["end"] - markers["start"]
    # Disabling the whole layer's loops remains an explicit override.
    _, finite = edit_region(audio, Region(file="short.wav", root=57,
                                        loop={**markers, "mode": "source"}),
                           Process(loop="none", pre_ms=0), sr)
    assert finite["loop"] is None


def test_unpitched_regions_keep_their_keys_and_fill_gaps_on_request():
    def reg(f, lo, hi, **kw):
        return Region.from_any({"file": f, "pitched": False, "lo": lo, "hi": hi, **kw}, "body")

    regs = [reg("a.wav", 36, 36), reg("b.wav", 42, 42), reg("c.wav", 46, 47), reg("e.wav", 50, 50)]
    zs = plan_regions(MultiSpec("body", regs))
    assert [(z["lo"], z["hi"]) for z in zs] == [(36, 36), (42, 42), (46, 47), (50, 50)]
    assert all(z["vel_lo"] == 1 and z["vel_hi"] == 127 and not z["pitched"] for z in zs)
    filled = plan_regions(MultiSpec("body", regs, fill_gaps=True))
    rs = sorted((z["lo"], z["hi"]) for z in filled)
    assert rs[0][0] == 0 and rs[-1][1] == 127 and all(b[0] == a[1] + 1 for a, b in zip(rs, rs[1:]))
    # no range given: the whole keyboard, as before
    whole = plan_regions(MultiSpec("body", [Region.from_any({"file": "x.wav", "pitched": False}, "body")]))
    assert (whole[0]["lo"], whole[0]["hi"]) == (0, 127)
    with pytest.raises(ValueError):
        plan_regions(MultiSpec("body", [reg("a.wav", 36, 40), reg("b.wav", 38, 42)]))
    # velocity layers of one key still tile that key only
    two = plan_regions(MultiSpec("body", [reg("a.wav", 36, 36, vel=(1, 60)), reg("b.wav", 36, 36, vel=(61, 127))]))
    assert {(z["lo"], z["hi"]) for z in two} == {(36, 36)} and len({tuple(z["dyn"]) for z in two}) == 2


def test_drum_flags_are_validated():
    for bad in ({"one_shot": 1}, {"choke_group": 0}, {"choke_group": "a"}, {"chokes": [0]}, {"chokes": 2}):
        with pytest.raises(ValueError):
            Region.from_any({"file": "a.wav", **bad}, "body")
    r = Region.from_any({"file": "a.wav", "one_shot": True, "choke_group": 2, "chokes": [3, 1, 3]}, "body")
    assert r.chokes == [1, 3]


def test_drum_kit_compiles_to_one_zone_per_key_with_flags():
    folder = library.new_sound("kit", "percussion")
    regs = make_multisample(folder, roots=(48, 55, 62, 69), layers=((1, 127, -6, 0.5),))
    for r in regs:
        r.update(pitched=False, lo=r["root"], hi=r["root"])
    regs[0].update(one_shot=True, choke_group=1)
    regs[1].update(choke_group=1)
    regs[2].update(chokes=[1], one_shot=False)
    _sound(folder, regs, {"tune": "none"}, "sound.performance(one_shot=True)")
    res = compile_sound(folder)
    assert res.ok, res.error
    build = folder / "build"
    assert library.validate_bundle(build) == []
    m = json.loads((build / "manifest.json").read_text())
    assert m["format"] == "libero.bundle/2" and m["one_shot"] is True
    body = sorted((z for z in m["zones"] if z["layer"] == "body"), key=lambda z: z["lo"])
    assert [(z["lo"], z["hi"], z["pitched"]) for z in body] == [(48, 48, False), (55, 55, False), (62, 62, False), (69, 69, False)]
    assert len({z["file"] for z in body}) == 4
    assert body[0]["one_shot"] is True and body[0]["choke_group"] == 1 and body[1]["choke_group"] == 1
    assert body[2]["chokes"] == [1] and body[2]["one_shot"] is False and "choke_group" not in body[3]


def test_validate_bundle_rejects_bad_drum_fields():
    folder = library.new_sound("kit2", "percussion")
    regs = make_multisample(folder, roots=(48,), layers=((1, 127, -6, 0.5),))
    _sound(folder, regs, {"tune": "none"})
    assert compile_sound(folder).ok
    build = folder / "build"
    m = json.loads((build / "manifest.json").read_text())
    m["format"] = "libero.bundle/2"
    m["zones"][0]["choke_group"] = 0
    m["zones"][0]["one_shot"] = "yes"
    m["one_shot"] = 1
    (build / "manifest.json").write_text(json.dumps(m))
    probs = " ".join(library.validate_bundle(build))
    assert "choke_group" in probs and "one_shot" in probs
