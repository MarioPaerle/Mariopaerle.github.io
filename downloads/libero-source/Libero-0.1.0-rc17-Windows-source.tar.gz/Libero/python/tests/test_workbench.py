from libero import library, workbench


def test_workbench_saves_result():
    folder = library.new_sound("wb", "plucked")
    r = workbench.run(folder, "result = synth.karplus(freq(57), 1.0, seed=2).fade_out(0.1)", "k")
    assert r.ok, r.error
    assert r.saved == ["k.wav"] and (folder / "samples" / "k.wav").exists()
    r = workbench.run(folder, "a = load('k')\nresult = {'up': a.pitch(12), 'down': a.pitch(-12)}", "k2")
    assert r.ok and sorted(r.saved) == ["k2_down.wav", "k2_up.wav"]


def test_workbench_timeout():
    folder = library.new_sound("wb2", "plucked")
    r = workbench.run(folder, "while True:\n    pass", "x", timeout=4)
    assert not r.ok and "timed out" in r.error


def test_workbench_no_network():
    folder = library.new_sound("wb3", "plucked")
    code = "import socket\nsocket.create_connection(('1.1.1.1', 80), timeout=2)\nresult = None"
    r = workbench.run(folder, code, "x", timeout=20)
    assert not r.ok and ("disabled" in r.error or "not permitted" in r.error)


def test_workbench_reports_errors_and_bad_names():
    folder = library.new_sound("wb4", "plucked")
    r = workbench.run(folder, "result = 3", "x")
    assert not r.ok and "not Audio" in r.error
    try:
        workbench.run(folder, "result = None", "../evil")
        raise AssertionError("bad out_name accepted")
    except library.LibraryError:
        pass
