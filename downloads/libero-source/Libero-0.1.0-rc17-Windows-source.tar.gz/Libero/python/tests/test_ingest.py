import json
import textwrap
from pathlib import Path

from types import SimpleNamespace

import pytest

from libero import library, licenses
from libero.compiler import compile_sound
from libero.ingest import BY_ID, SOURCES, import_sfz, import_wav_set, parse_name, parse_sfz, search
import libero.ingest.fetcher as F
from libero.ingest.sfz import take_index
from conftest import fake_recording

SFZ_MAIN = r"""
// a small instrument exercising the parts of SFZ real libraries use
#define $EXT wav
#define $RES 20
<control>
default_path=Samples\Piano\
set_hdcc$RES=0.5
<global> ampeg_release=0.4
<master> sw_last=c0 sw_default=c0 sw_lokey=c0 sw_hikey=c#0
<group> #include "inc/vel_lo.txt" lovel=1 hivel=64 #include "inc/regions.txt"
<group> #include "inc/vel_hi.txt" lovel=65 hivel=127 #include "inc/regions.txt"
<master> sw_last=c#0
<group> lovel=1 hivel=127 #include "inc/regions_alt.txt"
<global> trigger=release rt_decay=6
<master> locc$RES=1
<group> volume=-20
<region> key=48 sample=rel48.$EXT
<region> key=60 sample=rel60.$EXT
<global>
<group> on_locc64=127
<region> sample=pedal.$EXT
<global>
<group> seq_length=2 lokey=72 hikey=84 pitch_keycenter=78
<region> seq_position=1 sample=rr1.$EXT tune=-12 volume=-3
<region> seq_position=2 sample=rr2.$EXT amplitude=50
"""


def _write_sfz(root: Path):
    (root / "inc").mkdir(parents=True)
    (root / "inc" / "vel_lo.txt").write_text("#define $L p\n")
    (root / "inc" / "vel_hi.txt").write_text("#define $L f\n")
    (root / "inc" / "regions.txt").write_text(textwrap.dedent("""
        <region> lokey=c3 hikey=f#3 pitch_keycenter=c3 sample=C3$L.$EXT
        <region> lokey=g3 hikey=b3 pitch_keycenter=e4 sample=E4$L.$EXT loop_mode=loop_continuous loop_start=4000 loop_end=40000
    """))
    (root / "inc" / "regions_alt.txt").write_text("<region> key=60 sample=ALT.$EXT\n")
    (root / "main.sfz").write_text(SFZ_MAIN)
    s = root / "Samples" / "Piano"
    s.mkdir(parents=True)
    for name, note, lvl, br in (("C3p", 48, -18, 0.25), ("C3f", 48, -6, 0.8), ("E4p", 64, -18, 0.25),
                                ("E4f", 64, -6, 0.8), ("rr1", 78, -8, 0.5), ("rr2", 78, -8, 0.5)):
        fake_recording(note, lvl, br, seed=note + int(lvl)).save(s / f"{name}.wav")
    for name in ("rel48", "rel60", "pedal", "ALT"):
        fake_recording(60, -30, 0.2, seconds=0.4).save(s / f"{name}.wav")
    return root / "main.sfz"


def test_sfz_parser(tmp_path):
    ins = parse_sfz(_write_sfz(tmp_path / "lib"))
    names = sorted(r.sample.name for r in ins.regions)
    assert "ALT.wav" not in names and "pedal.wav" not in names  # other keyswitch bank, CC-triggered
    assert names.count("C3p.wav") == 1 and names.count("E4f.wav") == 1
    c3p = next(r for r in ins.regions if r.sample.name == "C3p.wav")
    assert (c3p.lokey, c3p.hikey, c3p.root, c3p.lovel, c3p.hivel) == (48, 54, 48, 1, 64)
    assert c3p.sample.exists() and c3p.ampeg_release == 0.4
    e4 = next(r for r in ins.regions if r.sample.name == "E4f.wav")
    assert (e4.root, e4.loop_mode, e4.loop_start, e4.loop_end) == (64, "loop_continuous", 4000, 40000)
    rel = [r for r in ins.regions if r.trigger == "release"]
    assert sorted(r.root for r in rel) == [48, 60] and rel[0].rt_decay == 6 and rel[0].gain_db == -20
    rr = sorted((r for r in ins.regions if r.sample.name.startswith("rr")), key=lambda r: r.sample.name)
    assert [take_index(ins.regions)[ins.regions.index(r)] for r in rr] == [0, 1]
    assert rr[0].tune_cents == -12 and rr[0].gain_db == -3 and rr[1].gain_db == pytest.approx(-6.02, abs=0.01)
    assert any("keyswitch" in w for w in ins.warnings) and any("controller" in w for w in ins.warnings)


def test_import_sfz_end_to_end(tmp_path):
    sfz = _write_sfz(tmp_path / "lib")
    cr = {"source": "Test Piano", "author": "Tester", "license": "CC BY 4.0", "license_class": "by",
          "url": "https://example.org"}
    rep = import_sfz("tpiano", sfz, family="piano", title="T Piano", credit=cr)
    assert rep["body_regions"] == 6 and rep["tail_regions"] == 2 and rep["license_class"] == "by"
    folder = Path(rep["folder"])
    m = json.loads((folder / "samples" / "map.json").read_text())
    assert m["tail"][0]["rt_decay"] == 6
    # the samples are linked into the sound folder, not duplicated
    f0 = folder / "samples" / m["body"][0]["file"]
    assert f0.exists() and f0.stat().st_nlink >= 2
    res = compile_sound(folder)
    assert res.ok, res.error
    build = folder / "build"
    assert library.validate_bundle(build) == []
    man = json.loads((build / "manifest.json").read_text())
    assert man["license"].startswith("CC BY 4.0") and man["credits"][0]["source"] == "Test Piano"
    assert (build / "ATTRIBUTION.md").read_text().count("Test Piano") == 1
    assert {z["layer"] for z in man["zones"]} == {"body", "tail"}
    assert any("take" in z and z["take"] == 1 for z in man["zones"])


def test_parse_name_variants():
    assert parse_name("Marimba_hit_Outrigger_C#4_loud_01") == {"note": 61, "dyn": 8, "dyn_label": "loud", "rr": 1}
    assert parse_name("JHPiano_Sus_Close_G#1_vl3_rr1")["note"] == 32
    p = parse_name("Vn-ord-A4-ff-4c-N")
    assert p["note"] == 69 and p["dyn"] == 8
    assert parse_name("Harpsi4_Rel_Main_B1_rr1")["release"] is True
    assert parse_name("GrandPno_Main_Sus_C0_v3_rr1")["dyn"] == 3
    assert parse_name("noise_take") == {}


def test_import_wav_set(tmp_path):
    src = tmp_path / "Marimba"
    (src / "Releases").mkdir(parents=True)
    for note, nn in (("C3", 48), ("G3", 55), ("D4", 62)):
        for dyn, lvl, br in (("soft", -20, 0.2), ("loud", -6, 0.8)):
            for rr in (1, 2):
                fake_recording(nn, lvl, br, seed=nn * rr).save(src / f"Marimba_hit_{note}_{dyn}_0{rr}.wav")
                fake_recording(nn, lvl - 3, br, seed=nn * rr + 5).save(src / f"Marimba_hit_{note}_{dyn}_0{rr}_Far.wav")
        fake_recording(nn, -30, 0.2, seconds=0.3).save(src / "Releases" / f"Marimba_rel_{note}.wav")
    rep = import_wav_set("mar", src, family="mallet", exclude="far")
    assert rep["body_regions"] == 12 and rep["tail_regions"] == 3 and rep["takes"] == 2
    assert rep["dynamics_levels"] == ["soft", "loud"]
    res = compile_sound(rep["folder"])
    assert res.ok, res.error
    assert library.validate_bundle(Path(rep["folder"]) / "build") == []


def test_budget_reduces_layers_then_roots(tmp_path):
    from libero.ingest.importers import Pick, fit_budget

    body = [Pick(Path(f"{r}_{v}.wav"), r, vr, 0, seconds=8.0, channels=2)
            for r in range(21, 109, 3) for v, vr in enumerate([(1, 30), (31, 60), (61, 90), (91, 127)])]
    chosen, info, notes = fit_budget(body, "piano", 0, 0, 0, 150.0)
    assert info["estimated_mb"] <= 150 and info["layers"] >= 3 and info["roots"] < 30 and notes


def test_catalog_is_consistent():
    ids = [s.id for s in SOURCES]
    assert len(ids) == len(set(ids))
    for s in SOURCES:
        assert s.license_class in licenses.CLASSES
        if s.fetch["type"] == "github":
            assert "/" in s.fetch["repo"] and s.fetch["branch"]
    assert search("grand piano")[0].id == "salamander-grand-v3"
    assert all(s.shippable for s in search("rhodes"))
    assert any(not s.shippable for s in search("rhodes", license="any"))
    assert BY_ID["vsco2-ce"].license_class == "cc0"


def test_fetch_plans_without_network(tmp_path, monkeypatch):
    src = BY_ID["vsco2-ce"]
    remote = tmp_path / "remote"
    (remote / "Strings" / "Harp").mkdir(parents=True)
    (remote / "Harp.sfz").write_text("<control> default_path=Strings\\Harp\\\n<region> key=60 sample=KSHarp_C4_mf.wav\n")
    fake_recording(60, -6, 0.5, seconds=0.5).save(remote / "Strings" / "Harp" / "KSHarp_C4_mf.wav")
    fake_recording(62, -6, 0.5, seconds=0.5).save(remote / "Strings" / "Harp" / "unused.wav")
    tree = [{"path": str(p.relative_to(remote)), "size": p.stat().st_size} for p in remote.rglob("*") if p.is_file()]
    monkeypatch.setattr(F, "github_tree", lambda s, refresh=False: tree)

    def fake_download(url, dst, expect=-1, lfs_url=None, client=None):
        rel = url.split(f"/{src.fetch['branch']}/", 1)[1]
        from urllib.parse import unquote

        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes((remote / unquote(rel)).read_bytes())

    monkeypatch.setattr(F, "_download", fake_download)
    # The 5 GB free-disk guard is right; the test must not depend on the machine's free space.
    monkeypatch.setattr(F.shutil, "disk_usage", lambda _p: SimpleNamespace(total=10**12, used=10**11, free=9 * 10**11))
    plan = F.make_plan("vsco2-ce", "sfz:Harp.sfz")
    assert sorted(p for p, _, _ in plan.files) == ["Harp.sfz", "Strings/Harp/KSHarp_C4_mf.wav"]
    rep = F.fetch("vsco2-ce", "sfz:Harp.sfz")
    assert rep["status"] == "ok" and rep["audio_files"] == 1
    assert (F.library_dir("vsco2-ce") / "Strings/Harp/KSHarp_C4_mf.wav").exists()
    globbed = F.make_plan("vsco2-ce", "Strings/Harp/*")
    assert len(globbed.files) == 2
    with pytest.raises(F.FetchError):
        F.fetch("vsco2-ce", "Strings/Harp/*", max_mb=0.00001)
    big = [{"path": "Strings/Harp/huge.wav", "size": 900_000_000}]
    monkeypatch.setattr(F, "github_tree", lambda s, refresh=False: big)
    assert "confirm=True" in F.fetch("vsco2-ce", "Strings/Harp/*")["status"]
    with pytest.raises(F.FetchError):
        F.make_plan("openair", "")


def test_licence_class_propagates(libero_home):
    folder = library.new_sound("lic", "plucked")
    licenses.add_credit(folder, {"source": "A", "license": "CC0", "license_class": "cc0"})
    licenses.add_credit(folder, {"source": "B", "license": "CC BY-NC 4.0", "license_class": "nc"})
    text, cls = licenses.bundle_license(licenses.read_credits(folder))
    assert cls == "nc" and "private" in text
    from libero.mcp_server import sound_save

    assert "WARNING" in sound_save("lic")
