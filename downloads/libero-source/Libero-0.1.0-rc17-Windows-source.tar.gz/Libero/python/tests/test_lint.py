import json
import textwrap
from types import SimpleNamespace

import numpy as np
import soundfile as sf

from libero import library
from libero.compiler import compile_sound
from libero.lint import _onset_offsets, lint_bundle, lint_text
from libero.multisample import true_onset
from conftest import make_multisample


def _build(slug, layers=((1, 60, -13, 0.2), (61, 127, -6, 0.85)), takes=2):
    folder = library.new_sound(slug, "plucked")
    regs = make_multisample(folder, layers=layers, takes=takes)
    (folder / "sound.py").write_text(textwrap.dedent(f"""
        from libero import Sound
        sound = Sound(title="L", tags=["mallet"])
        sound.multisample("body", {regs!r}, process={{"tune": "detect", "max_seconds": 2.0, "max_step_db": 7.5}})
    """))
    res = compile_sound(folder)
    assert res.ok, res.error
    return folder / "build"


def test_lint_clean_multisample():
    build = _build("lclean")
    fs = lint_bundle(build)
    bad = [f.line() for f in fs if f.level in ("FAIL", "WARN") and f.check not in ("layers", "takes")]
    assert bad == [], bad


def test_lint_catches_defects():
    build = _build("ldef")
    m = json.loads((build / "manifest.json").read_text())
    body = [z for z in m["zones"] if z["layer"] == "body"]
    # a click: overwrite the first samples of one zone with a step
    f = build / body[0]["file"]
    x, sr = sf.read(str(f), always_2d=True)
    x[:10] = 0.5
    sf.write(str(f), x, sr, format="FLAC", subtype="PCM_24")
    # a broken ladder: make the loud layer of one key quieter than its soft layer
    loud = next(z for z in body if z["root"] == 55 and z["dyn"][1] == 1.0 and z.get("take", 0) == 0)
    g = build / loud["file"]
    y, sr = sf.read(str(g), always_2d=True)
    sf.write(str(g), y * 0.05, sr, format="FLAC", subtype="PCM_24")
    # two identical takes
    t0 = next(z for z in body if z["root"] == 62 and z.get("take", 0) == 0 and z["dyn"][0] == 0.0)
    t1 = next(z for z in body if z["root"] == 62 and z.get("take", 0) == 1 and z["dyn"][0] == 0.0)
    (build / t1["file"]).write_bytes((build / t0["file"]).read_bytes())
    text = lint_text(build)
    assert "FAIL click" in text and "FAIL ladder" in text and "round robins nearly identical" in text


def test_lint_flags_missing_release_for_piano():
    folder = library.new_sound("lpiano", "plucked")
    regs = make_multisample(folder, layers=((1, 50, -18, 0.2), (51, 90, -12, 0.5), (91, 127, -6, 0.85)))
    (folder / "sound.py").write_text(textwrap.dedent(f"""
        from libero import Sound
        sound = Sound(title="P", tags=["piano"])
        sound.multisample("body", {regs!r})
    """))
    assert compile_sound(folder).ok
    assert "WARN release" in lint_text(folder / "build")


def _performed_note(phase, dyn, take=0, delay_ms=0):
    sr = 48000
    t = np.arange(sr // 2) / sr
    # Same physical attack, different carrier phase: independent performances.
    x = 0.18 * np.exp(-t / 0.0008)
    x += 0.6 * np.sin(2 * np.pi * 110 * t + phase) * np.minimum(t / 0.008, 1)
    delay = round(delay_ms * sr / 1000)
    if delay:
        x = np.pad(x, (delay, 0))[:len(t)]
    return SimpleNamespace(head=x, sr=sr, onset=true_onset(x, sr),
                           z={"dyn": dyn, "take": take, "vel_lo": 1, "vel_hi": 127})


def test_independent_phase_is_not_a_delay_in_hard_switched_dynamics():
    notes = [_performed_note(0, [0, 0.5]), _performed_note(1.3, [0.5, 1])]
    assert _onset_offsets(notes, 0) == (0, 0)
    timing, phase_shift = _onset_offsets(notes, 0.3)
    assert timing == 0
    assert phase_shift > 1  # Same recordings are unsafe to phase-blend.


def test_round_robins_are_selected_even_when_dynamics_crossfade():
    notes = [_performed_note(0, [0, 1]), _performed_note(1.3, [0, 1], take=1)]
    assert _onset_offsets(notes, 0.3) == (0, 0)


def test_delayed_hard_switched_performance_remains_visible():
    notes = [_performed_note(0, [0, 0.5]), _performed_note(1.3, [0.5, 1], delay_ms=12)]
    timing, phase_shift = _onset_offsets(notes, 0)
    assert timing > 10
    assert phase_shift == 0
