"""Library previews (build/preview.m4a): what gets played, and that compile writes one."""

import json

import pytest

from libero import preview, render


def _zone(layer="body", root=60, lo=None, hi=None, pitched=True, **kw):
    return {"layer": layer, "file": f"{layer}_{root}.wav", "root": root, "pitched": pitched,
            "lo": root if lo is None else lo, "hi": root if hi is None else hi, **kw}


def _notes(s):
    return [tuple(float(x) for x in n.split(":")) for n in s.split(",")]


def test_pitched_phrase_sits_in_the_main_register():
    zones = [_zone(root=r, lo=r - 1, hi=r + 1) for r in range(36, 85, 3)]
    notes, kind = preview.plan({"tags": ["plucked"], "zones": zones})
    assert kind == "pitched"
    pitches = [int(n[0]) for n in _notes(notes)]
    assert min(pitches) >= 54 and max(pitches) <= 85 + 12
    assert max(n[1] + n[2] for n in _notes(notes)) < 5.0


def test_bass_gets_a_riff_without_thirds():
    zones = [_zone(root=r, lo=r - 1, hi=r + 1) for r in range(24, 50, 3)]
    notes, _ = preview.plan({"tags": ["bass"], "zones": zones})
    assert all((int(n[0]) - 24) % 12 in (0, 7, 10, 5, 2, 9, 4, 11, 1, 3, 6, 8) for n in _notes(notes))
    assert max(int(n[0]) for n in _notes(notes)) < 48 + 13


def test_kit_gets_a_two_bar_groove_in_the_playable_octave():
    zones = [_zone(root=k, pitched=False, choke_group=1) for k in (36, 38, 40, 42, 44, 46, 60, 61)]
    notes, kind = preview.plan({"tags": ["drums"], "zones": zones})
    assert kind == "kit"
    ns = _notes(notes)
    assert {int(n[0]) for n in ns} <= {36, 38, 40, 42, 44, 46}
    assert 4.0 < max(n[1] for n in ns) + 0.2 < 5.0 and len(ns) >= 20


def test_one_shot_bank_plays_its_hits_in_sequence():
    zones = [_zone(root=k, pitched=False) for k in range(48, 60)]
    notes, kind = preview.plan({"tags": ["guitar", "chords"], "zones": zones})
    assert kind == "hits" and len(_notes(notes)) == 8


def test_oscillator_only_sound():
    _, kind = preview.plan({"tags": ["lead", "synth"], "zones": []})
    assert kind == "oscillator"


@pytest.mark.skipif(render.find_renderer() is None, reason="libero-render not built")
def test_make_preview_writes_a_small_normalised_file(tmp_path):
    from libero.audio import Audio

    build = tmp_path / "s" / "build"
    build.mkdir(parents=True)
    (build / "manifest.json").write_text(json.dumps({
        "format": "libero.bundle/2", "slug": "s", "title": "S", "subtitle": "", "tags": ["lead"], "description": "",
        "sample_rate": 48000, "compiled_at": "x", "source_hash": "0" * 64, "zones": [], "ir": None,
        "params": {"osc1_level": 0, "osc1_wave": "Sega"}}))
    out = preview.make_preview(tmp_path / "s")
    assert out is not None and out.exists() and out.stat().st_size < 150_000
    a = Audio.load(out) if out.suffix == ".wav" else None
    if a is not None:
        assert 4.0 < a.duration <= 6.01 and abs(a.lufs - preview.TARGET_LUFS) < 1.5
