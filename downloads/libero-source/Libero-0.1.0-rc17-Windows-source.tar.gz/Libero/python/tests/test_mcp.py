import asyncio
import os
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

EXPECTED = {
    "guide", "params_reference", "sound_new", "sound_list", "sound_read", "sound_write", "sound_save",
    "sound_discard", "sample_list", "sample_import", "freesound_search", "freesound_download", "workbench",
    "sample_trim", "sample_pitch", "sample_stretch", "sample_layer", "sample_convolve", "sample_filter",
    "sample_fade", "sample_normalize", "sample_noise_floor", "sample_attach_transient", "synth_generate",
    "analyze", "spectrogram", "waveform", "compare", "compile", "preview", "figure_view", "plugin_instances",
    "plugin_load", "plugin_get_params", "plugin_set_params", "plugin_play", "plugin_status",
    "plugin_reload", "plugin_reset", "plugin_save_as",
    "library_search", "library_info", "library_fetch", "import_sfz", "import_wav_set", "family_preset", "lint",
    "sound_licenses", "sample_trim_onset", "sample_align", "sample_ladder", "sample_release", "sample_morph",
    "sample_texture", "sample_split",
    "bank_create", "bank_list", "bank_add", "bank_pack", "bank_install",
}


async def _session_run(fn):
    env = dict(os.environ)
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1])
    params = StdioServerParameters(command=sys.executable, args=["-m", "libero.mcp_server"], env=env)
    async with stdio_client(params) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            return await fn(s)


def test_server_lists_tools_and_works():
    async def body(s):
        tools = {t.name: t for t in (await s.list_tools()).tools}
        assert EXPECTED <= set(tools)
        assert all(len(t.description or "") > 40 for t in tools.values())
        out = {}
        out["params"] = await s.call_tool("params_reference", {})
        out["new"] = await s.call_tool("sound_new", {"slug": "mcp-test", "template": "bell"})
        out["gen"] = await s.call_tool("synth_generate", {"slug": "mcp-test", "kind": "karplus",
                                                           "params": {"note": "A3", "dur": 1.0}, "out_name": "k"})
        out["spec"] = await s.call_tool("spectrogram", {"slug": "mcp-test", "sample": "k"})
        out["trav"] = await s.call_tool("sound_read", {"slug": "mcp-test", "file": "../../x"})
        out["guide"] = await s.call_tool("guide", {"topic": "recipe_api"})
        return out

    out = asyncio.run(_session_run(body))
    assert "rev_mode" in out["params"].content[0].text
    assert not out["new"].isError and "sound.py" in out["new"].content[0].text
    assert not out["gen"].isError and [c.type for c in out["gen"].content] == ["text", "image"]
    assert "A3" in out["gen"].content[0].text
    assert out["spec"].content[0].type == "image" and out["spec"].content[0].mimeType == "image/png"
    assert out["trav"].isError
    assert "karplus" in out["guide"].content[0].text
