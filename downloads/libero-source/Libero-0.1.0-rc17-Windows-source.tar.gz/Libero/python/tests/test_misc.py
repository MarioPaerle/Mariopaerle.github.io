import json

import pytest

from libero import params, render
from libero.figure import rasterize, validate_svg

GOOD_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
<defs><linearGradient id="g"><stop offset="0" stop-color="#f3eee3"/><stop offset="1" stop-color="#b08a3a"/></linearGradient></defs>
<rect width="512" height="512" fill="url(#g)"/><circle cx="256" cy="256" r="120" fill="none" stroke="#1d1a24"/></svg>"""


def test_params_validation():
    assert params.validate({"rev_mode": "cisterna", "rev_mix": 0.3}) == {"rev_mode": "Cisterna", "rev_mix": 0.3}
    assert params.validate({"reverb_mode": 1}) == {"rev_mode": "Basilica"}
    assert params.validate({"voices": 8}) == {"voices": 8}
    for bad in ({"rev_mix": 2}, {"nope": 1}, {"rev_mode": "Hall"}, {"voices": 3.5}):
        with pytest.raises(params.ParamError):
            params.validate(bad)
    assert len(params.PARAMS) == 110 and "| `rev_shimmer` |" in params.reference_markdown()
    assert params.defaults()['caldi_mode'] == 'Spento'
    assert params.validate({'caldi_mode': 'Blu', 'caldi_amount': .65, 'caldi_output': -12})['caldi_output'] == -12


def test_figure_checks():
    assert validate_svg(GOOD_SVG) == []
    bad = GOOD_SVG.replace('viewBox="0 0 512 512"', 'viewBox="0 0 100 100"').replace(
        "</svg>", '<script>alert(1)</script><image href="http://x/y.png"/><rect fill="url(http://x)"/></svg>')
    probs = " ".join(validate_svg(bad))
    for word in ("viewBox", "script", "image", "url"):
        assert word in probs
    assert validate_svg("<!DOCTYPE svg [<!ENTITY a 'x'>]><svg/>")
    png = rasterize(GOOD_SVG, 128)
    assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_parse_notes():
    assert render.parse_notes("60:0:1.2:100,64:0.5:1.0:90") == [(60, 0.0, 1.2, 100), (64, 0.5, 1.0, 90)]
    seq = render.parse_notes("48 60 C5")
    assert [n[0] for n in seq] == [48, 60, 72] and seq[1][1] > seq[0][1]
    chord = render.parse_notes("60+64+67")
    assert len({n[1] for n in chord}) == 1
    with pytest.raises(Exception):
        render.parse_notes("200")


@pytest.mark.skipif(render.find_renderer() is None, reason="libero-render not built")
def test_preview_through_renderer():
    from libero import library

    library.new_sound("pv", "plucked")
    pv = render.preview("pv", "60 67", {"rev_mix": 0.1})
    assert pv.wav.exists() and pv.audio.duration > 1.0


def test_plugin_discovery_skips_dead(libero_home):
    from libero import plugin

    d = libero_home / "instances"
    d.mkdir(parents=True)
    (d / "dead.json").write_text(json.dumps({"id": "dead", "port": 47899, "pid": 999999}))
    import os

    (d / "me.json").write_text(json.dumps({"id": "me", "port": 47898, "pid": os.getpid()}))
    live = plugin.instances()
    assert [i["id"] for i in live] == ["me"]


def test_plugin_client_roundtrip(libero_home):
    """A fake plugin speaking SPEC §6 newline-delimited JSON."""
    import os
    import socket
    import threading

    from libero import plugin

    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen()
    port = srv.getsockname()[1]

    def serve():
        for _ in range(2):
            c, _ = srv.accept()
            req = json.loads(c.makefile().readline())
            if req["method"] == "boom":
                c.sendall((json.dumps({"id": req["id"], "error": "nope"}) + "\n").encode())
            else:
                c.sendall((json.dumps({"id": req["id"], "result": {"ok": True, "echo": req["params"]}}) + "\n").encode())
            c.close()

    threading.Thread(target=serve, daemon=True).start()
    d = libero_home / "instances"
    d.mkdir(parents=True)
    (d / "x.json").write_text(json.dumps({"id": "x", "port": port, "pid": os.getpid()}))
    assert plugin.call("note", pitch=60)["echo"] == {"pitch": 60}
    with pytest.raises(plugin.PluginError, match="nope"):
        plugin.call("boom")
    srv.close()
