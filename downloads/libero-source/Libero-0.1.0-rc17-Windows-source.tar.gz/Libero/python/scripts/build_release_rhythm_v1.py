#!/usr/bin/env python3
"""Build the eight isolated -libero release-replacement presets.

Only the eight explicitly owned folders under ~/Libero/banks/{mie,trap,
percussioni,chitarre}, this script, and demo/release-replacements-v1/rhythm are
written. Existing presets, source libraries and bank metadata are read-only.
Raw source files and per-file SHA-256 provenance are kept beside any derived
render; each upstream recording lane has its own credit and exact license.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, importlib.util, json, math, re, shutil, sys
import numpy as np
import soundfile as sf
from scipy import signal

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, render, library
from libero.dsp import momentary_max, estimate_f0, refine_f0
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero.figure import validate_svg, rasterize
from libero.ingest.sfz import parse_sfz
HOME=Path.home(); BANK=HOME/'Libero/banks'; SOUNDS=HOME/'Libero/sounds'; SKETCHES=HOME/'Libero/sketches'; DEMO=HOME/'Libero/demo/release-replacements-v1/rhythm'
VCSL=HOME/'Libero/cache/libraries/vcsl'; VSCO=HOME/'Libero/cache/libraries/vsco2-ce'
BRD=HOME/'Libero/cache/libraries/karoryfer-big-rusty-drums'
GUITAR=HOME/'Libero/cache/libraries/karoryfer-shinyguitar/Shinyguitar'
VOCAL=HOME/'Libero/cache/research/cielo/vocalset'; SR=48000

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def librosa_f0(x, expected, sr):
 """Restrict autocorrelation F0 to the expected note for voiced sources."""
 x=np.asarray(x)
 if x.ndim==2:x=x.mean(axis=1)
 freq,voiced=estimate_f0(x,int(sr),max(25.,expected*.5),expected*2)
 if not np.isfinite(freq) or freq<=0:return expected,0.
 return refine_f0(x,int(sr),freq),float(voiced)
def dump(p,obj): Path(p).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def copy_source(src, samples, collection='originals'):
 src=Path(src); rel=Path(collection)/src.parent.name/src.name
 dest=samples/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if not dest.exists():shutil.copy2(src,dest)
 if sha(src)!=sha(dest):raise RuntimeError(f'copy mismatch {src}')
 return rel.as_posix(),sha(src)
def source_row(src, rel, digest, **fields):
 return {'source_path':str(src),'included':rel,'sha256_source':digest,'sha256_included':sha(Path(src).parent.parent/rel) if False else None,**fields}
def credit(source,author,license,cls,url,notes=''):
 return {'source':source,'author':author,'license':license,'license_class':cls,'url':url,'notes':notes}
def normalize_dynamics(rows):
 """Map actual source ladders to a gapless performance axis without inventing takes."""
 groups={}
 for i,r in enumerate(rows):groups.setdefault((r.get('articulation'),r.get('root'),r.get('lo'),r.get('hi'),r.get('pitched',True)),[]).append(i)
 for idx in groups.values():
  by_take={}
  for i in idx:by_take.setdefault(int(rows[i].get('take',0)),set()).add(tuple(rows[i].get('vel',(1,127))))
  ladders={take:sorted(vels,key=lambda v:(v[0],v[1])) for take,vels in by_take.items()};n=max(map(len,ladders.values()))
  for i in idx:
   take=int(rows[i].get('take',0));vel=tuple(rows[i].get('vel',(1,127)));ladder=ladders[take]
   j=ladder.index(vel);j=min(n-1,round(j*(n-1)/max(1,len(ladder)-1)))
   rows[i]['dyn']=[round(j/n,6),round((j+1)/n,6)];rows[i].pop('vel',None)
 # A few upstream SFZ key ranges expose only RR2. Renumber the extant real
 # alternatives within each exact key/dynamic group: this keeps every take and
 # avoids a phantom missing RR1 for regions where the source has one take.
 rr_groups={}
 for i,r in enumerate(rows):
  rr_groups.setdefault((r.get('articulation'),r.get('root'),r.get('lo'),r.get('hi'),tuple(r.get('dyn',()))),[]).append(i)
 for idx in rr_groups.values():
  takes=sorted({int(rows[i].get('take',0)) for i in idx})
  for i in idx:rows[i]['take']=takes.index(int(rows[i].get('take',0)))
 return rows

def repair_recorded_dynamic_ladder(rows,samples):
 """Make recorded layer loudness progress natural while retaining real timbre.

 Source proof retains unaltered performances. Only a small uniform zone gain is
 added when measured recorded level order contradicts its velocity labels.
 """
 groups={}
 for i,r in enumerate(rows):
  if r.get('articulation','').endswith('_staccato'):
   groups.setdefault((r.get('articulation'),r['root'],r['lo'],r['hi']),[]).append(i)
 for idx in groups.values():
  bins={}
  for i in idx:bins.setdefault(tuple(rows[i].get('dyn',(0,1))),[]).append(i)
  ordered=sorted(bins)
  if len(ordered)<2:continue
  levels=[]
  for dyn in ordered:
   vals=[]
   for i in bins[dyn]:
    x,sr=sf.read(samples/rows[i]['file'],dtype='float64',always_2d=True)
    vals.append(momentary_max(x,sr)+float(rows[i].get('gain_db',0)))
   levels.append((min(vals),max(vals)) if vals else (-120.,-120.))
  # Preserve each take's relative dynamics. Where the source's nominal layer
  # order crosses, lift only the upper layer enough that even its quietest RR
  # clears the loudest previous layer by a small 1.5 dB step.
  previous_max=levels[0][1]
  for j,dyn in enumerate(ordered[1:],start=1):
   low,high=levels[j]
   correction=max(0.,min(20.,previous_max+1.5-low))
   for i in bins[dyn]:rows[i]['gain_db']=float(rows[i].get('gain_db',0))+correction
   previous_max=high+correction
 return rows
def retain_docs(samples, documents):
 index=samples/'source-reference-index.json'
 rows=json.loads(index.read_text()) if index.exists() else [];known={r['source_path'] for r in rows}
 dst=samples/'source-reference';dst.mkdir(parents=True,exist_ok=True)
 for src in documents:
  src=Path(src)
  if not src.is_file() or str(src) in known:continue
  out=dst/src.name
  if not out.exists():shutil.copy2(src,out)
  rows.append({'source_path':str(src),'included':out.relative_to(samples).as_posix(),'sha256_source':sha(src),'sha256_included':sha(out)})
 dump(index,rows)
def draw(title,slug,color,kind):
 # Individual, instrument-specific vector motif (not a generated placeholder).
 if kind=='cello': body='<path d="M230 78c-48 34-67 92-39 145 28 53 100 53 130 0 28-53 9-111-39-145m-52 187c-54 24-68 75-38 120 26 38 94 38 120 0 30-45 16-96-38-120M255 65v320m-55-136h110m-116 89h122"/><path d="M150 110l200 250M354 111 155 355"/>'
 elif kind=='choir': body='<path d="M100 260q38-95 76 0t76 0 76 0 76 0"/><path d="M114 328h284M142 348h228"/><circle cx="166" cy="174" r="18"/><circle cx="256" cy="143" r="18"/><circle cx="346" cy="174" r="18"/><path d="M166 192v52m90-83v83m90-52v52"/>'
 elif kind=='guitar': body='<path d="M245 95c-56-44-142 4-121 84 8 31 34 53 44 82 8 24-17 53 2 92 24 48 89 68 136 40 44-26 37-74 44-106 7-31 43-50 45-88 4-70-80-105-150-64z"/><circle cx="255" cy="251" r="34"/><path d="M256 88v293m-15-106h30m-31 10h32"/>'
 elif kind=='texture': body='<path d="M94 145l90 12 74 174 71-175 90-11M148 143l40 127m176-127-40 127M202 140v156m108-156v156"/><path d="M100 337q156-39 312 0M113 356q143-34 286 0"/>'
 elif kind=='mano': body='<path d="M170 362V199q0-23 21-23t21 23v-87q0-24 23-24t23 24v80-110q0-22 22-22t22 22v111-80q0-21 22-21t22 21v139q0 98-90 98h-12q-74 0-74-88z"/><path d="M112 398h288"/>'
 elif kind=='kit' and 'ita' in slug: body='<path d="M88 342q168-177 336 0M115 342q141-132 282 0M144 342q112-88 224 0M172 342q84-46 168 0"/><path d="M118 365h276M166 385h180"/><circle cx="256" cy="140" r="30"/><path d="M256 108v64m-32-32h64"/>'
 elif kind=='kit' and 'pro' in slug: body='<rect x="96" y="104" width="320" height="285" rx="18"/><path d="M128 149h256M128 207h256M128 265h256M128 323h256M192 125v246M256 125v246M320 125v246"/><circle cx="160" cy="178" r="13"/><circle cx="224" cy="236" r="13"/><circle cx="288" cy="294" r="13"/><circle cx="352" cy="352" r="13"/>'
 elif kind=='kit': body='<circle cx="256" cy="245" r="133"/><circle cx="256" cy="245" r="94"/><path d="M256 52v48m0 291v62M63 245h48m291 0h47M119 108l34 34m206 206 34 34M393 108l-34 34M153 348l-34 34"/><path d="M160 271q96 57 192 0M181 213h150"/>'
 else: body='<circle cx="256" cy="232" r="125"/><circle cx="256" cy="232" r="84"/><path d="M256 50v92m-26-25 26 25 26-25M130 380h252"/>'
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="none" stroke="{color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>{slug}: illustration of its distinct source or designed excitation.</desc>{body}</svg>'
def save_art(folder,title,slug,color,kind):
 svg=draw(title,slug,color,kind); err=validate_svg(svg)
 if err:raise RuntimeError(f'{slug} invalid SVG: {err}')
 (folder/'figure.svg').write_text(svg);(folder/'figure.png').write_bytes(rasterize(svg,512))

def bake_active_performed_loop(audio):
 """Retain onset and derive a stable, active loop from this exact composite."""
 right=min(audio.duration-.08,4.5)
 lp=audio.loop_points(min_seconds=.9,region=(.28,right),window=.03,max_crossfade=.30)
 if lp is None:lp=audio.loop_points(min_seconds=.55,region=(.18,audio.duration-.06),window=.025,max_crossfade=.30)
 if lp is None:raise RuntimeError('No active same-performance sustain loop found')
 y=audio.data.astype(np.float64).copy();n=int(.02*audio.sr);xf=min(int(.30*audio.sr),lp.start,lp.end-lp.start);blend=max(0,xf-n)
 if blend>1:
  t=np.linspace(0,1,blend,endpoint=True);w=t*t*(3-2*t)
  src=y[lp.start-xf:lp.start-n];dst=y[lp.end-xf:lp.end-n]
  if y.ndim==2:w=w[:,None]
  y[lp.end-xf:lp.end-n]=dst*(1-w)+src*w
 if n>0:y[lp.end-n:lp.end]=y[lp.start-n:lp.start]
 cooked=Audio(y[:lp.end],sr=audio.sr)
 return cooked,{'start':lp.start,'end':lp.end,'selection_error_db':lp.error_db,'crossfade_ms':1000*xf/audio.sr,'exact_tail_ms':1000*n/audio.sr,'loop_rms_dbfs':20*math.log10(np.sqrt(np.mean(y[lp.start:lp.end]**2))+1e-20)}

def bake_explicit_active_loop(audio,lp,overlap=.20,exact_tail=.02):
 y=audio.data.astype(np.float64).copy();n=int(exact_tail*audio.sr);xf=min(int(overlap*audio.sr),lp.start,lp.end-lp.start);blend=max(0,xf-n)
 if blend>1:
  t=np.linspace(0,1,blend,endpoint=True);w=t*t*(3-2*t);src=y[lp.start-xf:lp.start-n];dst=y[lp.end-xf:lp.end-n]
  if y.ndim==2:w=w[:,None]
  y[lp.end-xf:lp.end-n]=dst*(1-w)+src*w
 if n>0:y[lp.end-n:lp.end]=y[lp.start-n:lp.start]
 return Audio(y[:lp.end],sr=audio.sr),{'start':lp.start,'end':lp.end,'error_db':lp.error_db,'crossfade_ms':1000*xf/audio.sr,'exact_tail_ms':1000*n/audio.sr}

def source_manifest(folder, proof, credits, map_rows, title, subtitle, tags, roots, *, pitched=True, loop='auto', master=-6, articulations=None, one_shot=False, preserve_key_ranges=False, loop_min_s=None):
 s=folder/'samples';dump(s/'source-proof.json',proof);dump(s/'credits.json',credits);dump(s/'map.json',map_rows)
 attribution=['# Source attribution and licence notices','',f'Preset: {title}','']
 for c in credits:
  attribution += [f"## {c['source']}",f"- Author: {c['author']}",f"- Licence/grant: {c['license']}",f"- Source: {c['url']}",f"- Notes: {c.get('notes','')}",'']
 (folder/'ATTRIBUTION.md').write_text('\n'.join(attribution)+'\n')
 arts=f"sound.articulations({articulations!r})" if articulations else ''
 # Full source gestures remain; loop auto is constrained to a stable region by
 # compiler analysis. Natural one-shots have no loop and ignore note-off.
 p={'tune':'source','ladder':'keep','align_ms':0,'pre_ms':0,'loop':loop,'loop_min_s':float(loop_min_s if loop_min_s is not None else (0.45 if loop=='auto' else 0)),
    'max_seconds':None,'end_db':-95,'fade_ms':10 if loop in ('none','auto') else 0,'edge_fill':False,'encoding':'flac24'}
 if preserve_key_ranges:p['preserve_key_ranges']=True
 if loop=='none':p['max_seconds']=None
 recipe=f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nP=Path(__file__).parent\nr=json.loads((P/'samples/map.json').read_text())\nsound=Sound({title!r},subtitle={subtitle!r},tags={tags!r},roots={sorted(set(roots))!r},sample_rate=48000,accent={folder.name.endswith('libero') and '#9f6d42' or '#9f6d42'!r})\n{arts}\nsound.multisample('body',r,process={p!r},as_dyn=False)\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,rr_reset_ms=1500,humanize={{'cents':0,'ms':0,'db':0}},one_shot={one_shot!r})\nsound.defaults(mode='Poli',glide=0,voices=32,master={master},amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=180,vel_sens=.45,rev_mode='Cappella',rev_size=.18,rev_decay=.6,rev_mix=0.025,width=1,drive=0,tape_wow=0,tape_flutter=0,tape_sat=0,tape_mix=0,caldi_mode='Spento',lvl_body=0,lvl_attack=-60,lvl_tail=-60,lvl_air=-60,lfo_pitch=0,lfo_amp=0,echo_mix=0)\n'''
 (folder/'sound.py').write_text(recipe)
 (folder/'notes.md').write_text(f'# {title}\n\n{subtitle}\n\nSource-led replacement preset. Original performances are retained in `samples/originals/`; every mapped source and derived file has SHA-256 provenance in `samples/source-proof.json`. Credits and licence lanes are explicit in `samples/credits.json`.\n\nDefaults: Poli, glide 0, sustain 1.0, wow/flutter 0, Caldi Spento. This held version uses an automatically detected same-source loop where the recording supports it; the recorded attack and gesture remain in the source. A one-shot articulation is finite. Compiler loop diagnostics and native verification are in the demo report. Numeric checks do not establish perceived quality.\n')

def parse_pitch(filename):
 m=re.search(r'([A-G])([#b]?)(-?\d)',Path(filename).stem)
 if not m:return None
 n={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[m[1]]+({'#':1,'b':-1}.get(m[2],0));return (int(m[3])+1)*12+n

def build_vcs_hand(slug, texture=False):
 folder=BANK/'percussioni'/slug;s=folder/'samples';s.mkdir(parents=True,exist_ok=True)
 srcs=[];groups=[]
 if not texture:
  # Keyed by gesture, not pitch. VCSL source layers/takes are grouped as real velocity/RR.
  root=VCSL/'Membranophones/Struck Membranophones'; idi=VCSL/'Idiophones/Struck Idiophones'
  specs=[(36,'Bongos/BongoH_Hit1_v','v'),(37,'Bongos/BongoH_HitMuted1_v','v'),(38,'Bongos/BongoL_Hit1_v','v'),(39,'Bongos/BongoL_HitMuted2_v','v'),
   (40,'Conga/Quinto_HitN_v','v'),(41,'Conga/Quinto_HitFM1_v','v'),(42,'Conga/Conga_HitN_v','v'),(43,'Conga/Conga_HitFM_v','v'),(44,'Conga/Tumba_HitN_v','v'),(45,'Conga/Tumba_HitFM_v','v'),
   (46,'Darbuka/Darbuka_1_hit_vl','vl'),(47,'Darbuka/Darbuka_2_hit_vl','vl'),(48,'Darbuka/Darbuka_3_hit_vl','vl'),(49,'Darbuka/Darbuka_4_hit_vl','vl'),(50,'Darbuka/Darbuka_5_hit_vl','vl'),
   (51,'Frame Drum/HDrumL_Hit_v','v'),(52,'Frame Drum/HDrumL_HitMuted_v','v'),(53,'Frame Drum/HDrumS_Hit_v','v'),(54,'Frame Drum/HDrumS_HitMuted_v','v')]
  for key,pat,dyncode in specs: groups.append((key,root,pat,dyncode))
  specs2=[(55,'Shaker, Small/Mid_Shaker_Slap_','rr'),(56,'Shaker, Small/Mid_ShakerHighFaster_Up_','rr'),(57,'Tambourine 1/Tamb1_Hit_','v'),(58,'Tambourine 1/Tamb1_Shake_','rr'),(59,'Triangles/Triangle3_Hit_v','v'),(60,'Triangles/Triangle3_HitM_v','v'),(61,'Claves/Claves1_Hit_v','v'),(62,'Claves/Claves2_Hit_v','v'),(63,'Woodblock/wood_click_','wb'),(64,'Cowbells/Cowbell1_Normal_v','v'),(65,'Agogo Bells/Agogo_Low_v','v'),(66,'Guiro/Guiro_Fast_','rr'),(67,'Cabasa/Cabasa1_Hit_','rr'),(68,'Claps/SoloClap_vl','vl')]
  for key,pat,dc in specs2:groups.append((key,idi,pat,dc))
  title='Percussioni a Mano · Libero'; kind='mano'; color='#b36a3d'; tag=['percussioni','mano','vcsL','hand-percussion','recorded']
  license=credit('Versilian Community Sample Library (selected hand percussion)','Sam Gossner / Versilian Studios LLC','CC0 1.0','cc0','https://github.com/sgossner/VCSL','CC0 grant applies to the original library samples. VCSL file structure and exact mapped WAV paths are retained.')
 else:
  idi=VCSL/'Idiophones';groups=[]
  # A different physical palette: rubbed glass, gong, anvil and granular metal/wood.
  specs=[(36,idi/'Friction Idiophones/Wine Glasses/Sustains/Slow','*.wav','pitch'),(37,idi/'Friction Idiophones/Wine Glasses/Sustains/Fast','*.wav','pitch'),
         (38,idi/'Struck Idiophones/Gong 1','*.wav','v'),(39,idi/'Struck Idiophones/Gong 2','*.wav','v'),(40,idi/'Struck Idiophones/Anvil','*.wav','v'),
         (41,idi/'Struck Idiophones/Cabasa','*.wav','rr'),(42,idi/'Struck Idiophones/Guiro','*Slow*.wav','rr'),(43,idi/'Struck Idiophones/Guiro','*Fast*.wav','rr'),
         (44,idi/'Struck Idiophones/Triangles','*Roll*.wav','rr'),(45,idi/'Struck Idiophones/Woodblock','*.wav','rr')]
  for key,path,pat,dc in specs:groups.append((key,path,pat,dc))
  title='Percussioni · Texture';kind='texture';color='#5f8791';tag=['percussioni','texture','glass','metal','vcsL','recorded']
  license=credit('Versilian Community Sample Library (glass, struck metals and motion textures)','Sam Gossner / Versilian Studios LLC','CC0 1.0','cc0','https://github.com/sgossner/VCSL','CC0. Original sources are independent glass and metal/wood gestures, not processed hand-percussion copies.')
 rows=[];proof=[];candidates=[]
 for key,path,pat,dc in groups:
  fs=sorted(path.glob(pat if '*' in pat else pat+'*.wav'))
  # exclude legacy labels and non-performance/ambiguous files
  fs=[f for f in fs if f.is_file() and f.suffix.lower()=='.wav' and 'Legacy' not in str(f) and 'Rel' not in f.parts]
  if not fs:continue
  for f in fs:
   candidates.append((key,f,dc))
 # stable, broad map with every matching take/layer retained
 family_key={}
 if texture:
  import re as _re
  def texture_family(f):
   stem=f.stem
   for pat in (r'_(?:v|vl)\d+',r'_rr\d+',r'_(?:fff|ff|mf|mp|pp|p|f)(?:$|_)'):
    stem=_re.sub(pat,'_',stem,flags=_re.I)
   return stem.strip('_')
  for _,f,_ in candidates:family_key.setdefault((f.parent.as_posix(),texture_family(f)),None)
  for i,k in enumerate(sorted(family_key),start=80):family_key[k]=i
 for key,f,dc in candidates:
  rel,digest=copy_source(f,s)
  # group numbered velocities, otherwise preserve each actual RR as a take
  m=re.search(r'(?:_v|_vl)(\d+)',f.name)
  if m:vel=int(m.group(1))
  else:
   label=re.search(r'(?:^|_)(fff|ff|mf|mp|pp|p|f)(?:_|$)',f.stem)
   vel={'pp':1,'p':1,'mp':2,'mf':3,'f':4,'ff':5,'fff':6}.get(label.group(1),1) if label else 1
  rr=re.search(r'_rr(\d+)',f.name);take=int(rr.group(1))-1 if rr else 0
  # Gesture triggers, including resonant glass, are finite unpitched textures;
  # they are not promoted to held pitched presets by filename heuristics.
  root=family_key.get((f.parent.as_posix(),texture_family(f)),key) if texture else key;lo=root;hi=root;pitched=False;one=True
  row={'file':rel,'root':root,'lo':lo,'hi':hi,'vel':[max(1,(vel-1)*32+1),min(127,vel*32)],'take':take,'pitched':pitched,'one_shot':one,'tune_cents':0}
  source_audio,sr=sf.read(f,dtype='float64',always_2d=True)
  level=momentary_max(source_audio,sr)
  if level < -60:row['gain_db']=min(18.,-58.-level)
  if row.get('gain_db'):proof_gain_db=float(row['gain_db'])
  else:proof_gain_db=0.
  rows.append(row);proof.append({'source_path':str(f),'source_sha256':digest,'included':rel,'sha256_included':sha(s/rel),'root':root,'key':key,'source_velocity_label':vel,'source_gain_db':proof_gain_db,'take':take,'source_articulation':f.parent.name,'pitched':pitched})
 if not rows:raise RuntimeError(f'empty VCSL mapping {slug}')
 normalize_dynamics(rows)
 retain_docs(s,[VCSL/'LICENSE',VCSL/'README.md'])
 source_manifest(folder,proof,[license],rows,title,'VCSL hand gestures: distinct struck, shaken and rubbed physical sources' if not texture else 'Rubbed glass, gong/anvil strikes and dry granular scrape gestures, each mapped as its own texture event',tag,[r['root'] for r in rows],pitched=False,loop='none',master=-2,one_shot=True)
 save_art(folder,title,slug,color,kind)
 return folder

def build_guitar():
 folder=SKETCHES/'chitarra-acustica-libero';s=folder/'samples';s.mkdir(parents=True,exist_ok=True)
 sf2=HOME/'Libero/cache/libraries/tavymusic-plucked/PluckedStrings.sf2'
 rows=[];proof=[];(s/'originals').mkdir(parents=True,exist_ok=True)
 from sf2utils.sf2parse import Sf2File
 sf2hash=sha(sf2);shutil.copy2(sf2,s/'originals'/'PluckedStrings.sf2')
 parsed=Sf2File(sf2.open('rb'))
 wanted={'guitar-fingerstyle':'fingerstyle','guitar-plectrum':'plectrum'}
 for preset in parsed.presets:
  if preset.name not in wanted:continue
  art=wanted[preset.name]
  for pbag in preset.bags:
   inst=pbag.instrument
   if inst is None:continue
   for ibag in inst.bags:
    smp=ibag.sample
    if smp is None:continue
    generators=ibag.gens
    rootgen=generators.get(58);root=int(rootgen.amount) if rootgen else smp.original_pitch
    kr=ibag.key_range or [root,root];lo=max(40,pbag.key_range[0] if pbag.key_range else 40,kr[0]);hi=min(84,pbag.key_range[1] if pbag.key_range else 84,kr[1])
    if lo>hi:continue
    vr=ibag.velocity_range or [1,127];vr=(max(1,vr[0]),min(127,vr[1]))
    name=f'{art}-{smp.name}-root{root:03d}.wav';dest=s/'extracted'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    smp.export(str(dest));rawhash=sha(dest);audio=Audio.load(dest)
    # Preserve the exact SF2 sample payload; the compiler detects a stable held loop from its source body.
    # SF2 generator values retain root override, loop offsets and static tune.
    coarse=generators.get(51);fine=generators.get(52);cents=(float(coarse.amount)*100 if coarse else 0)+(float(fine.amount) if fine else 0)+float(smp.pitch_correction)
    loop={'start':int(smp.start_loop),'end':int(smp.end_loop)} if smp.end_loop>smp.start_loop else None
    row={'file':dest.relative_to(s).as_posix(),'root':root,'lo':lo,'hi':hi,'vel':list(vr),'take':0,'pitched':True,'articulation':art,'tune_cents':-cents,'gain_db':-2}
    if art=='plectrum':row.update({'loop':'none','one_shot':True})
    rows.append(row);proof.append({'source_container':str(sf2),'source_container_sha256':sf2hash,'raw_extracted_file':dest.relative_to(s).as_posix(),'raw_extracted_sha256':rawhash,'mapped_file':row['file'],'mapped_sha256':sha(dest),'extraction':'unmodified SF2 sample payload exported to PCM WAV; original full note sample is retained and compiler detects a stable loop from its source body','preset':preset.name,'source_instrument':inst.name,'sample':smp.name,'sample_rate':smp.sample_rate,'sample_original_pitch':smp.original_pitch,'generator_root_key_override':root,'key_range':[lo,hi],'velocity_range':list(vr),'take':0,'sf2_static_tune_cents':cents,'applied_bundle_tune_cents':-cents,'source_loop_frames':loop,'license_evidence':'SF2 metadata plus TavyMusic author release statement; CC0'})
 if not rows:raise RuntimeError('TavyMusic SF2 has no usable acoustic guitar presets')
 retain_docs(s,[sf2])
 lic=credit('PluckedStrings.sf2 · TavyMusic acoustic steel-string fingerstyle and plectrum','John Maddock / TavyMusic','CC0 1.0','cc0','https://musescore.org/en/node/23225','The source SF2 declares CC0 in its preset metadata; author distribution notice records that modification and redistribution are permitted. Fingerstyle and plectrum are separate actual presets; only one recorded dynamic/RR exists per note. The original SF2 container is retained byte-for-byte; extracted zone WAVs are mapped with their SF2 roots, velocity/key ranges, loops and static tune.')
 arts=[{'id':'fingerstyle','name':'Dita · steel-string','key':1},{'id':'plectrum','name':'Plettro · steel-string','key':2}]
 normalize_dynamics(rows)
 source_manifest(folder,proof,[lic],rows,'Chitarra acustica steel-string · Libero','TavyMusic steel-string acoustic guitar · fingerstyle and plectrum presets, separated as real articulations; authentic SF2 root/key mapping',['guitar','steel-string','acoustic','sampled','tavy-music','release-replacement'],[r['root'] for r in rows],loop='auto',master=-9,articulations=arts,loop_min_s=2.0)
 (folder/'notes.md').write_text('# Chitarra acustica steel-string · Libero\n\nFlat-top steel-string source: TavyMusic PluckedStrings SF2, fingerstyle and plectrum are two separate presets/articulations. The SF2 payload is preserved byte-for-byte; mapped WAVs are extracted sample payloads, with the SF2 root override, key ranges and static tune kept in the map. The full recorded pluck remains unmodified; the compiler analyses a stable loop in its source body for held playback. The source has one recorded velocity and one take per zone; no RR or dynamic is invented. The source CC0 notice and author redistribution statement are recorded in the retained SF2 INFO chunk.\n')
 save_art(folder,'Chitarra acustica steel-string · Libero','chitarra-acustica-libero','#956b48','guitar');return folder

def build_choir():
 folder=BANK/'trap/trap-coro-libero';s=folder/'samples';s.mkdir(parents=True,exist_ok=True)
 # Assemble six independently recorded human performers, preserving actual vowels,
 # entries and dynamic performances; there are no delayed clones or synthesized voices.
 base=ROOT/'python/scripts/build_cielo_v2.py';spec=importlib.util.spec_from_file_location('release_cielo_ro',base);cielo=importlib.util.module_from_spec(spec);spec.loader.exec_module(cielo)
 rows=[];proof=[];roots=list(range(48,77));selected=[['male1','male5','male6'],['male2','male3','male7'],['female1','female2','female3']]
 for vowel,art in [('a','a'),('e','e'),('o','o')]:
  for root in roots:
   for dyn_name,dyn in [('pp','pp'),('forte','forte')]:
    sources=[]
    for voice_ix,singer in enumerate(selected[0] if root<59 else selected[1] if root<67 else selected[2]):
     r=cielo.choose(singer,vowel,dyn,root,5)
     if r:sources.append((r,voice_ix))
    if len(sources)<2:
     # Fill sparse semitone cells from other actual performers in the same vowel/dynamic.
     used={r['singer'] for r,_ in sources}
     for singer in [f'male{i}' for i in range(1,11)]+[f'female{i}' for i in range(1,11)]:
      if singer in used:continue
      r=cielo.choose(singer,vowel,dyn,root,6)
      if r:
       sources.append((r,len(sources)));used.add(singer)
      if len(sources)>=3:break
    if len(sources)<2:continue
    buffers=[];stem_audits=[]
    for i,(r,_) in enumerate(sources):
     expected=440*2**((root-69)/12)
     base_audio=cielo.load(r['file'],sr=SR).pitch(root-r['root'])
     if base_audio.data.ndim==2:base_audio=Audio(base_audio.data.mean(axis=1),SR)
     base_loop=base_audio.loop_points(min_seconds=.9,region=(.28,max(.55,base_audio.duration-.06)),window=.03,max_crossfade=.30)
     if base_loop is None:base_loop=base_audio.loop_points(min_seconds=.55,region=(.18,max(.55,base_audio.duration-.06)),window=.025,max_crossfade=.30)
     fallback_window=None
     if base_loop is None:
      start=round(.22*SR);end=max(start+int(.30*SR),len(base_audio.data)-round(.05*SR));fallback_window=(start,min(end,len(base_audio.data)))
      if fallback_window[1]-fallback_window[0]<int(.30*SR):raise RuntimeError(f'No measurable sustained body for VocalSet stem {r["singer"]}/{vowel}/{dyn_name}/{root}')
     def stable_loop_center(performance,scale):
      if base_loop is not None:s0=max(0,round(base_loop.start*scale));e0=min(len(performance.data),round(base_loop.end*scale))
      else:s0=max(0,round(fallback_window[0]*scale));e0=min(len(performance.data),round(fallback_window[1]*scale))
      if e0-s0<int(.32*SR):raise RuntimeError(f'Transposed VocalSet stem loop too short: {r["singer"]}/{vowel}/{dyn_name}/{root}')
      cycle=np.asarray(performance.data[s0:e0],dtype=np.float64)
      sample=np.concatenate((cycle,cycle),axis=0)
      hz,voiced=estimate_f0(sample,SR,expected*.8,expected*1.2)
      if not np.isfinite(hz) or voiced<.55:raise RuntimeError(f'Unvoiced stable-loop VocalSet stem {r["singer"]}/{vowel}/{dyn_name}/{root}')
      return hz,voiced
     source_hz,source_voiced=stable_loop_center(base_audio,1.0);source_cents=1200*math.log2(source_hz/expected)
     if abs(source_cents)>100:raise RuntimeError(f'VocalSet source stem is more than a semitone from mapped root: {r["singer"]}/{vowel}/{dyn_name}/{root}: {source_cents:.1f} cents')
     stem_correction=0.0;remaining=source_cents;corrected_hz=source_hz;a=base_audio
     for _ in range(2):
      if abs(remaining)<=4.5:break
      stem_correction-=remaining;a=base_audio.pitch(stem_correction/100);scale=2**(-stem_correction/1200)
      corrected_hz,source_voiced=stable_loop_center(a,scale);remaining=1200*math.log2(corrected_hz/expected)
     stem_limit=5.0 if base_loop is not None else 20.0
     if abs(remaining)>stem_limit:raise RuntimeError(f'VocalSet stem center remains {remaining:.1f} cents after static correction (limit {stem_limit:.1f}): {r["singer"]}/{vowel}/{dyn_name}/{root}')
     x=a.data
     if x.ndim==2:x=x.mean(axis=1)
     delay=(i%3)*int(.006*SR);x=np.pad(x,(delay,0));pan=-.6+1.2*i/max(len(sources)-1,1);ang=(pan+1)*np.pi/4
     buffers.append(np.stack([x*np.cos(ang),x*np.sin(ang)],axis=1))
     stem_audits.append({'singer':r['singer'],'source_file':str(r['file']),'source_key':int(r['root']),'played_root':root,'performed_loop_center_hz_before_correction':source_hz,'performed_loop_offset_cents_before_correction':source_cents,'applied_constant_stem_correction_cents':stem_correction,'performed_loop_center_hz_after_correction':corrected_hz,'performed_loop_offset_cents_after_correction':remaining,'loop_source_frames_before':[base_loop.start,base_loop.end] if base_loop is not None else None,'continuous_body_window_frames_before':list(fallback_window) if fallback_window else None,'voiced_fraction':source_voiced,'method':'Constrained YIN median over two cycles from the same long active source loop when available; otherwise the longest unmodified continuous held body. Fixed stem pitch shift only; original onset and vibrato retained'})
    out=np.zeros((max(map(len,buffers)),2))
    for b in buffers:out[:len(b)]+=b
    out/=math.sqrt(len(buffers));out*=.78
    cooked,loop_audit=bake_active_performed_loop(Audio(out,SR))
    dest=s/'assembled'/f'{art}-{dyn_name}-m{root:03d}.wav';dest.parent.mkdir(parents=True,exist_ok=True);sf.write(dest,cooked.data,SR,subtype='PCM_24')
    dynlo,dynhi=(1,63) if dyn=='pp' else (64,127)
    # Tune from the active performed body, excluding the ensemble's transient.
    body=cooked.data[int(.3*SR):int(min(1.2,len(cooked.data)/SR)*SR)];target_hz=440*2**((root-69)/12);f0,voiced=estimate_f0(body,SR,target_hz*.8,target_hz*1.2)
    if np.isfinite(f0) and voiced>.35:f0=refine_f0(body,SR,f0);composite_offset=1200*math.log2(f0/target_hz)
    else:composite_offset=None
    # The singers are calibrated independently above. Do not apply a shared
    # polyphonic F0 correction: beating between distinct performers is not one
    # instrument's detuning.
    tune=0.0
    rows.append({'file':dest.relative_to(s).as_posix(),'root':root,'lo':root,'hi':root,'vel':[dynlo,dynhi],'take':0,'pitched':True,'articulation':art,'gain_db':-1,'tune_cents':tune,'loop':{'start':loop_audit['start'],'end':loop_audit['end']}})
    for r,i in sources:
     raw=Path(r['file']);rel,digest=copy_source(raw,s)
     raw_source=VOCAL/r['source'];raw_rel,raw_digest=copy_source(raw_source,s,'upstream-originals')
     lane=next(z for z in stem_audits if z['singer']==r['singer'])
     proof.append({'source_path':str(raw),'sha256_source':digest,'included':rel,'sha256_included':sha(s/rel),'raw_source_path':str(raw_source),'raw_sha256':raw_digest,'raw_included':raw_rel,'raw_sha256_included':sha(s/raw_rel),'assembled_file':dest.relative_to(s).as_posix(),'assembled_sha256':sha(dest),'singer':r['singer'],'vowel':vowel,'technique':dyn,'source_root':r['root'],'played_root':root,'constant_transposition_semitones':root-r['root'],'independent_lane':i,'composite_tune_cents':tune,'composite_f0_hz':f0,'composite_measured_offset_cents_diagnostic':composite_offset,'f0_voiced_fraction':voiced,'stem_native_pitch_audit':lane})
 if not rows:raise RuntimeError('No supported VocalSet vowel/performer regions')
 retain_docs(s,[HOME/'Libero/cache/research/cielo/vocalset-primary.json',HOME/'Libero/cache/research/cielo/vocalset-acquisition.json',HOME/'Libero/docs/research/public-bundle-cielo-piano-evidence/primary/vocalset-zenodo-record.html',HOME/'Libero/docs/research/public-bundle-cielo-piano-evidence/primary/vocalset-zenodo-record.json'])
 lic=credit('VocalSet: A Singing Voice Dataset (long-tone performances)','Julia Wilkins, Prem Seetharaman, Alison Wahl, Bryan Pardo / Northwestern University','CC BY 4.0','by','https://zenodo.org/records/1442513','Attribution: Wilkins et al., VocalSet, DOI 10.5281/zenodo.1442513, CC BY 4.0. License text: https://creativecommons.org/licenses/by/4.0/. Changes: independent recordings are excerpted, pitch-shifted to mapped notes, combined into a newly arranged multi-singer ensemble with independent panning and short entry offsets, then an active-body loop with smooth overlap and an exact source tail is derived for sustain. Singer, vowel, performed dynamic, raw-source hash and each transformation are documented in source-proof.json; no generated singer or delayed clone.')
 arts=[{'id':v,'name':{'a':'A · coro','e':'E · coro','o':'O · coro'}[v],'key':1+i} for i,v in enumerate('aeo')]
 normalize_dynamics(rows)
 source_manifest(folder,proof,[lic],rows,'Trap Coro · Libero','Coro scuro di performer VocalSet indipendenti · A/E/O registrate, due dinamiche e micro-scaglionamento di entrata reale',['trap','choir','vocalset','recorded','CC-BY-4.0','release-replacement'],[r['root'] for r in rows],loop='source',master=-4,articulations=arts,preserve_key_ranges=True)
 (folder/'notes.md').write_text('# Trap Coro · Libero\n\nVoci reali del VocalSet; tre cantanti indipendenti per nota e frase, selezionati per registro. Le linee sono composte da esecuzioni distinte con ingressi e panning individuali: nessun duplicato ritardato. Ogni esecuzione riceve una sola correzione statica del proprio centro di intonazione prima del montaggio; il vibrato naturale e i tempi originali restano nella registrazione. A/E/O sono le vocali effettivamente cantate (non si certifica una specifica qualità fonetica italiana). Le due dinamiche sono registrazioni pp e forte; la velocity seleziona il gesto. Sostenuto ottenuto da un loop derivato dal corpo attivo dello stesso composito, con sovrapposizione morbida e coda esatta della sorgente. Le sorgenti grezze, hash, misura/correzione per cantante e mappa delle linee sono in samples/source-proof.json. Attribuzione: Wilkins et al., VocalSet, DOI 10.5281/zenodo.1442513, CC BY 4.0.\n')
 save_art(folder,'Trap Coro · Libero','trap-coro-libero','#66527b','choir');return folder

def build_stab():
 folder=SOUNDS/'trap-hit-libero';s=folder/'samples';s.mkdir(parents=True,exist_ok=True)
 specs=[('cello','CelloEnsSusVib.sfz','CelloEnsSpic.sfz'),('trumpet','TrumpetSus.sfz','TrumpetStac.sfz'),('horn','FHornSus.sfz','FHornStac.sfz'),('trombone','TromboneSus.sfz','TromboneStac.sfz')]
 parsed={};held={};proof=[];rows=[]
 for family,susfile,stacfile in specs:
  for art,sfzname in [('hold',susfile),('stac',stacfile)]:
   inst=parse_sfz(VSCO/sfzname)
   if inst.warnings:raise RuntimeError(f'{sfzname} parse warnings: {inst.warnings}')
   parsed[(family,art)]=inst.regions
 retain_docs(s,[VSCO/n for _,sus,stac in specs for n in (sus,stac)])
 retain_docs(s,[VSCO/'LICENSE',VSCO/'README.md'])
 # A deliberately composed unison ensemble: four genuinely different recorded
 # instruments, same played note, no pre-baked harmony or delayed duplicate.
 from libero import load
 for target in range(36,73,3):
  lanes=[];laneproof=[]
  for family,_,_ in specs:
   options=[r for r in parsed[(family,'hold')] if r.lokey<=target<=r.hikey and r.trigger=='attack' and r.sample.exists()]
   if not options:
    options=sorted([r for r in parsed[(family,'hold')] if r.sample.exists() and r.trigger=='attack'],key=lambda r:abs(r.root-target))[:1]
   if not options:continue
   r=min(options,key=lambda r:abs(r.root-target));semitones=target-r.root
   a=load(r.sample,sr=SR).pitch(semitones+r.tune_cents/100);x=a.data
   if x.ndim==1:x=np.stack([x,x],axis=1)
   if x.ndim==2 and x.shape[1]>2:x=x[:,:2]
   pan={'cello':-.58,'trumpet':-.18,'horn':.22,'trombone':.59}[family];angle=(pan+1)*np.pi/4
   mono=x.mean(axis=1);x=np.stack([mono*np.cos(angle),mono*np.sin(angle)],axis=1)
   lanes.append((x,float(r.gain_db)))
   rel,digest=copy_source(r.sample,s)
   laneproof.append({'family':family,'source_path':str(r.sample),'source_sha256':digest,'included':rel,'sha256_included':sha(s/rel),'source_root':r.root,'played_root':target,'semitones':semitones,'fine_tune_cents':r.tune_cents,'SFZ_gain_db':r.gain_db,'source_key_range':[r.lokey,r.hikey]})
  if len(lanes)<3:continue
  n=max(len(x) for x,_ in lanes);out=np.zeros((n,2))
  for x,g in lanes:out[:len(x)]+=x*10**(g/20)
  out/=math.sqrt(len(lanes));peak=np.max(np.abs(out))+1e-15;mix_gain=.44/peak;out*=mix_gain
  dest=s/'composed-hold'/f'ensemble-{target:03d}.wav';dest.parent.mkdir(parents=True,exist_ok=True);sf.write(dest,out,SR,subtype='PCM_24')
  cooked,loop_audit=bake_active_performed_loop(Audio(out,SR));sf.write(dest,cooked.data,SR,subtype='PCM_24')
  from calibrate_blue_v6_body import estimate
  measured=cooked.data;freq,cents=estimate(measured[int(.25*SR):int(min(1.2,len(measured)/SR)*SR)],SR,440*2**((target-69)/12));tune=-cents
  rows.append({'file':dest.relative_to(s).as_posix(),'root':target,'lo':max(36,target-1),'hi':min(72,target+1),'vel':[1,127],'take':0,'pitched':True,'articulation':'sostenuto','gain_db':-3,'tune_cents':tune,'loop':{'start':loop_audit['start'],'end':loop_audit['end']}})
  proof.append({'derived_file':dest.relative_to(s).as_posix(),'derived_sha256':sha(dest),'kind':'new composed unison from independent VSCO performances','played_root':target,'mix_normalization_db':20*math.log10(mix_gain),'precompile_native_frequency_hz':freq,'precompile_pitch_offset_cents':cents,'applied_bundle_tune_cents':tune,'active_performed_loop':loop_audit,'source_lanes':laneproof,'loop_policy':'retained original composite onset and active same-composite sustain segment, smooth overlap plus exact source tail; not claimed to be one original performance'})
 # Preserve every mapped velocity, articulation and round robin from staccato SFZs.
 seen_stacc=set()
 for family,_,_ in specs:
  for r in parsed[(family,'stac')]:
   if not r.sample.exists() or r.trigger!='attack':continue
   rr=re.search(r'_rr(\d+)',r.sample.name,re.I);take=int(rr.group(1))-1 if rr else max(0,r.seq_position-1)
   signature=(family,str(r.sample),r.root,r.lokey,r.hikey,r.lovel,r.hivel,take)
   if signature in seen_stacc:continue
   seen_stacc.add(signature)
   rel,digest=copy_source(r.sample,s)
   row={'file':rel,'root':r.root,'lo':r.lokey,'hi':r.hikey,'vel':[r.lovel,r.hivel],'take':take,'tune_cents':r.tune_cents,'gain_db':r.gain_db-5,'pitched':True,'one_shot':True,'loop':'none','articulation':family+'_staccato'}
   rows.append(row);proof.append({'source_path':str(r.sample),'source_sha256':digest,'included':rel,'sha256_included':sha(s/rel),'family':family,'articulation':'staccato','root':r.root,'key_range':[r.lokey,r.hikey],'velocity':[r.lovel,r.hivel],'take':r.seq_position-1,'tuning_cents':r.tune_cents,'source_gain_db':r.gain_db,'derived_zone_gain_db_before_layer_correction':r.gain_db-5})
 if not rows:raise RuntimeError('No VSCO staccato/held source regions discovered')
 credits=[credit('VSCO 2 Community Edition · original recorded cello section and brass performances','Sam Gossner, Simon Dalzell; sample cutting Elan Hickler / Soundemote','CC0 1.0','cc0','https://versilian-studios.com/vsco-community/','Sustain and staccato maps follow upstream SFZ root/key/velocity/RR data. The held ensemble is a new unison composition from independent recorded instrument sources; the staccato maps remain separate original performances.')]
 arts=[{'id':'sostenuto','name':'Sostenuto · ensemble','key':1}]+[{'id':family+'_staccato','name':family.title()+' · staccato','key':i+2} for i,(family,_,_) in enumerate(specs)]
 normalize_dynamics(rows)
 repair_recorded_dynamic_ladder(rows,s)
 # VSCO's one-shot brass peaks drive the compiler's shared body safety gain
 # down by 30 dB. Reduce only the secondary staccato zones uniformly so the
 # sostenuto body is audible; the shared automatic gain then rises by the same
 # amount and the original articulation balance is retained at playback.
 for row in rows:
  if row.get('articulation','').endswith('_staccato'):
   row['gain_db']=float(row.get('gain_db',0))-14.0
 bysrc={r['file']:r for r in rows}
 for item in proof:
  if item.get('included') in bysrc:
   item['applied_zone_gain_db']=bysrc[item['included']].get('gain_db',0)
   if bysrc[item['included']].get('articulation','').endswith('_staccato'):item['shared_body_gain_balance_db']=-14.0
 source_manifest(folder,proof,credits,rows,'Trap Hit · Libero','Unisono sostenuto composto da esecuzioni reali VSCO: cello section, tromba, corno e trombone; staccati registrati secondari',['trap','orchestral-stab','vsco','recorded','CC0','release-replacement'],[r['root'] for r in rows],loop='source',master=6,articulations=arts)
 (folder/'notes.md').write_text('# Trap Hit · Libero\n\nDefault: unisono sostenuto composto da archi e ottoni VSCO registrati; ogni nota conserva l’attacco di quattro esecuzioni indipendenti, mentre ciascuna voce mantiene il proprio timbro e il proprio pan. Il loop di sostegno è derivato dallo stesso composito. Il composito non è presentato come una singola registrazione originale. Quattro articolazioni staccato secondarie mantengono le sorgenti e gli intervalli originali SFZ per strumento, dinamica e RR. Nessun campione Philharmonia o contenuto del vecchio preset. CC0 VSCO 2 CE.\n')
 save_art(folder,'Trap Hit · Libero','trap-hit-libero','#916b49','cello');return folder

# The two SYN kick/clap kit designs are independent original synthesis. All
# drum-set zones use real CC0 Big Rusty performance takes selected from one close mic.
def drum_src(folder,key,src_key,vel_restrict=None):
 mod=ROOT/'python/scripts/build_mog_v1.py';spec=importlib.util.spec_from_file_location('release_mog_ro',mod);base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
 inst=base.sources_big_rusty();return base.selected_brd(inst.regions,[src_key])

def syn_kick(path,style,vel):
 t=np.arange(int(.85*SR))/SR;v=(vel-1)/126
 if style=='trap':freq=47+69*np.exp(-t/(.035+.01*v));dec=.42;harm=.24;click=.12
 elif style=='ita':freq=61+57*np.exp(-t/(.022+.004*v));dec=.32;harm=.40;click=.06
 else:freq=54+77*np.exp(-t/(.018+.006*v));dec=.27;harm=.19;click=.18
 phase=2*np.pi*np.cumsum(freq)/SR
 x=(np.sin(phase)+harm*np.sin(2*phase+.14)+.11*np.sin(3*phase+.31))*np.exp(-t/dec)
 rng=np.random.default_rng(1000+vel+(0 if style=='trap' else 100 if style=='ita' else 300))
 x+=rng.normal(0,1,len(x))*np.exp(-t/.0022)*click*(.55+.65*v)
 x=np.tanh((1.3+.45*v)*x);x*=.48+.33*v
 return x
def syn_clap(style,vel):
 v=(vel-1)/126;t=np.arange(int(.46*SR))/SR; rng=np.random.default_rng(2000+vel+(100 if style=='ita' else 500))
 noise=rng.normal(0,1,len(t));z=np.zeros_like(t)
 bursts=([0,.011,.025,.047] if style=='trap' else [0,.019,.041] if style=='ita' else [0,.008,.016,.029,.052])
 for i,start in enumerate(bursts):
  n0=int(start*SR);n1=min(len(t),n0+int(.05*SR));tau=np.arange(n1-n0)/SR
  z[n0:n1]+=noise[n0:n1]*np.exp(-tau/(.010+.002*i))*(1 if i==len(bursts)-1 else .62)
 body=.22*np.sin(2*np.pi*(178+14*v)*t)*np.exp(-t/.08)+.08*np.sin(2*np.pi*340*t)*np.exp(-t/.04)
 x=np.tanh(1.35*(.22*z+body))*(.5+.28*v)
 return x

def make_kit(slug,variant):
 folder=BANK/'trap'/slug;s=folder/'samples';s.mkdir(parents=True,exist_ok=True)
 # Map 3 drum roles and one genuinely differentiated synth kick/clap across a compact GM layout.
 mapped=[];proof=[];notes=[];credits=[];ranges=[(1,30),(31,55),(56,78),(79,100),(101,127)]
 keymap=variant['map']
 for key,role in keymap.items():
  if role in ('kick','clap'):
   for take,(lo,hi) in enumerate(ranges):
    engine_style=variant['engine_style'];ref=(lo+hi)//2;arr=syn_kick(None,engine_style,ref) if role=='kick' else syn_clap(engine_style,ref)
    rel=f'authored/{role}-{variant["style"]}-v{ref:03d}.wav';dest=s/rel;dest.parent.mkdir(exist_ok=True,parents=True);sf.write(dest,arr,SR,subtype='PCM_24')
    mapped.append({'file':rel,'root':key,'lo':key,'hi':key,'vel':[lo,hi],'take':0,'pitched':False,'one_shot':True})
    proof.append({'included':rel,'sha256_included':sha(dest),'author':'original Libre sound synthesis','design':f'{engine_style} {role}','velocity_reference':ref,'velocity_window':[lo,hi],'deterministic_seed':1000+ref+({'trap':0,'ita':100,'pro':300}[engine_style] if role=='kick' else {'trap':0,'ita':100,'pro':500}[engine_style]),'synthesis_parameters':({'trap':{'kick_start_hz':47,'kick_drop_hz':69,'clap_bursts':[0,.011,.025,.047]},'ita':{'kick_start_hz':61,'kick_drop_hz':57,'clap_bursts':[0,.019,.041]},'pro':{'kick_start_hz':54,'kick_drop_hz':77,'clap_bursts':[0,.008,.016,.029,.052]}}[engine_style])})
  else:
   src_key=variant['sources'][role]
   regs=drum_src(folder,key,src_key)
   take_group={}
   for r in regs:
    src=r.sample;rel,digest=copy_source(src,s)
    # source-label thresholds and RR ids are carried through by parser
    row={'file':rel,'root':key,'lo':key,'hi':key,'vel':[r.lovel,r.hivel],'take':max(0,r.seq_position-1),'pitched':False,'one_shot':True}
    if role in ('hat','hat-open'):row['choke_group']=1
    mapped.append(row);proof.append({'source_path':str(src),'sha256_source':digest,'included':rel,'sha256_included':sha(s/rel),'role':role,'source_key':src_key,'velocity':[r.lovel,r.hivel],'take':r.seq_position-1,'mic':str(src.parent.name)})
 credits.append(credit('Big Rusty Drums v1.100','Zygmunt Szpaderski / D. Smolken · Karoryfer Samples','CC0 1.0','cc0','https://shop.karoryfer.com/pages/free-big-rusty-drums','Raw close-mic performances are preserved; all available recorded velocity layers and round robins for selected articulations are mapped.'))
 credits.append(credit('Original authored trap kick and clap synthesis','Libero design session','CC0 1.0 Universal (proposed local dedication; not published)','cc0','https://creativecommons.org/publicdomain/zero/1.0/','Original electronic synthesis; proposed for public-domain dedication by the project rights-holder in this local preparation. No upload or publication has occurred.'))
 retain_docs(s,[BANK/'mog/memphis-fita/samples/LICENSE-Big-Rusty-Drums.txt'])
 programs=s/'source-maps'/'Programs';shutil.copytree(BRD/'Programs',programs,dirs_exist_ok=True)
 dump(s/'source-map.json',{'source':'Big Rusty Drums v1.100','upstream':'https://github.com/sfzinstruments/karoryfer.big-rusty-drums','upstream_license_url':'https://github.com/sfzinstruments/karoryfer.big-rusty-drums/blob/f07ce00/LICENSE','mapped_zone_count':len(mapped),'source_maps_included':'samples/source-maps/Programs','mapping':'Big Rusty actual source zones parsed with the read-only Mog helper selected_brd; close-mic source, actual keys, performance velocity and RR preserved','source_map_copies':[{'file':str(p.relative_to(s)),'sha256':sha(p)}for p in programs.rglob('*')if p.is_file()]})
 normalize_dynamics(mapped)
 title=variant['title'];source_manifest(folder,proof,credits,mapped,title,variant['subtitle'],['trap','trap-kit',variant['style'],'drums','recorded','original-synthesis','release-replacement'],[k for k in keymap],pitched=False,loop='none',master=-7,one_shot=True)
 save_art(folder,title,slug,variant['color'],'kit');return folder

def build_all():
 DEMO.mkdir(parents=True,exist_ok=True)
 owned=[SOUNDS/'trap-hit-libero',BANK/'trap/trap-kit-libero',BANK/'trap/trap-kit-ita-libero',BANK/'trap/trap-kit-pro-libero',BANK/'trap/trap-coro-libero',BANK/'percussioni/percussioni-mano-libero',BANK/'percussioni/percussioni-texture-libero',SKETCHES/'chitarra-acustica-libero']
 for path in owned:
  if path.exists():shutil.rmtree(path)
 out=[]
 out.append(build_stab())
 out.append(build_choir())
 for slug,variant in [
  ('trap-kit-libero',dict(style='trap-dark',engine_style='trap',title='Trap Kit · Libero',subtitle='Kit essenziale: sweep sub scuro, snare secco, hi-hat chiuso e clap breve',color='#8c5f4a',map={36:'kick',38:'snare',39:'clap',42:'hat',46:'hat-open',40:'rim'},sources={'snare':38,'hat':42,'hat-open':46,'rim':40})),
  ('trap-kit-ita-libero',dict(style='italian',engine_style='ita',title='Trap Kit Italiano · Libero',subtitle='Kit melodico italiano: kick più corto e alto, clap a colpi ravvicinati, percussione/hat articolate',color='#bc7e42',map={36:'kick',38:'snare',39:'clap',42:'hat',46:'hat-open',40:'rim'},sources={'snare':39,'hat':42,'hat-open':46,'rim':37})),
  ('trap-kit-pro-libero',dict(style='pro-articulated',engine_style='pro',title='Trap Kit Pro · Libero',subtitle='Kit articolato: kick doppio-membrana, clap multi-impulso, snare center/rimshot, hi-hat close/open',color='#55717a',map={36:'kick',38:'snare',39:'clap',42:'hat',46:'hat-open',40:'rim'},sources={'snare':38,'hat':44,'hat-open':46,'rim':40}))]:
  out.append(make_kit(slug,variant))
 # Ensure the three kits contain genuinely distinct authored SYN at every
 # velocity, rather than relying on titles or EQ to imply a separate design.
 identity={}
 for slug in ('trap-kit-libero','trap-kit-ita-libero','trap-kit-pro-libero'):
  mp=json.loads((BANK/'trap'/slug/'samples/map.json').read_text())
  authored=[r for r in mp if r['file'].startswith('authored/')]
  identity[slug]={}
  for role in ('kick','clap'):
   byvel=sorted((r['dyn'],sha(BANK/'trap'/slug/'samples'/r['file'])) for r in authored if f'/{role}-' in r['file'])
   identity[slug][role]=byvel
 for role in ('kick','clap'):
  sets=[tuple((tuple(layer),digest) for layer,digest in d[role]) for d in identity.values()]
  if len(set(sets))!=3:raise RuntimeError(f'{role} SYN identity collision across the three kits')
 dump(DEMO/'kit-synthesis-identities.json',identity)
 out.append(build_vcs_hand('percussioni-mano-libero',False));out.append(build_vcs_hand('percussioni-texture-libero',True));out.append(build_guitar())
 return out

def measure_default_pitch(folder,folder_report,dft,roots):
 from calibrate_blue_v6_body import estimate
 pitch=[];pitch_keys=sorted(set(roots+[k for z in dft for k in (z['lo'],z['hi'])]))
 for key in pitch_keys:
  f=folder_report/f'pitch-{key:03d}.wav';render.render(folder,f,f'{key}:0:1.5:92',tail=.1);a=Audio.load(f);x=np.asarray(a.data)
  seg=x[int(.25*a.sr):int(min(1.2,len(x)/a.sr)*a.sr)];expected=440*2**((key-69)/12)
  if folder.name=='trap-coro-libero':
   freq,voiced=librosa_f0(seg,expected,a.sr);cents=1200*math.log2(freq/expected);method='constrained autocorrelation/refinement for human voice'
  else:freq,cents=estimate(seg,a.sr,expected);voiced=None;method='expected-note multi-harmonic FFT'
  item={'key':key,'measured_hz':freq,'cents':cents,'method':method,'kind':'sample-root' if key in roots else 'mapping-edge'}
  if voiced is not None:item['voiced_fraction']=voiced
  pitch.append(item)
 return {'test':'default-root-and-mapping-edge-pitch','count':len(pitch),'max_abs_cents':max(abs(z['cents']) for z in pitch),'measurements':pitch}

def choir_partial_center(seg,sr,expected):
 # Power centroids of the coherent harmonic family over two complete mapped
 # periods. This averages natural vowel vibrato instead of selecting its phase.
 x=np.asarray(seg).mean(axis=1);x=x-np.mean(x);n=1<<int(np.ceil(np.log2(max(4096,len(x)))));spec=np.abs(np.fft.rfft(x*np.hanning(len(x)),n));hz=np.fft.rfftfreq(n,1/sr);parts=[]
 for h in range(1,9):
  centre=expected*h
  if centre>=sr*.45:break
  ix=np.flatnonzero((hz>=centre*2**(-90/1200))&(hz<=centre*2**(90/1200)))
  if len(ix)<3:continue
  power=spec[ix]**2;total=float(power.sum())
  if total<=0:continue
  parts.append((float((hz[ix]*power).sum()/total)/h,float(np.sqrt(total))))
 if not parts:raise RuntimeError('Choir partial-family pitch estimator found no in-band harmonics')
 cents=np.array([1200*np.log2(f/expected) for f,w in parts]);weights=np.array([w for f,w in parts]);order=np.argsort(cents);cum=np.cumsum(weights[order]);median=float(cents[order[np.searchsorted(cum,cum[-1]/2)]])
 keep=np.abs(cents-median)<35
 if not keep.any():keep=np.ones(len(cents),dtype=bool)
 return float(expected*2**(np.average(cents[keep],weights=weights[keep])/1200))

def measure_choir_matrix(folder,folder_report,manifest,roots):
 rows=json.loads((folder/'samples/map.json').read_text());art_ids=manifest.get('articulations',[]);results=[]
 axes=[('pp',.25),('forte',.75)];groups=[]
 for art_ix,art in enumerate(art_ids):
  for dyn_name,axis in axes:
   events=[];schedule=[];cursor=0.0
   for root in roots:
    if not any(r.get('articulation')==art['id'] and r['root']==root and r.get('dyn',[0,1])[0]<=axis<r.get('dyn',[0,1])[1] for r in rows):
     raise RuntimeError(f'Choir source cell missing: {art["id"]}/{dyn_name}/MIDI {root}')
    zone=next(z for z in manifest['zones'] if z.get('articulation')==art['id'] and z['root']==root and z.get('dyn',[0,1])[0]<=axis<z.get('dyn',[0,1])[1] and z.get('loop'))
    playback_scale=2**((root-zone['root']+zone.get('tune_cents',0)/100)/12)
    loop_entry=zone['loop']['end']/manifest['sample_rate']/playback_scale
    period=(zone['loop']['end']-zone['loop']['start'])/manifest['sample_rate']/playback_scale
    duration=loop_entry+2*period+.04;start=cursor;cursor+=duration+.22
    events.append((root,start,duration,92));schedule.append((art_ix,art['id'],dyn_name,axis,root,start,loop_entry,period))
   groups.append((art_ix,art['id'],dyn_name,axis,events,schedule))
 for art_ix,vowel,dyn_name,axis,events,schedule in groups:
  tmp=folder_report/f'.choir-{vowel}-{dyn_name}-native.wav'
  render.render(folder,tmp,events,{'artic':art_ix,'dyn_mode':'Manopola','dynamics':axis,'rev_mix':0,'lvl_tail':-60,'lvl_air':-60},tail=.1,timeout=600)
  audio,sr=sf.read(tmp,always_2d=True,dtype='float64');tmp.unlink(missing_ok=True)
  for _,_,_,_,root,start,loop_entry,period in schedule:
   f=folder_report/f'pitch-{vowel}-{dyn_name}-{root:03d}.wav';seg=audio[round((start+loop_entry)*sr):round((start+loop_entry+2*period)*sr)]
   if len(seg)<int(1.8*period*sr):raise RuntimeError(f'Choir native body window too short: {vowel}/{dyn_name}/{root}')
   expected=440*2**((root-69)/12);mono=seg.mean(axis=1);freq,voiced=estimate_f0(mono,sr,expected*.8,expected*1.2)
   if not np.isfinite(freq) or voiced<.55:raise RuntimeError(f'Unvoiced native Choir cell {vowel}/{dyn_name}/{root} (two complete mapped loop periods)')
   cents=1200*math.log2(freq/expected);family_hz=choir_partial_center(seg,sr,expected);family_cents=1200*math.log2(family_hz/expected);rms=float(20*math.log10(np.sqrt(np.mean(seg*seg)+1e-30)))
   results.append({'vowel':vowel,'source_dynamic':dyn_name,'axis':axis,'key':root,'measured_fundamental_hz':freq,'fundamental_center_cents':cents,'partial_family_center_hz_diagnostic_only':family_hz,'partial_family_center_cents_diagnostic_only':family_cents,'voiced_fraction':voiced,'body_rms_dbfs':rms,'loop_entry_seconds':loop_entry,'loop_period_seconds':period,'method':'after original performance reaches mapped loop end: constrained YIN median of two complete playback-speed-adjusted loop periods for the composite fundamental; coherent partial-family centroid retained as diagnostic only because three singers can beat and have different upper-partial centers; lane pitch calibration is separately recorded in source-proof.json'})
 return {'test':'all-vowels-and-recorded-dynamics-native-pitch','cell_count':len(art_ids)*len(axes),'measurements_per_cell':len(roots),'loop_periods_per_measurement':2,'metric_role':'Composite fundamental is checked for same-note/octave errors and continuity, not forced to one centroid across independently moving singers. ±5c calibration is measured per singer stem in samples/source-proof.json.','max_abs_cents':max(abs(r['fundamental_center_cents']) for r in results),'partial_family_diagnostic_max_abs_cents':max(abs(r['partial_family_center_cents_diagnostic_only']) for r in results),'cells':[{'vowel':a['id'],'source_dynamic':d,'axis':v,'root_count':len(roots),'max_abs_cents':max(abs(r['fundamental_center_cents']) for r in results if r['vowel']==a['id'] and r['source_dynamic']==d),'max_partial_family_diagnostic_cents':max(abs(r['partial_family_center_cents_diagnostic_only']) for r in results if r['vowel']==a['id'] and r['source_dynamic']==d)} for a in art_ids for d,v in axes],'measurements':results}

def correct_choir_matrix(folder,measure):
 mp=folder/'samples/map.json';rows=json.loads(mp.read_text());proof=json.loads((folder/'samples/source-proof.json').read_text());corrections=[]
 for q in measure['measurements']:
  if abs(q['cents'])<=5:continue
  candidates=[r for r in rows if r.get('articulation')==q['vowel'] and r['root']==q['key'] and r.get('dyn',[0,1])[0]<=q['axis']<r.get('dyn',[0,1])[1]]
  if len(candidates)!=1:raise RuntimeError(f'Expected one Choir map row for {q["vowel"]}/{q["source_dynamic"]}/{q["key"]}, found {len(candidates)}')
  row=candidates[0];delta=-float(q['cents'])
  if abs(delta)>100:raise RuntimeError(f'Choir tuning correction outside ±100 cents at MIDI {q["key"]}: {delta:.1f}')
  row['tune_cents']=float(row.get('tune_cents',0))+delta
  for item in proof:
   if item.get('vowel')==q['vowel'] and item.get('played_root')==q['key'] and item.get('technique')==q['source_dynamic']:
    item['native_qa_adjustment_cents']=item.get('native_qa_adjustment_cents',0)+delta;item['native_qa_before_offset_cents']=q['cents']
  corrections.append({'vowel':q['vowel'],'source_dynamic':q['source_dynamic'],'played_key':q['key'],'measured_offset_cents':q['cents'],'applied_zone_tune_cents':delta})
 if not corrections:return False
 mp.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');dump(folder/'samples/source-proof.json',proof)
 path=folder/'samples/native-tuning-corrections.json';previous=json.loads(path.read_text()) if path.exists() else {'iterations':0,'corrections':[]}
 dump(path,{'method':'fresh native render of all A/E/O × pp/forte cells; median constrained autocorrelation on active body and per-zone static fine tune; natural source modulation retained','iterations':previous.get('iterations',0)+1,'superseded_history':previous.get('superseded_history',[]),'corrections':previous.get('corrections',[])+corrections})
 return True

def correct_choir_from_native(folder,measure):
 mp=folder/'samples/map.json';rows=json.loads(mp.read_text());proof=json.loads((folder/'samples/source-proof.json').read_text())
 corrections=[];default='a';axis=.72
 for q in measure['measurements']:
  if abs(q['cents'])<=1:continue
  candidates=[r for r in rows if r.get('articulation')==default and r['lo']<=q['key']<=r['hi']]
  if not candidates:continue
  active=[r for r in candidates if r.get('dyn') and r['dyn'][0]<=axis<r['dyn'][1]]
  chosen=active or candidates;root=min(chosen,key=lambda r:abs(r['root']-q['key']))['root'];chosen=[r for r in chosen if r['root']==root]
  delta=-q['cents']
  if abs(delta)>100:raise RuntimeError(f'Choir correction outside ±100 cents at MIDI {q["key"]}: {delta:.1f}')
  for r in chosen:r['tune_cents']=float(r.get('tune_cents',0))+delta
  for item in proof:
   if item.get('vowel')==default and item.get('played_root')==root and item.get('technique')=='forte':
    item['native_qa_adjustment_cents']=item.get('native_qa_adjustment_cents',0)+delta;item['native_qa_before_offset_cents']=q['cents']
  corrections.append({'played_key':q['key'],'mapped_root':root,'measured_offset_cents':q['cents'],'applied_zone_tune_cents':delta})
 if not corrections:return False
 mp.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');dump(folder/'samples/source-proof.json',proof)
 correction_path=folder/'samples/native-tuning-corrections.json'
 previous=json.loads(correction_path.read_text()) if correction_path.exists() else {'iterations':0,'corrections':[]}
 dump(correction_path,{'method':'fresh native render, voiced fundamental estimate, per-key zone correction','iterations':previous.get('iterations',0)+1,'corrections':previous.get('corrections',[])+corrections})
 return True

def correct_guitar_from_native(folder,measure):
 mp=folder/'samples/map.json';rows=json.loads(mp.read_text());proof=json.loads((folder/'samples/source-proof.json').read_text());corrections=[]
 art='fingerstyle'
 for q in measure['measurements']:
  if q.get('kind')!='sample-root' or abs(q['cents'])<=1:continue
  candidates=[r for r in rows if r.get('articulation')==art and r['root']==q['key']]
  if not candidates:continue
  delta=-float(q['cents'])
  if abs(delta)>25:raise RuntimeError(f'Guitar native tuning correction outside ±25 cents at MIDI {q["key"]}: {delta:.1f}')
  for r in candidates:r['tune_cents']=float(r.get('tune_cents',0))+delta
  for item in proof:
   if item.get('preset')=='guitar-fingerstyle' and item.get('generator_root_key_override')==q['key']:
    item['native_qa_adjustment_cents']=item.get('native_qa_adjustment_cents',0)+delta
  corrections.append({'played_key':q['key'],'mapped_root':q['key'],'measured_offset_cents':q['cents'],'applied_zone_tune_cents':delta})
 if not corrections:return False
 mp.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');dump(folder/'samples/source-proof.json',proof)
 path=folder/'samples/native-tuning-corrections.json';previous=json.loads(path.read_text()) if path.exists() else {'iterations':0,'corrections':[]}
 dump(path,{'method':'fresh native root render with expected-note spectrum estimate; per-root fine tuning','iterations':previous.get('iterations',0)+1,'corrections':previous.get('corrections',[])+corrections})
 return True

def qa(folder):
 c=compile_sound(folder,jobs=1)
 print('compile',folder.name,c.text(),flush=True)
 if not c.ok:raise RuntimeError(f'compile failure {folder.name}: {c.text()}')
 findings=lint_bundle(folder/'build');fails=[x.line() for x in findings if x.level=='FAIL'];warn=[x.line() for x in findings if x.level=='WARN']
 (folder/'lint.txt').write_text('\n'.join(x.line() for x in findings)+'\n')
 if fails:raise RuntimeError(f'{folder.name} lint failures: {fails}')
 manifest=json.loads((folder/'build/manifest.json').read_text());fresh=library.source_hash(folder)==manifest.get('source_hash')
 if not fresh:raise RuntimeError(f'{folder.name} manifest/source hash stale')
 p=DEMO/folder.name;p.mkdir(parents=True,exist_ok=True);native=[]
 default_art=manifest.get('articulations',[{'id':None}])[0]['id']
 dft=[z for z in manifest['zones'] if z.get('pitched',True) and z.get('articulation') in (None,default_art)]
 held=bool(dft) and not manifest.get('one_shot',False)
 if held:
  roots=sorted({z['root'] for z in dft});played_keys=sorted({k for z in dft for k in range(z['lo'],z['hi']+1)})
  if folder.name=='trap-coro-libero':pitchcheck=measure_choir_matrix(folder,p,manifest,roots)
  else:pitchcheck=measure_default_pitch(folder,p,dft,roots)
  native.append(pitchcheck)
  if folder.name=='trap-coro-libero':
   proof=json.loads((folder/'samples/source-proof.json').read_text());stem_rows=[q['stem_native_pitch_audit'] for q in proof if q.get('stem_native_pitch_audit')];loop_stems=[q for q in stem_rows if q.get('loop_source_frames_before')];fallback_stems=[q for q in stem_rows if not q.get('loop_source_frames_before')];loop_max=max((abs(float(q['performed_loop_offset_cents_after_correction'])) for q in loop_stems),default=0);fallback_max=max((abs(float(q['performed_loop_offset_cents_after_correction'])) for q in fallback_stems),default=0)
   pitchcheck['stem_calibration']={'lane_measurements':len(stem_rows),'loop_backed_lane_count':len(loop_stems),'loop_backed_max_abs_residual_cents':loop_max,'loop_backed_within_5_cents':loop_max<=5.0,'continuous_body_fallback_count':len(fallback_stems),'fallback_max_abs_residual_cents':fallback_max,'fallback_reason':'some individual long-tone excerpts have no ≥0.55s seamless loop; their longest continuous held body is measured, and the final composite gets its own held loop','method':'each recorded singer independently calibrated after target-key transpose; fixed offset only; natural vibrato preserved'}
   if loop_max>5:raise RuntimeError(f'{folder.name} loop-backed singer-stem calibration exceeds ±5 cents: {loop_max:.2f}')
   if fallback_max>20:raise RuntimeError(f'{folder.name} continuous-body singer-stem calibration exceeds ±20 cents: {fallback_max:.2f}')
   if pitchcheck['max_abs_cents']>100:raise RuntimeError(f'{folder.name} composite fundamental deviates by more than a semitone or failed octave guard: {pitchcheck["max_abs_cents"]:.2f} cents')
  elif folder.name=='chitarra-acustica-libero' and pitchcheck['max_abs_cents']>5:
   correction_path=folder/'samples/native-tuning-corrections.json';iteration=json.loads(correction_path.read_text()).get('iterations',0) if correction_path.exists() else 0
   if iteration<3 and correct_guitar_from_native(folder,pitchcheck):
    corrected=compile_sound(folder,jobs=1)
    if not corrected.ok:raise RuntimeError(f'{folder.name} native calibration compile failed: {corrected.text()}')
    return qa(folder)
  if folder.name!='trap-coro-libero' and pitchcheck['max_abs_cents']>5:raise RuntimeError(f'{folder.name} native source-root pitch error exceeds 5 cents: {pitchcheck}')
  # Short notes and genuine sustained checks in low, center, and high registers.
  picks=[played_keys[0],played_keys[len(played_keys)//2],played_keys[-1]]
  if folder.name=='chitarra-acustica-libero':picks=[41,60,76]
  late_checks=[]
  for label,key in zip(('low','mid','high'),picks):
   f=p/f'{label}.wav';render.render(folder,f,f'{key}:0:2:92',tail=.2)
   a=Audio.load(f);x=np.asarray(a.data);native.append({'test':label,'key':key,'peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'clipped':int(np.count_nonzero(np.abs(x)>=1))})
   f=p/f'hold-{label}-60s.wav';render.render(folder,f,f'{key}:0:60:92',tail=1);a=Audio.load(f);x=np.asarray(a.data);late=x[10*a.sr:59*a.sr];lr=float(20*np.log10(np.sqrt(np.mean(late*late))+1e-20))
   late_checks.append(lr);native.append({'test':'hold-60s','register':label,'key':key,'peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'late_rms_10_59_dbfs':lr,'clipped':int(np.count_nonzero(np.abs(x)>=1))})
  if min(late_checks)<-50:raise RuntimeError(f'{folder.name} held body is too quiet in at least one tested register: {late_checks}')
  candidates=[k for k in played_keys if all(k+i in played_keys for i in (0,4,7,11,12,16,19,24))]
  chord_keys=[(candidates[len(candidates)//2] if candidates else min(played_keys))+i for i in (0,4,7,11,12,16,19,24)]
  if any(k not in played_keys for k in chord_keys):raise RuntimeError(f'{folder.name} has no in-range 8-note stress voicing')
  events=','.join(f'{k}:0:6:127' for k in chord_keys)
  chord=p/'chord8-v127-default.wav';render.render(folder,chord,events,tail=1);a=Audio.load(chord);native.append({'test':'8-note-voicing-v127-default-dynamics','keys':chord_keys,'event_count':len(chord_keys),'peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'clipped':int(np.count_nonzero(np.abs(a.data)>=1))})
  chord=p/'chord8-v127-manopola1.wav';render.render(folder,chord,events,params={'dyn_mode':'Manopola','dynamics':1},tail=1);a=Audio.load(chord);native.append({'test':'8-note-voicing-v127-max-dynamics','keys':chord_keys,'event_count':len(chord_keys),'peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'clipped':int(np.count_nonzero(np.abs(a.data)>=1))})
  for ix,art in enumerate(manifest.get('articulations',[])[1:],start=1):
   note=next((z['root'] for z in manifest['zones'] if z.get('articulation')==art['id']),None)
   if note is None:continue
   f=p/f'art-{art["id"]}.wav';render.render(folder,f,f'{note}:0:1.2:127',params={'artic':ix},tail=.2);a=Audio.load(f);native.append({'test':'secondary-articulation-v127','articulation':art['id'],'key':note,'peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'clipped':int(np.count_nonzero(np.abs(a.data)>=1))})
 else:
  keys=sorted({z.get('root',60) for z in manifest['zones']});key=keys[len(keys)//2] if keys else 60
  f=p/'groove.wav';render.render(folder,f,','.join(f'{keys[i%len(keys)]}:{i*.2:.2f}:.18:{60+(i%3)*30}' for i in range(24)) if keys else f'{key}:0:.18:100',tail=2);a=Audio.load(f);native.append({'test':'percussion-groove','peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'clipped':int(np.count_nonzero(np.abs(a.data)>=1))})
  stress_keys=[keys[i%len(keys)] for i in range(8)] if keys else []
  if len(stress_keys)!=8:raise RuntimeError(f'{folder.name} missing eight mapped hit events')
  chord=p/'8-hit-overlap-v127.wav';render.render(folder,chord,','.join(f'{k}:0:1:127' for k in stress_keys),tail=2);a=Audio.load(chord);native.append({'test':'8-hit-overlap-v127','event_count':len(stress_keys),'keys':stress_keys,'peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'clipped':int(np.count_nonzero(np.abs(a.data)>=1))})
 if any(x.get('clipped',0) or x.get('peak_dbfs',-120)>-3 for x in native):raise RuntimeError(f'{folder.name} native clipping/headroom check failed: {native}')
 pitchcheck=next((x for x in native if x['test']=='default-root-and-mapping-edge-pitch'),None)
 report={'slug':folder.name,'title':manifest.get('title'),'zones':len(manifest.get('zones',[])),'source_hash':manifest.get('source_hash'),'source_hash_fresh':fresh,'license':manifest.get('license'),'license_class':manifest.get('license_class'),'lint':{'FAIL':len(fails),'WARN':len(warn),'INFO':sum(x.level=='INFO' for x in findings),'warnings':warn},'native':native,'limitations':'No subjective listening claim; RMS/pitch/loop/lint metrics are technical checks only.'}
 dump(p/'report.json',report);return report

def main(qa_only=False):
 folders=[SOUNDS/'trap-hit-libero',BANK/'trap/trap-coro-libero',BANK/'trap/trap-kit-libero',BANK/'trap/trap-kit-ita-libero',BANK/'trap/trap-kit-pro-libero',BANK/'percussioni/percussioni-mano-libero',BANK/'percussioni/percussioni-texture-libero',SKETCHES/'chitarra-acustica-libero'] if qa_only else build_all();reports=[]
 for p in folders:reports.append(qa(p))
 dump(DEMO/'report.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'8 newly created -libero preset folders only; no existing preset or bank metadata changed','presets':reports,'source_families':{'VCSL':'CC0 1.0','VSCO 2 CE':'CC0 1.0','VocalSet':'CC BY 4.0','TavyMusic PluckedStrings SF2':'CC0 1.0 as stated in SF2 INFO and author redistribution statement','Big Rusty Drums':'CC0 1.0','original SYN':'new authored synthesis with local CC0 1.0 dedication draft; not published'}})
 print('DONE',len(reports),'only-owned replacement presets',flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--qa-only',action='store_true');main(ap.parse_args().qa_only)
