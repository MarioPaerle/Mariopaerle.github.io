"""Install three recorded basses. The rejected BMC slap remains an explicit diagnostic.
No bank metadata mutation; run from repo root with python/.venv/bin/python.
"""
from pathlib import Path
import json,re,shutil,argparse
from collections import Counter
from libero import dsp
HOME=Path.home(); CACHE=HOME/'Libero/cache/libraries'; BANK=HOME/'Libero/banks/bassi'
SLUGS=['contrabbasso-jazz','basso-flatwound','basso-hollowbody']
ALL_SLUGS=SLUGS+['basso-slap']
def note(s,octave_offset=0):
 m=re.fullmatch(r'([a-g])([b#]?)(\d)',s.lower()); assert m,s
 return dsp.parse_note(m[1].upper()+m[2]+m[3])+octave_offset
def add(rows,f,root,art,dyn=(0,1),take=0,pitched=True,**kw):
 rows.append(dict(file=str(f),root=root,articulation=art,dyn=list(dyn),take=take,loop='none',pitched=pitched,**kw))
def bounds(rows):
 # Keep natural recorded compass. No keyboard-wide stretching of a tiny slap source.
 for art in {r['articulation'] for r in rows}:
  rr=[r for r in rows if r['articulation']==art];roots=sorted({r['root'] for r in rr})
  for r in rr:
   i=roots.index(r['root']);r['lo']=roots[0] if i==0 else (roots[i-1]+roots[i])//2+1
   r['hi']=roots[-1] if i==len(roots)-1 else (roots[i]+roots[i+1])//2
def build(slug):
 assert slug in ALL_SLUGS,slug
 folder=BANK/slug
 if folder.exists() and not (folder/'samples/map-bassi.json').exists():
  backup=HOME/'Libero-backups/2026-10-02/bassi-v2'/slug
  assert not backup.exists(),backup
  backup.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(folder,backup,symlinks=False)
 folder.mkdir(parents=True,exist_ok=True);(folder/'samples').mkdir(exist_ok=True)
 body=[];tail=[];sources=[]
 if slug=='contrabbasso-jazz':
  title='Contrabbasso Jazz';subtitle='Otto Rubner 1958 · quattro dinamiche · sessione quieta separata'
  arts=[('pizz','Pizzicato'),('quiet','Notturno'),('ghost','Ghost'),('mute','Muto'),('finger','Dita'),('perc','Percussioni')]
  sources=['karoryfer-meatbass','karoryfer-sneakybass']
  for f in sorted((CACHE/sources[0]/'Samples/pizz').glob('*.wav')):
   m=re.fullmatch(r'([a-g][b#]?\d)_vl(\d)_rr(\d)\.wav',f.name)
   if m:add(body,f,note(m[1]),'pizz',((int(m[2])-1)/4,int(m[2])/4),int(m[3])-1)
   else:
    m=re.fullmatch(r'perc(\d)_rr(\d)\.wav',f.name);assert m,f
    add(body,f,35+int(m[1]),'perc',take=int(m[2])-1,pitched=False,one_shot=True)
  for f in sorted((CACHE/sources[1]/'Samples').rglob('*.wav')):
   m=re.fullmatch(r'sneakybass_([a-g][b#]?\d)_(pluck|ghost|mute|finger|noise)_rr(\d)\.wav',f.name);assert m,f
   root=note(m[1],-12);kind=m[2];art={'pluck':'quiet','noise':None}.get(kind,kind)
   if kind=='noise':add(tail,f,root,None,take=int(m[3])-1,pitched=False,rt_decay=12,rt_min_db=-48)
   else:add(body,f,root,art,take=int(m[3])-1,pitched=kind!='ghost')
  identity='Contrabbasso acustico Otto Rubner 1958, Spirocore, accordatura in quinte. Meatbass offre quattro intensità e quattro esecuzioni per nota; Sneakybass una sessione pizzicata molto quieta, ghost, mute, dita e rilascio. Due sessioni selezionabili, mai sommate o spacciate per dinamiche della stessa registrazione.'
 elif slug=='basso-flatwound':
  title='Basso Flatwound';subtitle='Ibanez BTB400QM · corde Chrome consumate · pickup al manico'
  arts=[('finger','Dita'),('open','Corda aperta'),('noise','Gesti e rumori')];sources=['karoryfer-swagbass']
  for f in sorted((CACHE/sources[0]/'notes').glob('*.wav')):
   m=re.fullmatch(r'([a-g][b#]?\d)_(open_)?(p|f|fff)_rr(\d)\.wav',f.name);assert m,f
   v={'p':(0,50/127),'f':(50/127,110/127),'fff':(110/127,1)}[m[3]]
   add(body,f,note(m[1],-12),'open' if m[2] else 'finger',v,int(m[4])-1)
  for f in sorted((CACHE/sources[0]/'release').glob('*.wav')):
   m=re.fullmatch(r'([a-g][b#]?\d)_release_rr(\d)\.wav',f.name);assert m,f
   add(tail,f,note(m[1],-12),None,take=int(m[2])-1,pitched=False,rt_decay=12,rt_min_db=-48)
  kinds=sorted({re.sub(r'_rr\d+\.wav$','',f.name) for f in (CACHE/sources[0]/'noises').glob('*.wav')})
  for f in sorted((CACHE/sources[0]/'noises').glob('*.wav')):
   m=re.fullmatch(r'(.*)_rr(\d)\.wav',f.name);assert m,f
   add(body,f,36+kinds.index(m[1]),'noise',take=int(m[2])-1,pitched=False,one_shot=True,**({'gain_db':12} if m[1]=='noise_fingering' else {}))
  identity='Ibanez BTB-400QM con vecchie D’Addario Chrome flatwound, pickup al manico, DI senza effetti ed EQ onboard piatto. Tre dinamiche, quattro RR, tre RR release, cinque RR dei dieci gesti; la corda aperta registrata rimane una articolazione separata.'
 elif slug=='basso-hollowbody':
  title='Basso Hollowbody';subtitle='Darkblack cinque corde · quattro dinamiche · corpo cavo'
  arts=[('finger','Dita'),('ghost','Ghost'),('stacc','Staccato'),('btb','Dietro il ponte'),('open','Ponte aperto'),('fx','Gesti al ponte')];sources=['karoryfer-black-and-blue-basses']
  for f in sorted((CACHE/sources[0]/'Samples/darkblack').rglob('*.wav')):
   m=re.fullmatch(r'darkblack_([a-g][b#]?\d)_(p|mp|mf|f|ghost_p|ghost_f|stac|rel|btb|btb_open)_rr(\d)\.wav',f.name)
   if not m:
    m=re.fullmatch(r'darkblack_btb_fx(\d)_rr(\d)\.wav',f.name);assert m,f
    add(body,f,35+int(m[1]),'fx',take=int(m[2])-1,pitched=False,one_shot=True);continue
   root=note(m[1],-12);kind=m[2];take=int(m[3])-1
   if kind=='rel':add(tail,f,root,None,take=take,pitched=False,rt_decay=12,rt_min_db=-48)
   elif kind in ('p','mp','mf','f'):
    i=['p','mp','mf','f'].index(kind);add(body,f,root,'finger',(i/4,(i+1)/4),take,**({'gain_db':1.5} if i==3 and root in (41,42,43) else {}))
   elif kind.startswith('ghost'):
    i=int(kind.endswith('_f'));add(body,f,root,'ghost',(i/2,(i+1)/2),take,pitched=False)
   else:add(body,f,root,{'stac':'stacc','btb':'btb','btb_open':'open'}[kind],take=take,pitched=kind=='stac',one_shot=True)
  identity='Darkblack è un hollowbody cinque corde con registrazioni DI genuine, distinte dal flatwound Ibanez. Dita cromatiche B0–E4, quattro dinamiche e quattro RR; ghost due dinamiche, staccato, corde dietro il ponte e gesti, release quattro RR. I suoni inarmonici del ponte mantengono velocità originale.'
 else:
  title='Basso Slap';subtitle='Bruce H. McCosar · pollice e pop reali · mappa compatta'
  arts=[('slap','Slap lungo'),('pop','Pop lungo'),('short','Slap corto'),('popshort','Pop corto'),('hammer','Hammer'),('pophammer','Pop hammer'),('thump','Thump')];sources=['bmc-slap']
  for f in sorted((CACHE/'bmc-slap').glob('*.flac')):
   m=re.fullmatch(r'([a-g](?:b)?)(pop)?_(long|short)\.flac',f.name.lower())
   if m:
    # The six ascending A-string notes cross C: A1/Bb1/B1/C2/D2/Eb2.
    # Filenames omit octave, so one fixed suffix would mis-map half by 12 semitones.
    octave=1 if m[1] in ('a','bb','b') else 2
    root=note(m[1]+str(octave+bool(m[2])));art=('pop' if m[2] else 'slap') if m[3]=='long' else ('popshort' if m[2] else 'short')
    add(body,f,root,art,one_shot=m[3]=='short');continue
   if 'hamm' in f.name.lower():
    pop='pop'in f.name.lower();root=(35 if f.name.lower().startswith('ab') else 36)+(12 if pop else 0)
    add(body,f,root,'pophammer' if pop else 'hammer',pitched=False,one_shot=True)
   else:add(body,f,36,'thump',take=int(f.stem[-1])-1,pitched=False,one_shot=True)
  identity='NON ACCETTATO: sorgente bocciata dall’utente per qualità dello slap; conservata come diagnosi riproducibile, non come sostituzione riuscita. Slap e pop eseguiti da Bruce H. McCosar, registrati sulla corda A: sei radici A1, Bb1, B1, C2, D2, Eb2 e i corrispondenti pop una ottava sopra; lunghi e smorzati distinti, quattro hammer e due thump. Un solo livello e un solo take per nota: questa fonte compatta non pretende la profondità dei due elettrici maggiori.'
 bounds(body)
 if tail:bounds(tail)
 # Link originals, preserve provenance and never bake blends or processing into raw files.
 files_by_source={s:[] for s in sources}
 for r in body+tail:
  f=Path(r['file']);source=next(s for s in sources if s in f.parts);rel=f.relative_to(CACHE/source)
  dst=folder/'samples'/source/rel;dst.parent.mkdir(parents=True,exist_ok=True)
  if not dst.exists():dst.symlink_to(f)
  r['file']=str(dst.relative_to(folder/'samples'));files_by_source[source].append(str(rel))
 credits=[]
 for s in sources:
  isbmc=s=='bmc-slap';name=s.replace('karoryfer-','')
  lic='CC BY 3.0' if isbmc else 'CC0 1.0 Universal'
  url='https://ccmixter.org/files/bmccosar/13742' if isbmc else 'https://shop.karoryfer.com/pages/free-'+name
  credits.append(dict(source=s,author='Bruce H. McCosar' if isbmc else 'Karoryfer Samples / D. Smolken',license=lic,license_class='by' if isbmc else 'cc0',url=url,retrieved='2026-10-02',files=files_by_source[s]))
  if not isbmc:
   original=CACHE/s/('license' if 'black-and' in s else 'LICENSE');shutil.copy2(original,folder/'samples'/s/'LICENSE')
 (folder/'samples/credits.json').write_text(json.dumps(credits,indent=2)+'\n')
 (folder/'samples/ATTRIBUTION.md').write_text('\n\n'.join(f"{c['source']}: {c['author']}. {c['license']}. {c['url']}. Original samples linked unchanged; Libero conversion trims pre-roll, resamples and fades only; one static fine-tuning and bounded gain may be applied." for c in credits)+'\n')
 if slug=='basso-slap':
  with (folder/'samples/ATTRIBUTION.md').open('a') as attribution:attribution.write('\nLicense: https://creativecommons.org/licenses/by/3.0/ — source author and conversion changes stated above.\n')
 (folder/'samples/map-bassi.json').write_text(json.dumps(dict(body=body,tail=tail),indent=2)+'\n')
 a=[dict(id=id,name=name,key=12+i) for i,(id,name) in enumerate(arts)]
 proc=dict(tune='detect',ladder='smooth',ladder_max_db=3.0,max_step_db=9.5,peak_db=-10,align_ms=0 if slug!='basso-slap' else 5,pre_ms=10 if slug!='basso-slap' else 4,loop='none',max_seconds=None,end_db=-80,fade_ms=30,encoding='flac24',edge_fill=False)
 (folder/'sound.py').write_text(f'''"""Recorded {title}. Rebuild: python/scripts/build_bassi_acoustic.py."""
import json
from pathlib import Path
from libero import Sound, Audio
import numpy as np
def preserve_preroll(audio, region, ctx):
    x=audio.data
    pad=np.zeros((int(round(.010*audio.sr)),)+x.shape[1:],dtype=x.dtype)
    return Audio(np.concatenate([pad,x]),audio.sr)
MAP=json.loads((Path(__file__).parent/'samples/map-bassi.json').read_text())
sound=Sound(title={title!r},subtitle={subtitle!r},tags=['plucked','bass','sampled'],sample_rate=48000)
sound.articulations({a!r})
sound.multisample('body',MAP['body'],process={proc!r}{',custom=preserve_preroll' if slug!='basso-slap' else ''})
if MAP['tail']:sound.multisample('tail',MAP['tail'],process={{'tune':'none','ladder':'keep','align_ms':0,'pre_ms':2,'end_db':-80,'fade_ms':30,'loop':'none','edge_fill':False}})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,velocity_curve=1,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=1800)
sound.defaults(artic=0,mode='Poli',glide=0,voices=16,dyn_mode='Velocità',amp_attack=0,amp_decay=6000,amp_sustain=1,amp_release=120,lvl_body=0,lvl_tail=0,lvl_air=-60,vel_sens=0.35,master=0,humanize=0,tape_wow=0,tape_flutter=0,tape_sat=0,lfo_pitch=0,lfo_amp=0,drive=0,echo_mix=0,rev_mode='Cappella',rev_mix={0.04 if slug=='contrabbasso-jazz' else 0},rev_size=0.35,rev_decay=0.8,rev_predelay=10,rev_damp=0.55)
''')
 notes=f'''# {title} — 2 ottobre 2026

{identity}

## Costruzione

Registrazioni originali integre e tutte le loro dinamiche, RR e articolazioni pertinenti. Ogni zona riproduce un solo file: niente blending, dinamiche inventate, EQ duplicati o bassi sintetici sotto le registrazioni. Nessun loop; la tenuta termina col decadimento naturale. La fine del file conserva gesto e rumore, con dissolvenza finale breve. Non si importano unisoni GUI che duplicano le registrazioni originali.

Mappatura su altezza fisicamente misurata: i nomi Sneakybass, Swagbass e Darkblack sono una ottava sopra il fondamentale reale, mentre Meatbass e BMC usano nomi standard. Gli estremi restano limitati alle radici registrate; non c'è pitch stretching illimitato. Le variazioni interne di attacco e intonazione restano quelle suonate, con una sola correzione fine costante, mai vibrato sintetico o pitch flattening.

Process: guadagno globale con calibrazione locale limitata, nessuna normalizzazione per file; peak massimo di progetto −10 dBFS per headroom, stereo originale per Sneakybass, DI mono per gli elettrici. Prima del trim si aggiungono 10ms di silenzio per assicurare il preroll anche nei file che iniziano subito; si conserva un preroll completo di10ms. Nessun allineamento forzato di fase tra RR o dinamiche: il crossfade è zero. Release originali come tail non intonati, attenuati di12dB/s secondo il tempo tenuto. Poli, glide0, wow/flutter0, humanize aggiunto0, dinamiche velocity senza crossfade.

## Tastiera

'''+ '\n'.join(f"- {dsp.note_name(x['key'])}: {x['name']} ({x['id']})." for x in a)+ '\n\n## Fonte e licenza\n\n'+ '\n'.join(f"- {c['source']}, {c['author']}, {c['license']}: {c['url']}" for c in credits)+ '\n\nPosso misurare e ispezionare questi file, non ascoltarli; la verifica non garantisce preferenza percettiva. Standard Bass V2 escluso perché i termini originali vietano la modifica senza permesso.\n'
 (folder/'notes.md').write_text(notes)
 desc='Il corpo e le corde indicano la registrazione reale; il punto dorato è il gesto di eccitazione. I tratti ripetuti sono le esecuzioni indipendenti, non una modulazione artificiale.'
 outline='M235 185 C185 155 170 220 207 252 C170 280 155 373 213 416 Q256 440 299 416 C357 373 342 280 305 252 C342 220 327 155 277 185' if slug=='contrabbasso-jazz' else 'M238 228 C210 190 176 195 180 240 Q140 274 184 355 Q203 410 256 410 Q324 413 334 356 Q375 303 328 258 Q312 228 283 233'
 strings=''.join(f'<path d="M{x} 95 L{x} 395" stroke="currentColor" stroke-width="0.55"/>' for x in (244,252,260,268))
 hatch=''.join(f'<path d="M{295+i} {300+i//2} l12 26" stroke="currentColor" stroke-width="0.45"/>' for i in range(0,27,4))
 (folder/'figure.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>{desc}</desc><path d="{outline} Z" stroke="currentColor" stroke-width="1.3"/><path d="M238 96 L274 96 L274 235 L238 235 Z" fill="#f3eee6" stroke="currentColor" stroke-width="0.9"/>{strings}{hatch}<path d="M225 372 L287 372 L284 385 L228 385 Z" stroke="currentColor" stroke-width="1"/><circle cx="263" cy="283" r="5" fill="#b8924f"/><path d="M252 414 L252 456 M260 414 L260 456" stroke="currentColor" stroke-width="0.8"/></svg>')
 plate=Path(__file__).with_name('build_bassi_acoustic_figures')/(slug+'.svg')
 if plate.exists():shutil.copy2(plate,folder/'figure.svg')
 print(slug,Counter(r['articulation'] for r in body),'tails',len(tail),flush=True)
def retire_old():
 old=HOME/'Libero/banks/archi/contrabbasso-jazz';new=BANK/'contrabbasso-jazz'
 assert (new/'build/manifest.json').exists(),'compile replacement before retiring previous sound'
 if old.exists():
  dependencies=[str(p) for p in (HOME/'Libero/banks').rglob('*') if p.is_symlink() and (p.resolve()==old or old in p.resolve().parents)]
  assert not dependencies,dependencies
  backup=HOME/'Libero-backups/2026-10-02/bassi-v2/contrabbasso-jazz-previous-archi'
  assert not backup.exists(),backup
  backup.parent.mkdir(parents=True,exist_ok=True)
  # Full independent snapshot first, including dereferenced cached recordings;
  # then retain the original tree separately instead of deleting it.
  shutil.copytree(old,backup,symlinks=False)
  original=backup.with_name(backup.name+'-original-tree');assert not original.exists(),original
  shutil.move(str(old),str(original))
  (new/'migration.json').write_text(json.dumps(dict(previous_path=str(old),preserved_original_tree=str(original),independent_backup=str(backup),dependent_symlinks=dependencies),indent=2)+'\n')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('slugs',nargs='*',default=SLUGS);ap.add_argument('--retire-old',action='store_true');args=ap.parse_args()
 if args.retire_old:retire_old()
 else:
  for s in args.slugs:build(s)
