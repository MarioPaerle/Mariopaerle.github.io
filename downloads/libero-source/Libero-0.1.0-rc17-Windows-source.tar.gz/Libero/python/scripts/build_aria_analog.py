"""Install two source-led Jupiter-4 instruments from Rick Taylor's public-domain recordings.

Fetch is deliberately separate: original AIFF and SFZ files must already be in
~/Libero/cache/research/aria-hardware. No proprietary presets or demonstration audio.
"""
from pathlib import Path
import sys,json,re,hashlib,shutil
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero import render,analysis
import soundfile as sf
import numpy as np
CACHE=Path.home()/'Libero/cache/research/aria-hardware'
BANK=Path.home()/'Libero/banks/aria'
OUT=Path.home()/'Libero/demo/aria-analog';OUT.mkdir(parents=True,exist_ok=True)
PATCHES=[('jupiter-unisono','Giove · Unisono','JP4 - Unison Pad','Pads',80,10000,1,.65),
         ('chiave-di-petali','Chiave di Petali','Petals Piano','Keys',0,650,.22,.22)]
URL='https://github.com/publicsamples/Roland-Jupiter-4'

def figure(title,pad):
 body='<path d="M82 325V194L107 173H406L430 194V325Z" fill="#f3eee6" stroke-width="1.3"/><path d="M94 195H418V270H94ZM104 282H408V316H104Z" stroke-width=".8"/>'
 for x in range(113,407,21):body+=f'<path d="M{x} 283V315" stroke-width=".6"/>'
 for x in range(115,406,42):body+=f'<circle cx="{x}" cy="223" r="9" stroke-width="1.1"/><path d="M{x} 220V215" stroke-width=".7"/>'
 for y in range(242,260,4):body+=f'<path d="M109 {y}H403" stroke-width=".4"/>'
 if pad:
  for i in range(5):
   y=108+i*9;body+=f'<path d="M113 {y}C165 {y-17} 220 {y+18} 265 {y}S351 {y-18} 401 {y}" stroke="{ "#b8924f" if i==2 else "currentColor"}" stroke-width="{1.3 if i==2 else .55}"/>'
 else:
  for i in range(7):
   x=140+i*35;body+=f'<path d="M{x} 147V110Q{x+5} 97 {x+12} 108V144M{x+12} 125Q{x+21} 124 {x+24} 112" stroke="{"#b8924f" if i==3 else "currentColor"}" stroke-width="{1.3 if i==3 else .6}"/>'
 body+='<path d="M105 337H409M120 344H394" stroke-width=".6"/>'
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>Registrazione del Jupiter-4: pannello e tastiera; il segno dorato distingue l’unisono mobile dalla voce a pizzico filtrato.</desc>{body}</svg>\n'

def main():
 rows=[]
 for slug,title,patch,kind,attack,decay,sustain,release in PATCHES:
  dest=BANK/slug
  if dest.exists() and not (dest/'notes.md').exists():raise RuntimeError('Refusing unfamiliar directory')
  (dest/'samples').mkdir(parents=True,exist_ok=True)
  text=(CACHE/(patch+'.sfz')).read_text();regions=[];provenance=[]
  if (CACHE/'LICENSE.txt').is_file():shutil.copy2(CACHE/'LICENSE.txt',dest/'samples/LICENSE.txt')
  for root in range(48,85,3):
   sources=list((CACHE/'audio'/kind).glob(f'{patch}-{root}-127*.aif'))
   if not sources:continue
   source=sources[0];x,sr=sf.read(source,dtype='float64')
   region_text=next(block for block in text.split('<region>')[1:] if source.name in block)
   def value(key,default):
    m=re.search(r'\b'+key+r'=([\d.-]+)',region_text);return float(m[1]) if m else default
   offset=int(value('offset',0));end=int(value('end',len(x)-1))+1
   volume=value('volume',0);x=x[offset:min(end,len(x))]
   # Original SFZ gain is part of the recorded patch's keyboard balance.
   # Keep it below unity here; compiler sets one safe instrument-wide gain.
   x=x*10**((volume-12)/20)
   target=dest/'samples'/f'key-{root}.wav';sf.write(target,x,sr,subtype='PCM_24')
   regions.append({'file':target.name,'root':root-12,'take':0,'one_shot':False,'loop':'none'})
   provenance.append({'file':source.name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_key':root,'sounding_root':root-12,'original_offset':offset,'original_end':end,'original_volume_db':volume,'seconds':len(x)/sr})
  roots=[r['root'] for r in regions]
  (dest/'samples/map.json').write_text(json.dumps({'body':regions},indent=2)+'\n')
  credit={'source':f'Rick Taylor / Modular Samples · Jupiter-4 · {patch}','author':'Rick Taylor (Modular Samples)','license':'Public domain / Unlicense','license_class':'cc0','url':URL,'license_url':URL+'/blob/master/LICENSE','files':[f'samples/{r["file"]}' for r in regions],'notes':'Original hardware recordings, not commercial-ROM samples. No fake velocity layers or round robins.'}
  (dest/'samples/credits.json').write_text(json.dumps([credit],indent=2)+'\n')
  (dest/'samples/provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
  recipe=f'''from libero import Sound
import json
from pathlib import Path
sound=Sound(title={title!r},subtitle={'Jupiter-4 registrato · unisono lungo e mobile' if kind=='Pads' else 'Jupiter-4 registrato · pizzico filtrato e decadimento'!r},tags=['aria','sampled-analog','jupiter-4',{'pad' if kind=='Pads' else 'keys'!r}],roots={roots!r},velocities=[100],sample_rate=48000)
sound.multisample('body',json.loads((Path(__file__).parent/'samples/map.json').read_text())['body'],process={{'pre_ms':2,'align_ms':0,'tune':'source','ladder':'keep','peak_db':-12,'max_seconds':None,'fade_ms':35,'loop':'none','encoding':'flac24','mono':False}},as_dyn=False)
sound.performance(dynamics_source='velocity',velocity_curve=1,dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},one_shot=False)
sound.defaults(mode='Poli',voices=16,glide=0,master=-3,vel_sens=.35,amp_attack={attack},amp_decay={decay},amp_sustain={sustain},amp_release={release*1000},osc1_level=-60,osc2_level=-60,sub_level=-60,lvl_body=0,lvl_attack=-60,lvl_tail=-60,lvl_air=-60,flt_cutoff=20000,flt_reso=0,flt_env=0,drive=0,tape_wow=0,tape_flutter=0,tape_sat=0,tape_age=0,tape_mix=0,lfo_pitch=0,lfo_amp=0,res_mix=0,echo_mix=0,rev_mix=0,rev_shimmer=0)
'''
  (dest/'sound.py').write_text(recipe);(dest/'figure.svg').write_text(figure(title,kind=='Pads'))
  (dest/'notes.md').write_text(f'''# {title}

Original analog Jupiter-4 recording `{patch}` by Rick Taylor / Modular Samples.
{len(roots)} recorded roots, spaced three semitones, from MIDI {min(roots)} to {max(roots)}. One recorded velocity and one take per root: velocity controls gain, no fabricated dynamics or round robins. The hardware patch uses a 16-foot octave: source key labels are remapped down 12 semitones to their measured sounding fundamentals (source audit in demo/aria-analog/source-pitch-audit.json). Residual analog tuning and motion are retained, without synthetic support, wow, added effects or reverb. Original SFZ offsets/end and keyboard gains are recorded in `samples/provenance.json`; original loops are intentionally not used. Full source decay/gesture is retained; a held note eventually reaches the recording's end. Note-off releases it via the amplitude envelope.

Public domain / Unlicense: {URL}/blob/master/LICENSE
Original source: {URL}

Technical checks diagnose playback and headroom. They do not certify musical taste or equivalence to a commercial library.
''')
  c=compile_sound(dest)
  if not c.ok:raise RuntimeError(c.text())
  lint=[f.line() for f in lint_bundle(dest/'build')]
  phrase='48:0:3.2:105,55:0:3.2:98,60:0:3.2:100,64:0:3.2:93,53:3.6:3.2:105,60:3.6:3.2:98,65:3.6:3.2:100,69:3.6:3.2:93' if kind=='Pads' else '60:0:.55:105,67:.75:.25:90,70:1.12:.38:99,72:1.5:.8:112,67:2.5:.5:99,65:3.25:.5:95,63:4:.5:108,60:4.75:1.2:102'
  pv=render.preview(slug,phrase,tail=2);shutil.copy2(pv.wav,OUT/(slug+'-phrase.wav'))
  features=analysis.features(pv.audio)
  pv=render.preview(slug,'60:0:10:100',tail=2);shutil.copy2(pv.wav,OUT/(slug+'-held.wav'))
  rows.append({'slug':slug,'roots':roots,'lint':lint,'phrase':features,'source':provenance})
  print(slug,len(roots),lint,features['peak_db'],flush=True)
 (OUT/'report.json').write_text(json.dumps(rows,indent=2)+'\n')
if __name__=='__main__':main()
