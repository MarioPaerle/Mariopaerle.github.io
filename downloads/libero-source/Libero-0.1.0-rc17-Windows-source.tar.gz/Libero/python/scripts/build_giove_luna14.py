#!/usr/bin/env python3
"""Build the 14 Luna Giove programmes (10 original synths, 2 recorded mallets x 2).

Hardware references are design inspiration only. The electronic voices contain
first-party synthesis; the mallets preserve VCSL source performances and offer
both the unmodified strike and an explicitly designed same-source sustain.
"""
from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import argparse, importlib.util, json, math, re, shutil, sys

import numpy as np
import soundfile as sf

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero import render
from libero.audio import Audio
from libero.compiler import compile_sound
from libero.dsp import estimate_f0
from libero.figure import validate_svg
from libero.lint import lint_bundle
from libero.library import source_hash
from giove_mallet_cells import common_cells

HOME=Path.home(); BANK=HOME/'Libero/banks/giove'; MALLET_BANK=HOME/'Libero/banks/percussioni'; CACHE=HOME/'Libero/cache/libraries/vcsl'
OUT=HOME/'Libero/demo/giove-luna14'; SR=48000
OUT.mkdir(parents=True,exist_ok=True)
NOTE_PC={'C':0,'C#':1,'Db':1,'D':2,'D#':3,'Eb':3,'E':4,'F':5,'F#':6,'Gb':6,'G':7,'G#':8,'Ab':8,'A':9,'A#':10,'Bb':10,'B':11}
DYN={'pp':[1,42],'ff':[43,127],'soft':[1,38],'med':[39,82],'loud':[83,127]}

def midi(label):
    m=re.fullmatch(r'([A-G](?:#|b)?)(-?\d+)',label)
    if not m: raise ValueError(label)
    return (int(m.group(2))+1)*12+NOTE_PC[m.group(1)]
def note_token(name):
    m=re.search(r'(?<![A-Za-z])([A-G](?:#|b)?-?\d+)(?!\d)',Path(name).stem)
    if not m: raise ValueError(f'no note token: {name}')
    return m.group(1)
def digest(p): return sha256(Path(p).read_bytes()).hexdigest()
def dump(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def freq(n): return 440.0*2**((n-69)/12)

SYNTHS=[
 dict(slug='moog-minimoog-deep-ladder',title='Minimoog · Deep Ladder',family='moog',role='pedal bass',accent='#9a593a',osc1_wave='Sega',osc1_level=-13,osc2_wave='Quadra',osc2_level=-25,osc2_oct=-1,osc2_pw=.50,sub_level=-25,flt_mode='Basso',flt_cutoff=1150,flt_reso=.11,flt_env=.20,fenv_attack=0,fenv_decay=290,fenv_sustain=.22,amp_attack=3,amp_decay=900,amp_sustain=1,amp_release=130,master=-9,rev_mode='Cappella',rev_mix=.008,rev_size=.18,rev_decay=.35,echo_mix=0,flt_vel=.08,flt_key=.42),
 dict(slug='moog-minimoog-brass-ladder',title='Minimoog · Brass Ladder',family='moog',role='brass lead',accent='#ad6848',osc1_wave='Sega',osc1_level=-15,osc2_wave='Quadra',osc2_level=-19,osc2_oct=0,osc2_pw=.46,sub_level=-38,flt_mode='Basso',flt_cutoff=2450,flt_reso=.17,flt_env=.37,fenv_attack=0,fenv_decay=420,fenv_sustain=.28,amp_attack=6,amp_decay=1000,amp_sustain=1,amp_release=210,master=-9,rev_mode='Cappella',rev_mix=.018,rev_size=.18,rev_decay=.42,echo_mix=0,flt_vel=.11,flt_key=.36),
 dict(slug='moog-modular-harmonic-reed',title='Moog Modular · Harmonic Reed',family='moog',role='formant lead',accent='#795b47',osc1_wave='Quadra',osc1_level=-15,osc1_pw=.29,osc2_wave='Sega',osc2_level=-25,osc2_oct=0,osc2_pw=.5,sub_level=-42,flt_mode='Vocale',flt_cutoff=2150,flt_reso=.16,flt_env=.23,fenv_attack=20,fenv_decay=780,fenv_sustain=.42,amp_attack=18,amp_decay=900,amp_sustain=1,amp_release=250,master=-8,rev_mode='Piastra',rev_mix=.022,rev_size=.20,rev_decay=.62,echo_mix=0,flt_vel=.06,flt_key=.32),
 dict(slug='moog-taurus-pedal-foundation',title='Taurus · Pedal Foundation',family='moog',role='organ pedal bass',accent='#77513e',osc1_wave='Triangolo',osc1_level=-13,osc2_wave='Sega',osc2_level=-23,osc2_oct=-1,osc2_pw=.5,sub_level=-23,sub_wave='Seno',flt_mode='Basso',flt_cutoff=760,flt_reso=.07,flt_env=.11,fenv_attack=0,fenv_decay=220,fenv_sustain=.48,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=190,master=-9,rev_mode='Cappella',rev_mix=.006,rev_size=.16,rev_decay=.3,echo_mix=0,flt_vel=.04,flt_key=.54),
 dict(slug='sub37-duo-saw-lead',title='Subsequent 37 · Duo Saw',family='sub37',role='focused lead',accent='#8b744a',osc1_wave='Sega',osc1_level=-18,osc2_wave='Sega',osc2_level=-22,osc2_fine=2.0,osc2_pw=.5,sub_level=-32,flt_mode='Basso',flt_cutoff=3300,flt_reso=.10,flt_env=.22,fenv_attack=0,fenv_decay=480,fenv_sustain=.48,amp_attack=4,amp_decay=900,amp_sustain=1,amp_release=180,master=-5,rev_mode='Piastra',rev_mix=.02,rev_size=.2,rev_decay=.5,echo_mix=0,flt_vel=.07,flt_key=.30),
 dict(slug='sub37-pulse-contour',title='Subsequent 37 · Pulse Contour',family='sub37',role='short articulated lead',accent='#a07b4e',osc1_wave='Quadra',osc1_level=-16,osc1_pw=.24,osc2_wave='Triangolo',osc2_level=-23,osc2_oct=1,sub_level=-35,flt_mode='Banda',flt_cutoff=2650,flt_reso=.21,flt_env=.44,fenv_attack=0,fenv_decay=360,fenv_sustain=.15,amp_attack=0,amp_decay=630,amp_sustain=.90,amp_release=130,master=-5,rev_mode='Cappella',rev_mix=.012,rev_size=.16,rev_decay=.35,echo_mix=0,flt_vel=.09,flt_key=.24),
 dict(slug='sub37-feedback-organ',title='Subsequent 37 · Feedback Organ',family='sub37',role='compact chord/stab',accent='#66765a',osc1_wave='Quadra',osc1_level=-17,osc1_pw=.51,osc2_wave='Sega',osc2_level=-23,osc2_oct=0,osc2_voices=2,osc2_detune=.07,osc2_spread=.22,sub_level=-34,flt_mode='Banda',flt_cutoff=4100,flt_reso=.08,flt_env=.06,fenv_attack=30,fenv_decay=1100,fenv_sustain=.58,amp_attack=10,amp_decay=1100,amp_sustain=1,amp_release=220,master=-6,rev_mode='Cappella',rev_mix=.014,rev_size=.18,rev_decay=.4,echo_mix=0,flt_vel=.05,flt_key=.25),
 dict(slug='solar42f-five-drone-voice',title='Solar 42F · Five Drone Voice',family='solar42f',role='warm drone / pad',accent='#7b6551',osc1_wave='Sega',osc1_level=-15,osc1_voices=5,osc1_detune=.12,osc1_spread=.18,osc2_wave='Triangolo',osc2_level=-26,osc2_oct=0,sub_level=-36,flt_mode='Basso',flt_cutoff=3200,flt_reso=.08,flt_env=.06,fenv_attack=160,fenv_decay=1700,fenv_sustain=.72,amp_attack=175,amp_decay=10000,amp_sustain=1,amp_release=700,master=-9,rev_mode='Cappella',rev_mix=.025,rev_size=.2,rev_decay=.6,echo_mix=0,flt_vel=.03,flt_key=.32),
 dict(slug='solar42f-polivoks-pair',title='Solar 42F · Polivoks Pair',family='solar42f',role='dual-band lead / pad',accent='#936e53',osc1_wave='Sega',osc1_level=-17,osc2_wave='Quadra',osc2_level=-23,osc2_pw=.35,sub_level=-37,flt_mode='Banda',flt_cutoff=1850,flt_reso=.23,flt_env=.17,fenv_attack=85,fenv_decay=1500,fenv_sustain=.62,amp_attack=90,amp_decay=1700,amp_sustain=1,amp_release=650,master=-5,rev_mode='Cisterna',rev_mix=.038,rev_size=.26,rev_decay=1.0,echo_mix=.012,flt_vel=.04,flt_key=.38),
 dict(slug='solar42f-dual-vco-swell',title='Solar 42F · Dual VCO Swell',family='solar42f',role='sweeping lead',accent='#a37c59',osc1_wave='Sega',osc1_level=-17,osc2_wave='Quadra',osc2_level=-22,osc2_pw=.41,sub_level=-34,flt_mode='Basso',flt_cutoff=2900,flt_reso=.14,flt_env=.26,fenv_attack=600,fenv_decay=1800,fenv_sustain=.58,amp_attack=370,amp_decay=1600,amp_sustain=1,amp_release=720,master=-8,rev_mode='Piastra',rev_mix=.03,rev_size=.25,rev_decay=.85,echo_mix=0,flt_vel=.05,flt_key=.28),
 dict(slug='mercury-glass-current',title='Mercury · Glass Current',family='mercury-x',role='ambient glass current',accent='#658b87',osc1_wave='Triangolo',osc1_level=-11,osc2_wave='Seno',osc2_level=-17,osc2_oct=1,sub_level=-28,flt_mode='Banda',flt_cutoff=4800,flt_reso=.09,flt_env=.08,fenv_attack=800,fenv_decay=2400,fenv_sustain=.74,amp_attack=780,amp_decay=2500,amp_sustain=1,amp_release=1700,master=2,rev_mode='Basilica',rev_mix=.08,rev_size=.35,rev_decay=2.2,echo_mix=.035,flt_vel=.025,flt_key=.18,lfo_rate=.07,lfo_cutoff=.08),
 dict(slug='mercury-deep-orbit',title='Mercury · Deep Orbit',family='mercury-x',role='warm ambient drone',accent='#586c80',osc1_wave='Sega',osc1_level=-19,osc2_wave='Triangolo',osc2_level=-22,osc2_oct=-1,sub_level=-30,flt_mode='Basso',flt_cutoff=1550,flt_reso=.12,flt_env=.08,fenv_attack=1000,fenv_decay=3000,fenv_sustain=.68,amp_attack=1050,amp_decay=3200,amp_sustain=1,amp_release=1900,master=-5,rev_mode='Cisterna',rev_mix=.065,rev_size=.31,rev_decay=1.8,echo_mix=.045,flt_vel=.025,flt_key=.43,lfo_rate=.055,lfo_cutoff=.05),
]

MALLETS=[
 dict(slug='marble-xylophone-vcsl',title='Marble · Xylophone',sub='VCSL · legno alto e mazze distinte · attacco registrato, corpo sostenuto derivato',accent='#a87d48',folder='Xylophone',kind='xylo'),
 dict(slug='marble-marimba-vcsl',title='Marble · Marimba',sub='VCSL · barre lignee profonde a tre dinamiche · corpo sostenuto derivato',accent='#7b6948',folder='Marimba',kind='marimba'),
]

def svg(spec):
    # A measured design plate: oscillator paths, harmonic rails, and a single
    # gold element reserved for the defining resonator/interval.
    harmonics=spec.get('harmonics',[1,2,3,4,5,6])
    role=spec.get('role','mallet')
    bars=[]
    for i,h in enumerate(harmonics):
        x=74+i*62; height=26+118/(h**.63)
        col='#b8924f' if i==(len(harmonics)//2) else 'currentColor'
        bars.append(f'<path d="M{x} 355 V{355-height:.1f}" stroke="{col}" stroke-width="1.2"/>')
        bars.extend(f'<path d="M{x-8} {355-height+j*7:.1f} h16" stroke="currentColor" stroke-width=".35"/>' for j in range(1,4))
    profile=[]
    for i in range(28):
        t=i/27; y=100+spec.get('envelope',.6)*92*(1-math.exp(-6*t))*math.exp(-2.4*t)
        profile.append(f'{"M" if i==0 else "L"}{80+i*12.5:.1f} {y:.1f}')
    body=' '.join([
      '<path d="M58 403 H454 M58 403 V382 M454 403 V382" stroke="currentColor" stroke-width="1.2"/>',
      '<path d="M70 88 H442 M70 88 V370 M442 88 V370" stroke="currentColor" stroke-width=".7"/>',
      '<path d="M82 222 C136 172 190 286 246 230 S354 190 430 236" stroke="#b8924f" stroke-width="1.3"/>',
      '<path d="M82 263 C145 241 208 280 273 254 S370 247 430 269" stroke="currentColor" stroke-width=".7" stroke-dasharray="3 4"/>',
      *bars,
      f'<path d="{" ".join(profile)}" stroke="currentColor" stroke-width="1.1"/>',
      '<path d="M81 118 h42 m-42 9 h42 m-42 9 h42 M389 118 h42 m-42 9 h42 m-42 9 h42" stroke="currentColor" stroke-width=".45"/>',
      '<circle cx="256" cy="230" r="18" stroke="#b8924f" stroke-width="1.1"/>',
      '<circle cx="256" cy="230" r="4" fill="#b8924f" stroke="#b8924f" stroke-width=".5"/>',
    ])
    desc=f'{spec["title"]}: {role}; {len(harmonics)} measured or designed harmonic rails, with the gold line identifying the defining resonance. The upper curve is the authored envelope or resonant continuation.'
    text=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{spec["title"]}</title><desc>{desc}</desc>{body}</svg>'
    errors=validate_svg(text)
    if errors: raise ValueError(f'{spec["slug"]} SVG invalid: {errors}')
    return text

def write_synth(spec):
    dest=BANK/spec['slug']
    if dest.exists():
        proof=dest/'samples'/'source-proof.json'; old=dest/'sound.py'
        owned=(old.exists() and 'cc0-draft' in old.read_text()) or (proof.exists() and json.loads(proof.read_text()).get('preset')==spec['slug'])
        if not owned: raise RuntimeError(f'refusing existing folder: {dest}')
        shutil.rmtree(dest)
    dest.mkdir(parents=True); (dest/'samples').mkdir()
    cfg={k:v for k,v in spec.items() if k not in ('slug','title','family','role','accent','custom')}
    defaults=dict(mode='Poli',glide=0,voices=24,amp_attack=spec['amp_attack'],amp_decay=spec['amp_decay'],amp_sustain=spec['amp_sustain'],amp_release=spec['amp_release'],master=spec['master'],vel_sens=.36,
          osc1_wave=spec['osc1_wave'],osc1_level=spec['osc1_level'],osc1_oct=spec.get('osc1_oct',0),osc1_semi=spec.get('osc1_semi',0),osc1_fine=spec.get('osc1_fine',0),osc1_pw=spec.get('osc1_pw',.5),osc1_voices=spec.get('osc1_voices',1),osc1_detune=spec.get('osc1_detune',0),osc1_spread=spec.get('osc1_spread',0),osc1_phase=0,
          osc2_wave=spec['osc2_wave'],osc2_level=spec['osc2_level'],osc2_oct=spec.get('osc2_oct',0),osc2_semi=spec.get('osc2_semi',0),osc2_fine=spec.get('osc2_fine',0),osc2_pw=spec.get('osc2_pw',.5),osc2_voices=spec.get('osc2_voices',1),osc2_detune=spec.get('osc2_detune',0),osc2_spread=spec.get('osc2_spread',0),osc2_phase=0,sub_level=spec['sub_level'],sub_wave=spec.get('sub_wave','Seno'),osc_drift=0,osc_retrig='Libera',
          flt_mode=spec['flt_mode'],flt_cutoff=spec['flt_cutoff'],flt_reso=spec['flt_reso'],flt_key=spec['flt_key'],flt_vel=spec['flt_vel'],flt_env=spec['flt_env'],fenv_source='Propria',fenv_attack=spec['fenv_attack'],fenv_decay=spec['fenv_decay'],fenv_sustain=spec['fenv_sustain'],fenv_release=max(1,spec['amp_release']),
          lfo_shape='Seno',lfo_rate=spec.get('lfo_rate',5),lfo_pitch=0,lfo_cutoff=spec.get('lfo_cutoff',0),lfo_delay=0,lfo_amp=0,lfo_pw=0,
          drive=0,width=1,rev_mode=spec['rev_mode'],rev_mix=spec['rev_mix'],rev_size=spec['rev_size'],rev_decay=spec['rev_decay'],echo_mix=spec['echo_mix'],tape_wow=0,tape_flutter=0,tape_sat=0,tape_mix=0,caldi_mode='Spento',lvl_body=0,lvl_attack=-60,lvl_tail=-60,lvl_air=-60)
    recipe=f'''from libero import Sound
sound=Sound(title={spec['title']!r},subtitle={spec['role']+' · sintesi originale ispirata all’architettura, non campionamento hardware'!r},tags=['giove','{spec['family']}','synth','original','cc0-draft'],roots=list(range(36,85,3)),velocities=[36,80,116],sample_rate=48000,accent={spec['accent']!r},seed=20371004)
sound.performance(dynamics_source='velocity',velocity_curve=.72,dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=1500)
sound.defaults(**{defaults!r})
'''
    (dest/'sound.py').write_text(recipe)
    figure_spec={**spec,'harmonics':[1,2,3,4,5,6,7,8],'envelope':.55}
    (dest/'figure.svg').write_text(svg(figure_spec))
    proof={'preset':spec['slug'],'title':spec['title'],'route':'SYN; original first-party Libero oscillator synthesis; no commercial audio, presets, or ROM included','inspiration_family':spec['family'],'design_role':spec['role'],'design_parameters':cfg if spec.get('custom') else {k:v for k,v in spec.items() if k not in ('slug','title','accent')},'license_proposal':{'license':'CC0 1.0','license_class':'cc0','status':'local authoring-session dedication proposal; no upload/publication performed'},'limits':'Hardware names describe design inspiration. This is not a recording, exact circuit simulation, or proprietary patch dump.'}
    if spec['family']=='solar42f': proof['reference']={'path':str(HOME/'Libero/cache/research/giove/solar42f-manual.pdf'),'sha256':digest(HOME/'Libero/cache/research/giove/solar42f-manual.pdf'),'note':'Solar 42F manual: six drone voices; four use five saw oscillators each; two Papa Srapa FM voices; two VCOs and dual Polivoks filters. This programme borrows only the named design cue.'}
    dump(dest/'samples/source-proof.json',proof)
    dump(dest/'samples/credits.json',[{'source':'Original Libero oscillator synthesis authored for Giove','author':'Mario Prignano / Libero authoring session','license':'CC0 1.0 (local dedication proposal)','license_class':'cc0','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','notes':'No third-party sample audio, ROM or factory patch included. CC0 status is a proposal for the newly authored output pending project-owner confirmation; no public release performed.'}])
    (dest/'notes.md').write_text(f'''# {spec['title']}\n\nSYN original, design inspiration only. {spec['role']}. The local credit proposes CC0 1.0 for this new work; no upload or release has occurred. Exact synthesis parameters and design disclaimer are in `samples/source-proof.json`.\n\nDefault is Poli, glide 0, sustain 1, drive 0, wow/flutter 0, CaldiSpento. Pitch motion is zero unless explicitly introduced by the player; all preset motion is spectral/envelope/reverb rather than pitch wobble. 60-second holds are verified as live synthesis or a looped synthesized buffer. Measurements verify the engine/render and do not claim listener approval or hardware identity.\n''')
    c=compile_sound(dest,jobs=2)
    if getattr(c,'error',None): raise RuntimeError(f"{spec['slug']} compile: {c.text()}")
    return dest

def read_pitch(path, written_midi):
    x,sr=sf.read(path,dtype='float64',always_2d=True); x=x.mean(axis=1)
    seg=x[int(.12*sr):min(len(x),int(.65*sr))]
    hz,voiced=estimate_f0(seg,sr,fmin=freq(written_midi)*.88,fmax=freq(written_midi)*1.12)
    if not np.isfinite(hz) or voiced<.45:return None
    return round(1200*math.log2(float(hz)/freq(written_midi)),3),round(float(voiced),3)

def local_synth_qc(spec):
    slug=spec['slug']; folder=BANK/slug; build=folder/'build'; params={'mode':'Poli','voices':16,'amp_attack':0,'lfo_pitch':0,'lfo_cutoff':0,'amp_release':8}
    results={'slug':slug,'source_hash':source_hash(folder),'source_hash_fresh':False,'tests':[]}
    for label,key in [('low',40),('mid',60),('high',80)]:
        wav=OUT/f'{slug}-{label}-hold.wav'; info=render.render(build,wav,f'{key}:0:60:112',params=params,tail=.2)
        a=Audio.load(wav); x=np.asarray(a.data,dtype=float); x=x.mean(axis=1) if x.ndim>1 else x
        rms=lambda q:20*np.log10(max(float(np.sqrt(np.mean(np.asarray(q)**2))),1e-15))
        peak=20*np.log10(max(float(np.max(np.abs(x))),1e-15))
        late=rms(x[int(10*SR):int(59*SR)])
        pitch=read_pitch(wav,key)
        results['tests'].append({'test':'60s-native-hold','register':label,'key':key,'rms_dbfs':round(rms(x),2),'late_rms_10_59_dbfs':round(late,2),'peak_dbfs':round(peak,2),'clipped':int(np.sum(np.abs(x)>=.999)),'fundamental_cents':None if pitch is None else pitch[0],'voiced_fraction':None if pitch is None else pitch[1]})
    notes=[48,52,55,59,60,64,67,72]
    chord=OUT/f'{slug}-chord8.wav';render.render(build,chord,','.join(f'{n}:0:4:127' for n in notes),params={**params,'voices':16},tail=.25)
    ca=Audio.load(chord); cx=np.asarray(ca.data,dtype=float)
    results['tests'].append({'test':'8-note-v127-chord','notes':notes,'peak_dbfs':round(20*np.log10(max(float(np.max(np.abs(cx))),1e-15)),2),'clipped':int(np.sum(np.abs(cx)>=.999))})
    # Stabilized chromatic pitch-map probe at 60 and 116 velocity for all keys
    # between chosen anchors catches cell-edge errors without relying on a label.
    events=[(n,v) for n in range(36,85) for v in (60,116)]
    notestr=','.join(f'{n}:{i*.40:.3f}:.36:{v}' for i,(n,v) in enumerate(events))
    pitchwav=OUT/f'{slug}-chromatic.wav';render.render(build,pitchwav,notestr,params=params,tail=.3)
    px=np.asarray(Audio.load(pitchwav).data,dtype=float);px=px.mean(axis=1) if px.ndim>1 else px
    errors=[]
    for i,(n,v) in enumerate(events):
        seg=px[int((i*.40+.09)*SR):int((i*.40+.34)*SR)]
        hz,voiced=estimate_f0(seg,SR,fmin=freq(n)*.88,fmax=freq(n)*1.12)
        if np.isfinite(hz) and voiced>.4: errors.append(1200*math.log2(float(hz)/freq(n)))
        else: errors.append(None)
    good=[abs(v) for v in errors if v is not None]
    chrom={'test':'chromatic-map-native','event_count':len(events),'measured_count':len(good),'missing_count':len(errors)-len(good),'max_abs_cents':round(max(good,default=0),2),'threshold_cents':5}
    results['tests'].append(chrom)
    l=lint_bundle(build); warnings=[x.line() for x in l]
    results['lint']={'FAIL':sum(s.startswith('FAIL') for s in warnings),'WARN':sum(s.startswith('WARN') for s in warnings),'INFO':sum(s.startswith('INFO') for s in warnings),'warnings':warnings}
    m=json.loads((build/'manifest.json').read_text()); results['manifest_source_hash']=m.get('source_hash'); results['source_hash_fresh']=m.get('source_hash')==results['source_hash']
    chord_test=next(t for t in results['tests'] if t['test']=='8-note-v127-chord')
    results['quality']={'pitch_pass':chrom['missing_count']==0 and chrom['max_abs_cents']<=5,'hold_pass':all(t['late_rms_10_59_dbfs']>=-50 and t['clipped']==0 for t in results['tests'] if t['test']=='60s-native-hold'),'chord_pass':chord_test['peak_dbfs']<=-3 and chord_test['clipped']==0,'lint_pass':results['lint']['FAIL']==0}
    if not results['source_hash_fresh']: raise RuntimeError(f'stale build: {slug}')
    return results

def source_files(inst):
    base=CACHE/'Idiophones'/'Struck Idiophones'/inst['folder']
    return sorted(p for p in base.rglob('*.wav') if p.is_file())

def sample_pitch(path,label_midi):
    x,sr=sf.read(path,dtype='float64',always_2d=True); mono=x.mean(axis=1)
    # VCSL labels for these struck-bar folders are one octave below playback.
    # Search around that expected sounding root; a real source outlier is mapped
    # to its nearest measured key rather than being retuned almost a semitone.
    expected=label_midi+12; target=freq(expected)
    seg=mono[int(.05*sr):min(len(mono),int(.6*sr))]
    hz,voiced=estimate_f0(seg,sr,fmin=target*2**(-1.15/12),fmax=target*2**(1.15/12))
    method='YIN source-period estimate'
    if not np.isfinite(hz) or voiced<.35:
        # At the upper bars YIN may not have enough periods in the attack/body
        # window. Fall back to the strongest local modal peak around the
        # expected written root and keep that method explicit in provenance.
        win=seg*np.hanning(len(seg)); nfft=1<<int(np.ceil(np.log2(max(65536,len(win)*16))))
        mag=np.abs(np.fft.rfft(win,n=nfft)); hzgrid=np.fft.rfftfreq(nfft,1/sr)
        ids=np.flatnonzero((hzgrid>=target*2**(-1.15/12))&(hzgrid<=target*2**(1.15/12)))
        if not len(ids): raise RuntimeError(f'no pitch bins near {path}')
        k=int(ids[np.argmax(mag[ids])]); delta=0.0
        if 0<k<len(mag)-1:
            a,b,c=np.log(np.maximum(mag[k-1:k+2],1e-30)); den=a-2*b+c
            if abs(den)>1e-15: delta=.5*(a-c)/den
        hz=(k+delta)*sr/nfft; voiced=.5; method='parabolic strongest modal peak around expected sounding root'
    raw_cents=1200*math.log2(float(hz)/target)
    shift=int(round(raw_cents/100))
    physical=expected+shift
    residual=raw_cents-100*shift
    if abs(residual)>35: raise RuntimeError(f'physical pitch is not near an equal-tempered root: {path} {raw_cents:.1f}c')
    return {'root':physical,'written_expected_root':expected,'written_label_offset_semitones':-12,'measured_hz':round(float(hz),4),'raw_offset_cents':round(raw_cents,3),'residual_cents':round(residual,3),'voiced':round(float(voiced),4),'method':method}

def load_modal_builder():
    sp=importlib.util.spec_from_file_location('giove_modal_source',ROOT/'python/scripts/build_aria_mechanical.py')
    mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);return mod

def build_mallet(inst):
    dest=MALLET_BANK/inst['slug']
    if dest.exists():
        old=dest/'sound.py'; proof=dest/'samples'/'source-proof.json'
        owned=(old.exists() and 'marble-inspired' in old.read_text()) or (proof.exists() and bool(json.loads(proof.read_text())))
        partial=old.exists() is False and set(p.name for p in dest.iterdir())<= {'samples'}
        if not owned and not partial: raise RuntimeError(f'refusing existing folder: {dest}')
        shutil.rmtree(dest)
    dest.mkdir(parents=True); samples=dest/'samples'; (samples/'originals').mkdir(parents=True); (samples/'body').mkdir()
    files=source_files(inst)
    if not files: raise FileNotFoundError(f'VCSL source folder empty for {inst}')
    mechanic=load_modal_builder(); rows=[]; proof=[]
    physical_path=HOME/'Libero/cache/research/giove/vcsl-mallet-physical-roots.json'
    physical_doc=json.loads(physical_path.read_text()) if physical_path.exists() else {'records':[]}
    physical_by_sha={z['source_sha256']:z for z in physical_doc['records']}
    for src in files:
        token=note_token(src.name); label=midi(token)
        # VCSL bar files use written pitches one octave below sounding pitch.
        pitch=sample_pitch(src,label); root=pitch['root']
        independent=physical_by_sha.get(digest(src))
        if independent and str(independent.get('status','')).startswith('supported'):
            root=int(independent['physical_root_candidate_midi'])
            root_clusters=[c for c in independent.get('stable_spectral_mode_clusters',[])
                           if c.get('nearest_tempered_root_midi')==root and c.get('window_count',0)>=2
                           and c.get('spread_cents',999)<8]
            if root_clusters:
                # Use the dominant stable mode in the independently audited
                # physical-root family. Weaker nearby modes are stretch/side
                # modes, not a better tuning reference for the bar's root.
                mode=max(root_clusters,key=lambda c:c.get('median_relative_db',-999))
                tune_cents=round(-float(mode['nearest_tempered_cents']),3)
                physical_pitch={'status':'supported_root_family_mode','frequency_hz':mode['frequency_hz'],'offset_cents':mode['nearest_tempered_cents'],'relative_level_db':mode.get('median_relative_db'),'window_count':mode['window_count'],'spread_cents':mode['spread_cents'],'method':'independent unconditioned broad audit identifies the physical root; tuning uses its strongest coherent root-family mode across three windows'}
            else:
                broad=float(independent['broad_f0_median_hz'])
                cents=1200*math.log2(broad/freq(root))
                tune_cents=round(-cents,3)
                physical_pitch={'status':'supported_broad_period','frequency_hz':broad,'offset_cents':round(cents,3),'window_count':3,'spread_cents':independent.get('window_pitch_spread_cents'),'method':'independent unconditioned broad-period estimate; no stable root mode cluster'}
        else:
            tune_cents=round(-pitch['residual_cents'],3)
            physical_pitch={'status':independent.get('physical_root_status','ambiguous') if independent else 'no_independent_audit','frequency_hz':None,'offset_cents':None,'method':'no supported physical mode; source YIN retained only as diagnostic'}
        nm=src.stem
        if inst['kind']=='xylo':
            m=re.search(r'Xylo_(Soft|Medium|Hard)_([A-G](?:#|b)?-?\d+)_(pp|ff)_(\d+)',nm)
            if not m: raise ValueError(f'unparsed VCSL xylophone: {nm}')
            mallet,dyn,take=m.group(1).lower(),m.group(3),int(m.group(4))-1
            art=mallet
        else:
            m=re.search(r'Marimba_hit_[A-Za-z]+_([A-G](?:#|b)?-?\d+)_(soft|med|loud)_(\d+)',nm)
            if not m: raise ValueError(f'unparsed VCSL marimba: {nm}')
            dyn=m.group(2); take=int(m.group(3))-1; art='continuo'
        original=samples/'originals'/src.name
        shutil.copyfile(src,original)
        if digest(src)!=digest(original): raise RuntimeError(f'original copy changed: {src}')
        outname=f'{src.stem}-sostenuto.wav'
        # Fast-decaying high strikes splice sooner; retain the full recorded
        # onset before beginning the fitted modal continuation.
        raw,sr=sf.read(src,dtype='float64',always_2d=True); mono=raw.mean(axis=1)
        source_peak_db=20*math.log10(max(float(np.max(np.abs(raw))),1e-15))
        # A small number of VCSL soft takes are isolated recording-level
        # outliers (20+dB below adjacent soft takes). Preserve the raw WAV,
        # but apply a bounded source-specific gain to the playable derivatives
        # so the real quiet articulation remains audible rather than vanishing.
        source_gain_db=min(15.0,max(0.0,-54.0-source_peak_db))
        def seg_rms(a,b):
            z=mono[int(a*sr):min(len(mono),int(b*sr))]
            return float(np.sqrt(np.mean(z*z))) if len(z) else 1e-12
        drop=20*math.log10(max(seg_rms(.55,.65),1e-12)/max(seg_rms(.18,.25),1e-12))
        transition=.350 if drop<-14 else .450 if drop<-8 else .650
        body_path=samples/'body'/outname
        loop,continuation=mechanic.derive_source_body(src,body_path,root,period=6.0,transition_end=transition)
        # Keep the measured native-source calibration on both treatments.
        # The fitted continuation retains the bar's complex inharmonic modes;
        # a generic periodicity estimate can follow its beating rather than
        # the lowest physical mode, so it is never used as tuning authority.
        sustain_tune_cents=tune_cents
        if source_gain_db:
            bx,bsr=sf.read(body_path,dtype='float64',always_2d=True)
            sf.write(body_path,bx*(10**(source_gain_db/20)),bsr,subtype='PCM_24')
        strike_path=original
        if source_gain_db:
            strike_path=samples/'body'/(src.stem+'-colpo-calibrato.wav')
            sf.write(strike_path,raw*(10**(source_gain_db/20)),sr,subtype='PCM_24')
        # Use an independently selected source-derived extension, leaving the
        # original complete recorded attack in the `colpo` articulation.
        vlo,vhi=DYN[dyn]
        if inst['kind']=='xylo':
            sustain_art=f'{art}_sostenuto'; strike_art=f'{art}_colpo'
        else: sustain_art='sostenuto'; strike_art='colpo'
        region_common={'root':root,'lo':root,'hi':root,'vel':[vlo,vhi],'take':take,'tune_cents':sustain_tune_cents}
        rows.append({'file':body_path.relative_to(samples).as_posix(),**region_common,'loop':loop,'articulation':sustain_art})
        strike_common={**region_common,'tune_cents':tune_cents}
        rows.append({'file':strike_path.relative_to(samples).as_posix(),**strike_common,'one_shot':True,'articulation':strike_art})
        proof.append({'source_path':src.relative_to(CACHE).as_posix(),'source_sha256':digest(src),'included_path':original.relative_to(samples).as_posix(),'included_sha256':digest(original),'playable_strike_path':strike_path.relative_to(samples).as_posix(),'playable_strike_sha256':digest(strike_path),'source_peak_dbfs':round(source_peak_db,2),'bounded_source_gain_db':round(source_gain_db,2),'filename_note_label':token,'source_pitch_audit_yin_diagnostic_only':pitch,'independent_physical_pitch_audit':physical_pitch,'independent_audit_status':independent.get('status') if independent else None,'independent_audit_sha256':digest(physical_path) if physical_path.exists() else None,'mapped_source_root_midi':root,'root':root,'static_tune_cents':tune_cents,'sustain_tune_cents':sustain_tune_cents,'sustain_source_body_pitch_delta_cents':0.0,'dynamic_label':dyn,'dynamic_velocity_range':[vlo,vhi],'mallet_articulation':art,'sostenuto_articulation_id':sustain_art,'one_shot_articulation_id':strike_art,'filename_take_label':take,'runtime_take_index':take,'continuation':continuation,'transition_end_seconds':transition,'source_decay_drop_db_180_650':drop,'design_note':'Sostenuto body is a source-derived complex modal continuation after the full real strike; colpo is the natural decay from the same source performance. A bounded source-specific gain levels exceptional low-SNR playable derivatives; raw recording remains byte-identical. Pitch tuning uses the dominant stable mode in the independent physical-root family when supported; YIN is retained only as a diagnostic. Not an infinite acoustic performance.'})
    # Exclude the two low-SNR soft sources before tiling. All dynamic layers
    # of each articulation then share identical, disjoint lo/hi tiles; inside
    # each tile every dynamic chooses its nearest real physical root/take.
    if inst['kind']=='marimba':
        # Independent broadband analysis found F5-soft and C6-soft too quiet
        # for a reliable physical-root decision. Keep their raw WAVs and
        # proof, but exclude them before nearest-supported-source tiling.
        excluded=[r for r in rows if r['root'] in (89,96) and r['vel'][1]<=38]
        rows=[r for r in rows if not (r['root'] in (89,96) and r['vel'][1]<=38)]
        for p in proof:
            if p['root'] in (89,96) and p['dynamic_label']=='soft':
                p['physical_root_status']='ambiguous-low-SNR'
                p['playback_excluded']=True
                p['playable_strike_path']=None;p['playable_strike_sha256']=None
                p['playback_exclusion_reason']='Independent unconditioned broad pitch/modal audit could not support a stable root at source RMS below -71 dBFS; raw WAV is archived unchanged and this performance is not mapped for playback.'
        for r in excluded:
            (samples/r['file']).unlink(missing_ok=True)
    source_regions=rows;roots=sorted({r['root'] for r in source_regions})
    rows=common_cells(source_regions,min(roots),max(roots))
    roots=sorted({r['root'] for r in rows})
    if inst['kind']=='marimba':
        for p in proof:
            if p.get('playback_excluded'):
                target=int(p['root'])
                donors=[r for r in rows if r['articulation']=='sostenuto' and r['vel']==[1,38] and r['lo']<=target<=r['hi']]
                if donors:
                    donor=min(donors,key=lambda r:(abs(r['root']-target),r['root']))
                    p['fallback_source_root_midi']=donor['root']
                    p['fallback_source_note']=note_token(Path(donor['file']).name)
                    p['fallback_transposition_semitones']=target-donor['root']
                    p['fallback_is_existing_performance']=True
    dump(samples/'map.json',{'body':rows})
    dump(samples/'source-proof.json',proof)
    physical_audit=HOME/'Libero/cache/research/giove/vcsl-mallet-physical-roots.json'
    if physical_audit.exists():
        shutil.copyfile(physical_audit,samples/'vcsl-mallet-physical-roots.json')
    lic=CACHE/'LICENSE'
    if lic.exists():shutil.copyfile(lic,samples/'VCSL-LICENSE')
    active_performances=sum(not p.get('playback_excluded') for p in proof)
    dump(samples/'credits.json',[{'source':'Versilian Community Sample Library (VCSL), '+inst['folder'],'author':'Versilian Studios / Sam Gossner','license':'CC0 1.0','license_class':'cc0','url':'https://github.com/sgossner/VCSL','license_url':'https://raw.githubusercontent.com/sgossner/VCSL/master/LICENSE','notes':f'{len(files)} original WAV performances retained byte-identically in samples/originals and individually SHA-256 recorded; source-proof records all {len(files)} and identifies {active_performances} active playback performances. The two ambiguous low-SNR Marimba soft sources remain archived but excluded from playback. Main sostenuto art is a designed complex-modal continuation derived from each same source after its full recorded strike; colpo art retains the natural decay. This is not a naturally infinite performance.'}])
    if inst['kind']=='xylo':
        arts=[{'id':f'{m}_sostenuto','name':f'Mazza {label} · Sostenuto','key':None} for m,label in [('soft','morbida'),('medium','media'),('hard','dura')]] + [{'id':f'{m}_colpo','name':f'Mazza {label} · Colpo naturale','key':None} for m,label in [('soft','morbida'),('medium','media'),('hard','dura')]]
    else: arts=[{'id':'sostenuto','name':'Sostenuto · corpo derivato','key':None},{'id':'colpo','name':'Colpo · decadimento registrato','key':None}]
    defaults={'mode':'Poli','glide':0,'voices':24,'amp_attack':0,'amp_decay':10000,'amp_sustain':1,'amp_release':320,'master':-1,'vel_sens':.45,'dyn_mode':'Velocità','lvl_body':0,'lvl_attack':-60,'lvl_tail':-60,'lvl_air':-60,'osc1_level':-60,'osc2_level':-60,'sub_level':-60,'flt_cutoff':18000,'flt_env':0,'lfo_pitch':0,'lfo_amp':0,'drive':0,'tape_wow':0,'tape_flutter':0,'tape_sat':0,'tape_mix':0,'echo_mix':0,'rev_mode':'Cappella','rev_mix':.015,'rev_size':.16,'rev_decay':.42,'caldi_mode':'Spento'}
    recipe=f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nM=json.loads((Path(__file__).parent/'samples/map.json').read_text())\nROOTS={roots!r}\nsound=Sound(title={inst['title']!r},subtitle={inst['sub']!r},tags=['giove','marble-inspired','mallet','recorded','vcsl','cc0'],roots=ROOTS,velocities=[25,60,100,120],sample_rate=48000,accent={inst['accent']!r},takes={max(1,max(r['filename_take_label'] for r in proof)+1)})\nsound.articulations({arts!r})\nsound.multisample('body',M['body'],as_dyn=False,process={{'tune':'source','ladder':'keep','peak_db':-10,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','max_seconds':None,'end_db':-100,'encoding':'flac24','edge_fill':False,'preserve_key_ranges':True}})\nsound.performance(dynamics_source='velocity',velocity_curve=.85,dyn_crossfade=0,rr_reset_ms=1500,humanize={{'cents':0,'ms':0,'db':0}},one_shot=False)\nsound.defaults(**{defaults!r})\n'''
    (dest/'sound.py').write_text(recipe)
    fig_spec={'slug':inst['slug'],'title':inst['title'],'role':'registered acoustic bars and measured modal continuation','accent':inst['accent'],'harmonics':[1,2,3,4,5,6,7],'envelope':.9}
    (dest/'figure.svg').write_text(svg(fig_spec))
    mallet_limit=('The Marimba F5-soft and C6-soft sources are archived but excluded from playback because the physical root is ambiguous at their noise floor; the nearest supported B4-soft performance is explicitly transposed for those target keys.' if inst['kind']=='marimba' else 'The Hard G3/pp file is physically F#4; its native Hard/pp zone is extended one semitone to cover G4 where no Hard/pp G4 take exists, while the recorded Hard/ff G4 layer remains distinct.')
    (dest/'notes.md').write_text(f'''# {inst['title']}\n\nRoute REC + source-derived sustain design. This is a Marble Machine-inspired melodic mallet voice, not a recording of a Wintergatan machine. VCSL CC0 recordings provide the genuine acoustic strikes, original dynamics and mallet variants; all {len(files)} source WAVs remain byte-identical in `samples/originals/` with hashes and source-root checks in `samples/source-proof.json`. Independent broadband pitch/modal analysis is archived at `~/Libero/cache/research/giove/vcsl-mallet-physical-roots.json`; it does not assume filename octave and distinguishes stable candidates from low-SNR ambiguity.\n\nDefault articulation is `sostenuto`: the complete recorded attack is retained, then a complex-mode continuation fitted to that same performance sustains the actual bar's inharmonic body. `colpo` follows the recording's natural finite decay. {mallet_limit} Any bounded per-take level calibration is listed in source-proof and applies to the playable derivative only; raw recordings are unchanged. The continuation is designed, not a naturally endless performance. Hard velocity switching preserves recorded source performances; no processed file is claimed as a new round robin.\n\nDefaults: Poli, glide 0, sustain 1, no pitch modulation, no wow/flutter, no baked drive, CaldiSpento. Lint warnings are recorded in the native report. They describe genuine source dynamic range, measured attack/onset variation, natural stretch tuning, neighboring recording-level differences, or the source noise floor; there are no lint FAILs. These measurements do not establish listener preference.\n''')
    c=compile_sound(dest,jobs=2)
    if getattr(c,'error',None): raise RuntimeError(f"{inst['slug']} compile: {c.text()}")
    return dest,roots

def local_mallet_qc(inst,roots):
    slug=inst['slug'];folder=MALLET_BANK/slug;build=folder/'build'; params={}
    row={'slug':slug,'source_hash':source_hash(folder),'source_hash_fresh':False,'tests':[]}
    targets=(67,84,103) if inst['kind']=='xylo' else (roots[0],67,84)
    tests=[('low',min(roots,key=lambda n:abs(n-targets[0]))),('mid',min(roots,key=lambda n:abs(n-targets[1]))),('high',min(roots,key=lambda n:abs(n-targets[2])))]
    for label,n in tests:
        wav=OUT/f'{slug}-{label}-hold.wav';render.render(build,wav,f'{n}:0:60:110',params=params,tail=.3)
        x=np.asarray(Audio.load(wav).data,dtype=float);x=x.mean(axis=1) if x.ndim>1 else x
        rms=lambda z:20*math.log10(max(float(np.sqrt(np.mean(np.asarray(z)**2))),1e-15))
        row['tests'].append({'test':'60s-sostenuto-hold','register':label,'key':n,'rms_dbfs':round(rms(x),2),'late_rms_10_59_dbfs':round(rms(x[int(10*SR):int(59*SR)]),2),'peak_dbfs':round(20*math.log10(max(float(np.max(np.abs(x))),1e-15)),2),'clipped':int(np.sum(np.abs(x)>=.999))})
    # Exercise every genuine art×dynamic source cell in the native renderer.
    # For inharmonic bars we report the dominant root-family mode near the independently
    # audited physical source root; YIN can lock to beating/upper modes here.
    source_rows=json.loads((folder/'samples/map.json').read_text())['body']
    key_low,key_high=min(roots),max(roots)
    coverage=[]
    for art in sorted({r['articulation'] for r in source_rows}):
        art_rows=[r for r in source_rows if r['articulation']==art]
        layers=[]
        for dyn in sorted({tuple(r['vel']) for r in art_rows}):
            layer=[r for r in art_rows if tuple(r['vel'])==dyn]
            gaps=[key for key in range(key_low,key_high+1) if not any(r['lo']<=key<=r['hi'] for r in layer)]
            bounds=sorted({(r['lo'],r['hi']) for r in layer})
            layers.append({'velocity_range':list(dyn),'key_count':key_high-key_low+1,'missing_keys':gaps,'cell_bounds':bounds})
        same_cells=all(x['cell_bounds']==layers[0]['cell_bounds'] for x in layers[1:]) if layers else True
        coverage.append({'articulation':art,'layers':layers,'common_key_cells_across_dynamics':same_cells})
    art_ids=([f'{m}_sostenuto' for m in ('soft','medium','hard')]
             +[f'{m}_colpo' for m in ('soft','medium','hard')]
             if inst['kind']=='xylo' else ['sostenuto','colpo'])
    arts_audit=[]; all_cents=[]; missing=0; expected=0
    def mode_peak(seg,key):
        seg=np.asarray(seg,dtype=np.float64)
        if len(seg)<2048 or np.max(np.abs(seg),initial=0)<1e-7:return None
        nfft=1<<int(np.ceil(np.log2(len(seg)*16))); spec=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),nfft)); hzgrid=np.fft.rfftfreq(nfft,1/SR)
        target=freq(key); ids=np.flatnonzero((hzgrid>=target*2**(-100/1200))&(hzgrid<=target*2**(100/1200)))
        if not len(ids):return None
        k=int(ids[np.argmax(spec[ids])]);
        # The local bin neighbourhood includes the main-lobe skirts of these
        # short, inharmonic bar tones; require clear dominance, not an octave-
        # or note-centred YIN confidence threshold.
        if spec[k] < 1.35*np.median(spec[max(0,k-64):min(len(spec),k+65)]):return None
        d=0.0
        if 0<k<len(spec)-1:
            a,b,c=np.log(np.maximum(spec[k-1:k+2],1e-25)); den=a-2*b+c
            if abs(den)>1e-15:d=max(-.5,min(.5,.5*(a-c)/den))
        measured=float((k+d)*SR/nfft)
        return measured if measured>0 and np.isfinite(measured) else None
    for ai,art in enumerate(art_ids):
        rawrows=[r for r in source_rows if r.get('articulation')==art]
        # One genuine sample per mapped pitch/dynamic cell. Repeated takes are
        # checked in source-proof hashes and retained as true RR choices.
        cells={}
        for r in rawrows:
            dyn=tuple(r['vel'])
            targets=sorted({r['lo'],r['hi'],r['root'] if r['lo']<=r['root']<=r['hi'] else r['lo']})
            for target in targets:cells.setdefault((target,dyn),r)
        ordered=sorted(cells.items(),key=lambda item:(item[0][0],item[0][1]))
        if not ordered:continue
        events=[]
        event_spacing=8.0 if art.endswith('colpo') else 1.55
        for i,((target,dyn),r) in enumerate(ordered):
            v=max(1,min(127,(dyn[0]+dyn[1])//2));events.append((target,i*event_spacing,v,r))
        seq=','.join(f'{n}:{t:.3f}:1.45:{v}' for n,t,v,_ in events)
        wav=OUT/f'{slug}-{art}-matrix.wav';render.render(build,wav,seq,params={'artic':ai},tail=.25)
        aud=np.asarray(Audio.load(wav).data,dtype=float);aud=aud.mean(axis=1) if aud.ndim>1 else aud
        measurements=[]
        for n,t,v,r in events:
            one_shot=art.endswith('colpo')
            a=t+(.03 if one_shot else 1.02);b=t+(.15 if one_shot else 1.40)
            hz=mode_peak(aud[int(a*SR):int(b*SR)],n)
            cents=None if hz is None else round(1200*math.log2(hz/freq(n)),2)
            measurements.append({'key':n,'mapped_sample_root':r['root'],'transposition_semitones':n-r['root'],'velocity':v,'source_file':r['file'],'dynamic_range':r['vel'],'root_mode_hz':hz,'root_mode_cents':cents,'measure_window_seconds':[round(a-t,3),round(b-t,3)]})
            expected+=1
            if cents is None:missing+=1
            else:all_cents.append(abs(cents))
        arts_audit.append({'articulation':art,'cells_tested':len(measurements),'measurements':measurements})
    physical_audit=HOME/'Libero/cache/research/giove/vcsl-mallet-physical-roots.json'
    audit_ref={'path':str(physical_audit),'sha256':digest(physical_audit) if physical_audit.exists() else None}
    pitch_test={'test':'native-articulation-dynamic-root-mode-matrix','expected_cells':expected,'measured_cells':expected-missing,'missing_cells':missing,'max_abs_root_mode_cents':round(max(all_cents,default=0),2),'physical_mode_limit_cents':35,'method':'Native dominant physical root-family mode compared with the independent unconditioned source root/modal audit; colpo uses a 30–150 ms attack window, sostenuto uses 1.02–1.40 s. Bars are inharmonic and naturally stretch-tuned, so this checks the physical root mode rather than a single-YIN-F0 estimate.','independent_source_audit':audit_ref,'articulation_cells':arts_audit}
    row['tests'].append({'test':'source-map-key-coverage','key_range':[key_low,key_high],'articulation_layers':coverage,'missing_cell_count':sum(len(layer['missing_keys']) for a in coverage for layer in a['layers']),'common_cells_pass':all(a['common_key_cells_across_dynamics'] for a in coverage)})
    row['tests'].append(pitch_test)
    # Chord stress; only keys inside the instrument's actual map.
    chordkeys=sorted({min(roots[-1],max(roots[0],k)) for k in (roots[0],roots[0]+4,roots[0]+7,roots[0]+11,roots[0]+14,roots[0]+17,roots[0]+21,roots[0]+24)})
    chord=OUT/f'{slug}-chord8.wav';render.render(build,chord,','.join(f'{n}:0:4:127' for n in chordkeys),params=params,tail=.25)
    cx=np.asarray(Audio.load(chord).data,dtype=float)
    row['tests'].append({'test':'chord-v127','keys':chordkeys,'event_count':len(chordkeys),'peak_dbfs':round(20*math.log10(max(float(np.max(np.abs(cx))),1e-15)),2),'clipped':int(np.sum(np.abs(cx)>=.999))})
    lint=[z.line() for z in lint_bundle(build)];row['lint']={'FAIL':sum(z.startswith('FAIL') for z in lint),'WARN':sum(z.startswith('WARN') for z in lint),'INFO':sum(z.startswith('INFO') for z in lint),'warnings':lint}
    manifest=json.loads((build/'manifest.json').read_text());row['manifest_source_hash']=manifest.get('source_hash');row['source_hash_fresh']=row['source_hash']==row['manifest_source_hash']
    chord_test=next(t for t in row['tests'] if t['test']=='chord-v127')
    coverage_test=next(t for t in row['tests'] if t['test']=='source-map-key-coverage')
    row['quality']={'pitch_pass':pitch_test['measured_cells']==expected and pitch_test['max_abs_root_mode_cents']<=35,'coverage_pass':coverage_test['missing_cell_count']==0 and coverage_test['common_cells_pass'],'hold_pass':all(t['late_rms_10_59_dbfs']>=-50 and t['clipped']==0 for t in row['tests'] if t['test']=='60s-sostenuto-hold'),'chord_pass':chord_test['event_count']==8 and chord_test['peak_dbfs']<=-3 and chord_test['clipped']==0,'lint_pass':row['lint']['FAIL']==0}
    if not row['source_hash_fresh']:raise RuntimeError(f'stale manifest {slug}')
    return row

def refresh_installed_synth_pitch(report):
    """Use the owner's actual-default 60 s holds to verify the synth carriers.

    This is read-only with respect to preset folders and uses a long steady
    FFT, which is appropriate for the intentionally layered/sub-octave synth
    spectra that can defeat a single-fundamental YIN estimator.
    """
    safety_path=HOME/'Libero/demo/giove-v1/default-safety/report.json'
    if not safety_path.exists():return
    safety=json.loads(safety_path.read_text());by={x['slug']:x for x in safety.get('presets',[])}
    for q in report.get('presets',[]):
        if q['slug'] not in {s['slug'] for s in SYNTHS}:continue
        src=by.get(q['slug'])
        if not src or src.get('source_hash')!=source_hash(BANK/q['slug']):
            q.setdefault('tests',[]).append({'test':'installed-default-carrier-pitch','status':'unverified','reason':'default-safety report absent or source hash mismatch'})
            q.setdefault('quality',{})['pitch_pass']=False
            continue
        vals=[];items=[]
        for hold in src.get('holds',[]):
            key=int(hold['key']);path=safety_path.parent/q['slug']/f'hold-{key}.wav'
            if not path.exists():continue
            audio,sr=sf.read(path,dtype='float64',always_2d=True);audio=audio.mean(axis=1)
            # Use a stable 20 s section well after attack; zero-padding plus
            # log-parabolic interpolation sharpens the actual carrier peak.
            lo_s=20.0;hi_s=min(40.0,len(audio)/sr-0.1);seg=audio[int(lo_s*sr):int(hi_s*sr)]
            if len(seg)<sr:continue
            nfft=1<<int(np.ceil(np.log2(len(seg)*4)));spec=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),nfft));hzgrid=np.fft.rfftfreq(nfft,1/sr)
            target=freq(key);ids=np.flatnonzero((hzgrid>=target*2**(-70/1200))&(hzgrid<=target*2**(70/1200)))
            if not len(ids):continue
            k=int(ids[np.argmax(spec[ids])]);d=0.0
            if 0<k<len(spec)-1:
                a,b,c=np.log(np.maximum(spec[k-1:k+2],1e-25));den=a-2*b+c
                if abs(den)>1e-15:d=.5*(a-c)/den
            measured=(k+d)*sr/nfft;cents=1200*math.log2(measured/target);vals.append(abs(cents))
            items.append({'key':key,'file':str(path),'measured_carrier_hz':round(measured,4),'cents':round(cents,3),'window_seconds':[lo_s,hi_s]})
        test={'test':'installed-default-carrier-pitch','status':'measured','source_hash':src['source_hash'],'measured_registers':len(items),'method':'Long-window native FFT carrier peak inside ±70 cents of the designed played-key oscillator band; intentional sub-octave bass components are not misreported as a tuning error.','measurements':items,'max_abs_cents':round(max(vals,default=float('inf')),3),'threshold_cents':5}
        q.setdefault('tests',[]).append(test);q.setdefault('quality',{})['pitch_pass']=len(items)==3 and max(vals,default=float('inf'))<=5
    report['synth_pitch_source']='demo/giove-v1/default-safety/report.json (actual default installed-native hold renders; no preset recompile)'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--only',nargs='*',help='optional exact preset slugs; defaults to the full 14')
    args=ap.parse_args()
    all_specs={s['slug']:('synth',s) for s in SYNTHS}
    all_specs.update({s['slug']:('mallet',s) for s in MALLETS})
    selected=args.only or list(all_specs)
    unknown=set(selected)-set(all_specs)
    if unknown:raise SystemExit(f'unknown slugs: {sorted(unknown)}')
    report_path=OUT/'report.json'
    prior={}
    if report_path.exists():
        try:prior={x['slug']:x for x in json.loads(report_path.read_text()).get('presets',[])}
        except Exception:prior={}
    for slug in selected:
        kind,spec=all_specs[slug]
        if kind=='synth':
            folder=write_synth(spec);q=local_synth_qc(spec)
        else:
            folder,roots=build_mallet(spec);q=local_mallet_qc(spec,roots)
        prior[slug]=q
        rows=[prior[k] for k in all_specs if k in prior]
        dump(report_path,{'generated_utc':datetime.now(timezone.utc).isoformat(),'preset_count':len(rows),'presets':rows})
        print(slug,q['lint']['FAIL'],q['lint']['WARN'],q['source_hash'],q.get('quality'),flush=True)
    print('report',report_path)
if __name__=='__main__':main()
