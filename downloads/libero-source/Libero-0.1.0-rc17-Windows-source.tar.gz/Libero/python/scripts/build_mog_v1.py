#!/usr/bin/env python3
"""Build the Mog phonk / Brazilian phonk bank from original synth designs and CC0 kits.

Only ~/Libero/banks/mog and ~/Libero/demo/mog-v1 are written. Electronic
patches are live synthesis except the original pitch-falling 808 body, whose
authored cycles are looped after a short, key-specific pitch drop. Drum sounds
are unprocessed performances from Big Rusty Drums and VCSL, with original maps,
source copies, licence snapshots, and per-file SHA-256 provenance retained.
"""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json, math, shutil, sys, re
import argparse

import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'python'))
from libero import Audio, render, analysis, library
from libero.compiler import compile_sound
from libero.ingest.sfz import parse_sfz
from libero.lint import lint_bundle
from libero.figure import validate_svg, rasterize

HOME = Path.home()
BANK = HOME / 'Libero' / 'banks' / 'mog'
DEMO = HOME / 'Libero' / 'demo' / 'mog-v1'
BRD = HOME / 'Libero' / 'cache' / 'libraries' / 'karoryfer-big-rusty-drums'
VCSL = HOME / 'Libero' / 'cache' / 'libraries' / 'vcsl'
SR = 48000
NOW = datetime.now(timezone.utc).isoformat()

# Physical and musical designs are deliberately distinct. Electronic identities
# are oscillator synthesis, not transformed third-party presets or samples.
LIVE = {
 'sino-lata': ('Sino de Lata','cowbell phonk · due quadre strette, intervallo di tritono', dict(
  osc1_wave='Quadra',osc1_level=-17,osc1_pw=.38,osc2_wave='Quadra',osc2_level=-19,osc2_semi=6,osc2_pw=.56,
  sub_level=-43,flt_mode='Basso',flt_cutoff=6200,flt_reso=.08,flt_env=.08,fenv_attack=1,fenv_decay=210,fenv_sustain=.14,
  amp_attack=1,amp_decay=900,amp_sustain=1,amp_release=180,master=-8.5,drive=.04,width=1.08,rev_mix=.035,rev_mode='Piastra',rev_size=.18,rev_decay=.55)),
 'sino-noite': ('Sino de Noite','cowbell scura · triangolo metallico, ottava bassa e attacco cavo', dict(
  osc1_wave='Quadra',osc1_level=-19,osc1_pw=.24,osc2_wave='Seno',osc2_level=-17,osc2_semi=7,
  sub_level=-34,flt_mode='Banda',flt_cutoff=3100,flt_reso=.12,flt_env=.04,fenv_attack=0,fenv_decay=380,fenv_sustain=.24,
  amp_attack=2,amp_decay=1000,amp_sustain=1,amp_release=260,master=-2.2,drive=.02,width=1.04,rev_mix=.025,rev_mode='Piastra',rev_size=.14,rev_decay=.45)),
 'faisca-cromada': ('Faísca Cromada','lead bright · sega centrale e doppio bordo di ottava', dict(
  osc1_wave='Sega',osc1_level=-18,osc1_voices=1,osc2_wave='Sega',osc2_level=-29,osc2_oct=1,osc2_voices=3,osc2_detune=.12,osc2_spread=.82,
  sub_level=-43,flt_cutoff=5700,flt_env=.19,fenv_attack=2,fenv_decay=620,fenv_sustain=.38,
  amp_attack=2,amp_decay=900,amp_sustain=1,amp_release=220,master=-7.2,drive=.025,width=1.1,lfo_rate=.11,lfo_cutoff=.025,rev_mix=.04,rev_decay=.8)),
 'apito-de-neon': ('Apito de Neon','lead agudo · impulso stretto, centro triangolare e formante vocale', dict(
  osc1_wave='Triangolo',osc1_level=-16,osc2_wave='Quadra',osc2_level=-27,osc2_semi=12,osc2_pw=.22,osc2_voices=2,osc2_detune=.08,osc2_spread=.7,
  sub_level=-48,flt_mode='Vocale',flt_cutoff=5000,flt_env=.13,fenv_attack=4,fenv_decay=500,fenv_sustain=.22,
  amp_attack=3,amp_decay=800,amp_sustain=1,amp_release=200,master=-7.5,drive=.018,width=1.0,lfo_rate=.08,lfo_cutoff=.018,rev_mix=.04,rev_decay=.65)),
 'motor-ritual': ('Motor Ritual','lead sincopato · sega tagliata e impulso quadrato nel registro basso', dict(
  osc1_wave='Sega',osc1_level=-19,osc1_voices=2,osc1_detune=.11,osc1_spread=.35,osc2_wave='Quadra',osc2_level=-23,osc2_oct=-1,osc2_pw=.31,
  sub_level=-32,flt_mode='Basso',flt_cutoff=2800,flt_reso=.16,flt_env=.29,fenv_attack=0,fenv_decay=300,fenv_sustain=.12,
  amp_attack=0,amp_decay=800,amp_sustain=1,amp_release=160,master=-6.8,drive=.055,width=1.02,lfo_rate=.14,lfo_pw=.025,rev_mix=.02,rev_decay=.4)),
 'voz-de-asfalto': ('Voz de Asfalto','lead vocale · ancia sega e triangolo, centro di formanti medio-basso', dict(
  osc1_wave='Sega',osc1_level=-20,osc2_wave='Triangolo',osc2_level=-22,osc2_oct=-1,osc2_voices=2,osc2_detune=.08,osc2_spread=.4,
  sub_level=-35,flt_mode='Vocale',flt_cutoff=2100,flt_reso=.22,flt_env=.16,fenv_attack=12,fenv_decay=760,fenv_sustain=.35,
  amp_attack=10,amp_decay=1000,amp_sustain=1,amp_release=340,master=-.8,drive=.025,width=1.03,lfo_rate=.10,lfo_cutoff=.025,rev_mix=.045,rev_decay=.9)),
 'sub-asfalto': ('Sub Asfalto','sub fondamentale · seno pulito con attacco quadrato molto lieve', dict(
  osc1_wave='Seno',osc1_level=-13,osc2_wave='Quadra',osc2_level=-33,osc2_oct=0,osc2_pw=.5,sub_level=-60,
  flt_mode='Basso',flt_cutoff=900,flt_reso=.04,flt_env=.04,fenv_attack=0,fenv_decay=180,fenv_sustain=.1,
  amp_attack=0,amp_decay=800,amp_sustain=1,amp_release=140,master=-8.7,drive=.012,width=1.0,rev_mix=.008,rev_decay=.25)),
 'reese-de-favela': ('Reese de Favela','reese bass · centro sega denso, bordi detunati e sub mono', dict(
  osc1_wave='Sega',osc1_level=-20,osc1_voices=3,osc1_detune=.28,osc1_spread=.60,osc2_wave='Sega',osc2_level=-22,osc2_oct=-1,osc2_voices=3,osc2_detune=.24,osc2_spread=.65,
  sub_level=-26,flt_mode='Basso',flt_cutoff=1550,flt_reso=.13,flt_env=.10,fenv_attack=0,fenv_decay=850,fenv_sustain=.45,
  amp_attack=4,amp_decay=1000,amp_sustain=1,amp_release=180,master=-8.2,drive=.04,width=1.15,lfo_rate=.07,lfo_cutoff=.018,rev_mix=.012,rev_decay=.3)),
 'baixo-corrente': ('Baixo Corrente','bassline a impulsi · quadro morbido e triangolo centrale', dict(
  osc1_wave='Quadra',osc1_level=-20,osc1_pw=.32,osc2_wave='Triangolo',osc2_level=-21,osc2_oct=-1,osc2_voices=1,
  sub_level=-27,flt_mode='Basso',flt_cutoff=1450,flt_reso=.09,flt_env=.20,fenv_attack=0,fenv_decay=380,fenv_sustain=.22,
  amp_attack=0,amp_decay=900,amp_sustain=1,amp_release=130,master=-8.5,drive=.028,width=1.0,lfo_rate=.09,lfo_pw=.04,rev_mix=.01,rev_decay=.3)),
 'gota-de-cobre': ('Gota de Cobre','pluck sintetico · triangolo morbido, impulso corto e corpo sostenuto', dict(
  osc1_wave='Triangolo',osc1_level=-18,osc2_wave='Quadra',osc2_level=-28,osc2_oct=1,osc2_pw=.3,
  sub_level=-38,flt_mode='Banda',flt_cutoff=3900,flt_reso=.16,flt_env=.42,fenv_attack=1,fenv_decay=280,fenv_sustain=.08,
  amp_attack=0,amp_decay=1000,amp_sustain=1,amp_release=420,master=-7.4,drive=.018,width=1.08,rev_mode='Piastra',rev_size=.24,rev_decay=.95,rev_mix=.055)),
 'coro-fantasma': ('Coro Fantasma','pad senza accordo baked · centro triangolare, sega soffice e bordi lenti', dict(
  osc1_wave='Triangolo',osc1_level=-21,osc1_voices=1,osc2_wave='Sega',osc2_level=-27,osc2_oct=0,osc2_voices=5,osc2_detune=.17,osc2_spread=.82,
  sub_level=-38,flt_mode='Basso',flt_cutoff=3400,flt_env=.09,fenv_attack=350,fenv_decay=1500,fenv_sustain=.62,
  amp_attack=420,amp_decay=1800,amp_sustain=1,amp_release=950,master=-7.2,drive=.012,width=1.22,lfo_rate=.06,lfo_cutoff=.045,rev_mode='Basilica',rev_size=.32,rev_decay=1.6,rev_mix=.065)),
 'poeira-de-concreto': ('Poeira de Concreto','texture ritmica pitched · sega bassa, grana d’oscillatore controllata', dict(
  osc1_wave='Quadra',osc1_level=-23,osc1_pw=.18,osc2_wave='Rumore',osc2_level=-36,osc2_oct=-1,sub_level=-32,
  flt_mode='Banda',flt_cutoff=1700,flt_reso=.28,flt_env=.18,fenv_attack=0,fenv_decay=520,fenv_sustain=.16,
  amp_attack=5,amp_decay=800,amp_sustain=1,amp_release=280,master=-8.7,drive=.02,width=1.05,lfo_rate=.12,lfo_cutoff=.025,rev_mix=.035,rev_decay=.6)),
 'lua-de-viaduto': ('Lua de Viaduto','pluck brillante · triangolo caldo e partiale alto quasi campana', dict(
  osc1_wave='Triangolo',osc1_level=-20,osc2_wave='Seno',osc2_level=-25,osc2_oct=1,osc2_semi=7,osc2_fine=-8,
  sub_level=-39,flt_mode='Basso',flt_cutoff=4700,flt_reso=.12,flt_env=.25,fenv_attack=0,fenv_decay=430,fenv_sustain=.10,
  amp_attack=0,amp_decay=900,amp_sustain=1,amp_release=620,master=-7.8,drive=.015,width=1.12,rev_mode='Piastra',rev_size=.26,rev_decay=1.0,rev_mix=.05)),
 'sirene-de-vidro': ('Sirene de Vidro','lead inarmonico senza accordo · fondamentale sinusoidale centrale e partiale sega a tritono', dict(
  osc1_wave='Seno',osc1_level=-11,osc2_wave='Sega',osc2_level=-21,osc2_semi=5,osc2_voices=2,osc2_detune=.12,osc2_spread=.62,
  sub_level=-33,flt_mode='Banda',flt_cutoff=5200,flt_reso=.16,flt_env=.08,fenv_attack=150,fenv_decay=1100,fenv_sustain=.24,
  amp_attack=160,amp_decay=1200,amp_sustain=1,amp_release=850,master=2.5,drive=.01,width=1.12,lfo_rate=.045,lfo_cutoff=.045,rev_mode='Piastra',rev_size=.26,rev_decay=1.0,rev_mix=.045)),
}

# Two new interval colors derived from the approved Sino de Lata patch. All
# oscillator/filter/envelope/cold-warm settings match it byte-for-byte except
# osc2_semi; the original tritone voice itself is never rewritten.
LIVE['sino-lata-terza'] = ('Sino de Lata · Terza maggiore', 'cowbell phonk · quadre strette con terza maggiore superiore',
    {**LIVE['sino-lata'][2], 'osc2_semi': 4})
LIVE['sino-lata-quarta'] = ('Sino de Lata · Quarta giusta', 'cowbell phonk · quadre strette con quarta giusta superiore',
    {**LIVE['sino-lata'][2], 'osc2_semi': 5})

DRUM_KEYS_MEMPHIS = [36,37,38,39,40,41,43,45,47,42,44,46,49,51,52,53]
DRUM_KEYS_BR = [36,37,38,40,42,44,46,49,51,52]
DRUM_MIC = {36:'kick',37:'top',38:'top',39:'top',40:'top',41:'cl',42:'cl',43:'cl',44:'cl',45:'cl',46:'cl',47:'cl',49:'cl',51:'cl',52:'cl',53:'cl'}
KEY_LABEL = {36:'kick',37:'sidestick',38:'snare-center',39:'snare-edge',40:'rimshot',41:'tom22',42:'hihat-closed',43:'tom18',44:'hihat-pedal',45:'tom15',46:'hihat-open',47:'tom14',49:'crash',51:'ride-bow',52:'ride-bell',53:'ride-edge'}
VCSL_PADS = {
 60:('Cowbells/Cowbell1_Normal',[(2,1,63),(3,64,127)]),
 61:('Cowbells/Cowbell2_Normal',[(2,1,63),(3,64,127)]),
 62:('Agogo Bells/Agogo_Low',[(1,1,70),(2,71,127)]),
 63:('Agogo Bells/Agogo_High',[(1,1,42),(2,43,84),(3,85,127)]),
 64:('Claves/Claves1_Hit',[(1,1,42),(2,43,84),(3,85,127)]),
 65:('Claves/Claves2_Hit',[(1,1,42),(2,43,84),(3,85,127)]),
 66:('Cowbells/Cowbell1_Hit',[(2,1,42),(3,43,84),(4,85,127)]),
 67:('Cowbells/Cowbell1_Muted',[(2,1,63),(3,64,127)]),
 68:('Cowbells/Cowbell2_Double',[(2,1,63),(3,64,127)]),
}

def hfile(p: Path) -> str:
    return sha256(p.read_bytes()).hexdigest()

def defaults(role: str, config: dict) -> dict:
    d = dict(mode='Poli', glide=0, voices=32, master=-8, vel_sens=.35,
             amp_attack=3, amp_decay=900, amp_sustain=1, amp_release=250,
             osc1_wave='Sega', osc1_level=-60, osc1_oct=0, osc1_semi=0, osc1_fine=0,
             osc1_voices=1, osc1_detune=0, osc1_spread=0, osc1_phase=0,
             osc2_wave='Sega', osc2_level=-60, osc2_oct=0, osc2_semi=0, osc2_fine=0,
             osc2_voices=1, osc2_detune=0, osc2_spread=0, osc2_phase=0,
             sub_wave='Seno', sub_level=-60, osc_drift=.025, osc_retrig='Libera',
             flt_mode='Basso', flt_cutoff=15000, flt_reso=.04, flt_key=.5, flt_vel=.1,
             flt_env=0, fenv_source='Propria', fenv_attack=10, fenv_decay=800,
             fenv_sustain=.35, fenv_release=250, lfo_shape='Seno', lfo_rate=.1,
             lfo_delay=0, lfo_pitch=0, lfo_cutoff=0, lfo_amp=0, lfo_pw=0,
             drive=0, width=1, rev_mode='Cappella', rev_size=.18, rev_decay=.55,
             rev_predelay=10, rev_damp=.65, rev_width=.8, rev_mix=.02, rev_shimmer=0,
             echo_mix=0, tape_wow=0, tape_flutter=0, tape_sat=0, tape_age=0, tape_mix=0,
             caldi_mode='Spento', caldi_amount=.45, caldi_grain=0, caldi_motion=0,
             lvl_body=-60, lvl_attack=-60, lvl_tail=-60, lvl_air=-60)
    d.update(config)
    # User constraints are invariants, not per-design options.
    d.update(mode='Poli', glide=0, amp_sustain=1, tape_wow=0, tape_flutter=0,
             caldi_mode='Spento')
    return d

def svg(title: str, slug: str, color: str='#c77a36', kind='synth') -> str:
    idx=sum(map(ord,slug))%12
    paths=[]
    for i in range(11):
        x=78+i*35
        y=225 + 95*math.sin((i+idx*.25)*.58)
        paths.append(f'<path d="M{x} 250 Q{x+12} {y:.1f} {x+27} 250"/>')
    extra = '<path d="M112 338H400M140 354H372M165 370H347" stroke-width="2"/>' if kind=='kit' else f'<circle cx="256" cy="170" r="{30+idx*4}"/> <path d="M256 94V327M128 208H384" stroke-width="1"/>'
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="none" stroke="{color}" stroke-width="2.2" stroke-linecap="round">'
            f'<title>{title}</title><desc>{slug}: phonk palette geometry.</desc>{extra}<g>{"".join(paths)}</g>'
            f'<path d="M82 396H430M82 404H430" stroke="#2d2924" stroke-width=".8"/></svg>')

def write_artifacts(slug: str, title: str, subtitle: str, notes: str, color: str, kind='synth'):
    p=BANK/slug
    p.mkdir(parents=True,exist_ok=True)
    art=svg(title,slug,color,kind)
    assert not validate_svg(art), (slug,validate_svg(art))
    (p/'figure.svg').write_text(art)
    (p/'notes.md').write_text(f'# {title}\n\n{subtitle}\n\n{notes}\n\nDefaults: Poli, glide 0, infinite sustain to MIDI note-off, wow/flutter 0, Caldi Spento. Native technical QA does not substitute for listening approval.\n')
    (p/'figure.png').write_bytes(rasterize(art,512))

def synth_sound(slug: str, title: str, subtitle: str, config: dict, role: str, color: str):
    p=BANK/slug; p.mkdir(parents=True,exist_ok=True)
    d=defaults(role,config)
    tags=['mog','phonk','brazilian-phonk','synth',role,'infinite']
    rootmap=[24,31,36,48,60,72,84] if role=='bass' else [36,48,60,72,84]
    source=f'''from libero import Sound\nsound=Sound(title={title!r},subtitle={subtitle!r},tags={tags!r},roots={rootmap!r},accent={color!r})\nsound.performance(dynamics_source="velocity",humanize={{"cents":0,"ms":0,"db":0}})\nsound.defaults(**{d!r})\n'''
    (p/'sound.py').write_text(source)
    (p/'samples').mkdir(exist_ok=True)
    (p/'samples'/'credits.json').write_text(json.dumps([{'source':'Original live oscillator synthesis for Mog v1','author':'Libero sound design session','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://creativecommons.org/publicdomain/zero/1.0/','files':[]}],indent=2)+'\n')
    write_artifacts(slug,title,subtitle,
        f'Route SYN. Original oscillator patch, not a commercial sample or repack. Role: {role}. Its excitation and filter/body design: {subtitle}. Two oscillators/sub are combined only for named spectral roles; no pre-baked chord. Small room only; no tape modulation.',color)
    compile_folder(p)
    return p

def compile_folder(p: Path):
    c=compile_sound(p,jobs=1)
    print(p.name,c.text(),flush=True)
    if not c.ok: raise RuntimeError(f'compile failed for {p.name}: {c.text()}')

def sources_big_rusty():
    sfz=BRD/'Programs'/'01-full.sfz'
    if not sfz.exists(): raise FileNotFoundError(sfz)
    return parse_sfz(sfz)

def selected_brd(regions, keys):
    out=[]
    for key in keys:
        mic=DRUM_MIC[key]
        rs=[r for r in regions if r.lokey<=key<=r.hikey and r.trigger=='attack' and r.sample.exists()]
        if key==36:
            rs=[r for r in rs if '/kick/kick/' in r.sample.as_posix()]
        elif key in (37,38,39,40):
            rs=[r for r in rs if f'/{mic}/' in r.sample.as_posix()]
        else:
            rs=[r for r in rs if f'/{mic}/' in r.sample.as_posix()]
        if not rs and key in (42,44,46):
            # The upstream full map references the unavailable TC hi-hat subset
            # at key 42. Use the documented CC0 close-hit map, resolving its
            # original relative sample paths to the locally cached originals.
            mapname={42:'ht_cl_cl.sfz',44:'ht_chik_cl.sfz',46:'ht_open_cl.sfz'}[key]
            alt=parse_sfz(BRD/'Programs'/'mappings'/'hihat_14'/mapname)
            for r in alt.regions:
                src=BRD/'Samples'/'hihat_14'/('cl' if key==42 else ('chik' if key==44 else 'open'))/'cl'/r.sample.name
                if not src.exists():continue
                r.sample=src;r.root=key;r.lokey=key;r.hikey=key
                rs.append(r)
        if not rs: raise RuntimeError(f'No Big Rusty source zones for MIDI {key} mic {mic}')
        out.extend(rs)
    return out

def copy_program_maps(folder: Path):
    dst=folder/'samples'/'source-maps'/'Programs'
    if not dst.exists(): shutil.copytree(BRD/'Programs',dst)
    return dst

def source_license_snapshot(url: str, dest: Path):
    import urllib.request
    dest.parent.mkdir(parents=True,exist_ok=True)
    req=urllib.request.Request(url,headers={'User-Agent':'Libero Mog source/license audit'})
    with urllib.request.urlopen(req,timeout=45) as r: dest.write_bytes(r.read())

def velocity_for_v(v: int, choices):
    for src,lo,hi in choices:
        if src==v:return lo,hi
    return None

def add_vcsl_regions(folder: Path, rows: list, keylist):
    original=folder/'samples'/'originals';original.mkdir(parents=True,exist_ok=True)
    for key in keylist:
        stem,versions=VCSL_PADS[key]
        for v,lo,hi in versions:
            matches=list((VCSL/'Idiophones'/'Struck Idiophones').glob(stem+f'_v{v}_rr1_Mid.wav'))
            if not matches:
                # Aggregated local source tree uses folder paths, while stem is
                # authored as a slash-separated path below Idiophones.
                src=(VCSL/'Idiophones'/'Struck Idiophones'/stem.split('/')[0]/(stem.split('/')[1]+f'_v{v}_rr1_Mid.wav'))
                matches=[src] if src.exists() else []
            if not matches: raise FileNotFoundError(f'VCSL source for {stem} v{v}')
            src=matches[0];dest=original/f'vcsl-{key}-v{v}-rr1.wav'
            if not dest.exists():shutil.copy2(src,dest)
            rows.append({'file':str(dest.relative_to(folder/'samples')),'root':key,'lo':key,'hi':key,
                         'vel':[lo,hi],'take':0,'pitched':False,'one_shot':True,
                         'source_path':src.relative_to(VCSL).as_posix(),'source_sha256':hfile(src),
                         'source_layer':f'v{v}; one recorded strike; mapped as velocity layer'})

def build_kit(slug: str, title: str, subtitle: str, keys: list, brazilian: bool=False):
    p=BANK/slug;samples=p/'samples';orig=samples/'originals';orig.mkdir(parents=True,exist_ok=True)
    inst=sources_big_rusty(); regions=selected_brd(inst.regions,keys)
    rows=[]; credits={};seen=set()
    copy_program_maps(p)
    for r in regions:
        mic=DRUM_MIC[next(k for k in keys if r.lokey<=k<=r.hikey)]
        key=r.root
        rel=r.sample.relative_to(BRD)
        # Each selected key/dynamic/take path is one original performance.
        basename=f'brd-k{key}-v{r.lovel:03d}-{r.hivel:03d}-rr{r.seq_position}-{mic}-{rel.name}'
        dest=orig/basename
        if not dest.exists():shutil.copy2(r.sample,dest)
        sha=hfile(r.sample);credits[dest.name]={'upstream_path':rel.as_posix(),'sha256':sha,'vel':[r.lovel,r.hivel],'take':r.seq_position-1}
        row={'file':str(dest.relative_to(samples)),'root':key,'lo':key,'hi':key,
             'vel':[r.lovel,r.hivel],'take':r.seq_position-1,'pitched':False,'one_shot':True,
             'source_path':rel.as_posix(),'source_sha256':sha}
        if key==46:row['choke_group']=1
        if key==42 or key==44:row['chokes']=[1]
        rows.append(row)
        seen.add(rel.as_posix())
    if brazilian:
        add_vcsl_regions(p,rows,[60,61,62,63,64,65,66,67,68])
    (samples/'map.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
    # Electronic transient/body layers make these genre kits authored hybrid
    # instruments rather than a Big Rusty kit with EQ. They are explicit new
    # oscillator renders, separate from and auditable against the acoustic hits.
    attack_rows=[]
    synth_dir=samples/'synthesis';synth_dir.mkdir(parents=True,exist_ok=True)
    for kind,key in [('kick',36),('clap',38)]:
        if key not in keys:continue
        for vel in (44,112):
            n=int(.72*SR);t=np.arange(n)/SR;v=(vel-1)/126
            if kind=='kick':
                # Baseline 808-v3 was measured at ~55 Hz; its attack/body was
                # strongly sub-dominant-band weighted (20–60 Hz share ~0.86/0.89).
                # Recreate only this measured envelope/spectral direction with
                # original synthesis, never copy its commercial audio.
                f=55+95*np.exp(-t/.042);ph=2*np.pi*np.cumsum(f)/SR
                body=np.sin(ph)+(.22+.08*v)*np.sin(2*ph)+.045*np.sin(3*ph)
                env=np.exp(-t/(.33+.08*v))
                rng=np.random.default_rng(731+vel+(11 if brazilian else 0))
                noise=rng.normal(0,1,n)*np.exp(-t/.010)
                # Small controlled transient, sub-led sustained body.
                x=.77*body*env+.025*noise
                x=np.tanh(1.12*x)
            else:
                # Original four-hit noise cluster + short 170 Hz skin body;
                # Brazilian patch uses a slightly more spread-accented clap.
                rng=np.random.default_rng(911+vel+(17 if brazilian else 0))
                noise=rng.normal(0,1,n)
                burst=np.zeros(n)
                for j,at in enumerate((0,.014,.029,.047)):
                    i=int(at*SR);end=min(n,i+int(.048*SR))
                    burst[i:end]+=noise[i:end]*np.exp(-np.arange(end-i)/(.010*SR))/(1+j*.18)
                body=np.sin(2*np.pi*(166+12*v)*t+.28*np.sin(2*np.pi*5*t))*np.exp(-t/.13)
                x=.28*burst+(.18+.05*v)*body
                if brazilian:
                    # Narrow two-component transient; no third-party clap sample.
                    x+=.08*np.sin(2*np.pi*(245+15*v)*t)*np.exp(-t/.065)
                x=np.tanh(1.35*x)
            peak=np.max(np.abs(x));x=x/max(peak,1e-12)*(.46+.13*v)
            name=f'{kind}-{key}-v{vel}.wav';dest=synth_dir/name;sf.write(dest,x,SR,subtype='PCM_24')
            attack_rows.append({'file':f'synthesis/{name}','root':key,'lo':key,'hi':key,
               'vel':[1,79] if vel==44 else [80,127],'take':0,'pitched':False,'one_shot':True,
               'authored_synthesis':kind,'sha256':hfile(dest)})
    (samples/'attack-map.json').write_text(json.dumps(attack_rows,indent=2)+'\n')
    (samples/'source-map.json').write_text(json.dumps({'big_rusty_program':'Programs/01-full.sfz','selected_performances':credits,
      'zone_count':len(rows),'velocities_and_round_robins_preserved':True,'mic_policy':'close kick; top snare; close toms/hats/cymbals'},indent=2,ensure_ascii=False)+'\n')
    # Keep current upstream CC0 notices beside every extracted performance.
    source_license_snapshot('https://raw.githubusercontent.com/sfzinstruments/karoryfer.big-rusty-drums/main/LICENSE',samples/'LICENSE-Big-Rusty-Drums.txt')
    (samples/'LICENSE-VCSL.txt').write_bytes((VCSL/'LICENSE').read_bytes())
    vcsfiles=[r for r in rows if r.get('source_path','').startswith(('Idiophones/'))]
    credits_doc=[{'source':'Big Rusty Drums','author':'Zygmunt Szpaderski / D. Smolken, Karoryfer Samples','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://shop.karoryfer.com/pages/free-big-rusty-drums','license_url':'https://github.com/sfzinstruments/karoryfer.big-rusty-drums/blob/main/LICENSE','source_commit':'f07ce00 (upstream 1.100 release)','files':[x['file'] for x in rows if x.get('source_path','').startswith('Samples/')] }]
    credits_doc.append({'source':'Original electronic kick/clap layers','author':'Libero sound design session','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://creativecommons.org/publicdomain/zero/1.0/','files':[r['file'] for r in attack_rows]})
    if brazilian:credits_doc.append({'source':'Versilian Community Sample Library (VCSL)','author':'Versilian Studios LLC / Sam Gossner and contributors','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://github.com/sgossner/VCSL','license_url':'https://github.com/sgossner/VCSL/blob/master/LICENSE','files':[x['file']for x in vcsfiles]})
    (samples/'credits.json').write_text(json.dumps(credits_doc,indent=2,ensure_ascii=False)+'\n')
    soundpy=f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nP=Path(__file__).parent\nKEEP={{'file','root','lo','hi','vel','dyn','take','tune_cents','gain_db','loop','offset','end','rt_decay','rt_min_db','pitched','one_shot','choke_group','chokes','articulation'}}\ndef regions(name):\n return [{{k:v for k,v in row.items() if k in KEEP}} for row in json.loads((P/'samples'/name).read_text())]\nsound=Sound(title={title!r},subtitle={subtitle!r},tags=['mog','phonk','drums','kit',{'brazilian-phonk' if brazilian else 'memphis-phonk'!r}],roots={sorted(set(keys+([60,61,62,63,64,65,66,67,68] if brazilian else [])) )!r},accent={'#cf7c32' if brazilian else '#9c5638'!r})\nsound.multisample('body',regions('map.json'),as_dyn=False,process={{'tune':'none','ladder':'keep','align_ms':0,'pre_ms':0,'loop':'none','max_seconds':8,'end_db':-100,'peak_db':-12,'edge_fill':False,'encoding':'flac24'}})\nsound.multisample('attack',regions('attack-map.json'),as_dyn=False,process={{'tune':'none','ladder':'keep','align_ms':0,'pre_ms':0,'loop':'none','max_seconds':1,'end_db':-100,'peak_db':-12,'edge_fill':False,'encoding':'flac24'}})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,rr_reset_ms=1200,humanize={{'cents':0,'ms':0,'db':0}},one_shot=True)\nsound.defaults(mode='Poli',glide=0,voices=48,master=0.0,vel_sens=.72,humanize=0,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=120,rev_mode='Cappella',rev_size=.08,rev_decay=.25,rev_mix=0,width=1,drive=0,tape_wow=0,tape_flutter=0,tape_mix=0,tape_sat=0,caldi_mode='Spento',lvl_body=0,lvl_attack=-1.5,lvl_tail=-60,lvl_air=-60)\n'''
    soundpy=soundpy.replace('voices=48','voices=32')
    (p/'sound.py').write_text(soundpy)
    write_artifacts(slug,title,subtitle,
      f'Route HYB. Big Rusty source has {len([r for r in rows if r.get("source_path","").startswith("Samples/")])} extracted original performances. True SFZ velocity windows and takes are retained; close kick, top snare, close tom/hat/cymbal channels. {"Brazilian extra pads 60–68 are CC0 VCSL cowbell/agogo/claves recordings, each original version stays a velocity layer." if brazilian else "Memphis core focuses on the oversized kick/snare, sidestick, toms and close cymbal recordings."} An original oscillator-generated sub kick and controlled synthetic clap transient reinforce keys 36/38; generated audio is documented separately from source recordings. Drums are one-shot; hats choke the open hat. No commercial sources.', '#cf7c32' if brazilian else '#9c5638','kit')
    compile_folder(p)
    return p

def write_808():
    slug='oitao-808';title='Oitão 808';subtitle='808 con discesa di nota breve e fondamentale stabile fino al note-off'
    p=BANK/slug;s=p/'samples';body=s/'body';body.mkdir(parents=True,exist_ok=True)
    roots=[24,31,36,43,48,55,60,67,72,79,84];rows=[];proof=[]
    for root in roots:
        for v in (42,112):
            f0=440*2**((root-69)/12);ncycles=256;loop_n=round(SR*ncycles/f0);f_eff=SR*ncycles/loop_n
            # First 220 ms contain the intentional pitch glide from +12 semitones;
            # the loop that follows is an authored stable oscillator at the key root.
            att_n=round(.22*SR);t=np.arange(att_n)/SR
            drop=12*np.exp(-t/.032);inst_f=f_eff*2**(drop/12)
            phase=2*np.pi*np.cumsum(inst_f)/SR
            vel=(v-1)/126
            attack=np.sin(phase)+(.20+.10*vel)*np.sin(2*phase+.24)+(.045+.045*vel)*np.sin(3*phase+.1)
            # The body is a periodic wave at pitch; timbre opens slightly with velocity.
            q=np.arange(loop_n)/SR;phi=2*np.pi*f_eff*q+phase[-1]+2*np.pi*f_eff/SR
            cyc=np.sin(phi)+(.20+.10*vel)*np.sin(2*phi+.24)+(.045+.045*vel)*np.sin(3*phi+.1)
            scale=.45+.22*vel
            rng=np.random.default_rng(8400+root+v)
            transient=rng.normal(0,1,att_n)*np.exp(-t/.006)*(.008+.012*vel)
            x=np.r_[attack*scale+transient,cyc*scale]
            x[:240]*=np.linspace(0,1,240)
            name=f'{root}-{v}.wav';dest=body/name;sf.write(dest,x,SR,subtype='PCM_24')
            start=att_n;end=att_n+loop_n
            tune=1200*math.log2(f0/f_eff)
            lo=0 if root==roots[0] else (roots[roots.index(root)-1]+root)//2+1
            hi=127 if root==roots[-1] else (root+roots[roots.index(root)+1])//2
            rows.append({'file':f'body/{name}','root':root,'lo':lo,'hi':hi,
                         'vel':[1,79] if v==42 else [80,127],'take':0,'tune_cents':tune,'loop':{'start':start,'end':end},'one_shot':False})
            proof.append({'file':name,'root':root,'authored_velocity':v,'fundamental_hz':f_eff,'expected_hz':f0,'tune_cents':tune,
                          'pitch_drop_semitones_initial':12,'pitch_drop_tau_seconds':.032,'loop_cycles':ncycles,'loop_start_frame':start,'loop_end_frame':end,
                          'sha256':hfile(dest),'synthesis':'original generated sine + 2nd/3rd harmonic; exact periodic loop'})
    (s/'map.json').write_text(json.dumps(rows,indent=2)+'\n');(s/'design-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    (s/'credits.json').write_text(json.dumps([{'source':'Original Libero oscillator synthesis','license':'CC0 1.0 Universal','license_class':'cc0','author':'Libero sound design session','url':'https://creativecommons.org/publicdomain/zero/1.0/','files':[r['file'] for r in proof]}],indent=2)+'\n')
    soundpy=f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nP=Path(__file__).parent\nsound=Sound(title={title!r},subtitle={subtitle!r},tags=['mog','phonk','808','bass','synth','infinite'],roots={roots!r},accent='#d49a4a')\nsound.multisample('body',json.loads((P/'samples'/'map.json').read_text()),as_dyn=False,process={{'tune':'none','ladder':'keep','align_ms':0,'pre_ms':0,'loop':'source','max_seconds':None,'end_db':-100,'peak_db':-10,'encoding':'flac24','edge_fill':False}})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}})\nsound.defaults(mode='Poli',glide=0,voices=16,master=-5.8,vel_sens=.35,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=260,sub_level=-60,drive=.03,width=1,rev_mix=0,tape_wow=0,tape_flutter=0,caldi_mode='Spento')\n'''
    (p/'sound.py').write_text(soundpy)
    write_artifacts(slug,title,subtitle,'Route SYN authored periodic oscillators. A one-time +12-semitone downward pitch gesture lasts 220 ms; the exact-key fundamental then continues on a source-authored periodic body until note-off. Two authored velocity spectra, not recorded takes. The loop is a designed infinite continuation, not a sampled hardware 808.', '#d49a4a')
    compile_folder(p);return p

def make_bank_metadata():
    BANK.mkdir(parents=True,exist_ok=True)
    rows=[]
    for slug,(title,subtitle,_) in LIVE.items():rows.append({'slug':slug,'title':title,'role':subtitle})
    rows.extend([{'slug':'memphis-fita','title':'Memphis Fita','role':'kit Memphis'}, {'slug':'baile-rua','title':'Baile de Rua','role':'kit Brazilian phonk'}, {'slug':'oitao-808','title':'Oitão 808','role':'pitch-fall bass'}])
    (BANK/'bank.json').write_text(json.dumps({'format':'libero.bank/1','slug':'mog','title':'Mog','subtitle':'phonk Memphis e Brazilian phonk · drum kits, leads, cowbells e bassi','description':'Diciassette programmi: due kit ibridi da registrazioni CC0 e transienti sintetici originali, cowbell melodici, lead, bassi e texture elettroniche; 808 sintetizzato con discesa iniziale e corpo continuo.','version':'1.0.0','author':'Mario Prignano','license':'CC0 1.0 — synthesis; source kits retain upstream CC0 notices','created':NOW,'updated':NOW,'figure':'figure.svg','programs':rows},indent=2,ensure_ascii=False)+'\n')
    (BANK/'figure.svg').write_text(svg('Mog · Phonk','mog-bank','#ca7a36','kit'))

def append_bank_programs(slugs):
    """Add just the requested live synth voices without rebuilding Mog metadata."""
    path=BANK/'bank.json';meta=json.loads(path.read_text())
    programs=meta.get('programs',[]);known={r['slug'] for r in programs}
    for slug in slugs:
        title,subtitle,_=LIVE[slug]
        if slug not in known:programs.append({'slug':slug,'title':title,'role':subtitle});known.add(slug)
    meta['programs']=programs
    meta['description']=meta.get('description','').replace('Diciassette programmi','Diciannove programmi')
    meta['updated']=NOW
    path.write_text(json.dumps(meta,indent=2,ensure_ascii=False)+'\n')

def compile_and_qa(slug: str, hold_s=60):
    p=BANK/slug;out=DEMO/slug;out.mkdir(parents=True,exist_ok=True)
    findings=lint_bundle(p/'build');lines=[f.line() for f in findings]
    fails=[x for x,f in zip(lines,findings) if f.level=='FAIL']
    (p/'lint.txt').write_text('\n'.join(lines)+'\n')
    if fails:raise RuntimeError(slug+' lint FAIL: '+repr(fails))
    iskit=slug in ('memphis-fita','baile-rua')
    if iskit:
        groove=[];bpm=140 if slug=='memphis-fita' else 150;beat=60/bpm
        # 4-bar pattern: kick, half-time snare, hats, plus Brazilian bell cells.
        for bar in range(4):
            base=bar*4*beat
            for b in (0,2.5):groove.append((36,base+b*beat,.19,117 if bar%2==0 else 105))
            for b in (2,):groove.append((38,base+b*beat,.18,114))
            if bar%2:groove.append((37,base+3.5*beat,.16,88))
            for j in range(8):
                t=base+j*beat/2
                groove.append((42,t,.08,64+15*(j%2)))
            if slug=='baile-rua':
                for j in range(8):groove.append((60+(j%4),base+j*beat/2,.11,92+(j%3)*10))
                groove.extend([(64,base+beat*.75,.1,95),(65,base+beat*2.75,.1,100),(63,base+beat*3.5,.12,118)])
                if bar==3:groove.extend([(66,base+.25*beat,.12,106),(67,base+1.25*beat,.12,90),(68,base+3.25*beat,.15,112)])
        notes=','.join(f'{n}:{t:.5f}:{d:.4f}:{v}' for n,t,d,v in groove)
        fn=out/'native-groove.wav';render.render(p,fn,notes,tail=1.5)
        audio=Audio.load(fn);x=audio.data.astype(float)
        row={'name':'native-groove','peak_dbfs':audio.peak_db,'rms_dbfs':audio.rms_db,'seconds':len(x)/audio.sr,'clipped_samples':int(np.sum(abs(x)>=1)),'events':len(groove),'bpm':bpm}
        assert audio.peak_db < -.5 and row['clipped_samples']==0,(slug,row)
        stats=[row]
    else:
        pitch_events=[];t=0
        for n in [24,31,36,48,60,72,84]:pitch_events.append((n,t,.52,100));t+=.65
        pitchfile=out/'native-pitch-run.wav';render.render(p,pitchfile,','.join(f'{n}:{t:.4f}:{d:.4f}:{v}'for n,t,d,v in pitch_events),tail=.5)
        pitchaudio=Audio.load(pitchfile);x=pitchaudio.data.astype(float)
        if x.ndim==1:x=x[:,None]
        pitch_rows=[]
        for n,t,d,v in pitch_events:
            seg=x[int((t+.17)*SR):int((t+.48)*SR)].mean(1)
            nfft=1<<int(np.ceil(np.log2(max(131072,len(seg)*8))))
            spec=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),n=nfft));freq=np.fft.rfftfreq(nfft,1/SR)
            expected=440*2**((n-69)/12)
            # Audit the fundamental band alone. Higher partials are intentionally
            # offset in some synth identities (cowbell/pluck); using them as a
            # harmonic pitch tracker would mistake the design's colour for tuning.
            sel=(freq>expected*2**(-18/1200))&(freq<expected*2**(18/1200))
            bandf=freq[sel];banda=spec[sel]
            measured=float(np.sum(bandf*banda)/np.sum(banda));cents=1200*math.log2(measured/expected)
            pitch_rows.append({'midi':n,'expected_hz':expected,'measured_hz':measured,'cents':cents})
        maxc=max(abs(x['cents']) for x in pitch_rows)
        assert maxc<5,(slug,'pitch mapping',pitch_rows)
        hold=out/'native-held60.wav';render.render(p,hold,'60:0:60:100',tail=1)
        a=Audio.load(hold);x=a.data.astype(float);x=x[:,None]if x.ndim==1 else x
        rms=lambda z:float(20*np.log10(np.sqrt(np.mean(z*z))+1e-20))
        wins=[rms(x[i*SR:(i+1)*SR])for i in range(10,60)]
        assert min(wins)>-55 and max(wins)-min(wins)<8,(slug,'hold',min(wins),max(wins))
        chord=out/'native-chord.wav';render.render(p,chord,'48:0:4:118,55:0:4:114,60:0:4:108,64:0:4:102',tail=1)
        ca=Audio.load(chord);assert ca.peak_db<-.5,(slug,'chord peak',ca.peak_db)
        phrase=out/'native-phrase.wav';phrase_notes='48:0:.34:45,55:.42:.32:78,60:.9:.58:112,63:1.62:.35:95,67:2.08:.65:118,72:2.9:.48:100,60:3.7:2.8:106'
        render.render(p,phrase,phrase_notes,tail=1.5)
        pa=Audio.load(phrase);(out/'spectrogram.png').write_bytes(analysis.spectrogram(pa,title=slug))
        stats=[{'name':'native-pitch-run','pitch':pitch_rows,'max_abs_cents':maxc,'peak_dbfs':pitchaudio.peak_db,'clipped_samples':int(np.sum(abs(pitchaudio.data)>=1))},
               {'name':'native-held60','peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'held_min_dbfs':min(wins),'held_span_db':max(wins)-min(wins),'seconds':len(x)/SR,'clipped_samples':int(np.sum(abs(x)>=1))},
               {'name':'native-chord','peak_dbfs':ca.peak_db,'rms_dbfs':ca.rms_db,'seconds':len(ca.data)/SR,'clipped_samples':int(np.sum(abs(ca.data)>=1))},
               {'name':'native-phrase','peak_dbfs':pa.peak_db,'rms_dbfs':pa.rms_db,'seconds':len(pa.data)/SR,'clipped_samples':int(np.sum(abs(pa.data)>=1))}]
    m=json.loads((p/'build'/'manifest.json').read_text())
    report={'slug':slug,'zones':len(m.get('zones',[])),'body_loops':sum(bool(z.get('loop'))for z in m.get('zones',[])if z.get('layer')=='body'),
            'source_hash_fresh':library.source_hash(p)==m['source_hash'],'compile_warnings':m.get('warnings',[]),'lint':lines,'native':stats,
            'timestamp_utc':datetime.now(timezone.utc).isoformat()}
    if not report['source_hash_fresh']:raise RuntimeError(f'{slug} manifest stale')
    (out/'verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    from collections import Counter
    warn_counts=Counter(line.split()[1] for line in lines if line.startswith('WARN '))
    warn_text=', '.join(f'{name}: {count}' for name,count in sorted(warn_counts.items())) or 'none'
    details={
        'aliasing':'source WAV energy above 18 kHz (analysis warning; original recordings are preserved unchanged)',
        'ladder':'large measured level step between source velocity layers',
        'brightness':'some soft/loud source layers have similar measured brightness',
        'takes':'some source round-robin takes are highly correlated',
        'loudness':'measured loudness varies across neighboring source keys',
    }
    warn_explain='; '.join(details[k] for k in sorted(warn_counts) if k in details)
    note_path=p/'notes.md'
    note_base=note_path.read_text().split('\n## Native QA',1)[0]
    note_text=note_base+'\n\n## Native QA\n\nLint: '+('0 FAIL' if not fails else '; '.join(fails))+'. Native checks: '+', '.join(x['name'] for x in stats)+'. See `~/Libero/demo/mog-v1/'+slug+'/verification.json`. Numerical QA cannot establish genre feel or listening preference.\n'
    if warn_counts:
        note_text+='\n### Lint WARN notes\n\n'+warn_text+'. '+warn_explain+'. These are source-measurement notices, not build failures; the selected original source performances and their natural level/take variation are retained.\n'
    note_path.write_text(note_text)

def sino_interval_qa(slug: str, semitones: int):
    """Measure each intended oscillator pair on native held notes, plus phrase/headroom."""
    p=BANK/slug;out=DEMO/slug;out.mkdir(parents=True,exist_ok=True)
    pitch_notes=[36,48,60,72,84];events=[(n,i*1.35,1.05,108) for i,n in enumerate(pitch_notes)]
    pitch_path=out/'interval-pitch-check.wav'
    render.render(p,pitch_path,','.join(f'{n}:{t:.4f}:{d:.4f}:{v}' for n,t,d,v in events),
                  {'rev_mix':0,'echo_mix':0,'tape_wow':0,'tape_flutter':0},tail=.4)
    x,sr=sf.read(pitch_path,always_2d=True,dtype='float64');rows=[]
    for n,t,d,v in events:
        seg=x[round((t+.30)*sr):round((t+.78)*sr)].mean(axis=1);seg-=seg.mean()
        nfft=1<<int(math.ceil(math.log2(max(262144,len(seg)*8))))
        spec=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),n=nfft));freq=np.fft.rfftfreq(nfft,1/sr)
        f0=440*2**((n-69)/12);f2=f0*2**(semitones/12)
        def measure(center):
            mask=(freq>center*2**(-35/1200))&(freq<center*2**(35/1200));ix=np.flatnonzero(mask)
            if not len(ix):return {'hz':0.0,'cents':999.0,'level_dbfs':-120.0}
            k=ix[np.argmax(spec[ix])];lev=20*math.log10(float(spec[k]/max(np.sum(np.hanning(len(seg))),1e-20))+1e-20)
            return {'hz':float(freq[k]),'cents':1200*math.log2(float(freq[k])/center),'level_dbfs':lev}
        first=measure(f0);second=measure(f2)
        ratio_db=second['level_dbfs']-first['level_dbfs']
        rows.append({'midi':n,'expected_fundamental_hz':f0,'measured_fundamental':first,
                     'expected_interval_hz':f2,'measured_interval_component':second,
                     'interval_semitones':semitones,'component_level_difference_db':ratio_db})
    if max(abs(r['measured_fundamental']['cents']) for r in rows)>5:raise RuntimeError(f'{slug} fundamental tuning failed: {rows}')
    if max(abs(r['measured_interval_component']['cents']) for r in rows)>5:raise RuntimeError(f'{slug} interval component failed: {rows}')
    if min(r['measured_interval_component']['level_dbfs'] for r in rows)<-48:raise RuntimeError(f'{slug} interval component is too weak to verify: {rows}')
    hold=out/'held60.wav';render.render(p,hold,'60:0:60:108',{'rev_mix':0,'echo_mix':0},tail=.5)
    hx,sr=sf.read(hold,always_2d=True);late=hx[10*sr:59*sr];hrms=20*math.log10(float(np.sqrt(np.mean(late*late)))+1e-20)
    if hrms<-50:raise RuntimeError(f'{slug} 60s hold too quiet: {hrms:.2f} dBFS')
    chord=out/'chord-headroom.wav';chord_notes=','.join(f'{n}:0:4:127' for n in [48,55,60,64])
    render.render(p,chord,chord_notes,{'rev_mix':0,'echo_mix':0},tail=.5)
    cx,sr=sf.read(chord,always_2d=True);peak=20*math.log10(float(np.max(np.abs(cx)))+1e-20)
    if peak> -3:raise RuntimeError(f'{slug} dense chord headroom below 3 dB: {peak:.2f} dBFS')
    phrase=out/'quick-phrase.wav';seq='60:0:.28:90,64:.32:.30:106,65:.68:.32:94,67:1.04:.42:114,72:1.56:.34:100,67:2:.28:90,65:2.32:.28:96,64:2.64:.32:108,60:3.02:.7:100'
    render.render(p,phrase,seq,{'rev_mix':0,'echo_mix':0},tail=.6)
    stats={'interval_semitones':semitones,'pitch_and_interval_measurements':rows,'held60_late_rms_dbfs_10_59s':hrms,
           'four_note_chord_127_peak_dbfs':peak,'phrase_peak_dbfs':float(20*math.log10(np.max(np.abs(sf.read(phrase,always_2d=True)[0]))+1e-20)),
           'interval_component_floor_dbfs':min(r['measured_interval_component']['level_dbfs'] for r in rows),
           'limitations':'FFT peak measurements confirm spectral centers/components only; they do not rate timbre, warmth, or genre feel.'}
    (out/'interval-qa.json').write_text(json.dumps(stats,indent=2,ensure_ascii=False)+'\n')
    vpath=out/'verification.json';v=json.loads(vpath.read_text());v['interval_qa']=stats
    vpath.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
    return stats

def append_mog_qa(slugs):
    path=DEMO/'report.json'
    report=json.loads(path.read_text()) if path.exists() else {'bank':'mog','presets':[],'qa':[]}
    for slug in slugs:
        v=json.loads((DEMO/slug/'verification.json').read_text())
        summary={'slug':slug,'zones':v['zones'],'body_loops':v['body_loops'],'lint_failures':sum('FAIL' in x for x in v['lint']),
                 'warnings':{'compile':v['compile_warnings'],'lint':{}}}
        qa={'slug':slug,'zones':v['zones'],'body_loops':v['body_loops'],'lint_failures':summary['lint_failures'],
            'warnings':v['compile_warnings'],'lint_warn_count':sum(x.startswith('WARN ') for x in v['lint']),
            'lint_warn_categories':sorted({x.split()[1] for x in v['lint'] if x.startswith('WARN ')}),'native':v['native'],
            'interval_qa':v.get('interval_qa')}
        for key in ('presets','qa'):
            report.setdefault(key,[])
            report[key]=[x for x in report[key] if x.get('slug')!=slug]
        report['presets'].append(summary);report['qa'].append(qa)
    report['built_utc']=datetime.now(timezone.utc).isoformat()
    report.setdefault('warn_interpretation',{})
    path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')

def render_musical_demos():
    DEMO.mkdir(parents=True,exist_ok=True)
    # Native individual program renders on identical 4-bar clocks, then a fixed
    # -9 dB stem sum leaves peak room. MIDI event lists and stems are retained.
    sessions=[
      ('memphis-phonk',140,[('memphis-fita',None),('reese-de-favela',None),('faisca-cromada',None)]),
      ('brazilian-phonk',150,[('baile-rua',None),('oitao-808',None),('sino-lata',None),('apito-de-neon',None)]),
    ]
    for name,bpm,programs in sessions:
        beat=60/bpm;duration=16*beat;stems=[];events=[]
        for slug,_ in programs:
            if slug.endswith('fita') or slug=='baile-rua':
                ns=[]
                for bar in range(4):
                    base=bar*4*beat
                    ns += [(36,base,.18,118),(36,base+2.5*beat,.18,108),(38,base+2*beat,.18,116)]
                    for j in range(8):ns.append((42,base+j*beat/2,.07,68+(j%2)*15))
                    if slug=='baile-rua':
                        for j in range(8):ns.append((60+j%4,base+j*beat/2,.1,93+(j%3)*10))
                        ns.extend([(64,base+.75*beat,.08,92),(65,base+2.75*beat,.08,98),(63,base+3.5*beat,.11,116)])
            elif slug=='reese-de-favela':
                pattern=[(36,0),(36,.75),(39,1.5),(43,2.75),(36,3.25)]
                ns=[(n,b*4*beat+q*beat,.32,112) for b in range(4) for n,q in pattern]
            elif slug=='oitao-808':
                pattern=[(36,0),(36,.75),(43,1.5),(39,2.5),(36,3.25)]
                ns=[(n,b*4*beat+q*beat,.38,116) for b in range(4) for n,q in pattern]
            elif slug=='sino-lata':
                pattern=[(60,0),(63,.5),(67,1),(70,1.5),(72,2),(70,2.5),(67,3),(63,3.5)]
                ns=[(n,b*4*beat+q*beat,.19,102+(i%3)*8) for b in range(4) for i,(n,q) in enumerate(pattern)]
            elif slug=='faisca-cromada':
                notes=[(72,0),(75,.75),(79,1.5),(82,2.25),(79,2.75),(75,3.25)]
                ns=[(n,b*4*beat+q*beat,.23,92+(b%2)*16) for b in range(4) for n,q in notes]
            elif slug=='apito-de-neon':
                notes=[(79,.25),(82,1),(84,1.75),(87,2.5),(84,3.25)]
                ns=[(n,b*4*beat+q*beat,.21,100) for b in range(4) for n,q in notes]
            else:ns=[]
            seq=','.join(f'{n}:{t:.6f}:{d:.5f}:{v}'for n,t,d,v in ns)
            wav=DEMO/f'{name}-{slug}-native.wav';render.render(BANK/slug,wav,seq,tail=1)
            x=Audio.load(wav).data.astype(np.float64);x=x[:,None]if x.ndim==1 else x
            if x.shape[1]==1:x=np.repeat(x,2,axis=1)
            if len(x)<int((duration+1)*SR):x=np.pad(x,((0,int((duration+1)*SR)-len(x)),(0,0)))
            stems.append(x[:int((duration+1)*SR)]);events.append({'program':slug,'events':ns,'native_wav':wav.name})
        mix=sum(stems)*10**(-9/20)
        peak=float(np.max(np.abs(mix)))
        if peak>.92:mix*=.92/peak
        Audio(mix,SR).save(DEMO/f'{name}-native.wav')
        (DEMO/f'{name}-events.json').write_text(json.dumps({'bpm':bpm,'meter':'4/4','bars':4,'events':events,'mix_gain_db':-9,'peak_after_mix_dbfs':20*math.log10(max(float(np.max(np.abs(mix))),1e-12))},indent=2)+'\n')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--qa-only',action='store_true');ap.add_argument('--slugs',nargs='+');args=ap.parse_args()
    BANK.mkdir(parents=True,exist_ok=True);DEMO.mkdir(parents=True,exist_ok=True)
    slugs=['memphis-fita','baile-rua',*LIVE.keys(),'oitao-808']
    if args.slugs:
        selected=list(dict.fromkeys(args.slugs))
        if set(selected)-set(LIVE):raise SystemExit(f'--slugs supports live synth voices only; unknown: {sorted(set(selected)-set(LIVE))}')
        if not args.qa_only:
            for slug in selected:
                title,subtitle,config=LIVE[slug]
                role='cowbell' if slug.startswith('sino') else ('lead' if slug in ('faisca-cromada','apito-de-neon','motor-ritual','voz-de-asfalto') else ('bass' if slug in ('sub-asfalto','reese-de-favela','baixo-corrente') else 'texture'))
                synth_sound(slug,title,subtitle,config,role,'#c87534' if slug.startswith('sino') else '#b95b32')
            append_bank_programs(selected)
        for slug in selected:
            compile_and_qa(slug)
            if slug=='sino-lata-terza':sino_interval_qa(slug,4)
            elif slug=='sino-lata-quarta':sino_interval_qa(slug,5)
        append_mog_qa(selected)
        print(f'Built and verified only selected Mog synth voices: {selected}',flush=True)
        return
    if not args.qa_only:
        make_bank_metadata()
        brd=sources_big_rusty()
        print(f'Source inventory: Big Rusty {len(brd.regions)} parsed regions, {len(brd.warnings)} parser warnings, VCSL CC0 cached.',flush=True)
        source_license_snapshot('https://raw.githubusercontent.com/sfzinstruments/karoryfer.big-rusty-drums/main/LICENSE',DEMO/'source-evidence'/'LICENSE-Big-Rusty-Drums.txt')
        # Kit banks: separate source maps, documented CC0 provenance, no copied effects.
        build_kit('memphis-fita','Memphis Fita','kit Memphis · kick 24”, snare centrale, sidestick, tom e close cymbals',DRUM_KEYS_MEMPHIS,False)
        build_kit('baile-rua','Baile de Rua','kit Brazilian phonk · batteria asciutta e pads CC0 di cowbell, agogo e claves',DRUM_KEYS_BR,True)
        for slug,(title,subtitle,config) in LIVE.items():
            role='cowbell' if slug.startswith('sino') else ('lead' if slug in ('faisca-cromada','apito-de-neon','motor-ritual','voz-de-asfalto') else ('bass' if slug in ('sub-asfalto','reese-de-favela','baixo-corrente') else 'texture'))
            color='#c87534' if slug.startswith('sino') else '#b95b32'
            synth_sound(slug,title,subtitle,config,role,color)
        write_808()
        make_bank_metadata()
    for slug in slugs:compile_and_qa(slug)
    render_musical_demos()
    # Stable aggregate, hashes and warnings for root-level audit.
    aggregate=[]
    for slug in slugs:
        d=json.loads((DEMO/slug/'verification.json').read_text())
        from collections import Counter
        lint_warn=Counter(x.split()[1] for x in d['lint'] if x.startswith('WARN '))
        aggregate.append({'slug':slug,'zones':d['zones'],'body_loops':d['body_loops'],
                          'lint_failures':sum('FAIL' in x for x in d['lint']),
                          'warnings':{'compile':d['compile_warnings'],'lint':dict(sorted(lint_warn.items()))}})
    qa=[]
    for q in sorted(DEMO.glob('*/verification.json')):
        v=json.loads(q.read_text())
        qa.append({'slug':v['slug'],'zones':v['zones'],'body_loops':v['body_loops'],'lint_failures':sum('FAIL' in x for x in v['lint']),
                   'warnings':v['compile_warnings'],'lint_warn_count':sum(x.startswith('WARN ') for x in v['lint']),
                   'lint_warn_categories':sorted({x.split()[1] for x in v['lint'] if x.startswith('WARN ')}),
                   'native':v['native']})
    (DEMO/'report.json').write_text(json.dumps({'bank':'mog','presets':aggregate,'qa':qa,'built_utc':NOW,
        'demos':['memphis-phonk-native.wav','brazilian-phonk-native.wav'],
        'warn_interpretation':{'aliasing':'original sample energy above 18 kHz; source files are preserved unchanged',
                               'ladder':'velocity-layer level discontinuity in source recordings',
                               'brightness':'similar measured spectrum across some source velocity layers',
                               'takes':'highly correlated source round-robin takes',
                               'loudness':'natural level variation across adjacent source keys'}},indent=2)+'\n')
    print(f'Built {len(slugs)} Mog sounds. Reports and musical demos: {DEMO}',flush=True)

if __name__=='__main__':main()
