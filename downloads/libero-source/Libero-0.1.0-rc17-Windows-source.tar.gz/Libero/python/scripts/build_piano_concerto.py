"""Install the full natural Salamander V3 piano in ~/Libero/banks/piano.

Run from the Libero repository with python/.venv/bin/python. The script reads
the library cache, structurally imports its natural SFZ bank, and refuses to
replace either an existing sketch or installed instrument.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import soundfile as sf

from libero.audio import load
from libero.ingest import import_sfz
from libero.multisample import Process, Region, edit_region


HOME = Path.home() / "Libero"
SOURCE = HOME / "cache/libraries/salamander-grand-v3/Salamander Grand Piano V3.sfz"
SLUG = "pianoforte-concerto"
SKETCH = HOME / "sketches" / SLUG
DEST = HOME / "banks/piano" / SLUG


FIGURE = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke-linecap="round" stroke-linejoin="round" fill="none">
<title>Pianoforte Concerto</title>
<desc>A grand piano seen in section: the graduated string bed represents 30 sampled roots from A0 to C8, and the long bass course marks the 25.81 second compiled decay. Gold marks the strike point; three nested reflections represent the modest 9 percent room.</desc>
<g stroke="currentColor">
  <path d="M65 341 Q155 323 250 322 L426 322 L426 348 Q326 366 231 371 L72 367 Z" fill="#f3eee6" stroke-width="1.3"/>
  <path d="M82 346 Q166 330 246 330 M82 351 Q164 336 246 336 M83 357 Q164 343 246 342 M87 363 Q164 350 246 348" stroke-width="0.55"/>
  <path d="M246 328 L420 326 M246 333 L420 331 M246 338 L420 336 M246 343 L420 341 M246 348 L420 346 M246 353 L420 351 M246 358 L420 356 M246 363 L420 361" stroke-width="0.5"/>
  <path d="M75 337 Q178 297 277 290 Q356 285 437 300 L426 322 Q335 309 247 322 Q156 326 65 341 Z" fill="#f3eee6" stroke-width="1.2"/>
  <path d="M92 333 Q190 305 282 298 M104 337 Q194 312 282 304 M118 340 Q202 319 283 310 M136 343 Q211 326 285 316" stroke-width="0.5"/>
  <path d="M80 337 L80 263 Q177 245 271 253 L430 277 L437 300 Q356 285 277 290 Q178 297 75 337 Z" fill="#f3eee6" stroke-width="1.2"/>
  <path d="M91 326 L91 272 M104 322 L104 269 M117 318 L117 266 M130 314 L130 263 M143 310 L143 261 M156 306 L156 259 M169 302 L169 258 M182 298 L182 257 M195 295 L195 256 M208 292 L208 255 M221 290 L221 254 M234 287 L234 253 M247 285 L247 253 M260 283 L260 254 M273 281 L273 255 M286 279 L286 257 M299 278 L299 258 M312 277 L312 260 M325 276 L325 262 M338 276 L338 264 M351 276 L351 266 M364 276 L364 268 M377 277 L377 270 M390 278 L390 272 M403 279 L403 274 M416 280 L416 276" stroke-width="0.45"/>
  <path d="M73 369 L78 391 L390 391 L421 368 M79 386 L390 386 M99 371 L104 386 M383 370 L378 386" stroke-width="1.1"/>
  <path d="M102 392 L98 414 M370 392 L377 414 M93 414 L112 414 M369 414 L386 414" stroke-width="1.2"/>
  <path d="M84 402 L104 402 M373 402 L381 402 M150 392 L150 404 M154 392 L154 404 M160 392 L160 404" stroke-width="0.55"/>
</g>
<g stroke="#b8924f" stroke-width="1.4">
  <path d="M72 276 L421 286"/>
  <circle cx="246" cy="281" r="4" fill="#b8924f"/>
</g>
<g stroke="currentColor" stroke-width="0.55" stroke-opacity="0.45">
  <path d="M154 226 Q256 190 358 226 M141 214 Q256 172 371 214 M128 202 Q256 154 384 202"/>
  <path d="M154 226 Q256 242 358 226 M141 214 Q256 239 371 214 M128 202 Q256 236 384 202"/>
</g>
</svg>
'''


def correct_source_ladder(folder: Path) -> list[dict]:
    """Apply only the small gains needed to keep real source levels monotonic."""
    map_path = folder / "samples/map.json"
    mapping = json.loads(map_path.read_text())
    process = Process.from_any({
        "tune": "smooth", "ladder": "keep", "peak_db": -9.0,
        "align_ms": 5.0, "loop": "none", "max_seconds": None,
        "end_db": -80.0, "fade_ms": 25.0, "encoding": "flac24",
    })
    levels: dict[int, list[tuple[dict, float]]] = {}
    for row in mapping["body"]:
        audio = load(folder / "samples" / row["file"])
        _, facts = edit_region(audio, Region.from_any(row, "body"), process, 48000)
        levels.setdefault(row["root"], []).append((row, facts["lufs_max"] + row.get("gain_db", 0.0)))

    changes = []
    for root, rows in sorted(levels.items()):
        rows.sort(key=lambda item: item[0]["vel"])
        previous = None
        for row, level in rows:
            correction = max(0.0, previous - 0.49 - level) if previous is not None and level < previous - 0.5 else 0.0
            if correction > 0:
                row["gain_db"] = round(row.get("gain_db", 0.0) + correction, 2)
                changes.append({"root": root, "vel": row["vel"], "gain_db": row["gain_db"]})
                level += correction
            previous = level
    map_path.write_text(json.dumps(mapping, indent=1) + "\n")
    return changes


def correct_compiled_ladder(folder: Path) -> list[dict]:
    """Repair only final measured velocity reversals, after compiler calibration."""
    from libero.lint import _load

    manifest = json.loads((folder / "build/manifest.json").read_text())
    map_path = folder / "samples/map.json"
    mapping = json.loads(map_path.read_text())
    rows: dict[int, list[dict]] = {}
    for row in mapping["body"]:
        rows.setdefault(row["root"], []).append(row)
    zones: dict[int, list[tuple[dict, float]]] = {}
    for zone in manifest["zones"]:
        if zone["layer"] == "body":
            zones.setdefault(zone["root"], []).append((zone, _load(folder / "build", zone, True).lufs_max))

    changes = []
    for root, actual in zones.items():
        actual.sort(key=lambda pair: tuple(pair[0].get("dyn") or (pair[0]["vel_lo"], pair[0]["vel_hi"])))
        root_rows = sorted(rows[root], key=lambda row: row["vel"])
        if len(actual) != len(root_rows):
            raise RuntimeError(f"Root {root}: compiled/source layer count differs")
        target = actual[0][1]
        for (zone, measured), row in zip(actual[1:], root_rows[1:]):
            correction = max(0.0, target - 0.49 - measured) if measured < target - 0.5 else 0.0
            if correction > 0.01:
                row["gain_db"] = round(row.get("gain_db", 0.0) + correction, 2)
                changes.append({"root": root, "vel": row["vel"], "gain_db": row["gain_db"]})
                measured += correction
            target = measured
    if changes:
        map_path.write_text(json.dumps(mapping, indent=1) + "\n")
    return changes


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(f"Expected the already-fetched Salamander source at {SOURCE}")
    if DEST.exists() or SKETCH.exists():
        raise FileExistsError(f"Refusing to replace existing instrument: {DEST if DEST.exists() else SKETCH}")

    imported = import_sfz(
        SLUG,
        SOURCE,
        family="piano",
        title="Pianoforte Concerto",
        subtitle="Yamaha C5 · 16 livelli · decay naturale",
        layers=16,
        root_step=1,
        takes=1,
        budget_mb=5000,
        quality="slow",
        releases=True,
    )
    if imported["layers"] != 16 or imported["roots"] != 30 or imported["tail_regions"] != 88:
        raise RuntimeError(f"Import did not keep the complete natural map: {imported}")

    DEST.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(SKETCH), str(DEST))
    ladder_corrections = correct_source_ladder(DEST)

    recipe = '''"""Pianoforte Concerto — complete natural Salamander V3 Yamaha C5 recordings."""
import json
from pathlib import Path
from libero import Sound

MAP = json.loads((Path(__file__).parent / "samples" / "map.json").read_text())
sound = Sound(title="Pianoforte Concerto", subtitle="Yamaha C5 · 16 livelli · decay naturale",
              tags=["piano", "grand", "sampled", "salamander"], sample_rate=48000)
sound.multisample("body", MAP["body"], process={
    "tune": "smooth", "ladder": "keep", "peak_db": -9.0,
    "align_ms": 5.0, "loop": "none", "max_seconds": None,
    "end_db": -80.0, "fade_ms": 25.0, "encoding": "flac24"})
sound.multisample("tail", MAP["tail"], process={
    "tune": "none", "align_ms": 0.0, "ladder": "keep",
    "max_seconds": None, "end_db": -80.0, "fade_ms": 25.0,
    "encoding": "flac24"})
sound.performance(dyn_crossfade=0, humanize={"cents": 0.0, "ms": 0.0, "db": 0.0}, rr_reset_ms=0)
sound.defaults(mode="Poli", glide=0, voices=32, dyn_mode="Velocità",
               amp_attack=0, amp_decay=10000, amp_sustain=1.0, amp_release=280,
               vel_sens=0.3, master=0, lvl_body=0, lvl_tail=-4,
               tape_wow=0, tape_flutter=0, tape_sat=0, drive=0,
               lfo_pitch=0, lfo_amp=0, echo_mix=0,
               rev_mode="Cappella", rev_mix=0.09, rev_decay=1.8,
               res_mix=0)
'''
    (DEST / "sound.py").write_text(recipe)
    (DEST / "figure.svg").write_text(FIGURE)
    (DEST / "notes.md").write_text(f'''# Pianoforte Concerto

Yamaha C5 concert grand from the full natural Salamander Grand Piano V3 recordings. This build keeps all 16 genuinely recorded strike velocities across the 30 minor-third roots from A0 (MIDI 21) through C8 (108), plus the 88 chromatic hammer-release recordings.

## Source and mapping

- Salamander Grand Piano V3, recordings by Alexander Holm, remapped by Kinwie; CC BY 3.0: https://github.com/sfzinstruments/SalamanderGrandPiano
- The SFZ was structurally imported from its default Natural keyswitch bank. Every recorded velocity band is retained: 16 layers × 30 roots = 480 body regions. The release set is the 88 hammer samples; the separate string-resonance samples and CC64 pedal noises are not included in the body or tail.
- Source samples are hard-linked under `samples/salamander-grand-v3/`; the source library remains in `~/Libero/cache/libraries/salamander-grand-v3`.
- `tune='smooth'` performs one consistency pass on the uncorrected source map. It keeps the piano's natural stretch curve while correcting only recorded layers or roots that sit away from their peers. Dynamics use hard switching (`dyn_crossfade=0`), so samples are not phase-blended. Humanize, wow, flutter, saturation, drive and the extra resonator are zero.

## Decay, gain and playback

There is no loop and no fixed duration cap. Body samples end only after their 20 ms RMS envelope has fallen 80 dB below its peak, preserving the recorded bass decay (the loud A0 source reaches 25.86 s). A short end fade removes truncation clicks. The single instrument gain targets -9 dBFS at the loudest region; no sample is normalized independently. Hammer samples retain the SFZ's -37 dB source gain and 2 dB/s held-note attenuation. Playback is polyphonic at the engine maximum of 32 voices, with modest Cappella room at 9% and no added synthetic string resonance.

## Limits

The source SFZ includes three velocity layers of string-resonance releases and CC64-triggered pedal noises. Libero's multisample recipe has no native source-string-resonance bus or pedal-noise trigger map, so these are intentionally not summed into note bodies or misrepresented as hammer releases. The 88 real hammer-release tails are present. CC64 sustain is exercised in native previews; half-pedaling and sympathetic-string response are not claimed.

## Build and QA

Install into a fresh Libero library with `python/.venv/bin/python python/scripts/build_piano_concerto.py` from the Libero repository; the script refuses to overwrite an existing sketch or installed sound. Native preview and spectrogram files are generated by `python/.venv/bin/python python/scripts/build_piano_concerto_qa.py`.
''')
    (DEST / "samples" / "ATTRIBUTION.md").write_text("""# Recordings

Salamander Grand Piano V3 by Alexander Holm, with SFZ remapping by Kinwie. Licensed under Creative Commons Attribution 3.0 Unported (CC BY 3.0).

Source and licence: https://github.com/sfzinstruments/SalamanderGrandPiano

The imported Natural SFZ map retains all 16 recorded velocity layers, 30 original sample roots and 88 hammer releases. Libero edits only the working copies in its multisample cache; it does not overwrite source recordings.
""")
    report = {k: imported[k] for k in ("body_regions", "tail_regions", "layers", "of_layers", "roots", "of_roots", "takes", "license")}
    report["family_default_length_cap_estimate_mb"] = imported["estimated_mb"]
    report["source_ladder_corrections"] = ladder_corrections
    (DEST / "import-report.json").write_text(json.dumps(report, indent=2) + "\n")
    repo = Path(__file__).resolve().parents[2]
    for pass_number in range(1, 5):
        subprocess.run([sys.executable, "-m", "libero.cli", "compile", SLUG], cwd=repo, check=True)
        from libero.lint import lint_bundle

        findings = lint_bundle(DEST / "build")
        failures = [f for f in findings if f.level == "FAIL"]
        if not failures:
            break
        if any(f.check != "ladder" for f in failures):
            raise RuntimeError("Unexpected compile lint failure: " + "; ".join(f.line() for f in failures))
        adjustments = correct_compiled_ladder(DEST)
        if not adjustments:
            raise RuntimeError("Could not repair final velocity ladder: " + "; ".join(f.line() for f in failures))
        report.setdefault("compiled_ladder_corrections", []).extend(adjustments)
        (DEST / "import-report.json").write_text(json.dumps(report, indent=2) + "\n")
    else:
        raise RuntimeError("Velocity ladder did not pass lint after four measured correction passes")
    final_lint = [f.line() for f in findings if f.level in ("FAIL", "WARN")]
    report["lint_findings"] = final_lint
    manifest = json.loads((DEST / "build/manifest.json").read_text())
    body_seconds = sum(sf.info(DEST / "build" / z["file"]).duration for z in manifest["zones"] if z["layer"] == "body")
    decoded_gb = body_seconds * 48000 * 2 * 4 / 1e9
    report["body_audio_minutes"] = round(body_seconds / 60, 1)
    report["decoded_body_memory_decimal_GB"] = round(decoded_gb, 3)
    (DEST / "import-report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"installed": str(DEST), **report, "import_notes": imported["notes"]}, indent=2))


if __name__ == "__main__":
    main()
