"""Read-only installed-library integration audit; taste and missing sources remain explicit."""
import json,sys
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import library
OUT=Path.home()/'Libero/demo/library-refresh-v3';OUT.mkdir(parents=True,exist_ok=True)
rows=library.list_sounds();errors=[];records=[]
for r in rows:
 folder=Path(r['path']);mp=folder/'build/manifest.json'
 if not mp.is_file():errors.append(f'{r["slug"]}: no manifest');continue
 m=json.loads(mp.read_text());missing=[z['file'] for z in m['zones'] if not (folder/'build'/z['file']).is_file()]
 if missing:errors.append(f'{r["slug"]}: missing zone files {missing}')
 records.append({'slug':r['slug'],'bank':r['bank'],'saved':r['saved'],'path':r['path'],'zones':len(m['zones']),'source_hash':m.get('source_hash'),'wow':m.get('params',{}).get('tape_wow',0),'flutter':m.get('params',{}).get('tape_flutter',0)})
counts=Counter(r['slug'] for r in rows)
errors += [f'duplicate slug: {s}' for s,n in counts.items() if n>1]
for rejected in ['basso-slap','voci-bianche-sillabe']:
 if rejected in counts:errors.append(f'rejected preset still active: {rejected}')
for slug in ['808-notte','808-colpo','808-cavo']:
 p=library.find_sound(slug);m=json.loads((p/'build/manifest.json').read_text());c=json.loads((p/'samples/credits.json').read_text())
 if not any('Abletunes' in x['source'] and x['license_class']=='eula' for x in c):errors.append(f'{slug}: wrong source or export class')
 if len(m['zones'])!=1 or m['zones'][0].get('one_shot') or m['zones'][0].get('loop'):errors.append(f'{slug}: wrong playback semantics')
for r in records:
 if r['bank'] in ['aria','bassi','cielo'] and (r['wow'] or r['flutter']):errors.append(f'{r["slug"]}: unsolicited tape modulation')
report={'status':'partial: child choir and dedicated slap source remain unresolved','active_count':len(rows),'saved_count':sum(r['saved'] for r in rows),'bank_counts':dict(Counter(r['bank'] for r in rows)),'structural_errors':errors,'unresolved':['real children choir: original download requires Pianobook account access or authorized purchase','dedicated realistic slap replacement: better source still required; rejected preset archived'],'records':records,'evidence':{'808_native':'../bassi-808-v3/verification.json','analog_sources':'../aria-analog/source-pitch-audit.json','analog_native':'../aria-analog/report.json','aria_hybrids':str(Path.home()/'Libero/banks/aria/_reports/REPORT.md'),'cielo':str(Path.home()/'Libero/banks/cielo/_reports/v3-children/RICERCA.md')},'limitations':'Structural and native playback checks are not listening approval or commercial-library quality certification.'}
(OUT/'integration.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','active_count','saved_count','bank_counts','structural_errors']},indent=2))
if errors:raise SystemExit(1)
