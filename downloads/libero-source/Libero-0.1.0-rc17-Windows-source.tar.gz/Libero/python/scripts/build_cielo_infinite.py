"""Cielo infinite: original entrances, recorded polygestural codas, 48 s loops.
Run from Libero with PYTHONPATH=python and the project Python interpreter.
Writes a staged bank; QA must pass before installing with --install.
"""
from pathlib import Path
import argparse, datetime, functools, hashlib, json, math, shutil
import numpy as np
from scipy import signal
from scipy.ndimage import uniform_filter1d
from libero import Audio, load, dsp, licenses
from libero.compiler import compile_sound
from build_cielo_v2 import RECS, ensemble, write_sound, CREDIT

SR=48000; PERIOD=48; N=SR*PERIOD
BANK=Path.home()/'Libero/banks/cielo'
BACK=Path.home()/'Libero-backups/2026-10-03/cielo-infinite-before'
BASE=Path.home()/'Libero/cache/research/cielo-infinite'
STAGE=BASE/'staged'; REPORT=BASE/'reports'
BAD={'m10_long_forte_o-0-59.wav','m10_arpeggios_c_slow_piano_o-0-52.wav','m10_scales_c_slow_forte_o-0-53.wav','m10_scales_f_slow_piano_o-0-55.wav'}
BAD.update({'m6_arpeggios_c_slow_forte_o-1-56.wav','f7_arpeggios_c_slow_piano_a-2-68.wav','f3_arpeggios_c_slow_forte_e-1-65.wav','f6_arpeggios_c_slow_forte_e-2-67.wav','f8_arpeggios_belt_o-0-71.wav'})
SUSTAIN_TRIMS={'f8_arpeggios_belt_o-0-71.wav':(.15,.8)}

@functools.lru_cache(maxsize=120)
def note(path, target, cents):
    a=load(path,sr=SR)
    if Path(path).name in SUSTAIN_TRIMS:a=a.trim(*SUSTAIN_TRIMS[Path(path).name])
    a=a.pitch(target).pitch(cents/100)
    x=dsp.mono(a.data);e=np.sqrt(np.maximum(0,signal.convolve(x*x,np.ones(960)/960,mode='same')))
    good=np.flatnonzero(e>max(e.max()*.18,1e-7))
    if len(good):x=x[max(0,good[0]-480):min(len(x),good[-1]+480)]
    fade=min(7200,len(x)//5);w=np.ones(len(x));w[:fade]=np.sin(np.linspace(0,np.pi/2,fade))**2;w[-fade:]=w[:fade][::-1]
    return x*w

def candidates(source,target):
    tech=source['dynamic'];allowed={tech}
    # Messa retains its original crescendo entrance; the coda uses its mature
    # original normal-vowel technique from the very same performers.
    if tech=='messa':allowed={'straight','vibrato','forte'}
    rows=[r for r in RECS if r['singer']==source['singer'] and r['vowel']==source['vowel'] and r['dynamic'] in allowed and abs(r['root']-target)<=2 and r['seconds']>=.65 and Path(r['file']).name not in BAD]
    if not rows:rows=[source]
    rows=sorted(rows,key=lambda r:(abs(r['root']-target),-r['seconds']))[:10]
    return rows

def recorded_coda(prov,root,seed):
    rng=np.random.default_rng(seed);sources=prov['sources'];y=np.zeros((N,2));used=[]
    for lane,s in enumerate(sources):
        target=root+12*s.get('section_octave',0);rows=candidates(s,target)
        pan=s.get('assembly_pan',-.65+1.3*lane/max(1,len(sources)-1));angle=(pan+1)*np.pi/4
        lane_y=np.zeros(N);t=-int(rng.uniform(.2,3)*SR);last=None;events=[]
        ref=note(s['file'],target-s['root'],0);ref_rms=np.sqrt(np.mean(ref*ref))
        while t<N:
            choices=[r for r in rows if r['file']!=last] or rows;r=choices[int(rng.integers(len(choices)))];last=r['file']
            # Extracted notes already carry a constant pitch correction. No
            # dynamic pitch resynthesis and no cloned near-copy unison voices.
            x=note(r['file'],target-r['root'],0).copy();rr=np.sqrt(np.mean(x*x));x*=np.clip(ref_rms/max(rr,1e-10),.25,4)
            x*=10**(s.get('section_gain_db',0)/20)
            idx=(np.arange(len(x))+t)%N;np.add.at(lane_y,idx,x)
            events.append({'source':r['source'],'file':r['file'],'source_seconds':r['source_seconds'],'coda_note_window_s':SUSTAIN_TRIMS.get(Path(r['file']).name),'root':r['root'],'target':target,'start_s':round(t/SR,5),'seconds':len(x)/SR})
            # Successive independent original performances overlap only their
            # entrance/exit ramps; each singer has its own non-synchronous lane.
            t+=max(int(.3*SR),len(x)-int(rng.uniform(.07,.12)*SR))
        y+=np.stack([lane_y*np.cos(angle),lane_y*np.sin(angle)],axis=1)
        used.append({'singer':s['singer'],'vowel':s['vowel'],'technique':s['dynamic'],'section_octave':s.get('section_octave',0),'distinct_recordings':len({e['file'] for e in events}),'events':events})
    y/=np.sqrt(len(sources));y-=y.mean(axis=0)
    return y,used

def ellen_coda(x):
    # Only the last recorded Ah state. Shared phase advance preserves stereo
    # phase relationships; spectral motion follows smooth paths through the
    # actual recording. Phase is never independently randomized per frame.
    nfft=4096;hop=512;frames=N//hop;length=frames*hop;window=np.hanning(nfft)
    segment=x[int(5.68*SR):int(6.48*SR)]
    spec=np.stack([np.fft.rfft(segment[i:i+nfft]*window[:,None],axis=0) for i in range(0,len(segment)-nfft,hop)])
    mag=abs(spec);ph=np.angle(spec);expected=2*np.pi*np.arange(nfft//2+1)*hop/nfft
    inc=expected[None,:,None]+np.angle(np.exp(1j*(np.diff(ph,axis=0)-expected[None,:,None])))
    phases=[];magnitudes=[];phase=ph[0].copy()
    for i in range(frames):
        pos=(len(spec)-2)*(.5+.28*np.sin(2*np.pi*i/frames*5)+.16*np.sin(2*np.pi*i/frames*7+.8));j=int(pos);f=pos-j
        magnitudes.append(mag[j]*(1-f)+mag[j+1]*f)
        # Identity phase locking: neighboring bins remain tied to an actual
        # spectral peak instead of creating independently beating bin phases.
        mm=magnitudes[-1].mean(axis=1);peaks=signal.find_peaks(mm,distance=3)[0]
        if not len(peaks):peaks=np.array([int(mm.argmax())])
        nearest=peaks[np.argmin(abs(np.arange(len(mm))[:,None]-peaks[None,:]),axis=1)]
        source_phase=ph[j]+np.angle(np.exp(1j*(ph[j+1]-ph[j])))*f
        locked=phase.copy();locked[:,0]=phase[nearest,0]+np.angle(np.exp(1j*(source_phase[:,0]-source_phase[nearest,0])))
        locked[:,1]=locked[:,0]+np.angle(np.exp(1j*(source_phase[:,1]-source_phase[:,0])))
        phases.append(locked);delta=inc[min(j,len(inc)-1)]*(1-f)+inc[min(j+1,len(inc)-1)]*f
        # Use common left-channel advance, retain source inter-channel offsets.
        phase[:,0]+=delta[:,0];phase[:,1]=phase[:,0]+np.angle(np.exp(1j*(ph[j,:,1]-ph[j,:,0])))
    phases=np.array(phases);magnitudes=np.array(magnitudes)
    total=phase[:,0]-ph[0,:,0];correction=2*np.pi*np.round(total/(2*np.pi))-total
    phases[:,:,0]+=np.arange(frames)[:,None]/frames*correction[None,:]
    phases[:,:,1]+=np.arange(frames)[:,None]/frames*correction[None,:]
    y=np.zeros((length,2));weight=np.zeros(length)
    for i,(m,p) in enumerate(zip(magnitudes,phases)):
        block=np.fft.irfft(m*np.exp(1j*p),n=nfft,axis=0)*window[:,None];idx=(np.arange(nfft)+i*hop)%length
        np.add.at(y,idx,block);np.add.at(weight,idx,window*window)
    y/=weight[:,None];y-=y.mean(axis=0)
    # Smooth circular envelope conditioning removes STFT beating/pumping;
    # maintain up to +/-1 dB of original slow amplitude motion.
    rms=np.sqrt(np.maximum(1e-16,uniform_filter1d(np.mean(y*y,axis=1),int(.24*SR),mode='wrap')))
    median=np.median(rms);desired=np.clip(rms,median*10**(-1/20),median*10**(1/20))
    gain=uniform_filter1d(desired/rms,int(.08*SR),mode='wrap');y*=gain[:,None]
    return y,[{'method':'stereo phase-continuous spectral continuation','source_seconds':[5.68,6.48],'source':'ellenmentor original HQ MP3','not_new_performers':True}]

def extend(folder):
    maps=json.loads((folder/'samples/map.json').read_text());provs=json.loads((folder/'samples/provenance.json').read_text());log=[]
    for i,(m,p) in enumerate(zip(maps,provs)):
        path=folder/'samples'/m['file'];a=load(path,sr=SR);x=a.data
        if x.ndim==1:x=np.stack([x/np.sqrt(2),x/np.sqrt(2)],axis=1)
        if folder.name=='ellen-ooh-aha':coda,events=ellen_coda(x);join=int(6.35*SR)
        else:
            coda,events=recorded_coda(p,m['root'],19031+i*119+sum(map(ord,folder.name)))
            times,env=dsp.rms_envelope(x,SR,.025);good=np.flatnonzero(env>max(env.max()*.52,1e-8));join=int(min(len(x)/SR-.04,max(.4,float(times[good[-1]]) if len(good) else len(x)/SR*.7))*SR)
        blend=min(int(.32*SR),join//3)
        body=x[int(.15*SR):max(int(.45*SR),join-blend)] if folder.name!='ellen-ooh-aha' else x[int(5.8*SR):join]
        target=np.sqrt(np.mean(body*body));level=np.sqrt(np.mean(coda*coda));coda*=target/max(level,1e-12)
        # Preserve source headroom; coda is level matched, never peak boosted.
        if abs(coda).max()>abs(x).max()*1.08:coda*=abs(x).max()*1.08/abs(coda).max()
        prefix=SR;start=join+prefix-blend;out=np.zeros((start+len(coda)+SR//10,2));out[:join]=x[:join]
        pre=coda[-prefix:];t=np.linspace(0,1,blend);out[join-blend:join]=x[join-blend:join]*(1-t[:,None])+pre[:blend]*t[:,None]
        out[join:start]=pre[blend:];out[start:start+len(coda)]=coda
        out[start+len(coda):]=coda[:SR//10]*np.linspace(1,0,SR//10)[:,None]
        Audio(out,SR).save(path,subtype='PCM_24');m['loop']={'start':start,'end':start+len(coda)}
        log.append({'file':m['file'],'root':m['root'],'articulation':m['articulation'],'dyn':m.get('dyn'),'original_seconds':a.duration,'original_entrance_until_s':round((join-blend)/SR,4),'transition_s':blend/SR,'loop_start_s':start/SR,'loop_period_s':len(coda)/SR,'sustain_sources':events,'source_peak_db':a.peak_db,'coda_peak_db':float(dsp.db(abs(coda).max()))})
    (folder/'samples/map.json').write_text(json.dumps(maps,indent=2));(folder/'samples/infinite-provenance.json').write_text(json.dumps(log,indent=2))
    recipe=(folder/'sound.py').read_text().replace("'loop':'none'","'loop':'source'").replace("'align_ms':5","'align_ms':0")
    (folder/'sound.py').write_text(recipe)
    res=compile_sound(folder,jobs=2)
    if not res.ok:raise RuntimeError(res.error)
    notes=(folder/'notes.md').read_text().split('\n## Verifiche tecniche')[0]
    notes=notes.replace('Nessun loop: tenendo il tasto, ogni componente termina alla fine della registrazione.','La nuova coda consente note infinite.').replace('Nessun loop,','Attacco originale e nuova coda sostenuta,')
    notes+='\n\n## Sostegno infinito\n\nAttacco e transizione originali conservati; una coda di48secondi sostiene la nota. Ogni dinamica,articolazione e take della mappa precedente resta presente. Le altre esecuzioni originali della stessa persona,vocale e tecnica formano corsie indipendenti; gli ingressi e i respiri sono sfalsati. Nessun wow/flutter e nessun accordo aggiunto. Il loop circolare è costruito a livello di campione, con movimento registrato e documentazione di ogni intervallo in samples/infinite-provenance.json. La ripetizione matematica dopo48secondi esiste: non si certifica impercettibilità senza ascolto.\n'
    if folder.name=='ellen-ooh-aha':notes+='\nEllen conserva Ooh→Aha, la pausa e il secondo ingresso. Solo l’ultimaAh (5.68–6.48s della fonte) viene prolungata in STFTstereo a fase continua: è una coda DSPda voci registrate, non40secondi di nuova performance e non dodici nuove cantanti. Il gesto completo non viene retriggerato.\n'
    (folder/'notes.md').write_text(notes)
    print(folder.name,len(maps),'extended',flush=True)

def orizzonte():
    regs=[];all_singers=[f'male{i}' for i in range(1,12)]+[f'female{i}' for i in range(1,10)]
    for vowel,art in [('a','ah'),('e','eh'),('o','oh')]:
        for root in [57,60,63,66]:
            rows=[ensemble('orizzonte',vowel,t,root,all_singers,True,12) for t in ['pp','straight','forte']]
            if not all(rows):continue
            for i,r in enumerate(rows):
                # Low human section stays near the centre; upper performers
                # span a wider stage than Volta, without stereoizing clones.
                buffers=[];counts={-1:0,0:0,1:0}
                for s in r['sources']:
                    section=s.get('section_octave',0);order=counts[section];counts[section]+=1
                    pan=(-1 if order%2==0 else 1)*({-1:.18,0:.55,1:.94}[section])*(.65+.35*(order%3)/2);s['assembly_pan']=pan
                    target=root+section*12;xx=dsp.mono(load(s['file'],sr=SR).pitch(target-s['root']).data)*10**(s.get('section_gain_db',0)/20)
                    xx=np.pad(xx,(order%4*384,0));angle=(pan+1)*np.pi/4;buffers.append(np.stack([xx*np.cos(angle),xx*np.sin(angle)],axis=1))
                yy=np.zeros((max(map(len,buffers)),2))
                for xx in buffers:yy[:len(xx)]+=xx
                Audio(yy/np.sqrt(len(buffers)),SR).remove_dc().fade_in(.003).fade_out(.04).save(r['file'],subtype='PCM_24')
                r.update(articulation=art,dyn=[i/3,(i+1)/3],gain_db=0);regs.append(r)
    arts=[{'id':a,'name':n,'key':24+i} for i,(a,n) in enumerate([('ah','Ah'),('eh','Eh'),('oh','Oh')])]
    p=write_sound('coro-orizzonte','Coro · Orizzonte','volta','Un insieme grande per accordi epici: bassi reali sotto, baritoni/tenori e mezzosoprani al centro, soprani sopra. Tutte le sezioni seguono la stessa nota o la sua ottava, senza accordi preregistrati. La coda mantiene molte persone contemporaneamente invece di lasciare finire una dopo l’altra le componenti.',regs,arts,24,.22,3.2)
    dest=STAGE/p.name;shutil.copytree(p,dest)
    recipe=(dest/'sound.py').read_text().replace('rev_size=.6','rev_size=.78');(dest/'sound.py').write_text(recipe)
    paths=[]
    for j in range(20):
        y=180+j*6;paths.append(f'<path d="M62,{y}Q150,{y-35} 256,{y}T450,{y}" stroke="currentColor" stroke-width=".5"/>')
        paths.append(f'<path d="M{80+j*17},340V{240+j%3*9}" stroke="currentColor" stroke-width=".7"/>')
    (dest/'figure.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>Coro · Orizzonte</title><desc>Twenty available independent performers become a broad layered horizon; three heights below it represent bass, middle and soprano octaves. The gold line marks a continuous sustained body.</desc>'+''.join(paths)+'<path d="M62,316H450" stroke="#b8924f" stroke-width="1.3"/></svg>')

def build():
    if not BACK.exists():raise RuntimeError('Full backup required before mutation')
    STAGE.mkdir(parents=True,exist_ok=False);REPORT.mkdir(parents=True,exist_ok=True)
    for p in BACK.iterdir():
        if (p/'sound.py').exists():shutil.copytree(p,STAGE/p.name)
    orizzonte()
    for p in sorted(STAGE.iterdir()):
        if (p/'sound.py').exists():extend(p)

def install():
    report=json.loads((REPORT/'qa.json').read_text());assert len(report)==8 and all(v['fail']==0 and v['looped']==v['zones'] for v in report.values())
    archive=Path.home()/'Libero-backups/2026-10-03/cielo-infinite-retired';archive.mkdir(parents=True,exist_ok=False)
    for p in STAGE.iterdir():
        if (p/'sound.py').exists():
            dst=BANK/p.name
            if dst.exists():shutil.move(str(dst),archive/dst.name)
            shutil.copytree(p,dst)
    shutil.copytree(REPORT,BANK/'_reports/infinite')
    meta=json.loads((BANK/'bank.json').read_text());meta.update(version='3.0.0',subtitle='otto cori e voci · sostegno infinito',description='Sette identità vocali approvate con attacchi originali e code sostenute, più Coro · Orizzonte: sezioni ampie di interpreti indipendenti. Tutte le vocali e dinamiche restano disponibili. Bambini in attesa di una nuova fonte.',updated=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'))
    (BANK/'bank.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
    (BANK/'README.md').write_text('# Cielo · note infinite\n\nSette timbri approvati mantengono gli attacchi originali e tutte le vocali/dinamiche; le nuove code circolari di48secondi sostengono le note. Coro · Orizzonte aggiunge sezioni ampie di persone reali con registri e ottave autentici. Ellen mantiene Ooh→Aha e prolunga soltanto l’ultima vocale con una coda STFTstereo dichiarata. Nessun wow/flutter.\n\nLe costruzioni e i limiti sono nelle notes di ogni strumento; la provenienza di ogni gesto aggiunto è in samples/infinite-provenance.json. Le misure non certificano impercettibilità dei loop o gusto: il giudizio musicale resta all’ascolto. Bambini non disponibili: il precedente preset bocciato resta archiviato fuori banca.\n\nBackup completo prima della modifica: ~/Libero-backups/2026-10-03/cielo-infinite-before. Rapporti e confronti nativi: _reports/infinite.\n')
    print('INSTALLED8',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--install',action='store_true');a=p.parse_args()
    install() if a.install else build()
