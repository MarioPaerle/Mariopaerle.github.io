"""Verify raw sources are unchanged and no layer mixing was baked; compare native sustain renders.
Run after rebuild_strings_validate.py. Saves checks in each sound verification.json.
"""
from pathlib import Path
import hashlib,json,subprocess,numpy as np,soundfile as sf
from scipy.signal import correlate,correlation_lags
from libero import Audio,load
from libero.recipe import load_recipe
from libero.multisample import edit_region
ROOT=Path.home()/'Libero/banks/archi'
SRC=Path.home()/'Libero/cache/libraries/vsco2-ce/Strings'
RENDER=Path.home()/'.local/bin/libero-render'
def corr(a,b,lag_max=600):
 a=a.mean(1) if a.ndim==2 else a; b=b.mean(1) if b.ndim==2 else b
 n=min(len(a),len(b));a=a[:n];b=b[:n]
 c=correlate(a,b,method='fft');lags=correlation_lags(n,n);mask=np.abs(lags)<=lag_max
 lag=int(lags[mask][np.argmax(c[mask])])
 if lag>0:a=a[lag:];b=b[:-lag]
 elif lag<0:a=a[:lag];b=b[-lag:]
 return float(np.clip(np.dot(a,b)/np.sqrt(np.dot(a,a)*np.dot(b,b)),-1,1)),lag
for slug,source in [('violini','Violin Section'),('viole','Viola Section')]:
 folder=ROOT/slug;b=folder/'build';spec=load_recipe(folder).multisamples['body']
 mp=json.loads((folder/'samples/map-natural.json').read_text())['body'];m=json.loads((b/'manifest.json').read_text())
 by={(r['articulation'],r['root'],tuple(r['dyn']),r['take']):r for r in mp}
 unchanged=[]
 for f in (folder/'samples/raw-vsco').rglob('*.wav'):
  original=SRC/source/f.parent.name/f.name
  unchanged.append(hashlib.sha256(f.read_bytes()).digest()==hashlib.sha256(original.read_bytes()).digest())
 checks=[]
 sus=sorted([z for z in m['zones'] if z['articulation']=='sus' and z['dyn'][0]==.5],key=lambda z:z['root'])
 for z in [sus[0],sus[len(sus)//2],sus[-1]]:
  r=by[(z['articulation'],z['root'],tuple(z['dyn']),z.get('take',0))]
  reg=next(t for t in spec.regions if t.file==r['file'])
  edited,_=edit_region(load(folder/'samples'/r['file']),reg,spec.process,48000)
  compiled=load(b/z['file'])
  rawcorr,lag=corr(compiled.data[9600:67200],edited.data[9600:67200])
  out=b/f'compare-sus-n{z["root"]:03d}.wav'
  subprocess.run([str(RENDER),'--sound',str(folder),'--out',str(out),'--notes',f'12:0:0.01:100,{z["root"]}:0.1:2.5:110','--params',json.dumps({'rev_mix':0,'vel_sens':0}),'--tail','0.2'],check=True,capture_output=True)
  x,sr=sf.read(out,always_2d=True)
  expected=compiled.pitch(z.get('tune_cents',0)/100)
  nativecorr,nlag=corr(x[14400:67200],expected.data[9600:62400],lag_max=100)
  checks.append({'root':z['root'],'source':r['file'],'compiled_vs_edited_raw_correlation':rawcorr,'compiled_vs_raw_alignment_samples':lag,'native_vs_pitch_corrected_zone_correlation':nativecorr,'native_alignment_samples':nlag})
 qa=json.loads((folder/'verification.json').read_text());qa['raw_originals_sha256_match']={'matched':sum(unchanged),'total':len(unchanged)};qa['source_identity_checks']=checks
 x,sr=sf.read(b/'preview-dry.wav',always_2d=True)
 qa['held_sustain_rms_db_seconds_10_to_19']=float(20*np.log10(np.sqrt(np.mean(x[10*sr:19*sr]**2))+1e-20))
 events=[]
 for key,t,dur in [(12,0,2),(14,3,0.2),(15,4.5,0.2),(16,6,2)]:
  events.append(f'{key}:{t}:0.01:100')
  events.extend(f'{n}:{t+0.1}:{dur}:120' for n in (60,64,67,72))
 subprocess.run([str(RENDER),'--sound',str(folder),'--out',str(b/'preview-chords.wav'),'--notes',','.join(events),'--tail','1.5'],check=True,capture_output=True)
 x,sr=sf.read(b/'preview-chords.wav',always_2d=True)
 qa['default_chord_headroom']={'peak_db':float(20*np.log10(np.max(np.abs(x))+1e-20)),'clipped_samples':int(np.sum(np.abs(x)>=1)),'voices_simultaneous':4}
 from libero import analysis
 (b/'preview-chords.png').write_bytes(analysis.spectrogram(Audio(x,sr),title=f'{slug} · quattro voci · tutte le articolazioni'))
 from libero.lint import lint_bundle
 findings=lint_bundle(b)
 qa['lint']={'fail':sum(f.level=='FAIL' for f in findings),'warn':sum(f.level=='WARN' for f in findings),'warn_categories':sorted({f.check for f in findings if f.level=='WARN'})}
 qa['subjective_listening']='Not possible; numerical checks and spectrograms inspected'
 (folder/'verification.json').write_text(json.dumps(qa,indent=2)+'\n')
 with (folder/'notes.md').open('a') as p:
  p.write('\n## Identità del materiale e confronto con renderer\n\n')
  p.write(f'SHA-256 di {sum(unchanged)}/{len(unchanged)} WAV originali identici alla cache sorgente. Tre sostenuti (basso, medio, alto) confrontati con il RAW dopo soli taglio/fade/DC/resampling; correlazione e lag misurati sotto. Il secondo confronto usa il renderer nativo e la zona singola corretta di intonazione. Non ho ascoltato: i test provano identità/continuità e non un giudizio percettivo.\n\n'+json.dumps(checks,indent=2)+'\n')
  p.write('Spettrogrammi dei preview ispezionati: arco sostenuto a 8.6–20.6s, ripetizioni e quattro articolazioni, nessun loop periodico aggiunto. Durante la verifica è stato trovato e corretto dal lavoro principale un difetto del renderer offline: finishLoadingOffline non inizializzava activeArt. Il renderer installato ora sceglie correttamente il sostenuto. I preview includono anche C0 esplicito.\n')
 print(slug,qa['raw_originals_sha256_match'],checks,'held RMS',qa['held_sustain_rms_db_seconds_10_to_19'],flush=True)
