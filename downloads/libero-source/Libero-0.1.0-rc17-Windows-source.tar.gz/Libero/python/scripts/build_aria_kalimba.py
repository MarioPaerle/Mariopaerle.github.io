#!/usr/bin/env python3
"""Build Aria's source-led, endlessly held FreePats kalimba.

The recorded plucks and all original round robins stay intact. A per-take modal
continuation, fitted only to that take, replaces the part of the natural decay
after the recorded strike and loops as long as the note is held.
"""
from __future__ import annotations

import json
import hashlib
import argparse
import shutil
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy import signal

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))

from libero import Audio, analysis
from libero.compiler import compile_sound
from libero.figure import rasterize, validate_svg
from libero.ingest import import_sfz
from libero.lint import lint_bundle
from libero.lint import _load

HOME = Path.home() / "Libero"
SOURCE_DIR = HOME / "cache/libraries/freepats-kalimba/Kalimba-SFZ-20190723"
SOURCE = SOURCE_DIR / "Kalimba-20190723.sfz"
SLUG = "kalimba-legno"
SKETCH = HOME / "sketches" / SLUG
DEST = HOME / "banks/aria" / SLUG
DEMO = HOME / "demo/aria-v4/kalimba-legno"
SR = 48_000
PERIOD = 6.0
KEEP_ATTACK = 0.25
TRANSITION_END = 0.72

FIGURE = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke-linecap="round" stroke-linejoin="round">
<title>Kalimba di Legno</title>
<desc>Le otto lamelle, dalla più lunga alla più corta, seguono le radici reali F3–C#5 (MIDI 53–73). La lamella dorata identifica E4: il suo modo dominante misurato è 337,2 Hz, insieme ai modi a 310,2 e 411,7 Hz. Gli anelli incidono questi tre modi; la parte dorata conserva il colpo iniziale di 250 ms prima della tenuta modale di sei secondi.</desc>
<g stroke="currentColor">
 <path d="M75 328 Q256 296 437 328 L425 399 Q256 429 87 399 Z" fill="#f3eee6" stroke-width="1.4"/>
 <path d="M88 344 Q256 314 424 344 M85 365 Q256 335 427 365 M87 388 Q256 358 425 388" stroke-width=".55"/>
 <path d="M96 323 Q98 245 119 234 L145 321 M140 316 Q141 258 162 250 L188 312 M184 311 Q185 270 207 263 L231 305 M228 304 Q230 226 252 216 L276 299 M272 299 Q274 238 296 230 L320 300 M316 300 Q318 258 340 250 L364 307 M360 307 Q362 278 384 270 L408 315 M404 315 Q406 294 427 286 L437 328" stroke-width="1.05"/>
 <path d="M98 321 Q120 329 143 321 M142 314 Q164 325 186 311 M186 309 Q208 319 229 304 M230 302 Q252 316 274 297 M274 297 Q296 313 318 298 M318 298 Q340 313 362 305 M362 305 Q384 319 406 313 M406 313 Q423 324 435 326" stroke-width=".65"/>
 <path d="M96 350 Q168 337 244 347 M105 355 Q176 342 244 352 M116 360 Q182 347 246 357 M129 365 Q190 352 248 362 M145 370 Q200 357 250 367 M163 375 Q212 362 252 372 M184 380 Q228 367 254 377 M277 377 Q319 364 368 371 M278 371 Q326 358 386 365 M279 365 Q333 352 401 359 M280 359 Q341 346 414 353" stroke-width=".36"/>
 <path d="M75 329 L57 318 M437 329 L455 318 M87 399 L69 411 M425 399 L443 411" stroke-width="1.2"/>
 <path d="M96 416 Q256 444 416 416 M114 425 Q256 449 398 425" stroke-width=".65"/>
</g>
<g stroke="#b8924f" stroke-width="1.45">
 <path d="M245 302 Q247 262 270 209"/>
 <circle cx="258" cy="236" r="4" fill="#b8924f"/>
</g>
<g stroke="currentColor" stroke-width=".55" stroke-opacity=".48">
 <path d="M248 202 Q258 190 270 202 M243 192 Q258 176 275 192 M238 182 Q258 162 280 182"/>
 <path d="M248 202 Q258 214 270 202 M243 192 Q258 211 275 192 M238 182 Q258 208 280 182"/>
</g>
</svg>'''


def continue_take(path: Path, root: int, out: Path) -> tuple[dict, dict]:
    """Retain the onset; replace the decay with a modal cycle fitted per take."""
    x, sr = sf.read(path, dtype="float64", always_2d=True)
    if sr != SR:
        raise RuntimeError(f"Unexpected sample rate {sr}: {path}")
    if x.shape[1] != 1:
        raise RuntimeError(f"Expected the source's mono recording: {path}")
    x = x[:, 0]
    # Only remove the tiny DC component; this does not phase-align or reshape the pluck.
    x = x - np.mean(x[-min(len(x), SR // 2):])
    begin, end = .055, min(.48, len(x) / SR - .10)
    seg = x[int(begin * SR):int(end * SR)]
    if len(seg) < SR // 5:
        raise RuntimeError(f"Recording too short for modal fit: {path}")
    win = np.hanning(len(seg))
    nfft = 262144
    X = np.fft.rfft(seg * win, n=nfft)
    power = np.abs(X) ** 2
    freq = np.fft.rfftfreq(nfft, 1 / SR)
    tail = x[-min(len(x), int(.28 * SR)):]
    nw = np.hanning(len(tail))
    NX = np.fft.rfft(tail * nw, n=nfft)
    floor = np.abs(NX) ** 2 * (win.sum() / max(nw.sum(), 1e-12)) ** 2
    peaks, _ = signal.find_peaks(power, distance=max(1, int(1.0 / (SR / nfft))))
    peaks = peaks[(freq[peaks] > 35) & (freq[peaks] < 15_500)]
    peaks = peaks[(power[peaks] > power.max() * 10 ** (-48 / 10)) & (power[peaks] > floor[peaks] * 12)]
    peaks = peaks[np.argsort(power[peaks])[-256:]]
    if len(peaks) < 3:
        raise RuntimeError(f"Only {len(peaks)} source modes passed the noise floor: {path.name}")

    n = int(PERIOD * SR)
    spec = np.zeros(n // 2 + 1, dtype=np.complex128)
    modes = []
    for k in peaks:
        if k < 1 or k + 1 >= len(power):
            continue
        logs = np.log(np.maximum(power[k - 1:k + 2], 1e-30))
        denom = logs[0] - 2 * logs[1] + logs[2]
        frac = np.clip(.5 * (logs[0] - logs[2]) / denom if abs(denom) > 1e-20 else 0, -.5, .5)
        hz = (k + frac) * SR / nfft
        dest = int(round(hz * PERIOD))
        if not 0 < dest < n // 2:
            continue
        c = (X[k] * (1 - abs(frac)) + X[k + (1 if frac >= 0 else -1)] * abs(frac)) * 2 / win.sum()
        c *= np.exp(-2j * np.pi * hz * begin)
        spec[dest] += n * c / 2
        modes.append({"measured_hz": round(float(hz), 4), "cycle_hz": round(dest / PERIOD, 4),
                      "level_db": round(float(20 * np.log10(abs(c) / np.sqrt(2) + 1e-20)), 2)})
    if len(modes) < 3:
        raise RuntimeError(f"Modal fit collapsed for {path.name}")
    cycle = np.fft.irfft(spec, n=n)
    # A slowly varying common envelope retains a little of the source's beating;
    # it does not add noise or move the fitted mode frequencies.
    ef = np.fft.rfftfreq(n, 1 / SR)
    energy = np.fft.irfft(np.fft.rfft(cycle * cycle) * np.exp(-2 * np.pi**2 * .08**2 * ef**2), n=n)
    env = np.sqrt(np.maximum(energy, 1e-20))
    natural = float(np.sqrt(np.mean(x[int(.12 * SR):int(.30 * SR)] ** 2)))
    peak = float(np.max(np.abs(x[:int(.10 * SR)])))
    target = max(natural * 10 ** (-2 / 20), peak * 10 ** (-18 / 20))
    cycle *= target / max(float(np.sqrt(np.mean(cycle * cycle))), 1e-15)

    join_end = int(TRANSITION_END * SR)
    join_start = int(KEEP_ATTACK * SR)
    before = x[:join_end].copy()
    # End the source-to-hold transition at the cycle wrap, so its last 20 ms
    # are the exact preceding context for the loop's first 20 ms.
    held = cycle[-(join_end - join_start):]
    blend = np.linspace(0, 1, join_end - join_start)
    blend = blend * blend * (3 - 2 * blend)
    before[join_start:] = before[join_start:] * (1 - blend) + held[:join_end - join_start] * blend
    # Keep a quiet pre-roll; the engine's onset detector can trim it without cutting the pluck.
    pre = np.zeros(int(.012 * SR))
    y = np.concatenate([pre, before, cycle])
    loop_start = len(pre) + join_end
    loop_end = loop_start + n
    out.parent.mkdir(parents=True, exist_ok=True)
    sf.write(out, y, SR, subtype="PCM_24")
    seam = 10 * np.log10(np.sum((y[loop_start - 960:loop_start] - y[loop_end - 960:loop_end]) ** 2) /
                         (np.sum(y[loop_start - 960:loop_start] ** 2) + np.sum(y[loop_end - 960:loop_end] ** 2) + 1e-30) + 1e-30)
    audit = {
        "source": str(path), "source_seconds": round(len(x) / SR, 4), "source_peak_dbfs": round(20 * np.log10(peak + 1e-20), 2),
        "root": root, "measured_modes": len(modes), "mode_list": sorted(modes, key=lambda m: m["measured_hz"]),
        "recorded_attack_preserved_seconds": KEEP_ATTACK, "transition_end_seconds": TRANSITION_END,
        "modal_cycle_seconds": PERIOD, "modal_cycle_seam_db_20ms": round(float(seam), 2),
        "continuation_rms_dbfs": round(20 * np.log10(target + 1e-20), 2),
        "continuation_vs_transient_db": round(20 * np.log10(target / max(peak, 1e-20)), 2),
        "source_channels": 1, "stereo_phase": "not applicable; source is mono",
    }
    return {"start": loop_start, "end": loop_end}, audit


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    if DEST.exists() or SKETCH.exists():
        raise FileExistsError(f"Refusing to replace {DEST if DEST.exists() else SKETCH}")
    imported = import_sfz(SLUG, SOURCE, family="mallet", title="Kalimba di Legno",
                          subtitle="FreePats · 8 radici · 45 take autentici",
                          layers=1, root_step=1, takes=100, budget_mb=5000,
                          quality="slow", releases=False,
                          credit={"id": "freepats-kalimba", "source": "FreePats Kalimba, 2019",
                                  "author": "Xavimart, Gonzalo, Roberto", "license": "CC0 1.0",
                                  "license_class": "cc0", "url": "https://freepats.zenvoid.org/Ethnic/kalimba.html"})
    if imported["body_regions"] != 45 or imported["roots"] != 8:
        raise RuntimeError(f"Incomplete SFZ import: {imported}")
    shutil.move(str(SKETCH), str(DEST))
    samples = DEST / "samples"
    original_dir = samples / "originals"
    continuation_dir = samples / "continuations"
    original_dir.mkdir(exist_ok=True)
    continuation_dir.mkdir(exist_ok=True)
    shutil.copy2(SOURCE, samples / "source.sfz")
    mapping_path = samples / "map.json"
    mapping = json.loads(mapping_path.read_text())
    audits = {}
    for index, row in enumerate(mapping["body"]):
        original = SOURCE_DIR / "samples" / Path(row["file"]).name
        original_copy = original_dir / original.name
        if not original_copy.exists():
            shutil.copy2(original, original_copy)
        continuation = continuation_dir / (original.stem + ".wav")
        lp, audit = continue_take(original, int(row["root"]), continuation)
        audit["source_sha256"] = hashlib.sha256(original.read_bytes()).hexdigest()
        audit["continuation_sha256"] = hashlib.sha256(continuation.read_bytes()).hexdigest()
        row["file"] = str(continuation.relative_to(samples))
        row["loop"] = lp
        row["pitched"] = True
        audits[original.name] = audit
    mapping_path.write_text(json.dumps(mapping, indent=2) + "\n")
    (samples / "source-proof.json").write_text(json.dumps(audits, indent=2) + "\n")
    (samples / "ATTRIBUTION.md").write_text(
        "FreePats Kalimba, recorded January 2019 by Xavimart (Javier), Gonzalo and Roberto, "
        "with two Zoom H1 recorders; processed by Roberto. Source: "
        "https://freepats.zenvoid.org/Ethnic/kalimba.html. CC0 1.0 public domain dedication: "
        "https://creativecommons.org/publicdomain/zero/1.0/. The original complete readme is "
        "preserved in source-readme.txt. All 45 original takes are retained under originals/. "
        "Each playable take keeps its original strike for 250 ms, then transitions to a six-second "
        "modal cycle fitted from that same recording; no added noise or generic oscillator layer.\n")
    shutil.copy2(SOURCE_DIR / "readme.txt", samples / "source-readme.txt")
    recipe = '''"""FreePats Kalimba: recorded plucks with declared source-derived modal sustain."""
import json
from pathlib import Path
from libero import Sound
MAP=json.loads((Path(__file__).parent/'samples'/'map.json').read_text())
sound=Sound(title='Kalimba di Legno', subtitle='FreePats · 8 radici · 45 take autentici', tags=['kalimba','plucked','sampled','cc0'], sample_rate=48000)
sound.multisample('body', MAP['body'], process={'tune':'source','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':0,'loop':'source','max_seconds':None,'end_db':-100,'fade_ms':8,'encoding':'flac24'})
sound.performance(dyn_crossfade=0,humanize={'cents':0,'ms':0,'db':0},rr_reset_ms=0,onset_ms=0,one_shot=False)
sound.defaults(mode='Poli',glide=0,voices=24,dyn_mode='Velocità',amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=1200,vel_sens=.55,master=-1,lvl_body=0,lvl_tail=-60,lvl_air=-60,tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix=.035,rev_decay=1.1,rev_size=.28,rev_damp=.6)
'''
    (DEST / "sound.py").write_text(recipe)
    (DEST / "figure.svg").write_text(FIGURE)
    bad = validate_svg(FIGURE)
    if bad:
        raise RuntimeError(f"Figure validation: {bad}")
    manifest = {
        "source": "https://freepats.zenvoid.org/Ethnic/kalimba.html", "license": "CC0 1.0",
        "regions": len(mapping["body"]), "source_takes": len(audits),
        "roots": sorted({int(r["root"]) for r in mapping["body"]}),
        "key_ranges": sorted({(int(r["lo"]), int(r["hi"])) for r in mapping["body"]}),
        "sfz_tuning_offsets_cents": sorted({float(r.get("tune_cents", 0)) for r in mapping["body"]}),
        "source_sample_count": len(list((SOURCE_DIR / "samples").glob("*.wav"))),
        "sfz_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "takes_by_root": {str(root): sorted({int(r.get("take", 0)) for r in mapping["body"] if int(r["root"]) == root})
                          for root in sorted({int(r["root"]) for r in mapping["body"]})},
        "modal_cycles_seconds": PERIOD, "audit_file": "samples/source-proof.json",
    }
    (DEST / "import-report.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (DEST / "notes.md").write_text(f'''# Kalimba di Legno

Aria v4 · pizzicato acustico · campionamento reale con continuazione modale dichiarata.

## Fonte e mappa

FreePats Kalimba: https://freepats.zenvoid.org/Ethnic/kalimba.html. La pagina FreePats consultata riporta la versione 2019-05-31, mentre la SFZ e il readme del pacchetto locale sono datati 2019-07-23; archivio il pacchetto effettivamente usato e i suoi hash. Il readme completo è conservato in `samples/source-readme.txt`: strumenti reali dalla raccolta Xavimart, registrati a gennaio 2019 da Xavimart (Javier), Gonzalo e Roberto con due Zoom H1; trattamento dei file a cura di Roberto. CC0 1.0: https://creativecommons.org/publicdomain/zero/1.0/. `samples/ATTRIBUTION.md` riporta i crediti e le modifiche.

La mappa SFZ importa 45 registrazioni in 8 gruppi di radici: MIDI {min(manifest['roots'])}–{max(manifest['roots'])}, tasti coperti MIDI 48–84. I round robin reali per radice sono {manifest['takes_by_root']}; non sono state create dinamiche, radici o take. Gli offset tune SFZ presenti restano associati alle loro registrazioni: {manifest['sfz_tuning_offsets_cents']} cent. Nessuna release separata è fornita dalla mappa. Tutti i 45 WAV originali sono conservati in `samples/originals/`; `source-proof.json` identifica ciascun originale e la sua continuazione.

## Attacco e tenuta

I primi 250 ms del singolo gesto registrato sono lasciati intatti; tra 250 e 720 ms si passa dolcemente a un ciclo di sei secondi ricostruito dai modi misurati su quella stessa nota e sullo stesso take. Frequenze non armoniche, ampiezze e fasi provengono dalla registrazione; il fondo tardo viene escluso. Il livello di tenuta è il maggiore fra l’RMS naturale tra 120 e 300 ms meno 2 dB e il picco del transiente meno 18 dB: la risonanza resta udibile senza superare il colpo iniziale. Il cycle loop ha confine periodico; non c’è hiss aggiunto, oscillatore pad, riverbero usato per allungare, drive, wow o flanger. La fonte è mono, quindi non esistono fasi stereo da conservare.

Il suono è infinito mentre il tasto resta premuto; note-off usa 1,2 s di rilascio. Questo è un sustain modale progettato e dichiarato dopo il gesto reale, non la coda naturale della kalimba. La conversione rimuove il minuscolo offset DC e modifica l’ultima parte del decadimento, rendendo periodica la continuazione. Una sola intensità registrata significa che velocity controlla il livello, non il timbro. La fonte copre MIDI 48–84, con estensione trasposta entro i gruppi SFZ; fuori da questi tasti il preset non promette copertura.

## Verifica tecnica

Il builder salva report e hash di sorgenti/derivati per ogni take. Il native QA usa la frase con soft/forte, ribattute, note ai due estremi, accordo e note tenute 60 s su tre radici; esamina output stereo/render mono, picchi e RMS a blocchi, lint, seam di loop e SVG. I tre WARN restano espliciti: F3 ha 11 cent tra alcuni take originali (modo dominante 172,85–174,01 Hz); su E4 il rilevatore f0 salta fra componenti inarmoniche, benché il modo dominante dei sette take sia 337,16–337,43 Hz; il livello registrato di D#4 supera il vicino di 3,2 dB. Anche l’onset del C5 varia di 2,9 ms fra gesti. Non ho normalizzato i take né riallineato i transienti: sono differenze documentate della fonte e trasformarle cancellerebbe il round robin. Nessun FAIL; il seam massimo è −51,65 dB. Le misure descrivono il segnale e non provano gusto, calore percepito, realismo o parità con librerie commerciali. Non posso dichiarare un ascolto umano del risultato.
''')
    result = compile_sound(DEST)
    print(result.text())
    if not result.ok:
        raise RuntimeError(result.text())
    findings = lint_bundle(DEST / "build")
    lint = "\n".join(f.line() for f in findings)
    (DEST / "lint.txt").write_text(lint + "\n")
    failures = [f.line() for f in findings if f.level == "FAIL"]
    if failures:
        raise RuntimeError("Lint FAIL: " + "; ".join(failures))
    native_qa()


def native_qa() -> None:
    import subprocess
    from libero import library
    import soundfile as sf
    DEMO.mkdir(parents=True, exist_ok=True)
    renderer = Path.home() / ".local/bin/libero-render"
    out = DEMO
    events = {
        "phrase": "48:0:.55:45,53:.65:.5:84,60:1.2:.8:118,64:2.1:.5:58,67:2.7:.8:110,72:3.7:.7:94,60:4.6:.25:95,60:4.95:.25:90,60:5.3:.25:100,53:5.8:.6:70,72:6.5:1.2:115",
        "chord": "48:0:4:110,60:0:4:100,67:0:4:90,72:0:4:82",
            "hold-low": "53:0:60:100", "hold-mid": "60:0:60:100", "hold-high": "73:0:60:100",
    }
    records = {}
    for name, notes in events.items():
        target = out / f"{name}.wav"
        subprocess.run([str(renderer), "--sound", str(DEST), "--out", str(target),
                        "--notes", notes, "--tail", "1.5"], check=True, capture_output=True)
        x, sr = sf.read(target, dtype="float64", always_2d=True)
        peak = float(np.max(np.abs(x)))
        mono = x.mean(axis=1)
        stats = {"seconds": round(len(x)/sr, 3), "peak_dbfs": round(20*np.log10(peak+1e-20),2),
                 "clipped_samples": int(np.sum(np.abs(x)>=1)),
                 "mono_energy_loss_db": round(float(10*np.log10(np.mean(mono**2)/(np.mean(x*x)+1e-20)+1e-20)),2)}
        if name.startswith("hold-"):
            held = x[int(10*sr):int(58*sr)]
            size = sr // 2
            blocks = held[:len(held)//size*size].reshape(-1,size,2)
            db = 20*np.log10(np.sqrt(np.mean(blocks**2,axis=(1,2)))+1e-20)
            stats.update({"hold_rms_500ms_min_dbfs": round(float(db.min()),2),
                          "hold_rms_500ms_max_dbfs": round(float(db.max()),2),
                          "hold_rms_500ms_span_db": round(float(np.ptp(db)),2)})
        records[name] = stats
        (out / f"{name}.png").write_bytes(analysis.spectrogram(Audio(x, sr), title=f"Kalimba di Legno · {name}"))
    # Native mono check is a second render with the same phrase, folded by the renderer.
    phrase = sf.read(out / "phrase.wav", dtype="float64", always_2d=True)[0]
    folded = phrase.mean(axis=1)
    sf.write(out / "phrase-mono.wav", folded, SR, subtype="PCM_24")
    m = json.loads((DEST / "build/manifest.json").read_text())
    zones = [z for z in m["zones"] if z["layer"] == "body"]
    seams = []
    for z in zones:
        data = _load(DEST / "build", z, False)
        seams.append(data.loop_seam_db)
    info = {"native_renderer": str(Path.home()/".local/bin/libero-render"), "renders": records,
            "body_zones": len(zones), "loop_seam_max_db": round(float(max(s for s in seams if s is not None)),2),
            "lint": [f.line() for f in lint_bundle(DEST / "build") if f.level in ("WARN","FAIL")],
            "figure_svg_validation": validate_svg(FIGURE), "source_channels": "mono",
            "mono_render_note": "phrase-mono.wav is a fold-down diagnostic; native renderer emits stereo."}
    (out / "qa.json").write_text(json.dumps(info, indent=2) + "\n")
    svg = FIGURE
    for theme, colour, background in (("light", "#2a2430", "#fffdf8"), ("dark", "#f3eee6", "#171717")):
        themed = svg.replace('color="#2a2430"', f'color="{colour}"')
        (out / f"figure-{theme}-512.png").write_bytes(rasterize(themed, 512, background))
        (out / f"figure-{theme}-96.png").write_bytes(rasterize(themed, 96, background))
    (out / "README.md").write_text("Native renderer QA: phrase with dynamics and repeats, four-note chord, and 60-second low/mid/high holds. Includes mono fold-down, spectra, peak/clipping, 500 ms hold-RMS ranges, lint, and processed loop seam report. These measurements do not establish listener preference.\n")
    (DEST / "notes.md").open("a").write("\n\n## Risultati QA\n\n" + json.dumps(info, indent=2) + "\n")
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--qa-only", action="store_true", help="rerun native renders and figure checks on the installed voice")
    args = parser.parse_args()
    if args.qa_only:
        native_qa()
    else:
        main()
