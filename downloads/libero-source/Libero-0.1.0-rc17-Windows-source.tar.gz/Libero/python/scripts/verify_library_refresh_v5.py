"""Read-only final integration: new collections and approved-source protection."""
from pathlib import Path
from collections import Counter
import hashlib, json, sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import library
OUT=Path.home()/'Libero/demo/library-refresh-v5';OUT.mkdir(parents=True,exist_ok=True)
NEW_ARIA={'marimba-radice','vibrafono-caldo','handchimes-aria','tubolari-risonanti','arpa-folk','salterio-arco','ocarina-terra','armonica-vissuta'}
OLD_ARIA={'piano-giocattolo','carillon-particolare','xilofono-vivo','piano-preparato','kalimba-legno','saw-rame'}
BLUE={'rhodes-stage77','wurli-ep200','pianet-t','organo-blues','positivo-rinascimento','unitra-b11','mantice-blue','vetro-blue','corde-blue','fosforo-tasti','indaco-ance','rame-notturno'}
CIELO={'donne-radura','donne-mezzo','uomini-cenere','uomini-pietra','coro-volta','ellen-ooh-aha','trillo-rito','coro-orizzonte'}
SNARE_KEYS={50,52,57}
DRUM_KEYS={'batteria-boombap':{54,56,58,65,66,67,69}|SNARE_KEYS,'batteria-hiphop-vera':{55}}
CHANGED={'pan-canne','violino-solo','violoncello-solo','violoncelli'}|set(DRUM_KEYS)
BASE=json.loads((OUT/'baseline-approved.json').read_text())
NEW_BASE=json.loads((OUT/'baseline-new-approved.json').read_text()) if (OUT/'baseline-new-approved.json').exists() else {}
# Proven keyboard repairs after the listener's approval; source recordings and
# gain calibration are preserved and independently audited, not timbre redesigns.
PITCH_REPAIRS={'wurli-ep200','pianet-t'}
rows=library.list_sounds(); records=[];errors=[];protected=[]
for row in rows:
    p=Path(row['path']);mp=p/'build/manifest.json';slug=row['slug']
    if not mp.exists():errors.append(slug+': missing manifest');continue
    m=json.loads(mp.read_text());z=m.get('zones',[])
    errors.extend(slug+': '+e for e in library.validate_bundle(p/'build'))
    fresh=m.get('source_hash')==library.source_hash(p)
    if slug in NEW_ARIA|BLUE|CHANGED and not fresh:errors.append(slug+': stale compiled source')
    params=m.get('params',{})
    if slug in DRUM_KEYS:
        backup=Path.home()/'Libero-backups/2026-10-03/drums-hats-kick-v5'/slug/'build'
        old=json.loads((backup/'manifest.json').read_text())
        untouched=lambda regions:Counter(hashlib.sha256((base/r['file']).read_bytes()).hexdigest()
            for r in regions if r['lo'] not in DRUM_KEYS[slug])
        base=p/'build';current=untouched(z)
        base=backup;original=untouched(old['zones'])
        if current!=original:errors.append(slug+': unrelated drum zones altered')
        else:protected.append(slug+': all unrelated drum zone bytes')
        metadata=lambda regions:[r for r in regions if r['lo'] not in DRUM_KEYS[slug]]
        if metadata(z)!=metadata(old['zones']):errors.append(slug+': unrelated drum zone mapping or gain altered')
        if params!=old.get('params',{}):errors.append(slug+': kit-wide defaults altered')
        snare_backup=Path.home()/'Libero-backups/2026-10-03/batteria-boombap-snare-before-v1/build'
        if slug=='batteria-boombap' and snare_backup.exists():
            old_snare=json.loads((snare_backup/'manifest.json').read_text())
            non_snare=lambda regions:[r for r in regions if r['lo'] not in SNARE_KEYS]
            if non_snare(z)!=non_snare(old_snare['zones']):errors.append(slug+': approved hats or non-snare metadata changed')
            for r in non_snare(z):
                if hashlib.sha256((p/'build'/r['file']).read_bytes()).digest()!=hashlib.sha256((snare_backup/r['file']).read_bytes()).digest():
                    errors.append(slug+': approved non-snare audio changed: '+r['file'])
    if slug in NEW_ARIA|BLUE|CIELO|OLD_ARIA:
        if any(params.get(k,0) for k in ['tape_wow','tape_flutter']):errors.append(slug+': unsolicited pitch modulation')
    if params.get('caldi_mode','Spento') not in ['Spento',0]:errors.append(slug+': optional chain enabled by default')
    if slug in NEW_ARIA|BLUE and slug!='rame-notturno':
        body=[r for r in z if r['layer']=='body']
        if not body or any(not r.get('loop') for r in body):errors.append(slug+': body cannot hold')
    if slug in ['violoncello-solo','violoncelli']:
        continuous={'sus','nonvib','molto','trillo_tono','trillo_semitono','trem'}
        body=[r for r in z if r['layer']=='body' and r.get('articulation') in continuous]
        if any(not r.get('loop') for r in body):errors.append(slug+': continuous articulation stops')
    if slug in BASE:
        current=Counter(hashlib.sha256((p/'build'/r['file']).read_bytes()).hexdigest() for r in z)
        original=Counter(BASE[slug]['files'].values())
        if slug not in CHANGED:
            if m['source_hash']!=BASE[slug]['source_hash'] or current!=original:
                errors.append(slug+': approved sound altered')
            else:protected.append(slug)
        elif slug=='violino-solo':
            if original-current:errors.append(slug+': original TinySOL zones changed')
            else:protected.append('violino-solo: all '+str(sum(original.values()))+' original zone bytes')
    if slug in NEW_BASE and slug not in PITCH_REPAIRS:
        current={r['file']:hashlib.sha256((p/'build'/r['file']).read_bytes()).hexdigest() for r in z}
        if m['source_hash']!=NEW_BASE[slug]['source_hash'] or current!=NEW_BASE[slug]['files']:
            errors.append(slug+': newly approved timbre altered')
        else:protected.append('approved-v5: '+slug)
    records.append({'slug':slug,'bank':row['bank'],'saved':row['saved'],'source_hash':m.get('source_hash'),
                    'source_fresh':fresh,'zones':len(z),'body_loops':sum(bool(r.get('loop')) for r in z if r['layer']=='body'),
                    'articulations':m.get('articulations',[])})
for bank,expected in [('aria',OLD_ARIA|NEW_ARIA),('blue',BLUE),('cielo',CIELO)]:
    actual={r['slug'] for r in rows if r['bank']==bank}
    if actual!=expected:errors.append(f'{bank}: missing {sorted(expected-actual)}, extra {sorted(actual-expected)}')
pan=[r for r in rows if r['slug']=='pan-canne']
if len(pan)!=1 or pan[0]['bank']!='flauti':errors.append('Pan is not uniquely filed in Flauti')
counts=Counter(r['slug'] for r in rows)
errors.extend('duplicate: '+s for s,n in counts.items() if n>1)
report={'active_count':len(rows),'saved_count':sum(r['saved'] for r in rows),
        'bank_counts':dict(Counter(r['bank'] for r in rows)), 'errors':errors,
        'protected':protected,'records':records,
        'approved_pitch_repairs':sorted(PITCH_REPAIRS),
        'limitations':'Technical playback, source integrity and held-loop checks do not certify taste, realism or inaudibility of repeating recorded gestures.'}
(OUT/'integration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['active_count','saved_count','bank_counts','errors','protected']},indent=2))
if errors:raise SystemExit(1)
