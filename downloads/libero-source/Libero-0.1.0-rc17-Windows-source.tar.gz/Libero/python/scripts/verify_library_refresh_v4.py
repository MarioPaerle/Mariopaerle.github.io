"""Read-only integration audit for the new source-led Aria and infinite Cielo."""
from pathlib import Path
import sys,json
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import library
OUT=Path.home()/'Libero/demo/library-refresh-v4';OUT.mkdir(parents=True,exist_ok=True)
ARIA={'piano-giocattolo','carillon-particolare','xilofono-vivo','piano-preparato','kalimba-legno','pan-canne','saw-rame'}
CIELO={'donne-radura','donne-mezzo','uomini-cenere','uomini-pietra','coro-volta','ellen-ooh-aha','trillo-rito','coro-orizzonte'}
RETIRED={'velluto-arco','fiato-fuso','plettro-ambra','legno-risonante','soffio-di-sax','plettro-vivo','pizzicato-seta','colpo-di-legno','jupiter-unisono','chiave-di-petali','voci-bianche-sillabe','basso-slap'}
rows=library.list_sounds();errors=[];records=[]
base=json.loads((Path.home()/'Libero/demo/library-refresh-v3/integration.json').read_text());baseline={r['slug']:r['source_hash'] for r in base['records']}
for r in rows:
 folder=Path(r['path']);mp=folder/'build/manifest.json'
 if not mp.exists():errors.append(f"{r['slug']}: missing manifest");continue
 m=json.loads(mp.read_text());z=m.get('zones',[])
 errors += [f"{r['slug']}: {e}" for e in library.validate_bundle(folder/'build')]
 if r['slug'] in RETIRED:errors.append(f"Rejected preset still active: {r['slug']}")
 if r['bank'] in {'aria','cielo','bassi'} and any(m.get('params',{}).get(k,0) for k in ('tape_wow','tape_flutter')):errors.append(f"Unsolicited tape modulation: {r['slug']}")
 if r['slug'] in ARIA|CIELO and r['slug']!='saw-rame':
  body=[s for s in z if s['layer']=='body']
  if not body or any(not s.get('loop') for s in body):errors.append(f"{r['slug']}: body cannot sustain continuously")
 if r['slug'] in ARIA|CIELO and m.get('source_hash')!=library.source_hash(folder):
  errors.append(f"{r['slug']}: compiled bundle differs from current sources")
 if r['slug'] in {'808-cavo','808-colpo','808-notte'}:
  if m.get('source_hash')!=baseline[r['slug']]:errors.append(f"Approved 808 changed: {r['slug']}")
 records.append({'slug':r['slug'],'bank':r['bank'],'saved':r['saved'],'path':r['path'],'zones':len(z),'body_loops':sum(bool(s.get('loop')) for s in z if s['layer']=='body'),'source_hash':m.get('source_hash')})
counts=Counter(r['slug'] for r in rows)
errors += [f'Duplicate slug: {s}' for s,n in counts.items() if n>1]
for bank,expected in [('aria',ARIA),('cielo',CIELO)]:
 actual={r['slug'] for r in rows if r['bank']==bank}
 if actual!=expected:errors.append(f'{bank}: missing {sorted(expected-actual)}, unexpected {sorted(actual-expected)}')
report={'scope':'Seven new Aria sources, eight continuous Cielo; preserve approved three 808.','active_count':len(rows),'saved_count':sum(r['saved'] for r in rows),'bank_counts':dict(Counter(r['bank'] for r in rows)),'structural_errors':errors,'records':records,'backups':{'rejected_aria':str(Path.home()/'Libero-backups/2026-10-03/aria-v3-rejected'),'approved_cielo_before_extension':str(Path.home()/'Libero-backups/2026-10-03/cielo-infinite-before')},'previous_source_gaps':['Dedicated realistic slap replacement and real child choir remain outside the active banks; no fake substitute added.'],'limitations':'Native playback and source audits do not establish taste, commercial-library parity, or perceptually invisible loop repetition.'}
(OUT/'integration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['active_count','saved_count','bank_counts','structural_errors']},indent=2))
if errors:raise SystemExit(1)
