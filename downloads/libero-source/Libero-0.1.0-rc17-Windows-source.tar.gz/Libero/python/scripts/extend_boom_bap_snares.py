#!/usr/bin/env python3
"""Rebuild only the three boom-bap snare zones from full DRSKit recordings.

The builder runs in an isolated temporary folder. Only MIDI 50/52/57 WAVs and
matching peak/loudness values are copied into ~/Libero; other instrument assets,
defaults and the shared normalizer remain untouched.
"""
from __future__ import annotations
import argparse, json, os, re, shutil, subprocess, tempfile
from pathlib import Path

RECIPES={
  'SN1 = dict(par=-21, exc=-11, cap=0.55, t60=0.40, thr=-30, ratio=4, atk=12, rel=60, makeup=4, drive=2.0, lp_soft=6500, lp_hard=12500, low=1.5, top=-1.5,':
  'SN1 = dict(par=-16, exc=-9, cap=0.95, t60=0.85, thr=-30, ratio=4, atk=12, rel=60, makeup=4, drive=2.3, lp_soft=6500, lp_hard=12500, low=1.5, top=-1.5,',
  'SN2 = dict(par=-14, exc=-14, cap=0.95, t60=0.75, thr=-30, ratio=4, atk=12, rel=60, makeup=4, drive=2.2, lp_soft=5500, lp_hard=10500, low=3.0, top=-4.0,':
  'SN2 = dict(par=-9, exc=-12, cap=1.35, t60=1.35, thr=-30, ratio=4, atk=12, rel=60, makeup=4, drive=2.5, lp_soft=5500, lp_hard=10500, low=3.5, top=-2.5,',
  'SN3 = dict(par=-19, exc=-12, cap=0.50, t60=0.34, thr=-30, ratio=4, atk=10, rel=60, makeup=4, drive=2.4, lp_soft=7000, lp_hard=12800, low=1.0, top=-1.0,':
  'SN3 = dict(par=-15, exc=-10, cap=0.85, t60=0.72, thr=-30, ratio=4, atk=10, rel=90, makeup=4, drive=2.7, lp_soft=7000, lp_hard=12800, low=1.0, top=-1.0,'
}
TARGETS={50,52,57}

def apply(bank_home:Path,repo:Path)->None:
    bank=bank_home/'banks/percussioni/batteria-boombap'; builder=bank/'build_kit.py'
    manifest_path=bank/'samples/kit_manifest.json'; current=json.loads(manifest_path.read_text())
    original_counts={k:sum(z['key']==k for z in current) for k in TARGETS}
    if original_counts!={50:40,52:32,57:20}:raise RuntimeError(f'Unexpected snare layer/take map: {original_counts}')
    source=builder.read_text()
    for old,new in RECIPES.items():
        if source.count(old)!=1:raise RuntimeError(f'Recipe anchor not unique: {old[:3]}')
        source=source.replace(old,new)
    with tempfile.TemporaryDirectory(prefix='libero-boombap-snare-') as td:
        work=Path(td); temp_builder=work/'build_kit.py'; temp_builder.write_text(source)
        env=os.environ.copy();env['PYTHONPATH']=str(repo/'python')+os.pathsep+env.get('PYTHONPATH','')
        subprocess.run([str(repo/'python/.venv/bin/python'),str(temp_builder)],cwd=work,env=env,check=True,stdout=subprocess.DEVNULL)
        rendered=json.loads((work/'samples/kit_manifest.json').read_text())
        selected=[z for z in rendered if z['key'] in TARGETS]
        if {k:sum(z['key']==k for z in selected) for k in TARGETS}!=original_counts:
            raise RuntimeError('Temporary snare map does not match current bank rows')
        by_file={z['file']:z for z in selected}
        for z in current:
            if z['key'] not in TARGETS:continue
            fresh=by_file[z['file']]
            shutil.copy2(work/'samples'/fresh['file'],bank/'samples'/z['file'])
            z['peak_db']=fresh['peak_db'];z['lufs400']=fresh['lufs400']
        manifest_path.write_text(json.dumps(current,indent=2,ensure_ascii=False)+'\n')
    print('Updated only snare keys 50/52/57 from full DRSKit source recordings:',original_counts)
    print('Compile batteria-boombap and compare non-snare build hashes with the pre-edit backup.')

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--home',type=Path,default=Path.home()/'Libero')
    ap.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[2])
    ap.add_argument('--apply',action='store_true')
    a=ap.parse_args()
    if not a.apply: print('Dry run: would extend recorded snare keys 50, 52 and 57 in isolated scratch.')
    else: apply(a.home.expanduser(),a.repo)
