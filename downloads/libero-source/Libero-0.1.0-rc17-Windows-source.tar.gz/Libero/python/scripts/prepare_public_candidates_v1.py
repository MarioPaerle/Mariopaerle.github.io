"""Prepare local, audited sample-data candidates; never publish or edit the personal library."""
from pathlib import Path
from collections import defaultdict
import argparse, datetime, hashlib, json, os, shutil, sys, zipfile
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import library, licenses
from verify_release_replacements_v1 import EXPECTED
HOME=Path.home()/'Libero';OUT=HOME/'demo/release-replacements-v1'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--include-replacements',action='store_true');args=ap.parse_args()
 old=json.loads((HOME/'demo/public-bundle-audit/report.json').read_text());new=json.loads((HOME/'demo/public-new-packs-audit/all-200-final-summary.json').read_text())
 selected={(r['bank'],r['slug']) for r in old['presets'] if r['status']=='allowed'}|{(r['bank'],r['slug']) for r in new['new_packs']['preset_index'] if r['classification']=='allowed'}
 assert len(selected)==33
 label='candidate-51' if args.include_replacements else 'candidate-33'
 version='0.2.0' if args.include_replacements else '0.1.0'
 if args.include_replacements:
  qa=json.loads((OUT/'integration.json').read_text());assert not qa['errors'] and qa['replacement_count']==18 and qa['original_preserved_count']==200
  rights=json.loads((OUT/'replacements-rights-audit.json').read_text())
  assert rights['scope']['frozen_and_audited']==18 and rights['scope']['pending']==0, 'Replacement rights audit is not frozen'
  authored={'808-cavo-libero','808-colpo-libero','808-notte-libero','trap-kit-libero','trap-kit-ita-libero','trap-kit-pro-libero'}
  for record in rights['records']:
   assert record['audit_state']=='frozen_snapshot' and record['source_hash_fresh'], record['slug']
   assert record['rights_classification']=='allowed' or (record['rights_classification']=='conditional' and record['slug'] in authored), (record['slug'],'unresolved source rights')
   assert library.source_hash(Path(record['path']))==record['source_hash'], (record['slug'],'changed since rights audit')
  selected|={(bank,s) for bank,ss in EXPECTED.items() for s in ss}
 current={(r['bank'],r['slug']):r for r in library.list_sounds()};assert selected<=current.keys()
 staging=OUT/(label+'-staging-home'); exports=OUT/label; exports.mkdir(parents=True,exist_ok=True)
 bybank=defaultdict(list)
 for key in sorted(selected):
  r=current[key];p=Path(r['path']); problems=library.validate_bundle(p/'build');assert not problems,(key,problems)
  cls=licenses.bundle_license(licenses.read_credits(p))[1];assert cls in licenses.SHIPPABLE,(key,cls)
  public_bank={'mie':'trap','prove':'chitarre'}.get(key[0],key[0])
  dest=staging/'banks'/public_bank/key[1];dest.mkdir(parents=True,exist_ok=True)
  files=[f for f in (p/'build').rglob('*') if f.is_file() and not f.name.startswith('.')]
  files += [p/f for f in library._PACK_FILES if (p/f).is_file()]
  for f in files:
   q=dest/f.relative_to(p);q.parent.mkdir(parents=True,exist_ok=True)
   if q.exists():
    assert sha(q)==sha(f),(key,q,'changed after earlier staging');continue
   if f.relative_to(p).parts[0]=='build':os.link(f,q)
   else:shutil.copyfile(f,q)
  bybank[public_bank].append({'slug':key[1],'title':r['title'],'source':str(p),'source_bank':key[0],'license_class':cls})
 stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();index=[]
 for bank,rows in bybank.items():
  b=staging/'banks'/bank; original=HOME/'banks'/bank/'bank.json'
  meta=json.loads(original.read_text()) if original.exists() else {'title':bank.title()}
  meta.update(format='libero.bank/1',slug=bank,version=version,created=stamp,updated=stamp,figure=None,subtitle='Public redistribution candidate',description='Local audited sample-data selection. No upload or software release approval.',author='Mario Prignano')
  (b/'bank.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False)+'\n')
 os.environ['LIBERO_HOME']=str(staging)
 for bank,rows in bybank.items():
  archive=library.bank_pack(bank,exports/f'{bank}-{version}.liberobank')
  with zipfile.ZipFile(archive) as z:
   assert z.testzip() is None
   members=z.namelist(); assert all(name.startswith(bank+'/') for name in members)
   assert not any('/samples/' in name and not name.endswith(('ATTRIBUTION.md','credits.json')) for name in members)
  index.append({'bank':bank,'presets':len(rows),'programmes':rows,'file':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'uncompressed_bytes':sum(f.stat().st_size for f in (staging/'banks'/bank).rglob('*') if f.is_file())})
 result={'prepared_utc':stamp,'status':'Local candidate; no publication or upload. Software licence/JUCE review separate.','preset_count':len(selected),'pack_count':len(index),'compressed_bytes':sum(r['bytes'] for r in index),'packs':index}
 (exports/'catalog.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 (exports/'SHA256SUMS').write_text(''.join(f"{r['sha256']}  {Path(r['file']).name}\n" for r in index))
 rows='\n'.join(f"| {r['bank']} | {r['presets']} | {r['bytes']/1e6:.1f} |" for r in index)
 (exports/'README.md').write_text(f"""# Libero — selezione pubblica candidata {version}

{len(selected)} suoni in {len(index)} archivi `.liberobank`; totale {result['compressed_bytes']/1e9:.3f} GB decimali compressi. Preparazione locale: nessun upload effettuato.

| Banca | Suoni | Archivio MB |
|---|---:|---:|
{rows}

Importare gli archivi con l'importazione banche di Libero. Questi sono estratti delle banche personali, non le banche complete. Per la prova usare una libreria vuota: l'importazione gestisce una banca con lo stesso identificativo come aggiornamento e potrebbe sostituirne il contenuto.

`catalog.json` elenca i suoni e le dimensioni; `SHA256SUMS` identifica i download. Ogni suono conserva crediti e attribuzioni: mantenerli anche redistribuendo i pacchetti. I dati runtime consentono la riproduzione; la ricompilazione delle ricette richiede i materiali sorgente separati.

Le note dei preset descrivono anche i materiali di produzione conservati nella libreria di lavoro. Mappe, registrazioni originali e file source-proof/design-proof non sono inclusi in questi archivi runtime. La selezione pubblica organizza lo stab orchestrale in Trap e la chitarra acustica in Chitarre; le cartelle personali restano al loro posto.

Il controllo delle licenze del plugin e degli obblighi JUCE è separato dai diritti sui campioni. I controlli di importazione sono in `import-verification.json`, generato dopo la prova effettiva.
""",encoding='utf-8')
 print(json.dumps({'candidate':label,'presets':len(selected),'pack_count':len(index),'compressed_GB':result['compressed_bytes']/1e9,'packs':[(r['bank'],r['bytes']/1e9) for r in index]},indent=2))
if __name__=='__main__':main()
