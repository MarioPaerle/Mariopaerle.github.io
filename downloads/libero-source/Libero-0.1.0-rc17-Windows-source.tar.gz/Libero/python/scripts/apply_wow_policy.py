#!/usr/bin/env python3
"""Apply the conservative live wow/flutter policy to the old installed Libero sounds.

This edits only recipe source, compiles with Libero's normal per-zone cache, validates
the resulting bundles, and writes before/after native-render measurements outside
the sound library. It is safe to re-run: it preserves the first full backup and the
final recipes are idempotent.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

PY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PY_ROOT))

from libero import analysis, library, render  # noqa: E402
from libero.compiler import compile_sound  # noqa: E402


TARGETS = {
    "coro-di-marmo": Path("sounds/coro-di-marmo"),
    "trap-hit": Path("sounds/trap-hit"),
    **{slug: Path("banks/trap") / slug for slug in (
        "trap-archi", "trap-bell", "trap-brass-stab", "trap-coro", "trap-flute",
        "trap-lead", "trap-marimba-scura", "trap-pad", "trap-piano", "trap-pluck",
        "trap-rhodes", "trap-sub-grit", "trap-vox",
    )},
}

# Representative native-engine phrases include the ensemble pad, a live synth lead,
# a struck sound, plus the two recipes whose offline tape chains are being neutralized.
PREVIEWS = {
    "coro-di-marmo": ("48:0:2.5:85,55:0:2.5:85,60:0:2.5:85,60:3:2.5:100", 4.0),
    "trap-lead": ("48:0:1:100,60:1.5:1:100,72:3:1:100", 2.5),
    "trap-bell": ("60:0:0.7:100,72:1:0.7:100", 2.5),
    "trap-coro": ("60:0:1.5:100", 3.0),
    "trap-rhodes": ("48:0:1:100,60:1.5:1:100,72:3:1:100", 2.5),
}

NOTE_IDENTITY = {
    "coro-di-marmo": "Designed singer vibrato, detuned voices, saturation, EQ, cisterna room and echo keep the choir moving and worn.",
    "trap-hit": "The recorded attack, dark EQ, light saturation, tape age and hall keep the stab weight and colour.",
    "trap-archi": "The section's own bow vibrato, dark EQ, tape age, vinyl air and Basilica room keep the orchestral colour.",
    "trap-bell": "The mallet decay, inharmonic ring, glass resonator, dark filter, tape age, echo and hall keep its carillon colour.",
    "trap-brass-stab": "The recorded trumpet attack, saturation, tape age, dark EQ, short echo and hall keep the stab's weight.",
    "trap-coro": "The choir recordings, baked tape age, dark EQ, vinyl air and Basilica hall keep its worn, wide character.",
    "trap-flute": "The recorded breath and dynamics, light saturation, dark filter, echo and hall keep the smoky flute colour.",
    "trap-lead": "The designed oscillator detune, late live LFO vibrato, filter envelope, tape saturation and echo keep the lead moving.",
    "trap-marimba-scura": "The recorded mallet attacks, velocity-opened low-pass, tape age, echo and plate keep the marimba dark and clear.",
    "trap-pad": "The wavetable and filter LFOs, oscillator spread, chorus, EQ, echo and hall provide its designed motion and width.",
    "trap-piano": "The recorded dynamics and attacks, dark EQ, tape age, vinyl air and hall keep the piano weight and worn colour.",
    "trap-pluck": "The designed pluck transient and falling sine, EQ, stereo width, echo and plate keep its drop-like identity.",
    "trap-rhodes": "The FM tine, hammer transient, chorus, dark EQ and tape age keep its electric-piano colour.",
    "trap-sub-grit": "Oscillator detune, drive, tape saturation and the filter snap provide the growl and bite.",
    "trap-vox": "The formant envelope, designed 11-cent live LFO vibrato, filter, echo and room keep its vocal-like motion.",
}

NOTE_REPLACEMENTS = {
    "coro-di-marmo": [("tape wobble and a stone cistern around it.", "gentle singer vibrato and detuned voices inside a stone cistern.")],
    "trap-hit": [("Defaults: dry-ish hall 2.6 s 24 %, drive .2, tape .2, Poli, glide 0.", "Defaults: dry-ish hall 2.6 s 24 %, drive .2, tape saturation .2, age .4, mix .5, wow/flutter 0, Poli, glide 0.")],
    "trap-archi": [("Live: tape 0.2/0.1/0.3/0.3 mix 0.5, Basilica", "Live: wow/flutter 0/0, tape sat 0.08, age 0.3, mix 0.4, Basilica")],
    "trap-bell": [("tape wow/flutter/age (vinyl-like)", "tape age and saturation")],
    "trap-coro": [("Live defaults: tape wow 0.22 / flutter 0.12 / sat 0.3 / age 0.3, mix 0.55;", "Live defaults: wow/flutter 0 / 0, tape sat 0.08 / age 0.3 / mix 0.4;")],
    "trap-marimba-scura": [("light tape (wow 0.12, flutter 0.05, age 0.25, mix 0.3)", "light tape age (0.25, mix 0.3; wow/flutter 0)")],
    "trap-pad": [("tape wow .3, width 1.2", "tape wow/flutter 0, width 1.2")],
    "trap-piano": [("wow and flutter live", "wow/flutter off by default"), ("Live: tape wow 0.28 / flutter 0.10 / sat 0.3 / age 0.3, mix 0.55;", "Live: wow/flutter 0 / 0, tape sat 0.08 / age 0.3 / mix 0.4;")],
    "trap-pluck": [("tape wow .25, drive .12", "tape wow/flutter 0, drive .12")],
    "trap-rhodes": [("a light tape pass (wow 0.12, flutter 0.05) that detunes every note slightly differently", "a light tape pass for age and tone (wow/flutter 0 by default)"), ("Defaults: Poli, glide 0, tape wow .35 / age .45,", "Defaults: Poli, glide 0, tape wow/flutter 0, age .45,")],
    "trap-vox": [("tape wow .25, master +4 dB", "tape wow/flutter 0, master +4 dB")],
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_first_backup(src: Path, dst: Path) -> None:
    if dst.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, dst, copy_function=shutil.copy2)


def patch_keyword(text: str, key: str) -> tuple[str, bool]:
    pattern = re.compile(rf"(\b{re.escape(key)}\s*=\s*)[^,\n)]+")
    text, count = pattern.subn(r"\g<1>0.0", text)
    if count > 1:
        raise RuntimeError(f"expected at most one {key} default, found {count}")
    return text, count == 1


def remove_recipe_wobble(slug: str, source: str) -> tuple[str, list[str]]:
    changes = []
    if slug == "trap-coro":
        source, n = re.subn(r"(st\.tape\(a,\s*wow=0(?:\.0)?,\s*flutter=)(?:0\.10|0(?:\.0)?)", r"\g<1>0.0", source)
        if n != 1:
            raise RuntimeError(f"expected one baked flutter value in {slug}, got {n}")
        changes.append("set baked tape flutter to zero; keep tape age, EQ and room")
    elif slug == "trap-rhodes":
        source, n1 = re.subn(r"(FX\.Tape\(wow=)(?:0\.12|0(?:\.0)?)", r"\g<1>0.0", source)
        source, n2 = re.subn(r"(FX\.Tape\(wow=0\.0,\s*flutter=)(?:0\.05|0(?:\.0)?)", r"\g<1>0.0", source)
        if n1 != 1 or n2 != 1:
            raise RuntimeError(f"expected one baked wow/flutter pair in {slug}, got {n1}/{n2}")
        changes.append("set baked Tape FX wow/flutter to zero; keep age, head bump and tone shaping")
    return source, changes


def native_preview(slug: str, notes: str, tail: float, stage: str, out_dir: Path) -> dict:
    pv = render.preview(slug, notes, tail=tail)
    out_dir.mkdir(parents=True, exist_ok=True)
    saved = out_dir / f"{slug}.wav"
    shutil.copy2(pv.wav, saved)
    ft = analysis.features(pv.audio)
    keys = ("duration_s", "sample_rate", "channels", "peak_db", "rms_db", "loudness_lufs",
            "clipped_samples", "dc_offset_db", "f0_hz", "f0_spread_cents", "f0_drift_cents")
    result = {key: ft[key] for key in keys if key in ft}
    result.update({"stage": stage, "notes": notes, "wav": str(saved), "headroom_db": round(-ft["peak_db"], 2)})
    if ft.get("clipped_samples", 0) != 0 or ft.get("peak_db", 0.0) >= 0.0:
        raise RuntimeError(f"native preview for {slug} clipped or has no peak headroom: {result}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--home", type=Path, default=Path.home() / "Libero")
    parser.add_argument("--backup-root", type=Path, default=Path.home() / "Libero-backups/2026-10-02/wow-policy")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    home = args.home.expanduser().resolve()
    backup_root = args.backup_root.expanduser().resolve()
    report_path = args.report.expanduser().resolve() if args.report else backup_root / "report.json"
    os.environ["LIBERO_HOME"] = str(home)

    backup_paths = {}
    for slug, rel in TARGETS.items():
        src = home / rel
        if not (src / "sound.py").is_file():
            raise RuntimeError(f"missing recipe: {src / 'sound.py'}")
        dst = backup_root / "before" / rel
        copy_first_backup(src, dst)
        backup_paths[slug] = str(dst)

    # Keep a full copy of the in-repository example as well; it will be edited below.
    repo_example = PY_ROOT.parent / "sounds" / "coro-di-marmo"
    copy_first_backup(repo_example, backup_root / "before/repo/sounds/coro-di-marmo")

    report = {
        "policy": "ordinary defaults set tape_wow and tape_flutter to 0; explicit tape transfer remains opt-in",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "library_home": str(home),
        "backup_root": str(backup_root),
        "backups": backup_paths,
        "before": {},
        "after": {},
        "recipes": {},
        "bundles": {},
        "native_preview_checks": {},
        "note_updates": {},
    }

    # Save baseline native previews once; repeat runs retain the original comparison.
    old_report = json.loads(report_path.read_text()) if report_path.is_file() else {}
    existing_before = old_report.get("before", {})
    if all(slug in existing_before for slug in PREVIEWS):
        report["before"] = existing_before
    else:
        for slug, (notes, tail) in PREVIEWS.items():
            report["before"][slug] = native_preview(slug, notes, tail, "before", backup_root / "previews/before")

    for slug, rel in TARGETS.items():
        recipe = home / rel / "sound.py"
        old = recipe.read_text()
        before_hash = hashlib.sha256(old.encode()).hexdigest()
        source, baked_changes = remove_recipe_wobble(slug, old)
        live = set_live_wow_flutter_text(slug, source)
        recipe.write_text(live)
        report["recipes"][slug] = {
            "path": str(recipe),
            "before_sha256": before_hash,
            "after_sha256": sha256(recipe),
            "baked_changes": baked_changes,
        }

        note_path = home / rel / "notes.md"
        note = note_path.read_text() if note_path.is_file() else ""
        for old_text, new_text in NOTE_REPLACEMENTS.get(slug, []):
            note = note.replace(old_text, new_text)
        policy_section = ("\n\n## Wow/flutter defaults\n\nBoth live controls start at 0. "
                          + NOTE_IDENTITY[slug]
                          + " Enable pitch drift only for a deliberate tape/vintage reference; check it at the chosen tape mix because modulation can sound flanged against the direct signal.\n")
        if "## Wow/flutter defaults" not in note:
            note += policy_section
        note_path.write_text(note)
        report["note_updates"][slug] = str(note_path)

    # Mirror the ordinary acoustic/design example in the source repository.
    source_path = repo_example / "sound.py"
    source = source_path.read_text()
    source, has_wow = patch_keyword(source, "tape_wow"); source, has_flutter = patch_keyword(source, "tape_flutter")
    if not has_wow or not has_flutter:
        raise RuntimeError("repository coro-di-marmo example must declare both tape parameters")
    source_path.write_text(source)
    notes = repo_example / "notes.md"
    note_text = notes.read_text()
    note_text = note_text.replace("Tape: wow 0.35, flutter 0.1, age 0.45, mix 0.7.",
                                  "Tape wow/flutter default to 0. The choir keeps its designed singer vibrato, detuned voices, saturation, EQ, cisterna room and echo; tape drift is an optional live choice.")
    notes.write_text(note_text)

    for slug in TARGETS:
        folder = home / TARGETS[slug]
        compiled = compile_sound(folder, use_cache=True)
        if not compiled.ok:
            raise RuntimeError(f"compile failed for {slug}: {compiled.text()}")
        manifest = json.loads((folder / "build/manifest.json").read_text())
        params = manifest.get("params", {})
        values = {key: params.get(key) for key in ("tape_wow", "tape_flutter")}
        if values != {"tape_wow": 0.0, "tape_flutter": 0.0}:
            raise RuntimeError(f"compiled parameter invariant failed for {slug}: {values}")
        problems = library.validate_bundle(folder / "build")
        report["bundles"][slug] = {"compiled": True, "params": values, "validation_errors": problems}
        if problems:
            raise RuntimeError(f"bundle validation failed for {slug}: {problems}")

    for slug, (notes, tail) in PREVIEWS.items():
        report["after"][slug] = native_preview(slug, notes, tail, "after", backup_root / "previews/after")
        old_peak = report["before"][slug]["peak_db"]
        new_peak = report["after"][slug]["peak_db"]
        report["native_preview_checks"][slug] = {
            "peak_delta_db": round(new_peak - old_peak, 2),
            "headroom_before_db": report["before"][slug]["headroom_db"],
            "headroom_after_db": report["after"][slug]["headroom_db"],
            "clipped_before": report["before"][slug].get("clipped_samples", 0),
            "clipped_after": report["after"][slug].get("clipped_samples", 0),
        }

    report["created_at_utc"] = datetime.now(timezone.utc).isoformat()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"report": str(report_path), "sounds": len(TARGETS),
                      "previews": len(PREVIEWS), "bundle_invariant": "tape_wow=0, tape_flutter=0"}, indent=2))
    return 0


def set_live_wow_flutter_text(slug: str, source: str) -> str:
    source, has_wow = patch_keyword(source, "tape_wow")
    if not has_wow:
        raise RuntimeError(f"{slug} has no explicit tape_wow default")
    source, has_flutter = patch_keyword(source, "tape_flutter")
    if not has_flutter:
        source, n = re.subn(r"(\btape_wow\s*=\s*0\.0\s*,)", r"\1 tape_flutter=0.0,", source, count=1)
        if n != 1:
            raise RuntimeError(f"could not add explicit tape_flutter default for {slug}")
    return source


if __name__ == "__main__":
    raise SystemExit(main())
