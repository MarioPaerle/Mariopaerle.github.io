"""Actual recorded pan pipes, preserved breath and genuine single-take mapping."""
from pathlib import Path
import sys,json,shutil,re,math
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import Audio,analysis,render,dsp
from libero.compiler import compile_sound
from libero.lint import lint_bundle
DEST=Path.home()/'Libero/banks/flauti/pan-canne'; S=DEST/'samples';S.mkdir(parents=True,exist_ok=True)
OUT=Path.home()/'Libero/demo/library-refresh-v5/pan-canne';OUT.mkdir(parents=True,exist_ok=True)
SOURCE=Path.home()/'Libero/cache/research/pan-flute-real/raw/wav'
rows=[];regions=[]
for p in sorted(SOURCE.glob('*.wav')):
 note=re.search(r'Flute ([A-G]\d)',p.name).group(1);root=dsp.parse_note(note)
 a=Audio.load(p);f=analysis.features(a); hz=f['f0_hz']; cents=1200*math.log2(hz/(440*2**((root-69)/12)))
 originals=DEST/'originals';originals.mkdir(exist_ok=True);shutil.copy2(p,originals/p.name)
 a=a.resample(48000)
 # Some original stereo pairs strongly cancel in mono. Use one actual recorded
 # channel, chosen by energy, rather than introduce phase correction or widening.
 if a.data.ndim==2:
  channel=int(np.argmax(np.mean(a.data.astype(float)**2,axis=0)))
  a=Audio(a.data[:,channel],a.sr)
 t,e=dsp.rms_envelope(dsp.mono(a.data),a.sr,.08)
 good=np.flatnonzero(e>e.max()*10**(-6/20))
 # Retain more of the actual pressure/embouchure/air motion rather than only
 # the flattest loud body. Exclude the final dying breath, not human variation.
 left=max(float(t[good[0]])+.10,a.onset()+.3);right=float(t[good[-1]])-.10
 lp=a.loop_points(min_seconds=(right-left)*.78,region=(left,right),max_crossfade=.06)
 if lp is None:raise RuntimeError(f'No valid real sustain for {p.name}')
 a=a.bake_loop(lp);a.save(S/p.name)
 loop={'start':lp.start,'end':lp.end}
 # One performance per real pipe. Retain the breath gesture and varying spectrum.
 regions.append(dict(file=p.name,root=root,tune_cents=-cents,loop=loop,gain_db=max(-6,min(6,-30-f['rms_db'])),one_shot=False,lo=0 if root==55 else None,hi=127 if root==83 else None))
 rows.append(dict(file=p.name,root=root,measured_hz=hz,static_correction_cents=-cents,loop=loop,loop_error_db=lp.error_db,source=f))
(S/'credits.json').write_text(json.dumps([dict(source='WIP Raw Pan Flute Audio',author='pattingthestar',license='CC0',license_class='cc0',url='https://opengameart.org/content/wip-raw-pan-flute-audio',files=[p.name for p in SOURCE.glob('*.wav')])],indent=2))
(DEST/'sound.py').write_text('''from libero import Sound
sound=Sound(title="Pan · Canne",subtitle="dieci canne vere · soffio mosso e legno",tags=["flute","pan-flute","recorded","breath","infinite"],roots=[55,59,62,64,67,71,74,76,79,83],seed=1913)
regions='''+repr(regions)+'''
sound.multisample('body',regions,process={'tune':'source','ladder':'smooth','ladder_max_db':6,'peak_db':-9,'pre_ms':10,'align_ms':0,'loop':'source','loop_min_s':2.5,'max_seconds':None,'end_db':-65,'edge_fill':False,'encoding':'flac24'})
sound.defaults(mode='Poli',glide=0,voices=12,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=180,lvl_body=0,lvl_air=-60,lvl_attack=-60,lvl_tail=-60,vel_sens=.45,master=-2,osc1_level=-60,osc2_level=-60,sub_level=-60,drive=0,tape_mix=0,tape_wow=0,tape_flutter=0,echo_mix=0,rev_mix=.035,rev_decay=1.1,rev_damp=.4)
''')
(DEST/'notes.md').write_text('''# Pan · Canne

Real one-row pan flute recorded by pattingthestar, CC0: https://opengameart.org/content/wip-raw-pan-flute-audio . All ten distinct original WAV recordings retained; accompanying FLAC copies are duplicates, not extra takes. This amateur instrument is originally untuned; only the average tuning is corrected, preserving breath, pitch gestures and source texture. Playback uses the stronger original recorded channel per pipe: several original stereo pairs cancel strongly in mono. All original stereo WAV files remain untouched in originals/. One take and one dynamic per pipe: no invented round robins, no synthetic air bed, no claim of studio multisample realism.

Original attacks lead into loops selected within the stable blown portion of the same sustained performance, with short baked transitions; original files remain in originals/. The held note continues until MIDI note-off; an acoustic player cannot literally sustain without breathing. Recorded range G3–B5 with interpolation between pipes; outside that range the nearest recording is transposed. Single-take gain calibration uses at most 6 dB per source to reduce recording-level jumps. Loudness smoothing is limited to 6 dB; room is minimal and adjustable. The source author reports B3 is poorer than the other recordings. Inspect native audio before judging its suitability; lint does not establish warmth or realism.

Revision 5 follows user feedback: moved to Flauti. Longer source loops retain pressure, airy embouchure and timbral variation up to 6dB below the body's peak instead of selecting only the flattest 3dB range. No added hiss, pitch LFO, dirt effect or wow; all ongoing motion comes from the original blown performance. The final breath collapse is still excluded. Approved revision 4 is backed up in ~/Libero-backups/2026-10-03/pan-canne-approved-v4.
''')
(DEST/'figure.svg').write_text('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" stroke="currentColor" fill="none" stroke-linecap="round"><title>Pan · Canne</title><desc>Dieci canne di altezze diverse, legate con corda.</desc><g stroke-width="1.3">'''+''.join(f'<path d="M{125+i*26} 164v{210-i*12}q10 12 20 0V164Z" fill="#f3eee6"/>' for i in range(10))+'''</g><path d="M121 204Q256 223 383 203M121 209Q256 228 383 208" stroke="#b8924f" stroke-width="1.2"/><g stroke-width=".45">'''+''.join(f'<path d="M{130+i*26} 180v{170-i*12}"/>' for i in range(10))+'''</g></svg>''')
c=compile_sound(DEST)
if not c.ok:raise RuntimeError(c.text())
findings=[f.line() for f in lint_bundle(DEST/'build')]; native={}
for name,notes,tail in [('phrase','55:0:.7:85,62:1:.55:75,64:1.8:.8:100,67:3:1:90,71:4.3:1.4:110,76:6.1:1.8:95',1),('held60','67:0:60:100',1),('registers','55:0:1:100,59:1.5:1:100,64:3:1:100,71:4.5:1:100,79:6:1:100,83:7.5:1:100',1)]:
 pv=render.preview('pan-canne',notes,tail=tail);shutil.copy2(pv.wav,OUT/(name+'.wav'));native[name]=analysis.features(pv.audio);print(name,native[name]['peak_db'],flush=True)
(OUT/'verification.json').write_text(json.dumps(dict(sources=rows,compile=c.warnings,lint=findings,native=native),indent=2))
