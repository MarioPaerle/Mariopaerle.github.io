"""RMS-matched listening comparison: the saved Green v1, then richer v2."""
from pathlib import Path
import sys,json,numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import render,Audio
OUT=Path.home()/'Libero/demo/library-expansion-v6';OLD=Path.home()/'Libero-backups/2026-10-03/green-before-rich-v2/bank';NEW=Path.home()/'Libero/banks/green'
voices=['cedro-lead','miele-pulse','giada-fase','ambra-fm','canneto-elettrico','aurora-vetro'];tracks=[];rows=[];cursor=0
notes=[(60,0,.30,55),(60,.55,.35,110),(63,1.15,.6,95),(67,2,.6,100),(60,2.9,3.2,100)]
for slug in voices:
 for label,bank in [('prima',OLD),('arricchito',NEW)]:
  p=bank/slug;m=json.loads((p/'build/manifest.json').read_text());f=OUT/(slug+'-'+label+'-AB-native.wav');render.render(p,f,notes,tail=1.4);a=Audio.load(f);x=a.data.astype(float);x=np.column_stack([x,x])if x.ndim==1 else x
  gain=min(9,max(-9,-25-a.rms_db));gain=min(gain,-3-a.peak_db);x*=10**(gain/20)
  rows.append({'slug':slug,'title':m['title'],'version':label,'start_s':cursor,'native_rms_db':a.rms_db,'gain_db':gain,'export_rms_db':a.rms_db+gain})
  tracks.extend([x,np.zeros((16800,2))]);cursor+=len(x)/a.sr+.35
Audio(np.concatenate(tracks),48000).save(OUT/'green-prima-arricchito.wav');(OUT/'green-prima-arricchito-index.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n');print('Green A/B',round(cursor,1),flush=True)
