"""Short native audition in real source registers, gain matching only on demos."""
from pathlib import Path
import sys,json,numpy as np,shutil
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import render,Audio,analysis
OUT=Path.home()/'Libero/demo/aria-v4';OUT.mkdir(parents=True,exist_ok=True)
PALETTE=[('piano-giocattolo',64),('carillon-particolare',77),('xilofono-vivo',72),('piano-preparato',60),('kalimba-legno',60),('pan-canne',67),('saw-rame',60)]
tracks=[];rows=[];cursor=0
for slug,root in PALETTE:
 notes=[(root,0,.22,76),(root,.4,.2,110),(root+7,.9,.45,95),(root+3,1.55,.7,92),(root+2,2.4,.45,72),(root,3.1,3.2,95)]
 pv=render.preview(slug,notes,tail=1.8);a=pv.audio
 f=analysis.features(a);gain=min(6,max(-6,-23-f['rms_db']));gain=min(gain,-3-a.peak_db)
 x=a.data.astype(np.float64)*10**(gain/20)
 if x.ndim==1:x=np.column_stack([x,x])
 Audio(x,a.sr).save(OUT/(slug+'-audition.wav'))
 rows.append({'slug':slug,'root':root,'start_s':round(cursor,3),'end_s':round(cursor+len(x)/a.sr,3),'demo_gain_db':round(gain,2),'native_peak_db':a.peak_db,'notes':notes});print(slug,gain,flush=True)
 tracks.extend([x,np.zeros((int(.35*a.sr),2))]);cursor+=(len(x)/a.sr+.35)
Audio(np.concatenate(tracks),a.sr).save(OUT/'aria-sette-voci.wav')
(OUT/'audition-index.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'ASCOLTO.md').write_text('# Aria — sette voci\n\n'+ '\n'.join(f"- {r['start_s']:05.1f}s — {r['slug']}, base MIDI{r['root']}; due ribattute, frase e nota tenuta3.2s." for r in rows)+'\n\nRenderer nativo. Solo il gain della demo è confrontato; preset, sorgente e timbro restano invariati. Carillon e xilofono suonano nei loro registri registrati, più alti delle altre voci. Le verifiche lunghe della tenuta sono separate.\n')
