"""Native Quick Look raster QA at 512/96px, both application themes."""
from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw
from libero.figure import validate_svg
from build_cielo_v2 import BASE,STAGE,draw
OUT=BASE/'reports/figure-qa';OUT.mkdir(parents=True,exist_ok=True)
cover=BASE/'cover';cover.mkdir(exist_ok=True);(cover/'figure.svg').write_text(draw('volta','Cielo'))
folders=[cover]+sorted(p for p in STAGE.iterdir() if (p/'sound.py').exists())+[Path.home()/'Libero/banks/cielo/voci-bianche-sillabe']
svgs=[];checks={}
for folder in folders:
    original=(folder/'figure.svg').read_text();checks[folder.name]=validate_svg(original)
    for theme in ['light','dark']:
        content=original
        if theme=='dark':
            content=content.replace('color="#2a2430"','color="#eee7de"');ix=content.index('>')+1;content=content[:ix]+'<rect width="512" height="512" fill="#17151c"/>'+content[ix:]
        for size in [512,96]:
            svg=OUT/f'{folder.name}-{theme}-{size}.svg';svg.write_text(content);svgs.append((svg,size))
for size in [512,96]:
    subprocess.run(['/usr/bin/qlmanage','-t','-s',str(size),'-o',str(OUT)]+[str(p) for p,s in svgs if s==size],check=True,capture_output=True)
    rows=[svg for svg,s in svgs if s==size];cols=4;canvas=Image.new('RGB',(cols*(size+20),((len(rows)+cols-1)//cols)*(size+35)),'#eee7de');d=ImageDraw.Draw(canvas)
    for i,svg in enumerate(rows):
        im=Image.open(svg.with_suffix('.svg.png')).convert('RGB');x=(i%cols)*(size+20);y=(i//cols)*(size+35);canvas.paste(im,(x,y+25));d.text((x,y),svg.stem,fill='black')
    canvas.save(OUT/f'contact-{size}.png')
(OUT/'validation.json').write_text(json.dumps(checks,indent=2));print(checks,flush=True)
assert all(not errors for errors in checks.values())
