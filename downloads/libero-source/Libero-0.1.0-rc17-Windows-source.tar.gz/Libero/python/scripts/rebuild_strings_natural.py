"""Rebuild installed violini/viole from the original, individually recorded VSCO CE WAVs.
Run from repository root with python/.venv/bin/python. Existing sound folders are backed
up OUTSIDE the library before any edits. No shared bank or config file is changed.
"""
from pathlib import Path
from collections import Counter
import argparse, json, re, shutil, os
from datetime import datetime, timezone
HOME = Path.home()
BANK = HOME / 'Libero/banks/archi'
SOURCE = HOME / 'Libero/cache/libraries/vsco2-ce/Strings'
DEST = {'violini': ('Violin Section','Violini'), 'viole': ('Viola Section','Viole')}
ART = {'susvib': ('sus','Sostenuto',12), 'spic': ('stacc','Spiccato',14), 'pizz': ('pizz','Pizzicato',15), 'trem': ('trem','Tremolo',16)}
PC = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def rebuild(slug):
    folder = BANK / slug
    backup = HOME / 'Libero-backups/2026-10-02' / 'archi' / slug
    if not backup.exists():
        backup.parent.mkdir(parents=True,exist_ok=True)
        shutil.copytree(folder,backup,symlinks=False)
        print('Backup:',backup,flush=True)
    srcname,title = DEST[slug]
    body=[]; supplements=[]
    for sub in sorted((SOURCE/srcname).iterdir()):
        if sub.name.lower() not in ART: continue
        aid,aname,key = ART[sub.name.lower()]
        files=sorted(sub.glob('*.wav'))
        indexed=[]
        for f in files:
            m=re.search(r'_([A-G])(#?)(\d)_v(\d)(?:_rr(\d)|_(\d))?\.wav$',f.name,re.I)
            if not m: raise ValueError(f'Unrecognised filename: {f}')
            root=12*(int(m[3])+2)+PC[m[1].upper()]+bool(m[2])
            indexed.append((f,root,int(m[4]),int(m[5] or m[6] or 1)-1))
        vs=sorted({v for _,_,v,_ in indexed})
        originals=list(indexed)
        for root in sorted({r for _,r,_,_ in originals}):
            for v in vs:
                if any(r==root and v2==v for _,r,v2,_ in originals): continue
                candidates=[e for e in originals if e[2]==v]
                nearest=min({e[1] for e in candidates},key=lambda r:(abs(r-root),r))
                from libero import load
                for f,r,v2,take in candidates:
                    if r!=nearest: continue
                    dst=folder/'samples/nearest-root'/sub.name/f'n{root:03d}_v{v}_t{take}.flac'
                    dst.parent.mkdir(parents=True,exist_ok=True)
                    load(f).pitch(root-r).save(dst,subtype='PCM_24')
                    indexed.append((dst,root,v,take))
                    supplements.append({'articulation':aid,'source':str(f.relative_to(SOURCE)),'source_root':r,'target_root':root,'semitones':root-r,'velocity_layer':v,'take':take,'file':str(dst.relative_to(folder/'samples'))})
        atroot={r:vs for _,r,_,_ in indexed}
        for f,root,v,take in indexed:
            dst=f if f.suffix=='.flac' else folder/'samples/raw-vsco'/sub.name/f.name
            dst.parent.mkdir(parents=True,exist_ok=True)
            if not dst.exists(): shutil.copy2(f,dst)
            layers=atroot[root]
            pos=layers.index(v)
            reg={'file':str(dst.relative_to(folder/'samples')),'root':root,'dyn':[pos/len(layers),(pos+1)/len(layers)],'take':take,'articulation':aid,'loop':'none'}
            if slug=='violini' and aid=='sus': reg['gain_db']=8.0
            if aid in ('stacc','pizz'): reg['one_shot']=True
            body.append(reg)
    (folder/'samples/nearest-root.json').write_text(json.dumps(supplements,indent=2)+'\n')
    mp={'body':body,'tail':[]}
    (folder/'samples/map-natural.json').write_text(json.dumps(mp,indent=2)+'\n')
    credit={'source':'VSCO 2 Community Edition — original WAV recordings','author':'Sam Gossner and Simon Dalzell; cutting Elan Hickler / Soundemote','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://github.com/sgossner/VSCO-2-CE','retrieved':datetime.now(timezone.utc).isoformat(),'files':[r['file'] for r in body]}
    (folder/'samples/credits.json').write_text(json.dumps([credit],indent=2)+'\n')
    (folder/'samples/ATTRIBUTION.md').write_text('# Recordings\n\nVSCO 2 Community Edition, Sam Gossner and Simon Dalzell; sample cutting by Elan Hickler / Soundemote. CC0 1.0 Universal.\n\nhttps://versilian-studios.com/vsco-community/\nhttps://github.com/sgossner/VSCO-2-CE/blob/master/LICENSE\n\nRaw source files copied unchanged; compiler edits onset, fade and applies bounded level calibration and ONE tuning correction.\n')
    (folder/'sound.py').write_text(f'''"""{title}: individual real VSCO CE recordings (CC0); natural, unlooped playback.
No composite layers, fake marcato, synthetic bow-lift tails, or baked stereo effects.
Reproducible: python/scripts/rebuild_strings_natural.py in the Libero repository.
"""
import json
from pathlib import Path
from libero import Sound
MAP=json.loads((Path(__file__).parent/'samples/map-natural.json').read_text())
sound=Sound(title={title!r},subtitle="sezione naturale · C0 sostenuto · D0 spiccato · D#0 pizzicato · E0 tremolo · dinamica dalla velocità",tags=['bowed','strings','section','sampled','articulations'],sample_rate=48000)
sound.articulations([{{'id':'sus','name':'Sostenuto','key':12}},{{'id':'stacc','name':'Spiccato','key':14}},{{'id':'pizz','name':'Pizzicato','key':15}},{{'id':'trem','name':'Tremolo','key':16}}])
sound.multisample('body',MAP['body'],process={{'tune':'detect','ladder':'smooth','ladder_max_db':4.0,'max_step_db':9.5,'peak_db':-9.0,'align_ms':{5.0 if slug=='violini' else 8.0},'pre_ms':{4.0 if slug=='violini' else 6.0},'loop':'none','max_seconds':None,'end_db':-80.0,'fade_ms':30.0,'encoding':'flac24'}})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,velocity_curve=1,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=1800)
sound.defaults(artic=0,mode='Poli',glide=0,voices=24,dyn_mode='Velocità',amp_attack=0,amp_decay=6000,amp_sustain=1,amp_release=160,lvl_body=0,lvl_tail=-60,lvl_air=-60,vel_sens=0.25,master=0,humanize=0,tape_wow=0,tape_flutter=0,tape_sat=0,lfo_pitch=0,lfo_amp=0,drive=0,echo_mix=0,rev_mode='Cappella',rev_mix=0.08,rev_size=0.45,rev_decay=1.4,rev_predelay=12,rev_damp=0.45)
''')
    (folder/'notes.md').write_text(f'''# {title} — ricostruzione naturale, 2 ottobre 2026

Sezione d'archi basata solo sulle registrazioni originali VSCO 2 Community Edition (CC0). Ogni zona suona una singola esecuzione reale, con tutti i livelli e round robin registrati. Non vi sono loop o somma di dinamiche.

## Diagnosi precedente

Il vecchio map.json applicava già una correzione di intonazione; il recipe tune=detect sottraeva nuovamente l'intonazione misurata. Il lint precedente riportava 25–26 cent di estensione residua. La sorgente dinamica CC1 manteneva lo stesso livello registrato anche cambiando la velocità della tastiera. 'Marcato' duplicava solo gli spiccati forti; i tail erano ritagli ricalibrati dei sostenuti. I defaults aggiungevano jitter di 3 cent e 4 ms; nei violini master e body arrivavano entrambi a +6 dB.

## Progetto

Reimportazione dai WAV originali, copiati immutati in samples/raw-vsco. Tune=detect con tune_cents iniziale zero: una sola correzione. Dinamica tramite velocity, senza crossfade; nessun jitter aggiunto; wow/flutter zero. Intera durata originale (nessun max_seconds), inclusi i finali naturali. Nessun tail inventato: un note-off anticipato usa 160 ms di release. Normalizzazione unica dello strumento a −9 dBFS, correzioni locali limitate a 4 dB; niente normalizzazione per file. Stereo originale. Riverbero Cappella 8%, disattivabile.

C0 sostenuto, D0 spiccato, D#0 pizzicato, E0 tremolo. C#0 non è più una falsa articolazione marcato. I vecchi materiali restano inattivi per compatibilità con i collegamenti dell'ensemble; backup integrale: {backup}.

## Bilanciamento delle articolazioni

Nei violini la registrazione dei sostenuti era circa 10.6 dB sotto il tremolo in LUFS massimo mediano. Un unico trim +8 dB applicato a TUTTI i sostenuti avvicina le mediane a circa 2.6 dB: rapporti tra dinamiche, radici e take conservati. Nessun guadagno di questo tipo nelle viole. Non è un effetto o una normalizzazione per file.

## Fonti e limiti

VSCO 2 CE: https://versilian-studios.com/vsco-community/ — CC0; licenza verificata: https://github.com/sgossner/VSCO-2-CE/blob/master/LICENSE. Registrazioni Sam Gossner e Simon Dalzell, editing Elan Hickler / Soundemote. Nessuna nuova libreria è stata scaricata; nuove zone ricompilate dalle fonti originali. SSO è stata valutata ma non selezionata per l'origine mista e licenza Sampling Plus, meno chiara per distribuzione.

Mancano transizioni legato registrate e release separati. Le note tenute oltre la durata registrata terminano naturalmente. Posso misurare e ispezionare i file, non ascoltare: qualità percettiva da verificare dall'utente nei preview.
''')
    with (folder/'notes.md').open('a') as out:
        out.write('\n## Completamento dei livelli mancanti\n\n')
        for item in supplements: out.write(f"- {item['source']}: MIDI {item['source_root']} → {item['target_root']} ({item['semitones']:+d} semitoni), v{item['velocity_layer']}, take {item['take']}. Una sola registrazione vicina ricampionata con filtro antialias; nessuna somma o dinamica inventata.\n")
    print(slug,Counter(r['articulation'] for r in body),'source zones',len(body),flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('slugs',nargs='*',default=list(DEST));args=ap.parse_args()
    for slug in args.slugs: rebuild(slug)
