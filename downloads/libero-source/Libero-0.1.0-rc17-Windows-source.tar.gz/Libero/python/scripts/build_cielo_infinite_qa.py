"""Native long-hold and wrap QA; preserve the original musical entrances."""
from pathlib import Path
import concurrent.futures, json, math, subprocess
import numpy as np
from scipy import signal
import soundfile as sf
from libero import Audio,load,dsp,analysis,library
from libero.lint import lint_bundle,lint_text
from libero.figure import validate_svg
from libero.render import render
from build_cielo_infinite import STAGE,REPORT,BACK,SR

def wave(path,start,frames):
    return sf.read(str(path),start=max(0,start),frames=frames,always_2d=True)[0]

def band(x):
    f,p=signal.welch(x.mean(axis=1),SR,nperseg=8192);tot=p.sum()+1e-25
    return [round(float(10*np.log10((p[(f>=lo)&(f<hi)].sum()+1e-25)/tot)),3) for lo,hi in [(80,400),(400,2000),(2000,8000)]]

def qa(folder):
    b=folder/'build';m=json.loads((b/'manifest.json').read_text());zones=m['zones'];checks=[]
    for z in zones:
        path=b/z['file'];s,e=z['loop']['start'],z['loop']['end'];w=960
        pre=wave(path,s-w,w+1);end=wave(path,e-w,w)
        err=np.sum((pre[:w]-end)**2)/(np.sum(pre[:w]**2)+np.sum(end**2)+1e-20)
        jump=abs(pre[-1]-end[-1]).max();typ=np.percentile(abs(np.diff(end,axis=0)),99)+1e-20
        levels=[];mono=[]
        for frac in np.arange(0,1,.025):
            block=wave(path,s+int((e-s-48000)*frac),48000);levels.append(float(dsp.db(np.sqrt(np.mean(block*block)))))
            mono.append(float(dsp.db(np.sqrt(np.mean(block.mean(axis=1)**2))/max(np.sqrt(np.mean(block*block)),1e-20))))
        checks.append({'file':z['file'],'root':z['root'],'articulation':z.get('articulation'),'period_s':(e-s)/SR,'seam_db':round(float(10*np.log10(err+1e-15)),2),'jump_vs_local_derivative':round(float(jump/typ),3),'rms_1s_min_db':round(min(levels),2),'rms_1s_median_db':round(float(np.median(levels)),2),'rms_1s_range_db':round(max(levels)-min(levels),2),'mono_worst_db':round(min(mono),2)})
    findings=lint_bundle(b);text=lint_text(b,folder.name);(b/'lint.txt').write_text(text)
    fail=[f.text for f in findings if f.level=='FAIL'];warn=[f.text for f in findings if f.level=='WARN']
    errors=library.validate_bundle(b);figure=validate_svg((folder/'figure.svg').read_text())
    roots=sorted({z['root'] for z in zones});mid=roots[len(roots)//2];arts=m.get('articulations',[])
    render(folder,b/'hold-110s.wav',[(mid,0,110,106)],params={'artic':0,'rev_mix':0,'master':-3},tail=3)
    hold=load(b/'hold-110s.wav');(b/'hold-110s.png').write_bytes(analysis.spectrogram(hold,title=m['title'].replace('→','verso')+' · 110 s / two wraps'))
    held=[]
    for t in [1,10,20,40,60,80,100,110.5]:
        block=hold.data[int(t*SR):int((t+1)*SR)];held.append({'time_s':t,'rms_db':round(float(dsp.db(np.sqrt(np.mean(block*block)))),2),'bands_80_400_400_2k_2k_8k_db':band(block),'stereo_correlation':round(float(np.corrcoef(block.T)[0,1]),3)})
    articulation_tests=[]
    for ai,art in enumerate(arts):
        ar=sorted({z['root'] for z in zones if z.get('articulation')==art['id']});root=ar[len(ar)//2]
        render(folder,b/f'hold-articulation-{ai}.wav',[(root,0,60,90)],params={'artic':ai},tail=2)
        a=load(b/f'hold-articulation-{ai}.wav');segment=a.data[55*SR:58*SR]
        articulation_tests.append({'articulation':art['name'],'root':root,'late_rms_db':round(float(dsp.db(np.sqrt(np.mean(segment*segment)))),2),'peak_db':round(a.peak_db,2)})
    lo=min(z['lo'] for z in zones);hi=max(z['hi'] for z in zones)
    notes=[(lo,0,2.2,40),(hi,2.7,2.2,116),(mid,5.4,16,97),(max(lo,mid-5),5.4,16,86),(min(hi,mid+3),5.4,16,84),(mid,22,.7,70),(mid,23,.7,113),(mid,24,35,110)]
    if folder.name=='ellen-ooh-aha':notes=[(55,0,60,95),(54,62,10,75)]
    render(folder,b/'preview.wav',notes,tail=3);preview=load(b/'preview.wav')
    subprocess.run(['/opt/homebrew/bin/ffmpeg','-y','-loglevel','error','-i',str(b/'preview.wav'),'-c:a','aac','-b:a','192k',str(b/'preview.m4a')],check=True)
    (b/'spectrogram.png').write_bytes(analysis.spectrogram(preview,title=m['title'].replace('→','verso')+' · infinite native preview'))
    entrance=None
    if (BACK/folder.name).exists():
        for label,p in [('before',BACK/folder.name),('after',folder)]:render(p,REPORT/f'{folder.name}-{label}-entrance.wav',[(mid,0,1.4,106)],params={'artic':0,'rev_mix':0,'master':0},tail=.05)
        x=load(REPORT/f'{folder.name}-before-entrance.wav').data;y=load(REPORT/f'{folder.name}-after-entrance.wav').data;n=min(len(x),len(y),int(.35*SR));x=x[:n];y=y[:n]
        # Onset trim remains performer-dependent; compare physical waveform
        # with a <=5ms alignment, and report it rather than hiding the shift.
        cc=signal.correlate(x.mean(axis=1),y.mean(axis=1),mode='full',method='fft');lags=signal.correlation_lags(n,n);ok=abs(lags)<=240;lag=int(lags[ok][np.argmax(cc[ok])]);xx=x[max(0,lag):n+min(0,lag)];yy=y[max(0,-lag):n+min(0,-lag)]
        gain=np.sum(xx*yy)/(np.sum(yy*yy)+1e-20);err=np.sqrt(np.mean((xx-yy*gain)**2))/max(np.sqrt(np.mean(xx*xx)),1e-20)
        entrance={'align_ms':lag/SR*1000,'relative_rms_error_db':round(float(dsp.db(err)),2),'gain_to_match_db':round(float(dsp.db(abs(gain))),2)}
    decoded=sum(sf.info(str(b/z['file'])).frames*sf.info(str(b/z['file'])).channels*4 for z in zones)/1048576
    data={'zones':len(zones),'looped':sum(bool(z['loop']) for z in zones),'decoded_mib':round(decoded,1),'fail':len(fail)+len(errors)+len(figure),'failures':fail+errors+figure,'warn':len(warn),'warnings':warn,'loops':checks,'holds':held,'articulations':articulation_tests,'entrance_vs_approved':entrance,'hold_peak_db':round(hold.peak_db,2),'preview_peak_db':round(preview.peak_db,2)}
    if min(c['seam_db'] for c in checks)>-30 or max(c['seam_db'] for c in checks)>-30:data['fail']+=1;data['failures'].append('Loop seam above -30dB')
    if decoded>1536:data['fail']+=1;data['failures'].append('Decoded RAM above1536MiB')
    if preview.peak_db>-.5:data['fail']+=1;data['failures'].append('Preview headroom')
    (b/'infinite-qa.json').write_text(json.dumps(data,indent=2))
    p=folder/'notes.md';p.write_text(p.read_text().split('\n## QA infinito')[0]+f'\n## QA infinito\n\n{len(zones)}zone,tutte loopate; RAM decodificata{decoded:.1f}MiB. Hold nativo110s attraversa due ritorni; ulteriori hold60s per tutte le articolazioni. Loop e coda sono misurati per livello,continuità,stereo/mono e spettro.\n\n'+text+'\n\nGli avvisi restano nelle dinamiche originali: ingressi indipendenti a commutazione, singolo livello per tecniche specifiche, naturale colore non monotono. I dati non certificano il giudizio musicale o un loop impercettibile.\n')
    print(folder.name,data['fail'],'FAIL',len(warn),'WARN','max seam',max(c['seam_db'] for c in checks),'RAM',round(decoded),flush=True)
    return folder.name,data

if __name__=='__main__':
    REPORT.mkdir(parents=True,exist_ok=True);results={}
    for folder in sorted(p for p in STAGE.iterdir() if (p/'sound.py').exists()):
        k,v=qa(folder);results[k]=v;(REPORT/'qa.json').write_text(json.dumps(results,indent=2))
    assert len(results)==8 and all(v['fail']==0 for v in results.values())
