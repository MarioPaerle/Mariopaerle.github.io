from pathlib import Path
import sys,json,numpy as np,soundfile as sf,shutil
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import render,analysis
from libero.figure import validate_svg
OUT=Path.home()/'Libero/demo/aria-v4';report={}
for slug in ['pan-canne','saw-rame']:
 folder=Path.home()/'Libero/banks/aria'/slug
 report[slug]={'figure':str(validate_svg((folder/'figure.svg').read_text())),'roots':[]}
 roots=[55,59,62,64,67,71,74,76,79,83] if slug=='pan-canne' else [36,48,60,72,84]
 for root in roots:
  pv=render.preview(slug,f'{root}:0:15:110',tail=2)
  x=pv.audio.data;sr=pv.audio.sr
  if x.ndim==1:x=x[:,None]
  rms=lambda a:20*np.log10(np.sqrt(np.mean(a*a))+1e-20)
  windows=[float(rms(x[i*sr:(i+1)*sr])) for i in range(5,15)]
  mono=x.mean(axis=1);mono_delta=float(rms(mono[5*sr:15*sr])-rms(x[5*sr:15*sr]))
  row={'root':root,'peak_db':pv.audio.peak_db,'late_rms_db':windows[-1],'held_rms_spread_db':max(windows)-min(windows),'mono_change_db':mono_delta,'post_release_rms_db':float(rms(x[16*sr:]))}
  report[slug]['roots'].append(row);print(slug,root,row,flush=True)
  if not np.isfinite(windows[-1]) or windows[-1]<-60:raise RuntimeError(f'held silent {slug}:{root}')
  if pv.audio.peak_db>-.5:raise RuntimeError('clipping')
  if root==83 and slug=='pan-canne':shutil.copy2(pv.wav,OUT/slug/'B5-held15.wav')
 pv=render.preview(slug,'48:0:4:127,55:0:4:127,60:0:4:127,64:0:4:127,67:0:4:127,72:0:4:127',tail=2)
 report[slug]['six_note_chord_peak_db']=pv.audio.peak_db
 if pv.audio.peak_db>-.5:raise RuntimeError(f'chord headroom {slug}')
(OUT/'pan-saw-native-qa.json').write_text(json.dumps(report,indent=2)+'\n')
