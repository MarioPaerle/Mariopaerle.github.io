"""Replace the three rejected synthetic 808s with distinct Abletunes hardware samples.

The local Abletunes source pack must already exist in ~/Libero/cache/research/808-v3.
Its EULA allows sampler use in musical productions but prohibits redistribution; these
installed sounds are private and marked license_class=eula so Libero blocks pack export.
Only the three 808 folders are replaced. The three sub sounds are not touched.
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
LIBRARY_ROOT = Path.home() / "Libero"
BANK = LIBRARY_ROOT / "banks" / "bassi"
PACK = LIBRARY_ROOT / "cache" / "research" / "808-v3" / "Abletunes" / "Abletunes - 808"
BACKUP = Path.home() / "Libero-backups" / "2026-10-03" / "808-v3-feedback"
SOURCE_URL = "https://abletunes.com/product/sample-packs/free-808-samples"
LICENSE_URL = "https://abletunes.com/license-agreement"

PATCHES = [
    {
        "slug": "808-notte", "title": "808 Notte", "sample": 22,
        "file": "Abletunes - 808 22 A.wav", "root": 33, "lo": 24, "hi": 48,
        "subtitle": "registrazione hardware · coda lunga, corpo A1 stabile",
        "accent": "#5c537f", "peak_db": -9.0,
        "identity": "Il campione A1 n. 22 conserva un corpo quasi fermo per circa 3 s e una coda naturale lunga 18,56 s. Un solo registrato stereo, senza loop, livello d’ingresso ridotto globalmente.",
        "figure": "notte",
    },
    {
        "slug": "808-colpo", "title": "808 Colpo", "sample": 28,
        "file": "Abletunes - 808 28 C.wav", "root": 36, "lo": 24, "hi": 48,
        "subtitle": "registrazione hardware · attacco presente, decadimento C2",
        "accent": "#9d6044", "peak_db": -9.0,
        "identity": "Il campione C2 n. 28 ha un attacco pieno, energia alta iniziale e un decadimento evidente dopo circa 1,5–2 s. Un solo registrato stereo, senza loop o strati sintetici.",
        "figure": "colpo",
    },
    {
        "slug": "808-cavo", "title": "808 Cavo", "sample": 1,
        "file": "Abletunes - 808 01 E.wav", "root": 28, "lo": 24, "hi": 48,
        "subtitle": "registrazione hardware · corpo E1 stabile e rotondo",
        "accent": "#8a6c39", "peak_db": -9.0,
        "identity": "Il campione E1 n. 01 mantiene un corpo ricco e stabile per circa 3 s, con una grana armonica diversa dagli altri due registrati. Un solo registrato stereo, senza oscillator bed, saturazione aggiunta o riverbero.",
        "figure": "cavo",
    },
]


def install(patch: dict) -> None:
    source = PACK / patch["file"]
    if not source.is_file():
        raise FileNotFoundError(source)
    dest = BANK / patch["slug"]
    if not (BACKUP / patch["slug"]).is_dir():
        raise RuntimeError(f"Backup missing for {patch['slug']}: {BACKUP / patch['slug']}")
    if dest.exists():
        shutil.rmtree(dest)
    (dest / "samples").mkdir(parents=True)
    installed = dest / "samples" / "body.wav"
    shutil.copy2(source, installed)
    region = [{"file": "body.wav", "root": patch["root"],
               "take": 0, "tune_cents": 0.0, "loop": "none", "one_shot": False}]
    (dest / "samples" / "map.json").write_text(json.dumps({"body": region}, indent=2) + "\n")
    credit = [{
        "source": f"Abletunes - 808 · {patch['file']}",
        "license": "Abletunes License Agreement (EULA; sampler use in musical productions permitted, redistribution prohibited)",
        "license_class": "eula", "author": "Abletunes",
        "url": SOURCE_URL, "license_url": LICENSE_URL,
        "retrieved": "2026-10-03",
        "files": ["samples/body.wav"],
        "notes": "Private local instrument installation. Do not share, bundle, export or redistribute this audio as a sample library.",
    }]
    (dest / "samples" / "credits.json").write_text(json.dumps(credit, indent=2, ensure_ascii=False) + "\n")
    (dest / "samples" / "ATTRIBUTION.md").write_text(
        f"""# Abletunes 808 source

`{patch['file']}` from the Abletunes 808 pack, recorded from analog drum machines / processing.

Pack: {SOURCE_URL}  
License: {LICENSE_URL}

The EULA permits sampler use in musical productions and prohibits redistribution, bundling,
sharing, or making the samples available as a library. This private installation is marked
`license_class=eula`; Libero's pack exporter blocks it. Do not commit or distribute the WAV.
"""
    )
    recipe = f'''"""{patch['title']} — one unlooped hardware recording, kept at its source tuning."""
import json
from pathlib import Path
from libero import Sound

sound = Sound(
    title={patch['title']!r}, subtitle={patch['subtitle']!r},
    tags=["bass", "808", "trap", "rap", "sampled-hardware", "mono-low"],
    roots=[{patch['root']}], velocities=[100], accent={patch['accent']!r}, sample_rate=48000,
)
sound.multisample("body", json.loads((Path(__file__).parent / "samples" / "map.json").read_text())["body"],
    process={{"pre_ms": 2, "align_ms": 0, "tune": "source", "ladder": "keep",
             "peak_db": {patch['peak_db']}, "max_seconds": None, "end_db": -72,
             "fade_ms": 45, "loop": "none", "encoding": "flac24", "mono": False,
             "edge_fill": True}},
    as_dyn=False,
)
sound.performance(dynamics_source="velocity", velocity_curve=1, dyn_crossfade=0,
                  humanize={{"cents": 0, "ms": 0, "db": 0}}, rr_reset_ms=2000,
                  one_shot=False)
sound.defaults(
    mode="Mono", glide=45, voices=16, dyn_mode="Velocità", vel_sens=0.25,
    master=-3, amp_attack=0, amp_decay=10000, amp_sustain=1, amp_release=75,
    osc1_level=-60, osc2_level=-60, sub_level=-60,
    lvl_body=0, lvl_attack=-60, lvl_tail=-60, lvl_air=-60,
    drive=0, tape_wow=0, tape_flutter=0, tape_sat=0, tape_age=0, tape_mix=0,
    lfo_pitch=0, lfo_amp=0, res_mix=0, echo_mix=0,
    flt_cutoff=20000, flt_reso=0, flt_env=0,
    rev_mode="Cappella", rev_mix=0, rev_size=0.2, rev_decay=0.5,
    rev_predelay=0, rev_damp=0.7, rev_width=0, rev_shimmer=0,
)
'''
    (dest / "sound.py").write_text(recipe)
    (dest / "notes.md").write_text(f"""# {patch['title']}

{patch['identity']}

Hardware/source file: `{patch['file']}`. Root {patch['root']} MIDI is transposed by sample playback across the keyboard; pitch and playback time shift together, so the closest timbre is around the recorded root. The source has no velocity recordings, so velocity changes level only. The sample decays naturally while a note is held; note-off controls a short 75 ms release for playable melodic phrases. Mono mode with 45 ms glide supports held legato slides. The sample remains stereo as recorded; measured L/R correlation is above 0.999, so the low end is effectively centered without synthetic widening.

No synthetic oscillator bed, extra saturation, resonator, tape modulation, chorus, or reverb. The source sample is left intact; the compiler makes its FLAC zone with one global gain, a 2 ms preroll, source tuning, no looping, and a short fade only at the quiet tail. The analog pitch movement and transient remain part of the recording.

## Credits and license

Abletunes 808 pack: {SOURCE_URL}  
EULA: {LICENSE_URL}

Private local use only. The EULA allows sampler use in musical productions but prohibits redistribution or making the samples available as a sample library. `samples/credits.json` marks this source `eula` so Libero blocks export.

## Verifica tecnica

QA_PLACEHOLDER
""")
    (dest / "figure.svg").write_text(figure_svg(patch))


def figure_svg(patch: dict) -> str:
    # Engraved architectural readings, each keyed to the recording's actual envelope.
    common = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">'
    title = patch["title"]
    if patch["figure"] == "notte":
        desc = "Le sette campate della galleria traducono la coda di 18,56 s; il corpo A1 quasi fermo per i primi 3 s è la nicchia centrale dorata. L’edificio largo resta basso nel riquadro, come il registro grave."
        art = '''<g stroke-width="1.2"><path d="M83 367V186Q83 138 125 138H387Q429 138 429 186V367M103 367V190Q103 158 132 158H380Q409 158 409 190V367"/><path d="M62 367H450V394H62Z" fill="#f3eee6"/><path d="M74 394H438M89 404H423" stroke-width=".8"/></g>
<g stroke-width=".5"><path d="M108 189L150 159M124 196L177 159M148 196L201 159M172 196L225 159M196 196L249 159M220 196L273 159M244 196L297 159M268 196L321 159M292 196L345 159M316 196L369 159M340 196L393 159"/><path d="M98 236H414M98 257H414M98 279H414M98 301H414M98 323H414M98 345H414"/></g>
<g stroke-width=".8"><path d="M117 214Q132 204 147 214V350M159 214Q174 204 189 214V350M201 214Q216 204 231 214V350M243 214Q258 204 273 214V350M285 214Q300 204 315 214V350M327 214Q342 204 357 214V350M369 214Q384 204 399 214V350"/></g>
<path d="M229 367V248Q229 219 256 219Q283 219 283 248V367Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.4"/><path d="M238 365V251Q238 229 256 229Q274 229 274 251V365" stroke="#b8924f" stroke-width="1.2"/><path d="M246 355V252Q246 239 256 239Q266 239 266 252V355" stroke="currentColor" stroke-width=".55"/>'''
    elif patch["figure"] == "colpo":
        desc = "Il cuneo dorato al vertice è l’attacco C2; i conci fitti attorno al centro diventano radi lungo le colonne, come gli armonici 150–500 Hz che scendono dal 7% iniziale a circa 0,4% dopo 1,5 s."
        art = '''<path d="M78 375H434V401H78Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.3"/><path d="M96 375V298Q96 262 130 262Q164 262 164 298V375M348 375V298Q348 262 382 262Q416 262 416 298V375" stroke-width="1.2"/><path d="M115 369V300Q115 282 130 282Q145 282 145 300V369M367 369V300Q367 282 382 282Q397 282 397 300V369" stroke-width=".6"/>
<path d="M185 375V212L256 124L327 212V375Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.4"/><path d="M205 365V219L256 157L307 219V365" stroke="#b8924f" stroke-width="1.3"/><path d="M221 356V226L256 185L291 226V356" stroke-width=".6"/><path d="M256 120V91M245 106L256 91L267 106" stroke="#b8924f" stroke-width="1.2"/>
<g stroke-width=".5"><path d="M190 276L226 240M190 298L244 244M190 320L244 266M190 342L244 288M266 244L322 300M266 266L322 322M266 288L322 344"/><path d="M93 389L110 375M112 389L126 375M131 389L145 375M367 389L381 375M386 389L400 375M405 389L419 375M216 307L239 284M216 324L239 301M216 341L239 318M272 315L291 296M276 323L300 299M281 332L309 303M286 341L318 307M291 350L327 311M294 318L311 335M304 313L322 335M313 309L333 331"/></g>
<path d="M247 370V214H265V370Z" fill="#b8924f" stroke="currentColor" stroke-width=".7"/>'''
    else:
        desc = "Il fusto largo e quieto è l’E1 che mantiene il livello per circa 3 s; la sezione avvolta e le fitte righe laterali indicano la sua fascia 60–150 Hz dominante (circa 10%) senza aggiungere armoniche sintetiche."
        art = '''<path d="M102 355Q101 245 153 191Q205 137 256 137Q307 137 359 191Q411 245 410 355L387 372H125Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.3"/><path d="M122 349Q124 255 168 208Q211 164 256 164Q301 164 344 208Q388 255 390 349" stroke-width=".8"/><path d="M145 346Q147 267 184 226Q219 188 256 188Q293 188 328 226Q365 267 367 346" stroke-width=".6"/>
<path d="M213 350V264Q213 225 256 225Q299 225 299 264V350Z" fill="#f3eee6" stroke="#b8924f" stroke-width="1.4"/><path d="M230 347V265Q230 244 256 244Q282 244 282 265V347" stroke="currentColor" stroke-width=".7"/>
<g stroke-width=".5"><path d="M130 313Q154 300 178 313M127 327Q153 314 179 327M126 341Q152 328 180 341M334 313Q358 300 382 313M333 327Q359 314 385 327M332 341Q360 328 386 341"/><path d="M159 239Q177 219 195 211M170 250Q190 229 208 222M305 222Q323 229 342 250M317 211Q335 219 353 239M210 351L231 275M218 352L239 269M226 352L247 260M284 269L305 351M273 260L297 352M265 258L289 352"/></g>
<path d="M74 372H438V397H74ZM91 406H421" stroke="currentColor" stroke-width=".8"/><path d="M235 347V265Q235 251 256 251Q277 251 277 265V347" stroke="#b8924f" stroke-width="1"/>'''
    return f'{common}<title>{title}</title><desc>{desc}</desc>{art}</svg>\n'


def sub_figure(title: str, mode: str) -> str:
    common = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">'
    if mode == "ancora":
        desc = "Un solo pilastro saldo porta il fondamentale; a C2 la seconda parziale è sotto −87 dB e dalla quinta è sotto −121 dB, perciò il vano resta quasi vuoto. Il capitello dorato segna il sostegno sinusoidale continuo."
        art = '''<path d="M117 365H395V391H117Z" fill="#f3eee6" stroke-width="1.3"/><path d="M153 365L178 316V184L153 153H359L334 184V316L359 365Z" fill="#f3eee6" stroke-width="1.3"/><path d="M176 184H336M177 316H335M157 355H355" stroke-width=".8"/>
<path d="M198 309V193Q198 172 256 172Q314 172 314 193V309" stroke-width=".65"/><path d="M219 300V197Q219 186 256 186Q293 186 293 197V300" stroke="#b8924f" stroke-width="1.3"/><path d="M236 297V197Q236 194 256 194Q276 194 276 197V297" stroke-width=".55"/>
<g stroke-width=".45"><path d="M166 345L196 317M181 355L213 317M201 355L233 317M221 355L253 317M241 355L273 317M261 355L293 317M281 355L313 317M301 355L333 317"/><path d="M95 238H134M86 256H137M98 274H134M382 238H421M375 256H426M382 274H414"/></g>
<path d="M85 402H427" stroke-width=".8"/>'''
    elif mode == "legno":
        desc = "Le colonne sono i parziali C2 misurati fino al 7°: altezza e peso calano con i livelli reali, mentre la terza colonna dorata identifica il corpo armonico. La venatura curva segue la risonanza di Legno."
        art = '''<path d="M84 364H428V393H84Z" fill="#f3eee6" stroke-width="1.2"/><path d="M109 364V231Q109 206 134 206H160Q185 206 185 231V364M201 364V178Q201 151 229 151H255Q283 151 283 178V364M299 364V222Q299 197 324 197H350Q375 197 375 222V364" stroke-width="1.2"/>
<path d="M122 354V233Q122 218 137 218H157Q172 218 172 233V354M214 354V180Q214 164 230 164H254Q270 164 270 180V354M312 354V224Q312 209 327 209H347Q362 209 362 224V354" stroke-width=".65"/>
<path d="M228 355V204Q228 179 242 179V355M244 355V179Q258 179 258 204V355" stroke="#b8924f" stroke-width="1.3"/>
<g stroke-width=".5"><path d="M117 274Q143 262 178 274M117 290Q144 278 178 290M117 306Q144 294 178 306M210 249Q240 235 274 249M210 267Q240 253 274 267M210 285Q240 271 274 285M308 280Q335 268 367 280M308 297Q336 285 367 297M308 314Q336 302 367 314"/><path d="M132 221Q146 243 132 262Q120 280 137 301M235 173Q267 208 235 242Q220 263 241 299M328 213Q346 235 330 260Q319 278 338 298M310 345L329 319M318 354L341 322M326 359L353 325M336 360L365 329M344 360L370 337"/></g>
<path d="M92 403H420" stroke-width=".8"/>'''
    else:
        desc = "L’arco elastico apre subito (attacco 0 ms), poi stringe la luce nel decadimento di 520 ms; tre archi interni più bassi mostrano il rimbalzo corto, con il sostegno dorato che mantiene il fondamentale."
        art = '''<path d="M76 357Q87 212 152 212Q217 212 256 339Q295 212 360 212Q425 212 436 357Z" fill="#f3eee6" stroke-width="1.35"/><path d="M98 347Q112 237 160 237Q208 237 256 352Q304 237 352 237Q400 237 414 347" stroke-width=".8"/>
<path d="M138 351Q153 274 183 274Q214 274 256 358Q298 274 329 274Q359 274 374 351M181 355Q193 310 215 310Q237 310 256 364Q275 310 297 310Q319 310 331 355" stroke-width=".65"/>
<path d="M238 367V329Q238 307 256 307Q274 307 274 329V367Z" fill="#b8924f" stroke-width=".9"/><path d="M256 310V187M246 197L256 187L266 197" stroke-width="1.1"/>
<g stroke-width=".5"><path d="M89 318L116 303M94 334L125 317M397 317L428 334M406 303L433 318M148 244L170 258M365 244L343 258M193 283L218 299M319 283L294 299"/><path d="M119 365L137 355M140 370L157 362M365 362L382 370M385 355L403 365M80 338L102 316M80 347L113 315M80 356L124 314M80 365L136 311M86 337L108 357M97 327L129 358M108 318L138 347"/></g>
<path d="M66 376H446V397H66Z" fill="#f3eee6" stroke-width="1.1"/>'''
    return f'{common}<title>{title}</title><desc>{desc}</desc>{art}</svg>\n'


def update_sub_figures() -> None:
    for slug, title, mode in (("sub-ancora", "Sub Ancora", "ancora"),
                              ("sub-legno", "Sub Legno", "legno"),
                              ("sub-rimbalzo", "Sub Rimbalzo", "rimbalzo")):
        (BANK / slug / "figure.svg").write_text(sub_figure(title, mode))


def main() -> None:
    BANK.mkdir(parents=True, exist_ok=True)
    if not PACK.is_dir():
        raise FileNotFoundError(f"Abletunes source pack is missing: {PACK}")
    for patch in PATCHES:
        install(patch)
        print(f"Installed {patch['slug']} from {patch['file']}")
    update_sub_figures()
    from libero.compiler import compile_sound
    from libero.lint import lint_bundle
    for patch in PATCHES:
        folder = BANK / patch["slug"]
        result = compile_sound(folder, jobs=4)
        print(result.text())
        if not result.ok:
            raise SystemExit(f"Compilation failed for {patch['slug']}")
        findings = lint_bundle(folder / "build")
        print(f"{patch['slug']}: " + ", ".join(f"{f.level} {f.check}: {f.text}" for f in findings))
        if any(f.level == "FAIL" for f in findings):
            raise SystemExit(f"Lint failures for {patch['slug']}")


if __name__ == "__main__":
    main()
