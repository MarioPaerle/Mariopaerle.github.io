"""Copy the example sounds from the repo into the library and compile them.

    uv --directory python run python scripts/install_examples.py [--sketches] [--force]

By default they go to $LIBERO_HOME/sounds (saved sounds). Existing folders are
left alone unless --force, which moves them to the Trash first.
"""

from __future__ import annotations

import argparse
import shutil
import sys
import time
from pathlib import Path

from libero import library
from libero.compiler import compile_sound

REPO = Path(__file__).resolve().parents[2]
EXAMPLES = ("lira", "vetro", "coro-di-marmo")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sketches", action="store_true", help="install as sketches instead of saved sounds")
    ap.add_argument("--force", action="store_true", help="replace existing copies (old ones go to the Trash)")
    a = ap.parse_args()
    dest_root = library.sketches_dir() if a.sketches else library.sounds_dir()
    rc = 0
    for slug in EXAMPLES:
        src = REPO / "sounds" / slug
        dst = dest_root / slug
        if dst.exists():
            if not a.force:
                print(f"{slug}: already in {dest_root}, skipped (use --force to replace)")
                continue
            trash = library.trash_dir() / f"libero-{slug}-replaced-{time.strftime('%Y%m%d-%H%M%S')}"
            trash.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(dst), str(trash))
            print(f"{slug}: previous copy moved to {trash}")
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns("build", "__pycache__", ".build.*"))
        res = compile_sound(dst)
        print(res.text() if res.ok else f"{slug}: {res.error}")
        rc |= 0 if res.ok else 1
    return rc


if __name__ == "__main__":
    sys.exit(main())
