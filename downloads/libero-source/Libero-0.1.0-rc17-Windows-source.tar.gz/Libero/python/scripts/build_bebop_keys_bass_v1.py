#!/usr/bin/env python3
"""Build two source-led Bebop rhythm instruments: Steinway B and pizzicato bass."""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json, math, re, shutil, subprocess, sys
import numpy as np
import soundfile as sf
from scipy.signal import find_peaks, resample_poly

ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, analysis, dsp, library
from libero.compiler import compile_sound
from libero.ingest.sfz import parse_sfz
from libero.lint import lint_bundle, _load
from libero.figure import validate_svg

HOME=Path.home(); LIB=HOME/'Libero'; BANK=LIB/'banks/bebop'; DEMO=LIB/'demo/bebop-v1/rhythm-keys-bass'
SR=48000; PERIOD=6.0
PIANO=LIB/'cache/libraries/vcsl/Chordophones/Zithers/Grand Piano, Steinway B'
BASS=LIB/'cache/libraries/karoryfer-smolken'
SFZ=BASS/'d_smolken_rubner_bass_pizz.sfz'
SLUGS=('bebop-steinway','bebop-contrabbasso')

def digest(p):
 h=sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def stored(src:Path,samples:Path,root:Path):
 rel=src.relative_to(root); dst=samples/'originals'/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 if not dst.exists() or digest(dst)!=digest(src):shutil.copy2(src,dst)
 return dst.relative_to(samples).as_posix()

def note_midi(label):
 m=re.fullmatch(r'(A#|C#|D#|F#|G#|A|B|C|D|E|F|G)(-?\d+)',label)
 if not m:raise ValueError(f'bad note label {label}')
 semis={'C':0,'C#':1,'D':2,'D#':3,'E':4,'F':5,'F#':6,'G':7,'G#':8,'A':9,'A#':10,'B':11}
 return (int(m.group(2))+1)*12+semis[m.group(1)]

def find_root(name):
 m=re.search(r'_([A-G]#?)(\d)_vl([234])_rr(\d+)\.wav$',name,re.I)
 if not m:raise ValueError(f'cannot read pitch/dynamic/take from {name}')
 return note_midi(m.group(1).upper()+m.group(2)),int(m.group(3)),int(m.group(4))

def derive_stereo(src:Path,dst:Path,root:int):
 """Preserve the stereo attack, then fit same-take phase-coherent modal sustain."""
 raw,sr0=sf.read(src,dtype='float64',always_2d=True)
 if sr0!=SR:
  g=math.gcd(int(sr0),SR);raw=resample_poly(raw,SR//g,int(sr0)//g,axis=0)
 x=raw.copy(); mono=x.mean(axis=1);sr=SR
 env_n=48;ab=np.abs(mono);env=np.sqrt(np.convolve(ab**2,np.ones(env_n)/env_n,mode='same'))
 active=np.flatnonzero(env>=max(float(env.max())*10**(-36/20),1e-5));onset=int(active[0]) if len(active) else 0
 cut=max(0,onset-round(.005*sr));x=x[cut:];mono=x.mean(axis=1);mono-=np.mean(mono[-min(len(mono),round(.25*sr)):]);x-=np.mean(x[-min(len(x),round(.25*sr)):],axis=0)
 offset=(onset-cut)/sr;begin=offset+.04;end=min(offset+.30,len(x)/sr-.10)
 if end<=begin+.12:raise RuntimeError(f'too short for modal continuation: {src}')
 i0=round(begin*sr);i1=round(end*sr);seg=mono[i0:i1];win=np.hanning(len(seg));nfft=262144
 X=np.fft.rfft(seg*win,n=nfft);power=abs(X)**2;freq=np.fft.rfftfreq(nfft,1/sr)
 peaks,_=find_peaks(power,distance=max(1,int(1.5/(sr/nfft))))
 peaks=peaks[(freq[peaks]>28)&(freq[peaks]<min(15500,sr*.45))]
 peaks=peaks[power[peaks]>power.max()*10**(-48/10)];peaks=peaks[np.argsort(power[peaks])[-1100:]]
 if len(peaks)<3:raise RuntimeError(f'only {len(peaks)} modes: {src}')
 n=round(PERIOD*sr);spec=np.zeros((n//2+1,2),dtype=np.complex128);modecount=0
 # Project each measured modal frequency separately into each original stereo channel.
 tt=np.arange(len(seg),dtype=np.float64)/sr
 for k in peaks:
  if k<=0 or k+1>=len(power):continue
  logs=np.log(np.maximum(power[k-1:k+2],1e-30));den=logs[0]-2*logs[1]+logs[2]
  frac=np.clip(.5*(logs[0]-logs[2])/den if abs(den)>1e-20 else 0,-.5,.5)
  hz=(k+frac)*sr/nfft;dstbin=round(hz*PERIOD)
  if not 0<dstbin<n//2:continue
  # Estimate sub-bin complex coefficient in the same source-window time origin.
  osc=np.exp(-2j*np.pi*hz*tt)*win
  c=(x[i0:i1].T@osc)*(2/win.sum())
  c*=np.exp(-2j*np.pi*hz*begin)
  spec[dstbin,:]+=n*c/2;modecount+=1
 cycle=np.fft.irfft(spec,n=n,axis=0)
 early=x[round((offset+.04)*sr):round((offset+.16)*sr)]
 target=float(np.sqrt(np.mean(early**2)))*10**(-1.5/20)
 cyc=float(np.sqrt(np.mean(cycle**2)))
 if cyc<1e-12:raise RuntimeError(f'empty modal cycle {src}')
 cycle*=target/cyc
 hold=round((offset+.180)*sr);join=round((offset+.650)*sr)
 if join>=len(x) or hold>=join:raise RuntimeError(f'bad source join {src}')
 prefix=cycle[:join].copy();prefix[:hold]=x[:hold]
 u=np.linspace(0,1,join-hold);u=u*u*(3-2*u)
 prefix[hold:join]=x[hold:join]*(1-u[:,None])+cycle[hold:join]*u[:,None]
 settle=round(.350*sr);total=join+settle+n
 y=cycle[np.arange(total)%n].copy();y[:join]=prefix;ls=join+settle;le=ls+n
 dst.parent.mkdir(parents=True,exist_ok=True);sf.write(dst,y.astype('float32'),SR,format='FLAC',subtype='PCM_24')
 w=round(.020*sr);seam=10*np.log10((np.sum((y[ls-w:ls]-y[le-w:le])**2)+1e-30)/(np.sum(y[ls-w:ls]**2)+np.sum(y[le-w:le]**2)+1e-30))
 # Source-to-result entry balance and full actual stereo, no mono duplicate layer.
 return {'start':ls,'end':le},{'analysis_seconds':[round(begin,4),round(end,4)],'preserved_attack_ms':180,'join_end_s':round(join/sr,4),'loop_seconds':PERIOD,'mode_projection_count':modecount,'continuation_rms_dbfs':round(20*np.log10(target+1e-20),2),'loop_seam_db':round(float(seam),2),'derived_sha256':digest(dst),'stereo_channels':2}

def source_doc(samples:Path,docs:list[Path],credit:dict):
 out=samples/'source-reference';out.mkdir(parents=True,exist_ok=True); rows=[]
 for src in docs:
  dst=out/src.name;shutil.copy2(src,dst);rows.append({'file':dst.relative_to(samples).as_posix(),'source':str(src),'sha256':digest(src),'bytes':dst.stat().st_size})
 (samples/'source-documents.json').write_text(json.dumps(rows,indent=2)+'\n')
 (samples/'credits.json').write_text(json.dumps([credit],indent=2,ensure_ascii=False)+'\n')

def build_piano(dest:Path):
 samples=dest/'samples';samples.mkdir(parents=True,exist_ok=True); src_files=sorted((PIANO/'NoSus').glob('*.wav')); rel_files=sorted((PIANO/'Rel').glob('*.wav'))
 if len(src_files)!=126 or len(rel_files)!=99:raise RuntimeError(f'piano cache count changed: {len(src_files)} body, {len(rel_files)} release')
 originals={}; rows=[]; colpo=[]; tails=[];proof=[]; bykey=defaultdict(dict)
 for src in src_files:
  root,vel,take=find_root(src.name);f=stored(src,samples,PIANO); originals[src.name]=f;bykey[root][vel]=src
 # Only written roots (every whole-tone note) are mapped; the compiler fills the playable intervals.
 ordered_roots=sorted(bykey)
 for ri,root in enumerate(ordered_roots):
  layers=bykey[root]
  if set(layers)!={2,3,4}:raise RuntimeError(f'piano layer mismatch at MIDI {root}: {layers}')
  for vel,src in sorted(layers.items()):
   original=originals[src.name];derived_rel=f'derived/sostenuto-{src.stem}.flac';derived=samples/derived_rel
   lp,metrics=derive_stereo(src,derived,root)
   vels={2:(1,54),3:(55,89),4:(90,127)}[vel]
   lo=root if ri==0 else (ordered_roots[ri-1]+root)//2+1
   hi=root if ri==len(ordered_roots)-1 else (root+ordered_roots[ri+1])//2
   row={'file':derived_rel,'root':root,'lo':lo,'hi':hi,'vel':list(vels),'take':0,'loop':lp,'articulation':'sostenuto'};rows.append(row)
   colpo.append({'file':original,'root':root,'lo':lo,'hi':hi,'vel':list(vels),'take':0,'one_shot':True,'loop':'none','articulation':'colpo'})
   proof.append({'original':original,'source_file':str(src),'source_sha256':digest(src),'root_midi':root,'filename_dynamic':vel,'mapped_velocity':list(vels),'round_robin':take,'kind':'body-and-colpo','derived_file':derived_rel,**metrics})
 rel_bykey=defaultdict(dict)
 for src in rel_files:
  root,vel,take=find_root(src.name);f=stored(src,samples,PIANO);rel_bykey[root][vel]=src
 for root,layers in sorted(rel_bykey.items()):
  for vel,src in sorted(layers.items()):
   # Match release to actual captured strike dynamic and key, trigger only on note-off of Sostenuto.
   vels={2:(1,54),3:(55,89),4:(90,127)}[vel];rel=originals.get(src.name)
   source_rel=stored(src,samples,PIANO)
   tails.append({'file':source_rel,'root':root,'lo':root,'hi':root,'vel':list(vels),'take':0,'rt_decay':1.2,'rt_min_db':-55,'gain_db':18.0,'one_shot':True,'articulation':'sostenuto'})
   proof.append({'original':source_rel,'source_file':str(src),'source_sha256':digest(src),'root_midi':root,'filename_dynamic':vel,'mapped_velocity':list(vels),'round_robin':take,'kind':'release'})
 # Small static offsets restore the source's genuine three-step attack ladder.
 dyn_groups=defaultdict(list)
 for row in colpo:
  src=PIANO/'NoSus'/Path(row['file']).name
  v=row['vel'];root=row['root'];amp=dsp.momentary_max(Audio.load(src,sr=SR).data,SR)
  dyn_groups[root].append((row,v,amp))
 for root,items in dyn_groups.items():
  levels=[]
  for v in sorted({tuple(x[1]) for x in items}):levels.append((v,float(np.median([x[2] for x in items if tuple(x[1])==v]))))
  floor=None;targets={}
  for v,lev in levels:
   target=lev if floor is None else max(lev,floor+1.5);targets[v]=target;floor=target
  for row,v,lev in items:row['gain_db']=round(row.get('gain_db',0)+targets[tuple(v)]-lev,2)
 for row in rows:
  match=next(x for x in colpo if x['root']==row['root'] and x['vel']==row['vel']);row['gain_db']=match.get('gain_db',0)
 # The continued body is independently measured because its phase-coherent
 # modal projection can change peak loudness slightly versus the full strike.
 sostenuto=defaultdict(list)
 for row in rows:
  src=samples/row['file'];amp=dsp.momentary_max(Audio.load(src,sr=SR).data,SR)
  sostenuto[row['root']].append((row,amp+row.get('gain_db',0)))
 for root,items in sostenuto.items():
  layers=[]
  for v in sorted({tuple(x[0]['vel']) for x in items}):layers.append((v,float(np.median([x[1] for x in items if tuple(x[0]['vel'])==v]))))
  floor=None;targets={}
  for v,lev in layers:
   target=lev if floor is None else max(lev,floor+1.0);targets[v]=target;floor=target
  for row,lev in items:row['gain_db']=round(row.get('gain_db',0)+targets[tuple(row['vel'])]-lev,2)
 source_doc(samples,[LIB/'cache/libraries/vcsl/LICENSE',LIB/'cache/libraries/vcsl/README.md'],{'source':'VCSL · Grand Piano, Steinway B, close microphone, no-sustain recording and recorded releases','author':'JH piano recordings / Versilian Community Sample Library; Sam Gossner library maintainer','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://github.com/sgossner/VCSL/tree/master/Chordophones/Zithers/Grand%20Piano,%20Steinway%20B','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','notes':'126 genuine NoSus body performances (42 whole-tone roots × 3 recorded velocities; one take each) and all 99 matching Rel samples (33 roots × 3 velocities; one take each). Every NoSus take remains available in Sostenuto as a source-derived infinite continuation and in Colpo as its original finite unlooped recording. File root is read from the recorded-note filename; only measured small source tuning corrections are allowed. VCSL README states CC0 for commercial software/sound use.','retrieved':datetime.now(timezone.utc).date().isoformat()})
 (samples/'map.json').write_text(json.dumps({'body':rows+colpo,'tail':tails,'counts':{'sostenuto_body':len(rows),'colpo_original':len(colpo),'release':len(tails),'roots':len(bykey),'velocity_layers':3,'takes_per_root_layer':1},'articulations':[('sostenuto','Sostenuto · sustain modale dalla presa',12),('colpo','Colpo · decadimento originale',13)]},indent=2,ensure_ascii=False)+'\n')
 (samples/'source-proof.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
 write_recipe(dest,'Steinway Bebop','Piano a coda Steinway B · close mic VCSL · dinamiche e release originali preservate',['bebop','piano','steinway','keys'],[r['root'] for r in rows],as_dyn=True,master=-4.2,release=240)
 return {'source_bodies':len(src_files),'release_samples':len(rel_files),'roots':len(bykey),'sostenuto_zones':len(rows),'colpo_zones':len(colpo)}

def build_bass(dest:Path):
 samples=dest/'samples';samples.mkdir(parents=True,exist_ok=True); inst=parse_sfz(SFZ)
 if inst.warnings:raise RuntimeError(f'bass SFZ parse warnings: {inst.warnings}')
 # Keep the authentic pitched performance map in Sostenuto/Colpo and all separately
 # sampled pluck noises as an available natural finite secondary articulation.
 body=[];colpo=[];attacks=[];tails=[];proof=[]; seen=set(); keyroots=defaultdict(list); dyn_groups=defaultdict(list)
 for r in inst.regions:
  src=r.sample
  if not src.exists():raise RuntimeError(f'missing SFZ sample {src}')
  rel=stored(src,samples,BASS); is_noise=src.parent.name=='noises'
  if is_noise:
   sig=(src.name,r.root,r.lokey,r.hikey,r.seq_position)
   if sig in seen:continue
   seen.add(sig)
   row={'file':rel,'root':r.root,'lo':r.lokey,'hi':r.hikey,'vel':[r.lovel,r.hivel],'take':(r.seq_position or 1)-1,'one_shot':True,'loop':'none','articulation':'colpo','pitched':False}
   row['articulation']=None;attacks.append(row);proof.append({'source_file':str(src),'original_file':rel,'source_sha256':digest(src),'kind':'noise_attack','sfz_root':r.root,'sfz_key_range':[r.lokey,r.hikey],'velocity':[r.lovel,r.hivel],'rr':r.seq_position,'rr_count':r.seq_length,'sfz_opcodes':r.opcodes,'duration_s':sf.info(src).duration});continue
  # Preserve actual RR and source pitch/key range from the SFZ; mapping is not octave-shifted.
  if src.parent.name!='pizz':raise RuntimeError(f'unexpected mapped bass sample {src}')
  key=(r.root,r.lovel,r.hivel,r.seq_position,src.name)
  if key in seen:continue
  seen.add(key);take=(r.seq_position or 1)-1
  lp,metrics=derive_stereo(src,samples/f'derived/sostenuto-{src.stem}.flac',r.root)
  drel=f'derived/sostenuto-{src.stem}.flac'
  base={'root':r.root,'lo':r.lokey,'hi':r.hikey,'vel':[r.lovel,r.hivel],'take':take,'loop':lp,'articulation':'sostenuto','tune_cents':r.tune_cents}
  body.append({'file':drel,**base})
  colpo.append({'file':rel,'root':r.root,'lo':r.lokey,'hi':r.hikey,'vel':[r.lovel,r.hivel],'take':take,'one_shot':True,'loop':'none','articulation':'colpo','tune_cents':r.tune_cents})
  keyroots[r.root].append((r.lovel,r.hivel,take))
  amp=dsp.momentary_max(Audio.load(src,sr=SR).data,SR)
  dyn_groups[r.root].append((r.lovel,r.hivel,amp,src.name))
  proof.append({'source_file':str(src),'original_file':rel,'source_sha256':digest(src),'sfz_root':r.root,'sfz_key_range':[r.lokey,r.hikey],'velocity':[r.lovel,r.hivel],'rr_position':r.seq_position,'rr_count':r.seq_length,'sfz_opcodes':r.opcodes,'source_seconds':sf.info(src).duration,'derived_file':drel,**metrics})
 gain_offsets={}
 for root,items in dyn_groups.items():
  layers=[]
  for vel in sorted({(x[0],x[1]) for x in items}):layers.append((vel,float(np.median([x[2] for x in items if (x[0],x[1])==vel]))))
  floor=None;targets={}
  for vel,lev in layers:
   target=lev if floor is None else max(lev,floor+1.5);targets[vel]=target;floor=target
  for row in body+colpo:
   if row['root']==root and tuple(row['vel']) in targets:
    base=next((x[2] for x in items if (x[0],x[1])==tuple(row['vel']) and Path(x[3]).stem in Path(row['file']).stem),None)
    if base is None: base=next(lev for vel,lev in layers if vel==tuple(row['vel']))
    row['gain_db']=round(targets[tuple(row['vel'])]-base,2)
 credit={'source':'1958 Otto Rubner double bass pizzicato · D. Smolken performance and SFZ map','author':'D. Smolken (performer/mapper); Otto Rubner instrument; recording by Ludwik Zamenhof per upstream records','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://github.com/sfzinstruments/dsmolken.double-bass','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','notes':'Upstream repository identifies this as the 1958 Otto Rubner instrument, states royalty-free commercial and non-commercial use, and links CC0-1.0. Original SFZ plus all pizzicato note and noise samples mapped by its pizz program are bundled; all 4 velocity layers, all mapped takes/RRs, and all separate noises are preserved. Per-root gain offsets are shared across takes within a velocity layer and only enforce monotone recorded dynamics. No standalone release samples are present in this pizz SFZ; note-off uses the natural instrument amp release.','retrieved':datetime.now(timezone.utc).date().isoformat()}
 source_doc(samples,[BASS/'LICENSE',BASS/'d_smolken_rubner_bass_pizz.sfz',BASS/'README.md'] if (BASS/'README.md').exists() else [BASS/'LICENSE',SFZ],credit)
 (samples/'map.json').write_text(json.dumps({'body':body+colpo,'attack':attacks,'tail':tails,'counts':{'sostenuto_source_regions':len(body),'colpo_source_regions':len(colpo),'noise_attack_regions':len(attacks),'pizz_notes':len(keyroots),'source_roots':sorted(keyroots)},'articulations':[('sostenuto','Sostenuto · sustain modale dalla presa',12),('colpo','Colpo · pizzicato naturale e rumori',13)]},indent=2,ensure_ascii=False)+'\n')
 (samples/'source-proof.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
 write_recipe(dest,'Contrabbasso Rubner Bebop','Contrabbasso pizzicato Rubner · D. Smolken · quattro riprese e dinamiche originali',['bebop','double-bass','pizzicato','bass'],[r['root'] for r in body],as_dyn=True,master=0,release=310)
 return {'source_regions':len(inst.regions),'sostenuto_zones':len(body),'colpo_zones':len(colpo),'roots':len(keyroots),'source_round_robins':sum(1 for r in inst.regions if r.sample.parent.name=='pizz')}

def write_recipe(dest,title,subtitle,tags,roots,as_dyn,master,release):
 code=f'''"""{title} · recorded performance with a same-source modal continuation."""
import json
from pathlib import Path
from libero import Sound
sound=Sound(title={title!r},subtitle={subtitle!r},tags={tags!r},roots={sorted(set(roots))!r},sample_rate=48000)
mapping=json.loads((Path(__file__).parent/'samples/map.json').read_text())
sound.articulations([{{'id':'sostenuto','name':'Sostenuto · sustain modale dalla presa','key':12}},{{'id':'colpo','name':'Colpo · suono originale naturale','key':13}}])
sound.multisample('body',mapping['body'],as_dyn={as_dyn},process={{'tune':'source','ladder':'smooth','ladder_max_db':2.5,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'}})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=1500,onset_ms=0)
if mapping.get('attack'):
 sound.multisample('attack',mapping['attack'],as_dyn=False,process={{'tune':'source','ladder':'keep','peak_db':-8,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'}})
if mapping.get('tail'):
 sound.multisample('tail',mapping['tail'],as_dyn=False,process={{'tune':'source','ladder':'keep','peak_db':-10,'align_ms':0,'pre_ms':0,'fade_ms':8,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'}})
sound.defaults(mode='Poli',glide=0,voices=32,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release={release},lvl_body=0,lvl_tail=-1,lvl_attack=-60,lvl_air=-60,vel_sens=.35,master={master},tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix=0,rev_decay=1,rev_size=.30,rev_damp=.50,caldi_mode='Spento')
'''
 (dest/'sound.py').write_text(code)

def calibrate_bass_body(dest:Path):
 """Tune the actual continued bass body by a bounded per-source correction."""
 samples=dest/'samples';mp=samples/'map.json';m=json.loads(mp.read_text());proof=[]
 for row in m['body']:
  if row.get('articulation')!='sostenuto':continue
  path=samples/row['file'];x,sr=sf.read(path,always_2d=True,dtype='float64');lp=row['loop']
  idx=np.arange(round(1.0*sr),round(1.5*sr));idx=np.where(idx>=lp['end'],lp['start']+(idx-lp['start'])%(lp['end']-lp['start']),idx)
  seg=x[idx].mean(axis=1);seg-=seg.mean();nfft=524288;sp=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),nfft));hz=np.fft.rfftfreq(nfft,1/sr)
  expected=440*2**((int(row['root'])-69)/12);candidates=[]
  for harmonic in (1,2,3,4):
   centre=expected*harmonic;bins=np.flatnonzero((hz>centre*2**(-150/1200))&(hz<centre*2**(150/1200)))
   k=int(bins[np.argmax(sp[bins])]);q=np.log(np.maximum(sp[k-1:k+2],1e-30));d=float(np.clip(.5*(q[0]-q[2])/(q[0]-2*q[1]+q[2]+1e-30),-.5,.5))
   candidates.append(((k+d)*sr/nfft/harmonic,float(sp[k]),harmonic))
  strongest=max(q[1] for q in candidates);chosen=candidates[0] if candidates[0][1]>strongest*.05 else max(candidates,key=lambda q:q[1])
  cents=1200*math.log2(chosen[0]/expected);tune=float(row.get('tune_cents',0))-cents
  if abs(tune)>100:raise RuntimeError(f'bass stable-body correction exceeds ±100 cents {row["file"]}: {tune:.2f}')
  row['tune_cents']=round(tune,2)
  proof.append({'file':row['file'],'root':row['root'],'vel':row['vel'],'take':row['take'],'measured_hz':chosen[0],'offset_cents':cents,'applied_tune_cents':round(tune,2),'window_s':[1.0,1.5],'source_unchanged':True})
  match=[z for z in m['body'] if z.get('articulation')=='colpo' and z['root']==row['root'] and z['vel']==row['vel'] and z['take']==row['take']]
  if len(match)!=1:raise RuntimeError(f'bass Colpo calibration match count {len(match)} for {row}')
  match[0]['tune_cents']=round(tune,2)
 mp.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n');(samples/'stable-body-tuning-v1.json').write_text(json.dumps(proof,indent=2)+'\n')

def _estimate_static_pitch(x,sr,root,start_s,end_s):
 """Estimate a recorded note centre from its first clear partials, not the attack."""
 if x.ndim==2:x=x.mean(axis=1)
 a=max(0,round(start_s*sr));b=min(len(x),round(end_s*sr))
 seg=np.asarray(x[a:b],dtype=np.float64)
 if len(seg)<round(.12*sr):raise RuntimeError('pitch-calibration window is shorter than 120 ms')
 seg=seg-np.mean(seg);nfft=1048576
 sp=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),nfft));hz=np.fft.rfftfreq(nfft,1/sr)
 expected=440*2**((int(root)-69)/12);candidates=[]
 for harmonic in (1,2,3,4,5,6):
  centre=expected*harmonic
  bins=np.flatnonzero((hz>centre*2**(-95/1200))&(hz<centre*2**(95/1200)))
  if len(bins)==0:continue
  k=int(bins[np.argmax(sp[bins])]);q=np.log(np.maximum(sp[k-1:k+2],1e-30));den=q[0]-2*q[1]+q[2]
  delta=float(np.clip(.5*(q[0]-q[2])/(den if abs(den)>1e-20 else 1e-20),-.5,.5))
  candidates.append(((k+delta)*sr/nfft/harmonic,float(sp[k]),harmonic))
 if not candidates:raise RuntimeError(f'no stable partial found for MIDI {root}')
 top=max(q[1] for q in candidates)
 chosen=candidates[0] if candidates[0][1]>=top*.05 else max(candidates,key=lambda q:q[1])
 cents=1200*math.log2(chosen[0]/expected)
 return chosen[0],cents,chosen[2]

def calibrate_piano_body(dest:Path):
 """Apply bounded pitch-centre correction separately to sustain and raw strike."""
 samples=dest/'samples';mp=samples/'map.json';m=json.loads(mp.read_text());proof=[]
 sost=[r for r in m['body'] if r.get('articulation')=='sostenuto']
 col=[r for r in m['body'] if r.get('articulation')=='colpo']
 for row in sost:
  src=samples/row['file'];x,sr=sf.read(src,always_2d=True,dtype='float64');lp=row['loop']
  start=(lp['start']/sr)+.20;end=min(start+.90,(lp['end']/sr)-.04)
  hz,cents,harm=_estimate_static_pitch(x,sr,row['root'],start,end)
  correction=float(row.get('tune_cents',0))-cents
  if abs(correction)>100:raise RuntimeError(f'piano stable-body correction exceeds ±100 cents {row["file"]}: {correction:.2f}')
  row['tune_cents']=round(correction,2)
  proof.append({'articulation':'sostenuto','file':row['file'],'root':row['root'],'velocity':row['vel'],'measured_hz':hz,'offset_cents':cents,'applied_tune_cents':round(correction,2),'partial_used':harm,'window_s':[round(start,4),round(end,4)],'source_unchanged':True})
 for row in col:
  src=samples/row['file'];x,sr=sf.read(src,always_2d=True,dtype='float64')
  hz,cents,harm=_estimate_static_pitch(x,sr,row['root'],.15,.65)
  correction=float(row.get('tune_cents',0))-cents
  if abs(correction)>100:raise RuntimeError(f'piano strike correction exceeds ±100 cents {row["file"]}: {correction:.2f}')
  row['tune_cents']=round(correction,2)
  proof.append({'articulation':'colpo','file':row['file'],'root':row['root'],'velocity':row['vel'],'measured_hz':hz,'offset_cents':cents,'applied_tune_cents':round(correction,2),'partial_used':harm,'window_s':[.15,.65],'source_unchanged':True})
 mp.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n');(samples/'stable-body-tuning-v1.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')

def figure(slug):
 if slug=='bebop-steinway':
  title='Steinway Bebop';desc='Steinway B piano strings and close microphone; key groups mark the whole-tone sampled roots, with separate struck entry, source-derived sustain continuation and recorded release.'
  bits=['<path d="M82 316Q111 179 235 130L422 155L439 184Q370 226 338 368L123 401Z" fill="#f2eee8" stroke-width="1.4"/>','<path d="M131 342L387 197M141 357L397 212M151 372L407 227M164 381L416 240" stroke-width=".6"/>','<path d="M94 300L340 142M111 333L389 163" stroke="#b8924f" stroke-width="1.5"/>','<path d="M154 301L361 186M174 310L375 196M192 322L387 208" stroke-width="1.1"/>','<path d="M215 102L294 109L319 126L237 120Z" fill="#b8924f" stroke-width="1"/>']
 else:
  title='Contrabbasso Rubner Bebop';desc='A large upright-bass body and four strings; marks indicate C-G-D-A fifth tuning, the plucked note attack, and the same-take modal sustain.'
  bits=['<path d="M256 105C205 105 163 146 165 215C166 273 208 294 197 342C186 391 206 431 256 431C306 431 326 391 315 342C304 294 346 273 347 215C349 146 307 105 256 105Z" fill="#f2eee8" stroke-width="1.6"/>','<path d="M256 105V431M244 76H268L272 154H240Z" stroke-width="1.2"/>','<path d="M228 139V412M242 132V417M256 130V419M270 132V417M284 139V412" stroke-width=".7"/>','<path d="M190 286H322M198 329H314" stroke="#b8924f" stroke-width="1.4"/>','<path d="M223 90V127M239 84V126M255 82V126M271 84V126" stroke-width="1"/>']
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#292630" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>{desc}</desc>'+''.join(bits)+'</svg>'

def make_notes(dest,title,subtitle,counts,report):
 lic=json.loads((dest/'samples/credits.json').read_text())[0]
 warnings='\n'.join('- '+x for x in report['lint'] if x.startswith('WARN')) or 'Nessun WARN.'
 if dest.name=='bebop-steinway':
  explanation='Ogni campione di sustain ha una correzione statica misurata sul corpo stabile del loop; la corrispondente presa Colpo è misurata separatamente tra 0,15 e 0,65 s. Correzioni, parziali usati e finestre sono in `samples/stable-body-tuning-v1.json` (tutte entro ±100 cent). Restano intatti file WAV e movimenti d’intonazione nel gesto; i quattro WARN descrivono residui di 8–10 cent fra dinamiche per file diversi e la misura del continuo non corretto in alcuni strati, non il centro accordato della nota sostenuta. I 99 campioni originali di release più bassi non superano sempre la soglia analitica di coda udibile al layer più piano: restano nella mappa e attivabili.'
 else:
  explanation=('Gli onset WARN sono differenze temporali misurate nelle esecuzioni pizzicate originali, mantenute senza allineamento artificiale. I WARN tuning fra dinamiche/RR derivano da intonazione e gesto differenti nelle singole riprese; per le zone Sostenuto la correzione statica del centro del corpo misurata a 1,0–1,5 s è applicata alla corrispondente take Colpo, senza processare i file sorgente. I WARN tuning-curve descrivono la dispersione fra roots registrati; le take restano distinte. Il WARN takes segnala alta correlazione in una coppia di take G1 ma entrambi i file originali sono conservati. Il WARN loudness è uno scarto di circa 3,6 dB dello strato superiore A#1 dopo il bilanciamento per root; non è stato attenuato separatamente per non alterare il rapporto registrato. I 58 sample di noise dell’SFZ sono conservati come attacchi one-shot non intonati.')
 (dest/'notes.md').write_text(f'''# {title}\n\n{subtitle}\n\n## Provenienza e disegno\n\n- Fonte: {lic['source']}\n- Autore: {lic['author']}\n- Licenza fonte: {lic['license']} — [fonte primaria]({lic['url']}) e [licenza]({lic['license_url']}).\n- Conteggi mappa: {json.dumps(counts,ensure_ascii=False)}. Originali e SHA-256 per ogni file sono in `samples/source-proof.json`; copia dei documenti sorgente in `samples/source-reference/`.\n- Sostenuto conserva i primi 180 ms suonati e passa alla continuazione modale fase-coerente derivata dalla stessa esecuzione. La nota finale non è un decadimento naturale infinito. Colpo riproduce il file originale non esteso come one-shot. Per il contrabbasso, la correzione statica di ogni continuazione viene misurata sul corpo finale tra 1,0 e 1,5 s e applicata anche alla sua take Colpo corrispondente; i valori sono in `samples/stable-body-tuning-v1.json` e restano entro ±100 cent.\n- Il contatore RR avanza fra le prese originali nelle note ripetute e torna alla prima dopo 1500 ms di silenzio (`rr_reset_ms=1500`). La prova nativa delle quattro prese del contrabbasso è in `~/Libero/demo/bebop-v1/rhythm-keys-bass/bebop-contrabbasso-rr-reset-check.json`.\n- Release piano originali mantenuti come tail; i campioni originali, alcuni registrati molto bassi, hanno un offset comune +18 dB esplicitato in `samples/map.json` per portarli sopra la soglia di silenzio; livelli relativi e file originali restano documentati. Il SFZ pizz bass non contiene regioni di release.\n\n## QA nativa\n\n{json.dumps(report,ensure_ascii=False,indent=2)}\n\nWARN: {warnings}\n\nMotivo tuning WARN: {explanation}\n\nLe misure non sostituiscono l'ascolto e non certificano preferenza o realismo percepito.\n''')

def render_one(slug,dest,counts):
 findings=lint_bundle(dest/'build');lines=[f.line() for f in findings];levels=Counter(f.level for f in findings)
 (dest/'lint.txt').write_text('\n'.join(lines)+'\n')
 if levels['FAIL']:raise RuntimeError(f'{slug} lint FAIL: {lines}')
 renderer=str(HOME/'.local/bin/libero-render'); phrase='48:0:.28:68,55:.28:.24:52,60:.58:.28:88,64:.86:.42:92,67:1.00:.25:74,60:1.28:.42:82,55:1.72:.28:62,48:2:.60:80,52:2.28:.24:63,55:2.56:.24:87,59:2.84:.42:92,60:3.2:.70:78'
 notes=[40,60,84] if slug=='bebop-steinway' else [24,38,52]
 native=[]
 def render(name,note_string,tail='1'):
  path=dest/'build'/f'{name}.wav';subprocess.run([renderer,'--sound',str(dest),'--out',str(path),'--notes',note_string,'--tail',tail],check=True,capture_output=True,text=True)
  x,sr=sf.read(path,always_2d=True);peak=float(np.max(np.abs(x)));rms=float(np.sqrt(np.mean(x*x)));mono=x.mean(axis=1);rmono=float(np.sqrt(np.mean(mono*mono)))
  stat={'name':name,'file':str(path),'seconds':len(x)/sr,'peak_dbfs':20*math.log10(peak+1e-20),'rms_dbfs':20*math.log10(rms+1e-20),'mono_loss_db':20*math.log10(rmono/(rms+1e-20)),'clipped_samples':int(np.count_nonzero(np.abs(x)>=1))}
  if name.startswith('held-'):
   seg=x[int(10*sr):int(59*sr)];stat['held_rms_dbfs_10_59s']=20*math.log10(float(np.sqrt(np.mean(seg*seg)))+1e-20)
  native.append(stat);return path,stat
 _,phrase_stats=render('phrase',phrase,'2')
 shutil.copy2(dest/'build/phrase.wav',DEMO/f'{slug}-phrase.wav')
 (DEMO/f'{slug}-phrase.png').write_bytes(analysis.spectrogram(Audio(sf.read(dest/'build/phrase.wav')[0],SR),title=slug+' rhythm phrase'))
 for label,key in zip(('held-low','held-mid','held-high'),notes):
  render(label,f'{key}:0:60:96','2')
 for name,chordkeys in [('dense-chord-8x127',[48,52,55,59,60,64,67,72]) if slug=='bebop-steinway' else ('bass-octave-127',[24,31,38,45])]:
  ns=','.join(f'{k}:0:4:127' for k in chordkeys);_,st=render(name,ns,'1')
  if st['peak_dbfs']>-3:raise RuntimeError(f'{slug} dense chord headroom failure {st}')
 if slug=='bebop-steinway':render('colpo-articulation','60:0:.25:96','3')
 else:render('colpo-articulation','45:0:.25:96','3')
 manifest=json.loads((dest/'build/manifest.json').read_text());seams=[];loops=[]
 for z in manifest.get('zones',[]):
  if z.get('layer')=='body' and z.get('loop'):
   lp=z['loop'];loops.append((lp['end']-lp['start'])/SR);seams.append(_load(dest/'build',z,False).loop_seam_db)
 if seams and max(seams)>-30:raise RuntimeError(f'{slug} loop seam exceeds -30dB: {max(seams)}')
 if any(x['peak_dbfs']>-.2 or x['clipped_samples'] for x in native):raise RuntimeError(f'{slug} clip/headroom issue')
 if any(x.get('held_rms_dbfs_10_59s',0)<-50 for x in native if x['name'].startswith('held-')):raise RuntimeError(f'{slug} held note body too quiet')
 source_hash=library.source_hash(dest)
 if source_hash!=manifest.get('source_hash'):raise RuntimeError(f'{slug} stale build: source hash mismatch')
 report={'slug':slug,'counts':counts,'zones':len(manifest.get('zones',[])),'source_hash':source_hash,'compiled_source_hash':manifest.get('source_hash'),'source_fresh':True,'lint_counts':{k:levels[k] for k in ('FAIL','WARN','INFO')},'lint':lines,'body_loop_count':len(loops),'body_loop_min_seconds':min(loops) if loops else None,'body_loop_worst_seam_db':max(seams) if seams else None,'native_renders':native,'listening_limit':'Numerical/render checks only; not a perceptual listening claim.'}
 (dest/'verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 return report

def main():
 DEMO.mkdir(parents=True,exist_ok=True)
 builders={'bebop-steinway':build_piano,'bebop-contrabbasso':build_bass}
 selected=sys.argv[1:] or list(SLUGS)
 if set(selected)-set(SLUGS):raise SystemExit(f'unknown requested slugs: {set(selected)-set(SLUGS)}')
 for slug in selected:
  builder=builders[slug]
  dest=BANK/slug
  if dest.exists() and not (dest/'builder-owner.json').exists():raise RuntimeError(f'refusing unowned folder {dest}')
  dest.mkdir(parents=True,exist_ok=True);(dest/'builder-owner.json').write_text(json.dumps({'builder':Path(__file__).name,'schema':1},indent=2)+'\n')
  info=builder(dest)
  if slug=='bebop-contrabbasso':calibrate_bass_body(dest)
  if slug=='bebop-steinway':calibrate_piano_body(dest)
  svg=figure(slug);err=validate_svg(svg)
  if err:raise RuntimeError(f'{slug} invalid SVG: {err}')
  (dest/'figure.svg').write_text(svg)
  result=compile_sound(dest,jobs=1);print(f'COMPILE {slug}: {result.text()}',flush=True)
  if not result.ok:raise RuntimeError(f'compile failed: {slug}')
  title='Steinway Bebop' if slug=='bebop-steinway' else 'Contrabbasso Rubner Bebop'
  subtitle='Steinway B · close mic · NoSus/Rel VCSL' if slug=='bebop-steinway' else '1958 Otto Rubner · pizzicato D. Smolken'
  report=render_one(slug,dest,info);make_notes(dest,title,subtitle,info,report)
  print(f'QA {slug}: {report["lint_counts"]}, source_fresh, {len(report["native_renders"])} native renders',flush=True)
  (DEMO/f'{slug}-verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 print('Completed Bebop keys/bass v1',flush=True)
if __name__=='__main__':main()
