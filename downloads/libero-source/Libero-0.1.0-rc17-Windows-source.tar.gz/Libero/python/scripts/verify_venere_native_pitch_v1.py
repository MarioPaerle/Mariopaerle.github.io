"""Native chromatic mapping audit, separate from source and loop lint."""
from pathlib import Path
import argparse
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, render, library

parser=argparse.ArgumentParser()
parser.add_argument('--slugs',nargs='+')
args=parser.parse_args()
BANK=Path.home()/'Libero/banks/venere'
OUT=Path.home()/'Libero/demo/venere-v1'
rows=[]
errors=[]
for folder in sorted(BANK.iterdir()):
    if not (folder/'build/manifest.json').is_file():continue
    slug=folder.name
    if args.slugs and slug not in args.slugs:continue
    m=json.loads((folder/'build/manifest.json').read_text())
    if slug=='quasar-arpeggio':
        rows.append({'slug':slug,'test':'Documented root/fifth/octave arpeggio; requires interval-by-time audit, not a single f0 estimate.'})
        continue
    zones=[z for z in m.get('zones',[])if z['layer']=='body']
    arts=m.get('articulations',[])
    if arts:zones=[z for z in zones if z.get('articulation')==arts[0]['id']]
    keys=sorted({v for z in zones for v in (z['root'],z['lo'],z['hi']) if 24<=v<=84}) or [24,31,36,43,48,55,60,67,72,79,84]
    spacing=2.65
    seq=[(k,i*spacing,2.5,v)for i,(k,v)in enumerate((k,v)for k in keys for v in (52,110))]
    file=OUT/slug/'native-chromatic-pitch.wav'
    render.render(folder,file,seq,{'rev_mix':0,'amp_attack':2,'amp_release':5,'lvl_tail':-60,'lvl_air':-60},tail=.1)
    a=Audio.load(file);x=a.data.astype(float)
    if x.ndim>1:x=x.mean(1)
    result=[]
    for key,start,dur,vel in seq:
        y=x[round((start+1.2)*a.sr):round((start+2.3)*a.sr)]
        expected=440*2**((key-69)/12)
        n=524288
        hz=np.fft.rfftfreq(n,1/a.sr)
        sp=abs(np.fft.rfft(y*np.hanning(len(y)),n))
        fundamental_expected=expected
        # Reese's intentionally beating first partial can cancel in the mono
        # sum. The unmodulated second partial controls keyboard mapping; retain
        # the first-partial estimate separately, rather than reporting it as
        # a pitch error or retuning the designed beat away.
        if slug=='nido-reese':expected*=2
        candidates=np.flatnonzero((hz>expected*.96)&(hz<expected*1.04))
        k=int(candidates[np.argmax(sp[candidates])])
        q=np.log(np.maximum(sp[k-1:k+2],1e-30))
        delta=float(np.clip(.5*(q[0]-q[2])/(q[0]-2*q[1]+q[2]+1e-30),-.5,.5))
        cents=float(1200*np.log2((k+delta)*a.sr/n/expected))
        rms=float(10*np.log10(np.mean(y*y)+1e-30))
        row={'key':key,'velocity':vel,'cents':cents,'body_rms_dbfs':rms}
        if slug=='nido-reese':
            ix=np.flatnonzero((hz>fundamental_expected*.96)&(hz<fundamental_expected*1.04))
            j=int(ix[np.argmax(sp[ix])]);z=np.log(np.maximum(sp[j-1:j+2],1e-30))
            d=float(np.clip(.5*(z[0]-z[2])/(z[0]-2*z[1]+z[2]+1e-30),-.5,.5))
            row.update(pitch_control='stable second harmonic',mono_beating_fundamental_peak_cents=float(1200*np.log2((j+d)*a.sr/n/fundamental_expected)))
        result.append(row)
    worst=max(abs(q['cents'])for q in result)
    fresh=library.source_hash(folder)==m['source_hash']==json.loads((folder/'build/manifest.json').read_text())['source_hash']
    failures=[q for q in result if abs(q['cents'])>5 or q['body_rms_dbfs']<-60]
    if failures:errors.append({'slug':slug,'failures':failures})
    if not fresh:errors.append({'slug':slug,'error':'build replaced or source changed during audit'})
    rows.append({'slug':slug,'source_hash':m['source_hash'],'fresh':fresh,'max_abs_cents':worst,'notes':result})
    print(slug,round(worst,3),'cents',len(result),'notes',flush=True)
report={'voices':rows,'errors':errors,'limitations':'Finite-window peaks need separate controls for intentional ensembles or time-varying arpeggios. Technical pitch checks do not establish musical taste.'}
(OUT/'native-pitch-audit.json').write_text(json.dumps(report,indent=2)+'\n')
if errors:raise SystemExit(1)
