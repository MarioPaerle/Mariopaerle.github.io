"""Native Libero checks and listening exports for the private Abletunes 808 remap."""
from __future__ import annotations
import json, subprocess, math
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy.signal import periodogram
from libero import Audio, analysis
from libero.lint import lint_bundle

HOME=Path.home()/"Libero"; BANK=HOME/"banks"/"bassi"
OUT=HOME/"demo"/"bassi-808-v3"; RENDER=Path.home()/".local/bin/libero-render"
SLUGS=("808-notte","808-colpo","808-cavo")
PHRASE=[(28,0,.55,62),(31,.5,.55,70),(33,1,.55,78),(36,1.5,.55,88),(38,2,.55,96),
        (36,2.5,.55,88),(33,3,.55,78),(31,3.5,.55,70),(28,4,.55,62),
        (28,5.1,.2,64),(28,5.45,.2,112)]

def render(folder,name,events,tail):
    out=OUT/f"{folder.name}-{name}.wav"
    text=",".join(f"{n}:{s}:{d}:{v}" for n,s,d,v in events)
    cp=subprocess.run([str(RENDER),"--sound",str(folder),"--out",str(out),"--notes",text,
                       "--tail",str(tail)],text=True,capture_output=True)
    if cp.returncode: raise RuntimeError(cp.stderr or cp.stdout)
    return out

def stats(path):
    x,sr=sf.read(path,always_2d=True,dtype="float64"); mono=x.mean(axis=1)
    peak=float(np.max(np.abs(x))); rms=float(np.sqrt(np.mean(x*x))); dc=float(np.max(np.abs(np.mean(x,axis=0))))
    st=np.sqrt(np.mean(((x[:,0]-x[:,-1])/2)**2)); mid=np.sqrt(np.mean(((x[:,0]+x[:,-1])/2)**2))
    win=.1
    windows=[]
    for t in np.arange(0,len(x)/sr-win,.25):
        seg=mono[int(t*sr):int((t+win)*sr)]
        windows.append((round(float(t),2),round(20*np.log10(np.sqrt(np.mean(seg**2))+1e-15),1)))
    return x,sr,dict(duration_s=len(x)/sr,channels=x.shape[1],peak_dbfs=20*np.log10(peak+1e-15),
        rms_dbfs=20*np.log10(rms+1e-15),dc_dbfs=20*np.log10(dc+1e-15),clipped=int(np.sum(np.abs(x)>=1)),
        side_mid_db=20*np.log10((st+1e-15)/(mid+1e-15)),rms_windows_100ms_step250ms=windows)

def dominant_f0(y,sr,expected,start,seconds=1.0):
    a=int(start*sr); z=np.asarray(y[a:a+int(seconds*sr)],dtype=np.float64)
    if len(z)<int(.5*sr) or np.sqrt(np.mean(z*z))<1e-5:return None
    z-=np.mean(z); nfft=1 << int(np.ceil(np.log2(len(z)*8)))
    spec=np.abs(np.fft.rfft(z*np.hanning(len(z)),nfft))**2; fr=np.fft.rfftfreq(nfft,1/sr)
    band=(fr>=expected*.94)&(fr<=expected*1.06); ks=np.flatnonzero(band)
    k=ks[int(np.argmax(spec[ks]))]; yy=np.log(spec[k-1:k+2]+1e-40)
    d=.5*(yy[0]-yy[2])/(yy[0]-2*yy[1]+yy[2]); f=(k+d)*sr/nfft
    return {"hz":float(f),"cents_from_equal_tuning":float(1200*np.log2(f/expected))}

def broad_f0(y,sr,start,seconds=.12):
    z=np.asarray(y[int(start*sr):int((start+seconds)*sr)],dtype=np.float64)
    z-=np.mean(z); nfft=1 << int(np.ceil(np.log2(len(z)*8)))
    spec=np.abs(np.fft.rfft(z*np.hanning(len(z)),nfft))**2; fr=np.fft.rfftfreq(nfft,1/sr)
    band=(fr>=28)&(fr<=150); ks=np.flatnonzero(band); k=ks[int(np.argmax(spec[ks]))]
    yy=np.log(spec[k-1:k+2]+1e-40); d=.5*(yy[0]-yy[2])/(yy[0]-2*yy[1]+yy[2])
    return float((k+d)*sr/nfft)

def source_measurements(folder,manifest):
    p=folder/"samples"/"body.wav"; x,sr=sf.read(p,always_2d=True,dtype="float64"); y=x.mean(axis=1)
    zone=manifest["zones"][0]; root=zone["root"]; expected=440*2**((root-69)/12)
    pitches={str(t):dominant_f0(y,sr,expected,t) for t in (.3,.8,1.5,2.5)}
    spectral={}
    for label,(a,b) in {"attack":(.05,.35),"body":(.5,1.0),"late":(1.5,2.2)}.items():
        z=y[int(a*sr):int(b*sr)]; spec=np.abs(np.fft.rfft(z*np.hanning(len(z)),2**18))**2; fr=np.fft.rfftfreq(2**18,1/sr)
        total=spec.sum()+1e-30
        spectral[label]={name:float(spec[(fr>=lo)&(fr<hi)].sum()/total) for name,lo,hi in
            (("20_60Hz",20,60),("60_150Hz",60,150),("150_500Hz",150,500),("500_1500Hz",500,1500),("1500_5000Hz",1500,5000))}
    peak=float(np.max(np.abs(x)));dc=float(np.max(np.abs(x.mean(axis=0))))
    return {"duration_s":len(y)/sr,"sample_rate":sr,"channels":x.shape[1],"peak_dbfs":20*np.log10(peak+1e-15),
        "dc_dbfs":20*np.log10(dc+1e-15),"stereo_correlation":float(np.corrcoef(x.T)[0,1]),
        "f0_at_root_hz":expected,"f0_estimates":pitches,"spectral_band_shares":spectral}

def main():
    OUT.mkdir(parents=True,exist_ok=True); reports={}; previews=[]; phrase_stats={}
    for slug in SLUGS:
        folder=BANK/slug; manifest=json.loads((folder/"build"/"manifest.json").read_text())
        source=json.loads((folder/"samples"/"credits.json").read_text())[0]
        zone=manifest["zones"][0]; srinfo=sf.info(str(folder/"samples"/"body.wav"))
        phrase=render(folder,"phrase",PHRASE,4.0)
        short=render(folder,"noteoff-350ms",[(zone['root'],0,.35,100)],19.0)
        held=render(folder,"hold-12s",[(zone['root'],0,12,100)],7.0)
        glide=render(folder,"mono-glide",[(zone['root'],0,1.2,100),(zone['root']+7,.6,.65,100)],1.0)
        xp,srp,sp=stats(phrase); xs,srs,ss=stats(short); xh,srh,sh=stats(held); xg,srg,sg=stats(glide)
        sm=source_measurements(folder,manifest)
        # One comparison-only constant per sound; installed levels and audio are untouched.
        active=xp[:int(6.0*srp)]; loud=float(np.sqrt(np.mean(active*active)))
        phrase_stats[slug]=dict(rms=loud,raw_rms_db=20*np.log10(loud+1e-15),
                                raw_peak_db=sp['peak_dbfs'],raw_clips=sp['clipped'])
        (OUT/f"{slug}-spectrogram.png").write_bytes(analysis.spectrogram(Audio(xp.astype(np.float32),srp),title=f"{slug} · native Libero phrase"))
        from libero.multisample import true_onset
        body=xs.mean(axis=1)
        onset=true_onset(body,srs)
        gm=xg.mean(axis=1)
        glide_f0={str(t):broad_f0(gm,srg,t) for t in (.30,.48,.56,.60,.63,.66,.70,.74,.80,.90)}
        release_rms={str(t):float(20*np.log10(np.sqrt(np.mean(body[int(t*srs):int((t+.02)*srs)]**2))+1e-20))
                     for t in (.35,.37,.39,.41,.43,.45)}
        findings=lint_bundle(folder/"build")
        reports[slug]={"source_file":source["source"],"source_samples":srinfo.frames,"source_duration_s":srinfo.duration,
            "source_channels":srinfo.channels,"source_measurements":sm,"manifest_zone":zone,"native_phrase":sp,
            "native_noteoff_350ms":ss,"native_12s_hold":sh,
            "native_mono_glide":sg,"glide_f0_hz_by_window_start_s":glide_f0,"noteoff_rms_dbfs_20ms":release_rms,
            "noteoff_350ms_sample_onset_guess_s":onset,"lint":[f.line() for f in findings],
            "license_class":source["license_class"],"comparison_phrase_rms":loud}
        previews.append((slug,xp,srp))
        source_y,sr_source=sf.read(folder/"samples"/"body.wav",always_2d=True,dtype="float32")
        (OUT/f"{slug}-source-spectrogram.png").write_bytes(analysis.spectrogram(Audio(source_y.mean(axis=1),sr_source),title=f"{slug} · original Abletunes recording"))
    target=np.mean([v['rms'] for v in phrase_stats.values()])
    matched=[]
    for slug,x,sr in previews:
        gain=target/phrase_stats[slug]['rms']; y=x*gain
        if np.max(np.abs(y))>=.98: raise RuntimeError(f"Matched comparison clips {slug}; lower target")
        phrase_stats[slug]['comparison_gain_db']=20*np.log10(gain)
        sf.write(OUT/f"{slug}-phrase-level-matched.wav",y,sr,subtype="PCM_24")
        matched.extend([y,np.zeros((int(.75*sr),y.shape[1]))])
    sf.write(OUT/"808-v3-phrase-level-matched.wav",np.concatenate(matched),previews[0][2],subtype="PCM_24")
    reports["matched_phrase_levels"]=phrase_stats
    reports["limitations"]=["The comparison exports use one constant gain per patch only; no EQ or dynamics processing.",
        "Auditory preference still requires listening. The source pack has one sample per instrument and no recorded velocity layers.",
        "Native engine preview verified sample note-off and measured mono glide, but is not a DAW mix audition."]
    (OUT/"verification.json").write_text(json.dumps(reports,indent=2)+"\n")
    for slug in SLUGS:
        p=BANK/slug/"notes.md"; x=reports[slug]; sm=x['source_measurements']
        pitch=[v for v in sm['f0_estimates'].values() if v]
        fmin=min(v['hz'] for v in pitch);fmax=max(v['hz'] for v in pitch)
        cmin=min(v['cents_from_equal_tuning'] for v in pitch);cmax=max(v['cents_from_equal_tuning'] for v in pitch)
        bands=sm['spectral_band_shares']
        source_body=bands['body']; source_attack=bands['attack']
        release_end=x['noteoff_rms_dbfs_20ms']['0.43']
        glide_start=x['glide_f0_hz_by_window_start_s']['0.3'];glide_end=x['glide_f0_hz_by_window_start_s']['0.9']
        report=f"""## Verifica tecnica

Il campione sorgente misura {sm['duration_s']:.2f} s, {sm['sample_rate']} Hz, {sm['channels']} canali. F0 misurata in quattro finestre stabili: {fmin:.3f}–{fmax:.3f} Hz ({cmin:+.1f}…{cmax:+.1f} cent rispetto al temperamento equabile); il recipe conserva il pitch della sorgente senza autotuning. Nel corpo 0,5–1,0 s le bande 20–60 / 60–150 / 150–500 Hz valgono {source_body['20_60Hz']*100:.1f}% / {source_body['60_150Hz']*100:.1f}% / {source_body['150_500Hz']*100:.1f}%; nell’attacco 0,05–0,35 s: {source_attack['20_60Hz']*100:.1f}% / {source_attack['60_150Hz']*100:.1f}% / {source_attack['150_500Hz']*100:.1f}%. Queste misure documentano il contrasto dei tre registrati; non sono un target di qualità.

Preview nativa Libero: picco {x['native_phrase']['peak_dbfs']:.1f} dBFS, RMS {x['native_phrase']['rms_dbfs']:.1f} dBFS, DC {x['native_phrase']['dc_dbfs']:.1f} dBFS, {x['native_phrase']['clipped']} campioni clippati. Il note-off a 350 ms scende a {release_end:.1f} dBFS nella finestra 80–100 ms successiva. La prova legato mono (root→+7 semitoni, glide 45 ms) misura circa {glide_start:.1f}→{glide_end:.1f} Hz. Il render tenuto 12 s lascia udibile il decadimento nativo fino al note-off. Lint: nessun FAIL/WARN.

Frase e tenute native, spettrogrammi del campione originale e del render, confronto level-matched e misure complete: `{OUT}`; report strutturato: `verification.json`. Il confronto applica solo un guadagno costante a ogni frase, senza EQ o compressione; non modifica i suoni installati. Una sola registrazione per strumento: la velocity controlla il livello, senza layer dinamici o round robin inventati. Le misure non possono decidere il gusto d’ascolto.
"""
        text=p.read_text().replace("QA_PLACEHOLDER",report)
        p.write_text(text)
    print(json.dumps(reports,indent=2))

if __name__=="__main__": main()
