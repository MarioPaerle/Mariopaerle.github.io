"""Native holds/headroom of the fourteen Giove palette programmes, using real defaults."""
from pathlib import Path
import argparse
import json
import sys
import numpy as np
import soundfile as sf
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero import library,render
from build_giove_luna14 import SYNTHS,MALLETS
BANK=Path.home()/'Libero/banks/giove'
OUT=Path.home()/'Libero/demo/giove-v1/default-safety'

def measure(path):
    x,sr=sf.read(path,always_2d=True)
    r={'peak_dbfs':float(20*np.log10(max(np.max(np.abs(x)),1e-15))),
       'clipped_samples':int(np.sum(np.abs(x)>=1)), 'finite':bool(np.isfinite(x).all())}
    if len(x)>=59*sr:
        r['late_rms_dbfs']=float(10*np.log10(np.mean(x[10*sr:59*sr]**2)+1e-30))
    return r

def main():
    parser=argparse.ArgumentParser()
    all_specs=[*SYNTHS,*MALLETS]
    parser.add_argument('--slugs',nargs='+',choices=[s['slug'] for s in all_specs])
    args=parser.parse_args()
    rows=[]
    for spec in all_specs:
        if args.slugs and spec['slug'] not in args.slugs:continue
        slug=spec['slug'];p=BANK/slug;o=OUT/slug;o.mkdir(parents=True,exist_ok=True)
        m=json.loads((p/'build/manifest.json').read_text());params=m['params']
        roots=sorted({z['root'] for z in m['zones']})
        low,high=(roots[0],roots[-1]) if roots else (36,84)
        mid=round((low+high)/2);holds=[];stacks=[];errors=[]
        for key in sorted({low,mid,high}):
            wav=o/f'hold-{key}.wav'
            render.render(p,wav,[(key,0,60,110)],{},tail=.5,timeout=240)
            r=measure(wav);holds.append(dict(key=key,**r))
            if not r['finite'] or r['clipped_samples'] or r['late_rms_dbfs'] < -50:
                errors.append(f'Default hold failed at {key}')
        keys=[round(low+(high-low)*i/7) for i in range(8)]
        assert len(set(keys))==8,(slug,keys)
        for label,overrides in [('default',{}),('maximum-dynamics',{'dyn_mode':'Manopola','dynamics':1})]:
            wav=o/f'stack8-{label}.wav'
            render.render(p,wav,[(k,0,5,127) for k in keys],overrides,tail=.5)
            r=measure(wav);stacks.append(dict(mode=label,keys=keys,events=8,**r))
            if not r['finite'] or r['clipped_samples'] or r['peak_dbfs'] > -3:
                errors.append(f'Eight-note headroom failed: {label}')
        if library.source_hash(p)!=m['source_hash']:errors.append('Source changed during render')
        rows.append(dict(slug=slug,source_hash=m['source_hash'],status='PASS' if not errors else 'FAIL',
                         default_parameters=params,holds=holds,stacks=stacks,errors=errors))
        print(slug,rows[-1]['status'],errors,flush=True)
    previous=OUT/'report.json'
    merged={r['slug']:r for r in json.loads(previous.read_text())['presets']} if previous.exists() else {}
    merged.update({r['slug']:r for r in rows})
    snapshots=[merged[s['slug']] for s in all_specs if s['slug'] in merged]
    for r in snapshots:
        if library.source_hash(BANK/r['slug'])!=r['source_hash']:
            r['status']='STALE';r['errors']=['Preset changed since native safety check']
    result=dict(status='PASS' if len(snapshots)==14 and all(r['status']=='PASS' for r in snapshots) else 'FAIL',
                method='Native installed renderer, actual default parameters. Three 60-second register holds and exactly eight distinct notes at v127, both defaults and maximum Manopola dynamics. Pitch and realism are separate checks.',presets=rows)
    result['presets']=snapshots
    (OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    return result['status']!='PASS'

if __name__=='__main__':raise SystemExit(main())
