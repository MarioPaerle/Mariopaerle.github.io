#!/usr/bin/env python3
"""Native default-Legato overlap and optional eight-voice headroom check."""
import json, math, sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from libero.render import render
from libero.audio import Audio

BANK=Path.home()/'Libero/banks/giove'; OUT=Path.home()/'Libero/demo/giove-v1'; OUT.mkdir(parents=True,exist_ok=True)
SLUGS=['theremin-vetro','theremin-ambra','trautonium-due-formanti','volkstrautonium-manuale','mixturtrautonium-quarta-aperta','mixturtrautonium-frange']
SR=48000
def db(x): return 20*math.log10(max(float(x),1e-12))
def rms(x): return float(np.sqrt(np.mean(np.asarray(x,dtype=np.float64)**2)))
rows=[]
for slug in SLUGS:
 folder=BANK/slug; manifest=json.loads((folder/'build'/'manifest.json').read_text())
 # Eight overlapped notes; the default mode and patch parameters are used.
 events=[(48,0.,1.0,100),(52,.48,1.0,100),(55,.96,1.0,100),(60,1.44,1.0,100),(64,1.92,1.0,100),(67,2.40,1.0,100),(72,2.88,1.0,100),(76,3.36,1.3,100)]
 note_arg=','.join(f'{n}:{t:.3f}:{d:.3f}:{v}' for n,t,d,v in events)
 p=OUT/f'{slug}-eight-legato-default.wav'; info=render(folder/'build',p,note_arg,tail=.6)
 a=Audio.load(p); x=np.asarray(a.data,dtype=np.float64)
 if x.ndim>1:x=x.mean(axis=1)
 trans=[]
 for _,t,_,_ in events[1:]:
  before=rms(x[int((t-.09)*SR):int((t-.025)*SR)])
  after=rms(x[int((t+.025)*SR):int((t+.09)*SR)])
  trans.append({'t':t,'rms_change_db':round(db(after)-db(before),2)})
 chord=OUT/f'{slug}-eight-poly-stress.wav'; cinf=render(folder/'build',chord,'48:0:3:127,52:0:3:127,55:0:3:127,60:0:3:127,64:0:3:127,67:0:3:127,72:0:3:127,76:0:3:127',params={'mode':'Poli','voices':16},tail=.2)
 ca=Audio.load(chord); cx=np.asarray(ca.data,dtype=np.float64)
 peak=db(np.max(np.abs(cx)))
 rows.append({'slug':slug,'source_hash':manifest.get('source_hash'),'default_legato_phrase':{'path':str(p),'engine':info,'finite':bool(np.isfinite(x).all()),'8_overlapped_notes':True,'transition_rms_changes_db':trans,'mode_default_from_sound_py':True},'poly_stress':{'path':str(chord),'engine':cinf,'peak_db':round(peak,2),'under_minus_3dBFS':bool(peak<=-3),'optional_not_default':True}})
 print(slug,'legato max ΔdB',max(abs(q['rms_change_db']) for q in trans),'poly peak',round(peak,2),flush=True)
(OUT/'legato-headroom-report.json').write_text(json.dumps({'method':'native engine renders; default Legato phrase is eight notes overlapping by 520 ms (duration 1.0 s); chord stress explicitly switches to Poli and is not the default instrument mode','presets':rows},indent=2,ensure_ascii=False)+'\n')
