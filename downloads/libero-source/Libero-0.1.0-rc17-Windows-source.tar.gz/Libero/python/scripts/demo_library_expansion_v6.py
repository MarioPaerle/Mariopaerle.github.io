"""Native v6 musical listening reels. Gain matching belongs to exports only."""
from pathlib import Path
import argparse,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import Audio,render,library
OUT=Path.home()/'Libero/demo/library-expansion-v6';OUT.mkdir(parents=True,exist_ok=True)
SETS={
'aria-sei-nuovi':[('mandolino-dorato',60),('oboe-respiro',65),('fagotto-ombra',48),('flauto-barocco',72),('gong-profondo',60),('dan-tranh-lunare',60)],
'blue-sei-nuovi':[('prime-zither-blue',72),('nylon-blue',55),('chemnitzer-blue',60),('banjo-blue',60),('clavinet-blue',60),('blues-formant-blue',60)],
'green-lead-e-corpo':[('cedro-lead',60),('miele-pulse',60),('ottone-verde',55),('giada-fase',60),('ambra-fm',60),('muscolo-basso',36)],
'green-larghi-e-risonanti':[('bosco-largo',60),('canneto-elettrico',60),('prisma-morbido',60),('seta-spettrale',60),('resina-sync',60),('aurora-vetro',60)]}
def collection(name,voices):
 tracks=[];rows=[];cursor=0
 for slug,key in voices:
  p=library.find_sound(slug);m=json.loads((p/'build/manifest.json').read_text())
  if slug=='gong-profondo':notes=[(key,0,6,95)]
  elif name=='green-larghi-e-risonanti':notes=[(key,0,4.2,100),(key+7,0,4.2,85),(key+10,0,4.2,82),(key+3,4.6,2.4,105)]
  else:notes=[(key,0,.28,55),(key,.55,.35,112),(key+3,1.15,.55,92),(key+7,1.95,.75,102),(key,3.0,3.8,98)]
  f=OUT/(slug+'-native.wav');render.render(p,f,notes,tail=1.45)
  a=Audio.load(f);x=a.data.astype(float);x=np.column_stack([x,x]) if x.ndim==1 else x
  if not np.all(np.isfinite(x)) or a.peak_db>=-.2:raise RuntimeError(slug+' invalid/clip')
  gain=min(9,max(-9,-25-a.rms_db));gain=min(gain,-3-a.peak_db);x*=10**(gain/20)
  Audio(x,a.sr).save(OUT/(slug+'-ascolto.wav'))
  rows.append({'slug':slug,'title':m['title'],'key':key,'start_s':cursor,'end_s':cursor+len(x)/a.sr,'native_peak_db':a.peak_db,'native_rms_db':a.rms_db,'demo_gain_db':gain,'default_articulation':m.get('articulations',[None])[0] if m.get('articulations') else None})
  tracks.extend([x,np.zeros((16800,2))]);cursor+=len(x)/a.sr+.35
 Audio(np.concatenate(tracks),48000).save(OUT/(name+'.wav'))
 (OUT/(name+'-index.json')).write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
 print(name,round(cursor,1),flush=True)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--sets',nargs='+',choices=list(SETS));args=parser.parse_args()
 for name in args.sets or SETS:collection(name,SETS[name])
 lines=['# Ascolti nuove voci Libero\n','Renderer nativo. Gain confrontato solo nei file di ascolto (massimo ±9 dB); preset invariati. Le prove numeriche non certificano gusto, realismo o ripetizioni impercettibili.\n']
 for name in SETS:
  f=OUT/(name+'-index.json')
  if f.exists():
   lines+=['\n## '+name+'\n']+[f'- {r["start_s"]:.1f}s — {r["title"]}, base MIDI {r["key"]}' for r in json.loads(f.read_text())]
 (OUT/'ASCOLTO.md').write_text('\n'.join(lines)+'\n')
