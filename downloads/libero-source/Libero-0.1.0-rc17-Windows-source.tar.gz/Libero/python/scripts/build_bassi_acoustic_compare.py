"""Native, RMS-matched same-phrase comparison plus the actual long quiet upright take.
No installed preset gain is changed. Comparison WAVs are measurement/listening references.
"""
from pathlib import Path
import json,subprocess,numpy as np,soundfile as sf
from libero import Audio,analysis
from build_bassi_acoustic import SLUGS,BANK
RENDER=Path.home()/'.local/bin/libero-render'
OUT=Path.home()/'Libero/cache/refs/bassi-acoustic'
NOTES='12:0:.01:100,33:.05:.45:35,36:.7:.45:70,38:1.4:.45:115,39:2.1:.45:90,36:2.8:.18:80,36:3.1:.18:80,36:3.4:.18:80,36:3.7:.18:80,36:4.2:3:100'
def main():
 OUT.mkdir(parents=True,exist_ok=True);summary=[];clips=[]
 for slug in SLUGS:
  p=BANK/slug;v=json.loads((p/'verification.json').read_text());m=json.loads((p/'samples/map-bassi.json').read_text());credits=json.loads((p/'samples/credits.json').read_text())
  v['credits']=[{k:c[k]for k in ('source','author','license','license_class','url')}for c in credits]
  v['articulation_design']={art:{'body_zones':len(rr),'roots':len({r['root']for r in rr}),'dynamics':len({tuple(r['dyn'])for r in rr}),'takes':len({r['take']for r in rr}),'range_midi':[min(r['root']for r in rr),max(r['root']for r in rr)]}for art in sorted({r['articulation']for r in m['body']})if (rr:=[r for r in m['body']if r['articulation']==art])}
  if (p/'migration.json').exists():v['migration']=json.loads((p/'migration.json').read_text())
  f=OUT/(slug+'-matched-phrase.wav');subprocess.run([str(RENDER),'--sound',str(p),'--out',str(f),'--notes',NOTES,'--params','{"rev_mix":0}','--tail','6'],check=True,capture_output=True)
  x,sr=sf.read(f,always_2d=True);rms=np.sqrt(np.mean(x[:int(7.2*sr)]**2));gain=10**(-32/20)/(rms+1e-20);x*=gain
  assert np.abs(x).max()<1,'comparison clipping'
  sf.write(f,x,sr,subtype='PCM_24');clips.extend([x,np.zeros((sr,2))]);v['comparison_gain_db']=20*np.log10(gain);v['comparison_rms_first7_2s_db']=-32;v['comparison_peak_db']=20*np.log10(np.abs(x).max()+1e-20)
  (OUT/(slug+'-matched-phrase.png')).write_bytes(analysis.spectrogram(Audio(x,sr),title=slug+' · same phrase · RMS−32dBFS'));summary.append(v)
 x=np.concatenate(clips);sf.write(OUT/'palette-comparison.wav',x,sr,subtype='PCM_24');(OUT/'palette-comparison.png').write_bytes(analysis.spectrogram(Audio(x,sr),title='Jazz / Flatwound / Hollowbody · same notes · RMS−32dBFS'))
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 p=BANK/'contrabbasso-jazz';f=p/'build/preview-quiet-long.wav';subprocess.run([str(RENDER),'--sound',str(p),'--out',str(f),'--notes','13:0:.01:100,24:.1:12:110','--params','{"rev_mix":0}','--tail','3'],check=True,capture_output=True)
 x,sr=sf.read(f,always_2d=True);assert np.abs(x).max()<1
 (p/'build/preview-quiet-long.png').write_bytes(analysis.spectrogram(Audio(x,sr),title='Quiet upright C1 · single unlooped recorded note held12s'))
 print('Comparison',OUT/'palette-comparison.wav','all sources at RMS−32dBFS; long quiet preview',f,flush=True)
if __name__=='__main__':main()
