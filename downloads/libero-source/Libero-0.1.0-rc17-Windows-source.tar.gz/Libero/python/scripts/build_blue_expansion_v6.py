#!/usr/bin/env python3
"""Build and verify six source-led Blue additions owned by this builder.

Inputs are pinned in ~/Libero/cache/libraries and were acquired from the
upstream CC0/GPL repositories listed in each output sound's notes and credits.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json, math, re, shutil, subprocess, sys
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy import signal

ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, analysis, dsp
from libero.compiler import compile_sound
from libero.ingest.sfz import parse_sfz
from libero.multisample import true_onset
from libero.lint import lint_bundle, _load
from libero.figure import validate_svg

HOME=Path.home(); LIB=HOME/'Libero'; BANK=LIB/'banks/blue'; DEMO=LIB/'demo/blue-v6'; SR=48000
HZ=LIB/'cache/libraries/hungarian_zither/hungarian_zither-main'
CH=LIB/'cache/libraries/chemnitzer/Chemnitzer'
BAN=LIB/'cache/libraries/kay-banjo/FlameStudios.Kay5StringBanjo-master'
NYL=LIB/'cache/libraries/freepats-nylon/SpanishClassicalGuitar-SFZ-20190618'
REC={
 'prime-zither-blue':('Prime Zither','Prime zither ungherese · melody di default · strum down/up selezionabili · due o tre riprese reali',['blue','sampled','plucked','zither'],HZ),
 'nylon-blue':('Corde di Cedro','Chitarra classica nylon · FreePats · note cromatiche registrate',['blue','sampled','guitar','nylon'],NYL),
 'chemnitzer-blue':('Mantice Sassone','Concertina Chemnitzer · tre dinamiche e rilascio registrati',['blue','sampled','concertina','reed'],CH),
 'banjo-blue':('Cinque Fili','Kay closed-back banjo · dita, corde smorzate e armonici',['blue','sampled','banjo','plucked'],BAN),
}
SYN={
 'clavinet-blue':('Filo Magnetico','Sintesi originale a corda tesa e pickup asimmetrico',['blue','synth','plucked','keys']),
 'blues-formant-blue':('Respiro d’Ambra','Sintesi originale a formanti mobili, fondamentale stabile e registro di legno',['blue','synth','pad','formant']),
}

def digest(p:Path)->str:
 h=sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def stored(src:Path,samples:Path)->str:
 rel=src.relative_to(_SOURCE); dst=samples/'originals'/rel; dst.parent.mkdir(parents=True,exist_ok=True)
 if not dst.exists() or digest(dst)!=digest(src): shutil.copy2(src,dst)
 return dst.relative_to(samples).as_posix()

_SOURCE=Path('/')
def loop_sample(src:Path,samples:Path,basename:str,early:float=.22,minlen:float=.45):
 """Retain the real attack and loop a segment of this exact performance."""
 a=Audio.load(src,sr=SR)
 hi=max(early+.25,a.duration-.06)
 lp=a.loop_points(minlen,region=(early,min(a.duration-.06,max(early+.3,hi))),window=.025,max_crossfade=.20)
 if lp is None: lp=a.loop_points(.30,region=(.12,a.duration-.05),window=.018,max_crossfade=.12)
 if lp is None: raise RuntimeError(f'No source-derived hold loop for {src} ({a.duration:.2f}s)')
 y=a.bake_loop(lp); dst=samples/'derived'/f'{basename}-loop.flac'; dst.parent.mkdir(parents=True,exist_ok=True)
 sf.write(dst,y.data,SR,format='FLAC',subtype='PCM_24')
 return dst.relative_to(samples).as_posix(),{'start':lp.start,'end':lp.end}, {'selection_error_db':lp.error_db,'crossfade_ms':1000*lp.crossfade/SR,'loop_seconds':(lp.end-lp.start)/SR,'derived_sha256':digest(dst)}

def modal_continue(src:Path,samples:Path,basename:str,root:int):
 """Fit a periodic body to the early recorded pluck and anchor its level there."""
 from build_aria_mechanical import derive_source_body
 dst=samples/'derived'/f'{basename}-modes.flac'
 loop,audit=derive_source_body(src,dst,root,period=8.0,transition_end=.65)
 return dst.relative_to(samples).as_posix(),loop,{
  'method':'same-source phase-fitted periodic continuation','source_analysis_seconds':audit['source_analysis_window_seconds'],
  'preserved_raw_attack_ms':180,'join_end_seconds':audit['transition_end_seconds'],
  'loop_seconds':round((loop['end']-loop['start'])/SR,6),'mode_count':audit['measured_component_count'],
  'continuation_rms_dbfs':audit['continuation_rms_dbfs'],'continuation_vs_transient_db':audit['continuation_vs_transient_db'],
  'detected_onset_seconds':audit['detected_onset_seconds'],'derived_sha256':digest(dst)}

def pressure_loop(src:Path,samples:Path,basename:str,loop_start_s:float|None=None,xfade_s:float=.18):
 """Bake an exact same-take reed join while retaining a long performed cycle."""
 a=Audio.load(src,sr=SR); x=a.data.astype(np.float64);x=x[:,None] if x.ndim==1 else x
 onset_s=true_onset(x,SR)/SR
 loop_start_s=max(.30,onset_s+.05) if loop_start_s is None else loop_start_s
 xf=min(round(max(xfade_s,.30)*SR),round(.30*SR)); start=round(loop_start_s*SR); keep=round(.135*SR)
 end=len(x)-keep
 if end-start<round(.58*SR): raise RuntimeError(f'No adequate performed reed loop after attack in {src}: {len(x)/SR:.2f}s')
 if xf*2>=end-start: raise RuntimeError(f'Reed crossfade exceeds half loop for {src}')
 y=x[:end].copy(); j=end-xf; tgt0=start-xf
 if tgt0<0:raise RuntimeError('Reed loop start too early for same-source overlap')
 u=np.linspace(0,1,xf,endpoint=False);u=u*u*(3-2*u)
 ramp_end=end-keep
 ramp_n=ramp_end-j
 u=np.linspace(0,1,ramp_n,endpoint=True);u=u*u*(3-2*u)
 y[j:ramp_end]=x[j:ramp_end]*(1-u[:,None])+x[tgt0:tgt0+ramp_n]*u[:,None]
 # End exactly on the source samples immediately preceding the loop start.
 y[end-keep:end]=x[start-keep:start]
 # Keep the original terminal sample after the loop boundary for offline lint;
 # it is never traversed by the sustain loop, and its last 8 ms are de-clicked.
 tail=x[end:].copy()
 if len(tail)>0:
  nfade=min(len(tail),round(.008*SR)); tail[-nfade:]*=np.linspace(1,0,nfade,endpoint=True)[:,None]
  y=np.concatenate([y,tail],axis=0)
 dest=samples/'derived'/f'{basename}-pressure-loop.flac';dest.parent.mkdir(parents=True,exist_ok=True)
 sf.write(dest,y,SR,format='FLAC',subtype='PCM_24')
 return dest.relative_to(samples).as_posix(),{'start':start,'end':end},{'method':'same-take sustained pressure loop with exact source overlap','loop_seconds':(end-start)/SR,
   'crossfade_ms':1000*xf/SR,'ramp_ends_before_exact_tail':True,'loop_start_seconds':start/SR,'source_onset_seconds':onset_s,'post_loop_source_tail_ms':1000*len(tail)/SR,'final_source_exact_ms':1000*keep/SR,'last_20ms_source_exact':True,'source_seconds':len(x)/SR,'derived_sha256':digest(dest)}

def source_doc(slug:str,samples:Path,srcroot:Path,docs:list[Path],credit:dict):
 base=samples/'source-reference'; base.mkdir(parents=True,exist_ok=True); rows=[]
 for doc in docs:
  out=base/doc.name; shutil.copy2(doc,out); rows.append({'file':out.relative_to(samples).as_posix(),'source':str(doc),'bytes':out.stat().st_size,'sha256':digest(out)})
 (samples/'source-documents.json').write_text(json.dumps(rows,indent=2)+'\n')
 (samples/'credits.json').write_text(json.dumps([credit],indent=2,ensure_ascii=False)+'\n')

def identity_pitch(src:Path, fallback:int)->tuple[int,float]:
 """Measure tuning at the expected fundamental, avoiding stronger harmonics."""
 x,sr=sf.read(src,always_2d=True,dtype='float64'); x=x.mean(axis=1)
 a=int(.08*sr); b=min(len(x),int(.45*sr)); seg=x[a:b]
 if len(seg)<2048:return fallback,0.0
 n=1<<int(math.ceil(math.log2(len(seg)*4))); spec=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),n=n)); fr=np.fft.rfftfreq(n,1/sr)
 expected=440*2**((fallback-69)/12); lo=expected*2**(-100/1200); hi=expected*2**(100/1200)
 ix=np.flatnonzero((fr>=lo)&(fr<=hi))
 if len(ix)<3:return fallback,0.0
 k=int(ix[np.argmax(spec[ix])]);
 if k<=0 or k+1>=len(spec):return fallback,0.0
 z=np.log(np.maximum(spec[k-1:k+2],1e-30)); d=float(np.clip(.5*(z[0]-z[2])/(z[0]-2*z[1]+z[2]+1e-30),-.5,.5))
 measured_hz=(k+d)*sr/n; cents=1200*math.log2(measured_hz/expected)
 return fallback,float(-cents)

def map_recorded(slug:str,samples:Path):
 global _SOURCE
 body=[]; tails=[]; proof=[]; arts=[]; counts={}
 if slug=='prime-zither-blue':
  # The SFZ's G4-labelled files were incorrectly assigned to G2. Correct from
  # measured source fundamentals and preserve the original opcode evidence.
  maps=[('down','down',HZ/'Programs/mappings/down.sfz'),('up','up',HZ/'Programs/mappings/up.sfz'),('melody','mel',HZ/'Programs/mappings/mel.sfz')]
  # The chord-capable melody course is the default; the fixed-G drone strums
  # remain independently selectable from their keyswitches.
  arts=[('melody','Corde melodiche',14),('down','Plettrata discendente',12),('up','Plettrata ascendente',13)]
  for art,source_art,srcsfz in maps:
   inst=parse_sfz(srcsfz); counts[art]=len(inst.regions)
   if inst.warnings: raise RuntimeError(f'zither mapping warning: {inst.warnings}')
   for r in inst.regions:
    name=r.sample.name; src=HZ/'Samples'/source_art/name
    if not src.exists(): raise RuntimeError(f'zither source missing: {src}')
    label=re.search(r'_([a-g](?:#|b)?)(\d)_',name,re.I)
    if not label: raise RuntimeError(f'No written pitch in {name}')
    note=label.group(1).replace('b','b').upper(); octave=int(label.group(2)); written=note+'4' if octave==4 else note+str(octave)
    # sample filename is concert pitch (e.g. g4 = MIDI 67); the upstream
    # SFZ region root/key is two octaves too low. Preserve both in proof.
    root=int(r.root+24); lo=root; hi=root
    # Down/up strums contain fixed-pitch drone strings; leave their source
    # pitches untouched. Melody courses have no such drone, so measure their
    # own early-body fundamental and apply only the bounded static correction.
    actual,corr=identity_pitch(src,root) if art=='melody' else (root,0.0)
    if abs(corr)>100: raise RuntimeError(f'zither fine tuning exceeds +/-100 cents: {src.name} {corr:.2f}')
    _SOURCE=HZ; f=stored(src,samples)
    derived,lp,metrics=modal_continue(src,samples,f'{art}-{src.stem}',root)
    take=(r.seq_position or 1)-1
    body.append({'file':derived,'root':root,'lo':lo,'hi':hi,'vel':[1,127],'take':take,'tune_cents':corr,
                 'articulation':art,'loop':lp})
    proof.append({'file':f,'source_file':str(src),'source_sha256':digest(src),'written_pitch':written,
       'sfz_root_key_original':[r.root,r.lokey,r.hikey],'mapped_measured_root':[actual,lo,hi],
       'root_correction_semitones':24,'measured_source_deviation_cents':-corr,'applied_tune_cents':corr,'articulation':art,'seq_position':r.seq_position,
       'source_seconds':sf.info(src).duration,'derived_file':derived,**metrics})
  source_doc(slug,samples,HZ,[HZ/'LICENSE',HZ/'README.md'],{'source':'Hungarian zither · prime zither in G','author':'Karoryfer Lecolds / D. Smolken','license':'CC0 1.0','license_class':'cc0','url':'https://github.com/sfzinstruments/hungarian_zither','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','notes':'All three recorded gestures (down/up/melody), all two or three sequence takes, originals included. SFZ source roots were 24 semitones below their written/sample-measured pitch; mapped at the written source register. Melody sources receive only a measured bounded static fine-tuning correction (per take); down/up drone gestures remain untuned.','retrieved':'2026-10-03'})
 elif slug=='chemnitzer-blue':
  sfz=CH/'chemnitzer.SFZ'; inst=parse_sfz(sfz); _SOURCE=CH; counts={'source_regions':len(inst.regions)}
  if inst.warnings:raise RuntimeError(str(inst.warnings))
  for r in inst.regions:
   src=r.sample
   if not src.exists():raise RuntimeError(f'missing Chemnitzer source {src}')
   f=stored(src,samples); actual,src_corr=identity_pitch(src,r.root); tune=r.tune_cents+src_corr
   if abs(tune)>100:raise RuntimeError(f'Chemnitzer tuning correction exceeds +/-100 cents: {src.name} {tune:.1f}')
   row={'file':f,'root':r.root,'lo':r.lokey,'hi':r.hikey,'vel':[r.lovel,r.hivel],
      'take':0,'tune_cents':tune,'gain_db':r.gain_db}
   proofrow={'file':f,'source_file':str(src),'source_sha256':digest(src),'sfz_root':r.root,'sfz_key_range':[r.lokey,r.hikey],
      'velocity':[r.lovel,r.hivel],'trigger':r.trigger,'source_seconds':sf.info(src).duration,'sfz_opcodes':r.opcodes,
      'measured_root':actual,'measured_source_deviation_cents':round(-src_corr,2),'applied_tune_cents':round(tune,2)}
   if r.trigger=='release':
    row.update({'rt_decay':r.rt_decay or 3.0,'rt_min_db':-55}); tails.append(row); proofrow['kind']='release'
   else:
    # Keep the full played-pressure cycle; bake an exact same-take overlap at its end.
    derived,lp,metrics=pressure_loop(src,samples,src.stem); row.update({'file':derived,'loop':lp})
    body.append(row); proofrow.update({'kind':'body','derived_file':derived,**metrics})
   proof.append(proofrow)
  source_doc(slug,samples,CH,[CH/'LICENSE.txt',CH/'README.txt',sfz],{'source':'Tomiak Chemnitzer Digital Instrument','author':'Tomiak Chemnitzer','license':'CC0 1.0','license_class':'cc0','url':'https://tomiakchemnitzer.com/digital-instrument/','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','notes':'Three genuine recorded dynamics and one release per available pitch are mapped from the upstream SFZ. Its body had no loop opcodes; each body preserves the real onset and long performed pressure/air gesture, then joins to an exact overlap from the same take.','retrieved':'2026-10-03'})
 elif slug=='nylon-blue':
  sfz=NYL/'SpanishClassicalGuitar-20190618.sfz'; inst=parse_sfz(sfz); _SOURCE=NYL; counts={'source_regions':len(inst.regions)}
  if inst.warnings:raise RuntimeError(str(inst.warnings))
  for r in inst.regions:
   src=r.sample; f=stored(src,samples)
   # Filename and SFZ root agree on the performed key. Low guitar notes have a
   # stronger second partial than fundamental, so a peak picker is not a valid
   # root estimator here; retain source tuning and record this limitation.
   actual,corr=identity_pitch(src,r.root); corr+=r.tune_cents
   if abs(corr)>100: raise RuntimeError(f'classical guitar tune exceeds +/-100 cents: {src.name} {corr:.1f}')
   derived,lp,metrics=modal_continue(src,samples,src.stem)
   row={'file':derived,'root':r.root,'lo':r.lokey,'hi':r.hikey,'vel':[r.lovel,r.hivel],'take':0,'tune_cents':corr,'loop':lp}
   body.append(row); proof.append({'file':f,'source_file':str(src),'source_sha256':digest(src),'sfz_root':r.root,
       'key_range':[r.lokey,r.hikey],'velocity':[r.lovel,r.hivel],'measured_root':actual,'measured_source_deviation_cents':round(-(corr-r.tune_cents),2),'tune_cents':corr,
       'source_seconds':sf.info(src).duration,'derived_file':derived,**metrics})
  source_doc(slug,samples,NYL,[NYL/'cc0.txt',NYL/'readme.txt',sfz],{'source':'FreePats Spanish Classical Guitar SFZ','author':'FreePats contributors','license':'CC0 1.0','license_class':'cc0','url':'https://freepats.zenvoid.org/Guitar/spanishclassicalguitar.html','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','notes':'All 48 original chromatic note recordings are retained. The natural release is preserved in each file; infinite sustain is a source-derived designed continuation after the recorded pluck. One recorded dynamic and no round robins are present.','retrieved':'2026-10-03'})
 elif slug=='banjo-blue':
  sfz=BAN/'FS KayBanjo (release mw1).sfz'; inst=parse_sfz(sfz); _SOURCE=BAN; counts={'source_regions':len(inst.regions)}
  if inst.warnings:raise RuntimeError(str(inst.warnings))
  mapped_signatures=set()
  for r in inst.regions:
   src=r.sample
   if not src.exists():raise RuntimeError(f'missing banjo source {src}')
   f=stored(src,samples); root=r.root; lo=r.lokey; hi=r.hikey
   # The upstream map has an octave-mirror convenience for the fifth string.
   # Its recorded source is G4 (verified near 392 Hz), so retain the three
   # recorded dynamics once at the physical note and record the bad mirror.
   if src.parent.name=='string5' and lo>84:
    proof.append({'file':f,'source_file':str(src),'source_sha256':digest(src),'sfz_root':r.root,
      'sfz_key_range':[r.lokey,r.hikey],'velocity':[r.lovel,r.hivel],
      'mapping_status':'upstream octave alias; same original sample and dynamic mapped at measured G4 65..69 instead'})
    continue
   art='effects' if lo>=96 else ('string5' if src.parent.name=='string5' else 'banjo')
   if art=='string5': root=67;lo=65;hi=69
   if art=='effects':
    row={'file':f,'root':root,'lo':lo,'hi':hi,'vel':[r.lovel,r.hivel],'take':0,'pitched':False,'one_shot':True,'articulation':art}
    body.append(row); proof.append({'file':f,'source_file':str(src),'source_sha256':digest(src),'sfz_root':r.root,'sfz_key_range':[r.lokey,r.hikey],
       'velocity':[r.lovel,r.hivel],'mapped_as':art,'source_seconds':sf.info(src).duration,'source_region_opcodes':r.opcodes}); continue
   signature=(str(src.resolve()),root,lo,hi,r.lovel,r.hivel,art)
   if signature in mapped_signatures:
    proof.append({'file':f,'source_file':str(src),'source_sha256':digest(src),'sfz_root':r.root,'sfz_key_range':[r.lokey,r.hikey],
      'velocity':[r.lovel,r.hivel],'mapping_status':'duplicate upstream region reference to the same original recording and velocity; kept once in playback map'}); continue
   mapped_signatures.add(signature)
   actual,corr=identity_pitch(src,root)
   if abs(corr)>100:raise RuntimeError(f'banjo tuning exceeds +/-100 cents: {src.name} {corr}')
   derived,lp,metrics=modal_continue(src,samples,src.stem+f'-{lo}')
   row={'file':derived,'root':root,'lo':lo,'hi':hi,'vel':[r.lovel,r.hivel],'take':0,'tune_cents':corr,'loop':lp,'articulation':art}
   body.append(row); proof.append({'file':f,'source_file':str(src),'source_sha256':digest(src),'sfz_root':r.root,'sfz_key_range':[r.lokey,r.hikey],
      'velocity':[r.lovel,r.hivel],'mapped_root':root,'measured_root':actual,'tune_cents':corr,'articulation':art,
      'source_seconds':sf.info(src).duration,'derived_file':derived,**metrics})
  source_doc(slug,samples,BAN,[BAN/'LICENSE.txt',BAN/'README.md',sfz],{'source':'FlameStudios Kay 5-String Banjo','author':'Gary Campion; SFZ conversion S. Christian Collins','license':'GNU GPL-3.0-or-later','license_class':'gpl','url':'https://github.com/sfzinstruments/FlameStudios.Kay5StringBanjo','license_url':'https://www.gnu.org/licenses/gpl-3.0.html','notes':'Original SFZ and all mapped source WAVs are included. The region map has genuine velocity layers; original harmonic and muted-string effect samples stay on a separate articulation. The upstream README warns that some original samples have residual clipping/noise after cleanup.','retrieved':'2026-10-03'})
  groups={}
  for row in body: groups.setdefault((row['root'],row.get('articulation')),[]).append(row)
  for key,rows in groups.items():
   levels=[]
   for row in rows:
    measured=dsp.momentary_max(Audio.load(samples/row['file'],sr=SR).data,SR)
    levels.append((row,20*math.log10(max(measured,1e-12))+row.get('gain_db',0.0)))
   levels.sort(key=lambda x:x[0]['vel'][0]); floor=None
   for row,db in levels:
    target=db if floor is None else max(db,floor+1.5)
    row['gain_db']=round(row.get('gain_db',0.0)+target-db,2); floor=target
 if not body: raise RuntimeError(f'No mapped body rows for {slug}')
 if slug=='nylon-blue':
  arts=[('normal','Tastiera',12)]
  for row in body: row['articulation']='normal'
  for row in tails: row['articulation']='normal'
 if slug=='chemnitzer-blue':
  # Preserve all three genuine dynamic recordings. A few source files are only
  # 1.04–1.05 s long; even a 180 ms same-source join cannot yield a full 1 s
  # cycle after the played onset and exact 20 ms terminal overlap. Keep those
  # loops at their maximum source-derived duration and record the exception.
  # Correct only per-note layer gain where the source ladder itself inverts.
  groups={}
  for row in body: groups.setdefault(row['root'],[]).append(row)
  for root,rows in groups.items():
   levels=[]
   for row in rows:
    measured=dsp.momentary_max(Audio.load(samples/row['file'],sr=SR).data,SR)
    levels.append((row,20*math.log10(max(measured,1e-12))+row.get('gain_db',0.0)))
   levels.sort(key=lambda x:x[0]['vel'][0]); floor=None
   for row,db in levels:
    target=db if floor is None else max(db,floor+0.7)
    row['gain_db']=round(row.get('gain_db',0.0)+target-db,2); floor=target
  arts=[('normal','Soffietto',12)]
  for row in body: row['articulation']='normal'
  for row in tails: row['articulation']='normal'
 (samples/'source-proof.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
 (samples/'map.json').write_text(json.dumps({'body':body,'tail':tails,'counts':counts,'articulations':arts},indent=2,ensure_ascii=False)+'\n')
 return {'body':len(body),'tail':len(tails),'proof':len(proof),'articulations':arts,'recorded_velocity_regions':len([x for x in body if x.get('vel')!=[1,127]])}

def synth_audio(slug:str,root:int,vel:int,samples:Path):
 """Original periodic synth identities, each with a voiced onset and full body."""
 period=8.; n=int(SR*period); f0=round(440*2**((root-69)/12)*period)/period
 t=np.arange(n)/SR; phase=2*np.pi*f0*t; v=(vel-1)/126; y=np.zeros(n,dtype=np.float64)
 if slug=='clavinet-blue':
  # Pluck impulse through a stiff string; pickup position creates physical
  # partial cancellations, with a small, non-repeating-onset string snap.
  pickup=.205
  for k in range(1,min(90,int(12000/f0))+1):
   stiffness=1+0.00011*k*k; hz=round(k*f0*stiffness*period)/period; pickup_gain=abs(math.sin(math.pi*k*pickup))
   a=(1/k**1.18)*pickup_gain*stiffness
   a*=1+.8*v*(k/25)
   if a>1e-5:y+=a*np.sin(2*np.pi*hz*t+.18*k)
  y/=max(np.max(np.abs(y)),1e-8); y*=.60
  desc={'excitation':'short pluck impulse','body':'stiff-string partial family','pickup_position_fraction':pickup,'character':'comb-shaped partial balance from asymmetric pickup position'}
 else:
  # A stable low reed-like fundamental plus broad moving formants. Independent
  # resonant partial groups and slow amplitude drift give motion without pitch LFO.
  centers=[430.+18*v,1020.+100*v,2180.+250*v]; widths=[210.-20*v,390.+30*v,680.+65*v]
  for k in range(1,min(70,int(11000/f0))+1):
   hz=k*f0; env=.32/(k**.9)
   for c,w,g in zip(centers,widths,[1.0,.78,.28]):
    env+=g*math.exp(-.5*((hz-c)/w)**2)/(k**.35)
   motion=1+.10*np.sin(2*np.pi*t/period+0.71*k)+.045*np.sin(4*np.pi*t/period+.33*k)
   y+=env*motion*np.sin(phase*k+.27*k)
  y/=max(np.max(np.abs(y)),1e-8); y*=.48
  desc={'excitation':'stable compound oscillator','formants_hz':centers,'bandwidths_hz':widths,'character':'warm low body, three slowly moving formant groups, no pitch modulation'}
 # Keep designed soft/hard timbres as original electronic velocity variants.
 y*=10**((-9+4*v)/20)
 onset=.72; n_on=int(onset*SR); attack=np.zeros(n_on)
 at=np.arange(n_on)/SR; attack_f=f0*(1+(.0025 if slug=='clavinet-blue' else .0004)*np.exp(-at/.13))
 ph=2*np.pi*np.cumsum(attack_f)/SR
 if slug=='clavinet-blue':
  attack=.32*np.sin(ph)*np.exp(-at/.32)+.10*np.sin(2*ph+1.2)*np.exp(-at/.12)
 else:
  attack=(.22*np.sin(ph)+.08*np.sin(2*ph+.4))*np.minimum(1,at/.16)
 attack*=10**((-9+4*v)/20)
 # Add a quarter-second periodic lead-in, then loop one exact cycle beyond it.
 # This lets the source-preserving compiler's DC blocker reach the periodic
 # steady state before its loop-boundary window.
 warm=round(.25*SR)
 out=np.concatenate([attack,y,y[:warm]]).astype(np.float32)
 dst=samples/'originals'/f'{slug}-m{root}-v{vel}.wav'; dst.parent.mkdir(parents=True,exist_ok=True)
 sf.write(dst,out,SR,subtype='PCM_24')
 row={'file':dst.relative_to(samples).as_posix(),'root':root,'lo':root,'hi':root,'vel':[1,79] if vel==55 else [80,127],
      'take':0,'loop':{'start':n_on+warm,'end':n_on+warm+n}}
 return row,{'root':root,'midi_frequency_target_hz':440*2**((root-69)/12),'period_seconds':period,'samples_per_period':n,
             'loop':row['loop'],'velocity':vel,'construction':desc,'sha256':digest(dst)}

def build_synth(slug:str,dest:Path):
 title,subtitle,tags=SYN[slug]; samples=dest/'samples'; samples.mkdir(parents=True,exist_ok=True)
 roots=[36,43,50,57,64,71,78,85,91]; body=[]; proofs=[]
 for root in roots:
  for vel in (55,115):
   row,proof=synth_audio(slug,root,vel,samples); body.append(row);proofs.append(proof)
 for row in body: row['articulation']='normal'
 (samples/'map.json').write_text(json.dumps({'body':body,'tail':[],'counts':{'body':len(body),'roots':roots,'velocity_layers':2},'articulations':[('normal','Tastiera',12)]},indent=2)+'\n')
 (samples/'source-proof.json').write_text(json.dumps(proofs,indent=2,ensure_ascii=False)+'\n')
 credits={'route':'SYN','construction':subtitle,'source':'original synthesis rendered by build_blue_expansion_v6.py','license_class':'original','roots':roots,'layers':[55,115]}
 (samples/'credits.json').write_text(json.dumps([credits],indent=2)+'\n')
 info={'body':len(body),'tail':0,'proof':len(proofs),'roots':roots,'velocity_layers':2}
 write_sound(slug,dest,title,subtitle,tags,info,synthetic=True)
 return info

def write_sound(slug:str,dest:Path,title:str,subtitle:str,tags:list,info:dict,synthetic:bool=False):
 roots=sorted({r['root'] for r in json.loads((dest/'samples/map.json').read_text())['body']})
 arts=json.loads((dest/'samples/map.json').read_text()).get('articulations',[])
 artcode='sound.articulations('+repr([{'id':a,'name':n,'key':k} for a,n,k in arts])+')\n' if arts else ''
 # Banjo effects are source attack articulations, not held notes.
 if slug=='banjo-blue':artcode="sound.articulations([{'id':'banjo','name':'Corde','key':12},{'id':'string5','name':'Quinta corda','key':13},{'id':'effects','name':'Armonici e corde smorzate','key':14}])\n"
 code=f'''"""{title} · native, source-led Blue instrument."""
import json
from pathlib import Path
from libero import Sound
sound=Sound(title={title!r},subtitle={subtitle!r},tags={tags!r},roots={roots!r},sample_rate=48000)
mapping=json.loads((Path(__file__).parent/'samples/map.json').read_text())
{artcode.rstrip()}
sound.multisample('body',mapping['body'],as_dyn={str(not synthetic)},process={{'tune':{'source' if slug in ('prime-zither-blue','chemnitzer-blue','banjo-blue') else 'smooth'!r},'ladder':'keep','peak_db':-4,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'}})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=0,onset_ms=0)
if mapping.get('tail'):
 sound.multisample('tail',mapping['tail'],as_dyn=False,process={{'tune':'source','ladder':'keep','peak_db':-8,'align_ms':0,'pre_ms':0,'fade_ms':8,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'}})
sound.defaults(mode='Poli',glide=0,voices=24,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=180,
 lvl_body={-4 if slug=='blues-formant-blue' else 0},lvl_tail=0,lvl_attack=-60,lvl_air=-60,vel_sens=.35,master={-7 if slug=='banjo-blue' else -4},
 tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,
 rev_mode='Cappella',rev_mix=0,rev_decay=1,rev_size=.30,rev_damp=.50)
'''
 (dest/'sound.py').write_text(code)

def figure(slug:str)->str:
 header='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#282630" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><title>{}</title><desc>{}</desc>'.format
 if slug=='prime-zither-blue':
  desc='Top view of a rectangular Hungarian prime zither, melody courses and drone strings, with a plectrum moving across the bridge.'
  bits=['<path d="M94 135L386 135L411 378L69 378Z" fill="#f2eee8" stroke-width="1.5"/>','<path d="M116 177H398M112 208H401M108 239H404M103 270H407M98 301H410M92 332H414" stroke-width=".7"/>','<path d="M131 161V354M350 161V354" stroke-width="1.1"/>','<path d="M191 118Q255 144 310 201" stroke="#b8924f" stroke-width="2"/>','<path d="M218 105L242 109L317 218L293 214Z" fill="#b8924f" stroke="#b8924f" stroke-width="1"/>']
 elif slug=='nylon-blue':
  desc='Nylon guitar body, round sound hole, bridge, and six strings; a picked note leaves a source-derived ringing body.'
  bits=['<path d="M256 80V190M256 360V432" stroke-width="6"/>','<path d="M256 143C198 101 126 141 140 212C149 258 171 278 159 324C141 389 206 430 256 379C306 430 371 389 353 324C341 278 363 258 372 212C386 141 314 101 256 143Z" fill="#f2eee8" stroke-width="1.5"/>','<circle cx="256" cy="254" r="38" stroke-width="1.2"/>','<path d="M211 337H301M228 327L284 347M256 80V337" stroke-width=".7"/>','<path d="M246 224L255 214L264 224" stroke="#b8924f" stroke-width="1.5"/>']
 elif slug=='chemnitzer-blue':
  desc='A Chemnitzer concertina shown open, with bellows folds and two banks of reed plates; its three real recorded dynamics remain separate.'
  bits=['<path d="M105 145H187L204 166V346L187 367H105Q83 256 105 145ZM407 145H325L308 166V346L325 367H407Q429 256 407 145Z" fill="#f2eee8" stroke-width="1.5"/>','<path d="M204 166L308 166M204 346L308 346M218 171V341M235 171V341M252 171V341M269 171V341M286 171V341" stroke-width=".8"/>','<path d="M121 187H175M120 214H177M119 241H178M119 268H178M120 295H177M121 322H175M337 187H391M336 214H392M335 241H393M335 268H393M336 295H392M337 322H391" stroke-width=".7"/>','<path d="M139 151V179M151 151V179M163 151V179M349 151V179M361 151V179M373 151V179" stroke="#b8924f" stroke-width="1.3"/>']
 elif slug=='banjo-blue':
  desc='A closed-back five-string banjo with a short fifth string, bridge, head and metallic rim; high frets mark the separately playable harmonics and muted-string samples.'
  bits=['<circle cx="256" cy="274" r="139" fill="#f2eee8" stroke-width="1.5"/>','<circle cx="256" cy="274" r="121" stroke-width=".8"/>','<path d="M256 86V399M142 275H370M165 188L347 360M347 188L165 360" stroke-width=".6"/>','<path d="M244 64L268 64L278 154L234 154Z" fill="#f2eee8" stroke-width="1.2"/>','<path d="M250 71V392M256 70V392M262 70V392M268 70V392M244 71V260" stroke-width=".6"/>','<path d="M231 341H281V357H231Z" fill="#b8924f" stroke="#b8924f" stroke-width="1"/>']
 elif slug=='clavinet-blue':
  desc='Synthesized string and pickup: the offset pickup samples the moving string at an uneven position, producing the characteristic partial cancellations of a plucked keyboard design.'
  bits=['<path d="M80 340H432V379H80Z" fill="#f2eee8" stroke-width="1.4"/>']+[f'<path d="M{95+i*22} 344V375" stroke-width=".6"/>' for i in range(15)]+['<path d="M120 302H394M120 292H394M120 282H394" stroke-width=".8"/>','<path d="M185 248V317M340 248V317" stroke="#b8924f" stroke-width="2"/>','<path d="M125 225Q256 199 388 225M125 211Q256 185 388 211" stroke-width=".8"/>','<path d="M185 234L340 234" stroke="#b8924f" stroke-width="1.4"/>','<path d="M244 202L256 166L269 202" stroke-width="1.1"/>']
 else:
  desc='Three resonant formant bands move above a steady low oscillator; arcs show independent amplitude motion, not pitch wobble.'
  bits=['<path d="M87 341H425V378H87Z" fill="#f2eee8" stroke-width="1.2"/>']+[f'<path d="M{104+i*18} 341V{122+int(142*(i/17)**.6)}Q{112+i*18} {110+int(142*(i/17)**.6)} {119+i*18} {122+int(142*(i/17)**.6)}V341" stroke-width=".7"/>' for i in range(18)]+['<path d="M112 273Q256 299 400 264M112 236Q256 205 400 244M112 201Q256 178 400 209" stroke="#b8924f" stroke-width="1.3"/>','<path d="M127 405Q256 436 385 405" stroke-width=".7"/>']
 return header(SYN.get(slug,REC.get(slug,('', '',[])))[0] if slug in SYN else REC[slug][0],desc)+''.join(bits)+'</svg>'

def render_one(slug,dest,counts):
 bundle=dest/'build'; findings=lint_bundle(bundle); lines=[f.line() for f in findings]; levels=Counter(f.level for f in findings)
 (dest/'lint.txt').write_text('\n'.join(lines)+'\n')
 if levels['FAIL']:raise RuntimeError(f'{slug} lint FAIL: {lines}')
 renderer=str(HOME/'.local/bin/libero-render'); notespecs={'prime-zither-blue':('67:0:1:80,67:1.2:1:100,72:2.4:1:110,79:3.6:1:115,85:4.8:1:120,67:6.2:.7:100',[67,72,76,79]),'nylon-blue':('40:0:1:45,40:1.2:1:78,40:2.4:1:110,52:3.6:.9:120,60:4.8:.8:90',[52,57,60,64]),'chemnitzer-blue':('40:0:1:30,40:1.2:1:72,40:2.4:1:110,52:3.6:1:120,60:4.8:.8:94',[52,57,60,64]),'banjo-blue':('48:0:1:32,48:1.2:1:70,48:2.4:1:110,60:3.6:.8:118,72:4.8:.7:90',[48,52,55,59]),'clavinet-blue':('40:0:1:40,40:1.2:1:76,40:2.4:1:116,52:3.6:.9:120,64:4.8:.7:90',[48,52,55,59]),'blues-formant-blue':('40:0:1:38,40:1.2:1:75,40:2.4:1:113,52:3.6:1:120,64:4.8:.8:90',[48,52,55,59])}
 phrase,chord=notespecs[slug]; native=[]; out=bundle/'phrase.wav'
 subprocess.run([renderer,'--sound',str(dest),'--out',str(out),'--notes',phrase,'--tail','2'],check=True,capture_output=True,text=True)
 def stat(path,name):
  x,sr=sf.read(path,always_2d=True);peak=float(np.max(np.abs(x))); mono=x.mean(axis=1)
  return {'name':name,'file':str(path),'seconds':round(len(x)/sr,2),'peak_dbfs':round(20*np.log10(peak+1e-20),2),'clipped_samples':int(np.count_nonzero(abs(x)>=1)),'mono_loss_db':round(10*np.log10(np.mean(mono**2)/(np.mean(x**2)+1e-20)+1e-20),2)}
 native.append(stat(out,'phrase-soft-loud-repeated-chromatic'))
 shutil.copy2(out,DEMO/f'{slug}-phrase.wav'); (DEMO/f'{slug}-phrase.png').write_bytes(analysis.spectrogram(Audio(sf.read(out)[0],SR),title=f'{slug} phrase'))
 for name,note in [('held-low',40 if slug!='prime-zither-blue' else 67),('held-mid',60 if slug!='prime-zither-blue' else 76),('held-high',88 if slug=='prime-zither-blue' else (84 if slug in ('nylon-blue','banjo-blue') else 80))]:
  path=bundle/f'{name}.wav'; subprocess.run([renderer,'--sound',str(dest),'--out',str(path),'--notes',f'{note}:0:60:96','--tail','2'],check=True,capture_output=True,text=True)
  row=stat(path,name); x,sr=sf.read(path,always_2d=True); row['held_rms_dbfs_5_55s']=round(float(20*np.log10(np.sqrt(np.mean(x[int(5*sr):int(55*sr)]**2))+1e-20)),2); row['held_rms_dbfs_10_59s']=round(float(20*np.log10(np.sqrt(np.mean(x[int(10*sr):int(59*sr)]**2))+1e-20)),2)
  if row['held_rms_dbfs_10_59s'] < -50: raise RuntimeError(f'{slug} held note loses energy before note-off: {row}')
  native.append(row);shutil.copy2(path,DEMO/f'{slug}-{name}-60s.wav')
 chordpath=bundle/'chord.wav'; chordnotes=chord
 if slug=='prime-zither-blue':
  # Melody is articulation 0 (default); the down/up strums remain selectable.
  pass
 spec=','.join(f'{n}:0:3:96' for n in chordnotes)
 subprocess.run([renderer,'--sound',str(dest),'--out',str(chordpath),'--notes',spec,'--tail','1'],check=True,capture_output=True,text=True)
 native.append(stat(chordpath,'four-note-chord'));shutil.copy2(chordpath,DEMO/f'{slug}-chord.wav')
 manifest=json.loads((bundle/'manifest.json').read_text()); loops=[]; seams=[]
 for z in manifest.get('zones',[]):
  if z.get('layer')=='body':
   if z.get('one_shot'): continue
   if z.get('loop') is None: raise RuntimeError(f'{slug} body zone has no loop: {z}')
   loops.append(z['loop']);seams.append(_load(bundle,z,False).loop_seam_db)
 if seams and max(seams)>-30: raise RuntimeError(f'{slug} loop seam {max(seams)} dB')
 if any(x['peak_dbfs']>-0.2 or x['clipped_samples'] for x in native):raise RuntimeError(f'{slug} clips or too hot: {native}')
 report={'generated_utc':datetime.now(timezone.utc).isoformat(),'slug':slug,'source_file_counts':counts,
  'manifest_layer_counts':dict(Counter(z.get('layer') for z in manifest.get('zones',[]))),
  'body_zone_count':sum(z.get('layer')=='body' for z in manifest.get('zones',[])),'body_loop_count':len(loops),
  'body_loop_seam_worst_db':max(seams) if seams else None,'body_loop_min_seconds':min((x['end']-x['start'])/SR for x in loops) if loops else None,
  'lint_counts':{k:levels[k] for k in ('FAIL','WARN','INFO')},'lint':lines,'native_renders':native,
  'listening_limit':'Native renders, numerical checks and phrase spectrograms were inspected; no perceptual listening claim is made.'}
 (dest/'verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 # Explain the known source/engine warnings in durable notes and the reply.
 warn=''
 if slug=='banjo-blue':warn='WARN: the upstream author reports residual clipped/noisy portions on some source samples; these were not altered or omitted.\n'
 if slug=='prime-zither-blue':warn='WARN: the upstream SFZ placed G4-labelled recordings two octaves low. Each original source is retained; measured fundamental and source filename were used to map the real register, without pitch shifting.\n'
 if slug in ('nylon-blue','prime-zither-blue','banjo-blue'):warn+='WARN: a plucked recording is finite; the body loops after its recorded attack to satisfy held-note playback. This repeats part of one source performance and is not a naturally endless acoustic note.\n'
 if slug=='chemnitzer-blue':warn='WARN: the upstream source provides finite performances without authored loop points. The loop retains each recorded breath and pressure gesture, joining its ending to an exact earlier same-take overlap; a smooth source overlap transitions into 135 ms of exact source before the wrap, including the final exact 20 ms. B2_f and D3_f are only about 1.04–1.05 s long, leaving about 0.60 s loop cycles after the performed onset and original terminal overlap. Per-root layer gain offsets only correct recorded velocity ladder inversions.\n'
 if slug=='chemnitzer-blue' and any(x.startswith('WARN') for x in lines):
  warn+='\nWARN details: high-frequency/aliasing warnings are source reed attack energy retained from the supplied 44.1 kHz files; brightness warnings mark keys where genuine recorded dynamics differ mainly in level; onset warnings record natural timing variation between separate pressure takes; remaining tuning warnings reflect inter-layer/source tuning spread after the measured per-file corrections. The terminal 20 ms loop overlap is copied exactly from before the same-take loop start; a separate source tail is kept after the loop boundary for de-clicked file termination.\n'
 if slug=='banjo-blue' and any(x.startswith('WARN') for x in lines):
  warn+='\nWARN details: the upstream author documents residual clipping/noise in some recordings; brightness warnings show genuine velocity layers with little spectral change; onset/tuning/loudness warnings report source-performance variation remaining after source-root tuning and monotone gain calibration. Duplicate SFZ references are retained in source proof but mapped once per identical original file and velocity.\n'
 if slug=='prime-zither-blue' and any(x.startswith('WARN') for x in lines):
  warn+='\nWARN details: the aliasing flags identify high-frequency transients in the original attacks and are retained. Onset/loudness flags describe variation among real takes. Melody take tuning is measured per source file with bounded static fine corrections (max 97.9 cents), while down/up drone gestures are untuned; they retain their fixed-pitch G strings. The native default-melody pitch check is within 11.9 cents across the mapped register.\n'
 if slug=='nylon-blue' and any(x.startswith('WARN') for x in lines):
  warn+='\nWARN details: loudness warnings mark genuine adjacent-string/key level differences in the original one-layer recordings; no artificial normalization erases their recorded dynamics.\n'
 if slug in SYN and any(x.startswith('WARN') for x in lines):
  warn+='\nWARN details: these original synths have two authored velocity timbres; the clavinet raises upper partials while the pad moves its resonant bands, but remaining brightness warnings mean the measured spectral difference is below the linter threshold on some keys. Their layer levels remain monotonic, and source construction parameters are recorded in `samples/source-proof.json`.\n'
 title_for=REC[slug][0] if slug in REC else SYN[slug][0]
 notes=f'''# {title_for}

{REC.get(slug,(SYN.get(slug,('',''))[0],SYN.get(slug,('',''))[1],[]))[1] if slug in REC else SYN[slug][1]}

## Mappa, licenza e verifica

Mappa originale, tuning/range, velocity, take, sample originali, SHA-256, file derivati, figure SVG e report QA sono conservati in questa cartella e in `samples/`. La mappa v6 è riproducibile con `python/scripts/build_blue_expansion_v6.py`. Licenza e credit completi sono in `samples/credits.json` e `samples/source-reference/`.

Copertura: {counts}. Lint: FAIL {levels['FAIL']}, WARN {levels['WARN']}, INFO {levels['INFO']}. Seams nativi worst {max(seams) if seams else None} dB. Il JSON in `verification.json` documenta render phrase, low/mid/high hold da 60 s e accordo. Nessun giudizio percettivo è dedotto dalle misure.

{warn}'''
 (dest/'notes.md').write_text(notes)
 return report

def build_one(slug:str):
 dest=BANK/slug
 if dest.exists() and not (dest/'builder-owner.json').exists():raise RuntimeError(f'Refusing to overwrite unowned folder: {dest}')
 dest.mkdir(parents=True,exist_ok=True); samples=dest/'samples';samples.mkdir(exist_ok=True)
 (dest/'builder-owner.json').write_text(json.dumps({'builder':Path(__file__).name,'schema':6},indent=2)+'\n')
 if slug in REC:
  mp=samples/'map.json'; pp=samples/'source-proof.json'
  reusable=False
  if mp.exists() and pp.exists():
   prior=json.loads(mp.read_text()); proofs=json.loads(pp.read_text())
   reusable=all((samples/z['file']).exists() for z in prior['body']+prior.get('tail',[]))
   if slug in ('prime-zither-blue','nylon-blue','banjo-blue'):
    reusable=reusable and bool(proofs) and all((not p.get('derived_file')) or p.get('method')=='same-source phase-fitted periodic continuation' for p in proofs)
   if slug=='prime-zither-blue':
    reusable=reusable and [a[0] for a in prior.get('articulations',[])]==['melody','down','up'] and all(p.get('continuation_rms_dbfs') is not None for p in proofs if p.get('derived_file')) and all(p.get('applied_tune_cents') is not None for p in proofs)
   if slug in ('nylon-blue','chemnitzer-blue'):
    reusable=reusable and all(z.get('articulation')=='normal' for z in prior.get('body',[]))
    reusable=reusable and all(p.get('measured_source_deviation_cents') is not None for p in proofs)
    if slug=='chemnitzer-blue': reusable=reusable and all((not p.get('derived_file')) or (p.get('method')=='same-take sustained pressure loop with exact source overlap' and p.get('ramp_ends_before_exact_tail') and p.get('source_onset_seconds') is not None and p.get('loop_start_seconds',0)>=p['source_onset_seconds']+.05 and p.get('final_source_exact_ms',0)>=135 and p.get('post_loop_source_tail_ms') is not None) for p in proofs)
   if slug=='banjo-blue': reusable=reusable and all(p.get('measured_source_deviation_cents') is not None for p in proofs if p.get('derived_file')) and len({(z['file'],z['root'],z.get('articulation'),tuple(z['vel'])) for z in prior['body']})==len(prior['body'])
  if not reusable: info=map_recorded(slug,samples)
  else:
   prior=json.loads(mp.read_text()); info={'body':len(prior['body']),'tail':len(prior.get('tail',[])),'proof':len(json.loads(pp.read_text())),
     'articulations':prior.get('articulations',[]),'recorded_velocity_regions':sum(x.get('vel')!=[1,127] for x in prior['body'])}
  title,subtitle,tags,_=REC[slug];write_sound(slug,dest,title,subtitle,tags,info)
 else:info=build_synth(slug,dest)
 svg=figure(slug); (dest/'figure.svg').write_text(svg)
 fig=validate_svg((dest/'figure.svg').read_text())
 if fig: raise RuntimeError(f'Invalid figure {slug}: {fig}')
 # Calibrate the actual continued body before SFZ compilation. The adjustment
 # is static and bounded; source WAVs and performed pitch movement stay intact.
 if slug in ('chemnitzer-blue','banjo-blue'):
  stable_body_calibrate_before_compile(dest,slug)
  apply_native_residual_proof(dest,slug)
 result=compile_sound(dest,jobs=1); print(f'COMPILE {slug}: {result.text()}',flush=True)
 if not result.ok:raise RuntimeError(f'Compile failed {slug}: {result.text()}')
 return render_one(slug,dest,info)

def stable_body_calibrate_before_compile(dest:Path,slug:str)->None:
 samples=dest/'samples'; mp=samples/'map.json'; m=json.loads(mp.read_text()); proof=[]
 for r in m.get('body',[]):
  lp=r.get('loop')
  if not lp: continue
  x,sr=sf.read(samples/r['file'],always_2d=True); x=x.mean(axis=1); x=x-float(np.mean(x))
  idx=np.arange(round(1.0*sr),round(1.5*sr)); start=int(lp['start']); end=int(lp['end'])
  idx=np.where(idx>=end,start+(idx-start)%(end-start),idx); seg=x[idx]
  nfft=524288; spec=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),nfft)); hz=np.fft.rfftfreq(nfft,1/sr)
  expected=440.0*2**((int(r['root'])-69)/12); candidates=[]
  for harmonic in (1,2,3,4):
   centre=expected*harmonic; bins=np.flatnonzero((hz>centre*2**(-150/1200))&(hz<centre*2**(150/1200)))
   k=int(bins[np.argmax(spec[bins])]); q=np.log(np.maximum(spec[k-1:k+2],1e-30))
   frac=float(np.clip(.5*(q[0]-q[2])/(q[0]-2*q[1]+q[2]+1e-30),-.5,.5))
   candidates.append(((k+frac)*sr/nfft/harmonic,float(spec[k]),harmonic))
  strongest=max(c[1] for c in candidates); chosen=candidates[0] if candidates[0][1]>strongest*.05 else max(candidates,key=lambda c:c[1])
  cents=float(1200*np.log2(chosen[0]/expected)); tune=-cents
  if abs(tune)>100: raise RuntimeError(f'{slug} {r["file"]} stable-body correction exceeds +/-100 cents: {tune:.2f}')
  proof.append({'file':r['file'],'root':r['root'],'velocity':r.get('vel'),'articulation':r.get('articulation'),
    'previous_tune_cents':r.get('tune_cents',0),'measured_stable_body_hz':chosen[0],
    'measured_stable_body_offset_cents':cents,'tune_cents':tune,
    'measurement':'same-take mapped loop at playback clock 1.0–1.5 s; original audio is unchanged'})
  r['tune_cents']=tune
 mp.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
 (samples/'stable-body-tuning-v6.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
 recipe=dest/'sound.py'; recipe.write_text(recipe.read_text().replace("'tune':'smooth'","'tune':'source'"))
 notes=dest/'notes.md'
 if notes.exists():
  with notes.open('a') as f:
   f.write('\n## Static tuning of the continued body\n\nPer-zone correction is measured on the exact mapped same-take loop at playback time 1.0–1.5 s and stored in `samples/stable-body-tuning-v6.json`. Only static `tune_cents` changes (maximum ±100 cents); recorded WAVs and their pitch movement remain unchanged.\n')

def apply_native_residual_proof(dest:Path,slug:str)->None:
 """Reapply measured engine residuals only to identical derived loop bytes."""
 samples=dest/'samples'; proof_path=samples/'native-residual-tuning-v6.json'
 if not proof_path.exists(): return
 mp=samples/'map.json'; m=json.loads(mp.read_text()); proofs=json.loads(proof_path.read_text()); applied=[]
 for p in proofs:
  f=str(p.get('file','')); candidate=samples/f
  if not candidate.is_file(): continue
  digest_now=digest(candidate)
  if digest_now!=p.get('derived_sha256'): continue
  matches=[r for r in m.get('body',[]) if r.get('file')==f and int(r.get('root',-1))==int(p.get('root',-2)) and r.get('vel')==p.get('velocity')]
  if len(matches)!=1: continue
  r=matches[0]
  # The stored proof's old_tune is the value after the stable-body stage.
  # Always recompute from that baseline, so repeated builder runs are idempotent.
  baseline=float(p['old_tune']); corr=float(p['native_residual_compensation_cents'])
  if abs(float(r.get('tune_cents',0))-baseline)>0.02: continue
  result=baseline+corr
  if abs(result)>100: raise RuntimeError(f'{slug} residual correction exceeds +/-100 cents: {f} {result:.2f}')
  r['tune_cents']=result; applied.append({'file':f,'derived_sha256':digest_now,'root':r['root'],'velocity':r.get('vel'),'baseline_tune_cents':baseline,'compensation_cents':corr,'applied_tune_cents':result})
 if applied:
  mp.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
  # Preserve the original native audit record; this companion proves which
  # entries actually matched this build's derived bytes and map.
  (samples/'native-residual-tuning-applied-v6.json').write_text(json.dumps(applied,indent=2,ensure_ascii=False)+'\n')
  notes=dest/'notes.md'
  if notes.exists():
   with notes.open('a') as f:
    f.write('\nNative residual tuning is reapplied only when the derived loop SHA-256 and file/root/velocity mapping match `samples/native-residual-tuning-v6.json`; see `samples/native-residual-tuning-applied-v6.json` for the rows applied by this build.\n')

def main():
 DEMO.mkdir(parents=True,exist_ok=True);reports=[]
 requested=sys.argv[1:]
 if requested==['--aggregate']:
  for slug in (*REC,*SYN):
   path=BANK/slug/'verification.json'
   if not path.exists():raise SystemExit(f'Missing completed verification: {path}')
   r=json.loads(path.read_text())
   if r['lint_counts']['FAIL'] or (r.get('body_loop_seam_worst_db') is not None and r['body_loop_seam_worst_db']>-30):
    raise SystemExit(f'Final aggregate rejected incomplete QA for {slug}')
   if any(z.get('held_rms_dbfs_10_59s',-120)<-50 for z in r.get('native_renders',[]) if z['name'].startswith('held-')):
    raise SystemExit(f'Final aggregate rejected weak 60s hold for {slug}')
   reports.append(r)
  (DEMO/'report.json').write_text(json.dumps(reports,indent=2,ensure_ascii=False)+'\n')
  print(f'Aggregated {len(reports)} verified instruments: {DEMO}/report.json',flush=True)
  return
 slugs=requested or [*REC,*SYN]
 unknown=set(slugs)-set(REC)-set(SYN)
 if unknown: raise SystemExit(f'Unknown Blue slug(s): {sorted(unknown)}')
 for slug in slugs:
  r=build_one(slug); reports.append(r);(DEMO/'report.json').write_text(json.dumps(reports,indent=2,ensure_ascii=False)+'\n')
 print(f'Report: {DEMO}/report.json',flush=True)
if __name__=='__main__':main()
