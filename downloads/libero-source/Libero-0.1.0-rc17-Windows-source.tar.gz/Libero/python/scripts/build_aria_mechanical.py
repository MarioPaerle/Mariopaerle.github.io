#!/usr/bin/env python3
"""Build Aria sampled music-box and xylophone voices from public originals."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import quote
import json
import re
import shutil
import sys

import numpy as np
import soundfile as sf
from scipy.signal import find_peaks

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero import analysis, render
from libero import dsp

HOME = Path.home()
BANK = HOME / "Libero" / "banks" / "aria"
CACHE = HOME / "Libero" / "cache" / "libraries" / "vcsl"
DEMO = HOME / "Libero" / "demo" / "aria-mechanical"
DEMO.mkdir(parents=True, exist_ok=True)

MUSIC_BOX = [
    {"id": 1870, "label": "F#1", "url": "https://bigsoundbank.com/UPLOAD/bwf-en/1870.wav",
     "page": "https://bigsoundbank.com/music-box-f-1-s1870.html"},
    {"id": 1873, "label": "A#2", "url": "https://bigsoundbank.com/UPLOAD/bwf-en/1873.wav",
     "page": "https://bigsoundbank.com/music-box-ad-2-s1873.html"},
    {"id": 1875, "label": "C#2", "url": "https://bigsoundbank.com/UPLOAD/bwf-en/1875.wav",
     "page": "https://bigsoundbank.com/music-box-cd-2-s1875.html"},
    {"id": 1877, "label": "F#2", "url": "https://bigsoundbank.com/UPLOAD/bwf-en/1877.wav",
     "page": "https://bigsoundbank.com/music-box-f-2-s1877.html"},
    {"id": 1879, "label": "G#3", "url": "https://bigsoundbank.com/UPLOAD/bwf-en/1879.wav",
     "page": "https://bigsoundbank.com/music-box-gd-3-s1879.html"},
]
XYLO = Path("Idiophones/Struck Idiophones/Xylophone")
MALLETS = ("Soft Mallets", "Medium Mallets", "Hard Mallets")
XYLO_NOTES = ("G3", "C4", "G4", "C5", "G5", "C6", "G6", "C7")
PITCH = {"C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3,
         "E": 4, "F": 5, "F#": 6, "Gb": 6, "G": 7, "G#": 8,
         "Ab": 8, "A": 9, "A#": 10, "Bb": 10, "B": 11}
TOY_MEDIAFIRE = "https://www.mediafire.com/file/9z42woac5zgbjf2/Toy.zip"
TOY_MIRROR_PAGE = "https://bigcatinstruments.blogspot.com/2017/03/freesound.html"
TOY_IDS = {
    196916: ("C#4", "196916__corsica-s__srhoenhut-mfp-c#.wav"),
    196917: ("B4", "196917__corsica-s__srhoenhut-mfp-b4.wav"),
    196918: ("A4", "196918__corsica-s__srhoenhut-mfp-a4.wav"),
    196919: ("A#4", "196919__corsica-s__srhoenhut-mfp-a#4.wav"),
    196920: ("D#4", "196920__corsica-s__srhoenhut-mfp-a#5.wav"),
    196921: ("C5", "196921__corsica-s__srhoenhut-mfp-c5.wav"),
    196922: ("C4", "196922__corsica-s__srhoenhut-mfp-c.wav"),
    196923: ("C#5", "196923__corsica-s__srhoenhut-mfp-c#5.wav"),
    196924: ("D4", "196924__corsica-s__srhoenhut-mfp-d.wav"),
    196925: ("D#5", "196925__corsica-s__srhoenhut-mfp-d#5.wav"),
    196929: ("E4", "196929__corsica-s__srhoenhut-mfp-b5.wav"),
    196930: ("D5", "196930__corsica-s__srhoenhut-mfp-d5.wav"),
    196931: ("G#4", "196931__corsica-s__srhoenhut-mfp-g#4.wav"),
    196932: ("E5", "196932__corsica-s__srhoenhut-mfp-e5.wav"),
    196933: ("G4", "196933__corsica-s__srhoenhut-mfp-g4.wav"),
    196934: ("F4", "196934__corsica-s__srhoenhut-mfp-f4.wav"),
    196935: ("F5", "196935__corsica-s__srhoenhut-mfp-f5.wav"),
    196936: ("F#4", "196936__corsica-s__srhoenhut-mfp-f#4.wav"),
}
TOY_UNMAPPED = {}


def fetch(url: str, dest: Path) -> bytes:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        req = Request(url, headers={"User-Agent": "Libero-Aria/1.0 (source acquisition)"})
        with urlopen(req, timeout=60) as response:
            payload = response.read()
        if len(payload) < 1024:
            raise RuntimeError(f"Unexpectedly small source download: {url} ({len(payload)} bytes)")
        dest.write_bytes(payload)
    return dest.read_bytes()


def midi(note: str) -> int:
    m = re.fullmatch(r"([A-G](?:#|b)?)(-?\d+)", note)
    if not m:
        raise ValueError(note)
    return (int(m.group(2)) + 1) * 12 + PITCH[m.group(1)]


def measure_pitch(path: Path) -> dict:
    raw, sr = sf.read(path, dtype="float64", always_2d=True)
    x = raw.mean(axis=1)
    segment = x[int(.05 * sr):min(len(x), int(.45 * sr))]
    if len(segment) < 2048:
        segment = x
    nfft = 1 << int(np.ceil(np.log2(max(4096, len(segment) * 8))))
    spectrum = np.abs(np.fft.rfft(segment * np.hanning(len(segment)), n=nfft))
    freqs = np.fft.rfftfreq(nfft, 1 / sr)
    peaks, _ = find_peaks(spectrum)
    peaks = [int(p) for p in peaks if 40 <= freqs[p] <= 12000]
    peaks.sort(key=lambda i: spectrum[i], reverse=True)
    if not peaks:
        raise RuntimeError(f"No tonal peak found: {path}")
    f0 = float(freqs[peaks[0]])
    note = int(round(69 + 12 * np.log2(f0 / 440)))
    cents = 1200 * np.log2(f0 / (440 * 2 ** ((note - 69) / 12)))
    peak = float(np.max(np.abs(x)))
    rms = float(np.sqrt(np.mean(x * x)))
    return {"sr": sr, "seconds": len(x) / sr, "f0_hz": round(f0, 3),
            "measured_midi": note, "cents_from_equal_temperament": round(float(cents), 2),
            "peak_dbfs": round(20 * np.log10(max(peak, 1e-12)), 2),
            "rms_dbfs": round(20 * np.log10(max(rms, 1e-12)), 2),
            "sha256": sha256(path.read_bytes()).hexdigest()}


def write_musicbox_source(dest: Path) -> tuple[list[dict], list[dict]]:
    samples = dest / "samples"
    rows, regions, audits = [], [], []
    for item in MUSIC_BOX:
        filename = f"musicbox-{item['id']}.wav"
        target = samples / "src" / filename
        fetch(item["url"], target)
        measured = measure_pitch(target)
        measured.update({"file": f"src/{filename}", "source_label": item["label"],
                         "source_page": item["page"], "source": "BigSoundBank",
                         "author": "Joseph SARDIN", "license": "CC0 1.0"})
        rows.append(measured)
        body_name = f"musicbox-{item['id']}-body.wav"
        loop, audit = derive_source_body(target, samples / "body" / body_name, measured["measured_midi"])
        audit.update({"source_id": item["id"], "kind": "music-box"})
        audits.append(audit)
        regions.append({"file": f"body/{body_name}", "root": measured["measured_midi"], "take": 0,
                        "tune_cents": -measured["cents_from_equal_temperament"], "loop": loop})
    (samples / "credits.json").write_text(json.dumps([
        {"source": "BigSoundBank / LaSonotheque music-box single-note recordings",
         "author": "Joseph SARDIN", "license": "CC0 1.0", "license_class": "cc0",
         "url": "https://bigsoundbank.com/", "retrieved": datetime.now(timezone.utc).date().isoformat(),
         "notes": "Five individually downloadable full-resolution BWF/WAV note recordings. Source note labels are retained in provenance; playback roots are measured from each file."}
    ], indent=2) + "\n")
    (samples / "provenance.json").write_text(json.dumps(rows, indent=2) + "\n")
    (samples / "map.json").write_text(json.dumps({"body": regions}, indent=2) + "\n")
    (samples / "infinite-provenance.json").write_text(json.dumps(audits, indent=2) + "\n")
    return rows, regions


def acquire_toy_archive() -> Path:
    cache = HOME / "Libero" / "cache" / "sources" / "bigcat-toy.zip"
    cache.parent.mkdir(parents=True, exist_ok=True)
    if cache.exists() and cache.stat().st_size > 10_000_000:
        return cache
    with urlopen(Request(TOY_MEDIAFIRE, headers={"User-Agent": "Mozilla/5.0 Libero source fetch"}), timeout=45) as r:
        page = r.read().decode("utf-8", errors="replace")
    match = re.search(r'https://download\d+\.mediafire\.com/[^"\\ ]+/9z42woac5zgbjf2/Toy\.zip', page)
    if not match:
        raise RuntimeError("Public BigCat Toy.zip page did not expose a direct download link")
    with urlopen(Request(match.group(0), headers={"User-Agent": "Libero source fetch"}), timeout=90) as r:
        data = r.read()
    if len(data) < 10_000_000 or not data.startswith(b"PK"):
        raise RuntimeError("BigCat mirror download was not a full Toy.zip archive")
    cache.write_bytes(data)
    return cache


def measure_toy_pitch(path: Path, target_note: str) -> dict:
    raw, sr = sf.read(path, dtype="float64", always_2d=True)
    x = raw.mean(axis=1)
    expected_midi = midi(target_note)
    expected_hz = 440 * 2 ** ((expected_midi - 69) / 12)
    segment = x[int(.04 * sr):min(len(x), int(.45 * sr))]
    yinf0, voiced = dsp.estimate_f0(segment, sr, fmin=100, fmax=1800)
    method = "YIN"
    # Most notes have a stable weak fundamental that YIN can recover. Two
    # strongly inharmonic Schoenhut notes do not; their tine modes follow a
    # characteristic 3, 6, 10, 15, 21 family, so infer the root from several
    # modes together instead of mistaking one unrelated low resonance for f0.
    if np.isfinite(yinf0) and abs(1200 * np.log2(yinf0 / expected_hz)) < 75:
        f0 = float(yinf0)
        method = "YIN agreement with Freesound source note"
    else:
        nfft = 1 << int(np.ceil(np.log2(max(65536, len(segment) * 16))))
        spectrum = np.abs(np.fft.rfft(segment * np.hanning(len(segment)), n=nfft))
        freqs = np.fft.rfftfreq(nfft, 1 / sr)
        peak_ix, _ = find_peaks(spectrum)
        peak_ix = np.asarray([i for i in peak_ix if 200 <= freqs[i] <= 15000], dtype=int)
        # A clearly measured low tine mode near the source note is better root
        # evidence than a family fit that assumes ideal partial ratios. This is
        # especially useful for the low E recording, whose upper modes are stiff.
        root_band = np.where((freqs >= expected_hz * 2 ** (-45 / 1200)) &
                             (freqs <= expected_hz * 2 ** (45 / 1200)))[0]
        if len(root_band):
            root_ix = int(root_band[np.argmax(spectrum[root_band])])
            if spectrum[root_ix] >= spectrum.max() * 10 ** (-22 / 20):
                f0 = float(freqs[root_ix])
                method = "measured low tine resonance near Freesound source note"
                measured_midi = int(round(69 + 12 * np.log2(f0 / 440)))
                cents = 1200 * np.log2(f0 / (440 * 2 ** ((measured_midi - 69) / 12)))
                return {"sr": sr, "seconds": len(x) / sr, "f0_hz": round(f0, 3),
                        "measured_midi": measured_midi, "cents_from_equal_temperament": round(float(cents), 2),
                        "pitch_method": method, "yin_voiced_fraction": round(float(voiced), 3),
                        "peak_dbfs": round(20 * np.log10(max(float(np.max(np.abs(x))), 1e-12)), 2),
                        "rms_dbfs": round(20 * np.log10(max(float(np.sqrt(np.mean(x * x))), 1e-12)), 2),
                        "sha256": sha256(path.read_bytes()).hexdigest()}
        strongest = peak_ix[np.argsort(spectrum[peak_ix])[-60:]]
        partials = (3, 6, 10, 15, 21)
        candidates = []
        for i in strongest:
            for partial in partials:
                candidate = float(freqs[i] / partial)
                if abs(1200 * np.log2(candidate / expected_hz)) <= 180:
                    candidates.append(candidate)
        best = None
        for candidate in candidates:
            score, matches = 0.0, []
            for partial in partials:
                target = candidate * partial
                local = peak_ix[np.abs(freqs[peak_ix] - target) < target * .018]
                if len(local):
                    k = int(local[np.argmax(spectrum[local])])
                    cents = float(1200 * np.log2(freqs[k] / target))
                    value = float(spectrum[k] / max(spectrum.max(), 1e-20) * np.exp(-.5 * (cents / 25) ** 2))
                    score += value
                    matches.append((float(freqs[k] / partial), value))
            if len(matches) >= 3 and (best is None or score > best[0]):
                best = (score, matches)
        if best is not None:
            vals = np.asarray([m[0] for m in best[1]])
            weights = np.asarray([m[1] for m in best[1]])
            f0 = float(np.average(vals, weights=np.maximum(weights, 1e-6)))
            method = "multi-mode inharmonic tine-family fit"
        else:
            band = np.where((freqs >= expected_hz * 2 ** (-90 / 1200)) &
                            (freqs <= expected_hz * 2 ** (90 / 1200)))[0]
            if not len(band):
                raise RuntimeError(f"No spectral evidence near source note {target_note}: {path}")
            f0 = float(freqs[band[np.argmax(spectrum[band])]])
            method = "FFT local mode (weak fundamental; inspect provenance)"
    measured_midi = int(round(69 + 12 * np.log2(f0 / 440)))
    cents = 1200 * np.log2(f0 / (440 * 2 ** ((measured_midi - 69) / 12)))
    return {"sr": sr, "seconds": len(x) / sr, "f0_hz": round(f0, 3),
            "measured_midi": measured_midi, "cents_from_equal_temperament": round(float(cents), 2),
            "pitch_method": method, "yin_voiced_fraction": round(float(voiced), 3),
            "peak_dbfs": round(20 * np.log10(max(float(np.max(np.abs(x))), 1e-12)), 2),
            "rms_dbfs": round(20 * np.log10(max(float(np.sqrt(np.mean(x * x))), 1e-12)), 2),
            "sha256": sha256(path.read_bytes()).hexdigest()}


def write_toy_source(dest: Path) -> tuple[list[dict], list[dict]]:
    samples = dest / "samples"
    archive = acquire_toy_archive()
    archive_sha = sha256(archive.read_bytes()).hexdigest()
    rows, regions, audits = [], [], []
    import zipfile
    with zipfile.ZipFile(archive) as zf:
        members = set(zf.namelist())
        archive_entries = []
        alias_dir = samples / "src" / "archive-aliases"
        for member in sorted(m for m in members if m.startswith("CorsicaS First Piano Samples/") and m.lower().endswith(".wav")):
            data = zf.read(member)
            alias_path = alias_dir / Path(member).name
            alias_path.parent.mkdir(parents=True, exist_ok=True)
            alias_path.write_bytes(data)
            match = re.match(r"(\d+)__", Path(member).name)
            archive_entries.append({"archive_member": member, "preserved_as": f"src/archive-aliases/{Path(member).name}",
                          "source_id": int(match.group(1)) if match else None,
                          "bytes": len(data), "sha256": sha256(data).hexdigest()})
        for sound_id, (note, member_name) in TOY_IDS.items():
            member = f"CorsicaS First Piano Samples/{member_name}"
            if member not in members:
                raise RuntimeError(f"Missing original toy-piano recording in mirror: {member}")
            filename = f"schoenhut-{sound_id}.wav"
            target = samples / "src" / filename
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(zf.read(member))
            measured = measure_toy_pitch(target, note)
            playback_root = measured["measured_midi"]
            measured.update({"file": f"src/{filename}", "source_id": sound_id,
                             "source_note_title": note, "source": "Freesound / Tim Kahn (Corsica_S)",
                             "playback_root": playback_root,
                             "used_in_instrument": sound_id not in TOY_UNMAPPED,
                             "mapping_note": TOY_UNMAPPED.get(sound_id),
                             "license": "CC BY 4.0", "source_page": f"https://freesound.org/people/tim.kahn/sounds/{sound_id}/",
                             "mirror_member": member, "mirror_page": TOY_MIRROR_PAGE,
                             "archive_sha256": archive_sha})
            rows.append(measured)
            root = playback_root
            if sound_id not in TOY_UNMAPPED:
                body_name = f"schoenhut-{sound_id}-body.wav"
                join_end = .350 if sound_id == 196929 else .650
                loop, continuation_audit = derive_source_body(target, samples / "body" / body_name, root,
                                                             transition_end=join_end)
                continuation_audit.update({"source_id": sound_id, "kind": "toy-piano"})
                audits.append(continuation_audit)
                regions.append({"file": f"body/{body_name}", "root": root, "take": 0,
                                "tune_cents": -measured["cents_from_equal_temperament"], "loop": loop})
    grouped = {}
    for a in archive_entries:
        grouped.setdefault(a["source_id"], []).append(a)
    audit_doc = {
        "archive_sha256": archive_sha,
        "preserved_original_wavs": len(archive_entries),
        "included_source_ids": sorted(TOY_IDS),
        "mapped_source_ids": sorted(set(TOY_IDS) - set(TOY_UNMAPPED)),
        "preserved_but_not_mapped": {str(k): v for k, v in TOY_UNMAPPED.items()},
        "included_reason": "All eighteen distinct Corsica_S / Tim Kahn Schoenhut My First Piano single-note recordings are preserved and mapped. The two notes with weak fundamentals use a documented multi-mode fit to their inharmonic tine families rather than a single misleading low spectral peak.",
        "deduplicated_aliases": {str(k): [x["preserved_as"] for x in v] for k, v in grouped.items() if len({x["sha256"] for x in v}) == 1 and len(v) > 1},
        "excluded_folders": [
            {"folder": "Tombola Toy Samples", "reason": "Creative Commons Sampling Plus, a separate and less permissive license."},
            {"folder": "Beskhu Toy Piano Samples", "reason": "Native Instruments NCW containers, not original WAV source recordings; not needed for this sampled Schoenhut voice."},
            {"folder": "Poissonmort Toy Piano Samples", "reason": "Native Instruments NCW containers; not needed for this sampled Schoenhut voice."}
        ],
        "entries": archive_entries
    }
    (samples / "archive-audit.json").write_text(json.dumps(audit_doc, indent=2) + "\n")
    (samples / "credits.json").write_text(json.dumps([
        {"source": "Schoenhut My First Piano original single-note WAVs (Freesound 196916–196936; public BigCat Kontakt archive)",
         "author": "Tim Kahn (Freesound account formerly Corsica_S)", "license": "CC BY 4.0",
         "license_class": "by", "url": "https://freesound.org/people/tim.kahn/sounds/196916/",
         "mirror_url": TOY_MIRROR_PAGE, "retrieved": datetime.now(timezone.utc).date().isoformat(),
                             "notes": "All 29 CorsicaS folder WAV archive entries are preserved under samples/src/archive-aliases/ and audited by SHA-256; they resolve to eighteen unique single-note recordings, all mapped. Two roots with weak fundamentals use a documented multi-mode fit to their inharmonic tine families. The original Freesound pages confirm a physical Schoenhut My First Piano, single-note recordings, Sennheiser 8060 into modified Marantz PMD661, and Attribution 4.0. Other authors' archive folders are excluded with reasons in archive-audit.json."}
    ], indent=2) + "\n")
    (samples / "provenance.json").write_text(json.dumps(rows, indent=2) + "\n")
    (samples / "map.json").write_text(json.dumps({"body": regions}, indent=2) + "\n")
    (samples / "infinite-provenance.json").write_text(json.dumps(audits, indent=2) + "\n")
    return rows, regions


def vcsl_source_path(relative: Path) -> tuple[Path, str]:
    cached = CACHE / relative
    url = "https://raw.githubusercontent.com/sgossner/VCSL/master/" + quote(relative.as_posix(), safe="/")
    return cached, url


def write_xylo_source(dest: Path) -> tuple[list[dict], list[dict]]:
    samples = dest / "samples"
    rows, body_regions, audits = [], [], []
    art_ids = {"Soft Mallets": "soft", "Medium Mallets": "medium", "Hard Mallets": "hard"}
    for note in XYLO_NOTES:
        for m_idx, mallet in enumerate(MALLETS):
            for vel_name, vel in (("pp", [1, 63]), ("ff", [64, 127])):
                rel = XYLO / mallet / f"Xylo_{mallet.split()[0]}_{note}_{vel_name}_01_far.wav"
                cached, url = vcsl_source_path(rel)
                target = samples / "src" / f"{mallet.split()[0].lower()}-{note}-{vel_name}.wav"
                if cached.exists():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    if not target.exists():
                        target.write_bytes(cached.read_bytes())
                else:
                    fetch(url, target)
                measured = measure_pitch(target)
                nominal = midi(note)
                measured.update({"file": f"src/{target.name}", "source_file": rel.as_posix(),
                                 "source_note_label": note, "source_velocity_label": vel_name,
                                 "mallet_family": mallet, "source_nominal_midi": nominal,
                                 "playback_root": nominal + 12,
                                 "measured_offset_semitones": measured["measured_midi"] - nominal,
                                 "source": "VCSL", "license": "CC0 1.0",
                                 "url": "https://github.com/sgossner/VCSL"})
                rows.append(measured)
                target_hz = 440 * 2 ** ((nominal + 12 - 69) / 12)
                tune_cents = 1200 * np.log2(target_hz / measured["f0_hz"])
                shared = {"root": nominal + 12, "tune_cents": float(tune_cents),
                          "vel": vel, "articulation": art_ids[mallet]}
                body_name = f"{target.stem}-body.wav"
                body_path = samples / "body" / body_name
                join_end = .350 if note == "G6" and mallet == "Hard Mallets" else .650
                loop, audit = derive_source_body(target, body_path, nominal + 12,
                                                 period=6.0 if nominal < 72 else 5.0,
                                                 transition_end=join_end)
                measured["continuation"] = audit
                audits.append({"file": target.name, **audit})
                body_regions.append({"file": f"body/{body_name}", "root": nominal + 12,
                                     "vel": vel, "articulation": art_ids[mallet],
                                     "tune_cents": float(tune_cents), "loop": loop})
    (samples / "credits.json").write_text(json.dumps([
        {"source": "Versilian Community Sample Library (VCSL), Xylophone / far mic",
         "author": "Versilian Studios / Sam Gossner", "license": "CC0 1.0",
         "license_class": "cc0", "url": "https://github.com/sgossner/VCSL",
         "license_url": "https://raw.githubusercontent.com/sgossner/VCSL/master/LICENSE",
         "retrieved": datetime.now(timezone.utc).date().isoformat(),
         "notes": "Uses full original recordings from soft, medium and hard mallet articulations at both pp and ff. The mallets are exposed as articulations, not randomized round robins."}
    ], indent=2) + "\n")
    (samples / "provenance.json").write_text(json.dumps(rows, indent=2) + "\n")
    (samples / "map.json").write_text(json.dumps({"body": body_regions}, indent=2) + "\n")
    (samples / "infinite-provenance.json").write_text(json.dumps(audits, indent=2) + "\n")
    return rows, body_regions


def derive_source_body(src_path: Path, dest: Path, root: int, period: float = 6.0,
                       transition_end: float = .650) -> tuple[dict, dict]:
    """Keep the recorded gesture, then continue the same source's measured modes.

    The loop is an explicitly designed sustain, not a claim that a struck object
    rings forever. Frequencies, modal ratios, amplitudes and phases are fitted to
    the source. No independent oscillator bed or random-phase layer is added.
    """
    raw, sr0 = sf.read(src_path, dtype="float64", always_2d=True)
    if sr0 != 48000:
        # scipy resampling preserves the measured take and yields stable loop indices.
        from scipy.signal import resample_poly
        import math
        g = math.gcd(int(sr0), 48000)
        raw = resample_poly(raw, 48000 // g, int(sr0) // g, axis=0)
    sr = 48000
    untrimmed = raw.mean(axis=1)
    # Some music-box files have tens of milliseconds of room silence before the
    # real strike. Anchor fitting and transition times to the detected gesture,
    # while preserving a few milliseconds of its genuine lead-in.
    abs_x = np.abs(untrimmed)
    win = max(1, int(.001 * sr))
    env = np.sqrt(np.convolve(abs_x ** 2, np.ones(win) / win, mode="same"))
    threshold = max(float(np.max(env)) * 10 ** (-36 / 20), 1e-5)
    active = np.flatnonzero(env >= threshold)
    onset = int(active[0]) if len(active) else 0
    preroll_n = int(.005 * sr)
    cut = max(0, onset - preroll_n)
    x = untrimmed[cut:].copy()
    x -= np.mean(x[-min(len(x), int(.25 * sr)):])
    onset_in_x = onset - cut
    onset_offset = onset_in_x / sr
    begin, end = onset_offset + .040, min(onset_offset + .300, len(x) / sr - .10)
    if end <= begin + .12:
        raise RuntimeError(f"Source too short for a source-led continuation: {src_path}")
    seg = x[int(begin * sr):int(end * sr)]
    win = np.hanning(len(seg))
    nfft = 262144
    X = np.fft.rfft(seg * win, n=nfft)
    power = np.abs(X) ** 2
    freq = np.fft.rfftfreq(nfft, 1 / sr)
    peaks, _ = find_peaks(power, distance=max(1, int(1.5 / (sr / nfft))))
    peaks = peaks[(freq[peaks] > 35) & (freq[peaks] < min(15500, sr * .45))]
    # The tail of these short struck recordings still contains real low modes;
    # do not mistake it for a noise-only calibration window. Keep every clear
    # early component above a conservative relative source floor.
    peaks = peaks[power[peaks] > power.max() * 10 ** (-48 / 10)]
    peaks = peaks[np.argsort(power[peaks])[-900:]]
    if len(peaks) < 3:
        raise RuntimeError(f"Only {len(peaks)} source modes above the measured floor: {src_path}")

    n = int(round(period * sr))
    spectrum = np.zeros(n // 2 + 1, dtype=np.complex128)
    modes = []
    for k in peaks:
        if k < 1 or k + 1 >= len(power):
            continue
        logs = np.log(np.maximum(power[k - 1:k + 2], 1e-30))
        denom = logs[0] - 2 * logs[1] + logs[2]
        frac = np.clip(.5 * (logs[0] - logs[2]) / denom if abs(denom) > 1e-20 else 0, -.5, .5)
        hz = (k + frac) * sr / nfft
        dst = int(round(hz * period))
        if not 0 < dst < n // 2:
            continue
        c = (X[k] * (1 - abs(frac)) + X[k + (1 if frac >= 0 else -1)] * abs(frac)) * 2 / win.sum()
        c *= np.exp(-2j * np.pi * hz * begin)
        spectrum[dst] += n * c / 2
        modes.append({"measured_hz": round(float(hz), 4), "cycle_hz": round(dst / period, 4),
                      "level_db": round(float(20 * np.log10(abs(c) / np.sqrt(2) + 1e-20)), 2)})
    if len(modes) < 3:
        raise RuntimeError(f"Modal projection collapsed for {src_path}")
    cycle = np.fft.irfft(spectrum, n=n)
    natural = float(np.sqrt(np.mean(x[int((onset_offset + .04) * sr):int((onset_offset + .16) * sr)] ** 2)))
    attack_peak = float(np.max(np.abs(x[:int(.10 * sr)])))
    target = natural * 10 ** (-1.5 / 20)
    cycle *= target / max(float(np.sqrt(np.mean(cycle ** 2))), 1e-15)

    # Leave the first 180 ms after the detected strike untouched, then blend
    # source and modal continuation at the same absolute time. A short settling
    # interval puts the explicit loop after both the splice and its last fade.
    hold = int((onset_offset + .180) * sr)
    join = int((onset_offset + transition_end) * sr)
    prefix = cycle[:join].copy()
    prefix[:hold] = x[:hold]
    u = np.linspace(0, 1, join - hold)
    u = u * u * (3 - 2 * u)
    prefix[hold:join] = x[hold:join] * (1 - u) + cycle[hold:join] * u
    settle = int(.350 * sr)
    total = join + settle + n
    y = cycle[np.arange(total) % n].copy()
    y[:join] = prefix
    loop_start = join + settle
    loop_end = loop_start + n
    dest.parent.mkdir(parents=True, exist_ok=True)
    sf.write(dest, y.astype(np.float32), sr, subtype="PCM_24")
    w = int(.020 * sr)
    seam = 10 * np.log10((np.sum((y[loop_start-w:loop_start] - y[loop_end-w:loop_end]) ** 2) + 1e-30) /
                         (np.sum(y[loop_start-w:loop_start] ** 2) + np.sum(y[loop_end-w:loop_end] ** 2) + 1e-30))
    return {"start": loop_start, "end": loop_end}, {
        "source": src_path.name, "period_seconds": period, "loop_seam_db_20ms": round(float(seam), 2),
        "detected_onset_seconds": round(onset / sr, 5),
        "preserved_preroll_seconds": round(onset_offset, 5),
        "recorded_attack_seconds": .180, "transition_end_seconds": transition_end,
        "sustain_settle_seconds": .350, "source_analysis_window_seconds": [round(begin, 4), round(end, 4)],
        "measured_component_count": len(modes), "components": sorted(modes, key=lambda m: m["measured_hz"]),
        "source_attack_peak_dbfs": round(20 * np.log10(attack_peak + 1e-20), 2),
        "continuation_rms_dbfs": round(20 * np.log10(target + 1e-20), 2),
        "continuation_vs_transient_db": round(20 * np.log10(target / max(attack_peak, 1e-20)), 2),
        "loop_start_sample": loop_start, "loop_end_sample": loop_end,
    }


def musicbox_figure() -> str:
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
<title>Carillon particolare</title><desc>La molla dorata è la carica meccanica; i cinque denti corrispondono ai cinque campioni misurati, mentre la cassa tratteggiata ne prolunga le risonanze.</desc>
<path d="M114 321V229Q114 205 138 205H370Q394 205 394 229V321L369 342H139Z" fill="#f3eee6" stroke-width="1.3"/>
<path d="M139 234H369M139 312H369M148 225V303M360 225V303" stroke-width=".8"/>
<path d="M164 234V299M190 234V299M216 234V299M242 234V299M268 234V299M294 234V299M320 234V299M346 234V299" stroke-width=".7"/>
<path d="M153 247H356M153 257H356M153 267H356M153 277H356M153 287H356" stroke-width=".42"/>
<path d="M211 160C185 137 196 109 225 109C251 109 257 137 233 150C210 163 185 153 186 132C187 111 215 99 239 109C268 121 270 153 248 165C228 176 198 169 196 150" stroke="#b8924f" stroke-width="1.35"/>
<path d="M246 164L260 194M250 192L279 183L287 203L258 213Z" stroke-width="1.15"/>
<circle cx="258" cy="202" r="5.5" fill="#b8924f" stroke-width=".8"/>
<path d="M170 348Q256 371 342 348M181 359Q256 379 331 359" stroke-width=".65"/>
<path d="M155 366l12 3m7-1 11 3m7-2 11 4m8-2 11 4m8-2 11 4m8-2 11 4m8-2 11 4m8-2 11 4m8-2 11 4m8-2 11 3m8-1 11 3" stroke-width=".4"/>
</svg>
"""


def xylo_figure() -> str:
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
<title>Xilofono vivo</title><desc>Le barre scalate segnano le otto radici registrate; le tre mazze arrivano ai tasti, con quella centrale dorata. I risonatori a imbuto portano la coda ciclica ricavata dalle stesse registrazioni.</desc>
<path d="M102 224L414 276L402 296L91 244Z" fill="#f3eee6" stroke-width="1.3"/>
<path d="M117 225L124 197L167 204L161 233ZM169 234L177 200L220 207L213 241ZM222 244L230 204L273 211L266 251ZM275 253L283 208L326 215L319 260ZM328 262L336 212L379 219L372 270ZM381 271L389 216L414 220L407 276Z" fill="#f3eee6" stroke-width="1.15"/>
<path d="M119 226L161 233M171 235L213 241M224 245L266 251M277 254L319 260M330 263L372 270" stroke-width=".55"/>
<path d="M119 214l5-12m4 14 6-13m4 14 6-12m4 14 6-12M172 220l5-15m4 16 6-15m4 16 6-14m4 15 7-14M225 230l5-17m4 18 6-16m4 17 7-16m4 17 7-15M278 239l5-20m4 21 7-19m4 20 7-18m4 19 7-17M331 247l5-23m4 24 7-22m4 23 7-20m4 21 7-20" stroke-width=".42"/>
<path d="M138 285Q149 314 160 285M194 294Q205 323 216 294M251 303Q262 332 273 303M308 312Q319 341 330 312M365 322Q376 351 387 322" stroke-width=".85"/>
<path d="M126 367L196 304M256 350L256 261M386 365L317 304" stroke-width="1.1"/>
<circle cx="194" cy="306" r="10" fill="#b8924f" stroke-width="1.1"/>
<path d="M160 347l13-12m-4 20 13-12m192 4-13-12m4 20-13-12" stroke-width=".42"/>
</svg>
"""


def toy_figure() -> str:
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
<title>Piano giocattolo</title><desc>Martelletti piccoli colpiscono le lamelle metalliche; righe incise segnano il mobile e la coda risonante si apre sotto il telaio.</desc>
<path d="M94 226H418V304H94Z" fill="#f3eee6" stroke-width="1.3"/><path d="M105 238H407M105 291H407" stroke-width=".75"/>
<path d="M113 252H146M153 252H186M193 252H226M233 252H266M273 252H306M313 252H346M353 252H386M393 252H406" stroke-width="1.1"/>
<path d="M119 258L139 258M159 258L179 258M199 258L219 258M239 258L259 258M279 258L299 258M319 258L339 258M359 258L379 258M397 258L405 258" stroke="#b8924f" stroke-width="1.4"/>
<path d="M128 189L139 216M208 178L219 216M288 184L299 216M368 177L379 216" stroke-width="1"/>
<path d="M123 177L135 177L142 190L130 195ZM203 166L215 166L222 179L210 184ZM283 172L295 172L302 185L290 190ZM363 165L375 165L382 178L370 183Z" fill="#f3eee6" stroke-width="1"/>
<circle cx="135" cy="216" r="4" fill="#b8924f" stroke-width=".8"/><circle cx="215" cy="216" r="4" fill="#b8924f" stroke-width=".8"/><circle cx="295" cy="216" r="4" fill="#b8924f" stroke-width=".8"/><circle cx="375" cy="216" r="4" fill="#b8924f" stroke-width=".8"/>
<path d="M122 305L111 358M390 305L401 358M110 358H153M359 358H402M161 330Q256 375 351 330M172 341Q256 379 340 341" stroke-width=".9"/>
<path d="M182 347l11 4m8-1 11 4m8-1 11 4m8-1 11 4m8-1 11 4m8-1 11 4m8-1 11 4m8-1 11 4" stroke-width=".45"/>
</svg>
"""


def emit_sound(slug: str, title: str, subtitle: str, description: str, roots: list[int],
               figure: str, technique: str, peak_db: float, attack: int,
               release_ms: int, loop_min_s: float, dynamics: bool, kind: str) -> None:
    dest = BANK / slug
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "figure.svg").write_text(figure)
    recipe = f'''from pathlib import Path
import json, math
import numpy as np
from libero import Audio, Sound
ROOTS = {roots!r}
PROFILES = json.loads((Path(__file__).parent / "samples" / "provenance.json").read_text())
ATTACKS = json.loads((Path(__file__).parent / "samples" / "attack_map.json").read_text())
sound = Sound(title={title!r}, subtitle={subtitle!r},
    tags=["aria", "sampled", "warm", "melody"], roots=ROOTS,
    velocities={[28, 60, 96, 120] if dynamics else [96]!r}, sample_rate=48000, takes={3 if dynamics else 1})

def source_for(ctx):
    choices = [p for p in PROFILES if p.get("file") and p.get("measured_midi") is not None
               and p.get("used_in_instrument", True)]
    if {kind!r} == "xylo":
        desired_vel = "pp" if ctx.velocity < 64 else "ff"
        choices = [p for p in choices if p["source_velocity_label"] == desired_vel
                   and p["mallet_family"].startswith(("Soft", "Medium", "Hard"))]
        families = ["Soft Mallets", "Medium Mallets", "Hard Mallets"]
        family = families[ctx.take % len(families)]
        choices = [p for p in choices if p["mallet_family"] == family]
    p = min(choices, key=lambda r: abs(r.get("playback_root", r["measured_midi"]) - ctx.note))
    return p, ctx.load(p["file"])

@sound.body
def body(ctx):
    p, src = source_for(ctx)
    x = src.to_mono().data.astype(np.float64)
    # Measure a real mid-decay spectrum; retain its inharmonic mode ratios and
    # relative strengths so the infinite sustain remains material-specific.
    a, b = int(.075 * ctx.sr), min(len(x), int(.32 * ctx.sr))
    if b - a < 2048:
        a, b = 0, min(len(x), int(.25 * ctx.sr))
    seg = x[a:b]
    nfft = max(65536, 1 << int(np.ceil(np.log2(len(seg) * 4))))
    spec = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), n=nfft))
    hz = np.fft.rfftfreq(nfft, 1 / ctx.sr)
    from scipy.signal import find_peaks
    peaks, _ = find_peaks(spec, distance=max(2, int(18 * nfft / ctx.sr)))
    peaks = [int(i) for i in peaks if 55 <= hz[i] <= min(12000, ctx.sr * .47)]
    peaks.sort(key=lambda i: spec[i], reverse=True)
    peaks = [i for i in peaks if spec[i] >= spec[peaks[0]] * 10**(-43/20)][:36]
    if not peaks:
        raise ValueError("No measured source modes")
    f0 = float(p["f0_hz"])
    dur = 6.0
    n = int(round(dur * ctx.sr))
    t = np.arange(n, dtype=np.float64) / ctx.sr
    rng = np.random.default_rng(ctx.seed)
    y = np.zeros(n, dtype=np.float64)
    for idx in peaks:
        ratio = hz[idx] / f0
        f = ctx.freq * ratio
        if f >= ctx.sr * .47:
            continue
        # Integer loop cycles keep every measured mode continuous at the seam.
        f = round(f * dur) / dur
        amp = spec[idx] / spec[peaks[0]]
        phase = rng.uniform(0, 2 * math.pi)
        y += amp * np.sin(2 * math.pi * f * t + phase)
    fade = int(.10 * ctx.sr)
    y[:fade] *= np.linspace(0, 1, fade, endpoint=False)
    peak = float(np.max(np.abs(y))) or 1.0
    y *= (10**(-23/20)) / peak
    if {kind!r} == "xylo":
        level_db = 20 * math.log10(float(np.sqrt(np.mean(seg * seg))) + 1e-12)
        target_db = float(np.clip(-23 + .42 * (level_db + 30), -36, -17))
        y *= 10 ** ((target_db + 23) / 20)
    return Audio(y.astype(np.float32), ctx.sr)

sound.multisample("attack", ATTACKS,
    process={{"pre_ms": 2, "align_ms": 0, "tune": "source", "ladder": "keep",
             "peak_db": {peak_db!r}, "max_seconds": None, "end_db": -62,
             "fade_ms": 22, "loop": "none", "encoding": "flac24", "mono": True}},
    as_dyn={dynamics!r})
sound.loop(body=True, min_seconds=5.8)
sound.performance(dynamics_source="velocity", velocity_curve=0.9, dyn_crossfade=0,
                  rr_reset_ms=0, humanize={{"cents":0,"ms":0,"db":0}})
sound.defaults(mode="Poli", voices=24, glide=0, master=-3,
    amp_attack={attack}, amp_decay=1, amp_sustain=1, amp_release={release_ms},
    lvl_body=0, lvl_attack=0, lvl_tail=-60, lvl_air=-60,
    osc1_level=-60, osc2_level=-60, sub_level=-60,
    flt_cutoff=20000, flt_reso=0, flt_env=0,
    drive=0, tape_wow=0, tape_flutter=0, tape_sat=0, tape_age=0, tape_mix=0,
    lfo_pitch=0, lfo_amp=0, res_mix=0, echo_mix=0, rev_mix=0, rev_shimmer=0,
    rev_mode="Cappella")
'''
    if kind == "xylo":
        recipe = f'''import json
from pathlib import Path
from libero import Sound
ROOTS = {roots!r}
ROOT = Path(__file__).parent / "samples"
ATTACKS = json.loads((ROOT / "attack_map.json").read_text())
BODY = json.loads((ROOT / "map.json").read_text())["body"]
sound = Sound(title={title!r}, subtitle={subtitle!r},
    tags=["aria", "sampled", "xylophone", "warm", "melody"], roots=ROOTS,
    velocities=[28, 60, 96, 120], sample_rate=48000, takes=1)
sound.articulations([
    {{"id":"soft", "name":"Mazza morbida", "key":None}},
    {{"id":"medium", "name":"Mazza media", "key":None}},
    {{"id":"hard", "name":"Mazza dura", "key":None}},
])
sound.multisample("attack", ATTACKS,
    process={{"pre_ms": 2, "align_ms": 0, "tune": "source", "ladder": "keep",
             "peak_db": {peak_db!r}, "end_db": -62, "fade_ms": 22, "loop": "none",
             "encoding": "flac24", "mono": True}}, as_dyn=True)
sound.multisample("body", BODY,
    process={{"pre_ms": 0, "onset_db": -20, "align_ms": 0, "tune": "source", "ladder": "keep",
             "peak_db": -18, "end_db": -62, "fade_ms": 1, "loop": "source",
             "encoding": "flac24", "mono": True}}, as_dyn=True)
sound.performance(dynamics_source="velocity", velocity_curve=0.9, dyn_crossfade=0,
                  rr_reset_ms=0, humanize={{"cents":0,"ms":0,"db":0}})
sound.defaults(mode="Poli", voices=24, glide=0, master=-3,
    amp_attack={attack}, amp_decay=1, amp_sustain=1, amp_release={release_ms},
    lvl_body=0, lvl_attack=0, lvl_tail=-60, lvl_air=-60,
    osc1_level=-60, osc2_level=-60, sub_level=-60, flt_cutoff=20000, flt_reso=0, flt_env=0,
    drive=0, tape_wow=0, tape_flutter=0, tape_sat=0, tape_age=0, tape_mix=0,
    lfo_pitch=0, lfo_amp=0, res_mix=0, echo_mix=0, rev_mix=0, rev_shimmer=0, rev_mode="Cappella")
'''
    # All three voices use a single source-led BODY zone. Each file contains
    # the original attack, its gradual source-to-modal splice and an explicit
    # sample-accurate periodic loop; there is no detached attack or oscillator bed.
    articulation_block = '''sound.articulations([
    {"id":"soft", "name":"Mazza morbida", "key":None},
    {"id":"medium", "name":"Mazza media", "key":None},
    {"id":"hard", "name":"Mazza dura", "key":None},
])
''' if kind == "xylo" else ""
    recipe = f'''import json
from pathlib import Path
from libero import Sound
ROOTS = {roots!r}
SAMPLES = Path(__file__).parent / "samples"
BODY = json.loads((SAMPLES / "map.json").read_text())["body"]
sound = Sound(title={title!r}, subtitle={subtitle!r},
    tags=["aria", "sampled", "warm", "melody"], roots=ROOTS,
    velocities={[28, 60, 96, 120] if dynamics else [96]!r}, sample_rate=48000, takes=1)
{articulation_block}sound.multisample("body", BODY,
    process={{"pre_ms":0, "align_ms":0, "tune":"source", "ladder":"keep",
             "peak_db":-13, "max_seconds":None, "end_db":-100, "fade_ms":0,
             "loop":"source", "encoding":"flac24", "mono":True}},
    as_dyn={dynamics!r})
sound.performance(dynamics_source="velocity", velocity_curve=0.9, dyn_crossfade=0,
                  rr_reset_ms=0, humanize={{"cents":0,"ms":0,"db":0}})
sound.defaults(mode="Poli", voices=24, glide=0, master={0 if kind == "xylo" else -4},
    amp_attack=0, amp_decay=1, amp_sustain=1, amp_release={release_ms},
    lvl_body=0, lvl_attack=-60, lvl_tail=-60, lvl_air=-60,
    osc1_level=-60, osc2_level=-60, sub_level=-60, flt_cutoff=20000, flt_reso=0, flt_env=0,
    drive=0, tape_wow=0, tape_flutter=0, tape_sat=0, tape_age=0, tape_mix=0,
    lfo_pitch=0, lfo_amp=0, res_mix=0, echo_mix=0, rev_mix=0, rev_shimmer=0, rev_mode="Cappella")
'''
    (dest / "sound.py").write_text(recipe)
    continue_rows = json.loads((dest / "samples" / "infinite-provenance.json").read_text())
    join_overrides = [f"{a.get('source', a.get('file'))}: {int(a['transition_end_seconds'] * 1000)} ms"
                     for a in continue_rows if a.get("transition_end_seconds") != .650]
    override_note = (" Join anticipato per decadimento rapido: " + ", ".join(join_overrides) + ".") if join_overrides else ""
    (dest / "notes.md").write_text(f'''# {title}

{description}

{technique}

## Provenienza e sostegno

Le registrazioni originali complete e gli hash SHA-256 sono in `samples/src/` e `samples/provenance.json`; la continuazione è documentata campione per campione in `samples/infinite-provenance.json`. Il BODY di playback mantiene i primi 180 ms della registrazione, sfuma gradualmente dalla stessa nota originale alla continuazione derivata entro 650 ms, poi ripete un ciclo esplicito dopo un breve assestamento.{override_note} Frequenze, rapporti, fasi e livelli delle componenti spettrali sono misurati sulla registrazione e filtrati con una soglia relativa prudente; non c’è un secondo strato oscillatore con fasi casuali. Il sustain è progettato; lo strumento acustico originale decade naturalmente. Le fonti restano disponibili per verificare il montaggio. Per lo xilofono, la mappa conserva le etichette VCSL e il pitch acustico misurato, un’ottava sopra alcune etichette.

## Prove

Vedi `~/Libero/demo/aria-mechanical/` per frase, accordo, note tenute di 60 secondi e report. Le dinamiche registrate dello xilofono restano pp/ff; le tre mazze sono articolazioni selezionabili e non RR. Le altre fonti hanno un solo livello registrato. I controlli numerici verificano mappa, tuning, loop e picchi; non sostituiscono l’ascolto musicale.
''')


def make_musicbox() -> dict:
    slug = "carillon-particolare"
    dest = BANK / slug
    rows, regions = write_musicbox_source(dest)
    # The recordings are actually F5–G#6 despite lower labels on the source site.
    roots = sorted(set(row["measured_midi"] for row in rows))
    emit_sound(slug, "Carillon particolare", "scatola musicale registrata · denti metallici e coda continua",
        "Cinque note isolate di una scatola musicale reale, incise da Joseph SARDIN con SoundDevices MixPre-3 e microfono Neumann KM184. Le radici misurate coprono F5–G#6: è il registro naturale dello strumento, da suonare lì o trasporre verso il basso se serve una frase più grave. L’attacco e il disegno inarmonico arrivano dai campioni completi; la coda del medesimo materiale sostiene la nota senza trasformarla in un pad generico. Voce asciutta e centrata per temi, doppie e accordi luminosi.",
        roots, musicbox_figure(),
        "Route HYB. Sorgente: cinque note singole CC0, un livello registrato; la continuazione modale è progettata a partire da ogni nota. Amp attack 0, sustain pieno, rilascio 1,1 s; niente oscillatore di supporto, saturazione, wow, chorus o riverbero incorporato. Master ridotto per lasciare margine negli accordi.",
        -16, 0, 1100, .28, False, "musicbox")
    return {"slug": slug, "samples": rows}


def make_xylo() -> dict:
    slug = "xilofono-vivo"
    dest = BANK / slug
    rows, regions = write_xylo_source(dest)
    roots = sorted(set(row["playback_root"] for row in rows))
    emit_sound(slug, "Xilofono vivo", "VCSL · tre articolazioni di mazza e dinamiche registrate",
        "Xilofono VCSL registrato da lontano. Mazza morbida, media e dura sono articolazioni selezionabili, non round robin; ciascuna conserva la propria registrazione single-take alle due dinamiche originali pp e ff. L’attacco legnoso resta in primo piano; la continuazione viene dalle componenti spettrali della stessa registrazione, senza imporre armonici ideali alle barre.",
        roots, xylo_figure(),
        "Route HYB. 48 registrazioni VCSL CC0 (8 radici × 3 mazze × 2 dinamiche) confluiscono ciascuna nel proprio BODY source-led. La coda periodica dura sei secondi sotto C5 e cinque sopra; livelli e rapporti inarmonici delle componenti spettrali vengono conservati, senza creare dinamiche o take artificiali. Le etichette VCSL risultano un’ottava sotto il pitch acustico misurato.",
        -16, 0, 950, .38, True, "xylo")
    return {"slug": slug, "samples": rows}


def make_toy() -> dict:
    slug = "piano-giocattolo"
    dest = BANK / slug
    rows, _ = write_toy_source(dest)
    roots = sorted(set(row["playback_root"] for row in rows))
    emit_sound(slug, "Piano giocattolo", "Schoenhut My First Piano · attacchi reali, risonanza infinita",
        "Un piccolo Schoenhut My First Piano registrato tasto per tasto, con i martelletti e le lamelle metalliche della scatola originale. L’attacco conserva il gesto acustico completo; per le note tenute, una trama di componenti spettrali misurate nella stessa nota prolunga il corpo senza aggiungere un oscillatore generico. Suono asciutto e leggibile per linee melodiche e piccoli accordi.",
        roots, toy_figure(),
        "Route HYB. Registrazioni originali CC BY 4.0 di Tim Kahn (Corsica_S), Sennheiser 8060 e Marantz PMD661 modificato. Sedici note singole mappate, un solo livello registrato; il corpo continuo è ricavato dal loro spettro modale reale. Le radici sono misurate con YIN e controllo locale delle risonanze per evitare errori d’ottava dei parziali del toy piano.",
        -18, 0, 900, .25, False, "toy")
    return {"slug": slug, "samples": rows}


def compile_and_test(item: dict) -> dict:
    slug = item["slug"]
    dest = BANK / slug
    compiled = compile_sound(dest)
    if not compiled.ok:
        raise RuntimeError(f"Compile failed for {slug}: {compiled.text()}")
    lint_result = lint_bundle(dest / "build")
    lint_lines = [line.line() for line in lint_result]
    if slug == "carillon-particolare":
        roots = sorted({r["measured_midi"] for r in item["samples"]})
    elif slug == "piano-giocattolo":
        roots = sorted({r["playback_root"] for r in item["samples"] if r.get("used_in_instrument", True)})
    else:
        roots = sorted({r["playback_root"] for r in item["samples"]})
    target_note = {"carillon-particolare": 84, "piano-giocattolo": 72, "xilofono-vivo": 72}[slug]
    root = min(roots, key=lambda n: abs(n - target_note))
    held = render.preview(slug, f"{root}:0:60:100", tail=2)
    shutil.copy2(held.wav, DEMO / f"{slug}-held-60s.wav")
    seq = [root, min(roots[-1], root + 3), min(roots[-1], root + 7), min(roots[-1], root + 10)]
    phrase_spec = ",".join(f"{n}:{i*.42:.3f}:.62:{v}" for i, (n, v) in enumerate(zip(seq, [42, 68, 104, 118])))
    phrase = render.preview(slug, phrase_spec, tail=2)
    shutil.copy2(phrase.wav, DEMO / f"{slug}-phrase.wav")
    chord_notes = sorted(set([root, min(roots[-1], root + 4), min(roots[-1], root + 7), min(roots[-1], root + 11)]))
    chord_spec = ",".join(f"{n}:0:4:100" for n in chord_notes)
    chord = render.preview(slug, chord_spec, tail=1)
    shutil.copy2(chord.wav, DEMO / f"{slug}-chord.wav")
    hdata = held.audio.to_mono().data
    sr = held.audio.sr
    win = max(1, int(sr))
    rms_windows = [round(float(20 * np.log10(np.sqrt(np.mean(hdata[i:i+win]**2)) + 1e-12)), 2)
                   for i in range(0, len(hdata) - win + 1, win)]
    features = analysis.features(phrase.audio)
    continuation = json.loads((dest / "samples" / "infinite-provenance.json").read_text())
    manifest = json.loads((dest / "build" / "manifest.json").read_text())
    body_zones = [z for z in manifest.get("zones", []) if z.get("layer") == "body"]
    body_loops = [z.get("loop") for z in body_zones]
    item.update({"lint": lint_lines, "phrase": features,
                 "held_peak_dbfs": held.audio.peak_db, "held_seconds": held.audio.duration,
                 "held_note_midi": root, "held_1s_rms_dbfs": rms_windows,
                 "phrase_notes_midi": seq, "phrase_peak_dbfs": phrase.audio.peak_db,
                 "chord_notes_midi": chord_notes, "chord_peak_dbfs": chord.audio.peak_db,
                 "body_zone_count": len(body_zones), "explicit_loop_count": sum(bool(lp) for lp in body_loops),
                 "loop_period_seconds": sorted({round((lp["end"] - lp["start"]) / 48000, 3)
                                                 for lp in body_loops if lp}),
                 "source_component_count_min": min(a["measured_component_count"] for a in continuation),
                 "source_component_count_max": max(a["measured_component_count"] for a in continuation),
                 "transition_end_seconds": sorted({a["transition_end_seconds"] for a in continuation}),
                 "transition_end_overrides": [a.get("source", a.get("file")) for a in continuation
                                              if a["transition_end_seconds"] != .650],
                 "source_loop_seam_worst_db_20ms": max(a["loop_seam_db_20ms"] for a in continuation),
                 "source_detected_onset_max_seconds": max(a.get("detected_onset_seconds", 0) for a in continuation)})
    return item


def main() -> None:
    report = {"generated_utc": datetime.now(timezone.utc).isoformat(), "voices": []}
    for build in (make_musicbox, make_toy, make_xylo):
        item = build()
        if item.get("status") != "already-exists":
            item = compile_and_test(item)
        report["voices"].append(item)
        (DEMO / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        print(item["slug"], json.dumps(item.get("lint", [])), flush=True)
    print(f"Report: {DEMO / 'report.json'}", flush=True)


if __name__ == "__main__":
    main()
