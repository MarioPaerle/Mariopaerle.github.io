"""Install verified Cielo v2 while retaining children bytes and retiring v1 adults."""
from pathlib import Path
import json,shutil,hashlib,datetime
from libero import licenses
from build_cielo_v2 import BASE,STAGE,draw
BANK=Path.home()/'Libero/banks/cielo';BACKUP=Path.home()/'Libero-backups/2026-10-02/cielo-v2-feedback'
def tree_hash(p):return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
def install():
    results=json.loads((BASE/'reports/verification.json').read_text());assert len(results)==7 and all(r['fail']==0 for r in results.values())
    child=BANK/'voci-bianche-sillabe';before=tree_hash(child);assert before==tree_hash(BACKUP/'voci-bianche-sillabe')
    retired=Path.home()/'Libero-backups/2026-10-02/cielo-v2-retired-adults'
    if retired.exists():raise RuntimeError('Refusing overwrite of retired archive')
    retired.mkdir()
    for p in list(BANK.iterdir()):
        if p.is_dir() and (p/'sound.py').exists() and p.name!='voci-bianche-sillabe':shutil.move(str(p),retired/p.name)
    for p in sorted(STAGE.iterdir()):
        if (p/'sound.py').exists():shutil.copytree(p,BANK/p.name)
    assert before==tree_hash(child)
    report=BANK/'_reports';report.mkdir(exist_ok=True)
    for name in ['verification.json','source-validation.json','hold-trajectories.json']:
        old=BANK/name
        if old.exists():shutil.move(str(old),retired/name)
    shutil.copytree(BASE/'reports',report/'v2')
    (report/'child-byte-identical.json').write_text(json.dumps({'identical_to_v1_backup':True,'files':len(before),'hashes':before},indent=2))
    meta=json.loads((BANK/'bank.json').read_text());credits=sum([licenses.read_credits(p) for p in BANK.iterdir() if (p/'sound.py').exists()],[])
    meta.update(version='2.0.0',subtitle='otto identità vocali · campioni reali',description='Coro femminile pieno, due mezzosoprani con belt autentico, bassi e baritoni, voci soffiate, coro misto per sezioni, trillo cantato e una frase originale di dodici sovraincisioni. Ah/Eh/Oh sono articolazioni. Le voci bianche originali restano identiche.',license=licenses.bundle_license(credits)[0],updated=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'))
    (BANK/'bank.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');(BANK/'figure.svg').write_text(draw('volta','Cielo'))
    (BANK/'README.md').write_text('''# Cielo · seconda tavolozza

Otto identità, con vocali dentro gli strumenti e gesti registrati differenti.

- **Donne · Radura**: coro femminile pieno, fino a nove interpreti reali, vocali lunghe e movimento naturale.
- **Donne · Mezzo**: due mezzosoprani, vocali lunghe e belt realmente cantato come articolazione alternativa.
- **Uomini · Pietra**: bassi e baritoni, fondamentali e corpo grave.
- **Uomini · Cenere**: tre baritoni soffiano le vocali; note native brevi per melodie intime.
- **Coro · Volta**: bassi, centro e soprani in ottave realmente registrate, per accordi larghi.
- **Trillo · Rito**: pulsazioni vocali eseguite, per ostinati e risposte.
- **Ellen · Ooh → Aha**: frase armonica originale; una donna, dodici sovraincisioni, effetti della fonte mantenuti. Ogni tasto trasporta l’accordo completo.
- **Voci bianche · sillabe**: il coro di bambini in chiesa resta identico alla versione precedente, rumori e triangolo compresi.

Ah/Eh/Oh indicano le vocali a/e/o delle sorgenti, non una certificazione della pronuncia italiana. Gli strumenti VocalSet sono cori montati da persone registrate separatamente; nessun sintetizzatore si spaccia per coro. Nessun loop, wow/flutter o vibrato inventato. Tutte le durate sono reali: tenendo una nota, il campione termina. Belt e soffi derivano da scale e hanno durate brevi; non vengono presentati come pad infiniti.

VocalSet CC BY 4.0; Ellen e isohoo CC0, da edizioni pubbliche HQ MP3 con tale limite dichiarato. Provenienza e tecniche per ogni componente sono in samples/provenance.json. Gli otto strumenti sono autonomi e compilabili dai campioni installati.

Il confronto tecnico usa la stessa frase, volume abbinato a −23 LUFS massimi e stanza disattivata. Costruzione, bassi/medi, attacchi e movimento sono documentati in _reports/v2. I dati e gli spettrogrammi non certificano gusto o realismo percepito: non posso ascoltare.

Backup completo: ~/Libero-backups/2026-10-02/cielo-v2-feedback. Gli undici adulti precedenti, compresi i due Ah breve, sono ritirati fuori dalla libreria in cielo-v2-retired-adults.
''')
    (BANK/'SOURCE-SEARCH.md').write_text('''# Fonti e licenze

VocalSet originale lossless, https://zenodo.org/records/1442513, CC BY 4.0. Archivio VocalSet11.zip MD5 0c09396242f946e7111ad7d8fc649b81. Julia Wilkins, Prem Seetharaman, Alison Wahl, Bryan Pardo / Northwestern University. Performer e registri seguono il readme originale: 9 donne, 11 uomini. Longtones pp/straight/forte più tecniche effettivamente registrate belt/breathy/trillo e scale slow_piano/slow_forte per colmare registri senza eccessivo trasporto. Ogni intervallo, cantante e trasposizione è attribuito. Non sono campioni di un coro simultaneo.

Ellenmentor: https://freesound.org/people/ellenmentor/sounds/419161/, CC0 1.0 verificata sulla pagina dell’autrice. Una sola donna registra dodici sovraincisioni originali, con effetti. Fonte pubblica HQ MP3 di 8.119 s, non WAV account-gated. Frase armonica Ooh/Aha, non multisample monofonico.

Isohoo: https://freesound.org/people/isohoo/sounds/512975/, CC0: bambini veri in chiesa in Finlandia 2017, Zoom H2, canto finlandese e triangolo. La texture originale rimane identica, inclusi limiti della fonte pubblica MP3 e rumore della ripresa. Non soddisfa la richiesta di un multisample studio pulito di voci bianche.

Fonti scartate: SSO contiene vecchi soundfont/derivazioni K2000 senza provenienza verificabile del coro; FreePats dichiara sintesi ZynAddSubFX; Signature Sounds e Pianobook richiedono email/login; nessun dato personale è stato inviato. CSD è cantato da una donna adulta, non bambini, quindi escluso. Mihai Sorohan ha termini personali non trasferibili ed è stato sostituito dal core VocalSet redistribuibile.
''')
    print('INSTALLED',len([p for p in BANK.iterdir() if (p/'sound.py').exists()]),'child files unchanged',len(before),flush=True)
if __name__=='__main__':install()
