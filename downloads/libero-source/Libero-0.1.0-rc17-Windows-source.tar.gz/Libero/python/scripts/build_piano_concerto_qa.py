"""Render and measure the installed Pianoforte Concerto against Pianoforte.

Run after compiling the new bank sound with python/.venv/bin/python.
Produces native WAV previews, spectrograms, a compact JSON report, and the
measurements section in the sound notes.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import numpy as np
import soundfile as sf

from libero import Audio
from libero import analysis
from libero.lint import lint_bundle


HOME = Path.home() / "Libero"
NEW = HOME / "banks/piano/pianoforte-concerto"
OLD = HOME / "banks/piano/pianoforte"
RENDER = Path.home() / ".local/bin/libero-render"
OUT = HOME / "demo/pianoforte-concerto"

NOTES = [
    (21, 0.00, 1.20, 18),       # quiet A0
    (60, 1.80, 0.70, 32),       # soft middle C
    (60, 3.00, 0.35, 57),       # repeated C4, distinct attacks
    (60, 3.45, 0.35, 64),
    (60, 3.90, 0.35, 73),
    (60, 4.35, 1.40, 88),       # held middle C
    (60, 6.20, 1.00, 126),      # hard middle C
    (108, 7.60, 1.00, 116),     # C8 extreme
    (21, 9.20, 20.50, 116),     # long bass decay
    (48, 22.90, 0.30, 66),
    (55, 23.00, 0.30, 72),
    (60, 23.10, 0.30, 76),
    (64, 23.20, 0.30, 70),      # four-note chord held by CC64
]
EVENTS = ",".join(f"{n}:{t}:{d}:{v}" for n, t, d, v in NOTES)
CC = "23.05:64:127,26.30:64:0"
PARAMS = json.dumps({"master": 0, "lvl_body": 0, "lvl_tail": -4, "amp_attack": 0,
                     "amp_decay": 10000, "amp_sustain": 1, "amp_release": 280,
                     "rev_mix": 0, "res_mix": 0, "echo_mix": 0, "vel_sens": 0.3})


def render(sound: Path, dest: Path) -> Audio:
    subprocess.run([
        str(RENDER), "--sound", str(sound), "--out", str(dest), "--notes", EVENTS,
        "--cc", CC, "--params", PARAMS, "--tail", "3.5",
    ], check=True, timeout=900, capture_output=True, text=True)
    x, sr = sf.read(dest, always_2d=True, dtype="float32")
    return Audio(x, sr)


def summary(audio: Audio) -> dict:
    x = audio.data.astype(np.float64)
    mono = x.mean(axis=1) if x.ndim == 2 else x
    bands = {}
    n = len(mono)
    spectrum = np.abs(np.fft.rfft(mono * np.hanning(n))) ** 2
    freq = np.fft.rfftfreq(n, 1 / audio.sr)
    total = max(float(spectrum.sum()), 1e-30)
    for label, low, high in (("below_200_hz", 0, 200), ("200_to_1000_hz", 200, 1000),
                             ("1_to_5_khz", 1000, 5000), ("above_5_khz", 5000, audio.sr / 2)):
        bands[label] = round(float(spectrum[(freq >= low) & (freq < high)].sum() / total), 4)
    rms_10_20 = mono[int(10 * audio.sr):int(20 * audio.sr)]
    return {
        "duration_s": round(audio.duration, 3),
        "peak_dbfs": round(audio.peak_db, 2),
        "rms_dbfs": round(audio.rms_db, 2),
        "clipped_samples": int(np.sum(np.abs(x) >= 1.0)),
        "t10_20s_rms_dbfs": round(20 * np.log10(np.sqrt(np.mean(rms_10_20 ** 2)) + 1e-20), 2),
        "whole_preview_spectral_energy_share": bands,
    }


def main() -> None:
    if not (NEW / "build/manifest.json").is_file():
        raise FileNotFoundError("Compile pianoforte-concerto before running QA")
    OUT.mkdir(parents=True, exist_ok=True)
    new_audio = render(NEW, OUT / "pianoforte-concerto.wav")
    old_audio = render(OLD, OUT / "pianoforte-8-layer-reference.wav")

    (OUT / "pianoforte-concerto-spectrogram.png").write_bytes(
        analysis.spectrogram(new_audio, fmin=25, fmax=12000,
                             title="Pianoforte Concerto · 16 sampled dynamics"))
    (OUT / "pianoforte-pair-comparison.png").write_bytes(
        analysis.compare(old_audio, new_audio, name_a="Pianoforte · 8 layers",
                         name_b="Pianoforte Concerto · 16 layers", fmin=25, fmax=12000, db_range=90))

    manifest = json.loads((NEW / "build/manifest.json").read_text())
    body_zones = [z for z in manifest["zones"] if z["layer"] == "body"]
    tail_zones = [z for z in manifest["zones"] if z["layer"] == "tail"]
    durations = [sf.info(NEW / "build" / z["file"]).duration for z in body_zones]
    body_seconds = float(sum(durations))
    body_gb = body_seconds * 48000 * 2 * 4 / 1e9
    base_notes = json.loads((NEW / "samples/map.json").read_text())
    lint = lint_bundle(NEW / "build")
    report = {
        "source_zone_counts": {"body": len(base_notes["body"]), "tail": len(base_notes["tail"])},
        "compiled_zone_counts": {"body": len(body_zones), "tail": len(tail_zones)},
        "body_duration_seconds": {"min": round(min(durations), 3), "median": round(float(np.median(durations)), 3),
                                  "max": round(max(durations), 3), "total": round(body_seconds, 3)},
        "decoded_body_memory_48k_stereo_float32": {"decimal_GB": round(body_gb, 3),
                                                    "binary_GiB": round(body_gb / (1024 ** 3 / 1e9), 3)},
        "longest_bass_layers_seconds": {
            str(z["dyn"][1]): round(sf.info(NEW / "build" / z["file"]).duration, 3)
            for z in body_zones if z["root"] == 21
        },
        "native_preview": summary(new_audio),
        "eight_layer_reference_same_events": summary(old_audio),
        "comparison_conditions": "same MIDI event times/velocities, 48 kHz, same amp/master/body/tail/release/velocity settings, dry room/resonator/echo",
        "lint": {"fail": sum(f.level == "FAIL" for f in lint), "warn": sum(f.level == "WARN" for f in lint),
                 "findings": [f.line() for f in lint if f.level in ("FAIL", "WARN")]},
        "perceptual_listening": "not available to this workflow; native render and spectrogram inspected",
        "cc64_preview": "pedal down at 23.05 s, released at 26.30 s after four-note chord note-offs",
    }
    (NEW / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    import_path = NEW / "import-report.json"
    if import_path.exists():
        import_report = json.loads(import_path.read_text())
        capped = import_report.pop("estimated_mb", None)
        if capped is not None:
            import_report["family_default_length_cap_estimate_mb"] = capped
        import_report["body_audio_minutes"] = round(body_seconds / 60, 1)
        import_report["decoded_body_memory_decimal_GB"] = round(body_gb, 3)
        import_report["lint_findings"] = report["lint"]["findings"]
        import_path.write_text(json.dumps(import_report, indent=2) + "\n")
    section = "\n## Compiled measurements and native preview\n\n" + (
        "The compiler output is checked below; the native preview uses quiet, soft, medium and hard strikes, "
        "repeated C4s, A0 and C8 extremes, a 20.5-second A0 hold, and a four-note chord under CC64. The "
        "comparison sends the exact same events through the installed eight-layer Pianoforte. Both renders "
        "are dry, use the same 48 kHz sample rate, amp envelope, master/body/tail levels and velocity sensitivity, "
        "and have room, resonator and echo "
        "set to zero. The longest compiled body layer is A0 at 25.81 s; all 16 A0 velocities last 21.11–25.81 s. "
        "Decoded body data is about 2.5 GB (48 kHz stereo float32, before release tails and engine overhead).\n\n```json\n" +
        json.dumps(report, indent=2) + "\n```\n\n"
        "Lint WARN ladder: D#7 has a measured 10.04 dB rise between its broad source velocity bands 1–26 and 27–34; "
        "both original samples are retained. WARN loudness: the C8 top layer is 3.2 dB below the local keyboard trend "
        "at the source's final key; it remains unflattened.\n"
    )
    notes_path = NEW / "notes.md"
    text = notes_path.read_text()
    text = text.replace(
        "Recreate the installed folder from the already fetched source with `python/.venv/bin/python python/scripts/build_piano_concerto.py` from the Libero repository. The build report and measurements are appended after compilation.",
        "Install into a fresh Libero library with `python/.venv/bin/python python/scripts/build_piano_concerto.py` from the Libero repository; the script refuses to overwrite an existing sketch or installed sound."
    )
    marker = "\n## Compiled measurements and native preview\n"
    if marker in text:
        text = text[:text.index(marker)]
    notes_path.write_text(text.rstrip() + section)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
