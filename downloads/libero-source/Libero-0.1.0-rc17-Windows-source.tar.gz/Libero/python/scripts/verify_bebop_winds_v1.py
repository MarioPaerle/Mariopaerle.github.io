"""Final structural/native hold audit for the nine Bebop wind instruments."""
from pathlib import Path
import json, sys, hashlib
import numpy as np, soundfile as sf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import library, render, lint
HOME=Path.home()/'Libero'; OUT=HOME/'demo/bebop-v1'; PITCH=OUT/'pitch/report.json'
slugs=['bebop-trumpet','bebop-trombone','bebop-french-horn','bebop-tuba','bebop-sax-soprano','bebop-sax-alto','bebop-sax-tenor','bebop-sax-bari','bebop-clarinet-bb']
pitch=json.loads(PITCH.read_text()) if PITCH.exists() else {'voices':[]}
pitch_by={v['slug']:v for v in pitch['voices']}
rows=[]; errors=[]
for slug in slugs:
 folder=HOME/'banks/bebop'/slug;m=json.loads((folder/'build/manifest.json').read_text());zs=m['zones'];aid=m.get('articulations',[{}])[0].get('id') if m.get('articulations') else None
 body=[z for z in zs if z['layer']=='body' and z.get('pitched') and (aid is None or z.get('articulation')==aid)]
 source_fresh=library.source_hash(folder)==m['source_hash']
 findings=lint.lint_bundle(folder/'build');counts={level:sum(f.level==level for f in findings) for level in ('FAIL','WARN','INFO')}
 audit=json.loads((folder/'samples/source-loop-audit.json').read_text())
 main_audit=[x for x in audit if x.get('articulation') in ('sus','vib','buzz',None)]
 unlooped=[x for x in main_audit if not x.get('looped')]
 keys=sorted({k for z in body for k in (z['lo'],z['hi']) if 21<=k<=108})
 k=keys[len(keys)//2]
 dest=OUT/'holds'/f'{slug}-native-hold60.wav';dest.parent.mkdir(parents=True,exist_ok=True)
 render.render(folder,dest,[(k,0.0,60.0,110)],{'rev_mix':0,'lvl_tail':-60,'lvl_air':-60},tail=.1)
 x,sr=sf.read(dest,always_2d=True,dtype='float32');mid=x[10*sr:59*sr]
 rms=float(10*np.log10(np.mean(mid.astype(np.float64)**2)+1e-30));peak=float(20*np.log10(np.max(np.abs(x))+1e-30));clipped=int(np.sum(np.abs(x)>=.9999))
 hold={'key':k,'seconds':len(x)/sr,'rms_10_59_dbfs':rms,'peak_dbfs':peak,'clipped_samples':clipped,'file':str(dest)}
 previews=[]
 arts=m.get('articulations',[])
 for ai,art in enumerate(arts):
  az=[z for z in zs if z['layer']=='body' and z.get('pitched') and z.get('articulation')==art['id']]
  if not az: continue
  if slug=='bebop-tuba' and ai==1: ks=[29,31,41,58,62]
  else:
   lo=min(z['lo'] for z in az);hi=max(z['hi'] for z in az);ks=[min(max(k,lo),hi) for k in (lo,(lo+hi)//2,hi)]
  ev=[(q,0.15*i,0.55,116) for i,q in enumerate(ks)]
  ap=OUT/'articulation-previews'/f'{slug}-{art["id"]}.wav';ap.parent.mkdir(parents=True,exist_ok=True)
  render.render(folder,ap,ev,{'artic':ai,'rev_mix':0,'lvl_tail':-60,'lvl_air':-60},tail=.1)
  ax,asr=sf.read(ap,always_2d=True,dtype='float32'); stats=[]
  for i,q in enumerate(ks):
   a=int((.15*i+.015)*asr);b=min(len(ax),int((.15*i+.20)*asr));seg=ax[a:b].astype(np.float64)
   stats.append({'key':q,'rms_first_200ms_dbfs':float(10*np.log10(np.mean(seg**2)+1e-30)),'peak_dbfs':float(20*np.log10(np.max(np.abs(seg))+1e-30))})
  previews.append({'id':art['id'],'name':art['name'],'index':ai,'keys':stats,'file':str(ap)})
 pv=pitch_by.get(slug,{});record={'slug':slug,'title':m.get('title'),'source_hash_fresh':source_fresh,'compiled_at':m.get('compiled_at'),'zones':len(zs),'body_zones':len(body),'articulations':arts,'articulation_previews':previews,'lint_counts':counts,'pitch_cases':pv.get('cases',0),'max_abs_native_cents':pv.get('max_abs_cents'),'native_pitch_errors':len(next((e.get('failures',[]) for e in pitch.get('errors',[]) if e.get('slug')==slug),[])),'loop_audit':{'main_entries':len(main_audit),'unlooped_main':len(unlooped),'articulation_short_entries':len(audit)-len(main_audit)},'hold60':hold,'limitations':'Native sustain/playback metrics verify continuity, mapping and headroom only; they do not constitute listening approval.'}
 rows.append(record)
 if not source_fresh: errors.append(f'{slug}: source/build mismatch')
 if counts['FAIL']: errors.append(f'{slug}: {counts["FAIL"]} lint failures')
 if unlooped: errors.append(f'{slug}: {len(unlooped)} main sustained source entries not looped')
 if pv and pv.get('max_abs_cents',999)>10: errors.append(f'{slug}: native pitch exceeds 10-cent tolerance')
 if clipped: errors.append(f'{slug}: native 60s hold clipped samples')
 if rms < -60: errors.append(f'{slug}: native hold silent below -60 dBFS')
report={'status':'PASS' if not errors else 'REVIEW','voices':rows,'errors':errors,'scope':'Nine Bebop wind instruments; independent checks of provenance freshness, lint, native pitch, source-loop coverage and one 60-second native sustained note per instrument.','limitations':'This automated evidence does not claim subjective listening approval or certify that the timbre equals a commercial instrument.'}
(OUT/'winds-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':report['status'],'voices':len(rows),'errors':errors,'holds':[{r['slug']:r['hold60']['rms_10_59_dbfs']} for r in rows]},indent=2))
if errors: raise SystemExit(1)
