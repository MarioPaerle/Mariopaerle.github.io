"""Render Cielo figures in Quick Look at native 512 and actual 96px, both themes."""
from pathlib import Path
import subprocess
from PIL import Image,ImageDraw
BANK=Path.home()/'Libero/banks/cielo'
OUT=Path.home()/'Libero/cache/research/cielo/figure-qa'
OUT.mkdir(parents=True,exist_ok=True)
folders=[BANK]+sorted(p for p in BANK.iterdir() if (p/'figure.svg').exists())
svgs=[]
for folder in folders:
    original=(folder/'figure.svg').read_text()
    for theme in ['light','dark']:
        content=original
        if theme=='dark':
            content=content.replace('color="#2a2430"','color="#eee7de"')
            i=content.index('>')+1;content=content[:i]+'<rect width="512" height="512" fill="#17151c"/>'+content[i:]
        for size in [512,96]:
            svg=OUT/f'{folder.name}-{theme}-{size}.svg';svg.write_text(content);svgs.append((svg,size))
for size in [512,96]:
    subprocess.run(['/usr/bin/qlmanage','-t','-s',str(size),'-o',str(OUT)]+[str(p) for p,s in svgs if s==size],check=True,capture_output=True)
for size in [512,96]:
    cols=4;width=cols*(size+20);height=((len(folders)*2+cols-1)//cols)*(size+30);canvas=Image.new('RGB',(width,height),'#eee7de');draw=ImageDraw.Draw(canvas)
    for i,(svg,s) in enumerate((t for t in svgs if t[1]==size)):
        im=Image.open(svg.with_suffix('.svg.png')).convert('RGB');x=(i%cols)*(size+20);y=(i//cols)*(size+30);canvas.paste(im,(x,y+20));draw.text((x,y),svg.stem,fill='black')
    canvas.save(OUT/f'contact-{size}.png')
print(OUT)
