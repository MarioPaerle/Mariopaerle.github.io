"""Six source-distinct Blue keyboards. Never edits bank metadata or other sounds.

Run: python/.venv/bin/python python/scripts/build_blue_keys.py [slug] [--prepare-only|--qa-only]
Source downloads are public; Rhodes samples stay in the private/export-blocked lane.
"""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, math, re, shutil, subprocess
import tarfile, urllib.parse, urllib.request, zipfile
from collections import Counter
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy import signal, ndimage
from libero import Audio, analysis, dsp, library
from libero.compiler import compile_sound
from libero.figure import validate_svg, rasterize
from libero.ingest.sfz import parse_sfz
from libero.lint import lint_bundle, _load
from libero.multisample import true_onset
from libero.audio import LoopPoints

HOME=Path.home(); LIB=HOME/'Libero'; BANK=LIB/'banks/blue'
CACHE=LIB/'cache/sources/blue-keys'; RESEARCH=LIB/'cache/research/blue-keys'; SR=48000
ROSTER={
 'rhodes-stage77':dict(title='Stage 77',subtitle='Rhodes Mark I Stage 73 · Jeff Learman · 1977',kind='ep',source='1977 Rhodes Mark I Stage 73, jRhodes3d mono',author='Jeffrey Learman; SFZ mapping kinwie',url='https://github.com/sfzinstruments/jlearman.jRhodes3d',license='CC BY-NC 4.0 samples; commercial music explicitly permitted',license_class='nc',mechanism='Martelletto contro tine metallica e pickup elettromagnetico; bell e bark realmente registrati.',limit='Sorgente già equalizzata dall’autore (boost acuti, scoop low-mid) e de-noised, non si afferma DI neutra. 16 bit, nessun RR o rilascio separato. Mono autentico; le varianti stereo artificiali/pitch doubling restano fuori dalla palette.'),
 'wurli-ep200':dict(title='Ancia Elettrica',subtitle='Wurlitzer EP200 · Greg Sullivan · 1999',kind='ep',source='Wurlitzer EP200 v1.1',author='Greg Sullivan; SFZ conversion kinwie',url='https://github.com/sfzinstruments/GregSullivan.E-Pianos',license='CC BY 3.0',license_class='by',mechanism='Martelletto contro ancia metallica, diversa dalla tine del Rhodes; quattro dinamiche registrate.',limit='Campionamento non cromatico, radici diverse fra dinamiche; nella parte alta l’autore riusa le dinamiche disponibili. Nessun RR o rilascio isolato offerto.'),
 'pianet-t':dict(title='Pianet T',subtitle='Hohner Pianet T type 2 · Greg Sullivan · 2004',kind='ep',source='Hohner Pianet T type 2 v1.3',author='Greg Sullivan; SFZ conversion kinwie',url='https://github.com/sfzinstruments/GregSullivan.E-Pianos',license='CC BY 3.0',license_class='by',mechanism='La gomma solleva/pizzica la lamella; due dinamiche reali e sedici veri rilasci del tasto.',limit='Due intensità, nessun RR. Sostituisce il Clavinet richiesto come esempio: non è etichettato come D6 e non usa una simulazione di Clavinet.'),
 'organo-blues':dict(title='Ruote Blues',subtitle='Tonewheel · setBfree / FreePats · emulazione dichiarata',kind='organ',source='FreePats setBfree Drawbar, Percussive and Rock Organ Emulations',author='Roberto / FreePats; Strix SoundFont Team',url='https://freepats.zenvoid.org/Organ/electric-organ.html',license='CC0 1.0',license_class='cc0',mechanism='Modello elettronico tonewheel setBfree, tre registrazioni del software: drawbar, percussion e rock; non B3 hardware campionato.',limit='Sorgente SYN registrata dal software, dichiaratamente emulata. Una intensità per registro, nessun RR/release separato. L/R della medesima registrazione sono ricomposti come stereo, non miscelati come take.'),
 'positivo-rinascimento':dict(title='Positivo Rinascimentale',subtitle='VCSL · canne vere · registri 8′, 4′ e pieno',kind='organ',source='VCSL Renaissance Organ',author='Versilian Studios / Sam Gossner',url='https://github.com/sgossner/VCSL',license='CC0 1.0',license_class='cc0',mechanism='Aria contro labbro di canne acustiche; registri 8 piedi, 4 piedi e pieno realmente registrati in stereo nella sala.',limit='Una intensità e un take per registro. Il 4′ suona naturalmente un’ottava sopra l’8′ allo stesso tasto; non si appiattiscono i registri come se fossero errori di intonazione. La sala è già nella sorgente.'),
 'unitra-b11':dict(title='Unitra 83',subtitle='Unitra B11 · organo transistor polacco · 1983',kind='organ',source='Karoryfer Caveman Cosmonaut, Unitra B11',author='Karoryfer Samples / D. Smolken',url='https://shop.karoryfer.com/pages/free-caveman-cosmonaut',license='CC0 1.0 (author current dedication)',license_class='cc0',mechanism='Divisori elettronici dell’organo Unitra B11 registrato; undici combinazioni fisiche di registri, senza preset synth aggiunti.',limit='Una intensità/take. Footages e combinazioni possono dare YIN a ottave diverse: tasti/mappatura originali preservati. Le registrazioni sono brevi: loop naturali misurati di circa 0.7–4 secondi, non una falsa nuova ripresa lunga.'),
}
# Original EP files are peak-normalised by their authors. One fixed gain per
# recorded dynamic restores a rising body ladder without altering note-relative
# levels, attacks, timbre, or mixing recordings. Measured on all source roots.
EP_LAYER_GAIN={
 'rhodes-stage77':[-14.10,-11.37,-9.48,-4.50,0.],
 'wurli-ep200':[-11.84,-6.80,-2.23,0.],
 'pianet-t':[-1.70,0.],
}

def dump(p,obj): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fetch(url,path):
    path=Path(path)
    if path.exists(): return
    path.parent.mkdir(parents=True,exist_ok=True)
    for attempt in range(3):
        try:
            b=urllib.request.urlopen(url,timeout=90).read()
            if b.startswith(b'version https://git-lfs.github.com'):b=urllib.request.urlopen(url.replace('raw.githubusercontent.com','media.githubusercontent.com/media'),timeout=90).read()
            path.write_bytes(b);return
        except Exception:
            if attempt==2: raise

def acquire():
    RESEARCH.mkdir(parents=True,exist_ok=True);CACHE.mkdir(parents=True,exist_ok=True)
    jobs=[]
    for repo,prefixes in [('jlearman.jRhodes3d',['jRhodes3d-mono/']),('GregSullivan.E-Pianos',['Wurlitzer EP200/','Pianet T/'])]:
        tree=RESEARCH/(repo+'-tree.json')
        fetch('https://api.github.com/repos/sfzinstruments/'+repo+'/git/trees/master?recursive=1',tree)
        d=json.loads(tree.read_text())
        for z in d['tree']:
            f=z['path']
            if z['type']=='blob' and (any(f.startswith(p) for p in prefixes) or f in ['LICENSE','README.md']):jobs.append(('https://raw.githubusercontent.com/sfzinstruments/'+repo+'/'+d['sha']+'/'+urllib.parse.quote(f),CACHE/repo/f))
    tree=RESEARCH/'vcsl-tree.json'
    fetch('https://api.github.com/repos/sgossner/VCSL/git/trees/master?recursive=1',tree)
    d=json.loads(tree.read_text())
    for z in d['tree']:
        f=z['path']
        if (f.startswith('Aerophones/Edge-blown Aerophones/Renaissance Organ/') or f in ['LICENSE','README.md']) and z['type']=='blob':jobs.append(('https://raw.githubusercontent.com/sgossner/VCSL/'+d['sha']+'/'+urllib.parse.quote(f),CACHE/'vcsl'/f))
    jobs += [('https://github.com/sfzinstruments/karoryfer.caveman-cosmonaut/releases/download/v1.001/Karoryfer.Caveman_Cosmonaut.v1.001.zip',CACHE/'cosmonaut.zip')]
    for name,version in [('Drawbar','20190712'),('Percussive','20190715'),('Rock','20190715')]:
        f=f'{name}OrganEmulation-SFZ-{version}.tar.xz';jobs.append((f'https://freepats.zenvoid.org/Organ/{name}OrganEmulation/{f}',CACHE/f))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for future in [pool.submit(fetch,*x) for x in jobs]:future.result()
    for p in CACHE.glob('*.tar.xz'):
        target=CACHE/'freepats'/p.name.replace('.tar.xz','')
        if not target.exists():
            with tarfile.open(p) as t:t.extractall(CACHE/'freepats',filter='data')
    if not (CACHE/'cosmonaut/Caveman_Cosmonaut').exists():
        with zipfile.ZipFile(CACHE/'cosmonaut.zip') as z:
            for name in z.namelist():
                out=(CACHE/'cosmonaut'/name).resolve();assert (CACHE/'cosmonaut').resolve() in out.parents
            z.extractall(CACHE/'cosmonaut')
    for key,url in [('karoryfer-license','https://shop.karoryfer.com/pages/free-samples'),('karoryfer-cosmonaut',ROSTER['unitra-b11']['url']),('freepats-organ',ROSTER['organo-blues']['url'])]:fetch(url,RESEARCH/(key+'.html'))
    assert 'CC BY-NC 4.0' in (CACHE/'jlearman.jRhodes3d/LICENSE').read_text()
    assert 'Attribution 3.0' in (CACHE/'GregSullivan.E-Pianos/LICENSE').read_text()
    assert 'all CC0' in (RESEARCH/'karoryfer-license.html').read_text()

def edited_source(path,offset=0):
    a=Audio.load(path,sr=SR);x=a.data.astype(np.float64)
    if x.ndim==1:x=x[:,None]
    if offset:x=x[int(offset*SR/sf.info(path).samplerate):]
    env=np.sqrt(signal.convolve(np.mean(x*x,axis=1),np.ones(48)/48,mode='same'))
    hits=np.flatnonzero(env>max(env.max()*10**(-36/20),1e-6))
    onset=int(hits[0]) if len(hits) else 0;cut=max(0,onset-240)
    x=x[cut:].copy();x-=np.mean(x[-min(len(x),12000):],axis=0)
    return x,dict(original_seconds=a.duration,original_peak_db=a.peak_db,onset_trim_seconds=cut/SR,onset_in_source_seconds=onset/SR,preserved_preroll_seconds=(onset-cut)/SR,source_offset_frames=offset)

def source_tune(x,root,octave=0):
    """Small measured correction around the known physical root, never octave-fold stops."""
    expected=440*2**((root+12*octave-69)/12)
    seg=x[int(.055*SR):int(min(.40,len(x)/SR)*SR)].mean(axis=1)
    f,voiced=dsp.estimate_f0(seg,SR,fmin=max(20,expected/1.09),fmax=min(12000,expected*1.09))
    cents=1200*np.log2(expected/f) if f>0 else 0
    if abs(cents)>80 or voiced<.3:return 0,dict(pitch_method='source root trusted; no confident fine estimate',estimated_hz=f,confidence=voiced)
    return float(cents),dict(pitch_method='local YIN/refined recorded fundamental; no octave correction',estimated_hz=float(f),expected_hz=expected,confidence=voiced,correction_cents=round(float(cents),3))

def modal_continue(x,root,onset=0):
    """One source, measured complex spectrum, absolute phase(t), preserved real attack."""
    begin=onset+.045;end=min(onset+.40,len(x)/SR-.08)
    seg=x[int(begin*SR):int(end*SR)];w=np.hanning(len(seg));nfft=262144
    X=np.fft.rfft(seg*w[:,None],n=nfft,axis=0);power=np.mean(abs(X)**2,axis=1);freq=np.fft.rfftfreq(nfft,1/SR)
    late=x[-min(len(x),int(.50*SR)):];lw=np.hanning(len(late));noise=np.mean(abs(np.fft.rfft(late*lw[:,None],n=nfft,axis=0))**2,axis=1)*(w.sum()/max(lw.sum(),1e-20))**2
    early=x[int((onset+.04)*SR):int((onset+.16)*SR)]
    tonal_tail=np.sqrt(np.mean(late*late))>np.sqrt(np.mean(early*early))*.10
    if tonal_tail:
        # A short EP source can end while its REAL fundamental still rings.
        # Such a tail is not a noise-only recording: remove resolved spectral
        # peaks from the background estimate, rather than excluding the note.
        noise=ndimage.percentile_filter(noise,percentile=20,size=251,mode='nearest')
    ks,_=signal.find_peaks(power,distance=max(1,int(1.5/(SR/nfft))))
    ks=ks[(freq[ks]>25)&(freq[ks]<15000)&(power[ks]>power.max()*10**(-48/10))&(power[ks]>noise[ks]*8)]
    # Every significant component, no arbitrary 36-mode or 900-component cap.
    period=10. if root<60 else 8.;N=round(period*SR);spec=np.zeros((N//2+1,x.shape[1]),complex);components=[]
    for k in ks:
        z=np.log(np.maximum(power[k-1:k+2],1e-30));delta=np.clip(.5*(z[0]-z[2])/(z[0]-2*z[1]+z[2]+1e-30),-.5,.5)
        hz=(k+delta)*SR/nfft;dst=round(hz*period)
        c=(X[k]*(1-abs(delta))+X[k+(1 if delta>=0 else -1)]*abs(delta))*2/w.sum()*np.exp(-2j*np.pi*hz*begin)
        spec[dst]+=N*c/2;components.append([round(float(hz),4),round(dst/period,4),round(float(20*np.log10(np.sqrt(np.mean(abs(c)**2))+1e-20)),2)])
    if len(components)<2:raise RuntimeError(f'Only {len(components)} recorded components for root{root}')
    cycle=np.fft.irfft(spec,n=N,axis=0)
    ef=np.fft.rfftfreq(N,1/SR);energy=np.fft.irfft(np.fft.rfft(np.mean(cycle*cycle,axis=1))*np.exp(-2*np.pi**2*.12**2*ef**2),n=N)
    target=np.sqrt(np.mean(x[int((onset+.04)*SR):int((onset+.16)*SR)]**2))*10**(-1.5/20)
    cycle*=np.clip(target/np.sqrt(np.maximum(energy,1e-20)),.15,6)[:,None]
    cycle*=target/max(np.sqrt(np.mean(cycle*cycle)),1e-20)
    hold=int((onset+.220)*SR)
    join=min(int((onset+(.60 if root<60 else .40))*SR),len(x)-int(.010*SR))
    if join<=hold:raise RuntimeError(f'Recording root{root} too short to preserve220ms attack and splice')
    start=join+int(.40*SR);total=start+N;y=cycle[np.arange(total)%N].copy();y[:hold]=x[:hold]
    u=np.linspace(0,1,join-hold);u=u*u*(3-2*u);y[hold:join]=x[hold:join]*(1-u[:,None])+y[hold:join]*u[:,None]
    b=int((onset+.26)*SR);e=min(int((onset+.36)*SR),len(x));ref=x[b:e];cc=cycle[np.arange(b,e)%N]
    corr=float(np.sum(ref*cc)/max(np.sqrt(np.sum(ref*ref)*np.sum(cc*cc)),1e-20))
    w20=960;seam=float(10*np.log10((np.sum((y[start-w20:start]-y[total-w20:total])**2)+1e-30)/(np.sum(y[start-w20:start]**2)+np.sum(y[total-w20:total]**2)+1e-30)))
    return y,dict(start=start,end=total),dict(method='source complex spectral continuation; same absolute timeline',component_count=len(components),components=components,analysis_seconds=[begin,end],raw_attack_seconds=.220,transition_end_seconds=(join/SR-onset),period_seconds=period,loop_seam_db=seam,phase_correlation_260_360ms=corr,continuation_rms_db=float(20*np.log10(target+1e-20)),target_source_window_seconds=[.04,.16],target_gain_db=-1.5,tonal_tail_not_noise_floor=bool(tonal_tail))

def stereo_loop(x,region,minlen):
    """Search the sum of channel errors; a mono sum can hide opposite L/R seams."""
    lo=int(region[0]*SR);hi=int(min(region[1]*SR,len(x)-1));w=1200
    ref=x[:,int(np.argmax(np.mean(x*x,axis=0)))];zc=np.flatnonzero((ref[:-1]<0)&(ref[1:]>=0))+1
    zc=zc[(zc>=lo)&(zc<=hi)];ends=zc[zc>hi-int(.35*(hi-lo))]
    if len(ends)>32:ends=ends[np.linspace(0,len(ends)-1,32).astype(int)]
    c2=np.r_[0,np.cumsum(np.sum(x*x,axis=1))];best=[]
    for e in ends:
        upto=e-int(minlen*SR);cand=zc[zc<=upto]
        if len(cand)==0:continue
        target=x[e-w:e];et=np.sum(target*target);j=cand-lo;corr=np.zeros(upto-lo+1)
        for ch in range(x.shape[1]):corr+=signal.fftconvolve(x[lo-w:upto,ch],target[::-1,ch],mode='valid')
        es=c2[cand]-c2[cand-w];err=(es+et-2*corr[j])/np.maximum(es+et,1e-20);db=10*np.log10(np.maximum(err,1e-15))
        for k in np.argsort(db)[:4]:best.append((float(db[k]),int(e-cand[k]),int(cand[k]),int(e)))
    if not best:return None
    best.sort();near=[b for b in best if b[0]<best[0][0]+1.0];err,length,s,e=max(near,key=lambda b:b[1])
    return LoopPoints(s,e,min(2880,s,length//5),err)

def natural_loop(x,root):
    """Loop the actual performed sustain, keeping its attack and a separate real release."""
    m=x.mean(axis=1);size=480;blocks=x[:len(x)//size*size].reshape(-1,size,x.shape[1]);rms=np.sqrt(np.mean(blocks*blocks,axis=(1,2)));times=(np.arange(len(rms))+.5)*.01
    peak=rms.max();plateau=(times>.18)&(times<min(1.,len(x)/SR*.5));level=np.median(rms[plateau]) if np.any(plateau) else peak
    tail_search=np.flatnonzero((times>max(.6,len(x)/SR*.4))&(rms<level*10**(-8/20)))
    release=float(times[tail_search[0]]) if len(tail_search) else len(x)/SR-.06
    hi=min(release-.05,len(x)/SR-.08);lo=.25;minlen=min(2.,max(.55,(hi-lo)*.7))
    a=Audio(x.astype(np.float32),SR)
    lp=stereo_loop(x,(lo,hi),minlen) if x.shape[1]>1 else a.loop_points(minlen,region=(lo,hi),window=.025,max_crossfade=.06)
    if lp is None:
        # Some electronic samples are barely a second: lower only the loop length,
        # never silently leave a finite body in an instrument promised to hold.
        lp=stereo_loop(x,(.15,max(.65,hi)),.35) if x.shape[1]>1 else a.loop_points(.35,region=(.15,max(.65,hi)),window=.020,max_crossfade=.06)
    if lp is None:raise RuntimeError(f'No source sustain loop root{root}, length{len(x)/SR:.2f}s release{release:.2f}s')
    s,e=lp.start,lp.end;w=min(960,s,(e-s)//6);pre=x[s-w:s];post=x[e-w:e]
    corr=float(np.sum(pre*post)/max(np.sqrt(np.sum(pre*pre)*np.sum(post*post)),1e-20))
    y=x[:e].copy()
    # At most60ms of a well-matched same recording; last20ms are identical.
    xf=min(2880,s,(e-s)//5);u=np.linspace(0,1,xf-w);u=u*u*(3-2*u)
    y[e-xf:e-w]=y[e-xf:e-w]*(1-u[:,None])+x[s-xf:s-w]*u[:,None]
    y[e-w:e]=x[s-w:s]
    rel=x[max(0,int((release-.035)*SR)):].copy()
    return y,dict(start=s,end=e),dict(method='actual recorded sustain loop; short source-matched splice',period_seconds=(e-s)/SR,loop_seam_db_20ms=-120.,raw_loop_correlation=corr,raw_loop_error_db=lp.error_db,splice_ms=xf/SR*1000,physical_release_seconds=release),rel

def save_audio(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);sf.write(p,x[:,0] if x.shape[1]==1 else x,SR,subtype='PCM_24')
def link_raw(dest,path):
    out=dest/'samples/originals'/Path(path).name;out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists() and sha(out)!=sha(path):out=out.with_name(Path(path).parent.name+'-'+out.name)
    if not out.exists():out.symlink_to(Path(path).resolve())
    return str(out.relative_to(dest/'samples'))

def repack_cell_pitch(dest,row,cell_root,source_root):
    """Bake SFZ's actual nearest-source pitch into a shared compiler key cell.

    tune_cents is a FINE adjustment (±100), not an unbounded transposition.
    Kaiser resampling is equivalent to the author's nearest-root playback; it
    preserves the source recording and calibrated gain, with no time stretch.
    """
    delta=cell_root-source_root
    r=row.copy();r.update(root=cell_root)
    if delta:
        source=dest/'samples'/row['file'];out=dest/'samples/bodies/cells'/f'{source.stem}-cell{cell_root:03d}.flac'
        x=Audio.load(source,sr=SR).data
        if x.ndim==1:x=x[:,None]
        ratio=2**(-delta/12);y=dsp.resample_ratio(x,ratio)
        lp=row['loop'];start=round(lp['start']*ratio);end=round(lp['end']*ratio)
        y=y[:end].copy();w=min(960,start,(end-start)//6);xf=min(2880,start,(end-start)//5)
        pre=y[start-w:start];post=y[end-w:end]
        corr=float(np.sum(pre*post)/max(np.sqrt(np.sum(pre*pre)*np.sum(post*post)),1e-20))
        u=np.linspace(0,1,xf-w);u=u*u*(3-2*u)
        y[end-xf:end-w]=y[end-xf:end-w]*(1-u[:,None])+y[start-xf:start-w]*u[:,None]
        y[end-w:end]=pre
        save_audio(out,y);r.update(file=str(out.relative_to(dest/'samples')),loop=dict(start=start,end=end))
        dump(dest/'samples/cell-proofs'/f'{source.stem}-cell{cell_root:03d}.json',dict(source_derived_file=str(source),source_derived_sha256=sha(source),baked_file=str(out.relative_to(dest/'samples')),baked_sha256=sha(out),source_root=source_root,cell_root=cell_root,semitones=delta,method='bandlimited Kaiser nearest-root varispeed, no stretch; original source/attack and gain preserved',duration_ratio=ratio,old_loop=lp,new_loop=r['loop'],raw_loop_correlation=corr,seam_repair_ms=xf/SR*1000,residual_fine_cents=row['tune_cents'],calibrated_gain_db=row['gain_db']))
    return r

def prepare_ep(slug,dest):
    if slug=='rhodes-stage77':p=CACHE/'jlearman.jRhodes3d/jRhodes3d-mono/_jRhodes3d-mono-no-xfade-flac.sfz'
    else:
        name='Wurlitzer EP200' if slug=='wurli-ep200' else 'Pianet T';p=CACHE/'GregSullivan.E-Pianos'/name/(name+'.sfz')
    parsed=parse_sfz(p);sources={};body=[];tail=[]
    for r in parsed.regions:
        key=(str(r.sample),r.offset,r.trigger)
        if key not in sources:
            raw=link_raw(dest,r.sample);x,audit=edited_source(r.sample,r.offset)
            out=dest/'samples'/('tails' if r.trigger=='release' else 'bodies')/(r.sample.stem+'.flac')
            if r.trigger=='release':
                tune=0;lp=None;more={};x=x[:min(len(x),int(1.5*SR))]
            else:
                tune,more=source_tune(x,r.root);x,lp,mod=modal_continue(x,r.root,audit['preserved_preroll_seconds']);more.update(mod)
            save_audio(out,x);sources[key]=dict(file=str(out.relative_to(dest/'samples')),loop=lp,tune=tune)
            audit.update(source=str(r.sample),sha256=sha(r.sample),original=raw,root=r.root,trigger=r.trigger,source_sfz=str(p),source_sfz_gain_db=r.gain_db,**more);dump(dest/'samples/proofs'/(r.sample.stem+'.json'),audit)
        d=sources[key];row=dict(file=d['file'],root=r.root,lo=r.lokey,hi=r.hikey,vel=[r.lovel,r.hivel],take=0,gain_db=r.gain_db,tune_cents=d['tune'],pitched=r.trigger!='release',articulation='original')
        if r.trigger=='release':row.update(rt_decay=r.rt_decay or 6,rt_min_db=-24);tail.append(row)
        else:row['loop']=d['loop'];body.append(row)
    shutil.copy2(p,dest/'samples/source.sfz')
    axes=sorted({tuple(r['vel']) for r in body})
    for row in body:
        row['gain_db']+=EP_LAYER_GAIN[slug][axes.index(tuple(row['vel']))]
    dump(dest/'samples/dynamic-calibration.json',dict(method='fixed gain per real recorded dynamic; note-relative source gains preserved',velocity_ranges=axes,gain_db=EP_LAYER_GAIN[slug],reason='Author peak-normalised source files invert body energy; all-root source and native ladder measured. No per-note normalisation or waveform blend.'))
    if slug in ['wurli-ep200','pianet-t']:
        # The recordings use DIFFERENT pitch grids at different dynamics. The
        # compiler plans one key grid per instrument, so encode the exact SFZ
        # playback in shared cells. This is metadata pitch mapping, not new
        # recordings, fake dynamics, or wave mixing. net pitch remains
        # (played key - original source root) + original fine correction.
        cuts=sorted({v for r in body for v in [r['lo'],r['hi']+1]});shared=[];trace=[]
        for lo,end in zip(cuts,cuts[1:]):
            hi=end-1;root=(lo+hi)//2
            for row in body:
                if row['lo']<=lo and row['hi']>=hi:
                    old=row['root'];r=repack_cell_pitch(dest,row,root,old);r.update(lo=lo,hi=hi);shared.append(r)
                    trace.append(dict(file=r['file'],original_file=row['file'],original_source_root=old,shared_cell_root=root,lo=lo,hi=hi,vel=r['vel'],baked_transposition_semitones=root-old,residual_fine_cents=r['tune_cents']))
        body=shared;dump(dest/'samples/mapping-adapter.json',trace)
    return body,tail,[dict(id='original',name='Registrazione originale',key=12)]

def bounds(rows):
    roots=sorted({r['root'] for r in rows})
    for r in rows:
        i=roots.index(r['root']);r['lo']=r['root'] if i==0 else (roots[i-1]+r['root'])//2+1;r['hi']=r['root'] if i==len(roots)-1 else (roots[i+1]+r['root'])//2
    return rows

def prepare_positive(dest):
    base=CACHE/'vcsl/Aerophones/Edge-blown Aerophones/Renaissance Organ';body=[];tail=[];arts=[]
    for i,(folder,art,label) in enumerate([("8'",'otto','Otto piedi'),("4'",'quattro','Quattro piedi · ottava'),('Full','pieno','Pieno')]):
        arts.append(dict(id=art,name=label,key=12+i));rows=[];rels=[]
        for p in sorted((base/folder).glob('*.wav')):
            raw=link_raw(dest,p);note=re.search(r'_([A-G]#?\d)_rr',p.name).group(1);root=dsp.parse_note(note)+12
            x,audit=edited_source(p);tune,pt=source_tune(x,root,octave=1 if art=='quattro' else 0);y,lp,more,rel=natural_loop(x,root)
            out=dest/'samples/bodies'/(p.stem+'.flac');save_audio(out,y);row=dict(file=str(out.relative_to(dest/'samples')),root=root,dyn=[0,1],take=0,articulation=art,tune_cents=tune,loop=lp);rows.append(row)
            if len(rel)>.05*SR and np.max(abs(rel))>1e-5:
                out=dest/'samples/tails'/(p.stem+'-release.flac');save_audio(out,rel);rels.append(dict(file=str(out.relative_to(dest/'samples')),root=root,dyn=[0,1],take=0,articulation=art,tune_cents=tune,rt_decay=0,rt_min_db=0))
            audit.update(source=str(p),sha256=sha(p),original=raw,root=root,physical_stop=folder,**pt,**more);dump(dest/'samples/proofs'/(p.stem+'.json'),audit)
        body+=bounds(rows);tail+=bounds(rels)
    return body,tail,arts

def prepare_unitra(dest):
    base=CACHE/'cosmonaut/Caveman_Cosmonaut';body=[];tail=[];arts=[]
    families=[('flutes','Flauti'),('trombone','Trombone'),('clarinet','Clarinetto'),('violin','Violini'),('trompette','Tromba'),('all_all_all','Pieno'),('tremolo','Registro tremolo'),('bass_8','Basso otto'),('bass_16_1','Basso sedici I'),('bass_16_2','Basso sedici II'),('bass_all','Basso pieno')]
    for i,(family,label) in enumerate(families):
        art=family;arts.append(dict(id=art,name=label,key=12+i));rows=[];rels=[]
        mapping=base/'Programs/mappings'/('unitra_all.sfz' if family=='all_all_all' else 'unitra_'+family+'.sfz')
        parsed=parse_sfz(mapping);roots={r.sample.name:r.root for r in parsed.regions}
        for p in sorted((base/'Samples').glob(family+'_*.wav')):
            # The author's mappings explicitly encode footing/transposition.
            root=roots.get(p.name)
            if root is None:raise RuntimeError(f'Unmapped actual Unitra recording {p.name}')
            raw=link_raw(dest,p);x,audit=edited_source(p);y,lp,more,rel=natural_loop(x,root)
            out=dest/'samples/bodies'/(p.stem+'.flac');save_audio(out,y);rows.append(dict(file=str(out.relative_to(dest/'samples')),root=root,dyn=[0,1],take=0,articulation=art,tune_cents=0,loop=lp))
            if more['physical_release_seconds']<len(x)/SR-.12 and np.max(abs(rel))>1e-5:
                out=dest/'samples/tails'/(p.stem+'-release.flac');save_audio(out,rel);rels.append(dict(file=str(out.relative_to(dest/'samples')),root=root,dyn=[0,1],take=0,articulation=art,rt_decay=0,rt_min_db=0))
            audit.update(source=str(p),sha256=sha(p),original=raw,root=root,register=family,source_mapping=str(mapping),**more);dump(dest/'samples/proofs'/(p.stem+'.json'),audit)
        body+=bounds(rows);tail+=bounds(rels)
    shutil.copy2(base/'LICENSE',dest/'samples/source-LICENSE.txt')
    shutil.copy2(RESEARCH/'karoryfer-license.html',dest/'samples/author-cc0-dedication.html')
    return body,tail,arts

def prepare_blues(dest):
    body=[];arts=[]
    for i,(family,art,label) in enumerate([('Drawbar','drawbar','Drawbar'),('Percussive','percussivo','Percussione'),('Rock','rock','Pieno rock')]):
        p=next((CACHE/'freepats').glob(family+'*/*.sfz'));parsed=parse_sfz(p);arts.append(dict(id=art,name=label,key=12+i));groups={}
        for r in parsed.regions:groups.setdefault(r.root,[]).append(r)
        for root,regs in sorted(groups.items()):
            paired=sorted(regs,key=lambda r:float(r.opcodes.get('pan',0)));arrays=[];proof=[]
            for r in paired:
                raw=link_raw(dest,r.sample);a=Audio.load(r.sample,sr=SR);x=a.data.astype(np.float64)
                if x.ndim==1:x=x[:,None]
                arrays.append(x);proof.append(dict(file=str(r.sample),sha256=sha(r.sample),original=raw))
            length=min(len(x) for x in arrays);x=np.concatenate([v[:length] for v in arrays],axis=1)
            x-=np.mean(x[-min(len(x),12000):],axis=0);y,lp,more,_=natural_loop(x,root)
            out=dest/'samples/bodies'/f'{art}-{root}.flac';save_audio(out,y);body.append(dict(file=str(out.relative_to(dest/'samples')),root=root,lo=min(r.lokey for r in regs),hi=max(r.hikey for r in regs),dyn=[0,1],take=0,articulation=art,tune_cents=0,loop=lp))
            dump(dest/'samples/proofs'/f'{art}-{root}.json',dict(source_files=proof,source_sfz=str(p),root=root,category='SYN setBfree software recording, not Hammond hardware',**more))
    return body,[],arts

def figure(slug,title,proof):
    """Physical excitation and register geometry, no keyboard icons or wave ornaments."""
    parts=[]
    if slug in ['rhodes-stage77','wurli-ep200','pianet-t']:
        # Cutaway of a single tine/reed and its action, three genuinely different mechanisms.
        parts+=['<path d="M78 330H434L449 358H66Z" fill="#f3eee6" stroke-width="1.3"/>','<path d="M80 334H435M77 350H443" stroke-width=".8"/>']
        parts+=['<path d="'+' '.join(f'M{x} 332l17 24' for x in range(80,434,4))+'" stroke-width=".45"/>']
        if slug=='rhodes-stage77':
            parts+=['<path d="M118 182H169V258H118Z" fill="#f3eee6" stroke-width="1.3"/>','<path d="M169 194H360Q391 197 404 215M169 208H354" stroke-width="1.2"/>','<path d="M162 222H383M162 228H382" stroke-width=".8"/>','<path d="M253 275L281 288L297 253L270 244Z" fill="#f3eee6" stroke="#b8924f" stroke-width="1.3"/>','<path d="M262 258L271 239L279 227" stroke="#b8924f" stroke-width="1.2"/>','<path d="M373 243Q416 250 414 286L387 303L371 286Z" fill="#f3eee6" stroke-width="1.2"/>']
            for k in range(14):parts.append(f'<path d="M{375+k*2} 253q22 13 2 31" stroke-width=".45"/>')
            desc='Sezione di tine, tonebar e pickup del Rhodes Mark I. Il martelletto dorato è l’eccitazione registrata; il piede tratteggiato di22 unità indica i220ms di attacco preservato. Cinque nervature della staffa rappresentano le cinque dinamiche reali; la lunga tonebar porta la tenuta misurata di8–10s.'
        elif slug=='wurli-ep200':
            parts+=['<path d="M108 166H172V273H108Z" fill="#f3eee6" stroke-width="1.3"/>','<path d="M172 192L389 210L399 224L172 208Z" fill="#f3eee6" stroke-width="1.2"/>','<path d="M182 191L181 210M193 192L192 211" stroke-width=".7"/>','<path d="M283 270L315 252L330 268L297 287Z" fill="#f3eee6" stroke="#b8924f" stroke-width="1.3"/>','<path d="M305 250L303 222" stroke="#b8924f" stroke-width="1.2"/>','<path d="M171 223L365 239L382 262M170 229L363 245L378 268" stroke-width=".8"/>']
            for k in range(15):parts.append(f'<path d="M{190+k*12} {202+k*.8:.1f}l8 7" stroke-width=".45"/>')
            desc='Ancia metallica del Wurlitzer EP200 vista in sezione: la lamella rastremata distingue il corpo dalla tine del Rhodes; martelletto dorato per l’attacco reale220ms. Quattro nervature nel morsetto corrispondono alle quattro intensità campionate. La lama lunga codifica il ciclo source-led8–10s, senza noise bed.'
        else:
            parts+=['<path d="M103 209H176V289H103Z" fill="#f3eee6" stroke-width="1.3"/>','<path d="M176 221L393 207L399 218L176 234Z" fill="#f3eee6" stroke-width="1.2"/>','<path d="M275 146V178Q251 180 252 195L266 218H302L315 195Q315 180 290 178V146" fill="#f3eee6" stroke="#b8924f" stroke-width="1.3"/>','<path d="M267 210Q284 202 301 210M267 205Q284 197 301 205" stroke="#b8924f" stroke-width=".6"/>','<path d="M263 149H297M271 138V155M291 138V155" stroke-width=".8"/>']
            for k in range(14):parts.append(f'<path d="M{115+k*4} 217v63" stroke-width=".4"/>')
            desc='Pianet T: un cuscinetto di gomma dorato solleva la lamella invece di colpirla; la sua bocca aperta indica il gesto di rilascio, realmente registrato in16 radici. Due steli portano le due dinamiche. Il piede22unità codifica220ms di attacco raw e la lamella lunga il ciclo8–10s.'
        for k in range(5):parts.append(f'<path d="M{121+k*8} 173V265" stroke-width=".5"/>')
    elif slug=='positivo-rinascimento':
        parts+=['<path d="M109 122Q256 66 403 122V393H109Z" fill="#f3eee6" stroke-width="1.3"/>']
        for i in range(13):
            xx=130+i*19;top=139+abs(i-6)*15;bottom=363
            parts.append(f'<path d="M{xx} {bottom}V{top}q7-8 14 0V{bottom}Z" fill="#f3eee6" stroke-width=".8"/>')
            for k in range(4):parts.append(f'<path d="M{xx+8+k*1.3:.1f} {top+4}V{bottom-4}" stroke-width=".4"/>')
            parts.append(f'<path d="M{xx+2} 306h10v10h-10Z" fill="#f3eee6" stroke="'+('#b8924f' if i==6 else 'currentColor')+'" stroke-width=".8"/>')
        parts+=['<path d="M104 371H408V402H104Z" fill="#f3eee6" stroke-width="1.2"/>']
        for xx in range(111,402,4):parts.append(f'<path d="M{xx} 374l14 24" stroke-width=".45"/>')
        desc='Positivo a canne VCSL: la canna centrale aperta rappresenta il registro8 piedi, la bocca dorata è il labbro eccitato dall’aria. I13 tubi hanno lunghezze crescenti per il registro grave; tre fasce della cassa portano8′,4′ e pieno realmente registrati. La profondità del somiere indica il loop lungo del fiato registrato e i rilasci mantengono la sala.'
    elif slug=='organo-blues':
        parts+=['<path d="M94 362H420V391H94Z" fill="#f3eee6" stroke-width="1.3"/>','<path d="M114 345V165M400 345V165M114 178H400M114 184H400" stroke-width=".9"/>']
        for i in range(9):
            xx=127+i*32;yy=216+(i%3)*39;rr=13+(8-i)*1.3
            parts.append(f'<circle cx="{xx}" cy="{yy}" r="{rr:.1f}" fill="#f3eee6" stroke-width="1.1"/>')
            for j in range(14):
                t=j*2*np.pi/14;parts.append(f'<path d="M{xx+(rr-4)*np.cos(t):.1f} {yy+(rr-4)*np.sin(t):.1f}l{4*np.cos(t):.1f} {4*np.sin(t):.1f}" stroke-width=".45"/>')
            parts.append(f'<path d="M{xx} {yy-rr-5:.1f}V183" stroke="'+('#b8924f' if i==2 else 'currentColor')+'" stroke-width=".7"/>')
        for k in range(25):parts.append(f'<path d="M{100+k*12} 365l12 23" stroke-width=".45"/>')
        desc='Ruote tonewheel in una gabbia meccanica: nove dischi corrispondono ai nove piedi dei drawbar; il terzo pickup dorato indica la percussione selezionabile. Tre livelli dei dischi rappresentano drawbar, percussion e rock del software setBfree, dichiaratamente emulato. Nessuna falsa fotografia di un Hammond hardware campionato; le ruote sono la lettura del modello elettronico.'
    else:
        parts+=['<path d="M98 192L133 162H382L417 192V361L382 389H133L98 361Z" fill="#f3eee6" stroke-width="1.3"/>','<path d="M111 202H404V345H111Z" stroke-width=".8"/>','<path d="M129 363H383M129 369H383" stroke-width=".8"/>']
        for i in range(11):
            xx=136+i*23;yy=235+(i%3)*19;parts.append(f'<path d="M{xx} 295V{yy}h13v60" stroke="'+('#b8924f' if i==0 else 'currentColor')+'" stroke-width="1.1"/>')
            for k in range(3):parts.append(f'<path d="M{xx+2+k*3} {yy+2}V293" stroke-width=".4"/>')
        for k in range(13):parts.append(f'<path d="M{111+k*3} 213V331" stroke-width=".45"/>')
        for k in range(16):parts.append(f'<path d="M{357+k*2.5:.1f} 218v113" stroke-width=".45"/>')
        desc='Cassa e registro dell’Unitra B11 del1983: undici leve codificano le undici combinazioni hardware realmente registrate; solo il primo registro Flauti è dorato perché carica di default. Tre altezze delle leve distinguono footages bassi e superiori, conservati dalla mappatura dell’autore. L’inclinazione corta della cassa ricorda l’attacco elettrico e il suo volume lungo la tenuta di registrazioni loopate, senza delay o wow.'
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>'+title+'</title><desc>'+desc+'</desc>'+''.join(parts)+'</svg>'

def prepare(slug):
    info=ROSTER[slug];dest=BANK/slug
    if dest.exists() and not (dest/'builder-owner.json').exists():
        backup=HOME/'Libero-backups/2026-10-03/blue-keys'/slug
        assert not backup.exists(),f'Backup exists: {backup}'
        backup.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(dest,backup,symlinks=False)
    dest.mkdir(parents=True,exist_ok=True);dump(dest/'builder-owner.json',dict(builder='build_blue_keys.py',source=info['url']))
    if info['kind']=='ep':body,tail,arts=prepare_ep(slug,dest)
    elif slug=='positivo-rinascimento':body,tail,arts=prepare_positive(dest)
    elif slug=='unitra-b11':body,tail,arts=prepare_unitra(dest)
    else:body,tail,arts=prepare_blues(dest)
    dump(dest/'samples/map.json',dict(body=body,tail=tail));dump(dest/'samples/credits.json',[dict(source=info['source'],author=info['author'],license=info['license'],license_class=info['license_class'],url=info['url'],retrieved='2026-10-03',changes='48kHz/DC; true-onset preroll, actual dynamics/articulations/releases; declared source-led modal extension for EP or natural recorded loops for organ; no take/dynamic mixing')])
    # Licences live inside the hash-covered samples directory, so create them
    # before compile. QA never mutates that directory after the final compile.
    if info['kind']=='ep':
        repo='jlearman.jRhodes3d' if slug=='rhodes-stage77' else 'GregSullivan.E-Pianos'
        shutil.copy2(CACHE/repo/'LICENSE',dest/'samples/SOURCE-LICENSE.txt')
    elif slug=='positivo-rinascimento':shutil.copy2(CACHE/'vcsl/LICENSE',dest/'samples/SOURCE-LICENSE.txt')
    elif slug=='organo-blues':shutil.copy2(RESEARCH/'freepats-organ.html',dest/'samples/SOURCE-LICENSE.html')
    (dest/'samples/ATTRIBUTION.md').write_text(f"# {info['title']}\n\n{info['source']} — {info['author']}.\n{info['url']}\nLicense: {info['license']}.\n\nChanges: 48kHz resampling/DC removal; recorded attacks preserved; every actual dynamic and relevant register/release retained. EP endless sustain is a declared complex spectral continuation of the same recording, never fake infinite raw. Organ loops repeat actual source sustain with bounded seam repair. No endorsement.\n\n{info['limit']}\n")
    release=420 if info['kind']=='ep' else (170 if slug!='positivo-rinascimento' else 380)
    room=.035 if info['kind']=='ep' else 0
    vel=.65 if info['kind']=='ep' else .20
    (dest/'sound.py').write_text(f'''"""{info['source']}; truthful source-led infinite key hold."""
from pathlib import Path
import json
from libero import Sound
sound=Sound(title={info['title']!r},subtitle={info['subtitle']!r},tags={['blue','sampled',info['kind']]!r},sample_rate=48000)
sound.articulations({arts!r})
mapping=json.loads((Path(__file__).parent/'samples/map.json').read_text())
sound.multisample('body',mapping['body'],process={{'tune':'source','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':5,'loop':'source','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'}})
if mapping['tail']:
    sound.multisample('tail',mapping['tail'],as_dyn=True,process={{'tune':'source','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':5,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'link_gain':True,'encoding':'flac24'}})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},onset_ms=5,one_shot=False)
sound.defaults(mode='Poli',glide=0,voices=24,artic=0,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release={release},lvl_body=0,lvl_tail=0 if mapping['tail'] else -60,lvl_attack=-60,lvl_air=-60,vel_sens={vel},humanize=0,master=-1,tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix={room},rev_decay=1.15,rev_size=.30,rev_damp=.50)
''')
    svg=figure(slug,info['title'],None);assert not validate_svg(svg);(dest/'figure.svg').write_text(svg)
    for dark in [False,True]:
        themed=svg.replace('color="#2a2430"','color="#e5ddd0"').replace('#f3eee6','#171a22') if dark else svg
        (dest/'figure-light.png').write_bytes(rasterize(themed,512,background='#171a22' if dark else '#f3eee6')) if not dark else (dest/'figure-dark.png').write_bytes(rasterize(themed,512,background='#171a22'))
        (dest/('figure-thumb-dark.png' if dark else 'figure-thumb-light.png')).write_bytes(rasterize(themed,96,background='#171a22' if dark else '#f3eee6'))
    proofs=[json.loads(p.read_text()) for p in (dest/'samples/proofs').glob('*.json')];dump(dest/'samples/source-proof.json',proofs)
    counts=Counter(r['articulation'] for r in body)
    (dest/'notes.md').write_text(f"# {info['title']}\n\nBlue · accordi/tastiera · {'REC' if slug!='organo-blues' else 'SYN registrato / setBfree'} · {info['mechanism']}\n\n{info['source']}, {info['author']}: {info['url']}. {info['license']}.\n\n{len(proofs)} source performances/proofs, {len(body)} body regions and {len(tail)} tail regions. Articulations: {dict(counts)}. All actual dynamics and relevant registrations retained, hard-switched at note-on, no crossfaded dynamics or invented RR. Source originals preserved via cache links; source-proof.json records hashes, original labels and edits. {info['limit']}\n\nEP: actual first220ms preserved, continuation measured from same recording .045–.40s with actual complex phase, indexed at the same absolute time during the splice; all spectral components above−48dB of peak and9dB above late background, no arbitrary mode cap. Frequencies and inharmonicity come from source, never a series invented from MIDI. Target original RMS.04–.16s minus1.5dB, preserving dynamics/body energy; periodic common-channel slow envelope correction prevents excessive breathing without pitch/wow. It is a declared designed endless resonance, not a recording that naturally rings forever. Components may include finite-window spectral structure, not a claim of independent physical modes. Natural recorded decay/releases remain in originals.\n\nOrgans: loops sit before recorded key-off; first gesture and full actual body/room retained. At most60ms boundary repair within the same recording, no long chorus-like crossfade. Actual recorded note-off tails extracted where present; no manufactured damper or hiss layer. Footages/register pitch preserved; no YIN octave-flattening. Source source-matched loops are explicit, never auto5.8 on a six-second note.\n\nDefaults: Poli, glide0, amp_sustain1,24 voices, peak−12dBFS before master−1, zero wow/flutter/chorus/drive/delay. Small room only on DI EP; no additional room on captured organ space. No audible-quality, warmth or premium-parity claim from measurements: I can render/inspect but cannot listen.\n")
    return dest

def qa(slug):
    dest=BANK/slug;b=dest/'build';manifest=json.loads((b/'manifest.json').read_text());findings=lint_bundle(b);counts=Counter(f.level for f in findings);txt='\n'.join(f.line() for f in findings);(dest/'lint.txt').write_text(txt+'\n')
    zones=[z for z in manifest['zones'] if z['layer']=='body'];low=min(z['lo'] for z in zones);high=max(z['hi'] for z in zones);mid=max(low,min(high,60));other=max(low,min(high,72));renderer=str(HOME/'.local/bin/libero-render')
    phrase=f'12:0:.01:100,{mid}:.05:.7:28,{mid}:1:.7:70,{mid}:2:.7:120,{mid}:3:.15:85,{mid}:3.25:.15:85,{mid}:3.5:.15:85,{mid}:3.75:.15:85,{low}:4.2:1.5:100,{high}:6.2:1.5:110,{mid}:8.2:2:110,{min(mid+4,high)}:8.2:2:110,{min(mid+7,high)}:8.2:2:110,{other}:10.8:1.5:100'
    previews=[]
    def render(name,notes,tail=2,params=None):
        p=b/(name+'.wav');cmd=[renderer,'--sound',str(dest),'--out',str(p),'--notes',notes,'--tail',str(tail)]
        if params:cmd+=['--params',json.dumps(params)]
        subprocess.run(cmd,check=True,capture_output=True);x,sr=sf.read(p,always_2d=True);peak=float(abs(x).max());mono=x.mean(axis=1)
        rec=dict(file=str(p),seconds=len(x)/sr,peak_db=20*np.log10(peak+1e-20),clipped_samples=int(np.sum(abs(x)>=1)),mono_energy_loss_db=10*np.log10(np.mean(mono*mono)/(np.mean(x*x)+1e-20)+1e-20))
        if name.startswith('held'):
            t=x[int(8*sr):int(58*sr)];blocks=t[:len(t)//(sr//2)*(sr//2)].reshape(-1,sr//2,x.shape[1]);db=20*np.log10(np.sqrt(np.mean(blocks*blocks,axis=(1,2)))+1e-20);rec.update(held_rms_min_db=float(db.min()),held_rms_span_500ms_db=float(np.ptp(db)))
            assert db.min()>-85,'Held note died or source mapping missing'
        assert peak<1,'native render clips';previews.append(rec)
        if name in ['preview','held-mid']:(b/(name+'.png')).write_bytes(analysis.spectrogram(Audio(x,sr),title=ROSTER[slug]['title']+' · '+name))
    render('preview',phrase)
    for name,key,vel in [('held-low',low,100),('held-mid',mid,100),('held-high',high,110),('held-soft',mid,30)]:render(name,f'12:0:.01:100,{key}:.05:60:{vel}')
    dynamics_audit=None
    if slug in EP_LAYER_GAIN:
        ordered=sorted(zones,key=lambda z:(z['root'],z['dyn'][0]));events=['12:0:.01:100'];rows=[]
        for i,z in enumerate(ordered):
            v=max(1,round(127*np.mean(z['dyn'])));t=.1+i*1.3
            events.append(f'{z["root"]}:{t}:.7:{v}');rows.append(dict(root=z['root'],velocity=v,file=z['file'],time=t))
        render('dynamics-all-roots',','.join(events),tail=1)
        x,sr=sf.read(b/'dynamics-all-roots.wav',always_2d=True)
        for r in rows:
            t=r['time']
            for label,a,e in [('attack_body_rms_db',.04,.16),('held_body_rms_db',.25,.55)]:
                r[label]=float(20*np.log10(np.sqrt(np.mean(x[int((t+a)*sr):int((t+e)*sr)]**2))+1e-20))
        steps=[bb['held_body_rms_db']-aa['held_body_rms_db'] for aa,bb in zip(rows,rows[1:]) if aa['root']==bb['root']]
        dynamics_audit=dict(rows=rows,minimum_native_held_step_db=min(steps),peak_db=previews[-1]['peak_db'],calibration=json.loads((dest/'samples/dynamic-calibration.json').read_text()))
        dump(dest/'native-dynamics.json',dynamics_audit)
        assert min(steps)>0,'Recorded dynamic calibration still drops at an adjacent native layer'
    # Every real registration is exercised once, including release.
    arts=manifest.get('articulations',[])
    if len(arts)>1:
        notes=[]
        for i,art in enumerate(arts):
            artzones=[z for z in zones if z.get('articulation')==art['id']];key=max(min(z['lo'] for z in artzones),min(max(z['hi'] for z in artzones),60));notes.extend([f"{art['key']}:{i*2}:.01:100",f'{key}:{i*2+.05}:1.2:100'])
        render('registers',','.join(notes))
    seams=[_load(b,z,False).loop_seam_db for z in zones];seams=[x for x in seams if x is not None]
    files={z['file'] for z in manifest['zones']};ram=sum(sf.info(b/p).frames*sf.info(b/p).channels*4 for p in files)/2**20
    proofs=json.loads((dest/'samples/source-proof.json').read_text());modal=[p for p in proofs if 'component_count' in p]
    report=dict(slug=slug,title=ROSTER[slug]['title'],source=ROSTER[slug]['source'],source_url=ROSTER[slug]['url'],license=ROSTER[slug]['license'],license_class=ROSTER[slug]['license_class'],body_zones=len(zones),tail_zones=len(manifest['zones'])-len(zones),source_proofs=len(proofs),source_original_files=len(list((dest/'samples/originals').glob('*'))),actual_range=[low,high],actual_articulations=arts,decoded_ram_mib=ram,lint_counts={k:counts[k] for k in ['FAIL','WARN','INFO']},worst_compiled_loop_seam_db=max(seams),every_body_has_loop=all(z.get('loop') for z in zones),native_previews=previews,limitation=ROSTER[slug]['limit'])
    report.update(source_hash=manifest['source_hash'],source_fresh=library.source_hash(dest)==manifest['source_hash'])
    assert report['source_fresh'],'Source metadata changed after final compile'
    if modal:report.update(component_count_range=[min(p['component_count'] for p in modal),max(p['component_count'] for p in modal)],minimum_source_phase_correlation=min(p['phase_correlation_260_360ms'] for p in modal))
    if dynamics_audit:report.update(native_all_root_dynamics=dynamics_audit,dynamic_calibration=dynamics_audit['calibration'])
    dump(dest/'verification.json',report)
    notes=(dest/'notes.md').read_text().split('\n## Verifica tecnica\n')[0];notes+='\n## Verifica tecnica\n\n'+txt+'\n\n'
    for f in findings:
        if f.level=='WARN':notes+=f'- {f.line()}: fonte reale/mappatura esplicita; correlazioni carrier dei take indipendenti non implicano un offset del gesto, nessun blend di dinamiche. Footages intenzionali e radici non cromatiche dichiarati; fonti senza RR/release non vengono inventate. Il dettaglio alto originario resta negli attacchi; possibili limiti nella trasposizione alta.\n'
    notes+='\n'+json.dumps(report,indent=2,ensure_ascii=False)+'\n';(dest/'notes.md').write_text(notes)
    if slug in EP_LAYER_GAIN:
        notes+='\nCalibrazione delle dinamiche normalizzate dall’autore: '+str(EP_LAYER_GAIN[slug])+' dB, un guadagno per dinamica reale condiviso da tutte le note; livelli relativi dei tasti, gesti e file originali preservati. Vedi samples/dynamic-calibration.json e native-dynamics.json per il confronto esteso a tutte le radici.\n'
        (dest/'notes.md').write_text(notes)
    print(slug,json.dumps({k:report[k] for k in ['body_zones','tail_zones','decoded_ram_mib','lint_counts','worst_compiled_loop_seam_db']},ensure_ascii=False),flush=True)
    assert counts['FAIL']==0,txt
    assert report['every_body_has_loop'] and report['worst_compiled_loop_seam_db']<-30,'Source loop requirement not met'
    return report

def main():
    ap=argparse.ArgumentParser();ap.add_argument('slugs',nargs='*');ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--qa-only',action='store_true');args=ap.parse_args();slugs=args.slugs or list(ROSTER)
    if any(s not in ROSTER for s in slugs):ap.error('Unknown Blue keyboard slug')
    if not args.qa_only:acquire()
    for slug in slugs:
        if not args.qa_only:
            dest=prepare(slug)
            if args.prepare_only:continue
            result=compile_sound(dest,jobs=2);print(result.text(),flush=True)
            if not result.ok:raise RuntimeError(result.text())
        qa(slug)

if __name__=='__main__':main()
