"""Read-only native root/cell-boundary mapping for the new pitched Bebop instruments."""
from pathlib import Path
import sys,json,argparse
import numpy as np,soundfile as sf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import render,library
from calibrate_blue_v6_body import estimate
a=argparse.ArgumentParser();a.add_argument('--slugs',nargs='+',required=True);a.add_argument('--tolerance',type=float,default=10);args=a.parse_args()
out=Path.home()/'Libero/demo/bebop-v1/pitch';out.mkdir(parents=True,exist_ok=True)
allrows=[];errors=[]
for slug in args.slugs:
 folder=Path.home()/'Libero/banks/bebop'/slug;m=json.loads((folder/'build/manifest.json').read_text());aid=m['articulations'][0]['id']if m.get('articulations')else None
 zones=[z for z in m['zones']if z['layer']=='body'and(aid is None or z.get('articulation')==aid)and z.get('pitched')]
 keys=sorted({k for z in zones for k in [z['root'],z['lo'],z['hi']]if 21<=k<=108})
 events=[(k,i*2.65,2.5,v)for i,(k,v)in enumerate((k,v)for k in keys for v in [36,80,116])]
 file=out/f'{slug}.wav';render.render(folder,file,events,{'rev_mix':0,'lvl_tail':-60,'lvl_air':-60},tail=.1);x,sr=sf.read(file,always_2d=True);rows=[]
 for key,t,d,vel in events:
  seg=x[round((t+1.2)*sr):round((t+2.3)*sr)];f,c=estimate(seg,sr,440*2**((key-69)/12));rms=float(10*np.log10(np.mean(seg**2)+1e-30));row={'key':key,'velocity':vel,'cents':c,'rms_dbfs':rms};rows.append(row)
 fresh=library.source_hash(folder)==m['source_hash']==json.loads((folder/'build/manifest.json').read_text())['source_hash']
 failures=[r for r in rows if abs(r['cents'])>args.tolerance or r['rms_dbfs']<-60]
 if failures or not fresh:errors.append({'slug':slug,'fresh':fresh,'failures':failures})
 r={'slug':slug,'source_hash':m['source_hash'],'fresh':fresh,'max_abs_cents':max(abs(q['cents'])for q in rows),'cases':len(rows),'notes':rows,'tolerance_cents':args.tolerance}
 (out/f'{slug}.json').write_text(json.dumps(r,indent=2)+'\n');allrows.append(r);print(slug,r['cases'],r['max_abs_cents'],'errors',len(failures),flush=True)
(out/'report.json').write_text(json.dumps({'voices':allrows,'errors':errors,'limitations':'Stable body/native keyboard mapping with strong partial fallback; not an assessment of musical taste or natural attack inflection.'},indent=2)+'\n')
if errors:raise SystemExit(1)
