"""Fetch only selected public-domain Jupiter-4 recordings via verified HTTP byte ranges.

The upstream binary-split ZIP totals several GB. Range reads fetch the central
directory and selected native AIFF members only; an ignored Range is rejected.
"""
import io, json, zipfile, urllib.request, pathlib, re
CACHE=pathlib.Path.home()/'Libero/cache/research/aria-hardware'
CACHE.mkdir(parents=True,exist_ok=True)
class RemoteSplit(io.RawIOBase):
 def __init__(self, urls, lengths): self.urls=urls;self.lengths=lengths;self.total=sum(lengths);self.pos=0;self.cache={}
 def seekable(self): return True
 def readable(self): return True
 def tell(self): return self.pos
 def seek(self,o,w=0): self.pos=o if w==0 else self.pos+o if w==1 else self.total+o;return self.pos
 def read(self,n=-1):
  n=min(n if n>=0 else self.total-self.pos,self.total-self.pos);pieces=[]
  while n>0:
   base=0
   for i,l in enumerate(self.lengths):
    if self.pos<base+l: break
    base+=l
   off=self.pos-base;size=min(n,self.lengths[i]-off);key=(i,off,size)
   if key not in self.cache:
    req=urllib.request.Request(self.urls[i]+'?download=1',headers={'Range':f'bytes={off}-{off+size-1}','User-Agent':'Libero-source-audit'})
    with urllib.request.urlopen(req,timeout=90) as r:
     if r.status!=206: raise RuntimeError(('range ignored',r.status))
     data=r.read()
    if len(data)!=size: raise RuntimeError(('short range',len(data),size))
    self.cache[key]=data
   pieces.append(self.cache[key]);self.pos+=size;n-=size
  return b''.join(pieces)
with urllib.request.urlopen('https://raw.githubusercontent.com/publicsamples/Roland-Jupiter-4/master/LICENSE') as response:
 (CACHE/'LICENSE.txt').write_bytes(response.read())
base='https://github.com/publicsamples/Roland-Jupiter-4/releases/download/1.0/'
for kind,lens,prefix in [('Pads',[1000000000]*3+[385960488],'JP4 - Unison Pad'),('Keys',[1000000000,788988894],'Petals Piano')]:
 z=zipfile.ZipFile(RemoteSplit([base+kind+'.zip.'+str(i+1).zfill(3) for i in range(len(lens))],lens))
 names=z.namelist();(CACHE/(kind+'-index.json')).write_text(json.dumps(names,indent=2))
 sfz=(CACHE/(prefix+'.sfz')).read_text(); files=re.findall(r'sample=(.*)',sfz)
 # exact original every third root, not fake takes/dynamics.
 desired=[]
 for f in files:
  m=re.search(r'-(\d+)-127',f)
  if m and int(m[1])%3==0 and 48<=int(m[1])<=84: desired.append((int(m[1]),f.strip().replace('../Audio/','')))
 print(kind,'members',len(names),'selected',len(desired),flush=True)
 for root,f in desired:
  matches=[name for name in names if name.endswith(f)]
  if len(matches)!=1: print('NO MATCH',f);continue
  out=CACHE/'audio'/kind/pathlib.Path(f).name;out.parent.mkdir(parents=True,exist_ok=True)
  if not out.exists(): out.write_bytes(z.read(matches[0]))
  print(root,out.name,out.stat().st_size,flush=True)
