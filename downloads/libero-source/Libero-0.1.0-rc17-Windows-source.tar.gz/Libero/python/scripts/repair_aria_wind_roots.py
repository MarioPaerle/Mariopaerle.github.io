#!/usr/bin/env python3
"""Correct measured VCSL octave convention without regenerating recordings."""
from pathlib import Path
import json, re, sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'python'))
from libero import Audio, analysis, library, render
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from build_aria_expansion_winds_plucked import SOUNDS, sample_pitch, figure

VERSION = 'vcsl-label-plus-12-v1'
OUT = Path.home()/'Libero/demo/aria-winds-plucked'
OUT.mkdir(parents=True, exist_ok=True)

def repair(spec):
    folder = library.home()/'banks/aria'/spec['slug']
    mapfile = folder/'samples/map.json'
    mapping = json.loads(mapfile.read_text())
    proofpath = folder/'samples/source-proof.json'
    proof = json.loads(proofpath.read_text())
    if mapping.get('pitch_mapping') != VERSION:
        for rows in (mapping['body'], mapping['tail']):
            for row in rows:
                row['root'] += 12
                # Explicit release ranges must follow the corrected roots too.
                if 'lo' in row:
                    row['lo'] = min(127, row['lo']+12) if row['lo'] else 0
                if 'hi' in row:
                    row['hi'] = min(127, row['hi']+12)
        mapping['pitch_mapping'] = VERSION
        mapfile.write_text(json.dumps(mapping, indent=2)+'\n')
        recipe = folder/'sound.py'
        text = recipe.read_text()
        roots = sorted({r['root'] for r in mapping['body']})
        text = re.sub(r'roots=\[[^\]]*\]', 'roots='+repr(roots), text)
        recipe.write_text(text)
    for rows in (mapping['body'], mapping['tail']):
        for row in rows:
            row.pop('source_label_root', None)
    mapfile.write_text(json.dumps(mapping, indent=2)+'\n')
    for row in proof:
        source = folder/'samples/originals'/Path(row['source_path']).name
        audit = sample_pitch(source)
        if row.get('sha256') != audit['sha256']:
            raise RuntimeError('Original source changed: '+str(source))
        row.update(audit)
        row['pitch_mapping'] = VERSION
    proofpath.write_text(json.dumps(proof, indent=2)+'\n')
    (folder/'figure.svg').write_text(figure(spec))
    notes = folder/'notes.md'
    text = notes.read_text().split('\n## Verifica tecnica')[0]
    if '\n## Convenzione delle note' not in text:
        text += '\n## Convenzione delle note\n\nIn queste quattro cartelle VCSL, i nomi originali indicano un’ottava inferiore alla nota suonata: per esempio C3 è registrato a circa 261,6 Hz (C4). Le radici di playback sono corrette di +12 semitoni; il pitch dei WAV originali e delle continuazioni resta intatto. La misura cerca il fondamentale vicino alla famiglia fisica, evitando ripiegamenti delle note acute. `written_midi` nel documento di provenienza conserva l’etichetta originale.\n'
    notes.write_text(text)
    result = compile_sound(folder, jobs=2)
    if not result.ok:
        raise RuntimeError(result.text())
    findings = lint_bundle(folder/'build')
    fails = [f.line() for f in findings if f.level == 'FAIL']
    if fails:
        raise RuntimeError('\n'.join(fails))
    roots = sorted({r['root'] for r in mapping['body']})
    middle = min(roots, key=lambda r:abs(r-72))
    phrase = ','.join(f'{r}:{i*.65}:.48:{[40,75,105,115][i%4]}' for i,r in enumerate(roots[::max(1,len(roots)//7)]))
    native = {}
    for name, sequence in [('phrase',phrase),('held60',f'{middle}:0:60:100'),
                           ('chord',','.join(f'{r}:0:3:100' for r in roots[::max(1,len(roots)//4)][:4]))]:
        output = OUT/(spec['slug']+'-'+name+'.wav')
        render.render(folder, output, sequence, tail=1.5)
        a = Audio.load(output)
        f = analysis.features(a)
        if not np.all(np.isfinite(a.data)) or f['peak_db'] > -.5:
            raise RuntimeError(f'{spec["slug"]}: invalid/headroom: {f}')
        if name=='held60':
            late = a.data[int(50*a.sr):int(59*a.sr)]
            f['late_rms_dbfs'] = float(20*np.log10(np.sqrt(np.mean(late**2))+1e-15))
            if f['late_rms_dbfs'] < -60:
                raise RuntimeError('Sustain stopped: '+spec['slug'])
        if name=='phrase':
            (OUT/(spec['slug']+'-phrase.png')).write_bytes(analysis.spectrogram(a,title=spec['title']))
        native[name] = f
    manifest = json.loads((folder/'build/manifest.json').read_text())
    report = {'slug':spec['slug'],'pitch_mapping':VERSION,
              'source':{'provider':'VCSL','body_zones':len(mapping['body']),
                        'release_zones':len(mapping['tail']), 'roots':roots},
              'lint':{'FAIL':0,'WARN':sum(f.level=='WARN' for f in findings),
                      'findings':[f.line() for f in findings]},
              'native_previews':native, 'source_hash':manifest['source_hash'],
              'source_fresh':manifest['source_hash']==library.source_hash(folder),
              'original_sources_preserved':True}
    (folder/'verification.json').write_text(json.dumps(report, indent=2)+'\n')
    (folder/'lint.txt').write_text('\n'.join(f.line() for f in findings)+'\n')
    print(spec['slug'],len(mapping['body']),roots[0],roots[-1],report['lint']['WARN'],flush=True)
    return report

if __name__=='__main__':
    reports = [repair(s) for s in SOUNDS]
    (OUT/'report.json').write_text(json.dumps(reports,indent=2)+'\n')
