#!/usr/bin/env python3
"""Native long-hold/pitch verification for the repaired steel fingerstyle cells."""
import json,math,sys,datetime,collections
from pathlib import Path
import numpy as np
sys.path.insert(0,'/Users/mario/Documents/Libero/python')
from libero.render import render
from libero.audio import Audio
from libero.library import source_hash
from libero.lint import lint_bundle
FOLDER=Path.home()/'Libero/sketches/chitarra-acustica-libero'; OUT=Path.home()/'Libero/demo/release-replacements-v1/rhythm/chitarra-acustica-libero';OUT.mkdir(parents=True,exist_ok=True)
SR=48000; TARGETS=[72,75,78,79,80,81,82,83,84]
def db(x):return 20*math.log10(max(float(x),1e-15))
def window_rms(x,a,b):
 y=x[int(a*SR):int(b*SR)]
 return float(np.sqrt(np.mean(np.asarray(y,dtype=np.float64)**2))) if len(y) else 0.
def hz(note):return 440*2**((note-69)/12)
def measure_peak(x,target):
 x=np.asarray(x,dtype=np.float64);x=x-np.mean(x);x=x*np.hanning(len(x));n=1
 while n<len(x):n*=2
 n*=8;mag=np.abs(np.fft.rfft(x,n=n));freq=np.fft.rfftfreq(n,1/SR);ix=np.flatnonzero((freq>target*.985)&(freq<target*1.015))
 if not len(ix) or np.max(mag[ix])<1e-9:return None
 k=int(ix[np.argmax(mag[ix])]);
 if 0<k<len(mag)-1:
  a,b,c=np.log(np.maximum(mag[k-1:k+2],1e-30));d=a-2*b+c;off=.5*(a-c)/d if abs(d)>1e-15 else 0
 else:off=0
 return float((k+off)*SR/n)
manifest=json.loads((FOLDER/'build/manifest.json').read_text());rows=[]
for note in TARGETS:
 z=next(z for z in manifest['zones'] if z.get('articulation')=='fingerstyle' and z['root']==note)
 if not z.get('loop'):raise RuntimeError(f'no compiled loop for {note}')
 dest=OUT/f'fingerstyle-{note}-hold-60s.wav';info=render(FOLDER/'build',dest,f'{note}:0:60:100',params={'mode':'Poli','voices':1,'lfo_pitch':0},tail=.5)
 a=Audio.load(dest);x=np.asarray(a.data,dtype=np.float64)
 if x.ndim>1:x=x.mean(axis=1)
 early=window_rms(x,1,2);mid=window_rms(x,10,20);late=window_rms(x,50,59)
 # A 4s mid/late spectrum center tests the looped root at the written key.
 seg=x[int(20*SR):int(24*SR)];meas=measure_peak(seg,hz(note));cent=1200*math.log2(meas/hz(note)) if meas and math.isfinite(meas) else None
 lp=z['loop'];source_loop_s=(lp['end']-lp['start'])/SR; seam_times=[]
 for i in range(1,6):
  t=lp['start']/SR+i*source_loop_s
  if t<10:seam_times.append({'time_s':round(t,5),'pre_10ms_rms_db':round(db(window_rms(x,t-.015,t-.005)),2),'post_10ms_rms_db':round(db(window_rms(x,t+.005,t+.015)),2)})
 rows.append({'note':note,'zone_file':z['file'],'zone_loop':lp,'source_loop_s':round(source_loop_s,5),'native_pitch_hz':round(meas,5) if meas else None,'native_pitch_error_cents':round(cent,3) if cent is not None else None,'rms_1_2s_dbfs':round(db(early),2),'rms_10_20s_dbfs':round(db(mid),2),'rms_50_59s_dbfs':round(db(late),2),'late_above_minus50dBFS':bool(late>10**(-50/20)),'mid_to_late_delta_db':round(db(late)-db(mid),2),'engine':info,'seam_adjacent_windows':seam_times,'render':str(dest)})
 print(note,'late',rows[-1]['rms_50_59s_dbfs'],'pitch cents',rows[-1]['native_pitch_error_cents'],flush=True)
report={'slug':'chitarra-acustica-libero','title':manifest['title'],'source_hash':manifest['source_hash'],'source_hash_fresh':manifest['source_hash']==source_hash(FOLDER),'method':'Native Libero engine, default fingerstyle articulation, 60-second notes at velocity 100; measure late RMS and pitch on the sustained body; loop joins also inspected with adjacent-window RMS. Only the nine previously finite fingerstyle main zones are replaced by same-take overlap loops.','thresholds':{'late_hold_floor_dbfs':-50,'pitch_tolerance_cents':5},'all_pass':all(r['late_above_minus50dBFS'] and r['native_pitch_error_cents'] is not None and abs(r['native_pitch_error_cents'])<=5 for r in rows),'lint_failures':[f.line() for f in lint_bundle(FOLDER/'build') if f.level=='FAIL'],'zones':rows}
(OUT/'native-hold-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
stamp=datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
findings=lint_bundle(FOLDER/'build');counts=collections.Counter(f.level for f in findings)
lint={'FAIL':counts.get('FAIL',0),'WARN':counts.get('WARN',0),'INFO':counts.get('INFO',0),'warnings':[f.line() for f in findings if f.level=='WARN']}
local=OUT/'report.json'
if local.exists():
 d=json.loads(local.read_text());d.update({'source_hash':manifest['source_hash'],'source_hash_fresh':report['source_hash_fresh'],'zones':len(manifest['zones']),'lint':lint,'hold_repair':report,'updated_utc':stamp});local.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
aggregate=OUT.parent/'report.json'
if aggregate.exists():
 d=json.loads(aggregate.read_text());matches=[x for x in d.get('presets',[]) if x.get('slug')=='chitarra-acustica-libero']
 if len(matches)!=1:raise RuntimeError(f'aggregate must contain exactly one guitar entry, found {len(matches)}')
 matches[0].update({'source_hash':manifest['source_hash'],'source_hash_fresh':report['source_hash_fresh'],'zones':len(manifest['zones']),'lint':lint,'hold_repair':report,'updated_utc':stamp})
 d['updated_utc']=stamp;aggregate.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
print('native long hold:',report['all_pass'],'fresh:',report['source_hash_fresh'],'updated local + aggregate guitar report at',stamp)
