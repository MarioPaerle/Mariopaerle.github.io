"""Compile, measure, conservatively calibrate and render installed sampled basses."""
from pathlib import Path
from collections import defaultdict,Counter
import json,subprocess,argparse,math
import numpy as np,soundfile as sf
from libero import Audio,analysis,dsp
from libero.compiler import compile_sound
from libero.lint import _load,lint_bundle,lint_text
from build_bassi_acoustic import BANK,SLUGS,retire_old
RENDER=Path.home()/'.local/bin/libero-render'
def key(r):return (r.get('articulation'),r['root'],tuple(r.get('dyn',[0,1])),r.get('take',0))
def compile(folder):
 print('Compile',folder.name,flush=True);res=compile_sound(folder,jobs=6)
 print(res.text(),flush=True)
 if not res.ok:raise RuntimeError(res.text())
def calibrate(folder):
 b=folder/'build';m=json.loads((b/'manifest.json').read_text());mp=json.loads((folder/'samples/map-bassi.json').read_text());by={key(r):r for r in mp['body']}
 records=[]
 for z in m['zones']:
  if z['layer']!='body' or not z['pitched']:continue
  d=_load(b,z,True);r=by[key(z)];correction=z.get('tune_cents',0)-(d.f0_cents or 0)
  # Static fine correction only. No pitch-envelope flattening and no octave changes.
  if abs(correction)<=60:r['tune_cents']=round(correction,2)
  else:r['tune_cents']=0
  records.append(dict(file=r['file'],root=r['root'],residual_before=d.f0_cents,absolute_correction=r['tune_cents'],flag_large=abs(correction)>60))
 (folder/'samples/map-bassi.json').write_text(json.dumps(mp,indent=2)+'\n')
 p=folder/'sound.py';p.write_text(p.read_text().replace("'tune': 'detect'","'tune': 'source'"))
 (folder/'samples/tuning-calibration.json').write_text(json.dumps(records,indent=2)+'\n')
 compile(folder)
def preview(folder,m):
 # Musical walking/groove phrase, soft/mid/hard, four repeats, overlapping fifth,
 # extremes, six-second held natural pluck, then each actual articulation.
 arts=m['articulations'];body=[z for z in m['zones'] if z['layer']=='body'];main=[z for z in body if z.get('articulation')==arts[0]['id']]
 low=min(z['root'] for z in main);high=max(z['root'] for z in main);root=min(max(36,low),high)
 up=lambda semitones:min(root+semitones,high)
 p=[(12,0,.01,100),(low,.04,.75,30),(root,1,.75,72),(up(3),2,.75,115),(up(5),3,.75,80),(up(7),4,.75,110)]
 p += [(root,5+.45*i,.25,v) for i,v in enumerate([35,75,115,100])]
 p += [(root,7,1.4,95),(up(7),7.3,1,95),(high,8.8,1,115),(root,10,6,110)]
 t=17
 for art in arts[1:]:
  zones=[z for z in body if z.get('articulation')==art['id']];rr=sorted({z['root'] for z in zones});r=min(rr,key=lambda n:abs(n-root));p += [(art['key'],t,.01,100),(r,t+.05,.45,45),(r,t+.65,.45,115),(r,t+1.25,.3,90)];t+=2
 stats={};events=','.join(f'{n}:{s}:{d}:{v}' for n,s,d,v in p)
 (folder/'build/preview-events.json').write_text(json.dumps(p,indent=2)+'\n')
 for name,params in [('preview',{}),('preview-dry',{'rev_mix':0})]:
  out=folder/'build'/f'{name}.wav';subprocess.run([str(RENDER),'--sound',str(folder),'--out',str(out),'--notes',events,'--params',json.dumps(params),'--tail','6'],check=True,capture_output=True)
  x,sr=sf.read(out,always_2d=True);peak=float(np.max(np.abs(x)));rms=np.sqrt(np.mean(x*x));dc=float(np.max(np.abs(x.mean(axis=0))))
  mono=x.mean(axis=1);seg=mono[int(1*sr):int(1.6*sr)];S=np.abs(np.fft.rfft(seg*np.hanning(len(seg))))**2;fr=np.fft.rfftfreq(len(seg),1/sr)
  bands={label:float(100*S[(fr>=a)&(fr<c)].sum()/max(S.sum(),1e-20)) for label,a,c in [('25-120Hz',25,120),('120-500Hz',120,500),('500-4000Hz',500,4000),('4-18kHz',4000,18000)]}
  stats[name]=dict(duration_s=len(x)/sr,peak_db=20*np.log10(peak+1e-20),rms_db=20*np.log10(rms+1e-20),dc_db=20*np.log10(dc+1e-20),clipped_samples=int(np.sum(np.abs(x)>=1)),crest_db=20*np.log10((peak+1e-20)/(rms+1e-20)),bands_percent=bands,held_note_rms_by_second=[float(20*np.log10(np.sqrt(np.mean(x[int((10+i)*sr):int((11+i)*sr)]**2))+1e-20)) for i in range(6)])
  (folder/'build'/f'{name}.png').write_bytes(analysis.spectrogram(Audio(x,sr),title=f'{folder.name} · real recordings · {name}'))
 return stats
def validate(folder):
 b=folder/'build';m=json.loads((b/'manifest.json').read_text());findings=lint_bundle(b);txt='\n'.join(f.line() for f in findings);(folder/'lint.txt').write_text(txt+'\n');print(folder.name,txt,flush=True)
 ds=[_load(b,z,True) for z in m['zones']];groups=defaultdict(list);lengths=defaultdict(list)
 for d in ds:
  if d.f0_cents is not None:groups[d.z.get('articulation')].append(d.f0_cents)
  lengths[d.z.get('articulation') or d.z['layer']].append(d.frames/d.sr)
 # Bundle.cpp retains one channel for mono sources; never report forced stereo RAM.
 ram=sum(sf.info(str(b/z['file'])).frames*sf.info(str(b/z['file'])).channels*4 for z in m['zones'])
 stats=dict(slug=folder.name,zones=len(ds),body_zones=sum(d.z['layer']=='body' for d in ds),tail_zones=sum(d.z['layer']=='tail' for d in ds),articulation_counts=dict(Counter(d.z.get('articulation') or d.z['layer'] for d in ds)),decoded_ram_bytes=ram,bundle_audio_bytes=sum((b/z['file']).stat().st_size for z in m['zones']),loop_count=sum(bool(z.get('loop')) for z in m['zones']),lint=[vars(f) for f in findings],lint_counts=dict(Counter(f.level for f in findings)),tuning_by_art={a:dict(min_cents=min(v),max_cents=max(v),spread_cents=max(v)-min(v),zones=len(v)) for a,v in groups.items()},duration_by_art={a:dict(min_s=min(v),median_s=float(np.median(v)),max_s=max(v)) for a,v in lengths.items()},zone_peak_db_max=max(d.peak_db for d in ds),previews=preview(folder,m),can_listen=False)
 (folder/'verification.json').write_text(json.dumps(stats,indent=2)+'\n')
 warnings=[f for f in findings if f.level=='WARN']
 explanation={'brightness':'Le intensità sono registrazioni indipendenti; la quota di energia oltre 4kHz non è monotona su ogni nota. Nessun EQ inventato per uniformarla.','layers':'Le articolazioni secondarie hanno solo il numero di livelli realmente registrati; non si inventano dinamiche.','takes':'Tutti i file sorgente hanno hash distinti. Correlazione elevata nel fondamentale di bassi gravi non significa RR duplicati; lo slap dispone di un solo take per nota.','loudness':'Residue variazioni del gesto registrato oltre 3dB; calibrazione locale limitata per conservare corpo e gesto.','tuning':'Rumori e attacchi pizzicati possono rendere incerta la stima; variazioni naturali conservate.','ladder':'Distanza naturale tra alcune intensità oltre il target, conservata oltre la calibrazione locale limitata.','dc':'Offset misurato nel breve attacco, non clipping o segnale DC permanente.','aliasing':'Dettaglio percussivo originale oltre18kHz, non generato da sintetizzatore.','release':'La piccola fonte slap non offre release separati; il decadimento reale è incluso nel corpo.','onset':'Gesti indipendenti selezionati senza crossfade: differenze della forma d’attacco e della fase non vengono cancellate o tagliate. Preroll originale completo, nessun jitter aggiunto.'}
 p=folder/'notes.md';text=p.read_text();marker='\n## Verifica finale\n';text=text.split(marker)[0]
 text+=marker+'\n'+txt+'\n\n'+ '\n'.join(f"- WARN {f.check}: {explanation.get(f.check,f.text)}" for f in warnings)
 text+=f"\n\n{stats['zones']} zone, {stats['tail_zones']} release; RAM nativa decodificata float32 ai canali originali {ram/2**20:.1f} MiB; audio FLAC {stats['bundle_audio_bytes']/2**20:.1f} MiB. Nessun loop. Preview nativo con soft/mid/hard, RR, sovrapposizione, estremi, tenuta di sei secondi e tutte le articolazioni. Lunga tenuta conserva il decadimento del campione, poi termina: non inventa sustain infinito.\n\n"
 text+='Tuning: una sola correzione statica assoluta per registrazione, fino a60cent; nessuna modifica della curva interna. I dettagli sono in samples/tuning-calibration.json. Misure complete e limiti in verification.json. Non posso ascoltare questi file; realismо e preferenza richiedono ascolto utente.\n'
 p.write_text(text)
 return stats
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('slugs',nargs='*',default=SLUGS);ap.add_argument('--validate-only',action='store_true');args=ap.parse_args()
 for slug in args.slugs:
  folder=BANK/slug
  if not args.validate_only:compile(folder);calibrate(folder)
  validate(folder)
