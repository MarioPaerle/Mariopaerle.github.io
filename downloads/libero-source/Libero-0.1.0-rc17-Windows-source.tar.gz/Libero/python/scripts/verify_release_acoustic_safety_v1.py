"""Read-only native long-hold and exact eight-event headroom checks for seven replacements."""
from pathlib import Path
import json, sys
import numpy as np
import soundfile as sf
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from libero import library, render
from verify_release_replacements_v1 import EXPECTED

HOME = Path.home() / 'Libero'
OUT = HOME / 'demo/release-replacements-v1/acoustic/safety'
SLUGS = {'violoncello-solo-libero', 'archi-armonici-libero',
         'archi-particolari-libero', 'mandolino-dorato-libero',
         'chitarra-classica-libero', 'chitarra-classica-accordi-libero',
         'corno-francese-libero'}

def metrics(path):
    x, sr = sf.read(path, always_2d=True, dtype='float32')
    peak = float(np.max(np.abs(x)))
    result = {'seconds': len(x) / sr, 'peak_dbfs': float(20*np.log10(max(peak, 1e-15))),
              'clipped_samples': int(np.sum(np.abs(x) >= 1))}
    if len(x) >= 59 * sr:
        late = x[10 * sr:59 * sr]
        result['late_rms_dbfs'] = float(20*np.log10(np.sqrt(np.mean(late.astype('float64')**2) + 1e-30)))
    return result

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    index = {r['slug']: r for r in library.list_sounds()}
    report = {'criteria': 'Three 60 s native holds, late 10–59 s RMS >= -50 dBFS; exactly eight simultaneous v127 events at default and maximum dynamics, peak <= -3 dBFS; no clipped samples.',
              'checks': {}, 'errors': []}
    for slug in sorted(SLUGS):
        folder = Path(index[slug]['path'])
        manifest = json.loads((folder/'build/manifest.json').read_text())
        arts = manifest.get('articulations', [])
        default = arts[0]['id'] if arts else None
        zones = [z for z in manifest['zones'] if z.get('layer') == 'body'
                 and z.get('articulation') == default and z.get('pitched') is not False]
        reserved = {a['key'] for a in arts if a.get('key') is not None}
        keys = sorted({k for z in zones for k in range(z['lo'], z['hi']+1)} - reserved)
        assert keys, slug
        notes = sorted({keys[round((len(keys)-1)*f)] for f in (.15,.5,.85)})
        holds = []
        for note in notes:
            wav = OUT/f'{slug}-hold-{note}.wav'
            render.render(folder, wav, [(note,0,60,100)], {}, tail=.4, timeout=240)
            m = metrics(wav); holds.append({'note': note, **m})
            if m['seconds'] < 59.5 or m.get('late_rms_dbfs', -999) < -50 or m['clipped_samples']:
                report['errors'].append({'slug':slug,'test':'hold','note':note,**m})
        stress = [keys[round((len(keys)-1)*i/7)] for i in range(8)]
        assert len(stress) == 8
        stacks = []
        for label, params in [('default',{}),('maximum-dynamics',{'dyn_mode':'Manopola','dynamics':1})]:
            wav = OUT/f'{slug}-8-{label}.wav'
            render.render(folder, wav, [(k,0,3,127) for k in stress], params, tail=.6, timeout=180)
            m = metrics(wav); stacks.append({'mode':label,'event_count':8,'keys':stress,**m})
            if m['peak_dbfs'] > -3 or m['clipped_samples']:
                report['errors'].append({'slug':slug,'test':'headroom','mode':label,**m})
        fresh = library.source_hash(folder) == manifest['source_hash']
        if not fresh:
            report['errors'].append({'slug':slug,'test':'source-freshness'})
        report['checks'][slug] = {'source_hash':manifest['source_hash'],'fresh':fresh,'holds':holds,'stacks':stacks}
        print(slug, 'holds', [round(h['late_rms_dbfs'],2) for h in holds],
              'stacks', [round(s['peak_dbfs'],2) for s in stacks], flush=True)
    report['status'] = 'PASS' if not report['errors'] else 'FAIL'
    (OUT.parent/'safety-report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'errors':report['errors']},indent=2))
    return bool(report['errors'])

if __name__ == '__main__':
    raise SystemExit(main())
