#!/usr/bin/env python3
"""Build four source-led VCSL voices for the Aria bank.

Run from the Libero checkout with python/.venv/bin/python. Sources are pinned to
the VCSL tree SHA in cache/research/cielo/vcsl-tree.json; this script never edits
existing Aria voices or shared bank metadata.
"""
from __future__ import annotations
import hashlib, json, math, re, shutil, sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

import numpy as np
import soundfile as sf

ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, analysis, render, dsp
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from build_aria_mechanical import derive_source_body
from libero.library import home

HOME=Path.home(); BANK=home()/'banks'/'aria'; CACHE=HOME/'Libero/cache/libraries/vcsl'
TREE_FILE=HOME/'Libero/cache/research/cielo/vcsl-tree.json'; TREE=json.loads(TREE_FILE.read_text())
COMMIT=TREE['sha']; SR=48000; OUT=HOME/'Libero/demo/aria-winds-plucked'
OUT.mkdir(parents=True,exist_ok=True)
ROOTS={'C':0,'C#':1,'D':2,'D#':3,'E':4,'F':5,'F#':6,'G':7,'G#':8,'A':9,'A#':10,'B':11}
SOUNDS=[
 {'slug':'arpa-folk','title':'Arpa Folk','family':'Chordophones/Composite Chordophones/Folk Harp','arts':{'corda':'Normal'},'plucked':True,'subtitle':'corde pizzicate · due registrazioni originali per nota','accent':'#a86f4a','kind':'harp'},
 {'slug':'salterio-arco','title':'Salterio vivo','family':'Chordophones/Zithers/Psaltery, Bowed and Plucked','arts':{'pizzicato':'Pluck','arco':'LongBow','spiccato':'Spiccato'},'plucked':True,'subtitle':'plettro, arco lungo e arco corto','accent':'#b27843','kind':'psaltery'},
 {'slug':'ocarina-terra','title':'Ocarina di terra','family':'Aerophones/Edge-blown Aerophones/Ocarina, Typical','arts':{'dritta':'Sus','vibrata':'SusVib'},'plucked':False,'subtitle':'ceramica soffiata · tenuta e vibrato registrati','accent':'#9e704c','kind':'ocarina'},
 {'slug':'armonica-vissuta','title':'Armonica vissuta','family':'Aerophones/Free Aerophones/Harmonica-Hohner-Special20-C','arts':{'morbida':'Soft','normale':'Normal','vibrata':'Vib'},'plucked':False,'subtitle':'Hohner Special 20 in Do · ancia e fiato reali','accent':'#a35343','kind':'harmonica'},
]

def midi(note):
 m=re.fullmatch(r'([A-G](?:#)?)(-?\d+)',note)
 if not m: return None
 return (int(m.group(2))+1)*12+ROOTS[m.group(1)]
def note_in(path):
 # Strip articulation tokens to avoid interpreting letter names in instrument names.
 m=re.search(r'(?<![A-Za-z])([A-G]#?-?\d)(?!\d)',path.stem)
 return midi(m.group(1)) + 12 if m else None
def blob_sha(data):
 return hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
def fetch(rel, dest, expected_git_sha):
 dest.parent.mkdir(parents=True,exist_ok=True)
 if not dest.exists():
  url='https://raw.githubusercontent.com/sgossner/VCSL/'+COMMIT+'/'+quote(rel,safe='/')
  req=Request(url,headers={'User-Agent':'Libero-Aria-source-acquisition/1.0'})
  with urlopen(req,timeout=60) as r: data=r.read()
  if blob_sha(data)!=expected_git_sha: raise ValueError(f'VCSL Git blob mismatch: {rel}')
  dest.write_bytes(data)
 data=dest.read_bytes()
 if blob_sha(data)!=expected_git_sha: raise ValueError(f'Cached VCSL Git blob mismatch: {rel}')
 return data

def vfile_map():
 return {r['path']:r for r in TREE['tree'] if r['type']=='blob' and r['path'].lower().endswith('.wav')}

def sample_pitch(path):
 # These four source folders label C3 at sounding C4; measure near the
 # independently checked family fundamental, allowing high pipes without folding.
 raw,sr=sf.read(path,dtype='float64',always_2d=True); x=raw.mean(axis=1)
 seg=x[int(.08*sr):min(len(x),int(.5*sr))]
 expected=440*2**((note_in(path)-69)/12)
 f0,voiced=dsp.estimate_f0(seg,sr,fmin=max(25,expected*.75),fmax=min(sr*.4,expected*1.3))
 return dict(sr=sr,seconds=len(x)/sr,source_note=midi_note(path),written_midi=midi(midi_note(path)),playback_root=note_in(path),measured_f0_hz=float(f0) if np.isfinite(f0) else None,
             voiced_fraction=float(voiced),peak_dbfs=float(20*np.log10(np.max(np.abs(raw))+1e-12)),
             rms_dbfs=float(20*np.log10(np.sqrt(np.mean(raw*raw))+1e-12)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def midi_note(path):
 m=re.search(r'([A-G]#?-?\d)',path.stem)
 return m.group(1) if m else None

def stable_loop(src, out, *, bowed=False):
 """For wind, loop the real stable played tone, retaining its breath/pitch motion."""
 a=Audio.load(src,sr=SR).remove_dc(4)
 x=a.to_mono().data.astype(float)
 t,e=dsp.rms_envelope(x,SR,.04)
 good=np.flatnonzero(e>e.max()*10**((-9 if bowed else -3)/20))
 if len(good)<5: raise ValueError(f'no stable sustain: {src}')
 onset=max(0,float(t[good[0]])); left=max(onset+.12,float(t[good[0]])+.08); right=float(t[good[-1]])-.08
 if right-left<.9: left=max(onset+.04,float(t[good[0]])); right=float(t[good[-1]])-.025
 lp=a.loop_points(min_seconds=min(3.8 if bowed else 2.8,(right-left)*(.78 if bowed else .66)),region=(left,right),max_crossfade=.09 if bowed else .035)
 if lp is None: raise ValueError(f'no clean source loop: {src}')
 if bowed:
  # Same performed bow, with a smoothstep endpoint splice rather than the
  # equal-power join intended for noise. Last samples converge in value/slope.
  xf=min(int(.18*SR),lp.start,(lp.end-lp.start)//3)
  y=a.data[:lp.end].astype(float).copy()
  u=np.linspace(0,1,xf); w=u*u*(3-2*u)
  if y.ndim==2: w=w[:,None]
  y[-xf:]=y[-xf:]*(1-w)+a.data[lp.start-xf:lp.start]*w
  Audio(y,SR).save(out,subtype='PCM_24')
 else: a.bake_loop(lp).save(out,subtype='PCM_24')
 return {'start':lp.start,'end':lp.end},{'method':'recorded bow sustain loop' if bowed else 'recorded breath/pitch sustain loop','loop_error_db':float(lp.error_db),'loop_seconds':(lp.end-lp.start)/SR}

def family_files(srcmap, spec):
 p=spec['family'].lower()
 chosen=[]
 for rel,row in srcmap.items():
  if not rel.startswith(spec['family']+'/'): continue
  low=rel.lower()
  if not low.endswith('.wav'): continue
  if spec['kind']=='harp':
   if re.search(r'_normal_[a-g]#?\d_v[23]_rr1\.wav$',low): chosen.append((rel,row,'corda','v'+re.search(r'_v([23])_rr1',low).group(1)))
  elif spec['kind']=='psaltery':
   art=next((a for a in spec['arts'].values() if '/'+a.lower()+'/' in low),None)
   if art: chosen.append((rel,row,next(k for k,v in spec['arts'].items() if v==art),re.search(r'_rr(\d+)',low).group(1)))
  elif spec['kind']=='ocarina':
   m=re.search(r'/sustains/(susvib|sus)/([^/]+\.wav)$',rel,re.I)
   if m: chosen.append((rel,row,next(k for k,v in spec['arts'].items() if v.lower()==m.group(1).lower()),'0'))
  else:
   m=re.search(r'/sustains/(soft|normal|vib)/([^/]+\.wav)$',rel,re.I)
   if m: chosen.append((rel,row,next(k for k,v in spec['arts'].items() if v.lower()==m.group(1).lower()),'0'))
 return chosen

def figure(spec):
 kind=spec['kind']; title=spec['title']; accent=spec['accent']
 if kind in ('harp','psaltery'):
  lines=''.join(f'<path d="M{154+i*17} 132 Q{170+i*10} 270 {185+i*7} 373" stroke="currentColor" stroke-width=".75"/>' for i in range(12))
  body='<path d="M117 386 Q146 185 196 94 Q286 78 384 149 L350 391 Q245 351 117 386Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.4"/>'+lines
  extra='<path d="M92 154 L414 118" stroke="#b8924f" stroke-width="2"/>' if kind=='psaltery' else ''
 elif kind=='harmonica':
  body='<rect x="84" y="198" width="344" height="110" rx="16" fill="#f3eee6" stroke="currentColor" stroke-width="1.4"/><path d="M94 242 H418 M110 216 H400" stroke="currentColor" stroke-width=".7"/>'
  extra=''.join(f'<rect x="{105+i*30}" y="265" width="20" height="22" rx="3" stroke="{accent}"/>' for i in range(10))
 else:
  body='<path d="M196 112 Q256 79 316 112 L300 374 Q256 417 212 374Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.4"/><ellipse cx="256" cy="113" rx="60" ry="20" fill="#f3eee6" stroke="currentColor"/><path d="M220 167 Q256 183 292 167 M216 222 Q256 240 296 222 M212 280 Q256 300 300 280 M208 338 Q256 359 304 338" stroke="currentColor" stroke-width=".7"/>'
  extra=''.join(f'<circle cx="{222+i*17}" cy="{165+(i%3)*52}" r="4" fill="{accent}" stroke="none"/>' for i in range(5))
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>{spec["subtitle"]}; linee e fori rappresentano la risonanza acustica registrata.</desc>{body}{extra}</svg>\n'

def build(spec, srcmap):
 slug=spec['slug']; dest=BANK/slug
 if (dest/'verification.json').exists():
  old=json.loads((dest/'verification.json').read_text())
  if old.get('lint',{}).get('FAIL')==0 and old.get('pitch_mapping')=='vcsl-label-plus-12-v1':
   print(slug,'already compiled and lint clean',flush=True); return
 if dest.exists() and (dest/'samples'/'source-proof.json').exists(): shutil.rmtree(dest)
 samples=dest/'samples'; srcdir=samples/'originals'; bodydir=samples/'body'; srcdir.mkdir(parents=True,exist_ok=True);bodydir.mkdir(exist_ok=True)
 allfiles=family_files(srcmap,spec); roots=[]; maprows=[]; proof=[]; tailrows=[]
 if not allfiles: raise RuntimeError(f'No source files for {slug}')
 # Exact sources are saved in full, together with the upstream Git blob SHA and a local SHA-256.
 for rel,row,art,take in allfiles:
  root=note_in(Path(rel))
  if root is None: continue
  local=srcdir/Path(rel).name; fetch(rel,local,row['sha'])
  audit=sample_pitch(local);audit.update(source_path=rel,git_blob_sha=row['sha'],source_url='https://github.com/sgossner/VCSL/blob/'+COMMIT+'/'+quote(rel,safe='/'),articulation=art,source_variant=take)
  derived=bodydir/(local.stem+'-sustain.wav')
  if spec['plucked'] and art!='arco':
   loop,cont=derive_source_body(local,derived,root,period=8.0 if root<72 else 6.0,transition_end=.65)
   audit['continuation']=cont
  else:
   try: loop,cont=stable_loop(local,derived,bowed=art=='arco')
   except ValueError as exc:
    audit['loop_warning']=str(exc); continue
  roots.append(root)
  region=dict(file='body/'+derived.name,root=root,tune_cents=0,articulation=art,take=int(take) if take.isdigit() else 0,loop=loop,pitched=True)
  if spec['kind']=='psaltery' and art=='arco': region['gain_db']=6.0
  if spec['kind']=='harp': region['vel']=[1,63] if take=='v2' else [64,127]
  maprows.append(region)
  proof.append(audit)
 # Collect and preserve real release tails for the two wind instruments.
 if not spec['plucked']:
  for rel,row in srcmap.items():
   low=rel.lower()
   if not rel.startswith(spec['family']+'/') or '/releases/' not in low or not low.endswith('.wav'): continue
   if spec['kind']=='ocarina':
    m=re.search(r'/releases/(susvib|sus)/([^/]+\.wav)$',rel,re.I)
   else: m=re.search(r'/releases/(soft|normal|vib)/([^/]+\.wav)$',rel,re.I)
   if not m: continue
   art=next((k for k,v in spec['arts'].items() if v.lower()==m.group(1).lower()),None)
   note=note_in(Path(rel));root=note_in(Path(rel))
   if art is None or root is None: continue
   note_name=midi_note(Path(rel)); root=note_in(Path(rel))
   local=srcdir/Path(rel).name;fetch(rel,local,row['sha'])
   destrel=bodydir/(local.stem+'-release.wav');shutil.copy2(local,destrel)
   tailrows.append(dict(file='body/'+destrel.name,root=root,articulation=art,take=0,vel=[1,127],pitched=True))
   proof.append(dict(source_path=rel,sha256=hashlib.sha256(local.read_bytes()).hexdigest(),git_blob_sha=row['sha'],role='release',articulation=art,source_url='https://github.com/sgossner/VCSL/blob/'+COMMIT+'/'+quote(rel,safe='/')))
 if not maprows: raise RuntimeError(f'No usable regions for {slug}')
 # The numbered suffix in VCSL is an RR label, but a pitch may start at rr2 or
 # have fewer takes than its neighbours. Renumber actual takes contiguously in
 # each key/articulation/dynamic group; this does not synthesize missing takes.
 groups={}
 for region in maprows:
  group=(region['root'],region['articulation'],tuple(region.get('vel',[])))
  groups.setdefault(group,[]).append(region)
 for items in groups.values():
  items.sort(key=lambda r:r['file'])
  for i,region in enumerate(items): region['take']=i
 take_count=max(len(x) for x in groups.values())
 arts=sorted(spec['arts'])
 # Release samples are sparse too. Give each recorded release its nearest-key
 # interval within its actual articulation so every note-off can reach one.
 if tailrows:
  for art in arts:
   items=sorted((r for r in tailrows if r['articulation']==art),key=lambda r:r['root'])
   for i,r in enumerate(items):
    r['lo']=0 if i==0 else (items[i-1]['root']+r['root'])//2+1
    r['hi']=127 if i==len(items)-1 else (r['root']+items[i+1]['root'])//2
 (samples/'map.json').write_text(json.dumps({'body':maprows,'tail':tailrows},indent=2)+'\n')
 (samples/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 (samples/'credits.json').write_text(json.dumps([dict(source='Versilian Community Sample Library (VCSL)',author='Versilian Studios LLC / VCSL contributors',license='CC0 1.0',license_class='cc0',url='https://github.com/sgossner/VCSL',commit=COMMIT,license_url='https://github.com/sgossner/VCSL/blob/'+COMMIT+'/LICENSE',retrieved=datetime.now(timezone.utc).date().isoformat(),source_file_count=len(proof))],indent=2)+'\n')
 # Region loop endpoints are detected source coordinates; all original samples remain untouched.
 sound=f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nSAMPLES=Path(__file__).parent/'samples'\nMAP=json.loads((SAMPLES/'map.json').read_text())\nsound=Sound(title={spec['title']!r},subtitle={spec['subtitle']!r},tags=['aria','sampled','vcsl','acoustic','warm'],roots={sorted(set(roots))!r},velocities=[28,60,96,120],sample_rate=48000,accent={spec['accent']!r},takes={take_count})\nsound.articulations([{','.join(repr({'id':a,'name':a.title(),'key':None}) for a in arts)}])\nsound.multisample('body',MAP['body'],process={{'pre_ms':2,'align_ms':0,'tune':'source','ladder':'keep','peak_db':-13,'end_db':-100,'fade_ms':0,'loop':'source','max_seconds':None,'encoding':'flac24','mono':False}},as_dyn=False)\nif MAP['tail']: sound.multisample('tail',MAP['tail'],process={{'tune':'none','ladder':'keep','align_ms':0,'pre_ms':2,'end_db':-80,'fade_ms':30,'loop':'none','edge_fill':False}},as_dyn=False)\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=0)\nsound.defaults(mode='Poli',glide=0,voices=24,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=360,lvl_body=0,lvl_attack=-60,lvl_tail=0 if MAP['tail'] else -60,lvl_air=-60,vel_sens=.45,master={0 if spec['kind']=='psaltery' else -2},osc1_level=-60,osc2_level=-60,sub_level=-60,drive=0,tape_wow=0,tape_flutter=0,tape_sat=0,tape_mix=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix=.04,rev_decay=1.15,rev_damp=.45)\n'''
 (dest/'sound.py').write_text(sound)
 (dest/'figure.svg').write_text(figure(spec))
 body_method=('il gesto maturo registrato per l’arco, con loop sorgente e splice smoothstep di 180 ms, e una continuazione modale della stessa nota per pizzicato e spiccato' if spec['kind']=='psaltery' else ('una continuazione modale ricavata dalle componenti della stessa nota, con attacco registrato preservato per 180 ms e transizione fino a 650 ms' if spec['plucked'] else 'un ciclo dalla registrazione soffiata originale, mantenendone movimento di pitch e aria'))
 layer_note=('Le versioni v2/v3 sono mantenute come i due livelli velocity disponibili: su ognuna delle 29 radici il v3 ha RMS maggiore, da 2,8 a 20,4 dB (media 10,8 dB). Il naming VCSL non esplicita il significato di `v`; il WARN di luminosità conferma che la differenza misurata è soprattutto di livello, perciò non la presento come un cambio timbrico.' if spec['kind']=='harp' else 'Le articolazioni/takes compaiono solo dove i file originali le offrono; non sono stati duplicati per riempire zone.')
 notes=f'''# {spec['title']}\n\n{spec['subtitle']}. Strumento acustico registrato dalla VCSL, archivio upstream fissato al commit `{COMMIT}` e rilasciato CC0 1.0. `samples/originals/` conserva i WAV originali integrali, `source-proof.json` registra percorso VCSL, SHA Git blob e SHA-256 locale per ogni sorgente e release. `credits.json` include autore, licenza, commit e pagina d'origine.\n\nArticolazioni offerte integralmente: {', '.join(arts)}. Zone body compilate: {len(maprows)}; note radice distinte: {len(set(roots))}; release reali incluse: {len(tailrows)}. I file VCSL non marcati velocity o RR restano un solo livello/take. {layer_note}\n\nLa tenuta infinita usa {body_method}; non viene aggiunto un noise bed o un tappeto di sinusoidi generiche. Le articolazioni rimangono distinguibili. Poli, glide 0, riverbero moderato, wow/flutter 0.\n\nVerifica nativa e avvertenze in `verification.json`; WARN non corretti sono descritti qui.\n'''
 (dest/'notes.md').write_text(notes)
 result=compile_sound(dest,jobs=2)
 if not result.ok: raise RuntimeError(result.text())
 findings=lint_bundle(dest/'build'); fails=[x for x in findings if x.level=='FAIL'];
 if fails: raise RuntimeError('\n'.join(x.line() for x in fails))
 # Musical QA: phrase, held note/chord, mono-compatible register sweep, plus spectra.
 slugmap={s['slug']:s for s in SOUNDS}; iswind=not spec['plucked']
 phrase='60:0:.8:32,64:.9:.8:60,67:1.8:1:96,72:3:1.2:115,67:4.5:.35:72,67:4.95:.35:72,67:5.4:.35:72'
 if spec['kind'] in ('harp','psaltery'): phrase='48:0:.4:60,55:.5:.4:80,60:1:.6:105,67:2:.8:118,64:3:.4:75,72:4:.6:110'
 qa={}
 for name,notes_seq,tail in [('phrase',phrase,1.3),('held60','67:0:60:100',1),('chord','48:0:3:96,55:0:3:96,60:0:3:96,64:0:3:96',1.2),('registers','48:0:.7:95,55:.8:.7:95,60:1.6:.7:95,67:2.4:.7:95,72:3.2:.7:95,79:4:.7:95,84:4.8:.7:95',1.2)]:
  pv=render.preview(slug,notes_seq,tail=tail)
  shutil.copy2(pv.wav,OUT/(slug+'-'+name+'.wav'))
  feat=analysis.features(pv.audio); qa[name]=feat
  if name=='phrase': (OUT/(slug+'-phrase.png')).write_bytes(analysis.spectrogram(pv.audio,title=spec['title']+' · phrase'))
 # 0-FAIL required. Save exact lint and primary numerical checks.
 (dest/'lint.txt').write_text('\n'.join(f.line() for f in findings)+'\n')
 report={'pitch_mapping':'vcsl-label-plus-12-v1','slug':slug,'source':{'provider':'VCSL','commit':COMMIT,'license':'CC0 1.0','source_files':len(proof),'body_zones':len(maprows),'release_zones':len(tailrows),'roots':sorted(set(roots))},'compile_warnings':result.warnings,'lint':{'FAIL':len(fails),'WARN':sum(x.level=='WARN' for x in findings),'findings':[f.line() for f in findings]},'native_previews':qa,'modal_continuations':[x.get('continuation',{}) for x in proof if x.get('continuation')],'loop_measurements':[x.get('continuation',x) for x in proof if x.get('continuation') or x.get('loop_seconds')]}
 (dest/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
 warn_notes=[]
 warning_text='\n'.join(f.line() for f in findings if f.level=='WARN')
 if 'aliasing' in warning_text: warn_notes.append('Aliasing sopra 18 kHz: il materiale è presente negli attacchi originali e viene preservato; transposizioni molto alte possono ripiegarlo, quindi il registro sorgente è il riferimento. Non ho tagliato attacchi per nascondere la misura.')
 if 'loudness' in warning_text: warn_notes.append('Salti di loudness tra note: differenze misurate nelle registrazioni VCSL originali. Restano udibili e non vengono livellate nota per nota.')
 if 'ladder' in warning_text: warn_notes.append('Distanze tra dinamiche: la differenza di livello fra v2/v3 dell’arpa è ampia e cambia da corda a corda; sono i due sample originali della sorgente, senza compressione dinamica.')
 if 'brightness' in warning_text: warn_notes.append('Luminosità delle dinamiche: il lint rileva che i due strati dell’arpa hanno un’impronta spettrale simile, con la differenza concentrata soprattutto nel livello. Mantengo i due campioni offerti dalla sorgente senza inventare colore.')
 if 'onset' in warning_text: warn_notes.append('Onset: alcuni attacchi originali hanno preroll diverso di 1–2 ms; è conservato perché fa parte del gesto registrato.')
 if warn_notes: notes+='\n## Avvertenze lint\n\n'+'\n'.join('- '+w for w in warn_notes)+'\n'
 (dest/'notes.md').write_text(notes+'\n## Verifica tecnica\n\n'+json.dumps(report,indent=2)+'\n')
 print(slug, 'zones',len(maprows),'releases',len(tailrows),'lint',report['lint'],flush=True)

def main():
 srcmap=vfile_map()
 for spec in SOUNDS: build(spec,srcmap)
 print('native demo files:',OUT,flush=True)
if __name__=='__main__': main()
