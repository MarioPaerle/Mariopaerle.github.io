"""Read-only integrity and runtime integration check; never recompile originals."""
from pathlib import Path
from collections import Counter
import argparse, hashlib, json, sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero import library
HOME=Path.home()/'Libero'; OUT=HOME/'demo/release-replacements-v1'
EXPECTED={
 'bassi':['808-cavo-libero','808-colpo-libero','808-notte-libero'],
 'archi':['violoncello-solo-libero','archi-armonici-libero','archi-particolari-libero'],
 'aria':['mandolino-dorato-libero'],
 'chitarre':['chitarra-classica-libero','chitarra-classica-accordi-libero'],
 'ottoni':['corno-francese-libero'],
 'mie':['trap-hit-libero'],
 'trap':['trap-coro-libero','trap-kit-libero','trap-kit-ita-libero','trap-kit-pro-libero'],
 'percussioni':['percussioni-mano-libero','percussioni-texture-libero'],
 'prove':['chitarra-acustica-libero'],
}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as r:
  for block in iter(lambda:r.read(4*1024*1024),b''):h.update(block)
 return h.hexdigest()
def visible(p):
 return {str(f.relative_to(p)):f for f in p.rglob('*') if f.is_file() and not any(t.startswith('.') or t=='__pycache__' for t in f.relative_to(p).parts)}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--allow-giove',action='store_true',help='Allow the separately requested new Giove bank while checking the original 200 and 18 replacements')
 args=parser.parse_args()
 baseline=json.loads((OUT/'original-200-before.json').read_text()); current=library.list_sounds()
 index={(r['bank'],r['slug']):r for r in current}; errors=[]; preserved=[]; added=[]
 for old in baseline['presets']:
  key=(old['bank'],old['slug']); now=index.get(key)
  if not now or now['path']!=old['path']:errors.append(f'{key}: moved or missing');continue
  fs=visible(Path(old['path']))
  if set(fs)!=set(old['files']):errors.append(f'{key}: file roster changed');continue
  changed=[rel for rel,proof in old['files'].items() if fs[rel].stat().st_size!=proof['bytes'] or sha(fs[rel])!=proof['sha256']]
  if changed:errors.append(f'{key}: changed files {changed}')
  else:preserved.append(key)
 for bank,slugs in EXPECTED.items():
  for slug in slugs:
   row=index.get((bank,slug))
   if not row:errors.append(f'{bank}/{slug}: missing replacement');continue
   p=Path(row['path']); mf=p/'build/manifest.json'
   if not mf.exists():errors.append(f'{slug}: no compiled manifest');continue
   m=json.loads(mf.read_text()); zones=m.get('zones',[]); params=m.get('params',{})
   errors.extend(f'{slug}: {e}' for e in library.validate_bundle(p/'build'))
   fresh=library.source_hash(p)==m.get('source_hash')
   if not fresh:errors.append(f'{slug}: stale source')
   if params.get('mode') not in ('Poli',0,None) or params.get('glide',0)!=0:errors.append(f'{slug}: unexpected portamento default')
   if any(params.get(k,0) for k in ('tape_wow','tape_flutter')):errors.append(f'{slug}: unsolicited wobble')
   if params.get('caldi_mode','Spento') not in ('Spento',0):errors.append(f'{slug}: unsolicited Caldi')
   default=m.get('articulations',[{}])[0].get('id') if m.get('articulations') else None
   body=[z for z in zones if z.get('layer')=='body' and (default is None or z.get('articulation')==default)]
   kit=bool(set(m.get('tags',[])) & {'kit','drum-kit','drums','trap-kit','percussioni'}) or (bool(body) and all(z.get('pitched') is False for z in body))
   if body and not kit and any(not z.get('loop') for z in body):errors.append(f'{slug}: default pitched body lacks infinite sustain')
   added.append({'bank':bank,'slug':slug,'fresh':fresh,'zones':len(zones),'kit':kit,'runtime_bytes':sum(f.stat().st_size for f in (p/'build').rglob('*') if f.is_file())})
 duplicates=[s for s,n in Counter(r['slug'] for r in current).items() if n>1]
 if duplicates:errors.append(f'duplicate slugs: {duplicates}')
 expected={(r['bank'],r['slug']) for r in baseline['presets']}|{(b,s) for b,ss in EXPECTED.items() for s in ss}
 permitted_new={key for key in index if key[0]=='giove'} if args.allow_giove else set()
 if set(index)!=expected|permitted_new:errors.append('unexpected library roster: '+str(sorted(set(index)^(expected|permitted_new))))
 result={'original_preserved_count':len(preserved),'replacement_count':len(added),'active_count':len(current),'replacements':added,'errors':errors,'limitations':'Runtime integrity does not establish sample licensing or certify musical quality; consult per-preset source rights and native QA.'}
 (OUT/'integration.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
 return bool(errors)
if __name__=='__main__':raise SystemExit(main())
