#!/usr/bin/env python3
"""Rebuild the articulated Bebop wind patches from cached real recordings."""
from __future__ import annotations
import hashlib, json, os, shutil, subprocess, sys, time
from pathlib import Path
import numpy as np
import soundfile as sf
from libero.audio import Audio
from libero.multisample import true_onset
REPO=Path('/Users/mario/Documents/Libero')
CLI=REPO/'python/.venv/bin/libero'
SKETCHES=Path('/Users/mario/Libero/sketches')
VSCO=Path('/Users/mario/Libero/cache/libraries/vsco2-ce')
MTG=Path('/Users/mario/Libero/cache/libraries/mtg-solo-sax/MTG Solo Saxophones')
TINYSOL=Path('/Users/mario/Libero/cache/libraries/tinysol/Winds/Clarinet_Bb/ordinario')
# (stage slug, source, family, title, final slug, art id)
SOURCES=[
('bebop-trumpet-sus',VSCO/'TrumpetSus.sfz','brass','Trumpet · sustain','bebop-trumpet','sus'),
('bebop-trumpet-vib',VSCO/'TrumpetSusVib.sfz','brass','Trumpet · vibrato','bebop-trumpet','vib'),
('bebop-trumpet-stac',VSCO/'TrumpetStac.sfz','brass','Trumpet · staccato','bebop-trumpet','stac'),
('bebop-trombone-sus',VSCO/'TromboneSus.sfz','brass','Trombone · sustain','bebop-trombone','sus'),
('bebop-trombone-vib',VSCO/'TromboneVib.sfz','brass','Trombone · vibrato','bebop-trombone','vib'),
('bebop-trombone-stac',VSCO/'TromboneStac.sfz','brass','Trombone · staccato','bebop-trombone','stac'),
('bebop-old-trombone-buzz',VSCO/'Brass/OldTrombone/Buzz','brass','Old trombone · buzz','bebop-trombone','buzz'),
('bebop-old-trombone-fall',VSCO/'Brass/OldTrombone/Fall','brass','Old trombone · fall','bebop-trombone','fall'),
('bebop-old-trombone-short',VSCO/'Brass/OldTrombone/Short','brass','Old trombone · short','bebop-trombone','short'),
('bebop-horn-sus',VSCO/'FHornSus.sfz','brass','French horn · sustain','bebop-french-horn','sus'),
('bebop-horn-stac',VSCO/'FHornStac.sfz','brass','French horn · staccato','bebop-french-horn','stac'),
('bebop-horn-mute',VSCO/'FHornMute.sfz','brass','French horn · muted','bebop-french-horn','mute'),
('bebop-tuba-sus',VSCO/'TubaSus.sfz','brass','Tuba · sustain','bebop-tuba','sus'),
('bebop-tuba-stac',VSCO/'TubaStac.sfz','brass','Tuba · staccato','bebop-tuba','stac'),
('bebop-stage-sax-soprano',MTG/'MTG Soprano Sax.sfz','wind','Soprano saxophone','bebop-sax-soprano',''),
('bebop-stage-sax-alto',MTG/'MTG Alto Sax.sfz','wind','Alto saxophone','bebop-sax-alto',''),
('bebop-stage-sax-tenor',MTG/'MTG Tenor Sax.sfz','wind','Tenor saxophone','bebop-sax-tenor',''),
('bebop-stage-sax-bari',MTG/'MTG Baritone Sax.sfz','wind','Baritone saxophone','bebop-sax-bari',''),
('bebop-stage-clarinet-bb',TINYSOL,'wind','Clarinet in B♭','bebop-clarinet-bb',''),
]
ARTS={
 'bebop-trumpet':[('sus','Sostenuto',12),('vib','Vibrato',13),('stac','Staccato',14)],
 'bebop-trombone':[('sus','Sostenuto',12),('vib','Vibrato',13),('stac','Staccato',14),('buzz','Buzz',15),('fall','Fall',16),('short','Short',17)],
 'bebop-french-horn':[('sus','Sostenuto',12),('stac','Staccato',13),('mute','Muted',14)],
 'bebop-tuba':[('sus','Sostenuto',12),('stac','Staccato',13)],
}
MASTER_DB={'bebop-trumpet':-2,'bebop-trombone':5,'bebop-french-horn':6,'bebop-tuba':5,
           'bebop-sax-soprano':-7,'bebop-sax-alto':-10,'bebop-sax-tenor':-7,
           'bebop-sax-bari':-4,'bebop-clarinet-bb':-8}

def cmd(*args):
 for attempt in range(4):
  p=subprocess.run([str(CLI),*map(str,args)],cwd=REPO,text=True,capture_output=True)
  if not p.returncode: return p.stdout.strip()
  transient=('FileNotFoundError' in p.stderr and '.part' in p.stderr and 'compile' in args)
  if not transient or attempt==3:
   raise RuntimeError(f"libero {' '.join(map(str,args))}:\n{p.stdout}\n{p.stderr}")
  time.sleep(2+attempt)
def link_tree(src:Path,dst:Path):
 for p in src.rglob('*'):
  rel=p.relative_to(src); target=dst/rel
  if p.is_dir(): target.mkdir(parents=True,exist_ok=True)
  elif not target.exists():
   target.parent.mkdir(parents=True,exist_ok=True)
   try: os.link(p,target)
   except OSError: shutil.copy2(p,target)
def pressure_loop(src:Path,samples:Path,basename:str):
 """Make a same-take, phase-consistent sustain loop with exact 135 ms join."""
 sr=48000; a=Audio.load(src,sr=sr); x=a.data.astype(np.float64)
 if x.ndim==1: x=x[:,None]
 onset_s=true_onset(x,sr)/sr
 start=max(round(.30*sr),round((onset_s+.05)*sr)); keep=round(.135*sr)
 end=len(x)-keep; xf=round(.30*sr)
 if end-start<round(.62*sr) or xf*2>=end-start:
  return None,None,{'looped':False,'reason':'source too short for >=0.62 s same-take loop','source_seconds':len(x)/sr}
 j=end-xf; tgt0=start-xf
 if tgt0<0: return None,None,{'looped':False,'reason':'loop start precedes available overlap','source_seconds':len(x)/sr}
 y=x[:end].copy(); u=np.linspace(0,1,xf,endpoint=False);u=u*u*(3-2*u)
 ramp_end=end-keep; ramp_n=ramp_end-j
 u2=np.linspace(0,1,ramp_n,endpoint=True);u2=u2*u2*(3-2*u2)
 y[j:ramp_end]=x[j:ramp_end]*(1-u2[:,None])+x[tgt0:tgt0+ramp_n]*u2[:,None]
 y[end-keep:end]=x[start-keep:start]
 tail=x[end:].copy()
 if len(tail):
  nfade=min(len(tail),round(.008*sr)); tail[-nfade:]*=np.linspace(1,0,nfade,endpoint=True)[:,None]
  y=np.concatenate([y,tail],axis=0)
 dest=samples/'derived'/f'{basename}-pressure-loop.flac';dest.parent.mkdir(parents=True,exist_ok=True)
 sf.write(dest,y,sr,format='FLAC',subtype='PCM_24')
 audit={'looped':True,'method':'same-take sustained pressure loop with exact source overlap','loop_seconds':(end-start)/sr,'crossfade_ms':1000*xf/sr,'loop_start_seconds':start/sr,'source_onset_seconds':onset_s,'post_loop_tail_ms':1000*len(tail)/sr,'exact_source_join_ms':1000*keep/sr,'source_seconds':len(x)/sr,'derived_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
 return dest.relative_to(samples).as_posix(),{'start':start,'end':end},audit
def calibrate_ladders(folder:Path, slug:str):
 # Small per-region offsets repair non-monotonic recorded velocity layers;
 # the source audio and every velocity/take region remain intact.
 sys.path.insert(0,str(REPO/'python'))
 from libero import lint, families
 build=folder/'build'
 manifest=json.loads((build/'manifest.json').read_text())
 fam='wind' if slug.startswith('bebop-sax') else 'brass'
 groups={}
 for z in manifest.get('zones',[]):
  if z.get('layer')!='body': continue
  d=lint._load(build,z,True)
  axis=tuple(z.get('dyn') or (z['vel_lo'],z['vel_hi']))
  key=(z.get('articulation'),z['root'],z['lo'],z['hi'])
  groups.setdefault(key,{}).setdefault(axis,[]).append((d.lufs_max,z))
 data=json.loads((folder/'samples/map.json').read_text())
 adjusted=[]
 for key,axes in groups.items():
  ordered=sorted(axes.items(),key=lambda kv:kv[0])
  previous=None
  for axis,vals in ordered:
   raw=sorted(vals,key=lambda x:x[1].get('take',0))[0][0]
   wanted=(previous+0.8) if previous is not None else raw
   delta=max(0.0,wanted-raw)
   effective=raw+delta
   if delta>0.01:
    art,root,lo,hi=key
    a,b=axis
    for r in data.get('body',[]):
     if r.get('root')!=root or r.get('articulation')!=art: continue
     vel=r.get('vel',[1,127]); ra=((vel[0]-1)/126,(vel[1]-1)/126)
     if abs(ra[0]-a)<0.025 and abs(ra[1]-b)<0.025:
      r['gain_db']=float(r.get('gain_db',0))+delta
    adjusted.append((key,axis,round(delta,2)))
   previous=effective
 (folder/'samples/map.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 return adjusted

def figure_svg(slug: str) -> str:
 # Original instrument-specific engraved silhouettes, kept self-contained so
 # the compiled plugin can show each acoustic source as a distinct instrument.
 common='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#282630" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>{desc}</desc>'
 drawings={
 'bebop-trumpet':('Tromba bebop','Il tubo conico ripiegato e la campana distinguono il registro brillante; tre pistoni sono disegnati lungo la linea del fiato.','<path d="M85 250H287Q322 250 347 224L389 181M287 250Q322 250 347 276L389 319M389 181L449 151M389 319L449 349M448 151L448 349" stroke-width="2"/><path d="M134 235V265M174 235V265M214 235V265" stroke-width="1.2"/><path d="M134 235V208H152V235M174 235V208H192V235M214 235V208H232V235" stroke-width="1.2"/><path d="M389 181L448 151M389 319L448 349" stroke="#b8924f" stroke-width="1.5"/><path d="M85 243V257M95 243V257M105 243V257" stroke-width=".6"/>'),
 'bebop-trombone':('Trombone bebop','La coulisse lunga e mobile percorre il corpo sonoro; la campana ampia corrisponde alla coda piena del registro medio-basso.','<path d="M75 230H285V282H75M285 256H425L463 216V296L425 256" stroke-width="1.6"/><path d="M126 230V282M144 230V282M162 230V282M180 230V282M198 230V282M216 230V282" stroke-width=".55"/><path d="M75 239H49V273H75" stroke-width="1.2"/><path d="M425 230L463 216M425 282L463 296" stroke="#b8924f" stroke-width="1.4"/><path d="M298 247H406M298 265H406" stroke-width=".7"/>'),
 'bebop-french-horn':('Corno francese bebop','Il tubo circolare annidato nella campana rappresenta il timbro rotondo; la piccola mano nella campana richiama la variante sordina registrata.','<path d="M132 355C91 329 92 260 134 223C176 186 249 186 290 222C327 254 327 314 293 346C263 374 207 377 177 351C152 330 150 292 171 271C192 250 229 250 247 270C264 289 258 316 241 326" stroke-width="2"/><path d="M132 355L93 385M290 222L389 165L453 192V319L390 344L293 346" stroke-width="1.3"/><path d="M390 165L390 344M404 173V337M418 180V331M432 186V325" stroke-width=".55"/><path d="M421 241Q444 251 421 269" stroke="#b8924f" stroke-width="1.6"/>'),
 'bebop-tuba':('Tuba bebop','Le grandi spire ravvicinate indicano la colonna d’aria lunga; la campana larga e rivolta in alto segna il fondamentale profondo.','<path d="M171 376V205Q171 158 219 158H269Q314 158 314 202V329Q314 359 284 359H222Q194 359 194 330V230Q194 202 223 202H262Q287 202 287 229V300" stroke-width="2"/><path d="M171 205H129V165H171M287 300H332V265H314" stroke-width="1.1"/><path d="M129 165L110 110H348L332 165Z" stroke-width="1.6"/><path d="M110 110L348 110M131 121H327M146 133H313M158 145H301" stroke-width=".55"/><path d="M110 110H348" stroke="#b8924f" stroke-width="1.7"/><path d="M205 206V182M233 206V182M261 206V182" stroke-width="1"/>'),
 'bebop-sax-soprano':('Sassofono soprano','Il corpo diritto e la campana appena aperta seguono la linea agile del soprano; le chiavi corrono lungo il tubo.','<path d="M233 95V354Q233 380 256 394L287 413V370L266 351V95Q266 76 249 76Q233 76 233 95Z" stroke-width="1.5"/><path d="M233 95H266M237 124H262M237 154H262M237 184H262M237 214H262M237 244H262M237 274H262M237 304H262" stroke-width=".65"/><path d="M219 133H235M262 163H280M219 193H235M262 223H280M219 253H235M262 283H280M233 354Q251 344 266 351" stroke-width="1.1"/><path d="M256 395L287 413" stroke="#b8924f" stroke-width="1.5"/>'),
 'bebop-sax-alto':('Sassofono contralto','La campana svasata e il collo ricurvo rendono riconoscibile il contralto; le chiavi articolano i salti fra i registri campionati.','<path d="M247 91Q247 73 265 73Q282 73 282 91V151Q282 170 263 181L246 193V337Q246 365 220 386L183 416V360L211 339V200Q211 177 230 162L247 148Z" stroke-width="1.5"/><path d="M247 91H282M222 208H244M222 238H244M222 268H244M222 298H244M246 182L269 164" stroke-width=".7"/><path d="M211 210H195M246 232H264M211 258H195M246 280H264M211 306H195M183 416L220 386" stroke-width="1"/><path d="M183 416L220 386" stroke="#b8924f" stroke-width="1.5"/>'),
 'bebop-sax-tenor':('Sassofono tenore','Il collo curvato e la campana profonda danno al tenore una postura più ampia; la sequenza di chiavi segue il corpo conico.','<path d="M222 132Q204 118 211 99Q220 77 244 84L270 93Q289 99 282 118L268 151Q261 169 240 178L225 185V324Q225 353 202 374L162 408V350L188 326V196Q188 174 207 158L222 132Z" stroke-width="1.6"/><path d="M222 132L268 151M199 209H223M199 240H223M199 271H223M199 302H223M188 326Q207 337 225 324" stroke-width=".7"/><path d="M162 408L202 374" stroke="#b8924f" stroke-width="1.6"/><path d="M211 99Q228 87 244 84M235 179V200" stroke-width="1"/>'),
 'bebop-sax-bari':('Sassofono baritono','Il grande arco del collo e la campana ampia disegnano la massa grave del baritono; le chiavi sono più distanziate sul lungo fusto.','<path d="M201 145Q178 128 190 101Q202 74 231 88L278 109Q298 118 287 141L268 178Q260 194 239 204L221 212V321Q221 353 192 378L145 415V352L178 324V221Q178 193 198 175L201 145Z" stroke-width="1.7"/><path d="M201 145L268 178M188 232H219M188 268H219M188 304H219M178 324Q200 340 221 321" stroke-width=".75"/><path d="M145 415L192 378" stroke="#b8924f" stroke-width="1.7"/><path d="M190 101Q203 80 231 88M234 208V227" stroke-width="1"/>'),
 'bebop-clarinet-bb':('Clarinetto in Si bemolle','Il canneggio quasi cilindrico termina nel padiglione svasato; anelli e fori aperti distinguono la voce legnosa dai sax.','<path d="M244 82V361Q244 382 256 398Q269 382 269 361V82Q269 67 256 67Q244 67 244 82Z" stroke-width="1.5"/><path d="M244 113H269M244 151H269M244 189H269M244 227H269M244 265H269M244 303H269M244 341H269" stroke-width=".8"/><circle cx="235" cy="133" r="3" fill="#b8924f" stroke="#b8924f"/><circle cx="278" cy="171" r="3"/><circle cx="235" cy="209" r="3"/><circle cx="278" cy="247" r="3"/><circle cx="235" cy="285" r="3"/><path d="M244 361Q250 374 256 398Q263 374 269 361" stroke-width="1.3"/>')}
 title,desc,path=drawings[slug]
 return common.format(title=title,desc=desc)+path+'</svg>\n'
def main():
 collected={}
 only={s.strip() for s in os.environ.get('BEBOP_ONLY_SLUGS','').split(',') if s.strip()}
 for stage,source,fam,title,final,art in SOURCES:
  if only and final not in only: continue
  if not source.exists(): raise FileNotFoundError(source)
  if stage.startswith('bebop-stage-sax-'):
   # Preserve every true played RR/dynamic layer. The standard CLI defaults to
   # a smaller family take count; MTG's pitched p/f groups have 3 RR each.
   from libero.ingest.importers import import_sfz
   result=import_sfz(stage,source,fam,title,layers=3,takes=20,budget_mb=512,quality='slow',replace=True)
  else:
   result=json.loads(cmd('import',stage,source,'-f',fam,'--title',title,'--replace'))
  collected.setdefault(final,[]).append((stage,art,result))
  print(f"source {stage}: {result['body_regions']} regions, {result['roots']} roots")
 for final,parts in collected.items():
  target=SKETCHES/final
  # For single-articulation sax patches, importer already created the final folder.
  if target != SKETCHES/parts[0][0]:
   if target.exists(): shutil.rmtree(target)
   shutil.copytree(SKETCHES/parts[0][0],target,copy_function=shutil.copy2)
  body=[]; credits=[]; exclusions=[]
  original_maps=[]
  for stage,art,_ in parts:
   src=SKETCHES/stage
   if src!=target: link_tree(src/'samples',target/'samples')
   m=json.loads((src/'samples/map.json').read_text())
   original_maps.append({'stage_slug':stage,'map':m})
   for r in m.get('body',[]):
    r=dict(r)
    # The MTG sax SFZ also includes CC-gated breath/key-noise groups. The
    # importer cannot evaluate those controller gates, so exclude their short
    # unpitched files from the musical note map while retaining their rows and
    # files in the original source proof.
    if final.startswith('bebop-sax') and __import__('re').search(r'_(?:b|k)_\d+\.flac$',r.get('file',''),__import__('re').I):
     exclusions.append({'stage_slug':stage,'source_region':r,'reason':'CC-gated breath/key-noise group; not a pitched note performance'})
     continue
    if art: r['articulation']=art
    if art in ('stac','fall','short'): r['one_shot']=True
    # A few SFZ presets repeat identical sample opcodes in overlapping groups.
    # Keep each unique recorded file/key/velocity mapping once; preserve true
    # round robins when they point to distinct source performances.
    body.append(r)
   for credit in json.loads((src/'samples/credits.json').read_text()):
    if credit not in credits: credits.append(credit)
  unique=[]; seen=set()
  for r in body:
   k=(r.get('articulation'),r['file'],r['root'],tuple(r.get('vel',[])),tuple(r.get('dyn',[])),r.get('lo'),r.get('hi'))
   if k not in seen: seen.add(k); unique.append(r)
  body=unique
  # Normalize gaps in imported RR indices after exact duplicate mappings are
  # removed; each genuine distinct performance retains its own slot.
  groups={}
  for r in body:
   # SFZ may use adjacent physical sample roots for RR alternatives of the
   # same played note; index takes by the explicit target key range.
   group_key=(r.get('lo'),r.get('hi')) if r.get('lo') is not None and r.get('hi') is not None else (r['root'],r['root'])
   k=(r.get('articulation'),group_key,tuple(r.get('vel',[])),tuple(r.get('dyn',[])))
   groups.setdefault(k,[]).append(r)
  for rows in groups.values():
   rows.sort(key=lambda r:(int(r.get('take',0)),r['file']))
   for i,r in enumerate(rows):
    if i: r['take']=i
    else: r.pop('take',None)
  # Keep nearest-root chromatic zones inside the source's actual sampled range;
  # never let one sparse sample silently cover the full MIDI keyboard.
  roots_by_art={}
  for r in body: roots_by_art.setdefault(r.get('articulation'),set()).add(r['root'])
  ranges={}
  for art,rr in roots_by_art.items():
   ordered=sorted(rr)
   for i,root in enumerate(ordered):
    lo=root if i==0 else (ordered[i-1]+root)//2+1
    hi=root if i==len(ordered)-1 else (root+ordered[i+1])//2
    ranges[(art,root)]=(lo,hi)
  for r in body:
   if 'lo' not in r and 'hi' not in r:
    r['lo'],r['hi']=ranges[(r.get('articulation'),r['root'])]
   elif 'lo' not in r: r['lo']=r['root']
   elif 'hi' not in r: r['hi']=r['root']
  tune_fixes=[]; level_fixes=[]
  for r in body:
   tune=float(r.get('tune_cents',0))
   if abs(tune)>100:
    oldroot=r['root']; semitones=round(tune/100)
    r['root']=int(oldroot-semitones)
    r['tune_cents']=round(tune-100*semitones,2)
    tune_fixes.append({'file':r['file'],'sfz_root':oldroot,'physical_root':r['root'],'original_tune_cents':tune,'residual_tune_cents':r['tune_cents'],'method':'nearest-MIDI rebase from measured source fundamental; explicit original key range preserved'})
   # The bari low Bb recording has a stable +13.4-cent native residual after
   # preserving its rebased SFZ tuning opcode. Correct only that actual source
   # root; retain the unmodified opcode and the measured adjustment in proof.
   if final=='bebop-sax-bari' and r['root']==39:
    before=float(r.get('tune_cents',0)); r['tune_cents']=round(before-13.4,2)
    tune_fixes.append({'file':r['file'],'physical_root':39,'preserved_source_tune_cents':before,'native_correction_cents':-13.4,'method':'native sustained-body calibration of the played D#2 sample; original opcode remains in source-maps-original.json'})
   # The lowest sustained tuba sample's stable native body measures sharp at
   # the root and upper edge despite its SFZ tune opcode. Apply the measured
   # compromise correction that brings both played notes inside 10 cents.
   if final=='bebop-tuba' and r.get('articulation')=='sus' and r['root']==29:
    before=float(r.get('tune_cents',0)); r['tune_cents']=round(before-36.3,2)
    tune_fixes.append({'file':r['file'],'physical_root':29,'preserved_source_tune_cents':before,'native_correction_cents':-36.3,'method':'native stable-body calibration across played F0/G0 keys 29 and 31; original opcode remains in source-maps-original.json'})
   if final=='bebop-tuba' and r.get('articulation')=='sus' and r['root'] in (29,62):
    db=14.0 if r['root']==29 else 12.0; r['gain_db']=round(float(r.get('gain_db',0))+db,2)
    level_fixes.append({'file':r['file'],'root':r['root'],'region_gain_db':db,'method':'native vel=116 sustained RMS was an outlier (>10 dB below adjacent register); source performance unchanged, per-region gain only'})
   if final=='bebop-tuba' and r.get('articulation')=='stac' and r['root']==34:
    db=8.0; r['gain_db']=round(float(r.get('gain_db',0))+db,2)
    level_fixes.append({'file':r['file'],'root':r['root'],'articulation':'stac','region_gain_db':db,'method':'native first-100ms RMS on played keys 29/31 was ~7–9 dB below upper staccato notes; source performance/decay unchanged, local region gain only'})
  (target/'samples/source-maps-original.json').write_text(json.dumps(original_maps,ensure_ascii=False,indent=2)+'\n')
  (target/'samples/source-map-exclusions.json').write_text(json.dumps(exclusions,ensure_ascii=False,indent=2)+'\n')
  source_hashes={}
  for original_map in original_maps:
   for region in original_map['map'].get('body',[]):
    rel=region.get('file',''); p=target/'samples'/rel
    if p.is_file() and rel not in source_hashes:
     source_hashes[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
  (target/'samples/source-file-sha256.json').write_text(json.dumps(source_hashes,ensure_ascii=False,indent=2)+'\n')
  loop_report=[]; loop_cache={}
  for r in body:
   art=r.get('articulation')
   sustained=(not r.get('one_shot') and (art in ('sus','vib','buzz') or not art))
   if not sustained:
    r['loop']='none'; continue
   original=r['file']; key=hashlib.sha1(original.encode()).hexdigest()[:12]
   if key not in loop_cache:
    loop_cache[key]=pressure_loop(target/'samples'/original,target/'samples',key)
   file,loop,audit=loop_cache[key]
   if file:
    r['file']=file; r['loop']=loop
   else:
    # For short but clearly pitched played holds, use the project's measured
    # source-modal continuation. It retains the genuine attack and fits only
    # partials measured from this take; its status stays explicit in audit.
    try:
     from build_aria_mechanical import derive_source_body
     src=target/'samples'/original
     derived=target/'samples'/'derived'/f'{key}-measured-body.flac'
     period=8.0 if r['root']<72 else 6.0
     modal_loop,modal_audit=derive_source_body(src,derived,r['root'],period=period,transition_end=.65)
     file=derived.relative_to(target/'samples').as_posix();r['file']=file;r['loop']=modal_loop
     audit={'looped':True,'method':'same-take measured-modal continuation after recorded attack','derived_sha256':hashlib.sha256(derived.read_bytes()).hexdigest(),**modal_audit}
    except Exception as exc:
     r['loop']='none';audit={'looped':False,'reason':'pressure and measured-modal continuation unavailable','continuation_error':str(exc),'source_seconds':sf.info(target/'samples'/original).duration}
   loop_report.append({'source_file':original,'root':r['root'],'articulation':art,**audit})
  (target/'samples/source-loop-audit.json').write_text(json.dumps(loop_report,ensure_ascii=False,indent=2)+'\n')
  (target/'samples/tuning-corrections.json').write_text(json.dumps(tune_fixes,ensure_ascii=False,indent=2)+'\n')
  (target/'samples/native-level-corrections.json').write_text(json.dumps(level_fixes,ensure_ascii=False,indent=2)+'\n')
  (target/'samples/map.json').write_text(json.dumps({'body':body,'tail':[]},ensure_ascii=False,indent=2)+'\n')
  (target/'samples/credits.json').write_text(json.dumps(credits,ensure_ascii=False,indent=2)+'\n')
  title=parts[0][2].get('slug','')
  titles={'bebop-trumpet':'Trumpet','bebop-trombone':'Trombone','bebop-french-horn':'French horn','bebop-tuba':'Tuba','bebop-sax-soprano':'Soprano saxophone','bebop-sax-alto':'Alto saxophone','bebop-sax-tenor':'Tenor saxophone','bebop-sax-bari':'Baritone saxophone','bebop-clarinet-bb':'Clarinet in B♭'}
  family='wind' if final.startswith('bebop-sax') else 'brass'
  roots=sorted({r['root'] for r in body})
  tune_mode='source' if final.startswith('bebop-sax') else 'detect'
  arts=ARTS.get(final,[])
  ap=('sound.articulations('+repr([{'id':a,'name':n,'key':k} for a,n,k in arts])+')\n') if arts else ''
  recipe=f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nMAP=json.loads((Path(__file__).parent/'samples/map.json').read_text())\nsound=Sound(title={titles[final]!r},subtitle='Big band · registrato',tags=[{family!r},'sampled','bebop','recorded'],roots={roots!r},sample_rate=48000)\n{ap}sound.multisample('body',MAP['body'],process={{'max_step_db':9.5,'tune':{tune_mode!r},'ladder':'smooth','align_ms':3.0,'loop':'source','loop_min_s':2.0,'max_seconds':10.0,'preserve_key_ranges':True,'edge_fill':False}})\nsound.performance(humanize={{'cents':0.0,'ms':0.0,'db':0.0}},rr_reset_ms=1500,dynamics_source='cc1',dyn_crossfade=0.0,one_shot=False)\nsound.defaults(amp_attack=20,amp_sustain=1.0,amp_release=300,vel_sens=0.4,rev_mode='Cappella',rev_mix=0.12,dyn_mode='Modulazione',mode='Poli',glide=0,master={MASTER_DB[final]!r})\n'''
  (target/'sound.py').write_text(recipe)
  (target/'figure.svg').write_text(figure_svg(final))
  (target/'ATTRIBUTION.md').write_text('Sources and licenses recorded in samples/credits.json. Raw performance maps and original regions are retained; articulations are separate mapped performances.\n')
  print(cmd('compile',final))
  for attempt in range(4):
   calibrated=calibrate_ladders(target,final)
   if calibrated:
    print(f"calibrated {len(calibrated)} velocity-layer transitions (pass {attempt+1})")
    print(cmd('compile','--force',final))
   p=subprocess.run([str(CLI),'lint',final],cwd=REPO,text=True,capture_output=True)
   lintout=p.stdout.strip(); print(lintout)
   if 'FAIL ladder' not in lintout: break
  if 'FAIL' in lintout:
   print(f"UNRESOLVED_LINT {final}: {lintout.splitlines()[1] if len(lintout.splitlines())>1 else lintout}")
  # These destinations contain only prior Bebop artifacts from this builder.
  for old in (Path('/Users/mario/Libero/sounds')/final,Path('/Users/mario/Libero/banks/bebop')/final):
   if old.exists(): shutil.rmtree(old)
  cmd('save',final)
  cmd('bank','add',final,'bebop')
if __name__=='__main__':
 try: main()
 except Exception as e:
  import traceback; traceback.print_exc(); raise SystemExit(1)
