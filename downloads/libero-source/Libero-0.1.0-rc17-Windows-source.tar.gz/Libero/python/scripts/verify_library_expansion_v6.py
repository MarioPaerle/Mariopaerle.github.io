"""Read-only v6 integration and byte preservation of all 121 previous programmes."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import library
OUT=Path.home()/'Libero/demo/library-expansion-v6'
BASE=json.loads((OUT/'baseline.json').read_text())
NEW={'aria':{'mandolino-dorato','oboe-respiro','fagotto-ombra','flauto-barocco','gong-profondo','dan-tranh-lunare'},
'blue':{'prime-zither-blue','nylon-blue','chemnitzer-blue','banjo-blue','clavinet-blue','blues-formant-blue'},
'green':{'cedro-lead','miele-pulse','ottone-verde','bosco-largo','giada-fase','ambra-fm','canneto-elettrico','prisma-morbido','seta-spettrale','resina-sync','aurora-vetro','muscolo-basso'}}
expected=set(BASE)|set.union(*NEW.values());rows=library.list_sounds();errors=[];protected=[];records=[]
for row in rows:
 p=Path(row['path']);slug=row['slug'];mp=p/'build/manifest.json'
 if not mp.exists():errors.append(slug+': missing manifest');continue
 m=json.loads(mp.read_text());zones=m.get('zones',[])
 errors.extend(slug+': '+e for e in library.validate_bundle(p/'build'))
 tree=library.source_hash(p);fresh=tree==m.get('source_hash');params=m.get('params',{})
 if slug in BASE:
  b=BASE[slug];files={z['file']:hashlib.sha256((p/'build'/z['file']).read_bytes()).hexdigest() for z in zones}
  if m.get('source_hash')!=b['source_hash'] or tree!=b['source_tree_hash'] or params!=b['params'] or files!=b['files'] or row['bank']!=b['bank']:
   errors.append(slug+': previously approved programme changed')
  else:protected.append(slug)
 else:
  if not fresh:errors.append(slug+': stale new sources')
  if params.get('caldi_mode','Spento') not in ['Spento',0] or any(params.get(k,0) for k in ['tape_wow','tape_flutter','glide']):errors.append(slug+': unsolicited modulation/effects')
  arts=m.get('articulations',[]);default=arts[0]['id'] if arts else None
  body=[z for z in zones if z['layer']=='body' and (default is None or z.get('articulation')==default)]
  live=any(k in params for k in ['synth_wave','osc1_wave']) or not zones
  if not body and not live:errors.append(slug+': no default body')
  if body and any(not z.get('loop') for z in body):errors.append(slug+': default body cannot sustain')
 records.append({'slug':slug,'bank':row['bank'],'saved':row['saved'],'source_fresh':fresh,'zones':len(zones),'default_articulation':m.get('articulations',[None])[0] if m.get('articulations') else None})
actual={r['slug'] for r in rows}
if actual!=expected:errors.append('inventory: missing '+str(sorted(expected-actual))+' extra '+str(sorted(actual-expected)))
for bank,slugs in NEW.items():
 for slug in slugs:
  if not any(r['slug']==slug and r['bank']==bank for r in rows):errors.append(slug+': wrong bank')
counts=Counter(r['slug'] for r in rows);errors.extend('duplicate '+k for k,v in counts.items() if v>1)
report={'active_count':len(rows),'saved_count':sum(r['saved'] for r in rows),'new_count':sum(map(len,NEW.values())),'bank_counts':dict(Counter(r['bank'] for r in rows)),'protected_count':len(protected),'protected':protected,'errors':errors,'records':records,'limitations':'Technical source integrity and sustain checks do not certify listener preference or inaudibility of repeated gestures. Licensing eligibility is audited separately.'}
(OUT/'integration.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:report[k] for k in ['active_count','saved_count','new_count','protected_count','bank_counts','errors']},indent=2))
if errors:raise SystemExit(1)
