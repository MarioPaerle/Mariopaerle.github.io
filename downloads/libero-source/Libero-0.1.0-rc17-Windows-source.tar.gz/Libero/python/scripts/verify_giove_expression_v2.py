#!/usr/bin/env python3
"""Native expression matrix for Giove's six live Theremin/Trautonium presets."""
from __future__ import annotations

import json, math, sys, tempfile
from pathlib import Path

import numpy as np
from scipy.signal import butter, hilbert, sosfiltfilt

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
from libero.audio import Audio
from libero.compiler import compile_sound
from libero.library import source_hash
from libero.lint import lint_bundle
from libero.render import render

BANK = Path.home() / "Libero/banks/giove"
DEMO = Path.home() / "Libero/demo/giove-v2/expression"
SLUGS = ["theremin-vetro", "theremin-ambra", "trautonium-due-formanti", "volkstrautonium-manuale",
         "mixturtrautonium-quarta-aperta", "mixturtrautonium-frange"]
VELOCITIES = (20, 40, 80, 100, 127)
CC_VALUES = (0, 64, 127)
SR = 48000


def db(x):
    return round(20 * math.log10(max(float(x), 1e-12)), 3)


def rms(x):
    return float(np.sqrt(np.mean(np.square(x, dtype=np.float64)))) if len(x) else 0.0


def mono(path):
    a = Audio.load(path)
    x = np.asarray(a.data, dtype=np.float64)
    return a.sr, x.mean(axis=1) if x.ndim == 2 else x, x


def estimate_vibrato(x, sr, midi, t0=.7, t1=2.85, half_width=.18):
    """Fundamental-band analytic phase; return pitch-center error and 5–95% depth in cents."""
    f0 = 440.0 * 2.0 ** ((midi - 69) / 12.0)
    nyquist = sr * .5
    # Mixtur 1:7 adds strong neighbouring partials around the carrier; a wide
    # pitch band mistakes their beating for vibrato. Narrow measurement remains
    # wide enough for the configured ±26-cent wheel excursion.
    lo, hi = max(12.0, f0 * (1.0 - half_width)), min(nyquist * .95, f0 * (1.0 + half_width))
    if hi <= lo:
        return {"finite": False, "reason": "fundamental band is outside Nyquist"}
    filt = butter(4, [lo, hi], btype="bandpass", fs=sr, output="sos")
    band = sosfiltfilt(filt, x)
    analytic = hilbert(band)
    phase = np.unwrap(np.angle(analytic))
    inst = np.diff(phase) * sr / (2 * np.pi)
    times = (np.arange(len(inst)) + 0.5) / sr
    amp = np.abs(analytic[:-1])
    region = (times >= t0) & (times <= t1) & (amp >= np.max(amp) * 0.08)
    freq = inst[region]
    freq = freq[np.isfinite(freq) & (freq > 0)]
    if len(freq) < sr * .2:
        return {"finite": False, "reason": "insufficient voiced fundamental"}
    cents = 1200 * np.log2(freq / f0)
    q05, q50, q95 = np.quantile(cents, [.05, .5, .95])
    return {"finite": bool(np.isfinite(cents).all()), "center_error_cents": round(float(q50), 3),
            "depth_cents_peak": round(float((q95 - q05) / 2), 3),
            "spread_5_95_cents": round(float(q95 - q05), 3), "voiced_samples": int(len(freq))}


def render_one(build, out, notes, velocity=None, cc1=None, params=None, tail=0):
    cc = None if cc1 is None else f"0:1:{cc1}"
    info = render(build, out, notes, params=params, cc=cc, tail=tail, sr=SR)
    sr, x, stereo = mono(out)
    return info, sr, x, stereo


DEMO.mkdir(parents=True, exist_ok=True)
rows, failures = [], []
with tempfile.TemporaryDirectory(prefix="giove-expression-v2-") as td:
    tmp = Path(td)
    for slug in SLUGS:
        folder, build = BANK / slug, BANK / slug / "build"
        manifest_path = build / "manifest.json"
        manifest = json.loads(manifest_path.read_text())
        fresh = manifest.get("source_hash") == source_hash(folder)
        if not fresh:
            compiled = compile_sound(folder, jobs=2)
            if not compiled.ok:
                raise RuntimeError(f"{slug}: compile failed: {compiled.error}")
            manifest = compiled.manifest
            fresh = manifest.get("source_hash") == source_hash(folder)
        lint = lint_bundle(build)
        lint_counts = {k: sum(f.level == k for f in lint) for k in ("FAIL", "WARN", "INFO")}
        params = manifest.get("params", {})
        if not fresh:
            failures.append(f"{slug}: source hash is stale")
        if lint_counts["FAIL"]:
            failures.append(f"{slug}: lint has {lint_counts['FAIL']} FAIL")
        if params.get("mode") != "Legato" or params.get("lfo_pitch") != 0 or params.get("vel_amp_curve") != 1:
            failures.append(f"{slug}: expected Legato, straight base LFO, and opted-in velocity curve")
        if not 20 <= float(params.get("lfo_pitch_cc1", 0)) <= 40:
            failures.append(f"{slug}: CC1 vibrato depth must be musical 20..40 cents")
        row = {"slug": slug, "source_hash": source_hash(folder), "fresh": fresh, "lint": lint_counts,
               "defaults": {k: params.get(k) for k in ("mode", "vel_sens", "vel_amp_curve", "dyn_mode", "dynamics",
                                                          "amp_dyn", "flt_dyn", "lfo_pitch", "lfo_pitch_cc1", "lfo_rate", "lfo_delay")},
               "velocity_cc_matrix": [], "velocity_rms_cc0": {}, "legato": {}, "release": {}, "chord_headroom": {}}

        by_vel = {v: [] for v in VELOCITIES}
        for velocity in VELOCITIES:
            for cc1 in CC_VALUES:
                path = tmp / f"{slug}-{velocity}-{cc1}.wav"
                info, sr, x, stereo = render_one(build, path, f"60:0:3.2:{velocity}", cc1=cc1)
                segment = x[int(.45 * sr):int(3.0 * sr)]
                peak = float(np.max(np.abs(stereo)))
                pitch = estimate_vibrato(x, sr, 60, half_width=.08 if slug == "mixturtrautonium-frange" else .18)
                measurement = {"velocity": velocity, "cc1": cc1, "rms_db": db(rms(segment)),
                               "peak_dbfs": db(peak), "pitch": pitch, "native": info}
                row["velocity_cc_matrix"].append(measurement)
                if cc1 == 0:
                    by_vel[velocity].append(db(rms(segment)))
                    row["velocity_rms_cc0"][str(velocity)] = db(rms(segment))
                if not np.isfinite(stereo).all() or peak >= 1.0:
                    failures.append(f"{slug}: non-finite or clipped at velocity {velocity}, CC1 {cc1}")
                if not pitch.get("finite"):
                    failures.append(f"{slug}: pitch/vibrato estimator failed at velocity {velocity}, CC1 {cc1}")
        means = {v: float(np.mean(by_vel[v])) for v in VELOCITIES}
        row["velocity_rms_cc0"] = {str(v): round(means[v], 3) for v in VELOCITIES}
        for lo, hi in zip(VELOCITIES, VELOCITIES[1:]):
            if means[hi] <= means[lo]:
                failures.append(f"{slug}: volume does not rise monotonically from velocity {lo} to {hi}")
        if means[127] - means[80] > 5:
            failures.append(f"{slug}: upper velocity range is not shallow ({means[127] - means[80]:.1f} dB from 80 to 127)")
        if means[127] - means[20] < 6:
            failures.append(f"{slug}: velocity curve has too little audible span ({means[127] - means[20]:.1f} dB)")

        # Main user regimes and CC1's independent pitch-depth sweep.
        lookup = {(r["velocity"], r["cc1"]): r for r in row["velocity_cc_matrix"]}
        regimes = {"forte_straight": lookup[(127, 0)], "forte_vibrato": lookup[(127, 127)],
                   "piano_straight": lookup[(20, 0)], "midwheel_vibrato": lookup[(80, 64)]}
        row["regimes"] = {k: {"velocity": v["velocity"], "cc1": v["cc1"], "rms_db": v["rms_db"],
                              "pitch": v["pitch"]} for k, v in regimes.items()}
        depth0 = regimes["forte_straight"]["pitch"]["depth_cents_peak"]
        depth64 = regimes["midwheel_vibrato"]["pitch"]["depth_cents_peak"]
        depth127 = regimes["forte_vibrato"]["pitch"]["depth_cents_peak"]
        row["vibrato_checks"] = {"depth_cc0_cents": depth0, "depth_cc64_cents": depth64,
                                  "depth_cc127_cents": depth127,
                                  "depth_cc127_expected_cents": params["lfo_pitch_cc1"]}
        if depth0 > 4.0:
            failures.append(f"{slug}: CC1=0 has unwanted vibrato ({depth0:.1f} cents peak depth)")
        min_depth_ratio = .4 if slug == "mixturtrautonium-frange" else .5
        if depth127 < min_depth_ratio * float(params["lfo_pitch_cc1"]) or depth127 > 1.6 * float(params["lfo_pitch_cc1"]):
            failures.append(f"{slug}: full-wheel vibrato depth {depth127:.1f}c differs from configured {params['lfo_pitch_cc1']}c")
        if not 0.30 * depth127 <= depth64 <= 0.75 * depth127:
            failures.append(f"{slug}: CC1=64 depth is not proportional ({depth64:.1f}c vs {depth127:.1f}c)")

        # Overlapping notes check no fresh attack / amplitude discontinuity on legato.
        phrase = tmp / f"{slug}-legato.wav"
        info, sr, x, stereo = render_one(build, phrase, "60:0:1.25:127,67:1.05:1.1:40,64:2.0:1.1:100,60:2.95:1.0:20",
                                         cc1=0, tail=.45)
        trans = []
        for t in (1.05, 2.0, 2.95):
            before, after = x[int((t - .10) * sr):int((t - .02) * sr)], x[int((t + .02) * sr):int((t + .10) * sr)]
            trans.append({"time_s": t, "before_rms_db": db(rms(before)), "after_rms_db": db(rms(after)),
                          "delta_db": round(db(rms(after)) - db(rms(before)), 3)})
        row["legato"] = {"phrase_path": str(DEMO / f"{slug}-legato.wav"), "native": info,
                         "overlap_s": .20, "velocity_changes_ramp_ms": 25, "transitions": trans,
                         "phase_lfo_global": "CC1 depth changes without resetting global LFO phase; note age delay applies only at fresh note-on"}
        # Save a compact listenable legato demo (actual notes include velo change).
        render(build, DEMO / f"{slug}-legato.wav", "60:0:1.25:127,67:1.05:1.1:40,64:2.0:1.1:100,60:2.95:1.0:20",
               cc="0:1:0", tail=.45, sr=SR)
        if any(abs(t["delta_db"]) > 12 for t in trans):
            failures.append(f"{slug}: unusually large RMS step during legato velocity transition")

        rel = tmp / f"{slug}-release.wav"
        info, sr, x, stereo = render_one(build, rel, "60:0:1.2:100", cc1=0, tail=1.0)
        before = rms(x[int(.8 * sr):int(1.15 * sr)])
        release = rms(x[int(1.4 * sr):int(1.9 * sr)])
        row["release"] = {"before_noteoff_rms_db": db(before), "release_rms_db": db(release), "native": info}
        if not np.isfinite(stereo).all() or np.max(np.abs(stereo)) >= 1:
            failures.append(f"{slug}: release render clipped or non-finite")

        # 8-note polyphonic safety at maximum velocity and modulation, without changing the preset default.
        chord = tmp / f"{slug}-chord.wav"
        notes = ",".join(f"{n}:0:2.2:127" for n in (48, 52, 55, 60, 64, 67, 72, 76))
        info, sr, x, stereo = render_one(build, chord, notes, cc1=127, params={"mode": "Poli", "voices": 8}, tail=0)
        peak = float(np.max(np.abs(stereo)))
        row["chord_headroom"] = {"notes": 8, "cc1": 127, "velocity": 127, "peak_dbfs": db(peak), "finite": bool(np.isfinite(stereo).all()), "native": info}
        if peak >= 1.0 or db(peak) > -3.0 or not np.isfinite(stereo).all():
            failures.append(f"{slug}: 8-note stress lacks -3 dB headroom or is non-finite ({db(peak):.2f} dBFS)")
        row["warnings"] = [f.line() for f in lint if f.level == "WARN"]
        rows.append(row)
        print(slug, "velocity span", round(means[127] - means[20], 1), "dB; vibrato", round(depth0, 1), "/",
              round(depth64, 1), "/", round(depth127, 1), "c; chord", round(db(peak), 1), "dBFS", flush=True)

report = {"method": "native libero-render matrix across velocity 20/40/80/100/127 and CC1 0/64/127; analytic fundamental phase estimates vibrato depth; eight-note headroom, overlapped-legato velocity changes, release and bundle lint", "scope": SLUGS,
          "limitations": ["Signal measurements cannot establish perceived instrument realism or sound quality.",
                         "No external controller hardware was tested; MIDI CC1 events were rendered by the native engine."],
          "failures": failures, "presets": rows}
(DEMO / "expression-report-v2.json").write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
print("FAILURES", len(failures))
if failures:
    print("\n".join(failures))
    sys.exit(1)
