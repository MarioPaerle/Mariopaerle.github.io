"""Render the pianoforte demo through libero-render: ~45 s of arpeggiated harmony, a singing
melody, a pp-to-ff swell on repeated chords and the extremes of the keyboard.

    uv --directory python run python scripts/demo_pianoforte.py [slug] [out.wav]
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

from libero import library
from libero.render import render

BEAT = 60 / 72


def piece() -> list[tuple[int, float, float, int]]:
    notes = []
    t = 0.0
    # (bass, chord tones for the arpeggio, melody notes as (pitch, beats))
    bars = [
        (45, [57, 60, 64, 69], [(76, 2), (74, 1), (72, 1)]),        # Am
        (41, [53, 57, 60, 65], [(72, 1.5), (71, 0.5), (69, 2)]),    # F
        (48, [55, 60, 64, 67], [(67, 1), (72, 1), (76, 2)]),        # C
        (43, [55, 59, 62, 67], [(74, 3), (71, 1)]),                 # G
        (45, [57, 60, 64, 69], [(72, 2), (76, 1), (81, 1)]),        # Am
        (38, [50, 57, 62, 65], [(81, 1.5), (79, 0.5), (77, 2)]),    # Dm
        (40, [52, 56, 59, 64], [(76, 2), (74, 1), (71, 1)]),        # E
        (33, [45, 52, 57, 60], [(69, 4)]),                          # Am (low)
    ]
    for i, (bass, arp, mel) in enumerate(bars):
        swell = 0.55 + 0.35 * (1 - abs(i - 4.5) / 4.5)  # louder towards the middle
        notes.append((bass, t, 4 * BEAT, int(70 * swell + 20)))
        notes.append((bass - 12, t, 4 * BEAT, int(55 * swell + 15)))
        for k in range(8):
            p = arp[[0, 1, 2, 3, 2, 1, 2, 3][k]]
            notes.append((p, t + k * BEAT / 2, 4 * BEAT - k * BEAT / 2, int(38 + 30 * swell + (6 if k % 4 == 0 else 0))))
        mt = t
        for p, beats in mel:
            notes.append((p, mt, beats * BEAT * 0.98, int(60 + 45 * swell)))
            mt += beats * BEAT
        t += 4 * BEAT
    # repeated chord, pp → ff: the dynamics layers one after another
    chord = [57, 60, 64, 69]
    for k, v in enumerate((18, 32, 48, 64, 80, 96, 112, 127)):
        for p in chord:
            notes.append((p, t + k * 0.55, 0.5, v))
    t += 8 * 0.55 + 0.4
    # the extremes: a low A0 and a high cluster that rings out
    notes.append((21, t, 3.5, 110))
    notes.append((33, t, 3.5, 90))
    for k, p in enumerate((96, 100, 103, 108)):
        notes.append((p, t + 0.8 + k * 0.18, 2.5, 70))
    return notes


def main() -> int:
    slug = sys.argv[1] if len(sys.argv) > 1 else "pianoforte"
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else library.home() / "demo" / f"{slug}.wav"
    out.parent.mkdir(parents=True, exist_ok=True)
    info = render(library.find_sound(slug), out, piece(), tail=4.0, timeout=900)
    print(info)
    if shutil.which("afconvert"):
        m4a = out.with_suffix(".m4a")
        subprocess.run(["afconvert", "-f", "m4af", "-d", "aac", "-b", "256000", str(out), str(m4a)], check=True)
        print(m4a)
    return 0


if __name__ == "__main__":
    sys.exit(main())
