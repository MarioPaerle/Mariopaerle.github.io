"""Native musical auditions; matching gain only in the exported listening files."""
from pathlib import Path
import json, os, sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, render, library
OUT=Path.home()/'Libero/demo/library-refresh-v5';OUT.mkdir(parents=True,exist_ok=True)
os.environ['LIBERO_RENDER']=str(ROOT/'build/plugin/libero_render_artefacts/Release/libero-render')
SETS={
 'aria-otto-voci': [('marimba-radice',48),('vibrafono-caldo',60),('handchimes-aria',60),('tubolari-risonanti',60),('arpa-folk',48),('salterio-arco',72),('ocarina-terra',69),('armonica-vissuta',60)],
 'blue-dodici-voci': [('rhodes-stage77',60),('wurli-ep200',60),('pianet-t',60),('organo-blues',60),('positivo-rinascimento',60),('unitra-b11',60),('mantice-blue',60),('vetro-blue',75),('corde-blue',48),('fosforo-tasti',60),('indaco-ance',60),('rame-notturno',60)]}

def segment(slug, key, name, params=None):
    p=library.find_sound(slug)
    notes=[(key,0,.24,65),(key,.45,.25,110),(key+3,.95,.5,95),
           (key+7,1.65,.65,98),(key+10,2.45,.45,85),(key,3.15,2.7,95)]
    f=OUT/(name+'-native.wav');render.render(p,f,notes,params,tail=1.35)
    a=Audio.load(f);x=a.data.astype(float)
    if x.ndim==1:x=np.column_stack([x,x])
    if not np.all(np.isfinite(x)) or a.peak_db>=-.2:raise RuntimeError(str(f)+' clips')
    # Useful comparisons keep the real source dynamics and timbre; programme
    # levels stay untouched. The 9dB bound avoids amplifying near-silent samples.
    gain=min(9,max(-9,-25-a.rms_db));gain=min(gain,-3-a.peak_db)
    x*=10**(gain/20)
    Audio(x,a.sr).save(OUT/(name+'.wav'))
    return x,{'slug':slug,'title':json.loads((p/'build/manifest.json').read_text())['title'],
              'key':key,'notes':notes,'params':params,'native_peak_db':a.peak_db,
              'native_rms_db':a.rms_db,'demo_gain_db':gain,'file':str(OUT/(name+'.wav'))}

def collection(name, voices):
    tracks=[];index=[];cursor=0
    for slug,key in voices:
        x,row=segment(slug,key,slug+'-ascolto');row.update(start_s=cursor,end_s=cursor+len(x)/48000)
        tracks.extend([x,np.zeros((16800,2))]);index.append(row);cursor+=len(x)/48000+.35
    Audio(np.concatenate(tracks),48000).save(OUT/(name+'.wav'))
    (OUT/(name+'-index.json')).write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
    print(name,round(cursor,2),flush=True)
    return index

if __name__=='__main__':
    sets={name:collection(name,voices) for name,voices in SETS.items()}
    modes=['Spento','Velluto','Presenza','Intimo','Blu','Soffio'];tracks=[];index=[];cursor=0
    for mode in modes:
        x,row=segment('pianet-t',60,'caldi-'+mode.lower(),
                      {'caldi_mode':mode,'caldi_amount':.75,'caldi_grain':.35,'caldi_motion':.35})
        row.update(start_s=cursor,end_s=cursor+len(x)/48000);index.append(row)
        tracks.extend([x,np.zeros((16800,2))]);cursor+=len(x)/48000+.35
    Audio(np.concatenate(tracks),48000).save(OUT/'caldi-sei-caratteri.wav')
    (OUT/'caldi-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
    lines=['# Ascolti Libero\n','Renderer nativo; gain confrontato solo negli ascolti. I preset e i campioni mantengono i loro livelli.\n']
    for name,rows in sets.items():
        lines+=['\n## '+name+'\n']+[f'- {r["start_s"]:.1f}s — {r["title"]} (base MIDI {r["key"]})' for r in rows]
    lines+=['\n## Caldi\n','Pianet T: stessa frase, prima Spento, poi Velluto, Presenza, Intimo, Blu, Soffio. Quantità 75%, grana/movimento 35%, EQ macro al centro. Il confronto non premia semplicemente il volume.']
    (OUT/'ASCOLTO.md').write_text('\n'.join(lines)+'\n')
