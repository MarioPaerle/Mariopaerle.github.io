"""Render a short showcase of the physical-modelling toolkit: wav + m4a + spectrogram PNG per sound.

    cd python && uv run python scripts/physics_showcase.py [outdir]

Default outdir ~/Libero/demo/physics. Notes are 1-4 s, 16-bit, so the set stays small.
"""

from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

from libero import Audio, analysis, dsp
from libero import physics as ph
from libero.physics import presets as P


def main(out: Path):
    out.mkdir(parents=True, exist_ok=True)
    items: list[tuple[str, Audio]] = []

    def add(name, a):
        items.append((name, a))

    t0 = time.time()
    for n, nm in ((45, "A2"), (64, "E4")):
        add(f"guitar_classical_{nm}", P.guitar("classical").render(dsp.midi_to_freq(n), 0.7, 3.0, seed=1))
    add("guitar_steel_E3", P.guitar("steel").render(dsp.midi_to_freq(52), 0.8, 3.0, seed=2))
    for n, v in ((36, 0.7), (60, 0.25), (60, 0.9), (84, 0.7), (96, 0.7)):
        add(f"piano_{dsp.note_name(n)}_v{int(v * 100)}", P.piano().render(dsp.midi_to_freq(n), v, 4.0 if n < 90 else 2.5, seed=3))
    add("cello_C3", P.cello().render(dsp.midi_to_freq(48), 0.7, 3.0, seed=4))
    add("cello_G2_soft", P.cello().render(dsp.midi_to_freq(43), 0.3, 3.0, seed=4))
    add("violin_A4", P.violin().render(dsp.midi_to_freq(69), 0.7, 3.0, seed=5))
    add("clarinet_D4", P.clarinet().render(dsp.midi_to_freq(62), 0.6, 2.5, seed=6))
    add("oboe_A4", P.oboe().render(dsp.midi_to_freq(69), 0.6, 2.5, seed=7))
    add("sax_E3", P.saxophone().render(dsp.midi_to_freq(52), 0.6, 2.5, seed=8))
    add("flute_C5", P.flute().render(dsp.midi_to_freq(72), 0.6, 2.5, seed=9))
    add("trumpet_Bb4_pp", P.trumpet().render(dsp.midi_to_freq(70), 0.2, 2.0, seed=10))
    add("trumpet_Bb4_ff", P.trumpet().render(dsp.midi_to_freq(70), 0.95, 2.0, seed=10))
    add("trombone_Bb2", P.trombone().render(dsp.midi_to_freq(46), 0.7, 2.0, seed=11))
    add("horn_F3", P.horn().render(dsp.midi_to_freq(53), 0.6, 2.5, seed=12))
    add("marimba_C4", P.marimba().render(dsp.midi_to_freq(60), 0.7, 2.0, seed=13))
    add("vibraphone_F4", P.vibraphone().render(dsp.midi_to_freq(65), 0.6, 3.5, seed=14))
    add("bell_church_C4", P.bell("church").render(dsp.midi_to_freq(60), 0.7, 5.0, seed=15))
    add("glass_bowl_A5", P.glass().render(dsp.midi_to_freq(81), 0.5, 4.0, seed=16))
    add("timpani_D3", P.timpani().render(dsp.midi_to_freq(50), 0.8, 3.0, seed=17))
    add("fd_plate_gong", ph.fd_plate(140, 3.0, model="plate", aspect=1.25, t60=3.5, strike=(0.3, 0.4), hardness=0.4))
    add("fd_membrane_drum", ph.fd_plate(110, 2.0, model="membrane", aspect=1.0, t60=1.2, strike=(0.5, 0.5), hardness=0.5))
    dry = P.guitar("classical").render(dsp.midi_to_freq(57), 0.7, 1.6, seed=1).pad(after=0.2)
    for nm in ("studio", "hall", "cathedral"):
        ir = ph.room_preset(nm)
        add(f"room_{nm}_guitar", dry.convolve(ir, mix=0.35).normalize(-6))
    add("spring_reverb_guitar", dry.convolve(ph.spring_ir(3.0), mix=0.35).normalize(-6))
    add("plate_reverb_guitar", dry.convolve(ph.plate_ir(2.5), mix=0.35).normalize(-6))
    print(f"rendered {len(items)} sounds in {time.time() - t0:.1f} s")
    for name, a in items:
        wav = out / f"{name}.wav"
        a.save(wav, subtype="PCM_16")
        m4a = out / f"{name}.m4a"
        subprocess.run(["afconvert", "-f", "m4af", "-d", "aac", "-b", "256000", str(wav), str(m4a)], check=False)
        png = analysis.spectrogram(a, 0.0, min(a.duration, 4.0), title=name, small=True)
        (out / f"{name}.png").write_bytes(png)
        ft = analysis.features(a)
        print(f"{name:26s} {a.duration:4.1f}s peak {a.peak_db:5.1f} f0 {ft.get('f0_hz')} centroid {ft.get('centroid_hz')}")


if __name__ == "__main__":
    main(Path(sys.argv[1]).expanduser() if len(sys.argv) > 1 else Path("~/Libero/demo/physics").expanduser())
