"""Sixty-second native holds at the lowest/highest playable keys."""
import json
import concurrent.futures
import numpy as np
from libero import load,dsp
from libero.render import render
from build_cielo_infinite import STAGE,REPORT,SR

def check(p):
    m=json.loads((p/'build/manifest.json').read_text());lo=min(z['lo'] for z in m['zones']);hi=max(z['hi'] for z in m['zones']);result=[]
    for label,key in [('low',lo),('high',hi)]:
        path=p/'build'/f'extreme-{label}-60s.wav';render(p,path,[(key,0,60,106)],params={'artic':0,'rev_mix':0},tail=2)
        a=load(path);late=a.data[55*SR:58*SR];released=a.data[61*SR:62*SR]
        result.append({'key':key,'late_rms_db':round(float(dsp.db(np.sqrt(np.mean(late*late)))),2),'released_rms_db':round(float(dsp.db(np.sqrt(np.mean(released*released)))),2),'peak_db':round(a.peak_db,2)})
    print(p.name,result,flush=True);return p.name,result

if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:r=dict(pool.map(check,sorted(p for p in STAGE.iterdir() if (p/'sound.py').exists())))
    (REPORT/'extremes.json').write_text(json.dumps(r,indent=2));assert all(x['late_rms_db']>-65 and x['released_rms_db']<-65 and x['peak_db']<-.5 for rs in r.values() for x in rs)
