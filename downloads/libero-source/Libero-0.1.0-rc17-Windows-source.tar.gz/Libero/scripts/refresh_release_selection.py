#!/usr/bin/env python3
"""Refresh the reviewed release selection without including unreviewed working sounds."""
import hashlib,json,shutil,subprocess,sys,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python'))
from libero import library,licenses
BASE=Path('/Users/mario/Libero/releases/mellotron-hold-2026-10-07/Packs/Single Packs and terms')
OUT=Path('/Users/mario/Libero/releases/final-refresh-2026-10-07')
STAGE=OUT/'staging-home/banks'
PACKS=OUT/'Packs';SINGLE=PACKS/'Single Packs and terms'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4194304),b''):h.update(b)
 return h.hexdigest()
def write(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def copy_sound(src,dst):
 if dst.exists():shutil.rmtree(dst)
 dst.mkdir(parents=True)
 for p in library._pack_sound_files(src):
  d=dst/p.relative_to(src);d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
if OUT.exists() and not STAGE.exists():raise SystemExit('Unrecognized output directory')
SINGLE.mkdir(parents=True,exist_ok=True)
cat=json.loads((BASE/'catalog.json').read_text())
for pack in cat['packs']:
 p=BASE/pack['file'];assert sha(p)==pack['sha256']
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
  z.extractall(STAGE)
for bank,slug in [('chitarre','chitarra-classica-libero'),('chitarre','chitarra-classica-accordi-libero'),('chitarre','chitarra-elettrica-crunch'),('flauti','odisseo-aulos-bright')]:
 src=Path('/Users/mario/Libero/banks')/bank/slug
 credits=licenses.read_credits(src) or json.loads((src/'build/manifest.json').read_text()).get('credits',[])
 assert licenses.bundle_license(credits)[1] in ('cc0','by')
 assert not library.validate_bundle(src/'build')
 copy_sound(src,STAGE/bank/slug)
 target=STAGE/bank/slug
 (target/'samples').mkdir(exist_ok=True)
 write(target/'samples/credits.json',credits)
 if slug=='odisseo-aulos-bright':
  old=STAGE/bank/'odisseo-aulos/samples/licenses'
  if old.exists():shutil.copytree(old,target/'samples/licenses',dirs_exist_ok=True)
 print('Refreshed',slug,flush=True)
# Keep all inputs needed to rebuild the new electric instrument.
crunch=STAGE/'chitarre/chitarra-elettrica-crunch';live=Path('/Users/mario/Libero/banks/chitarre/chitarra-elettrica-crunch')
for name in ['amp.py','prep.py','ir']:
 p=live/name
 if p.is_dir():shutil.copytree(p,crunch/name,dirs_exist_ok=True)
 elif p.exists():shutil.copy2(p,crunch/name)
legal=crunch/'samples/licenses';legal.mkdir(exist_ok=True)
manual=Path('/tmp/libero-emerald/Emerald Pack 1.0/Jesters Emerald Pack Handbook.pdf')
assert sha(live/'ir/3_Wasabi_Warrior_48.wav')==sha(Path('/tmp/libero-emerald/Emerald Pack 1.0/Impulses/48kHz/3_Wasabi_Warrior_48.wav'))
shutil.copy2(manual,legal/manual.name)
write(legal/'source-verification.json',{'ir_sha256':sha(live/'ir/3_Wasabi_Warrior_48.wav'),'publisher_archive':'https://www.jester-dyne-productions.com/content/files/2023/04/Emerald-Pack-1.0.zip','publisher_archive_sha256':sha('/tmp/libero-emerald.zip'),'license':'CC0 1.0, publisher handbook','instrument_source':'https://github.com/sfzinstruments/karoryfer.emilyguitar'})
# The already-reviewed steel acoustic source must ring out rather than auto-loop.
steel=STAGE/'chitarre/chitarra-acustica-libero';p=steel/'sound.py';p.write_text(p.read_text().replace("'loop': 'auto'","'loop': 'none'").replace('Chitarra acustica steel-string · Libero','Steel-String Acoustic Guitar').replace('Dita · steel-string','Fingerstyle · steel-string').replace('Plettro · steel-string','Pick · steel-string'))
work=OUT/'compiler-work/chitarra-acustica-libero'
shutil.copytree(Path('/Users/mario/Libero/sketches/chitarra-acustica-libero'),work,dirs_exist_ok=True)
shutil.copy2(steel/'sound.py',work/'sound.py')
subprocess.run([str(ROOT/'python/.venv/bin/python'),'-m','libero.compiler',str(work),'--jobs','4'],cwd=ROOT/'python',check=True)
shutil.rmtree(steel/'build');shutil.copytree(work/'build',steel/'build')
terms=(ROOT/'docs/release/sound-data-terms.md').read_bytes()
practical={'chitarra-classica-accordi-libero':'Key = chord root · select Major or Minor','batteria-jazz':'C3 kick · D3 snare · A♯3 pedal hi-hat · C♯4 ride'}
for pack in cat['packs']:
 bank=pack['bank'];folder=STAGE/bank;programmes=[]
 for dst in sorted(folder.iterdir()):
  if not (dst/'build/manifest.json').is_file():continue
  slug=dst.name;assert 'mellotron' not in slug and slug!='drum-phonk-mog'
  for name in ['manifest.json','info.json']:
   p=dst/'build'/name
   if p.exists():
    m=json.loads(p.read_text());m['subtitle']=practical.get(slug,'');m['description']='';write(p,m)
  m=json.loads((dst/'build/manifest.json').read_text());(dst/'SOUND-DATA-TERMS.md').write_bytes(terms)
  assert not library.validate_bundle(dst/'build'),slug
  programmes.append({'slug':slug,'title':m['title'],'source_hash':m['source_hash'],'license_class':licenses.bundle_license(licenses.read_credits(dst) or m['credits'])[1],'runtime_files':{p.relative_to(dst/'build').as_posix():sha(p) for p in sorted((dst/'build').rglob('*')) if p.is_file()}})
 p=folder/'bank.json';m=json.loads(p.read_text());m.update(version='0.1.5',subtitle='',description='',updated=datetime.now(timezone.utc).isoformat());m.pop('programmes',None);write(p,m)
 archive=SINGLE/f'{bank}-0.1.5.liberobank'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(STAGE).as_posix())
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 pack.update(file=archive.name,presets=len(programmes),programmes=programmes,sha256=sha(archive),bytes=archive.stat().st_size)
 print('Packed',archive.name,len(programmes),flush=True)
cat.update(version='0.1.5',preset_count=sum(p['presets'] for p in cat['packs']),compressed_bytes=sum(p['bytes'] for p in cat['packs']),created_utc=datetime.now(timezone.utc).isoformat(),status='Testing release: CC0/CC BY core and Blue GPL instrument with editable source and music-use clarification.',excluded='Authentic Mellotron and other working-library presets outside the reviewed selection.')
write(SINGLE/'catalog.json',cat);(SINGLE/'SOUND-DATA-TERMS.md').write_bytes(terms)
(SINGLE/'README.txt').write_text(f"Libero Base Bundle 0.1.5\n\n{cat['preset_count']} presets in {len(cat['packs'])} collections.\nDownload both bundle ZIP parts and select them together in Libero Library > Import, or import individual .liberobank files.\nAll collections are version 0.1.5. Review the update summary and back up personal edits.\nUpdated nylon/chord guitar natural decays, finite acoustic guitar decay, added Crunch Electric Guitar and Bright Aulos.\nAuthentic Mellotron is excluded pending rights verification.\nCC0/CC BY recording licenses are included per preset. Five Strings retains GPLv3+ data terms with editable source and the author's music-use clarification.\nRecordings and demo music have independent licenses. Playback requires no Python or agent.\nContact: paerle.music@gmail.com\n")
(SINGLE/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(SINGLE.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
parts=[[],[]];sizes=[0,0]
for pack in sorted(cat['packs'],key=lambda x:-x['bytes']):
 i=0 if sizes[0]<=sizes[1] else 1;parts[i].append(pack);sizes[i]+=pack['bytes']
for i,group in enumerate(parts,1):
 path=PACKS/f'Libero-Base-Bundle-0.1.5-Part-{i}.zip'
 with zipfile.ZipFile(path,'w',zipfile.ZIP_STORED,allowZip64=True) as z:
  for p in group:z.write(SINGLE/p['file'],'Banks/'+p['file'])
  for n in ['catalog.json','SOUND-DATA-TERMS.md','README.txt','SHA256SUMS']:z.write(SINGLE/n,'Banks/'+n)
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
(PACKS/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(PACKS.glob('*.zip'))))
print('Ready',cat['preset_count'],sizes,flush=True)
