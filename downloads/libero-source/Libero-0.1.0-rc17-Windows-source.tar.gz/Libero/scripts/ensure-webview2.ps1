$ErrorActionPreference = 'Stop'
# Microsoft's Evergreen deployment contract: https://learn.microsoft.com/microsoft-edge/webview2/concepts/distribution
function RuntimeVersion {
    $id = '{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
    foreach ($key in @("HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\$id", "HKCU:\Software\Microsoft\EdgeUpdate\Clients\$id")) {
        $value = (Get-ItemProperty $key -Name pv -ErrorAction SilentlyContinue).pv
        if ($value -and [version]$value -gt [version]'0.0.0.0') { return $value }
    }
    return $null
}
$version = RuntimeVersion
if ($version) { Write-Host "WebView2 Runtime: $version"; return }
$setup = Join-Path $env:TEMP 'Libero-WebView2Setup.exe'
Invoke-WebRequest 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile $setup
$signature = Get-AuthenticodeSignature $setup
if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Microsoft Corporation') {
    throw 'The WebView2 bootstrapper has no valid Microsoft signature'
}
$result = Start-Process $setup -ArgumentList '/silent','/install' -Wait -PassThru
if ($result.ExitCode -ne 0 -or !(RuntimeVersion)) { throw "WebView2 installation failed: $($result.ExitCode)" }
Remove-Item $setup
Write-Host "WebView2 Runtime installed: $(RuntimeVersion)"
