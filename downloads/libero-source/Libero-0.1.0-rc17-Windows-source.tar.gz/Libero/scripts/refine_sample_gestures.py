#!/usr/bin/env python3
"""Plan or apply the October 2026 attack/decay corrections without rewriting PCM."""
import argparse
import json
import shutil
from pathlib import Path

# Milliseconds to settle, held amplitude, decay curve. Wind and bowed sources
# retain a stronger held body; struck instruments leave room for the next attack.
ARIA = {
    "piano-giocattolo": (1050, .20, -.45),
    "carillon-particolare": (1400, .22, -.40),
    "xilofono-vivo": (900, .16, -.25),
    "marimba-radice": (950, .20, -.40),
    "vibrafono-caldo": (1900, .28, -.35),
    "handchimes-aria": (1700, .24, -.40),
    "tubolari-risonanti": (2100, .26, -.40),
    "kalimba-legno": (1050, .18, -.45),
    "piano-preparato": (1700, .24, -.40),
    "arpa-folk": (1500, .22, -.35),
    "dan-tranh-lunare": (1200, .20, -.40),
    "mandolino-dorato": (1000, .18, -.20),
    "mandolino-dorato-libero": (1000, .18, -.20),
    "gong-profondo": (3500, .30, -.30),
    "armonica-vissuta": (650, .72, -.20),
    "flauto-barocco": (800, .76, -.20),
    "ocarina-terra": (700, .76, -.20),
    "salterio-arco": (1100, .72, -.20),
    "fagotto-ombra": (900, .76, -.20),
    "oboe-respiro": (900, .76, -.20),
    "saw-rame": (1000, .80, -.20),
}

def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--home", type=Path, default=Path.home() / "Libero")
    cli.add_argument("--apply", action="store_true")
    cli.add_argument("--backup", type=Path)
    args = cli.parse_args()
    if args.apply and (not args.backup or args.backup.exists()):
        cli.error("--apply requires a new --backup directory")
    changes = []
    paths = list((args.home / "banks").glob("*/*/build/manifest.json")) + list((args.home / "sounds").glob("*/build/manifest.json"))
    for path in sorted(paths):
        manifest = json.loads(path.read_text(encoding="utf-8"))
        slug, bank = path.parent.parent.name, path.parent.parent.parent.name
        params = {}
        onset = None
        if bank == "aria" and slug in ARIA:
            decay, sustain, curve = ARIA[slug]
            params = dict(amp_decay=decay, amp_sustain=sustain, amp_curve=curve)
        if "808" in manifest.get("tags", []) and (bank in ("bassi", "mog") or path.is_relative_to(args.home / "sounds")):
            # The first 200 ms contain the octave drop. Start in the pitched body;
            # native playback fades the cut by 1 ms and the amp rises over 5 ms.
            onset, params = 200, dict(amp_attack=5)
        if not params:
            continue
        folder = path.parent.parent
        recipe = folder / "sound.py"
        if not recipe.is_file():
            raise RuntimeError(f"Missing recipe: {folder}")
        changes.append(dict(folder=str(folder), title=manifest["title"],
                            previous={k: manifest.get("params", {}).get(k) for k in params},
                            params=params, onset_ms=onset))
        if not args.apply:
            continue
        for item in (path, recipe, path.parent / "info.json"):
            if item.is_file():
                target = args.backup / item.relative_to(args.home)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target)
        manifest.setdefault("params", {}).update(params)
        if onset is not None:
            manifest["onset_ms"] = onset
            for zone in manifest["zones"]:
                if zone.get("layer") == "body": zone["onset_ms"] = onset
        text = recipe.read_text(encoding="utf-8")
        marker = "\n# Playback gesture correction, October 2026.\n"
        text = text.split(marker)[0].rstrip() + marker
        if onset is not None:
            text += f"sound.performance(onset_ms={onset})\n"
        text += "sound.defaults(" + ", ".join(f"{k}={v!r}" for k, v in params.items()) + ")\n"
        recipe.write_text(text, encoding="utf-8")
        path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        info_path = path.parent / "info.json"
        if info_path.is_file():
            info = json.loads(info_path.read_text(encoding="utf-8"))
            info.setdefault("params", {}).update(params)
            info_path.write_text(json.dumps(info, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    report = dict(applied=args.apply, home=str(args.home), changes=changes)
    if args.apply:
        (args.backup / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
