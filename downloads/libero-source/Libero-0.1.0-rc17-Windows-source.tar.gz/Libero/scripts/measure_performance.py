#!/usr/bin/env python3
"""Run the native profiler and record host and observed WebKit process memory.

The native test host supplies footprint, audio timing, and UI readiness. RSS of
new WebKit processes is reported separately: it includes shared pages and temporal
association alone cannot prove that a process belongs to this editor.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import subprocess
import time
import ctypes


def process_usage(pid):
    if platform.system() != 'Darwin':
        return {}
    # sys/resource.h: rusage_info_v2 starts with a UUID and eighteen uint64 fields.
    class Usage(ctypes.Structure):
        _fields_ = [('uuid', ctypes.c_uint8 * 16), ('values', ctypes.c_uint64 * 18)]
    data = Usage()
    lib = ctypes.CDLL('/usr/lib/libproc.dylib')
    if lib.proc_pid_rusage(pid, 2, ctypes.byref(data)) != 0:
        return {}
    class Timebase(ctypes.Structure):
        _fields_ = [('numer', ctypes.c_uint32), ('denom', ctypes.c_uint32)]
    clock = Timebase()
    ctypes.CDLL('/usr/lib/libSystem.B.dylib').mach_timebase_info(ctypes.byref(clock))
    return dict(cpu_seconds=(data.values[0] + data.values[1]) * clock.numer / clock.denom * 1e-9,
                footprint_bytes=data.values[7])


def processes():
    rows = {}
    output = subprocess.check_output(
        ["ps", "-axo", "pid=,ppid=,rss=,pcpu=,comm="], text=True
    )
    for line in output.splitlines():
        fields = line.strip().split(None, 4)
        if len(fields) == 5:
            pid, parent, rss, cpu, command = fields
            rows[int(pid)] = dict(pid=int(pid), parent=int(parent), rss_bytes=int(rss) * 1024,
                                  cpu_percent=float(cpu), command=command)
            if 'WebKit' in command:
                rows[int(pid)].update(process_usage(int(pid)))
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True, type=Path)
    parser.add_argument("--sound", required=True, type=Path)
    parser.add_argument("--home", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--instances", type=int, default=1)
    parser.add_argument("--audio", action="store_true")
    parser.add_argument("--rate", type=int, default=48000)
    parser.add_argument("--no-cache", action="store_true", help="Reference run with decoded-sound sharing disabled")
    args = parser.parse_args()
    mode = "--audio-profile" if args.audio else "--performance-profile"
    command = [str(args.host.resolve()), mode, str(args.sound.resolve()),
               str(args.rate if args.audio else args.instances)]
    initial = processes()
    started = time.monotonic()
    env = dict(os.environ, LIBERO_HOME=str(args.home.resolve()))
    env['LIBERO_DISABLE_SAMPLE_CACHE'] = '1' if args.no_cache else '0'
    report = dict(platform=platform.platform(), machine=platform.machine(), command=command,
                  conditions="Native host, no hardware audio device; UI idle phases contain no audio playback.",
                  webkit_memory_note="New WebKit PIDs are candidates, not proven ownership. RSS sums double-count shared pages.",
                  rows=[])
    report['sample_cache_enabled'] = not args.no_cache
    report['webkit_cpu_units'] = 'seconds_from_mach_ticks'
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.with_suffix(".stderr.log").open("w") as errors:
        with subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=errors, text=True) as proc:
            for line in proc.stdout:
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                current = processes()
                descendants = {proc.pid}
                while True:
                    found = {pid for pid, p in current.items() if p["parent"] in descendants}
                    if found <= descendants:
                        break
                    descendants.update(found)
                candidates = [p for pid, p in current.items()
                              if "WebKit" in p["command"] and (pid not in initial or pid in descendants)]
                row.update(elapsed_seconds=time.monotonic() - started,
                           observed_webkit_processes=candidates,
                           observed_webkit_rss_bytes=sum(p["rss_bytes"] for p in candidates),
                           host_ps=current.get(proc.pid))
                report["rows"].append(row)
                print(row.get("stage"), "host MB", round(row.get("footprint_bytes", 0) / 1e6, 1),
                      "observed WebKit RSS MB", round(row["observed_webkit_rss_bytes"] / 1e6, 1), flush=True)
            report["exit_code"] = proc.wait()
    report["duration_seconds"] = time.monotonic() - started
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    return report["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
