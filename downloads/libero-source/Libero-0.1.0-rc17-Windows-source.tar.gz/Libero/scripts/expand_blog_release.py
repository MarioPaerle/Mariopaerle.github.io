#!/usr/bin/env python3
"""Add the blog's exact compiled presets to the frozen release selection."""
from __future__ import annotations
import argparse,copy,hashlib,json,os,shutil,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python'))
from libero import library,licenses
ADDITIONS=[('piano','pianoforte-concerto'),('piano','piano-feltro'),('blue','pianet-t'),
 ('aria','piano-giocattolo'),('percussioni','batteria-jazz'),('percussioni','percussioni-trailer'),
 ('archi','viole'),('archi','violino-solo'),('archi','violini'),('flauti','odisseo-aulos'),
 ('aria','oboe-respiro'),('blue-gpl','banjo-blue'),('giove-freeware','mellotron-mkii-strings')]
SPECIAL={'blue-gpl':'Blue GPL','giove-freeware':'Giove Freeware'}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for c in iter(lambda:f.read(4*1024*1024),b''):h.update(c)
 return h.hexdigest()
def write_json(p,obj):p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def copy_files(source,target):
 for p in library._pack_sound_files(source):
  q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
 ap.add_argument('--evidence',type=Path,required=True);a=ap.parse_args()
 if a.output.exists():ap.error('output exists')
 cat=json.loads((a.input/'catalog.json').read_text());original=copy.deepcopy(cat)
 stage=a.output/'staging-home/banks';packs=a.output/'Individual packs';packs.mkdir(parents=True)
 for pack in cat['packs']:
  p=a.input/pack['file'];assert sha(p)==pack['sha256']
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   assert all('..' not in Path(n).parts and not n.startswith('/') for n in z.namelist())
   z.extractall(stage)
 bybank={p['bank']:p for p in cat['packs']};changed=set();snapshots=[]
 terms=(ROOT/'docs/release/sound-data-terms.md').read_bytes()
 for bank,slug in ADDITIONS:
  live=library.find_sound(slug);assert not library.validate_bundle(live/'build'),slug
  target=stage/bank/slug;target.mkdir(parents=True)
  copy_files(live,target)
  m=json.loads((target/'build/manifest.json').read_text())
  credits=licenses.read_credits(live) or m.get('credits',[]);assert credits,slug
  credits=copy.deepcopy(credits)
  for c in credits:
   if c['source']=='Osiris Piano':c['url']='https://github.com/sfzinstruments/Osiris_Piano'
   c.setdefault('changes','Libero keyboard and velocity mapping, tuning, envelopes and documented sample processing; see the included recipe and notes.')
   c.setdefault('license_url','https://creativecommons.org/licenses/by/3.0/' if 'BY 3.0' in c.get('license','') else 'https://creativecommons.org/licenses/by/4.0/' if 'BY 4.0' in c.get('license','') else 'https://creativecommons.org/publicdomain/zero/1.0/' if c.get('license_class')=='cc0' else c.get('url'))
  cls=licenses.bundle_license(credits)[1]
  assert cls in ('cc0','by') or (bank=='blue-gpl' and cls=='gpl') or (bank=='giove-freeware' and cls=='nc'),(slug,cls)
  # Public custom permission is about freeware software, not a CC NonCommercial music license.
  if bank=='giove-freeware':
   for c in credits:c['license_class']='freeware';c['license']='Taijiguy freeware permission; no payware or commercial for-profit software'
   cls='freeware'
  (target/'samples').mkdir(exist_ok=True);write_json(target/'samples/credits.json',credits)
  for rel in ['samples/ATTRIBUTION.md','build/ATTRIBUTION.md']:(target/rel).write_text(licenses.attribution_text(credits))
  m['credits']=credits;m['license']=' + '.join(sorted({c['license'] for c in credits}))
  write_json(target/'build/manifest.json',m)
  (target/'SOUND-DATA-TERMS.md').write_bytes(terms)
  legal=target/'samples/licenses';legal.mkdir(exist_ok=True)
  # Preserve full publisher notices for the priority pianos, and source records for every addition.
  if slug=='pianet-t':shutil.copy2(a.evidence/'pianet-source-license.txt',legal/'Greg-Sullivan-CC-BY-3.0.txt')
  if slug in ('pianoforte-concerto','piano-feltro'):shutil.copy2(a.evidence/'salamander-source-license.txt',legal/'Salamander-CC-BY-3.0.txt')
  if slug=='piano-feltro':shutil.copy2(a.evidence/'osiris-source-license.txt',legal/'Osiris-CC0.txt')
  if slug in ('odisseo-aulos','oboe-respiro'):shutil.copy2(a.evidence/'tinysol-publisher.json',legal/'TinySOL-publisher.json')
  if slug=='piano-giocattolo':
   shutil.copy2(a.evidence/'toy-piano-source.html',legal/'Tim-Kahn-Freesound-196916.html')
   shutil.copy2(live/'samples/archive-audit.json',legal/'source-archive-audit.json')
  if bank in SPECIAL:
   notice=a.evidence.parent/(bank+'-NOTICE.md');assert notice.is_file()
   shutil.copy2(notice,target/'samples/TERMS.md');shutil.copy2(notice,legal/'NOTICE.md')
  if bank=='blue-gpl':
   upstream=Path('/Users/mario/Libero/cache/libraries/kay-banjo/FlameStudios.Kay5StringBanjo-master')
   shutil.copytree(upstream,target/'sources/upstream')
   # Current recipe inputs are the preferred editable source of the adaptation.
   shutil.copytree(live/'samples',target/'sources/libero-instrument/samples',symlinks=False)
   shutil.copy2(live/'sound.py',target/'sources/libero-instrument/sound.py')
   shutil.copy2(live/'figure.svg',target/'sources/libero-instrument/figure.svg')
   authoring=target/'sources/authoring/python';authoring.mkdir(parents=True)
   shutil.copytree(ROOT/'python/libero',authoring/'libero',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
   shutil.copy2(ROOT/'python/pyproject.toml',authoring/'pyproject.toml')
   shutil.copy2(ROOT/'LICENSE',target/'sources/authoring/LICENSE')
   for p in (ROOT/'python/scripts').glob('*.py'):
    if p.name in ['build_blue_expansion_v6.py','build_aria_mechanical.py','calibrate_blue_v6_body.py']:
     d=authoring/'scripts'/p.name;d.parent.mkdir(exist_ok=True);shutil.copy2(p,d)
   shutil.copy2(upstream/'LICENSE.txt',legal/'FlameStudios-original-license.txt')
   # The local project license is the complete AGPL; GPLv3 is supplied from the upstream legal-code download.
   shutil.copy2(a.evidence/'GPL-3.0.txt',legal/'GPL-3.0.txt')
   for p in a.evidence.glob('flamestudios-gigasamples-*.html'):shutil.copy2(p,legal/p.name)
   (target/'sources/README.txt').write_text('Preferred editable source for Five Strings\n\n'
     'upstream/ contains the complete SFZ conversion and its source recordings/settings.\n'
     'libero-instrument/ contains the current Libero recipe, mapping and original/derived inputs.\n'
     'authoring/ contains the Libero Python compiler and required project source (AGPLv3).\n'
     'In a trusted environment, install authoring/python and compile libero-instrument with python -m libero.compiler.\n'
     'Install dependencies listed in pyproject.toml first. Playback requires no source execution.\n'
     'The recordings and derived sample data retain GPLv3+, including the publisher copyright notice.\n'
     'The original author music-use clarification is in samples/licenses/; it permits artists to choose their music license.\n')
  # File hashes preserve the exact heard audio even when credits or recipes later changed.
  live_audio={p.relative_to(live/'build').as_posix():sha(p) for p in (live/'build').rglob('*') if p.suffix.lower() in ('.flac','.wav')}
  assert all(sha(target/'build'/n)==h for n,h in live_audio.items())
  record={'slug':slug,'title':m['title'],'source_hash':m['source_hash'],'license_class':cls,
    'source_bank':live.parent.name,'runtime_files':{p.relative_to(target/'build').as_posix():sha(p) for p in sorted((target/'build').rglob('*')) if p.is_file()}}
  if bank not in bybank:
   metadata={'format':'libero.bank/1','slug':bank,'title':SPECIAL.get(bank,bank.title()),'version':'0.1.3','figure':None,
      'subtitle':'Blog instruments','description':'Compiled presets with individual source terms','license':'See per-preset recording licenses.'}
   (stage/bank).mkdir(exist_ok=True);write_json(stage/bank/'bank.json',metadata)
   bybank[bank]={'bank':bank,'title':metadata['title'],'programmes':[]}
  bybank[bank]['programmes'].append(record);changed.add(bank)
  snapshots.append({'slug':slug,'bank':bank,'audio_files':len(live_audio),'audio_bytes_changed':0,'compiled_source_hash':m['source_hash'],
    'recipe_snapshot_hash':sha(live/'sound.py'),'source_hash_matches_current_authoring':m['source_hash']==library.source_hash(live),
    'note':'Existing compiled snapshot retained; authoring recipe/source hash can postdate the heard rendering.'})
  write_json(legal/'release-provenance.json',snapshots[-1])
  print('Staged exact preset:',slug,flush=True)
 stamp=datetime.now(timezone.utc).isoformat();result=[]
 for bank,pack in sorted(bybank.items()):
  if bank not in changed:
   shutil.copy2(a.input/pack['file'],packs/pack['file']);result.append(pack);continue
  meta=json.loads((stage/bank/'bank.json').read_text());meta.update(version='0.1.3',updated=stamp)
  write_json(stage/bank/'bank.json',meta);name=f'{bank}-0.1.3.liberobank';archive=packs/name
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
   for p in sorted((stage/bank).rglob('*')):
    if p.is_file():z.write(p,p.relative_to(stage).as_posix())
  with zipfile.ZipFile(archive) as z:assert z.testzip() is None
  pack.update(file=name,presets=len(pack['programmes']),sha256=sha(archive),bytes=archive.stat().st_size)
  result.append(pack);print('Packed',name,flush=True)
 cat.update(version='0.1.3',created_utc=stamp,packs=result,preset_count=sum(p['presets'] for p in result),
   compressed_bytes=sum(p['bytes'] for p in result),status='Testing release: CC0/CC BY core, GPL instrument with source/music clarification, and separately licensed freeware Mellotron',
   excluded='Other working-library presets outside this selection. All instrument presets used by the blog demos are included.')
 assert cat['preset_count']==88
 write_json(packs/'catalog.json',cat);write_json(a.output/'added-presets-provenance.json',snapshots)
 (packs/'SOUND-DATA-TERMS.md').write_bytes(terms)
 (packs/'README.txt').write_text('Libero Base Bundle 0.1.3\n\n88 presets in 15 collections. All blog demo instruments are included.\n'
  'Import the bundle ZIP or select the individual .liberobank files. Review versions and back up edits before an update.\n'
  'Collections without added presets retain version 0.1.2; expanded and new collections use 0.1.3.\n'
  'CC0/CC BY data and two special-term instruments have separate licenses. Keep per-preset credits.\n'
  'Blue GPL / Five Strings includes source and the author statement permitting artists to choose their music license and keep royalties.\n'
  'Giove Freeware / Mellotron is free to distribute with attribution; do not put its samples in payware or commercial for-profit software.\n'
  'The software is AGPLv3. Recorded demo performances and compositions have independent rights.\n'
  'These are the existing compiled sounds, without replacement synthesis or audio changes.\n')
 (packs/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(packs.iterdir()) if p.is_file()))
 print(json.dumps({'presets':cat['preset_count'],'packs':len(result),'bytes':cat['compressed_bytes']}))
if __name__=='__main__':main()
