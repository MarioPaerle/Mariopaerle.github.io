#!/usr/bin/env bash
# Installs the built plugins and libero-render for the current user (no sudo):
#   Libero.vst3      -> ~/Library/Audio/Plug-Ins/VST3
#   Libero.component -> ~/Library/Audio/Plug-Ins/Components
#   libero-render    -> ~/.local/bin
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
build="${LIBERO_BUILD_DIR:-$root/build}"
art="$build/plugin"

vst3="$art/Libero_artefacts/Release/VST3/Libero.vst3"
au="$art/Libero_artefacts/Release/AU/Libero.component"
cli="$art/libero_render_artefacts/Release/libero-render"

for f in "$vst3" "$au" "$cli"; do
    [ -e "$f" ] || { echo "missing $f — run scripts/build.sh first" >&2; exit 1; }
done

vst3_dir="$HOME/Library/Audio/Plug-Ins/VST3"
au_dir="$HOME/Library/Audio/Plug-Ins/Components"
bin_dir="$HOME/.local/bin"
mkdir -p "$vst3_dir" "$au_dir" "$bin_dir"

install_bundle() {
    local src="$1" dest_dir="$2"
    local dest="$dest_dir/$(basename "$src")"
    rm -rf "$dest"
    cp -R "$src" "$dest"
    xattr -dr com.apple.quarantine "$dest" 2>/dev/null || true
    codesign --force -s - --deep "$dest"
    echo "installed $dest"
}

install_bundle "$vst3" "$vst3_dir"
install_bundle "$au" "$au_dir"

cp "$cli" "$bin_dir/libero-render"
codesign --force -s - "$bin_dir/libero-render"
echo "installed $bin_dir/libero-render"

# Make the AU visible without a logout.
killall -9 AudioComponentRegistrar 2>/dev/null || true

case ":$PATH:" in
    *":$bin_dir:"*) ;;
    *) echo "note: $bin_dir is not on PATH" ;;
esac
