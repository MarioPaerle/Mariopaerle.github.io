#!/usr/bin/env python3
"""Build a file-level pack update from two exported .liberobank archives."""
import argparse
import hashlib
import json
from pathlib import PurePosixPath, Path
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def inventory(archive):
    result = {}
    folded = set()
    for entry in archive.infolist():
        name = entry.filename
        if entry.is_dir():
            continue
        parts = PurePosixPath(name).parts
        if (name.startswith('/') or '\\' in name or ':' in name or '\x00' in name
                or any(p in ('', '.', '..') for p in name.split('/')) or len(parts) < 2
                or name.lower() in folded or (entry.external_attr >> 16) & 0o170000 == 0o120000):
            raise ValueError(f'Unsafe archive path: {name!r}')
        folded.add(name.lower())
        result[name] = entry
    roots = {name.split('/')[0] for name in result}
    if len(roots) != 1:
        raise ValueError('Expected exactly one bank folder')
    root = roots.pop()
    meta = json.loads(archive.read(f'{root}/bank.json'))
    if meta['slug'] != root:
        raise ValueError('Bank slug does not match archive root')
    return root, meta, result


def build_delta(before, after, out):
    if out.resolve() in (before.resolve(), after.resolve()):
        raise ValueError('Output must not overwrite an input archive')
    with zipfile.ZipFile(before) as old, zipfile.ZipFile(after) as new:
        root, base, oldfiles = inventory(old)
        targetroot, target, newfiles = inventory(new)
        if root != targetroot or base['version'] == target['version']:
            raise ValueError('Need different versions of the same bank')
        files, payload = [], []
        for name, entry in sorted(newfiles.items()):
            data = new.read(entry)
            sha = digest(data)
            changed = name not in oldfiles or oldfiles[name].file_size != len(data) or digest(old.read(name)) != sha
            files.append(dict(path=name[len(root)+1:], bytes=len(data), sha256=sha, changed=changed))
            if changed:
                payload.append(name)
        meta = dict(format='libero.delta/1', id=root, from_version=base['version'], version=target['version'], files=files)
        out.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as patch:
            patch.writestr('delta.json', json.dumps(meta, separators=(',', ':')))
            for name in payload:
                patch.writestr('files/'+name[len(root)+1:], new.read(name))
    return dict(from_version=base['version'], bytes=out.stat().st_size,
                uncompressed_bytes=max(out.stat().st_size, sum(f['bytes'] for f in files)), sha256=digest(out.read_bytes()),
                changed_bytes=sum(f['bytes'] for f in files if f['changed']),
                changed_files=len(payload), reused_files=len(files)-len(payload))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('before', type=Path); p.add_argument('after', type=Path); p.add_argument('out', type=Path)
    a = p.parse_args()
    print(json.dumps(build_delta(a.before, a.after, a.out), indent=2))


if __name__ == '__main__':
    main()
