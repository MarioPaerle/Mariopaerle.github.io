import assert from 'node:assert/strict';
import { SampleEditWriter } from '../../ui/js/sample-edits.js';

const writes = [], completions = [], settled = [];
const writer = new SampleEditWriter(task => {
  writes.push(task.payload);
  return new Promise(resolve => completions.push(resolve));
}, (task, error) => settled.push([task.revision, error?.message]));
const task = (revision, path = '/bank/a', file = 'note.wav') => ({
  revision, payload: { sound_path: path, file, start_s: revision / 10 }
});
writer.enqueue(task(1), 10000);
const flush = writer.flush();
writer.enqueue(task(2), 10000);
writer.enqueue(task(3), 10000);
writer.enqueue(task(4, '/bank/b'), 10000);
assert.equal(writes.length, 1);
completions.shift()({ ok: true });
await new Promise(resolve => setImmediate(resolve));
assert.equal(writes[1].start_s, .3);
assert.equal(writes.length, 2);
completions.shift()({ ok: true });
await new Promise(resolve => setImmediate(resolve));
assert.equal(writes[2].sound_path, '/bank/b');
completions.shift()({ ok: false, error: 'Disk full' });
await flush;
assert.deepEqual(settled, [[1, undefined], [3, undefined], [4, 'Disk full']]);
assert.equal(writer.busy, false);
await writer.flush();
console.log('PASS: latest edit, serialized saves, navigation, visible save failure');
