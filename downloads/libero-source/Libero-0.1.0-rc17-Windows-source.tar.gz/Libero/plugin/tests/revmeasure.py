import sys, math
sys.path.insert(0, '.')
from wavstats import read
rate, nch, (L, R) = read(sys.argv[1])
w = int(0.05 * rate)
env = []
for i in range(0, len(L) - w, w):
    e = sum(L[j]*L[j] + R[j]*R[j] for j in range(i, i+w)) / (2*w)
    env.append(10*math.log10(max(e, 1e-20)))
pk = max(range(len(env)), key=lambda k: env[k])
top = env[pk]
def t_at(db):
    for k in range(pk, len(env)):
        if env[k] < top + db: return k * 0.05
    return None
a, b = t_at(-5), t_at(-35)
t60 = (b - a) * 2 if a is not None and b is not None else None
s = int(0.3*rate); e = int(1.5*rate)
sl = sum(L[i]*R[i] for i in range(s, e)); nl = math.sqrt(sum(L[i]**2 for i in range(s,e)) * sum(R[i]**2 for i in range(s,e)))
dc = sum(L) / len(L)
print(f"T60~{t60 if t60 is None else round(t60,2)}s  peak_env_db={top:.1f} at {pk*0.05:.2f}s  LRcorr={sl/max(nl,1e-12):.2f} dc={dc:.1e}")
