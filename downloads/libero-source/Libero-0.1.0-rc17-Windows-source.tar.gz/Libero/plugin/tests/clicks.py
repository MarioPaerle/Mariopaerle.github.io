import sys, math
sys.path.insert(0, '.')
from wavstats import read
# Click check: peak |2nd difference| in the 60 ms around each switch versus the steady state
# before (t-0.25..t-0.05) and after (t+0.15..t+0.35). A click shows as a ratio >> 1 vs both.
rate, nch, ch = read(sys.argv[1])
times = [float(t) for t in sys.argv[2].split(',')]
def d2max(a, b):
    m = 0
    for c in ch:
        for i in range(max(2, a), min(len(c), b)):
            m = max(m, abs(c[i] - 2*c[i-1] + c[i-2]))
    return m
res = []
for t in times:
    s = int(t * rate)
    at = d2max(s - int(0.01*rate), s + int(0.05*rate))
    ref = max(d2max(s - int(0.25*rate), s - int(0.05*rate)), d2max(s + int(0.15*rate), s + int(0.35*rate)), 1e-9)
    res.append(round(at / ref, 2))
print(' '.join(str(r) for r in res), '| worst', max(res))
