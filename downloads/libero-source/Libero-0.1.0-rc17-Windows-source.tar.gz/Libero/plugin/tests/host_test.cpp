// Headless host for tests: runs LiberoProcessor with a fake audio thread so the agent socket,
// note injection, parameter changes and state save/restore can be exercised from Python.
//
// Prints {"port": ..., "id": ...} once ready, runs until stdin closes, then prints a summary.

#include "../src/Library.h"
#include "../src/PackStore.h"
#include "../src/DeltaPack.h"
#include "PluginEditor.h"
#include "PluginProcessor.h"
#include "../cli/Arguments.h"
#include "../engine/Bundle.h"

#include <iostream>
#include <thread>
#include "PerformanceProfile.h"

namespace
{
    class PreviewWindow : public juce::DocumentWindow
    {
    public:
        explicit PreviewWindow (juce::AudioProcessorEditor& editor)
            : DocumentWindow ("Libero", juce::Colours::black, DocumentWindow::allButtons)
        {
            setUsingNativeTitleBar (true);
            setContentNonOwned (&editor, true);
            setResizable (true, false);
            setResizeLimits (1000, 560, 2600, 1600);
            centreWithSize (getWidth(), getHeight());
            setVisible (true);
        }
        void closeButtonPressed() override { setVisible (false); }
    };
    class FakeAudioThread : public juce::Thread
    {
    public:
        explicit FakeAudioThread (juce::AudioProcessor& p) : juce::Thread ("fake audio"), proc (p)
        {
            capture.setSize (2, 48000 * 120);
            capture.clear();
        }

        void run() override
        {
            juce::AudioBuffer<float> buffer (2, 256);
            juce::MidiBuffer midi;
            const auto startMs = juce::Time::getMillisecondCounterHiRes();

            while (! threadShouldExit())
            {
                buffer.clear();
                midi.clear();
                proc.processBlock (buffer, midi);

                for (int c = 0; c < 2; ++c)
                    for (int i = 0; i < buffer.getNumSamples(); ++i)
                    {
                        const auto v = buffer.getSample (c, i);

                        if (! std::isfinite (v))
                            nonFinite = true;

                        peak = std::max (peak.load(), std::abs (v));
                    }

                if (captured + buffer.getNumSamples() <= capture.getNumSamples())
                {
                    for (int c = 0; c < 2; ++c)
                        capture.copyFrom (c, captured, buffer, c, 0, buffer.getNumSamples());

                    captured += buffer.getNumSamples();
                }

                blocks++;

                // Pace to real time so wall-clock requests land where a real host would put them.
                const auto due = startMs + blocks.load() * 256.0 * 1000.0 / 48000.0;
                const auto wait = due - juce::Time::getMillisecondCounterHiRes();

                if (wait > 0.0)
                    juce::Thread::sleep ((int) wait);
            }
        }

        juce::AudioProcessor& proc;
        std::atomic<float> peak { 0.0f };
        std::atomic<int> blocks { 0 };
        std::atomic<bool> nonFinite { false };
        juce::AudioBuffer<float> capture;
        int captured = 0;
    };

    void writeCapture (const FakeAudioThread& audio, const juce::String& path)
    {
        const juce::File f (path);
        f.deleteFile();
        std::unique_ptr<juce::OutputStream> stream = std::make_unique<juce::FileOutputStream> (f);
        juce::WavAudioFormat wav;
        auto writer = wav.createWriterFor (stream, juce::AudioFormatWriterOptions{}
                                                       .withSampleRate (48000.0)
                                                       .withNumChannels (2)
                                                       .withBitsPerSample (32)
                                                       .withSampleFormat (juce::AudioFormatWriterOptions::SampleFormat::floatingPoint));
        if (writer != nullptr)
            writer->writeFromAudioSampleBuffer (audio.capture, 0, audio.captured);
    }

    void pump (int ms)
    {
        const auto end = juce::Time::getMillisecondCounter() + (juce::uint32) ms;

        while (juce::Time::getMillisecondCounter() < end)
        {
            juce::MessageManager::getInstance()->runDispatchLoopUntil (20);
        }
    }

    int runSampleEditorCheck (const juce::String& path, bool checkUi = false)
    {
        auto proc = std::make_unique<libero::LiberoProcessor>();
        proc->setPlayConfigDetails (0, 2, 48000.0, 256);
        proc->prepareToPlay (48000.0, 256);
        bool loaded = false;
        proc->loadSound (juce::File (path), true, [&loaded] (bool ok, juce::String) { loaded = ok; });
        for (int i = 0; i < 100 && ! loaded; ++i) pump (20);
        auto info = proc->sampleEditorInfo();
        auto* zones = info["zones"].getArray();
        bool waveform = false, applied = false, loaded441 = false, loaded480 = false, cropContent = false, saveCopy = false;
        bool playhead = false, wrapped = false, restored = false, copyOrigin = false;
        bool automatic = !checkUi, fullEnd = false, startOnly = !checkUi;
        juce::String file;
        if (zones != nullptr && ! zones->isEmpty())
        {
            file = (*zones)[0]["file"].toString();
            const auto wave = proc->sampleEditorWaveform (file);
            waveform = (bool) wave["ok"];
            double wavePeak = 0.0;
            if (const auto* points = wave["points"].getArray())
                for (const auto& point : *points)
                    if (const auto* pair = point.getArray(); pair != nullptr && pair->size() == 2)
                        wavePeak = std::max (wavePeak, std::max (std::abs ((double) (*pair)[0]), std::abs ((double) (*pair)[1])));
            waveform = waveform && wavePeak > .1;
            juce::String initialError;
            const auto initial = libero::SoundData::load (juce::File (path), 48000.0, initialError);
            juce::var edit = juce::JSON::parse ("{}");
            auto* object = edit.getDynamicObject();
            object->setProperty ("file", file);
            object->setProperty ("zone", (*zones)[0]);
            object->setProperty ("sound_path", proc->sampleEditorInfo()["sound_path"]);
            object->setProperty ("source_hash", (*zones)[0]["source_hash"]);
            object->setProperty ("start_s", 0.10);
            object->setProperty ("end_s", 0.70);
            object->setProperty ("loop_enabled", true);
            object->setProperty ("loop_start_s", 0.20);
            object->setProperty ("loop_end_s", 0.60);
            object->setProperty ("crossfade_ms", 10.0);
            bool done = false;
            proc->applySampleEditorEdit (edit, [&done, &applied] (bool ok, juce::String) { applied = ok; done = true; });
            for (int i = 0; i < 100 && ! done; ++i) pump (20);
            juce::String error;
            auto a = libero::SoundData::load (juce::File (path), 44100.0, error);
            loaded441 = a != nullptr && ! a->zones.empty() && a->zones.front().looped
                     && a->zones.front().onset == 0
                     && ! a->zones.front().oneShot
                     && std::abs ((double) a->zones.front().length() / 44100.0 - .60) < .002;
            error.clear();
            auto b = libero::SoundData::load (juce::File (path), 48000.0, error);
            loaded480 = b != nullptr && ! b->zones.empty() && b->zones.front().looped
                     && b->zones.front().onset == 0
                     && ! b->zones.front().oneShot
                     && std::abs ((double) b->zones.front().length() / 48000.0 - .60) < .002;
            if (initial != nullptr && b != nullptr && ! initial->zones.empty() && ! b->zones.empty())
            {
                const auto& before = initial->zones.front().audio;
                const auto& after = b->zones.front().audio;
                const auto offset = 4800;
                float maximumError = 0.0f;
                if (before.getNumChannels() == after.getNumChannels() && before.getNumSamples() >= offset + 128
                    && after.getNumSamples() >= 128)
                    for (int c = 0; c < after.getNumChannels(); ++c)
                        for (int i = 0; i < 128; ++i)
                            maximumError = juce::jmax (maximumError, std::abs (before.getSample (c, offset + i) - after.getSample (c, i)));
                cropContent = maximumError < 1.0e-5f;
            }
            const auto copy = libero::library::saveSoundAs (juce::File (path), "Waveform copy", juce::var (new juce::DynamicObject()));
            saveCopy = (bool) copy["ok"] && juce::File (copy["path"].toString()).getChildFile ("sample-edits.json").existsAsFile();
            const auto copiedInfo = libero::library::soundInfo (juce::File (copy["path"].toString()));
            copyOrigin = (bool) copiedInfo["is_copy"] && copiedInfo["original_title"].toString().isNotEmpty()
                      && copiedInfo["figure"].toString().replace ("\r\n", "\n")
                         == libero::library::soundInfo (juce::File (path))["figure"].toString().replace ("\r\n", "\n");
            if (b != nullptr)
            {
                libero::Engine engine;
                libero::ParamSet params;
                params[libero::P::amp_sustain] = 1.0f;
                engine.setParameters (params); engine.prepare (48000, 256);
                const auto key = b->zones.front().root;
                const auto index = b->zones.front().manifestIndex;
                engine.submitSound (std::move (b)); engine.finishLoadingOffline();
                std::array<float, 256> left {}, right {};
                double previous = -1;
                for (int block = 0; block < 250; ++block)
                {
                    juce::MidiBuffer midi;
                    if (block == 0) midi.addEvent (juce::MidiMessage::noteOn (1, key, (juce::uint8) 100), 0);
                    engine.process (left.data(), right.data(), 256, midi);
                    const auto position = engine.samplePlayback();
                    if (position.zone != index || !position.looped || position.seconds < .10 || position.seconds > .602) break;
                    playhead = true;
                    wrapped = wrapped || position.seconds < previous;
                    previous = position.seconds;
                }
            }
            object->setProperty ("loop_enabled", false);
            object->setProperty ("end_s", (double) wave["duration_s"]);
            done = false;
            proc->applySampleEditorEdit (edit, [&done] (bool, juce::String) { done = true; });
            for (int i = 0; i < 100 && !done; ++i) pump (20);
            auto full = libero::SoundData::load (juce::File (path), 44100, error);
            fullEnd = full != nullptr && !full->zones.front().looped
                && std::abs (full->zones.front().sourceStartSeconds - .10) < .0001
                && std::abs ((double) full->zones.front().length() / 44100 - ((double) wave["duration_s"] - .10)) < .002;
            object->setProperty ("restore", true);
            done = false;
            proc->applySampleEditorEdit (edit, [&done, &restored] (bool ok, juce::String) { restored = ok; done = true; });
            for (int i = 0; i < 100 && !done; ++i) pump (20);
            auto originalAgain = libero::SoundData::load (juce::File (path), 48000, error);
            restored = restored && originalAgain != nullptr && initial != nullptr
                    && originalAgain->zones.front().length() == initial->zones.front().length()
                    && originalAgain->zones.front().onset == initial->zones.front().onset
                    && originalAgain->zones.front().oneShot == initial->zones.front().oneShot;
        }
        if (checkUi && restored)
        {
            std::unique_ptr<juce::AudioProcessorEditor> editor (proc->createEditorAndMakeActive());
            editor->addToDesktop (juce::ComponentPeer::windowHasTitleBar);
            editor->setVisible (true);
            pump (4000);
            auto& browser = static_cast<libero::LiberoEditor*> (editor.get())->getBrowser();
            browser.evaluateJavascript (R"JS(
                const start = document.getElementById('sample-start');
                start.value = '.25'; start.dispatchEvent(new Event('input')); 1)JS");
            pump (3000);
            const auto startZone = proc->sampleEditorInfo()["zones"][0];
            juce::String startError;
            auto startSound = libero::SoundData::load (juce::File (path), 44100, startError);
            startOnly = startSound != nullptr && (bool) startZone["edited"]
                && std::abs ((double) startZone["start_s"] - .25) < .00001
                && std::abs (startSound->zones.front().sourceStartSeconds - .25) < .0001;
            // The original end was never edited: it must still equal the source duration.
            const auto sourceWave = proc->sampleEditorWaveform (file);
            startOnly = startOnly && std::abs ((double) startZone["end_s"] - (double) sourceWave["duration_s"]) < .00001;
            browser.evaluateJavascript (R"JS(
                (() => { const zones = document.getElementById('sample-zone');
                zones.value = zones.options.length > 1 ? '1' : '0'; zones.dispatchEvent(new Event('change')); })(); 1)JS");
            pump (500);
            browser.evaluateJavascript (R"JS(
                (() => { const zones = document.getElementById('sample-zone');
                zones.value = '0'; zones.dispatchEvent(new Event('change')); })(); 1)JS");
            pump (500);
            bool zoneReturn = false, zoneChecked = false;
            browser.evaluateJavascript ("Math.abs(Number(document.getElementById('sample-start').value) - .25) < .00001 && Number(document.getElementById('sample-end').value) > 1", [&] (juce::WebBrowserComponent::EvaluationResult value) {
                if (auto* v = value.getResult()) zoneReturn = (bool) *v;
                zoneChecked = true;
            });
            for (int i = 0; i < 50 && !zoneChecked; ++i) pump (20);
            startOnly = startOnly && zoneReturn;
            browser.evaluateJavascript (R"JS(
                (() => {
                    const loop = document.getElementById('sample-loop-enabled');
                    loop.checked = false; loop.dispatchEvent(new Event('change'));
                    for (const [id, value] of [['sample-start', '.15'], ['sample-end', '.55'], ['sample-start', '.25']]) {
                        const field = document.getElementById(id);
                        field.value = value; field.dispatchEvent(new Event('input'));
                    }
                    window.__autoNoApply = !document.getElementById('sample-apply');
                })(); 1)JS");
            pump (3000);
            const auto edited = proc->sampleEditorInfo()["zones"][0];
            juce::String error;
            auto cropped = libero::SoundData::load (juce::File (path), 48000, error);
            bool noApply = false, checked = false;
            browser.evaluateJavascript ("window.__autoNoApply", [&] (juce::WebBrowserComponent::EvaluationResult value) {
                if (auto* v = value.getResult()) noApply = (bool) *v;
                checked = true;
            });
            for (int i = 0; i < 50 && !checked; ++i) pump (20);
            automatic = noApply && (bool) edited["edited"]
                && std::abs ((double) edited["start_s"] - .25) < .00001
                && std::abs ((double) edited["end_s"] - .55) < .00001
                && cropped != nullptr && !cropped->zones.front().looped
                && std::abs ((double) cropped->zones.front().length() / 48000 - .30) < .002;
            editor.reset();
        }
        juce::DynamicObject::Ptr result = new juce::DynamicObject();
        result->setProperty ("eligible", (bool) info["eligible"]);
        result->setProperty ("waveform", waveform);
        result->setProperty ("applied", applied);
        result->setProperty ("loaded_44100", loaded441);
        result->setProperty ("loaded_48000", loaded480);
        result->setProperty ("crop_content", cropContent);
        result->setProperty ("save_copy", saveCopy);
        result->setProperty ("playhead", playhead && wrapped);
        result->setProperty ("restored", restored);
        result->setProperty ("copy_origin", copyOrigin);
        result->setProperty ("automatic", automatic);
        result->setProperty ("full_end", fullEnd);
        result->setProperty ("start_only", startOnly);
        std::cout << juce::JSON::toString (juce::var (result.get()), true) << std::endl;
        return (bool) info["eligible"] && waveform && applied && loaded441 && loaded480 && cropContent && saveCopy
               && playhead && wrapped && restored && copyOrigin && automatic && fullEnd && startOnly ? 0 : 1;
    }

    // Opens the real editor (WebView) on a loaded sound, then inspects the page from JavaScript.
    int runUiCheck (const juce::String& soundPath, const juce::String& secondSound, const juce::String& thirdSound)
    {
        auto proc = std::make_unique<libero::LiberoProcessor>();
        proc->setPlayConfigDetails (0, 2, 48000.0, 256);
        proc->prepareToPlay (48000.0, 256);

        FakeAudioThread audio (*proc);
        audio.startThread (juce::Thread::Priority::high);

        bool loaded = false;
        proc->loadSound (juce::File (soundPath), true, [&loaded] (bool ok, juce::String) { loaded = ok; });

        for (int i = 0; i < 100 && ! loaded; ++i)
            pump (50);

        std::unique_ptr<juce::AudioProcessorEditor> editor (proc->createEditorAndMakeActive());
        editor->addToDesktop (juce::ComponentPeer::windowHasTitleBar);
        editor->setTopLeftPosition (80, 80);
        editor->setVisible (true);
        auto& browser = static_cast<libero::LiberoEditor*> (editor.get())->getBrowser();
        const auto waitForPage = [&browser, &audio] (const juce::String& predicate, const char* stage, int timeoutMs = 30000)
        {
            const auto deadline = juce::Time::getMillisecondCounterHiRes() + timeoutMs;
            while (juce::Time::getMillisecondCounterHiRes() < deadline)
            {
                struct Evaluation { bool complete = false, matched = false; };
                auto evaluation = std::make_shared<Evaluation>();
                browser.evaluateJavascript ("Boolean(" + predicate + ")", [evaluation] (auto result)
                {
                    if (auto* value = result.getResult())
                        evaluation->matched = static_cast<bool> (*value);
                    evaluation->complete = true;
                });
                while (! evaluation->complete && juce::Time::getMillisecondCounterHiRes() < deadline)
                    pump (25);
                if (evaluation->matched)
                    return true;
                pump (50);
            }
            audio.stopThread (2000);
            std::cout << "{\"error\": " << juce::JSON::toString (juce::String ("UI timeout: ") + stage) << "}" << std::endl;
            return false;
        };
        if (! waitForPage ("document.documentElement.classList.contains('ready') && document.querySelector('[data-param=\"tape_age\"]') && document.getElementById('tab-caldi')", "initial controls"))
            return 1;

        browser.evaluateJavascript (R"JS(
            (function () {
              window.__t = { scope: 0, soundChanged: [] };
              window.__JUCE__.backend.addEventListener('scope', e => { window.__t.scope++; window.__t.scopeLen = e.l.length + e.r.length; window.__t.level = Math.max(window.__t.level || 0, e.level); });
              window.__JUCE__.backend.addEventListener('soundChanged', e => window.__t.soundChanged.push(e && e.title));
              window.__JUCE__.backend.addEventListener('agentStatus', e => window.__t.agentStatusEvent = e);
              window.__t.reloadedEvents = 0;
              window.__JUCE__.backend.addEventListener('soundReloaded', () => window.__t.reloadedEvents++);
              import('/juce/index.js').then(async j => {
                const f = n => j.getNativeFunction(n);
                window.__t.themes = await f('listThemes')();
                const theme = await f('getTheme')();
                window.__t.theme = theme.name;
                window.__t.theme_css = theme.css.length;
                window.__t.resizeWidth = (await f('resizeEditor')(1190, 780)).ok;
                await new Promise(resolve => setTimeout(resolve, 100));
                window.__t.widthOnly = innerWidth === 1190 && innerHeight === 780;
                window.__t.resizeHeight = (await f('resizeEditor')(1190, 690)).ok;
                await new Promise(resolve => setTimeout(resolve, 100));
                window.__t.heightOnly = innerWidth === 1190 && innerHeight === 690;
                await f('resizeEditor')(1360, 780);
                window.__t.current = (await f('currentSound')()).title;
                window.__t.sounds = (await f('listSounds')()).map(s => s.slug);
                window.__t.agent = await f('agentStatus')();
                window.__t.audition = await f('audition')(60, 90);

                const list = await f('listSounds')();
                const target = list[0];
                window.__t.fields = ['favorite', 'mtime', 'tags'].every(k => k in target);
                await f('setFavorite')(target.path, true);
                window.__t.favOn = (await f('listSounds')()).find(s => s.path === target.path).favorite;
                await f('setFavorite')(target.path, false);
                window.__t.favOff = (await f('listSounds')()).find(s => s.path === target.path).favorite;
                window.__t.reload = (await f('reloadSound')()).ok;
                window.__t.reset = (await f('resetSound')()).ok;
                // Modified-state notifications arrive on the editor timer.
                for (let i = 0; i < 20 && (await f('currentSound')()).modified; i++)
                  await new Promise(r => setTimeout(r, 25));
                window.__t.modified = (await f('currentSound')()).modified;
                const saved = await f('saveSoundAs')('Prova dalla UI');
                window.__t.saveAs = saved.ok && /prova-dalla-ui/.test(saved.path);
                window.__t.afterSave = (await f('currentSound')()).title;
                const banks = await f('listBanks')();
                window.__t.banks = ['test-bank', 'mie', 'prove'].every(k => banks.some(b => b.slug === k));
                const cur = await f('currentSound')();
                const mv = await f('moveSound')(saved.path, 'test-bank');
                const inBank = (await f('listSounds')()).find(s => s.slug === cur.slug);
                window.__t.moveIn = mv.ok && inBank && inBank.bank.slug === 'test-bank' && inBank.saved === true
                  && (await f('currentSound')()).title === cur.title;
                window.__t.moveBad = (await f('moveSound')(mv.path, 'no-such-bank')).ok === false;
                const back = await f('moveSound')(mv.path, 'mie');
                const inMie = (await f('listSounds')()).find(s => s.slug === cur.slug);
                window.__t.moveOut = back.ok && inMie.bank.slug === 'mie';
                const bk = (await f('listBanks')()).find(b => b.slug === 'test-bank');
                window.__t.bankFields = !!bk && ['title', 'subtitle', 'description', 'version', 'license', 'created', 'updated', 'count'].every(k => k in bk);
                const tgt = (await f('listSounds')()).find(s => s.slug === cur.slug);
                const tagOn = await f('setColorTag')(tgt.path, 2);
                window.__t.tagSet = tagOn.ok && (await f('listSounds')()).find(s => s.slug === cur.slug).colorTag === 2
                  && (await f('currentSound')()).colorTag === 2;
                await f('setColorTag')(tgt.path, 0);
                window.__t.tagOff = (await f('listSounds')()).find(s => s.slug === cur.slug).colorTag === 0;
                window.__t.tagBad = (await f('setColorTag')(tgt.path, 9)).ok === false;
                const cb = await f('createBank')('Banca UI', 'sotto');
                window.__t.createBank = cb.ok && cb.slug === 'banca-ui';
                const eb = await f('editBank')('banca-ui', { title: 'Banca UI 2', description: 'd' });
                const nb = (await f('listBanks')()).find(b => b.slug === 'banca-ui');
                window.__t.editBank = eb.ok && nb.title === 'Banca UI 2' && nb.description === 'd' && nb.subtitle === 'sotto';
                const packPath = cb.path.replace(/banks[\\/]banca-ui$/, 'ui-export.liberobank');
                const ex = await f('exportBank')('banca-ui', packPath);
                window.__t.exportBank = ex.ok && ex.path === packPath;
                const plan = await f('inspectBank')(packPath);
                window.__t.inspectSame = plan.ok === true && plan.action === 'already_installed'
                  && plan.code === 'SAME_VERSION' && plan.bank.slug === 'banca-ui'
                  && plan.bank.version === '1.0.0' && plan.installedVersion === '1.0.0'
                  && plan.soundCount === 0 && Array.isArray(plan.warnings);
                const im = await f('importBank')(packPath);
                window.__t.importSame = im.ok === false && /already installed/.test(im.error);
                window.__t.exportBad = (await f('exportBank')('nessuna', packPath)).ok === false;
                const collection = await f('inspectBankCollection')([packPath, packPath]);
                window.__t.collectionInspect = collection.ok === true && collection.entries.length === 2
                  && collection.entries.every(e => e.action === 'already_installed') && !!collection.sessionId;
                window.__t.collectionSkip = (await f('importBankCollectionEntry')(collection.sessionId, 0)).ok === false;
                window.__t.collectionCleanup = (await f('cleanupBankCollection')(collection.sessionId)).ok === true;
                window.__t.collectionExpired = (await f('importBankCollectionEntry')(collection.sessionId, 0)).ok === false;

                // The drawer: folders at the top, a bank opens its sounds, Esc goes back.
                const crumb = () => document.getElementById('lib-crumb');
                const folderTiles = () => document.querySelectorAll('#grid .tile.folder').length;
                document.getElementById('lib-toggle').click();
                await new Promise(r => setTimeout(r, 900));
                crumb().querySelector('button.crumb')?.click();
                await new Promise(r => setTimeout(r, 200));
                window.__t.foldersShown = folderTiles() >= 4 && !!document.querySelector('#grid .tile.folder[data-folder="fav"]')
                  && !!document.querySelector('#grid .tile.folder[data-folder="mie"]') && !!document.querySelector('#grid .tile.folder[data-folder="prove"]')
                  && !!document.querySelector('#grid .tile.folder[data-folder="test-bank"]');
                document.querySelector('#grid .tile.folder[data-folder="test-bank"] .thumb').click();
                await new Promise(r => setTimeout(r, 200));
                window.__t.bankView = /Banco di prova/.test(crumb().textContent) && folderTiles() === 0;
                document.getElementById('lib-close').click();
                await new Promise(r => setTimeout(r, 80));
                window.__t.returnToSound = !document.getElementById('drawer').classList.contains('open')
                  && document.getElementById('drawer').inert && document.activeElement.id === 'plate';
                document.getElementById('lib-toggle').click();
                await new Promise(r => setTimeout(r, 250));
                document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
                await new Promise(r => setTimeout(r, 200));
                window.__t.backToTop = crumb().textContent === 'Library' && folderTiles() >= 4;
                // Preview buttons: listed with a URL that serves audio, shown on the plate, play and stop.
                const sleep = ms => new Promise(r => setTimeout(r, ms));
                const pvItem = (await f('listSounds')()).find(s => s.previewUrl);
                window.__t.previewListed = !!pvItem && /^\/preview\//.test(pvItem.previewUrl);
                if (pvItem) {
                  const pr = await fetch(pvItem.previewUrl);
                  const blob = await pr.blob();
                  window.__t.previewServes = pr.ok && blob.size > 1000 && /^audio\//.test(blob.type);
                  window.__t.previewDecodes = await new Promise(res => {
                    const au = new Audio(URL.createObjectURL(blob));
                    au.addEventListener('canplaythrough', () => res(au.duration > 0.3), { once: true });
                    au.addEventListener('error', () => res(false), { once: true });
                    setTimeout(() => res(false), 4000);
                  });
                  document.querySelector('#grid .tile.folder[data-folder="mie"] .thumb').click();
                  await sleep(300);
                  const btn = document.querySelector('#grid .tile .play:not([hidden])');
                  window.__t.previewButton = !!btn;
                  if (btn) {
                    btn.click();
                    await sleep(700);
                    window.__t.previewPlays = btn.classList.contains('playing');
                    btn.click();
                    await sleep(100);
                    window.__t.previewStops = !btn.classList.contains('playing') && !btn.classList.contains('loading');
                  }
                  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
                  await sleep(200);
                }
                document.getElementById('lib-toggle').click();
                window.__t.dom = ['reload', 'reset', 'save-as', 'lib-search', 'lib-filter', 'fav-slot']
                  .every(id => document.getElementById(id));
                window.__t.done = true;
              }).catch(e => { window.__t.error = String(e); });
              return 1;
            })())JS");

        if (! waitForPage ("window.__t && (window.__t.done || window.__t.error)", "library and preview checks", 60000))
            return 1;

        // The UI writes parameters through the relays: move one slider and one choice from JS
        // exactly as a drag would, then read the processor's own parameter values back.
        browser.evaluateJavascript (R"JS(
            import('/juce/index.js').then(j => {
              const s = j.getSliderState('rev_mix');
              s.sliderDragStarted(); s.setNormalisedValue(0.9); s.sliderDragEnded();
              const c = j.getComboBoxState('flt_mode');
              c.setChoiceIndex(2);
              // Real drags on the UI's own controls, through their pointer handlers. The oscillator
              // and LFO controls are not in the UI (engine/socket only); a tape control is.
              const drag = id => {
                const el = document.querySelector(`[data-param="${id}"]`);
                if (!el) { window.__t.dragMissing = id; return; }
                const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
                const ev = (type, dy) => el.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, pointerId: 1, pointerType: 'mouse', button: 0, buttons: type === 'pointerup' ? 0 : 1, clientX: x, clientY: y - dy }));
                try { ev('pointerdown', 0); } catch (e) { window.__t.dragError = String(e); }
                for (let k = 1; k <= 10; k++) ev('pointermove', k * 10);
                ev('pointerup', 100);
              };
              window.__t.dragTarget = !!document.querySelector('[data-param="rev_size"]');
              ['rev_size', 'tape_age'].forEach(drag);
              // Exercise the actual Caldi tab, radio click and keyboard handlers,
              // rather than writing values through the relay API alone.
              document.getElementById('tab-caldi')?.click();
              const page = document.getElementById('page-caldi');
              const blu = [...(page?.querySelectorAll('[role="radio"]') || [])].find(el => el.textContent === 'Blue');
              if (!blu) { window.__t.caldiMissing = 'Blue'; return; }
              blu.click();
              const keys = (id, count) => {
                const el = page.querySelector(`[data-param="${id}"]`);
                if (!el) { window.__t.caldiMissing = id; return; }
                el.focus();
                for (let i=0; i<count; ++i) el.dispatchEvent(new KeyboardEvent('keydown', {key:'PageUp', bubbles:true, cancelable:true}));
              };
              keys('caldi_grain', 2); keys('caldi_motion', 1);
              window.__t.noOscUi = !document.querySelector('[data-param^="osc"], [data-param^="lfo_"]:not([data-param="lfo_rate"]):not([data-param="lfo_pitch_cc1"]), [data-param="sub_level"]') && !document.getElementById('tab-oscillatori') && !document.getElementById('tab-moto');
              window.__t.walk = !!document.getElementById('walk');
              window.__t.writesDone = true;
            }).catch(e => { window.__t.writeError = String(e); }); 1)JS");
        if (! waitForPage ("window.__t && (window.__t.writesDone || window.__t.writeError || window.__t.caldiMissing)", "parameter controls"))
            return 1;
        pump (250);

        browser.evaluateJavascript (R"JS(
            (function () {
              const page=document.getElementById('page-caldi');
              const ids=['caldi_amount','caldi_body','caldi_light','caldi_grain','caldi_motion','caldi_output'];
              const controls=ids.map(id=>page?.querySelector(`[data-param="${id}"]`));
              window.__t.caldi = {
                tabSelected: document.getElementById('tab-caldi')?.getAttribute('aria-selected') === 'true',
                controls: controls.filter(Boolean).length,
                visible: controls.every(el=>!!el && el.getBoundingClientRect().width>0 && !page.inert),
                preset: page?.querySelector('[role="radio"][aria-checked="true"]')?.textContent,
                grain: Number(controls[3]?.getAttribute('aria-valuenow')),
                motion: Number(controls[4]?.getAttribute('aria-valuenow')),
              };
              return 1;
            })())JS");
        pump (250);

        {
            juce::String writes = "{";
            for (auto* p : proc->getParameters())
                if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (p))
                    if (juce::StringArray { "rev_mix", "flt_mode", "rev_size", "tape_age", "tape_mix", "caldi_mode", "caldi_grain", "caldi_motion" }
                            .contains (rp->getParameterID()))
                        writes << "\"" << rp->getParameterID() << "\": " << rp->getValue() << ", ";
            std::cout << "ui-writes " << writes << "\"_\": 0}" << std::endl;
        }

        if (secondSound.isNotEmpty())
            proc->loadSound (juce::File (secondSound), true);

        pump (1500);

        if (thirdSound.isNotEmpty())
        {
            // A sound with articulations: the UI shows their names, the default (first) is lit, and a
            // keyswitch played through the engine moves the highlight (event articulationChanged).
            proc->loadSound (juce::File (thirdSound), true);
            if (! waitForPage ("document.querySelectorAll('#artics button').length === 4 && document.querySelector('#artics button[aria-checked=\"true\"]')?.textContent === 'Sostenuto'", "articulation controls"))
                return 1;

            const auto row = R"JS(
                (function () {
                  const row = document.getElementById('artics');
                  const btns = row ? [...row.querySelectorAll('button')] : [];
                  return { hidden: row ? row.hidden : true, names: btns.map(x => x.textContent),
                           active: btns.findIndex(x => x.getAttribute('aria-checked') === 'true') };
                })())JS";
            browser.evaluateJavascript (juce::String ("window.__t.articBefore = ") + row + "; 1");
            browser.evaluateJavascript (R"JS(
                window.__t.articEvents = [];
                window.__JUCE__.backend.addEventListener('articulationChanged', e => window.__t.articEvents.push(e));
                import('/juce/index.js').then(j => j.getNativeFunction('audition')(25, 100)); 1)JS");
            pump (1200);
            browser.evaluateJavascript (juce::String ("window.__t.articAfter = ") + row + "; 1");
            pump (300);
            // Clicking a word selects it through the parameter.
            browser.evaluateJavascript ("document.querySelector('#artics button[data-art=\"pizz\"]').click(); 1");
            pump (800);
            browser.evaluateJavascript (juce::String ("window.__t.articClick = ") + row + "; 1");
            pump (300);
        }

        juce::String result;
        bool done = false;

        browser.evaluateJavascript (R"JS(
            JSON.stringify({
              title: document.title,
              viewport: { width: innerWidth, height: innerHeight },
              juce: typeof window.__JUCE__,
              sliders: window.__JUCE__ ? window.__JUCE__.initialisationData.__juce__sliders.length : -1,
              combos: window.__JUCE__ ? window.__JUCE__.initialisationData.__juce__comboBoxes.length : -1,
              functions: window.__JUCE__ ? window.__JUCE__.initialisationData.__juce__functions.length : -1,
              stylesheets: document.styleSheets.length,
              text: document.body ? document.body.innerText.replace(/\s+/g, ' ').slice(0, 240) : '',
              calls: window.__t,
              artic: (function () {
                const t = window.__t || {};
                const names = ['Sostenuto', 'Staccato', 'Pizzicato', 'Tremolo'];
                const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
                const b0 = t.articBefore, b1 = t.articAfter, b2 = t.articClick;
                return {
                  before: b0, after: b1, click: b2, events: t.articEvents,
                  ok: !!(b0 && b1 && b2 && !b0.hidden && same(b0.names, names) && b0.active === 0
                         && b1.active === 1 && b2.active === 2
                         && (t.articEvents || []).some(e => e.index === 1 && e.id === 'stacc'))
                };
              })()
            }))JS",
            [&] (juce::WebBrowserComponent::EvaluationResult r)
            {
                if (auto* v = r.getResult())
                    result = v->toString();
                else if (auto* e = r.getError())
                    result = "{\"error\": " + juce::JSON::toString (e->message) + "}";

                done = true;
            });

        for (int i = 0; i < 100 && ! done; ++i)
            pump (50);

        std::cout << (result.isNotEmpty() ? result : juce::String ("{\"error\": \"no result\"}")) << std::endl;

        audio.stopThread (2000);
        editor.reset();
        proc.reset();
        return 0;
    }
}

// Opens the editor on the user's real library and measures where the interface spends time.
int runUiProfile (const juce::String& soundPath)
{
    {
        auto t0 = juce::Time::getMillisecondCounterHiRes();
        const auto list = libero::library::listSounds();
        auto t1 = juce::Time::getMillisecondCounterHiRes();
        const auto json = juce::JSON::toString (list, true);
        auto t2 = juce::Time::getMillisecondCounterHiRes();
        std::cout << "cpp listSounds " << (int) (t1 - t0) << " ms, toJSON " << (int) (t2 - t1) << " ms, "
                  << json.length() / 1024 << " KB" << std::endl;
    }

    auto proc = std::make_unique<libero::LiberoProcessor>();
    proc->setPlayConfigDetails (0, 2, 44100.0, 256);
    proc->prepareToPlay (44100.0, 256);
    FakeAudioThread audio (*proc);
    audio.startThread (juce::Thread::Priority::high);

    bool loaded = false;
    proc->loadSound (juce::File (soundPath), true, [&loaded] (bool ok, juce::String) { loaded = ok; });
    for (int i = 0; i < 200 && ! loaded; ++i)
        pump (50);

    std::unique_ptr<juce::AudioProcessorEditor> editor (proc->createEditorAndMakeActive());
    editor->addToDesktop (juce::ComponentPeer::windowHasTitleBar);
    editor->setVisible (true);
    pump (4000);
    auto& browser = static_cast<libero::LiberoEditor*> (editor.get())->getBrowser();

    browser.evaluateJavascript (R"JS(
      (function () {
        window.__p = {};
        const fps = ms => new Promise(r => { let n = 0, worst = 0, last = performance.now(); const t0 = last;
          const f = () => { const now = performance.now(); worst = Math.max(worst, now - last); last = now; n++;
            if (now - t0 < ms) requestAnimationFrame(f); else r({ fps: Math.round(n * 1000 / (now - t0)), worstFrameMs: Math.round(worst) }); };
          requestAnimationFrame(f); });
        (async () => {
          const j = await import('/juce/index.js');
          let t = performance.now(); const s = await j.getNativeFunction('listSounds')();
          window.__p.listSoundsMs = Math.round(performance.now() - t);
          window.__p.listSoundsKB = Math.round(JSON.stringify(s).length / 1024);
          t = performance.now(); await j.getNativeFunction('listBanks')(); window.__p.listBanksMs = Math.round(performance.now() - t);
          window.__p.closed = await fps(2000);
          t = performance.now(); document.getElementById('lib-toggle').click();
          await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
          window.__p.openMs = Math.round(performance.now() - t);
          window.__p.open = await fps(2000);
          window.__p.domNodes = document.getElementsByTagName('*').length;
          window.__p.done = true;
        })().catch(e => { window.__p.error = String(e); });
        return 1; })())JS");

    juce::String result;
    for (int i = 0; i < 300; ++i)
    {
        pump (100);
        bool done = false;
        browser.evaluateJavascript ("JSON.stringify(window.__p || {})", [&] (juce::WebBrowserComponent::EvaluationResult r)
        {
            if (auto* v = r.getResult()) result = v->toString();
            done = true;
        });
        for (int k = 0; k < 50 && ! done; ++k) pump (10);
        if (result.contains ("\"done\":true") || result.contains ("\"error\"")) break;
    }

    std::cout << "ui-profile " << result << std::endl;
    audio.stopThread (2000);
    editor.reset();
    proc.reset();
    return 0;
}

int main (int argc, char* argv[])
{
    const auto arguments = libero::commandLineArguments (argc, argv);
    argc = arguments.size();
    juce::ScopedJuceInitialiser_GUI init;
    if (arguments.contains ("--dry-reverb-check"))
    {
        libero::Reverb room;
        room.prepare (48000);
        std::array<float, 32> left {}, right {};
        const auto setMix = [&] (float mix)
        {
            room.set (libero::RevMode::basilica, false, 0.7f, 8, 0, 0.3f, 1, 0, mix);
        };
        setMix (0);
        bool transparent = true;
        for (int block = 0; block < 1500; ++block)
        {
            left.fill (0.2f); right.fill (-0.1f);
            room.process (left.data(), right.data(), 32);
            for (int i = 0; i < 32; ++i)
                transparent = transparent && left[(size_t) i] == 0.2f && right[(size_t) i] == -0.1f;
        }
        const auto excite = [&]
        {
            double peak = 0;
            for (int block = 0; block < 1500; ++block)
            {
                left.fill (0); right.fill (0);
                if (block < 15) { left.fill (0.2f); right.fill (0.2f); }
                room.process (left.data(), right.data(), 32);
                if (block > 100)
                    for (int i = 0; i < 32; ++i)
                        peak = std::max (peak, (double) std::max (std::abs (left[(size_t) i]), std::abs (right[(size_t) i])));
            }
            return peak;
        };
        setMix (0.6f);
        const auto firstTail = excite();
        setMix (0);
        for (int block = 0; block < 3000; ++block)
        {
            left.fill (0); right.fill (0);
            room.process (left.data(), right.data(), 32);
        }
        setMix (0.6f);
        double ghost = 0;
        for (int block = 0; block < 1500; ++block)
        {
            left.fill (0); right.fill (0);
            room.process (left.data(), right.data(), 32);
            for (int i = 0; i < 32; ++i)
                ghost = std::max (ghost, (double) std::max (std::abs (left[(size_t) i]), std::abs (right[(size_t) i])));
        }
        const auto secondTail = excite();
        std::cout << "{\"dry_transparent\":" << transparent << ",\"initial_tail\":" << firstTail
                  << ",\"reactivated_tail\":" << secondTail << ",\"ghost_peak\":" << ghost << "}" << std::endl;
        return transparent && firstTail > 1.0e-4 && secondTail > 1.0e-4 && ghost < 1.0e-8 ? 0 : 1;
    }
    if (arguments.contains ("--stream-failure-check")) return performance::streamFailureCheck();
    if (argc > 2 && arguments[1] == "--stream-storage-check") return performance::streamStorageCheck (arguments[2]);
    if (argc > 2 && arguments[1] == "--resident-playback-profile")
        return performance::streamPlaybackProfile (arguments[2], argc > 3 ? juce::jlimit (1, 8, arguments[3].getIntValue()) : 1, false, argc > 4 ? arguments[4].getDoubleValue() : 48000.0, argc > 5 ? arguments[5].getIntValue() : 256);
    if (argc > 3 && arguments[1] == "--unheard-voice-check")
        return performance::unheardVoiceCheck (arguments[2], arguments[3]);
    if (argc > 2 && arguments[1] == "--voice-stress-profile")
        return performance::voiceStressProfile (arguments[2], argc > 3 ? arguments[3].getIntValue() : 4, argc > 4 ? arguments[4].getDoubleValue() : 96000, argc > 5 ? arguments[5].getIntValue() : 64);
    if (argc > 2 && arguments[1] == "--stream-realtime-profile")
        return performance::streamPlaybackProfile (arguments[2], argc > 3 ? juce::jlimit (1, 8, arguments[3].getIntValue()) : 1, true, argc > 4 ? arguments[4].getDoubleValue() : 48000.0, argc > 5 ? arguments[5].getIntValue() : 256, true, argc > 6 ? arguments[6].getDoubleValue() : 6);
    if (argc > 2 && arguments[1] == "--stream-playback-profile")
        return performance::streamPlaybackProfile (arguments[2], argc > 3 ? juce::jlimit (1, 8, arguments[3].getIntValue()) : 1, true, argc > 4 ? arguments[4].getDoubleValue() : 48000.0, argc > 5 ? arguments[5].getIntValue() : 256);
    if (argc > 2 && arguments[1] == "--streaming-check")
        return performance::streamingCheck (arguments[2], argc > 3 ? arguments[3].getDoubleValue() : 48000.0);
    if (argc > 2 && arguments[1] == "--midi-merge-check")
        return performance::midiMergeCheck (arguments[2]);
    if (argc > 2 && arguments[1] == "--audition-queue-check")
        return performance::auditionQueueCheck (arguments[2]);
    if (argc > 3 && arguments[1] == "--sound-transition-check")
        return performance::soundTransitionCheck (arguments[2], arguments[3]);
    if (arguments.contains ("--editor-size-check"))
        return performance::editorSizeCheck();
    if (argc > 2 && arguments[1] == "--loading-cache-check")
        return performance::loadingCheck (arguments[2]);

    if (argc > 2 && arguments[1] == "--audio-profile")
        return performance::audio (arguments[2], argc > 3 ? arguments[3].getDoubleValue() : 48000.0);
    if (argc > 2 && arguments[1] == "--load-profile")
        return performance::loadProfile (arguments[2], argc > 3 ? arguments[3].getDoubleValue() : 44100.0);
    if (argc > 2 && arguments[1] == "--sample-cache-check")
        return performance::sampleCacheCheck (arguments[2]);
    if (argc > 2 && arguments[1] == "--performance-profile")
        return performance::ui (arguments[2], argc > 3 ? juce::jlimit (1, 8, arguments[3].getIntValue()) : 1);

    if (argc > 2 && arguments[1] == "--initial-load-check")
        return performance::initialLoadCheck (arguments[2]);

    if (arguments.contains ("--visualisation-check"))
    {
        libero::LiberoProcessor proc;
        proc.setPlayConfigDetails (0, 2, 48000.0, 256);
        proc.prepareToPlay (48000.0, 256);
        juce::AudioBuffer<float> buffer (2, 256);
        juce::MidiBuffer midi;
        std::array<float, 64> left {}, right {};
        float level = 0.0f;
        libero::Voice::Playback playback;
        const auto process = [&] { buffer.clear(); proc.processBlock (buffer, midi); };
        process();
        const bool initiallyOff = ! proc.readScope (left, right, level) && ! proc.readSamplePlayback (playback);
        proc.setVisualisationActive (true);
        process();
        const bool active = proc.readScope (left, right, level) && proc.readSamplePlayback (playback);
        proc.setVisualisationActive (false);
        process();
        const bool stopped = ! proc.readScope (left, right, level) && ! proc.readSamplePlayback (playback);
        proc.setVisualisationActive (true);
        process();
        const bool resumed = proc.readScope (left, right, level) && proc.readSamplePlayback (playback);
        std::cout << "visualisation: default-off=" << initiallyOff << " active=" << active
                  << " stopped=" << stopped << " resumed=" << resumed << std::endl;
        return initiallyOff && active && stopped && resumed ? 0 : 1;
    }

    // Prints what the editor's resource provider serves for a URL (checks ui-override).
    if (argc > 2 && arguments[1] == "--resource")
    {
        const auto r = libero::LiberoEditor::getResource (arguments[2]);
        const auto text = r ? juce::String::fromUTF8 (reinterpret_cast<const char*> (r->data.data()), (int) r->data.size())
                            : juce::String();
        std::cout << (r ? r->mimeType : juce::String ("none")) << " " << text.substring (0, 80).replace ("\n", " ") << std::endl;
        return 0;
    }

    if (argc > 2 && arguments[1] == "--ui-profile")
        return runUiProfile (arguments[2]);

    if (argc > 2 && arguments[1] == "--sample-editor-data")
    {
        const juce::File folder (arguments[2]);
        const auto info = libero::LiberoProcessor::sampleEditorInfoForFolder (folder);
        auto* result = new juce::DynamicObject();
        result->setProperty ("info", info);
        if (const auto* zones = info["zones"].getArray(); zones != nullptr && ! zones->isEmpty())
            result->setProperty ("wave", libero::LiberoProcessor::sampleEditorWaveformForFolder (folder, (*zones)[0]["file"].toString()));
        std::cout << juce::JSON::toString (juce::var (result), true) << std::endl;
        return 0;
    }

    if (argc > 2 && arguments[1] == "--sample-editor-check")
        return runSampleEditorCheck (arguments[2], arguments.contains ("--ui"));

    if (argc > 2 && arguments[1] == "--ui-check")
        return runUiCheck (arguments[2], argc > 3 ? arguments[3] : juce::String(),
                           argc > 4 ? arguments[4] : juce::String());

    if (argc > 3 && arguments[1] == "--concurrent-validation-check")
    {
        juce::String error;
        const auto data = libero::SoundData::load (juce::File (arguments[2]), 48000, error, {}, true);
        if (! data) return 1;
        juce::WaitableEvent started;
        bool validated = false;
        juce::String validationError;
        double validationMs = 0;
        std::thread validation ([&]
        {
            const auto begin = juce::Time::getMillisecondCounterHiRes();
            started.signal();
            validated = data->validateStreamedAudio (validationError);
            validationMs = juce::Time::getMillisecondCounterHiRes() - begin;
        });
        started.wait();
        juce::Thread::sleep (20);
        const auto begin = juce::Time::getMillisecondCounterHiRes();
        const auto other = libero::SoundData::load (juce::File (arguments[3]), 48000, error);
        const auto loadMs = juce::Time::getMillisecondCounterHiRes() - begin;
        validation.join();
        std::cout << "{\"validation_ms\":" << validationMs << ",\"concurrent_load_ms\":" << loadMs << "}" << std::endl;
        return other && validated ? 0 : 1;
    }

    if (argc > 2 && arguments[1] == "--stream-validation-check")
    {
        const auto folder = libero::library::home().getChildFile ("validation-fixture");
        if (! juce::File (arguments[2]).copyDirectoryTo (folder)) return 1;
        juce::String error;
        const auto data = libero::SoundData::load (folder, 48000, error, {}, true);
        if (! data || ! data->validateStreamedAudio (error)) return 1;
        const libero::SampleStreamPool::Asset* asset = nullptr;
        for (const auto& zone : data->zones) if (zone.stream) { asset = zone.stream; break; }
        if (! asset) return 1;
        {
            juce::FileOutputStream stream (asset->file);
            if (! stream.openedOk() || ! stream.setPosition (asset->file.getSize() / 2)
                || stream.truncate().failed()) return 1;
        }
        const bool rejected = ! data->validateStreamedAudio (error);
        std::cout << "{\"full_scan\":true,\"truncated_scan_rejected\":" << (rejected ? "true" : "false") << "}" << std::endl;
        return rejected ? 0 : 1;
    }

    if (argc > 1 && arguments[1] == "--pack-store-status")
    { std::cout << juce::JSON::toString (libero::packs::status(), true) << std::endl; return 0; }
    if (argc > 1 && arguments[1] == "--pack-catalogue-refresh")
    { std::cout << juce::JSON::toString (libero::packs::catalogue (true), true) << std::endl; return 0; }
    if (argc > 1 && arguments[1] == "--pack-catalogue-check")
    {
        const auto value = libero::packs::catalogue (false)["catalog"];
        bool ok = libero::packs::validateCatalogue (value);
        auto bad = value.clone(); bad["packs"][0].getDynamicObject()->setProperty ("url", "file:///tmp/unsafe");
        ok = ok && ! libero::packs::validateCatalogue (bad);
        bad = value.clone(); bad["packs"][0].getDynamicObject()->setProperty ("sha256", "bad");
        ok = ok && ! libero::packs::validateCatalogue (bad);
        bad = value.clone(); bad["packs"][0].getDynamicObject()->setProperty ("id", "../unsafe");
        ok = ok && ! libero::packs::validateCatalogue (bad);
        ok = ok && !(bool) libero::packs::start ("unknown-id")["ok"];
        const auto marker = (const void*) &ok;
        libero::packs::setActiveSound (marker, libero::library::home().getChildFile ("banks/mog/test"));
        ok = ok && !(bool) libero::packs::start ("mog")["ok"];
        libero::packs::forgetInstance (marker);
        const auto pending = libero::packs::acquireSoundLoad (libero::library::home().getChildFile ("banks/mog/test"));
        ok = ok && !(bool) libero::packs::start ("mog")["ok"];
        std::cout << "{\"ok\":" << (ok ? "true" : "false") << "}" << std::endl;
        return ok ? 0 : 1;
    }
    if (argc > 2 && arguments[1] == "--pack-download-check")
    {
        if (juce::SystemStats::getEnvironmentVariable ("LIBERO_HOME", {}).isEmpty()) return 2;
        const auto mode = argc > 3 ? arguments[3] : juce::String();
        auto catalog = libero::packs::catalogue (false)["catalog"];
        if (mode == "bad-hash")
        {
            for (auto& p : *catalog["packs"].getArray()) if (p["id"].toString() == arguments[2])
                p.getDynamicObject()->setProperty ("sha256", juce::String::repeatedString ("0", 64));
            libero::packs::setCatalogueForTest (catalog);
        }
        if (mode == "application")
        {
            catalog["release"].getDynamicObject()->setProperty ("build", LIBERO_BUILD + 1);
            libero::packs::setCatalogueForTest (catalog);
        }
        const auto result = libero::packs::start (arguments[2], mode == "application");
        if (! (bool) result["ok"]) { std::cout << juce::JSON::toString (result) << std::endl; return 1; }
        bool cancelled = false;
        for (int i = 0; i < 2400; ++i)
        {
            const auto status = libero::packs::status();
            const auto state = status["state"].toString();
            if (mode == "cancel" && state == "downloading" && ! cancelled) { libero::packs::cancel(); cancelled = true; }
            if (state == "installed" || state == "ready" || state == "error" || state == "cancelled")
            {
                std::cout << juce::JSON::toString (status, true) << std::endl;
                return (mode == "bad-hash" ? state == "error" : mode == "cancel" ? state == "cancelled"
                        : mode == "application" ? state == "ready" : state == "installed") ? 0 : 1;
            }
            juce::Thread::sleep (50);
        }
        libero::packs::cancel(); return 1;
    }
    if (argc > 2 && arguments[1] == "--delete-bank")
    {
        const auto result = libero::library::deleteBank (arguments[2]);
        std::cout << juce::JSON::toString (result, true) << std::endl;
        return static_cast<bool> (result["ok"]) ? 0 : 1;
    }

    if (argc > 5 && arguments[1] == "--reconstruct-delta")
    {
        const auto result = libero::packs::reconstructDelta (juce::File (arguments[2]), juce::File (arguments[3]), arguments[4], arguments[5]);
        std::cout << juce::JSON::toString (libero::library::makeResult (result.wasOk(), result.getErrorMessage()), true) << std::endl;
        return result.wasOk() ? 0 : 1;
    }
    if (argc > 2 && (arguments[1] == "--inspect-bank" || arguments[1] == "--import-bank"))
    {
        if (juce::SystemStats::getEnvironmentVariable ("LIBERO_HOME", {}).isEmpty())
        {
            std::cerr << "Bank tests require an isolated LIBERO_HOME." << std::endl;
            return 2;
        }
        const juce::File pack { arguments[2] };
        const auto result = arguments[1] == "--inspect-bank"
            ? libero::library::inspectBank (pack) : libero::library::importBank (pack);
        std::cout << juce::JSON::toString (result, true) << std::endl;
        return static_cast<bool> (result["ok"]) ? 0 : 1;
    }

    if (argc > 3 && arguments[1] == "--export-bank")
    {
        const auto result = libero::library::exportBank (arguments[2], juce::File (arguments[3]));
        std::cout << juce::JSON::toString (result, true) << std::endl;
        return static_cast<bool> (result["ok"]) ? 0 : 1;
    }

    if (argc > 2 && arguments[1] == "--inspect-bank-collection")
    {
        juce::Array<juce::File> inputs;
        for (int i = 2; i < argc; ++i) inputs.add (juce::File (arguments[i]));
        const auto result = libero::library::inspectBankCollection (inputs);
        std::cout << juce::JSON::toString (result, true) << std::endl;
        return static_cast<bool> (result["ok"]) ? 0 : 1;
    }

    if (argc > 3 && arguments[1] == "--import-bank-collection-entry")
    {
        const auto result = libero::library::importBankCollectionEntry (arguments[2], arguments[3].getIntValue());
        std::cout << juce::JSON::toString (result, true) << std::endl;
        return static_cast<bool> (result["ok"]) ? 0 : 1;
    }

    if (argc > 2 && arguments[1] == "--cleanup-bank-collection")
    {
        const auto result = libero::library::cleanupBankCollection (arguments[2]);
        std::cout << juce::JSON::toString (result, true) << std::endl;
        return static_cast<bool> (result["ok"]) ? 0 : 1;
    }


    auto proc = std::make_unique<libero::LiberoProcessor>();
    proc->setPlayConfigDetails (0, 2, 48000.0, 256);
    proc->prepareToPlay (48000.0, 256);

    std::unique_ptr<juce::AudioProcessorEditor> interactiveEditor;
    std::unique_ptr<PreviewWindow> interactiveWindow;
    if (argc > 2 && arguments[1] == "--ui-live")
    {
        bool loaded = false;
        proc->loadSound (juce::File (arguments[2]), true, [&loaded] (bool, juce::String) { loaded = true; });
        for (int i = 0; i < 300 && ! loaded; ++i) pump (20);
        interactiveEditor.reset (proc->createEditorAndMakeActive());
        interactiveWindow = std::make_unique<PreviewWindow> (*interactiveEditor);
    }

    FakeAudioThread audio (*proc);
    audio.startThread (juce::Thread::Priority::high);

    std::cout << "{\"port\": " << proc->getAgentPort() << "}" << std::endl;

    std::atomic<bool> quit { false };
    std::thread stdinWatcher ([&quit]
    {
        std::string line;
        while (std::getline (std::cin, line)) {}
        quit = true;
    });

    while (! quit.load())
        juce::MessageManager::getInstance()->runDispatchLoopUntil (20);

    stdinWatcher.join();

    audio.stopThread (2000);

    if (const auto capturePath = juce::SystemStats::getEnvironmentVariable ("LIBERO_CAPTURE", {}); capturePath.isNotEmpty())
        writeCapture (audio, capturePath);

    // State round trip into a fresh instance.
    constexpr float caldiValues[] = {3.f, .7f, .2f, .8f, .3f, .4f, -2.f};
    for (int i=(int) libero::P::caldi_mode; i<=(int)libero::P::caldi_output; ++i)
    {
        auto* parameter=proc->getState().getParameter(libero::spec(i).id);
        parameter->setValueNotifyingHost(parameter->convertTo0to1(caldiValues[i-(int)libero::P::caldi_mode]));
    }
    juce::MemoryBlock state;
    proc->getStateInformation (state);
    const auto soundBefore = proc->getCurrentSoundPath();
    const auto cutoffBefore = proc->getState().getRawParameterValue ("flt_cutoff")->load();
    const auto revModeBefore = proc->getState().getRawParameterValue ("rev_mode")->load();

    auto restored = std::make_unique<libero::LiberoProcessor>();
    restored->setPlayConfigDetails (0, 2, 48000.0, 256);
    restored->prepareToPlay (48000.0, 256);
    restored->setStateInformation (state.getData(), (int) state.getSize());

    for (int i = 0; i < 100 && restored->getCurrentSoundPath() != soundBefore; ++i)
        pump (50);

    const auto stateOk = restored->getCurrentSoundPath() == soundBefore
                      && restored->getState().getRawParameterValue ("flt_cutoff")->load() == cutoffBefore
                      && restored->getState().getRawParameterValue ("rev_mode")->load() == revModeBefore;

    bool caldiRoundtrip=true;
    for (int i=(int) libero::P::caldi_mode; i<=(int)libero::P::caldi_output; ++i)
        caldiRoundtrip &= std::abs(restored->getState().getRawParameterValue(libero::spec(i).id)->load()
                                  - caldiValues[i-(int)libero::P::caldi_mode])<1e-5f;
    // A genuine legacy XML contains none of the new parameter nodes. Restore
    // it into the same already-enabled instance, not just a fresh processor.
    auto legacyTree=proc->getState().copyState();
    for(int i=legacyTree.getNumChildren()-1;i>=0;--i)
        if(legacyTree.getChild(i).getProperty("id").toString().startsWith("caldi_"))
            legacyTree.removeChild(i,nullptr);
    legacyTree.setProperty("soundPath", "", nullptr);
    juce::MemoryBlock legacy;
    if(auto xml=legacyTree.createXml()) juce::AudioProcessor::copyXmlToBinary(*xml,legacy);
    restored->setStateInformation(legacy.getData(),(int)legacy.getSize());
    bool caldiLegacy=true;
    for (int i=(int) libero::P::caldi_mode; i<=(int)libero::P::caldi_output; ++i)
        caldiLegacy &= std::abs(restored->getState().getRawParameterValue(libero::spec(i).id)->load()-libero::spec(i).def)<1e-5f;
    restored->getState().getParameter("caldi_mode")->setValueNotifyingHost(.6f);
    restored->resetSound();
    const bool caldiReset=restored->getState().getRawParameterValue("caldi_mode")->load()<.5f;

    restored.reset();
    proc.reset();

    std::cout << "{\"blocks\": " << audio.blocks.load()
              << ", \"peak\": " << audio.peak.load()
              << ", \"non_finite\": " << (audio.nonFinite.load() ? "true" : "false")
              << ", \"state_roundtrip\": " << (stateOk ? "true" : "false")
              << ", \"caldi_roundtrip\": " << (caldiRoundtrip ? "true" : "false")
              << ", \"caldi_legacy_bypass\": " << (caldiLegacy ? "true" : "false")
              << ", \"caldi_reset_bypass\": " << (caldiReset ? "true" : "false")
              << ", \"sound\": " << juce::JSON::toString (soundBefore) << "}" << std::endl;
    return 0;
}
