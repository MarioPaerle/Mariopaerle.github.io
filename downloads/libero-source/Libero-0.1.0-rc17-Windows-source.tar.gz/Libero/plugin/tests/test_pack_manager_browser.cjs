// Run against a UI preview server; all browser windows remain headless.
const { chromium } = require(process.env.LIBERO_PLAYWRIGHT || 'playwright');
(async () => {
  const browser = await chromium.launch({ headless: true, ...(process.env.LIBERO_CHROME ? { executablePath: process.env.LIBERO_CHROME } : {}) });
  try {
    const page = await browser.newPage();
    const errors = []; page.on('pageerror', e => errors.push(e.message));
    await page.goto(process.env.LIBERO_UI_URL || 'http://127.0.0.1:8793/?drawer&agent=0');
    await page.getByRole('button', { name: 'Pack Manager and Downloader…', exact: true }).waitFor();
    await page.getByRole('button', { name: 'Libero updates…', exact: true }).click();
    await page.getByRole('heading', { name: 'Libero updates', exact: true }).waitFor();
    if (await page.locator('dialog.pack-manager').getByRole('searchbox').count()) throw Error('App updates includes pack search');
    await page.locator('dialog.pack-manager button').filter({ hasText: /^Close$/ }).click();
    await page.locator('dialog.pack-manager').waitFor({ state: 'detached' });
    await page.evaluate(async () => {
      const mod = await import('/js/pack-manager.js');
      window.fixture = { banks: [{slug:'test',title:'Test pack',version:'1.0.0',count:1}], job:{state:'idle'}, refreshes:0 };
      const fixture = window.fixture;
      const catalogue = { packs:[{id:'test',title:'Test pack',version:'1.0.0',sounds:12,bytes:1000}],release:{build:0} };
      const bridge = { call: async name => {
        if (name === 'packCatalogue') return {ok:true,catalog:catalogue,currentBuild:15,currentVersion:'test',platform:'macos',offline:false};
        if (name === 'listBanks') return fixture.banks;
        if (name === 'packDownloadStatus') return {...fixture.job};
        if (name === 'downloadPack') {
          fixture.job={id:'test',jobId:'repair',state:'downloading',received:100,total:1000};
          setTimeout(()=>{fixture.banks[0].count=12; fixture.job={...fixture.job,state:'installed',received:1000};},1800);
          return {ok:true};
        }
        throw Error(name);
      }};
      const options={refreshLibrary:async()=>{fixture.refreshes++;},deletePack:()=>{},openPack:()=>{},toast:()=>{}};
      mod.monitorPackDownloads(bridge,options.refreshLibrary)();
      window.openFixture=()=>mod.showPackManager(bridge,options);
      window.openFixture();
    });
    await page.getByRole('button', { name:'Repair download', exact:true }).click();
    await page.getByRole('button', { name:'Replace & repair', exact:true }).click();
    await page.getByRole('button', { name:'Cancel download', exact:true }).waitFor();
    await page.getByRole('button', { name:'Close pack manager' }).click();
    await page.locator('dialog.pack-manager').waitFor({state:'detached'});
    await page.evaluate(()=>window.openFixture());
    await page.getByRole('button', {name:'Cancel download',exact:true}).waitFor();
    await page.getByRole('button', {name:'Close pack manager'}).click();
    await page.locator('dialog.pack-manager').waitFor({state:'detached'});
    await page.waitForFunction(()=>window.fixture.refreshes===1);
    await page.evaluate(()=>window.openFixture());
    await page.getByText('Installed · v1.0.0 · 12 sounds',{exact:true}).waitFor();
    if(await page.getByRole('button',{name:'Repair download',exact:true}).count()) throw Error('Complete pack still marked incomplete');
    if (errors.length) throw Error(errors.join('\n'));
    console.log('PASS: separate updates; partial repair; close/reopen during download; completion while closed; full inventory on reopen.');
  } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1;});
