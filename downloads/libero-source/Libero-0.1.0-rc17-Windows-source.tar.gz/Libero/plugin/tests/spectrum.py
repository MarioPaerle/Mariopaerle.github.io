#!/usr/bin/env python3
"""Small stdlib spectral helpers for the oscillator tests: radix-2 FFT, complex Goertzel."""
import cmath
import math


def fft(x):
    n = len(x)
    if n == 1:
        return [complex(x[0])]
    even, odd = fft(x[0::2]), fft(x[1::2])
    out = [0j] * n
    for k in range(n // 2):
        t = cmath.exp(-2j * math.pi * k / n) * odd[k]
        out[k] = even[k] + t
        out[k + n // 2] = even[k] - t
    return out


def window(n):
    """4-term Blackman-Harris: side lobes below -92 dB, so leakage doesn't pass for aliasing."""
    a0, a1, a2, a3 = 0.35875, 0.48829, 0.14128, 0.01168
    return [a0 - a1 * math.cos(2 * math.pi * i / (n - 1)) + a2 * math.cos(4 * math.pi * i / (n - 1))
            - a3 * math.cos(6 * math.pi * i / (n - 1)) for i in range(n)]


def power_spectrum(x):
    """Blackman-Harris-windowed power spectrum of len(x) (a power of two) samples, bins 0..n/2."""
    w = window(len(x))
    X = fft([a * b for a, b in zip(x, w)])
    return [abs(c) ** 2 for c in X[:len(x) // 2 + 1]]


def alias_report(x, rate, f0):
    """(worst alias component dB re the fundamental, total non-harmonic energy dB re total).
    Harmonic bins (±6 around k*f0 < Nyquist) are signal; everything else counts as aliasing/noise."""
    n = len(x)
    p = power_spectrum(x)
    binhz = rate / n
    harmonic = set()
    k = 1
    while k * f0 < rate / 2:
        c = int(round(k * f0 / binhz))
        harmonic.update(range(c - 6, c + 7))
        k += 1
    total = sum(p[2:])
    fund = max(p[int(f0 / binhz) - 3:int(f0 / binhz) + 4])
    rest = [v for i, v in enumerate(p) if i > 2 and i not in harmonic]
    worst = max(rest) if rest else 1e-30
    return 10 * math.log10(worst / fund + 1e-30), 10 * math.log10(sum(rest) / total + 1e-30)


def goertzel(x, f, rate):
    """Complex amplitude of frequency f in x (rectangular window; use a whole number of cycles)."""
    w = 2 * math.pi * f / rate
    c = 2 * math.cos(w)
    s1 = s2 = 0.0
    for v in x:
        s1, s2 = v + c * s1 - s2, s1
    re = s1 - s2 * math.cos(w)
    im = s2 * math.sin(w)
    # phase referred to the first sample
    n = len(x)
    z = complex(re, im) * cmath.exp(-1j * w * (n - 1))
    return z * 2 / n
