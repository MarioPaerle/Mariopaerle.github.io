#!/usr/bin/env python3
"""Live oscillators, LFO, filter envelope and onset_ms (SPEC §5, §4), measured on libero-render output.

    test_osc.py <libero-render> <fixtures dir>
"""

import cmath
import filecmp
import json
import math
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from wavstats import read, stats  # noqa: E402
from pitchtrack import midi_zc  # noqa: E402
from spectrum import alias_report, goertzel  # noqa: E402

failures = []
OUT = Path(__file__).parent / 'out'
DRY = {'rev_mix': 0, 'lvl_air': -60, 'osc_drift': 0, 'osc_retrig': 'Riavvia', 'amp_attack': 5, 'vel_sens': 0}


def check(cond, what):
    print(('ok   ' if cond else 'FAIL ') + what)
    if not cond:
        failures.append(what)


def render(exe, out, notes, params, extra=(), sound=None):
    cmd = [exe, '--out', str(out), '--notes', notes, '--params', json.dumps(params)] + list(extra)
    if sound:
        cmd += ['--sound', str(sound)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(r.stderr)
    return read(out)


def hz(n):
    return 440 * 2 ** ((n - 69) / 12)


def db(x):
    return 20 * math.log10(max(x, 1e-12))


def main():
    exe, fixtures = sys.argv[1], Path(sys.argv[2])
    OUT.mkdir(exist_ok=True)
    report = {}

    # ---- Aliasing: band-limited tables at C8 (and below) at 44.1 kHz.
    worst = {}
    for wave in ['Sega', 'Quadra', 'Triangolo']:
        for note in [84, 96, 108]:
            rate, _, ch = render(exe, OUT / 'osc_alias.wav', f'{note}:0:1:100',
                                 dict(DRY, osc1_level=-12, osc1_wave=wave, osc1_pw=0.3), ['--sr', '44100', '--tail', '0'])
            w, _ = alias_report(ch[0][int(0.2 * rate):int(0.2 * rate) + 32768], rate, hz(note))
            worst[(wave, note)] = w
    report['alias_db'] = {f'{w} {n}': round(v, 1) for (w, n), v in worst.items()}
    check(max(worst.values()) < -60, f'no aliasing: worst component {max(worst.values()):.1f} dB re fundamental '
                                     f'(saw C8 {worst[("Sega", 108)]:.1f}, square C8 {worst[("Quadra", 108)]:.1f})')

    # ---- Tuning across the range (sine, no drift).
    errs = []
    for note in [24, 45, 60, 81, 96, 108]:
        rate, _, ch = render(exe, OUT / 'osc_tune.wav', f'{note}:0:1:100', dict(DRY, osc1_level=-12, osc1_wave='Seno'))
        errs.append((midi_zc(ch, rate, 0.2, 0.9) - note) * 100)
    check(max(abs(e) for e in errs) < 0.5, f'tuning within 0.5 cent from C1 to C8: {[round(e, 3) for e in errs]}')

    # ---- L/R phase offset: expected phase difference, mono loss 20·log10|cos(pi·x)|.
    offsets = [0.0, 0.125, 0.25, 0.375, 0.5]
    mono = {}
    ref_mono = None
    ok = True
    for x in offsets:
        rate, _, (L, R) = render(exe, OUT / 'osc_phase.wav', '69:0:1.2:100', dict(DRY, osc1_level=-12, osc1_wave='Seno', osc1_phase=x))
        a, b = int(0.2 * rate), int(0.2 * rate) + rate
        zl, zr = goertzel(L[a:b], 440, rate), goertzel(R[a:b], 440, rate)
        diff = (cmath.phase(zr) - cmath.phase(zl)) / (2 * math.pi) % 1.0
        zm = goertzel([(p + q) * 0.5 for p, q in zip(L[a:b], R[a:b])], 440, rate)
        if ref_mono is None:
            ref_mono = abs(zm)
        mono[x] = db(abs(zm) / ref_mono)
        expected = db(abs(math.cos(math.pi * x)))
        ok = ok and min(abs(diff - x), 1 - abs(diff - x)) < 0.002 and (abs(mono[x] - expected) < 0.1 or (x == 0.5 and mono[x] < -60))
    report['mono_loss_db'] = {x: round(v, 2) for x, v in mono.items()}
    check(ok, f'L/R phase offset is exact; mono loss per offset {report["mono_loss_db"]}')

    # A saw at half a cycle loses its odd harmonics in mono, keeps the even ones.
    rate, _, (L, R) = render(exe, OUT / 'osc_phase.wav', '57:0:1.2:100', dict(DRY, osc1_level=-12, osc1_phase=0.5))
    a, b = int(0.2 * rate), int(0.2 * rate) + rate
    m = [(p + q) * 0.5 for p, q in zip(L[a:b], R[a:b])]
    h1, h2 = abs(goertzel(m, 220, rate)), abs(goertzel(m, 440, rate))
    h1l = abs(goertzel(L[a:b], 220, rate))
    check(db(h1 / h1l) < -60 and db(h2 / h1l) > -12,
          f'saw at 180°: mono odd harmonics {db(h1 / h1l):.0f} dB, even kept at {db(h2 / h1l):.1f} dB')

    # ---- Unison: 8 voices at detune 1 sit at ±60, ±42.9, ±25.7, ±8.6 cents.
    rate, _, (L, R) = render(exe, OUT / 'osc_unison.wav', '69:0:3.5:100',
                             dict(DRY, osc1_level=-12, osc1_wave='Seno', osc1_voices=8, osc1_detune=1, osc1_spread=0))
    seg = L[int(0.3 * rate):int(3.3 * rate)]
    expect = [60 * (2 * v / 7 - 1) for v in range(8)]
    peaks = [abs(goertzel(seg, 440 * 2 ** (c / 1200), rate)) for c in expect]
    off = [abs(goertzel(seg, 440 * 2 ** (c / 1200), rate)) for c in (-80, 80, -34, 34)]
    check(min(peaks) > 0.8 * max(peaks) and max(off) < 0.2 * min(peaks),
          f'unison detune: 8 components at {[round(c, 1) for c in expect]} cents '
          f'(spread {db(min(peaks) / max(peaks)):.2f} dB), none in between')

    # ---- Drift: bounded, varying, deterministic.
    params = dict(DRY, osc1_level=-12, osc1_wave='Seno', osc_drift=1, osc_retrig='Libera')
    rate, _, ch = render(exe, OUT / 'osc_drift_a.wav', '69:0:6:100', params)
    render(exe, OUT / 'osc_drift_b.wav', '69:0:6:100', params)
    cents = [(midi_zc(ch, rate, t, t + 0.2) - 69) * 100 for t in [0.2 + 0.2 * k for k in range(28)]]
    check(filecmp.cmp(OUT / 'osc_drift_a.wav', OUT / 'osc_drift_b.wav', shallow=False)
          and max(abs(c) for c in cents) < 7.5 and max(cents) - min(cents) > 0.5,
          f'drift deterministic and bounded: {min(cents):+.2f}..{max(cents):+.2f} cents (limit ±7)')

    # ---- LFO: vibrato rate and depth, tremolo depth, delayed fade-in.
    rate, _, ch = render(exe, OUT / 'osc_vib.wav', '69:0:3:100',
                         dict(DRY, osc1_level=-12, osc1_wave='Seno', lfo_pitch=50, lfo_rate=4))
    track = [(midi_zc(ch, rate, t, t + 0.02) - 69) * 100 for t in [0.5 + 0.01 * k for k in range(200)]]
    mean = sum(track) / len(track)
    ups = [k * 0.01 for k, (a, b) in enumerate(zip(track, track[1:])) if (a - mean) < 0 <= (b - mean)]
    rate_hz = (len(ups) - 1) / (ups[-1] - ups[0]) if len(ups) > 2 else 0
    check(abs((max(track) - min(track)) / 2 - 50) < 8 and abs(rate_hz - 4) < 0.2,
          f'vibrato ±{(max(track) - min(track)) / 2:.1f} cents at {rate_hz:.2f} Hz (asked ±50 at 4 Hz)')

    rate, _, ch = render(exe, OUT / 'osc_trem.wav', '69:0:2:100',
                         dict(DRY, osc1_level=-12, osc1_wave='Seno', lfo_amp=1, lfo_rate=2))
    w = int(0.01 * rate)
    env = [math.sqrt(sum(v * v for v in ch[0][i:i + w]) / w) for i in range(int(0.3 * rate), int(1.8 * rate), w)]
    check(db(min(env) / max(env)) < -25, f'tremolo at depth 1 swings {db(min(env) / max(env)):.1f} dB')

    rate, _, ch = render(exe, OUT / 'osc_delay.wav', '69:0:2.5:100',
                         dict(DRY, osc1_level=-12, osc1_wave='Seno', lfo_pitch=50, lfo_rate=5, lfo_delay=1000))
    early = [(midi_zc(ch, rate, t, t + 0.02) - 69) * 100 for t in [0.05 + 0.01 * k for k in range(15)]]
    late = [(midi_zc(ch, rate, t, t + 0.02) - 69) * 100 for t in [1.5 + 0.01 * k for k in range(40)]]
    check(max(abs(x) for x in early) < 12 and max(late) - min(late) > 80,
          f'lfo_delay fades the LFO in (first 0.2 s ±{max(abs(x) for x in early):.1f} ct, after 1.5 s ±{(max(late) - min(late)) / 2:.1f} ct)')

    # ---- Oscillator-only bundle (zones: []) and no bundle at all.
    r1 = subprocess.run([exe, '--sound', str(fixtures / 'test-osc'), '--out', str(OUT / 'osc_only.wav'),
                         '--notes', '60:0:1:100'], capture_output=True, text=True)
    s1 = stats(OUT / 'osc_only.wav') if r1.returncode == 0 else {'rms': 0}
    render(exe, OUT / 'osc_none.wav', '60:0:1:100', {'osc1_level': -6})
    render(exe, OUT / 'osc_silent.wav', '60:0:1:100', {})
    s2, s3 = stats(OUT / 'osc_none.wav'), stats(OUT / 'osc_silent.wav')
    check(r1.returncode == 0 and db(s1['rms']) > -40 and db(s2['rms']) > -40 and s3['peak'] == 0,
          f'osc-only bundle plays ({db(s1["rms"]):.1f} dB rms), no bundle plays with osc1 on '
          f'({db(s2["rms"]):.1f} dB) and is silent with everything off')

    # ---- Three independently tunable, live subharmonic branches (Mixtur ratios 1:2:3:4).
    rate, _, ch = render(exe, OUT / 'subharmonics.wav', '60:0:1.4:100',
                         dict(DRY, osc1_level=-60, sub_wave='Sega', sub_level=-12, sub_divisor=2,
                              sub2_level=-12, sub2_divisor=3, sub3_level=-12, sub3_divisor=4))
    a, b = int(0.2 * rate), int(1.2 * rate)
    x = ch[0][a:b]
    components = [abs(goertzel(x, hz(60) / d, rate)) for d in (2, 3, 4)]
    check(min(components) > 0.01 and max(components) / min(components) < 2.0,
          f'live subharmonic branches sound at master/2, /3, /4: {[round(v, 4) for v in components]}')

    # ---- CC1 timbre sweep moves an absolute-frequency filter profile, independently of pitch.
    common = dict(DRY, osc1_level=-12, osc1_wave='Sega', flt_mode='Vocale', flt_cutoff=900,
                  flt_dyn=3, amp_dyn=0, dyn_mode='Modulazione', dynamics=.5)
    lo_rate, _, lo = render(exe, OUT / 'formant_cc_low.wav', '57:0:1.4:100', common,
                            ['--cc', '0:1:0'])
    hi_rate, _, hi = render(exe, OUT / 'formant_cc_high.wav', '57:0:1.4:100', common,
                            ['--cc', '0:1:127'])
    # Compare fixed absolute partial bands; pitch is identical while the controller moves.
    aa, bb = int(.2 * lo_rate), int(1.2 * lo_rate)
    lo_ratio = db(abs(goertzel(lo[0][aa:bb], 2640, lo_rate)) / abs(goertzel(lo[0][aa:bb], 220, lo_rate)))
    hi_ratio = db(abs(goertzel(hi[0][aa:bb], 2640, hi_rate)) / abs(goertzel(hi[0][aa:bb], 220, hi_rate)))
    check(abs(hi_ratio - lo_ratio) > 3,
          f'CC1 expression reshapes the fixed-Hz formant profile at constant pitch: {lo_ratio:.1f} -> {hi_ratio:.1f} dB')

    # ---- Filter envelope (Propria): rises over the attack, falls with the decay.
    rate, _, ch = render(exe, OUT / 'fenv.wav', '48:0:2:100',
                         dict(DRY, osc1_level=-12, fenv_source='Propria', fenv_attack=250, fenv_decay=400, fenv_sustain=0,
                              flt_env=0.6, flt_cutoff=300))

    def hf(t):
        a, b = int(t * rate), int((t + 0.04) * rate)
        x = ch[0]
        return 10 * math.log10(sum((x[i] - x[i - 1]) ** 2 for i in range(a + 1, b)) / (b - a) + 1e-20)
    h_early, h_peak, h_late = hf(0.02), hf(0.23), hf(1.2)
    check(h_peak - h_early > 6 and h_peak - h_late > 6,
          f'filter envelope: brightness {h_early:.1f} -> {h_peak:.1f} (250 ms) -> {h_late:.1f} dB')

    # Velocity to cutoff and key tracking.
    def bright(note, vel, params, cutoff=500):
        rate, _, ch = render(exe, OUT / 'ftrack.wav', f'{note}:0:0.6:{vel}', dict(DRY, osc1_level=-12, flt_cutoff=cutoff, flt_reso=0, **params))
        x = ch[0][int(0.2 * rate):int(0.5 * rate)]
        f0 = hz(note)
        return db(abs(goertzel(x, 2 * f0, rate)) / abs(goertzel(x, f0, rate)))
    v_lo, v_hi = bright(60, 20, {'flt_vel': 1}, 120), bright(60, 127, {'flt_vel': 1}, 120)
    check(v_hi - v_lo > 6, f'flt_vel: 2nd harmonic {v_lo:.1f} dB at velocity 20, {v_hi:.1f} dB at 127')
    k0 = abs(bright(72, 100, {}) - bright(48, 100, {}))
    k1 = abs(bright(72, 100, {'flt_key': 1}) - bright(48, 100, {'flt_key': 1}))
    check(k0 - k1 > 6, f'flt_key 1 keeps the tone across two octaves (2nd-harmonic difference {k0:.1f} dB -> {k1:.1f} dB)')

    # ---- Phase motion: the L/R offset moves slowly; 0 keeps it still.
    def phases(mod):
        rate, _, (L, R) = render(exe, OUT / 'pmod.wav', '69:0:3.3:100',
                                 dict(DRY, osc1_level=-12, osc1_wave='Seno', osc1_phase=0.25, osc1_phase_mod=mod))
        out = []
        for t in [0.2 + 0.1 * k for k in range(30)]:
            a, b = int(t * rate), int(t * rate) + int(rate * 0.1)
            out.append(math.degrees(cmath.phase(goertzel(R[a:b], 440, rate)) - cmath.phase(goertzel(L[a:b], 440, rate))) % 360)
        return out
    p0, p1 = phases(0), phases(1)
    check(max(p0) - min(p0) < 0.5 and max(p1) - min(p1) > 40,
          f'phase motion: offset range {max(p0) - min(p0):.2f}° at 0, {max(p1) - min(p1):.0f}° at 1')

    # ---- onset_ms: the pre-roll is skipped, so the strike lands at note-on.
    def first(path):
        rate, _, ch = read(path)
        return next(i for i, v in enumerate(ch[0]) if abs(v) > 1e-3) / rate * 1000
    subprocess.run([exe, '--sound', str(fixtures / 'test-onset'), '--out', str(OUT / 'onset.wav'), '--notes', '60:0.1:0.5:100',
                    '--params', json.dumps({'rev_mix': 0, 'lvl_air': -60})], capture_output=True, check=True)
    subprocess.run([exe, '--sound', str(fixtures / 'test-onset-ref'), '--out', str(OUT / 'onset_ref.wav'), '--notes', '60:0.1:0.5:100',
                    '--params', json.dumps({'rev_mix': 0, 'lvl_air': -60})], capture_output=True, check=True)
    o1, o2 = first(OUT / 'onset.wav') - 100, first(OUT / 'onset_ref.wav') - 100
    check(0 <= o1 < 1.5 and 19 < o2 < 21, f'onset_ms 20: sound starts {o1:.2f} ms after note-on (undeclared pre-roll: {o2:.2f} ms)')

    # ---- CPU: 16 voices x 2 oscillators x 8 unison, L/R offset on both (stereo reads), sub on.
    heavy = dict(rev_mix=0, voices=16, osc1_level=-12, osc2_level=-12, osc1_voices=8, osc2_voices=8, osc1_detune=0.5,
                 osc2_detune=0.5, osc1_phase=0.25, osc2_phase=0.3, osc2_wave='Quadra', sub_level=-12)
    notes = ','.join(f'{36 + 3 * i}:0:10:100' for i in range(16))
    before = time.perf_counter() if sys.platform == 'win32' else __import__('resource').getrusage(__import__('resource').RUSAGE_CHILDREN).ru_utime
    subprocess.run([exe, '--out', str(OUT / 'cpu.wav'), '--notes', notes, '--tail', '0', '--params', json.dumps(heavy)],
                   capture_output=True, check=True)
    used = (time.perf_counter() if sys.platform == 'win32' else __import__('resource').getrusage(__import__('resource').RUSAGE_CHILDREN).ru_utime) - before
    if sys.platform == 'win32':
        report['cpu'] = f'{used:.2f} s wall time for 10 s of audio, 16 voices x 2 osc x 8 unison ({used / 10:.3f} of real time)'
    else:
        report['cpu'] = (f'{used:.2f} s CPU for 10 s of audio, 16 voices x 2 osc x 8 unison (stereo phase on both, sub on): '
                         f'{used * 10:.1f} % of one core, {used * 10 / 16:.2f} % per voice')
    print('info', report['cpu'])

    print('report', json.dumps(report))
    print(f'\n{len(failures)} failure(s)')
    sys.exit(1 if failures else 0)


if __name__ == '__main__':
    main()
