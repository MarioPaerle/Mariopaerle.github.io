#!/usr/bin/env python3
"""Agent socket test (SPEC §6) against libero-host-test, a headless host for LiberoProcessor.

    test_socket.py <libero-host-test> <fixture sound folder>

Uses a private LIBERO_HOME so the real ~/Libero is never touched.
"""

import json
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

failures = []


def check(cond, what):
    print(('ok   ' if cond else 'FAIL ') + what)
    if not cond:
        failures.append(what)


class Client:
    def __init__(self, port):
        self.sock = socket.create_connection(('127.0.0.1', port), timeout=30)
        self.buf = b''
        self.next_id = 1

    def raw(self, line):
        self.sock.sendall(line.encode() + b'\n')
        while b'\n' not in self.buf:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError('closed')
            self.buf += chunk
        line, self.buf = self.buf.split(b'\n', 1)
        return json.loads(line)

    def call(self, method, **params):
        rid = self.next_id
        self.next_id += 1
        resp = self.raw(json.dumps({'id': rid, 'method': method, 'params': params}))
        assert resp.get('id') == rid, resp
        return resp

    def close(self):
        self.sock.close()


def worst_transient(path):
    """Largest ratio between a 10 ms window's peak |2nd difference| and the steady state
    around it (median of the surrounding 400 ms). Clicks stand out; notes that start
    smoothly don't."""
    sys.path.insert(0, str(Path(__file__).parent))
    from wavstats import read
    rate, _, ch = read(path)
    w = int(0.01 * rate)
    # Only look after the last stretch of silence (the chord + swap part of the test).
    start, quiet = 2, 0
    for i in range(0, len(ch[0]) - w, w):
        loud = max(abs(v) for c in ch for v in c[i:i + w]) > 1e-4
        if loud and quiet >= 20:
            start = max(2, i - 20 * w)   # onset after the last long silence (the chord)
        quiet = 0 if loud else quiet + 1
    peaks = []
    for i in range(max(2, start), len(ch[0]) - w, w):
        peaks.append(max(abs(c[j] - 2 * c[j - 1] + c[j - 2]) for c in ch for j in range(i, i + w)))
    worst, at = 0.0, 0.0
    for k in range(20, len(peaks) - 20):
        around = sorted(peaks[k - 20:k - 2] + peaks[k + 3:k + 21])
        ref = around[len(around) // 2]
        if ref > 1e-4 and peaks[k] / ref > worst:
            worst, at = peaks[k] / ref, start / rate + k * 0.01
    return worst, at


def start_host(exe, env):
    p = subprocess.Popen([exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE, env=env, text=True)
    first = json.loads(p.stdout.readline())
    return p, first['port']


def main():
    exe, fixture = sys.argv[1], Path(sys.argv[2])
    home = Path(__file__).parent / 'out' / 'libero-home'
    if home.exists():
        shutil.rmtree(home)
    (home / 'sketches').mkdir(parents=True)
    (home / 'instances').mkdir(parents=True)
    sketch = home / 'sketches' / 'test-tone'
    shutil.copytree(fixture, sketch)

    stale = home / 'instances' / 'dead00.json'
    stale.write_text(json.dumps({'id': 'dead00', 'port': 47899, 'pid': 999999}))

    noir = home / 'sketches' / 'test-noir'
    shutil.copytree(fixture.parent / 'test-noir', noir)
    capture = Path(__file__).parent / 'out' / 'host_capture.wav'

    env = dict(os.environ, LIBERO_HOME=str(home))
    host, port = start_host(exe, dict(env, LIBERO_CAPTURE=str(capture)))
    host2, port2 = start_host(exe, env)

    try:
        check(47800 <= port <= 47899, f'listening on {port}')
        check(port2 != port and 47800 <= port2 <= 47899, f'second instance on its own port {port2}')
        check(not stale.exists(), 'stale instance file removed')

        files = {json.loads(f.read_text())['port']: json.loads(f.read_text()) for f in (home / 'instances').glob('*.json')}
        check(port in files and files[port]['pid'] == host.pid, 'instance file written with pid and port')

        c = Client(port)
        info = c.call('info')['result']
        check(info['sample_rate'] == 48000 and info['block_size'] == 256 and info['sound'] == '', f'info {info}')

        r = c.call('load', path=str(sketch))
        check(r.get('result', {}).get('ok') is True and r['result']['title'] == 'Test Tone', f'load {r}')

        r = c.call('load', path=str(home / 'nope'))
        check('error' in r, f'load of a missing bundle fails: {r.get("error")}')

        p = c.call('get_params')['result']
        check(len(p) == 110, f'get_params returns all 110 params ({len(p)})')
        check(p.get('caldi_mode') == 'Spento' and p.get('caldi_grain') == 0 and p.get('caldi_motion') == 0,
              'old manifest loads Caldi bypass with optional texture/motion off')
        check(p['mode'] == 'Poli', 'mode defaults to Poli')
        check(abs(p['amp_release'] - 600) < 0.5 and p['rev_mode'] == 'Basilica' and abs(p['rev_mix'] - 0.25) < 1e-4,
              'manifest params applied on load')
        check(p['flt_mode'] == 'Basso' and p['voices'] == 16, 'defaults for params missing from the manifest')

        r = c.call('set_params', values={'mode': 'Legato'})['result']
        check(r['applied'] == ['mode'] and c.call('get_params', ids=['mode'])['result']['mode'] == 'Legato',
              'mode is settable over the socket')
        c.call('set_params', values={'mode': 'Poli'})

        r = c.call('set_params', values={'flt_cutoff': 1000, 'rev_mode': 'Piastra', 'tune': -3, 'bogus': 1})['result']
        check(sorted(r['applied']) == ['flt_cutoff', 'rev_mode', 'tune'] and r.get('rejected') == ['bogus'],
              f'set_params {r}')

        p = c.call('get_params', ids=['flt_cutoff', 'rev_mode', 'tune'])['result']
        check(abs(p['flt_cutoff'] - 1000) < 1 and p['rev_mode'] == 'Piastra' and p['tune'] == -3, f'get_params ids {p}')

        r = c.call('set_params', values={'rev_mix': 5})['result']
        p = c.call('get_params', ids=['rev_mix'])['result']
        check(p['rev_mix'] == 1.0, 'out-of-range values are clamped')

        check(c.call('get_params', ids=['nope']).get('error') is not None, 'unknown id in get_params is an error')

        c2 = Client(port)
        check(c2.call('status', text='the agent is tuning the resonators')['result']['ok'], 'status from a second client')
        check(c.call('note', pitch=60, velocity=110, duration_ms=300)['result']['ok'], 'note')
        time.sleep(0.8)
        check(c.call('note', pitch=64)['result']['ok'], 'note with defaults')
        check(c.call('panic')['result']['ok'], 'panic')
        check('error' in c.call('frobnicate'), 'unknown method is an error')
        check('error' in c.raw('{not json'), 'invalid JSON is an error')
        check('error' in c.call('note'), 'note without pitch is an error')

        info = c.call('info')['result']
        check(info['sound'] == str(sketch), f'info reports the loaded sound ({info["sound"]})')
        files = {json.loads(f.read_text())['port']: json.loads(f.read_text()) for f in (home / 'instances').glob('*.json')}
        check(files[port]['sound'] == str(sketch), 'instance file updated with the sound path')

        # Reset, modified, reload (manual and automatic), save as.
        c.call('set_params', values={'rev_mix': 0.9, 'mode': 'Legato'})
        check(c.call('info')['result']['modified'] is True, 'info reports modified params')
        check(c.call('reset')['result']['ok'], 'reset')
        p = c.call('get_params', ids=['rev_mix', 'mode', 'amp_release'])['result']
        check(abs(p['rev_mix'] - 0.25) < 1e-4 and p['mode'] == 'Poli' and abs(p['amp_release'] - 600) < 0.5
              and c.call('info')['result']['modified'] is False, f'reset restores the sound defaults {p}')

        c.call('set_params', values={'rev_mix': 0.33})
        r = c.call('reload')
        p = c.call('get_params', ids=['rev_mix'])['result']
        check(r.get('result', {}).get('ok') is True and abs(p['rev_mix'] - 0.33) < 1e-4, 'reload keeps the current params')

        mp = sketch / 'build' / 'manifest.json'
        m = json.loads(mp.read_text())
        m['title'] = 'Test Tone ricompilato'
        mp.write_text(json.dumps(m))
        title = ''
        for _ in range(40):
            time.sleep(0.1)
            title = c.call('info')['result']['title']
            if title == 'Test Tone ricompilato':
                break
        p = c.call('get_params', ids=['rev_mix'])['result']
        check(title == 'Test Tone ricompilato' and abs(p['rev_mix'] - 0.33) < 1e-4,
              'a changed build/manifest.json reloads by itself, keeping params')

        (sketch / 'sound.py').write_text('from libero import Sound\nsound = Sound(title="Test Tone")\n')
        (sketch / 'samples').mkdir(exist_ok=True)
        (sketch / 'samples' / 'a.wav').write_bytes(b'RIFF0000')
        c.call('set_params', values={'rev_mix': 0.6, 'mode': 'Legato', 'dyn_mode': 'Manopola'})
        r = c.call('save_as', title="Arpa d'oro è")
        res = r.get('result', {})
        new = Path(res.get('path', '/nonexistent'))
        check(res.get('ok') is True and new.parent == home / 'sounds' and new.name == 'arpa-d-oro-e',
              f'save_as creates sounds/<slug> ({res})')
        nm = json.loads((new / 'build' / 'manifest.json').read_text()) if new.exists() else {}
        check(nm.get('title') == "Arpa d'oro è" and nm.get('slug') == 'arpa-d-oro-e'
              and abs(nm.get('params', {}).get('rev_mix', 0) - 0.6) < 1e-6
              and nm['params'].get('mode') == 'Legato' and nm['params'].get('dyn_mode') == 'Manopola',
              f'the copy carries the new title and the current settings {nm.get("params")}')
        same_inode = all((new / 'build' / f.name).stat().st_ino == f.stat().st_ino
                         for f in (sketch / 'build').glob('*.wav'))
        check(same_inode and (new / 'samples' / 'a.wav').stat().st_ino == (sketch / 'samples' / 'a.wav').stat().st_ino,
              'audio and samples are hard links, not copies')
        tail = (new / 'sound.py').read_text()
        check('sound.retitle("Arpa d\'oro è")' in tail and 'rev_mix=0.6' in tail and 'mode="Legato"' in tail,
              'sound.py gets retitle() and defaults() so a recompile keeps them')
        info = c.call('info')['result']
        check(info['sound'] == str(new) and info['modified'] is False, 'the copy is loaded and unmodified')
        r2 = c.call('save_as', title="Arpa d'oro è")['result']
        check(r2.get('slug') == 'arpa-d-oro-e-2', 'save_as never overwrites: a second copy gets -2')
        check('error' in c.call('save_as', title='  '), 'save_as without a title is an error')

        bank = home / 'banks' / 'sock-bank'
        bank.mkdir(parents=True, exist_ok=True)
        (bank / 'bank.json').write_text('{"format":"libero.bank/1","slug":"sock-bank","title":"Sock","subtitle":"s","description":"","version":"1.0.0","author":"","license":"CC0","figure":null}')
        bl = c.call('list_banks')['result']
        check({b['slug'] for b in bl} >= {'sock-bank', 'mie', 'prove'}
              and next(b for b in bl if b['slug'] == 'sock-bank')['title'] == 'Sock', 'list_banks lists banks, Mie and Prove')
        cur = Path(c.call('info')['result']['sound'])
        r = c.call('move_sound', path=str(cur), bank='sock-bank')
        moved = bank / cur.name
        check(r.get('result', {}).get('path') == str(moved) and moved.is_dir() and not cur.exists(), 'move_sound moves the folder into the bank')
        check(c.call('info')['result']['sound'] == str(moved), 'moving the loaded sound keeps it loaded')
        check('error' in c.call('move_sound', path=str(moved), bank='nope'), 'move_sound refuses an unknown bank')
        check(c.call('move_sound', path=str(moved), bank='mie')['result']['path'] == str(cur), 'move_sound back to Mie')

        # Colour tags: keyed by slug in config.json, survive moves, shown in info items.
        cfgp = home / 'config.json'
        r = c.call('set_color_tag', path=str(cur), color=3)
        tags = json.loads(cfgp.read_text()).get('tags', {})
        check(r.get('result', {}).get('ok') is True and tags.get(cur.name) == 3, 'set_color_tag stores the tag by slug')
        c.call('move_sound', path=str(cur), bank='sock-bank')
        check(json.loads(cfgp.read_text()).get('tags', {}).get(cur.name) == 3, 'the tag survives a move between banks')
        c.call('move_sound', path=str(moved), bank='mie')
        c.call('set_color_tag', path=str(cur), color=0)
        check(cur.name not in json.loads(cfgp.read_text()).get('tags', {}), 'colour 0 removes the tag')

        # Bank format: create / edit / export / import (SPEC 2.4), same behaviour as python/libero/library.py.
        r = c.call('create_bank', title='Cori Antichi', subtitle='voci')
        slug = r.get('result', {}).get('slug')
        meta = json.loads((home / 'banks' / 'cori-antichi' / 'bank.json').read_text())
        check(slug == 'cori-antichi' and set(meta) == {'format', 'slug', 'title', 'subtitle', 'description', 'version', 'author',
              'license', 'created', 'updated', 'figure'} and meta['version'] == '1.0.0', 'create_bank writes the full libero.bank/1 schema')
        check(c.call('create_bank', title='Cori Antichi')['result']['slug'] == 'cori-antichi-2', 'create_bank never overwrites')
        r = c.call('edit_bank', slug='cori-antichi', title='Cori', description='d')
        meta = json.loads((home / 'banks' / 'cori-antichi' / 'bank.json').read_text())
        check(r.get('result', {}).get('ok') and meta['title'] == 'Cori' and meta['description'] == 'd' and meta['subtitle'] == 'voci',
              'edit_bank changes only the given fields')
        check('error' in c.call('edit_bank', slug='nope', title='x'), 'edit_bank refuses an unknown bank')
        mv = c.call('move_sound', path=str(cur), bank='cori-antichi')['result']['path']
        sd = Path(mv)
        (sd / 'samples').mkdir(exist_ok=True)
        (sd / 'samples' / 'credits.json').write_text(json.dumps([{'source': 'x', 'license': 'CC BY 4.0', 'license_class': 'by'}]))
        (sd / 'notes.md').write_text('n')
        pack = home / 'out' / 'cori.liberobank'
        r = c.call('export_bank', slug='cori-antichi', path=str(pack))
        import zipfile
        names = zipfile.ZipFile(pack).namelist() if pack.exists() else []
        zmeta = json.loads(zipfile.ZipFile(pack).read('cori-antichi/bank.json')) if pack.exists() else {}
        check(r.get('result', {}).get('ok') and 'cori-antichi/bank.json' in names
              and f'cori-antichi/{sd.name}/build/manifest.json' in names and f'cori-antichi/{sd.name}/notes.md' in names
              and not any(n.endswith('.wav') and '/samples/' in n for n in names) and zmeta['license'] == 'CC BY 4.0',
              f'export_bank packs bank.json (license derived), builds and notes, no source audio {names[:4]}')
        with zipfile.ZipFile(pack) as archive:
            check(all('\\' not in item.orig_filename for item in archive.infolist()),
                  'export_bank stores portable forward-slash ZIP paths')
        (sd / 'samples' / 'credits.json').write_text(json.dumps([{'source': 'x', 'license': 'CC BY-NC', 'license_class': 'nc'}]))
        r = c.call('export_bank', slug='cori-antichi', path=str(home / 'out' / 'bad.liberobank'))
        check('error' in r and sd.name in r['error'] and not (home / 'out' / 'bad.liberobank').exists(),
              'export_bank refuses a non-commercial sound and names it')
        for cls, label in [('gpl', 'GPL-3.0-or-later'), ('freeware', 'publisher freeware permission')]:
            (sd / 'samples' / 'credits.json').write_text(json.dumps([{'source': 'x', 'license': label, 'license_class': cls}]))
            c.call('edit_bank', slug='cori-antichi', description='conditional source')
            conditional = json.loads((home / 'banks' / 'cori-antichi' / 'bank.json').read_text())['license']
            check(label in conditional and 'private use only' not in conditional,
                  f'{cls} metadata preserves its conditional grant instead of declaring private use')
            r = c.call('export_bank', slug='cori-antichi', path=str(home / 'out' / f'{cls}.liberobank'))
            check('error' in r and not (home / 'out' / f'{cls}.liberobank').exists(),
                  f'automatic export cannot discard the {cls} distribution requirements')
        (sd / 'samples' / 'credits.json').unlink()
        r = c.call('export_bank', slug='cori-antichi', path=str(home / 'out' / 'uncredited.liberobank'))
        check('error' in r and not (home / 'out' / 'uncredited.liberobank').exists(),
              'native export refuses an uncredited instrument')
        (sd / 'samples' / 'credits.json').write_text(json.dumps([{'source': 'x', 'license': 'CC BY 4.0', 'license_class': 'by'}]))
        r = c.call('import_bank', path=str(pack))
        check('error' in r and 'already installed' in r['error'], f'import_bank refuses the same version: {r}')
        import shutil as _sh
        _sh.rmtree(home / 'banks' / 'cori-antichi')
        r = c.call('import_bank', path=str(pack))
        check(r.get('result', {}).get('ok') and (home / 'banks' / 'cori-antichi' / sd.name / 'build' / 'manifest.json').exists(),
              f'import_bank installs a pack: {r}')
        zin = zipfile.ZipFile(pack)
        newer = home / 'out' / 'newer.liberobank'
        with zipfile.ZipFile(newer, 'w') as zo:
            for n in zin.namelist():
                zo.writestr(n, json.dumps({**zmeta, 'version': '1.2.0'}) if n == 'cori-antichi/bank.json' else zin.read(n))
        check(c.call('import_bank', path=str(newer)).get('result', {}).get('ok'), 'import_bank replaces with a newer version')
        check(json.loads((home / 'banks' / 'cori-antichi' / 'bank.json').read_text())['version'] == '1.2.0', 'the newer version is installed')
        evil = home / 'out' / 'evil.liberobank'
        with zipfile.ZipFile(evil, 'w') as zo:
            zo.writestr('x/../../evil', '1')
        check('error' in c.call('import_bank', path=str(evil)), 'import_bank rejects unsafe paths')
        moved_back = home / 'banks' / 'cori-antichi' / cur.name
        if moved_back.exists():
            c.call('move_sound', path=str(moved_back), bank='mie')

        # Swap sounds under a sustained chord: must not click.
        c.call('set_params', values={'lvl_attack': -60, 'lvl_tail': -60, 'lvl_air': -60, 'rev_mix': 0, 'amp_attack': 40})
        c.call('panic')
        time.sleep(1.2)
        for pitch in (48, 55, 60, 64):
            c.call('note', pitch=pitch, velocity=100, duration_ms=2500)
        time.sleep(1.0)
        r = c.call('load', path=str(noir))
        check(r.get('result', {}).get('ok') is True, 'second load while notes sound')
        c.call('set_params', values={'lvl_attack': -60, 'lvl_tail': -60, 'lvl_air': -60, 'amp_attack': 40})
        for pitch in (50, 57):
            c.call('note', pitch=pitch, velocity=100, duration_ms=800)
        time.sleep(2.0)
        c.close()
        c2.close()
    finally:
        host.stdin.close()
        host2.stdin.close()
        out = host.stdout.read().strip().splitlines()
        host.wait(timeout=30)
        host2.stdout.read()
        host2.wait(timeout=30)

    summary = json.loads(out[-1]) if out else {}
    print('host summary:', summary)
    check(summary.get('peak', 0) > 1e-3, 'audio was produced by agent notes')
    check(summary.get('non_finite') is False, 'no NaN/inf in the host output')
    check(summary.get('state_roundtrip') is True, 'state save/restore (params + sound path)')
    check(summary.get('caldi_roundtrip') is True, 'all seven Caldi values survive state save/restore')
    check(summary.get('caldi_legacy_bypass') is True, 'legacy state restored into enabled instance returns Caldi defaults/bypass')
    check(summary.get('caldi_reset_bypass') is True, 'reset of old sound never enables a Caldi preset')
    check(not any((home / 'instances').glob('*.json')), 'instance files removed on destruction')

    worst, at = worst_transient(capture)
    check(worst < 4.0, f'no clicks in the host output across a sound swap (worst transient ratio {worst:.2f} at {at:.2f}s)')

    print(f'\n{len(failures)} failure(s)')
    sys.exit(1 if failures else 0)


if __name__ == '__main__':
    main()
