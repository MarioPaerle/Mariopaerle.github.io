import test from 'node:test';
import assert from 'node:assert/strict';
import {instrumentFamily, soundTypes, groupSounds, soundGroupKeys} from '../../ui/js/library-groups.js';
const colors = ['Red', 'Ochre', 'Green', 'Blue'];
test('families prefer the instrument over broad synth/keys tags', () => {
  for (const [title, tags, family] of [
    ['Toy Piano', ['sampled'], 'pianos'], ['Tine Air', ['keys', 'electric'], 'pianos'],
    ['Clean Studio Kit', ['drums', 'acoustic'], 'drums'], ['Phonk Snare', ['drums'], 'percussion'],
    ['Tonewheel Breathing Room', ['keys'], 'organs'], ['Aulos', ['sampled'], 'woodwinds'],
    ['French Horn', ['brass'], 'brass'], ['Solo Violin', ['strings'], 'strings'],
    ['Warm Bass', ['synth'], 'bass'], ['Lead', ['synth'], 'synths'],
    ['Unusual Music Box', ['sampled'], 'mallets'], ['Ellen', [], 'voices'],
    ['Concertina', ['sampled'], 'reeds'], ['Ocarina', [], 'woodwinds'],
    ['Fosforo', ['electronic'], 'synths'], ['Dan Tranh', [], 'guitars'],
    ['Unknown', [], 'other'],
  ]) assert.equal(instrumentFamily({title, tags})[0], family, title);
});
test('sound types may place a hybrid in several useful groups without duplication', () => {
  const s = {title:'Warm Pad', tags:['pad', 'synth', 'warm', 'wide']};
  const ids = soundTypes(s).map(([id]) => id);
  assert.deepEqual(new Set(ids), new Set(['pads','synthesized','sustained','warm','wide']));
  assert.deepEqual(soundGroupKeys(s, 'type'), ids);
});
test('groups span packs and retain all sounds, with unclassified sounds accessible', () => {
  const a={title:'Grand Piano', bank:{slug:'one'}}, b={title:'Felt Piano',bank:{slug:'two'}}, c={title:'Unknown'};
  const groups=groupSounds([a,b,c],'instrument',colors);
  assert.equal(groups.find(g=>g.key==='@instrument:pianos').count,2);
  assert.deepEqual(groups.flatMap(g=>g.members),[a,b,c]);
  assert.equal(groups.at(-1).title,'Other instruments');
});
test('color groups include untagged sounds and reflect changed tags', () => {
  const s={title:'A',colorTag:2}, empty={title:'B'};
  assert.equal(groupSounds([s,empty],'color',colors)[0].title,'Ochre');
  assert.equal(groupSounds([s,empty],'color',colors).at(-1).title,'Untagged');
  s.colorTag=4;
  assert.deepEqual(soundGroupKeys(s,'color'),['4']);
  assert.equal(groupSounds([s],'color',colors)[0].title,'Blue');
});
