#pragma once

#include "../engine/ParamsJson.h"
#include "../engine/RateCache.h"
#include <chrono>
#include <numeric>
#include <ctime>
#if JUCE_MAC
 #include <mach/mach.h>
 #include <sys/resource.h>
#endif

namespace performance
{
inline int editorSizeCheck()
{
    auto a = std::make_unique<libero::LiberoProcessor>();
    auto b = std::make_unique<libero::LiberoProcessor>();
    {
        std::unique_ptr<juce::AudioProcessorEditor> editor (a->createEditorAndMakeActive());
        editor->setSize (1410, 830);
        a->editorBeingDeleted (editor.get());
    }
    const auto cfg = libero::library::readConfig()["editor_size"];
    const bool immediate = (int) cfg["width"] == 1410 && (int) cfg["height"] == 830;
    {
        std::unique_ptr<juce::AudioProcessorEditor> editor (b->createEditorAndMakeActive());
        editor->setSize (1660, 920);
        b->editorBeingDeleted (editor.get());
    }
    std::unique_ptr<juce::AudioProcessorEditor> reopened (a->createEditorAndMakeActive());
    const bool independent = reopened->getWidth() == 1410 && reopened->getHeight() == 830;
    juce::MemoryBlock state; a->getStateInformation (state);
    auto restored = std::make_unique<libero::LiberoProcessor>();
    restored->setStateInformation (state.getData(), (int) state.getSize());
    std::unique_ptr<juce::AudioProcessorEditor> session (restored->createEditorAndMakeActive());
    const bool roundtrip = session->getWidth() == 1410 && session->getHeight() == 830;
    a->editorBeingDeleted (reopened.get());
    restored->editorBeingDeleted (session.get());
    std::cout << "editor-size: immediate-close=" << immediate << " independent=" << independent << " state-roundtrip=" << roundtrip << std::endl;
    return immediate && independent && roundtrip ? 0 : 1;
}
inline int midiMergeCheck (const juce::String& path)
{
    juce::String error;
    auto first = libero::SoundData::load (juce::File (path), 48000, error);
    auto second = libero::SoundData::load (juce::File (path), 48000, error);
    if (!first || !second) return 2;
    libero::ParamSet params;
    libero::applyJsonParams (params, first->params);
    params.set ("humanize", 0);
    libero::Engine reference, merged;
    for (auto* engine : {&reference, &merged}) { engine->setParameters (params); engine->prepare (48000, 127); }
    reference.submitSound (std::move (first)); merged.submitSound (std::move (second));
    reference.finishLoadingOffline(); merged.finishLoadingOffline();
    std::array<float, 127> refL {}, refR {}, gotL {}, gotR {};
    juce::MidiBuffer host, extra, combined;
    std::vector<uint8_t> sysex (65536, 1);
    const auto ignored = juce::MidiMessage::createSysExMessage (sysex.data(), (int) sysex.size());
    bool identical = true;
    for (int block = 0; block < 500; ++block)
    {
        host.clear(); extra.clear(); combined.clear();
        if (block % 20 == 0)
        {
            host.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 90), 0);
            host.addEvent (juce::MidiMessage::controllerEvent (1, 1, block % 128), 10);
            host.addEvent (ignored, 17);
            host.addEvent (juce::MidiMessage::noteOn (1, 72, (juce::uint8) 100), -1);
            host.addEvent (juce::MidiMessage::noteOn (1, 76, (juce::uint8) 100), 127);
            extra.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
            extra.addEvent (juce::MidiMessage::noteOn (1, 67, (juce::uint8) 80), 33);
            host.addEvent (juce::MidiMessage::controllerEvent (1, 11, 90), 33);
            extra.addEvent (juce::MidiMessage::noteOff (1, 67), 126);
        }
        if (block % 31 == 0) extra.addEvent (juce::MidiMessage::allSoundOff (1), 83);
        combined.addEvents (host, 0, 127, 0); combined.addEvents (extra, 0, 127, 0);
        reference.process (refL.data(), refR.data(), 127, combined);
        merged.process (gotL.data(), gotR.data(), 127, host, &extra);
        identical &= std::memcmp (refL.data(), gotL.data(), sizeof (refL)) == 0
                  && std::memcmp (refR.data(), gotR.data(), sizeof (refR)) == 0;
    }
    std::cout << "midi-merge: bit-identical=" << identical << " sysex-bytes=65536 host-first-at-ties=1" << std::endl;
    return identical ? 0 : 1;
}
inline int auditionQueueCheck (const juce::String& path)
{
    libero::LiberoProcessor processor;
    processor.prepareToPlay (48000, 256);
    bool loaded = false;
    processor.loadSound (juce::File (path), true, [&] (bool ok, juce::String) { loaded = ok; });
    for (int i = 0; i < 200 && ! loaded; ++i)
        juce::MessageManager::getInstance()->runDispatchLoopUntil (10);
    if (! loaded) return 2;
    for (const char* id : { "rev_mix", "res_mix", "echo_mix", "tape_mix", "caldi_amount" })
    {
        auto* parameter = processor.getState().getParameter (id);
        parameter->setValueNotifyingHost (parameter->convertTo0to1 (0));
    }
    auto* release = processor.getState().getParameter ("amp_release");
    release->setValueNotifyingHost (release->convertTo0to1 (5));
    std::thread ui ([&] { for (int n = 0; n < 64; ++n) processor.queueNote (n, 90, 200); });
    std::thread agent ([&] { for (int n = 64; n < 128; ++n) processor.queueNote (n, 90, 200); });
    ui.join(); agent.join();
    juce::AudioBuffer<float> buffer (2, 256);
    juce::MidiBuffer midi;
    float peak = 0, finalPeak = 0;
    bool finite = true;
    for (int block = 0; block < 300; ++block)
    {
        buffer.clear(); midi.clear();
        processor.processBlock (buffer, midi);
        for (int channel = 0; channel < 2; ++channel)
            for (int sample = 0; sample < 256; ++sample)
            {
                const auto value = buffer.getSample (channel, sample);
                finite = finite && std::isfinite (value);
                peak = std::max (peak, std::abs (value));
                if (block >= 280) finalPeak = std::max (finalPeak, std::abs (value));
            }
    }
    std::cout << "audition-queue: finite=" << finite << " audible=" << (peak > .001f)
              << " final-peak=" << finalPeak << std::endl;
    for (int i = 0; i < 300; ++i) processor.queueNote (60 + i % 12, 100, 60000);
    processor.queuePanic();
    float panicPeak = 0;
    for (int block = 0; block < 30; ++block)
    {
        buffer.clear(); midi.clear(); processor.processBlock (buffer, midi);
        if (block > 20) panicPeak = std::max (panicPeak, buffer.getMagnitude (0, 256));
    }
    processor.queueNote (60, 100, 10);
    float recoveryPeak = 0;
    for (int block = 0; block < 10; ++block)
    {
        buffer.clear(); midi.clear(); processor.processBlock (buffer, midi);
        recoveryPeak = std::max (recoveryPeak, buffer.getMagnitude (0, 256));
    }
    std::cout << "audition-panic: full-queue-silence=" << panicPeak << " recovery=" << recoveryPeak << std::endl;
    return finite && peak > .001f && finalPeak < .0001f && panicPeak < .0001f && recoveryPeak > .001f ? 0 : 1;
}
inline int soundTransitionCheck (const juce::String& irPath, const juce::String& dryPath)
{
    juce::String error;
    auto initial = libero::SoundData::load (juce::File (irPath), 48000, error);
    if (! initial || ! initial->hasIR()) return 2;
    libero::Engine engine;
    libero::ParamSet params;
    params.setChoice ("rev_mode", "Impronta");
    params.set ("rev_mix", .4f);
    engine.setParameters (params);
    engine.prepare (48000, 256);
    engine.submitSound (std::move (initial));
    engine.finishLoadingOffline();
    std::atomic<bool> stop { false }, finite { true };
    std::atomic<int> blocks { 0 };
    std::thread audio ([&]
    {
        std::array<float, 256> l {}, r {};
        juce::MidiBuffer midi;
        midi.ensureSize (128);
        while (! stop.load())
        {
            midi.clear();
            if (blocks.load() % 16 == 0)
                midi.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 90), 0);
            engine.process (l.data(), r.data(), 256, midi);
            for (int i = 0; i < 256; ++i)
                if (! std::isfinite (l[(size_t) i]) || ! std::isfinite (r[(size_t) i])) finite = false;
            ++blocks;
            juce::Thread::sleep (1);
        }
    });
    bool loaded = true;
    for (int i = 0; i < 64; ++i)
    {
        auto sound = libero::SoundData::load (juce::File (i % 2 == 0 ? dryPath : irPath), 48000, error);
        if (! sound) { loaded = false; break; }
        engine.submitSound (std::move (sound));
        juce::Thread::sleep (2);
    }
    juce::Thread::sleep (50);
    stop = true;
    audio.join();
    engine.collectGarbage();
    for (int i = 0; i < 24; ++i)
    {
        auto processor = std::make_unique<libero::LiberoProcessor>();
        processor->prepareToPlay (48000, 256);
        processor->loadSound (juce::File (irPath), true);
        processor->loadSound (juce::File (dryPath), true);
        processor.reset();
    }
    std::cout << "sound-transitions: loaded=" << loaded << " finite=" << finite.load()
              << " blocks=" << blocks.load() << " teardown-cycles=24" << std::endl;
    return loaded && finite && blocks >= 10 ? 0 : 1;
}
inline int loadingCheck (const juce::String& path)
{
    if (juce::SystemStats::getEnvironmentVariable ("LIBERO_DISABLE_SAMPLE_CACHE", {}) != "1"
        || juce::SystemStats::getEnvironmentVariable ("LIBERO_HOME", {}).isEmpty()) return 2;
    juce::String error;
    auto a = libero::SoundData::load (juce::File (path), 48000, error);
    auto b = libero::SoundData::load (juce::File (path), 48000, error);
    const auto equal = [&] (const auto& x, const auto& y)
    {
        if (!x || !y || x->zones.size() != y->zones.size()) return false;
        for (size_t i = 0; i < x->zones.size(); ++i)
            if (libero::rateCache::checksum (x->zones[i].audio) != libero::rateCache::checksum (y->zones[i].audio)) return false;
        return true;
    };
    const bool identical = equal (a, b);
    auto files = libero::rateCache::directory().findChildFiles (juce::File::findFiles, false, "*.lpcm");
    const bool populated = !files.isEmpty();
    if (populated)
    {
        juce::FileOutputStream stream (files[0]);
        stream.setPosition (0); stream.writeInt (0); stream.flush();
    }
    auto recovered = libero::SoundData::load (juce::File (path), 48000, error);
    const bool recovery = populated && equal (a, recovered);
    std::array<std::unique_ptr<libero::SoundData>, 8> simultaneous;
    std::array<juce::File, 8> sources;
    for (auto& source : sources)
    {
        source = juce::File::createTempFile ("-libero-parallel-load");
        if (!juce::File (path).copyDirectoryTo (source)) return 1;
    }
    std::vector<std::thread> loaders;
    for (size_t i = 0; i < sources.size(); ++i)
        loaders.emplace_back ([&, i]
        {
            juce::String loadError;
            simultaneous[i] = libero::SoundData::load (sources[i], 48000, loadError);
        });
    for (auto& loader : loaders) loader.join();
    const bool concurrent = std::all_of (simultaneous.begin(), simultaneous.end(),
        [&] (const auto& loaded) { return equal (a, loaded); });
    for (auto& source : sources) source.deleteRecursively();
    error.clear();
    auto cancelled = libero::SoundData::load (juce::File (path), 48000, error, [] { return true; });
    const bool immediate = !cancelled && error == "load cancelled";
    std::atomic<int> calls { 0 }; error.clear();
    auto interrupted = libero::SoundData::load (juce::File (path), 48000, error, [&] { return ++calls > 8; });
    const bool midLoad = !interrupted && error == "load cancelled";
    std::cout << "loading: populated=" << populated << " bit-identical=" << identical << " corruption-recovery=" << recovery
              << " concurrent-distinct=" << concurrent << " immediate-cancel=" << immediate << " mid-load-cancel=" << midLoad << std::endl;
    return populated && identical && recovery && concurrent && immediate && midLoad ? 0 : 1;
}
inline int sampleCacheCheck (const juce::String& source)
{
    const auto folder = juce::File::createTempFile ("-libero-cache");
    if (!juce::File (source).copyDirectoryTo (folder)) return 1;
    juce::String error;
    auto a = libero::SoundData::load (folder, 48000, error);
    auto b = libero::SoundData::load (folder, 48000, error);
    if (!a || !b || a->zones.empty() || b->zones.empty()) { folder.deleteRecursively(); return 1; }
    const auto original = b->zones[0].audio.getSample (0, 0);
    const bool shared = a->zones[0].audio.getReadPointer (0) == b->zones[0].audio.getReadPointer (0);
    a->zones[0].audio.getWritePointer (0)[0] = original + 1;
    const bool isolated = b->zones[0].audio.getSample (0, 0) == original;
    a->params.getDynamicObject()->setProperty ("master", 17);
    const bool paramsIsolated = (double) b->params["master"] != 17;
    auto differentRate = libero::SoundData::load (folder, 44100, error);
    const bool rateIsolated = differentRate && differentRate->zones[0].audio.getReadPointer (0) != b->zones[0].audio.getReadPointer (0);
    folder.getChildFile ("sample-edits.json").replaceWithText ("{\"edits\":{}}");
    auto changedEdits = libero::SoundData::load (folder, 48000, error);
    const bool editsInvalidate = changedEdits && changedEdits->zones[0].audio.getReadPointer (0) != b->zones[0].audio.getReadPointer (0);
    const auto manifestFile = folder.getChildFile ("build/manifest.json");
    auto manifest = juce::JSON::parse (manifestFile);
    manifest.getDynamicObject()->setProperty ("title", "Cache refresh");
    manifestFile.replaceWithText (juce::JSON::toString (manifest));
    auto changedManifest = libero::SoundData::load (folder, 48000, error);
    const bool manifestInvalidates = changedManifest && changedManifest->title == "Cache refresh"
        && changedManifest->zones[0].audio.getReadPointer (0) != changedEdits->zones[0].audio.getReadPointer (0);
    const auto sample = folder.getChildFile ("build").getChildFile (manifest["zones"][0]["file"].toString());
    sample.setLastModificationTime (sample.getLastModificationTime() + juce::RelativeTime::seconds (2));
    auto changedFile = libero::SoundData::load (folder, 48000, error);
    const bool fileInvalidates = changedFile && changedFile->zones[0].audio.getReadPointer (0) != changedManifest->zones[0].audio.getReadPointer (0);
    const std::weak_ptr<const libero::SoundData> lifetime = b->cacheBacking;
    a.reset(); b.reset();
    const bool released = lifetime.expired();
    changedEdits.reset(); changedManifest.reset(); changedFile.reset(); differentRate.reset();
    std::array<std::unique_ptr<libero::SoundData>, 4> concurrent;
    std::vector<std::thread> threads;
    for (size_t i = 0; i < concurrent.size(); ++i)
        threads.emplace_back ([&, i] { juce::String loadError; concurrent[i] = libero::SoundData::load (folder, 48000, loadError); });
    for (auto& thread : threads) thread.join();
    bool singleFlight = concurrent[0] != nullptr;
    for (size_t i = 1; i < concurrent.size(); ++i)
        singleFlight = singleFlight && concurrent[i] && concurrent[i]->zones[0].audio.getReadPointer (0) == concurrent[0]->zones[0].audio.getReadPointer (0);
    folder.deleteRecursively();
    std::cout << "sample-cache: shared=" << shared << " write-isolated=" << isolated << " params-isolated=" << paramsIsolated
              << " rate-isolated=" << rateIsolated << " edits-invalidate=" << editsInvalidate
              << " manifest-invalidates=" << manifestInvalidates << " file-invalidates=" << fileInvalidates
              << " released=" << released << " concurrent-shared=" << singleFlight << std::endl;
    return shared && isolated && paramsIsolated && rateIsolated && editsInvalidate && manifestInvalidates && fileInvalidates && released && singleFlight ? 0 : 1;
}
inline juce::var object() { return juce::var (new juce::DynamicObject()); }
inline void put (juce::var& v, const char* key, juce::var value) { v.getDynamicObject()->setProperty (key, value); }
inline double now() { return juce::Time::getMillisecondCounterHiRes(); }
inline int loadProfile (const juce::String& path, double rate)
{
    for (int i = 0; i < 3; ++i)
    {
        juce::String error; const auto start = now();
        auto sound = libero::SoundData::load (juce::File (path), rate, error);
        if (!sound) { std::cerr << error << std::endl; return 1; }
        auto report = object(); put (report, "run", i); put (report, "load_ms", now() - start);
        put (report, "rate", rate); put (report, "zones", (int) sound->zones.size());
        put (report, "first_zone_checksum", sound->zones.empty() ? juce::String() : juce::String::toHexString (libero::rateCache::checksum (sound->zones.front().audio)));
        std::cout << juce::JSON::toString (report, true) << std::endl;
    }
    return 0;
}
inline juce::var memory()
{
    auto v = object();
   #if JUCE_MAC
    task_vm_info_data_t info {};
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    if (task_info (mach_task_self(), TASK_VM_INFO, reinterpret_cast<task_info_t> (&info), &count) == KERN_SUCCESS)
    {
        put (v, "resident_bytes", (juce::int64) info.resident_size);
        put (v, "footprint_bytes", (juce::int64) info.phys_footprint);
    }
    rusage usage {};
    if (getrusage (RUSAGE_SELF, &usage) == 0)
        put (v, "cpu_seconds", usage.ru_utime.tv_sec + usage.ru_utime.tv_usec * 1.e-6
                                + usage.ru_stime.tv_sec + usage.ru_stime.tv_usec * 1.e-6);
   #endif
    return v;
}
inline void emit (const char* stage, juce::var v)
{
    put (v, "stage", stage);
    std::cout << juce::JSON::toString (v, true) << std::endl;
}
inline juce::var timings (std::vector<double> us, double budgetUs)
{
    auto v = object();
    if (us.empty()) return v;
    const auto mean = std::accumulate (us.begin(), us.end(), 0.0) / us.size();
    const int exceeded = (int) std::count_if (us.begin(), us.end(), [budgetUs] (double t) { return t > budgetUs; });
    std::sort (us.begin(), us.end());
    const auto q = [&] (double p) { return us[(size_t) (p * (us.size() - 1))]; };
    put (v, "blocks", (int) us.size()); put (v, "mean_us", mean);
    put (v, "median_us", q (.5)); put (v, "p95_us", q (.95)); put (v, "p99_us", q (.99));
    put (v, "max_us", us.back()); put (v, "budget_us", budgetUs);
    put (v, "mean_budget_percent", 100.0 * mean / budgetUs);
    put (v, "blocks_above_budget", exceeded);
    return v;
}

inline int streamStorageCheck (const juce::String& path)
{
    juce::String error;
    auto streamed = libero::SoundData::load (juce::File (path), 48000, error, {}, true);
    auto resident = libero::SoundData::load (juce::File (path), 48000, error, {}, false);
    if (!streamed || !streamed->streaming || !resident || resident->streaming) return 2;
    bool fallback = true;
    for (const auto& variant : { "loops", "legato", "edits" })
    {
        const auto folder = juce::File::createTempFile ("-stream-fallback");
        if (!juce::File (path).copyDirectoryTo (folder)) return 2;
        const auto manifestFile = folder.getChildFile ("build/manifest.json");
        auto manifest = juce::JSON::parse (manifestFile);
        if (juce::String (variant) == "loops")
            for (auto& zone : *manifest["zones"].getArray())
                if (zone["layer"].toString() == "body")
                {
                    auto loop = object(); put (loop, "start", 48000); put (loop, "end", 96000); put (loop, "crossfade", 512);
                    zone.getDynamicObject()->setProperty ("loop", loop);
                }
        if (juce::String (variant) == "legato") manifest["params"].getDynamicObject()->setProperty ("mode", "Legato");
        if (juce::String (variant) == "edits") folder.getChildFile ("sample-edits.json").replaceWithText ("{\"edits\":{}}");
        manifestFile.replaceWithText (juce::JSON::toString (manifest));
        auto sound = libero::SoundData::load (folder, 48000, error, {}, true);
        fallback = fallback && sound && !sound->streaming;
        sound.reset(); folder.deleteRecursively();
    }
    libero::ParamSet params; libero::applyJsonParams (params, resident->params);
    for (const char* id : { "rev_mix", "echo_mix", "tape_mix", "res_mix", "caldi_amount" }) params.set (id, 0);
    libero::Engine reference, candidate;
    reference.setParameters (params); candidate.setParameters (params);
    reference.prepare (48000, 256); candidate.prepare (48000, 256);
    reference.submitSound (std::move (resident)); reference.finishLoadingOffline();
    candidate.submitSound (std::move (streamed));
    std::array<float, 256> a {}, b {}, c {}, d {};
    juce::MidiBuffer midi; midi.ensureSize (256);
    bool continuity = true;
    auto next = std::chrono::steady_clock::now();
    for (int block = 0; block < 400; ++block)
    {
        midi.clear();
        if (block == 0) midi.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 90), 0);
        if (block == 200)
        {
            auto upgrade = libero::SoundData::load (juce::File (path), 48000, error, {}, false);
            if (!upgrade) return 2;
            upgrade->residentUpgrade = true;
            candidate.submitSound (std::move (upgrade));
        }
        reference.process (a.data(), b.data(), 256, midi);
        candidate.process (c.data(), d.data(), 256, midi);
        continuity = continuity && a == c && b == d;
        next += std::chrono::nanoseconds (5333333); std::this_thread::sleep_until (next);
    }
    auto offlineSound = libero::SoundData::load (juce::File (path), 48000, error, {}, true);
    libero::Engine offline; offline.prepare (48000, 256); offline.submitSound (std::move (offlineSound)); offline.finishLoadingOffline();
    const bool offlineResident = !offline.hasStreamingSound();
    libero::LiberoProcessor processor; processor.prepareToPlay (48000, 256);
    bool loaded = false;
    processor.loadSound (juce::File (path), true, [&] (bool ok, juce::String) { loaded = ok; });
    for (int i = 0; i < 200 && !loaded; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (10);
    if (!loaded) return 2;
    juce::AudioBuffer<float> buffer (2, 256);
    midi.clear(); processor.processBlock (buffer, midi);
    auto* mode = processor.getState().getParameter ("mode"); mode->setValueNotifyingHost (mode->convertTo0to1 (2));
    bool modeResident = false;
    for (int i = 0; i < 400 && !modeResident; ++i)
    {
        buffer.clear(); processor.processBlock (buffer, midi);
        juce::MessageManager::getInstance()->runDispatchLoopUntil (5);
        modeResident = processor.getCurrentSoundInfo()["sample_storage"].toString() == "resident";
    }
    std::cout << "stream-storage: fallback=" << fallback << " held-note-continuity=" << continuity
              << " offline-resident=" << offlineResident << " legato-reload=" << modeResident << std::endl;
    return fallback && continuity && offlineResident && modeResident ? 0 : 1;
}
inline int streamFailureCheck()
{
    auto pool = libero::SampleStreamPool::create();
    juce::AudioBuffer<float> prefix (2, 12000);
    for (int c = 0; c < 2; ++c) for (int i = 0; i < 12000; ++i) prefix.setSample (c, i, .125f);
    libero::SampleBuffer attack; attack = std::move (prefix);
    const auto* asset = pool->add (juce::File::getSpecialLocation (juce::File::tempDirectory).getNonexistentChildFile ("missing-stream", ".wav"), attack, 96000, 1);
    auto cursor = pool->acquire (asset);
    cursor.beginRead(); float l = 0, r = 0;
    cursor.read (38000, 0, l, r);
    bool guarded = l == 0 && r == 0 && cursor.missedRead();
    for (int i = 0; i < 100 && pool->stats().readErrors == 0; ++i) juce::Thread::sleep (5);
    cursor.beginRead(); cursor.read (38001, 0, l, r);
    guarded = guarded && l == 0 && r == 0 && cursor.missedRead() && pool->stats().readErrors > 0;
    auto copy = cursor; cursor.reset(); copy.reset();
    std::vector<libero::SampleStreamPool::Cursor> leases;
    leases.reserve (libero::SampleStreamPool::slotCount);
    // Wait for a worker holding the released slot to finish before saturating the pool.
    juce::Thread::sleep (20);
    for (int i = 0; i < libero::SampleStreamPool::slotCount; ++i) leases.push_back (pool->acquire (asset));
    const bool admitted = std::all_of (leases.begin(), leases.end(), [] (const auto& lease) { return bool (lease); });
    auto extra = pool->acquire (asset);
    const bool bounded = admitted && !extra && pool->stats().exhausted > 0;
    leases.clear();
    std::cout << "stream-failure: guarded=" << guarded << " capacity-bounded=" << bounded << std::endl;
    return guarded && bounded ? 0 : 1;
}
class RealtimeProfileThread final : public juce::Thread
{
public:
    explicit RealtimeProfileThread (std::function<void()> taskIn)
        : juce::Thread ("Libero profile audio"), task (std::move (taskIn)) {}
    void run() override { task(); }
private:
    std::function<void()> task;
};
inline double threadCpuMicroseconds() noexcept
{
#if JUCE_MAC || JUCE_LINUX
    timespec value {};
    if (clock_gettime (CLOCK_THREAD_CPUTIME_ID, &value) == 0)
        return (double) value.tv_sec * 1.e6 + (double) value.tv_nsec * .001;
#endif
    return std::numeric_limits<double>::quiet_NaN();
}
inline int unheardVoiceCheck (const juce::String& synthPath, const juce::String& drumsPath)
{
    const auto compare = [] (const juce::String& path, int firstNote, int lastNote, bool mono)
    {
        juce::String error;
        auto a = libero::SoundData::load (juce::File (path), 48000, error);
        auto b = libero::SoundData::load (juce::File (path), 48000, error);
        if (!a || !b) return false;
        libero::ParamSet params; libero::applyJsonParams (params, a->params);
        params.set ("voices", mono ? 1 : 32); params.set ("osc_retrig", 1); params.set ("osc_drift", 0);
        params.set ("glide", 0); params.set ("humanize", 0);
        for (const char* id : {"rev_mix", "echo_mix", "res_mix", "tape_mix", "caldi_amount"}) params.set (id, 0);
        libero::Engine chord, single;
        for (auto* engine : {&chord, &single}) { engine->setParameters (params); engine->prepare (48000, 64); }
        chord.submitSound (std::move (a)); single.submitSound (std::move (b));
        chord.finishLoadingOffline(); single.finishLoadingOffline();
        juce::MidiBuffer all, last;
        all.addEvent (juce::MidiMessage::noteOn (1, firstNote, (juce::uint8) 100), 0);
        all.addEvent (juce::MidiMessage::noteOn (1, lastNote, (juce::uint8) 100), 0);
        last.addEvent (juce::MidiMessage::noteOn (1, lastNote, (juce::uint8) 100), 0);
        std::array<float, 64> l {}, r {}, refL {}, refR {};
        bool identical = true;
        for (int frame = 0; frame < 4800; frame += 64)
        {
            chord.process (l.data(), r.data(), 64, all); single.process (refL.data(), refR.data(), 64, last);
            identical &= std::memcmp (l.data(), refL.data(), sizeof (l)) == 0 && std::memcmp (r.data(), refR.data(), sizeof (r)) == 0;
            if (frame == 0) identical &= chord.getActiveVoiceCount() == 1;
            all.clear(); last.clear();
        }
        if (mono)
        {
            all.addEvent (juce::MidiMessage::noteOn (1, 69, (juce::uint8) 100), 0);
            chord.process (l.data(), r.data(), 64, all);
            identical &= chord.getActiveVoiceCount() == 2; // heard predecessor still fades
        }
        return identical;
    };
    const bool chord = compare (synthPath, 60, 67, true), choke = compare (drumsPath, 46, 42, false);
    std::cout << "unheard-voice: simultaneous-limit=" << chord << " simultaneous-choke=" << choke << std::endl;
    return chord && choke ? 0 : 1;
}
inline int voiceStressProfile (const juce::String& path, int instances, double rate, int block)
{
    instances = juce::jlimit (1, 8, instances); block = juce::jlimit (32, 1024, block);
    std::vector<std::unique_ptr<libero::Engine>> engines;
    juce::String error;
    for (int i = 0; i < instances; ++i)
    {
        auto sound = libero::SoundData::load (juce::File (path), rate, error);
        if (!sound) { std::cerr << error << std::endl; return 2; }
        libero::ParamSet params; libero::applyJsonParams (params, sound->params);
        params.setChoice ("mode", "Poli"); params.set ("voices", 8); params.set ("amp_release", 400);
        for (const char* id : {"rev_mix", "echo_mix", "res_mix", "tape_mix", "caldi_amount", "humanize"}) params.set (id, 0);
        auto engine = std::make_unique<libero::Engine>(); engine->setParameters (params); engine->prepare (rate, block);
        engine->submitSound (std::move (sound)); engine->finishLoadingOffline(); engines.push_back (std::move (engine));
    }
    std::array<float, 1024> l {}, r {}; juce::MidiBuffer midi; midi.ensureSize (8192);
    std::vector<double> times, turnover;
    const int count = (int) (8 * rate / block); times.reserve ((size_t) count); turnover.reserve ((size_t) count);
    bool finite = true; int maxVoices = 0; double finalPeak = 0;
    const auto render = [&]
    {
        auto next = std::chrono::steady_clock::now();
        const auto period = std::chrono::nanoseconds ((long long) std::llround (block * 1.e9 / rate));
        int lastPacket = -1;
        for (int step = 0; step < count; ++step)
        {
            const int frame = step * block, packet = (int) (frame / (.05 * rate));
            const bool event = packet != lastPacket && frame < 6 * rate;
            const auto start = now();
            for (auto& engine : engines)
            {
                midi.clear();
                if (event)
                {
                    if (lastPacket >= 0)
                        for (int k = 0; k < 12; ++k) midi.addEvent (juce::MidiMessage::noteOff (1, 48 + (lastPacket % 3) * 3 + k), 0);
                    for (int k = 0; k < 12; ++k)
                        midi.addEvent (juce::MidiMessage::noteOn (1, 48 + (packet % 3) * 3 + k, (juce::uint8) (70 + (packet + k) % 45)), 0);
                }
                if (frame >= 6 * rate && frame - block < 6 * rate) midi.addEvent (juce::MidiMessage::allSoundOff (1), 0);
                engine->process (l.data(), r.data(), block, midi); maxVoices = std::max (maxVoices, engine->getActiveVoiceCount());
                for (int i = 0; i < block; ++i)
                {
                    finite = finite && std::isfinite (l[(size_t) i]) && std::isfinite (r[(size_t) i]);
                    if (frame > 7 * rate) finalPeak = std::max (finalPeak, (double) std::max (std::abs (l[(size_t) i]), std::abs (r[(size_t) i])));
                }
            }
            const auto elapsed = (now() - start) * 1000; times.push_back (elapsed);
            if (event) turnover.push_back (elapsed);
            if (event) lastPacket = packet;
            next += period; std::this_thread::sleep_until (next);
        }
    };
    RealtimeProfileThread worker (render);
    const auto periodMs = block * 1000.0 / rate;
    if (!worker.startRealtimeThread (juce::Thread::RealtimeOptions{}.withPriority (5).withPeriodMs (periodMs)
        .withProcessingTimeMs (periodMs * .5).withMaximumProcessingTimeMs (periodMs * .9))) return 3;
    worker.waitForThreadToExit (-1);
    auto result = timings (times, block * 1.e6 / rate); const auto bursts = timings (turnover, block * 1.e6 / rate);
    put (result, "instances", instances); put (result, "sample_rate", rate); put (result, "block", block);
    put (result, "turnover_mean_us", (double) bursts["mean_us"]); put (result, "turnover_p99_us", (double) bursts["p99_us"]);
    put (result, "finite", finite); put (result, "max_voices", maxVoices); put (result, "final_peak", finalPeak);
    emit ("voice-stress", result); emit ("voice-stress-memory", memory());
    return finite && finalPeak < .0001 ? 0 : 1;
}
inline int streamPlaybackProfile (const juce::String& path, int instances, bool allowStreaming = true, double rate = 48000, int block = 256, bool realtime = false, double seconds = 6)
{
    block = juce::jlimit (32, 1024, block);
    seconds = juce::jlimit (6.0, 120.0, seconds);
    emit ("stream-baseline", memory());
    std::vector<std::unique_ptr<libero::Engine>> engines;
    std::shared_ptr<libero::SampleStreamPool> pool;
    libero::ParamSet params;
    juce::String error;
    for (int i = 0; i < instances; ++i)
    {
        const auto start = now();
        auto sound = libero::SoundData::load (juce::File (path), rate, error, {}, allowStreaming);
        if (!sound || (allowStreaming && !sound->streaming)) { std::cerr << error << std::endl; return 2; }
        pool = sound->streaming;
        libero::applyJsonParams (params, sound->params);
        params.setChoice ("mode", "Poli"); params.set ("voices", 64);
        for (const char* id : { "rev_mix", "echo_mix", "tape_mix", "res_mix", "caldi_amount", "humanize" }) params.set (id, 0);
        auto engine = std::make_unique<libero::Engine>();
        engine->setParameters (params); engine->prepare (rate, block); engine->submitSound (std::move (sound));
        engines.push_back (std::move (engine));
        auto loaded = memory(); put (loaded, "instance", i + 1); put (loaded, "load_ms", now() - start); emit ("stream-instance", loaded);
    }
    std::array<float, 1024> l {}, r {};
    juce::MidiBuffer midi; midi.ensureSize (2048);
    bool finite = true;
    std::vector<double> times;
    times.reserve ((size_t) (seconds * rate / block) + 1);
    std::vector<double> cpuTimes;
    cpuTimes.reserve ((size_t) (seconds * rate / block) + 1);
    const auto render = [&]
    {
    auto next = std::chrono::steady_clock::now();
    const auto period = std::chrono::nanoseconds ((long long) std::llround (block * 1.0e9 / rate));
    const int cycleFrames = ((int) (6 * rate) / block) * block;
    for (int frame = 0; frame < ((int) (seconds * rate) / block) * block; frame += block)
    {
        const auto localFrame = frame % cycleFrames;
        const auto start = now();
        const auto cpuStart = threadCpuMicroseconds();
        for (int instance = 0; instance < instances; ++instance)
        {
            midi.clear();
            if (localFrame == 0 || localFrame == ((int) (2.5 * rate) / block) * block)
                for (int note = 48; note < 80; ++note)
                    midi.addEvent (juce::MidiMessage::noteOn (1, note, (juce::uint8) (80 + instance * 3)), 0);
            if (localFrame == ((int) (2 * rate) / block) * block || localFrame == ((int) (4 * rate) / block) * block)
                for (int note = 48; note < 80; ++note) midi.addEvent (juce::MidiMessage::noteOff (1, note), 0);
            engines[(size_t) instance]->process (l.data(), r.data(), block, midi);
            for (int i = 0; i < block; ++i) finite = finite && std::isfinite (l[(size_t) i]) && std::isfinite (r[(size_t) i]);
        }
        const auto cpuEnd = threadCpuMicroseconds();
        times.push_back ((now() - start) * 1000);
        if (std::isfinite (cpuStart) && std::isfinite (cpuEnd)) cpuTimes.push_back (cpuEnd - cpuStart);
        next += period; std::this_thread::sleep_until (next);
    }
    };
    if (realtime)
    {
        RealtimeProfileThread worker (render);
        const auto periodMs = block * 1000.0 / rate;
        const auto options = juce::Thread::RealtimeOptions{}.withPriority (5)
            .withPeriodMs (periodMs).withProcessingTimeMs (periodMs * .5)
            .withMaximumProcessingTimeMs (periodMs * .9);
        if (!worker.startRealtimeThread (options))
        { std::cerr << "audio-priority thread unavailable" << std::endl; return 3; }
        worker.waitForThreadToExit (-1);
    }
    else render();
    const auto stats = pool ? pool->stats() : libero::SampleStreamPool::Stats{};
    auto result = timings (times, block * 1.e6 / rate);
    put (result, "block", block); put (result, "instances", instances); put (result, "sample_rate", rate); put (result, "seconds", seconds);
    put (result, "first_block_us", times.front()); put (result, "realtime_thread", realtime);
    if (cpuTimes.size() == times.size())
    {
        const auto cpu = timings (cpuTimes, block * 1.e6 / rate);
        put (result, "thread_cpu_mean_us", (double) cpu["mean_us"]);
        put (result, "thread_cpu_p99_us", (double) cpu["p99_us"]);
        put (result, "thread_cpu_blocks_above_budget", (int) cpu["blocks_above_budget"]);
    }
    put (result, "finite", finite); put (result, "misses", (juce::int64) stats.misses); put (result, "exhausted", (juce::int64) stats.exhausted);
    put (result, "read_errors", (juce::int64) stats.readErrors);
    put (result, "decoded_chunks", (juce::int64) stats.decodedChunks); put (result, "cache_hits", (juce::int64) stats.cacheHits); put (result, "reader_opens", (juce::int64) stats.readerOpens); emit ("stream-audio", result); emit ("stream-final-memory", memory());
    return finite && stats.misses == 0 && stats.exhausted == 0 && stats.readErrors == 0 ? 0 : 1;
}
inline int streamingCheck (const juce::String& path, double rate = 48000)
{
    constexpr int block = 64;
    const int frames = ((int) (6 * rate) / block) * block;
    auto baseline = memory(); emit ("stream-baseline", baseline);
    const auto render = [&] (libero::Engine& engine, bool paced, std::vector<float>& output)
    {
        std::array<float, block> l {}, r {};
        juce::MidiBuffer midi;
        midi.ensureSize (2048);
        auto next = std::chrono::steady_clock::now();
        const auto period = std::chrono::nanoseconds ((long long) std::llround (block * 1.0e9 / rate));
        for (int frame = 0; frame < frames; frame += block)
        {
            midi.clear();
            if (frame == 0 || frame == ((int) (2.5 * rate) / block) * block)
                for (int note = 48; note < 80; ++note)
                    midi.addEvent (juce::MidiMessage::noteOn (1, note, (juce::uint8) (frame == 0 ? 100 : 65)), 0);
            if (frame == ((int) rate / block) * block) midi.addEvent (juce::MidiMessage::controllerEvent (1, 64, 127), 0);
            if (frame == ((int) (1.5 * rate) / block) * block || frame == ((int) (4 * rate) / block) * block)
                for (int note = 48; note < 80; ++note) midi.addEvent (juce::MidiMessage::noteOff (1, note), 0);
            if (frame == ((int) (2 * rate) / block) * block) midi.addEvent (juce::MidiMessage::controllerEvent (1, 64, 0), 0);
            engine.process (l.data(), r.data(), block, midi);
            for (int i = 0; i < block; ++i)
            { output[(size_t) (2 * (frame + i))] = l[(size_t) i]; output[(size_t) (2 * (frame + i) + 1)] = r[(size_t) i]; }
            if (paced) { next += period; std::this_thread::sleep_until (next); }
        }
    };
    std::vector<float> reference ((size_t) frames * 2), streamed ((size_t) frames * 2);
    juce::String error;
    libero::ParamSet params;
    {
        auto sound = libero::SoundData::load (juce::File (path), rate, error, {}, false);
        if (!sound) { std::cerr << error << std::endl; return 2; }
        libero::applyJsonParams (params, sound->params);
        params.setChoice ("mode", "Poli"); params.set ("voices", 64);
        for (const char* id : { "rev_mix", "echo_mix", "tape_mix", "res_mix", "caldi_amount", "humanize" }) params.set (id, 0);
        auto resident = memory(); emit ("stream-resident-reference", resident);
        libero::Engine engine; engine.setParameters (params); engine.prepare (rate, block);
        engine.submitSound (std::move (sound)); engine.finishLoadingOffline();
        render (engine, false, reference);
    }
    const auto start = now();
    auto sound = libero::SoundData::load (juce::File (path), rate, error, {}, true);
    if (!sound || !sound->streaming) { std::cerr << "streaming unavailable: " << error << std::endl; return 2; }
    auto pool = sound->streaming;
    juce::int64 attacks = 0;
    for (const auto& zone : sound->zones) attacks += (juce::int64) zone.audio.getNumChannels() * zone.audio.getNumSamples() * sizeof (float);
    auto loaded = memory(); put (loaded, "load_ms", now() - start); put (loaded, "attack_bytes", attacks); emit ("stream-loaded", loaded);
    {
        libero::Engine engine; engine.setParameters (params); engine.prepare (rate, block);
        engine.submitSound (std::move (sound));
        render (engine, true, streamed);
    }
    const auto stats = pool->stats();
    const bool identical = reference == streamed;
    auto result = memory(); put (result, "bit_identical", identical); put (result, "misses", (juce::int64) stats.misses);
    put (result, "exhausted", (juce::int64) stats.exhausted); put (result, "read_errors", (juce::int64) stats.readErrors); emit ("stream-result", result);
    return identical && stats.misses == 0 && stats.exhausted == 0 && stats.readErrors == 0 ? 0 : 1;
}
inline int audio (const juce::String& path, double rate)
{
    auto initial = memory(); put (initial, "sample_rate", rate); emit ("baseline", initial);
    juce::String error;
    const double start = now();
    auto sound = libero::SoundData::load (juce::File (path), rate, error);
    if (!sound) { std::cerr << error << std::endl; return 1; }
    auto loaded = memory();
    put (loaded, "load_ms", now() - start); put (loaded, "zones", (int) sound->zones.size());
    juce::int64 pcm = 0;
    for (const auto& z : sound->zones) pcm += (juce::int64) z.audio.getNumChannels() * z.audio.getNumSamples() * sizeof (float);
    put (loaded, "decoded_zone_bytes", pcm); emit ("loaded", loaded);
    libero::ParamSet defaults;
    libero::applyJsonParams (defaults, sound->params);
    defaults.setChoice ("mode", "Poli"); defaults.set ("voices", 32);
    libero::Engine engine;
    engine.setParameters (defaults); engine.prepare (rate, 256);
    engine.submitSound (std::move (sound)); engine.finishLoadingOffline();
    for (const int block : { 64, 128, 256 })
        for (const bool bypass : { false, true })
            for (const int notes : { 0, 1, 8, 32 })
            {
                auto params = defaults;
                if (bypass)
                    for (const char* id : { "rev_mix", "echo_mix", "tape_mix", "res_mix", "caldi_amount" }) params.set (id, 0);
                engine.setParameters (params); engine.prepare (rate, block); engine.reset();
                std::vector<float> left ((size_t) block), right ((size_t) block);
                juce::MidiBuffer midi;
                for (int n = 0; n < notes; ++n) midi.addEvent (juce::MidiMessage::noteOn (1, 48 + n, (juce::uint8) 90), 0);
                const auto firstStart = now();
                engine.process (left.data(), right.data(), block, midi);
                const auto firstBlockUs = (now() - firstStart) * 1000;
                midi.clear();
                const int warmup = (int) (.2 * rate / block);
                double warmupPeakUs = 0;
                for (int i = 0; i < warmup; ++i)
                {
                    const auto start = now();
                    engine.process (left.data(), right.data(), block, midi);
                    warmupPeakUs = std::max (warmupPeakUs, (now() - start) * 1000);
                }
                const int count = (int) (2 * rate / block);
                std::vector<double> us; us.reserve ((size_t) count);
                bool finite = true; int maxVoices = 0, minVoices = 32;
                for (int i = 0; i < count; ++i)
                {
                    const auto t = now(); engine.process (left.data(), right.data(), block, midi);
                    us.push_back ((now() - t) * 1000);
                    maxVoices = std::max (maxVoices, engine.getActiveVoiceCount());
                    minVoices = std::min (minVoices, engine.getActiveVoiceCount());
                    for (int k = 0; k < block; ++k) finite = finite && std::isfinite (left[(size_t) k]) && std::isfinite (right[(size_t) k]);
                }
                auto row = timings (std::move (us), block * 1.e6 / rate);
                put (row, "block", block); put (row, "requested_notes", notes);
                put (row, "first_block_us", firstBlockUs); put (row, "warmup_peak_us", warmupPeakUs);
                put (row, "min_active_voices", minVoices); put (row, "max_active_voices", maxVoices);
                put (row, "effect_mixes_zero", bypass); put (row, "finite", finite); emit ("audio", row);
                if (!finite) return 1;
            }
    return 0;
}

inline void pump (int ms) { juce::MessageManager::getInstance()->runDispatchLoopUntil (ms); }
inline int initialLoadCheck (const juce::String& path)
{
    if (juce::SystemStats::getEnvironmentVariable ("LIBERO_HOME", {}).isEmpty()) return 2;
    const auto previous = libero::library::readConfig()["last_sound"];
    if (!libero::library::writeConfigValue ("last_sound", path)) return 1;
    auto automatic = std::make_unique<libero::LiberoProcessor>();
    auto requested = std::make_unique<libero::LiberoProcessor>();
    bool replied = false, failed = false;
    requested->loadSound (juce::File (path).getChildFile ("missing-sound"), true,
        [&] (bool ok, juce::String) { replied = true; failed = !ok; });
    pump (1500);
    const bool defaultLoaded = automatic->getCurrentSoundPath() == juce::File (path).getFullPathName();
    const bool choicePreserved = replied && failed && requested->getCurrentSoundPath().isEmpty();
    libero::library::writeConfigValue ("last_sound", previous);
    std::cout << "initial-load: default=" << defaultLoaded << " explicit-choice-preserved=" << choicePreserved << std::endl;
    return defaultLoaded && choicePreserved ? 0 : 1;
}
inline juce::String evaluate (juce::WebBrowserComponent& browser, const juce::String& js)
{
    struct Result { bool done = false; juce::String text; };
    auto result = std::make_shared<Result>();
    browser.evaluateJavascript (js, [result] (juce::WebBrowserComponent::EvaluationResult r)
    {
        if (auto* v = r.getResult()) result->text = v->toString();
        result->done = true;
    });
    for (int i = 0; i < 200 && !result->done; ++i) pump (10);
    return result->text;
}
class LiveAudio : public juce::Thread
{
public:
    explicit LiveAudio (std::vector<std::unique_ptr<libero::LiberoProcessor>>& p)
        : Thread ("Libero performance audio"), processors (p) { samples.reserve (4096); }
    void run() override
    {
        juce::AudioBuffer<float> buffer (2, 256);
        juce::MidiBuffer midi;
        const auto start = now(); int blocks = 0;
        while (!threadShouldExit())
        {
            const auto t = now();
            for (auto& proc : processors)
            {
                buffer.clear(); midi.clear();
                if (blocks == 0)
                    for (int n = 0; n < 32; ++n) midi.addEvent (juce::MidiMessage::noteOn (1, 48 + n, (juce::uint8) 90), 0);
                proc->processBlock (buffer, midi);
                for (int c = 0; c < 2; ++c)
                    for (int n = 0; n < 256; ++n) finite = finite && std::isfinite (buffer.getSample (c, n));
            }
            if (samples.size() < 4096) samples.push_back ((now() - t) * 1000);
            ++blocks;
            const auto remaining = start + blocks * 256.0 * 1000 / 48000 - now();
            if (remaining >= 1) wait ((int) remaining);
        }
    }
    std::vector<double> samples;
    bool finite = true;
private:
    std::vector<std::unique_ptr<libero::LiberoProcessor>>& processors;
};
inline int ui (const juce::String& path, int instances)
{
    emit ("baseline", memory());
    std::vector<std::unique_ptr<libero::LiberoProcessor>> processors;
    std::vector<std::unique_ptr<juce::AudioProcessorEditor>> editors;
    for (int i = 0; i < instances; ++i)
    {
        auto proc = std::make_unique<libero::LiberoProcessor>();
        proc->setPlayConfigDetails (0, 2, 48000, 256); proc->prepareToPlay (48000, 256);
        const double start = now();
        bool done = false, ok = false;
        juce::String loadError;
        proc->loadSound (juce::File (path), true, [&] (bool loaded, juce::String message) { ok = loaded; loadError = message; done = true; });
        for (int tick = 0; tick < 3000 && !done; ++tick) pump (10);
        if (!done || !ok) { std::cerr << "load failed: " << path << ": " << loadError << std::endl; return 1; }
        // Install the pending sound without a capture buffer or a hardware audio device.
        juce::AudioBuffer<float> buffer (2, 256); juce::MidiBuffer midi; buffer.clear(); proc->processBlock (buffer, midi);
        auto row = memory(); put (row, "instances", i + 1); put (row, "load_ms", now() - start);
        put (row, "reported_latency_samples", proc->getLatencySamples()); emit ("processor_loaded", row);
        processors.push_back (std::move (proc));
    }
    for (int i = 0; i < instances; ++i)
    {
        const auto start = now();
        std::unique_ptr<juce::AudioProcessorEditor> editor (processors[(size_t) i]->createEditorAndMakeActive());
        const auto construction = now() - start;
        editor->addToDesktop (juce::ComponentPeer::windowHasTitleBar);
        editor->setTopLeftPosition (80 + i * 40, 80 + i * 40); editor->setVisible (true);
        editor->toFront (true);
        auto& browser = static_cast<libero::LiberoEditor*> (editor.get())->getBrowser();
        bool ready = false;
        for (int tick = 0; tick < 600 && !ready; ++tick)
        {
            pump (20);
            ready = evaluate (browser, "String(!!document.getElementById('lib-count')?.textContent)") == "true";
        }
        if (!ready) { std::cerr << "editor readiness timed out" << std::endl; return 1; }
        evaluate (browser, "document.querySelector('#lib-crumb button')?.click(); 'root'");
        auto row = memory(); put (row, "editors", i + 1); put (row, "construction_ms", construction);
        put (row, "ready_ms", now() - start); emit ("editor_ready", row);
        editors.push_back (std::move (editor));
    }
    auto& browser = static_cast<libero::LiberoEditor*> (editors.back().get())->getBrowser();
    evaluate (browser, R"JS((() => {
      window.__bench = { done: false };
      const paint=()=>new Promise(resolve=>{let raf=0;
        const timeout=setTimeout(()=>{cancelAnimationFrame(raf);resolve(false);},500);
        raf=requestAnimationFrame(()=>{raf=requestAnimationFrame(()=>{clearTimeout(timeout);resolve(true);});});});
      const frames = ms => new Promise(resolve => {
        const values = []; let last = performance.now(), start = last;
        let raf=0, complete=false;
        const finish = stalled => { if(complete)return;complete=true;cancelAnimationFrame(raf);clearTimeout(timeout);
          values.sort((a,b)=>a-b);resolve({frames:values.length, fps:values.length*1000/(performance.now()-start),
            p95_frame_ms:values.length?values[Math.floor(.95*(values.length-1))]:null,
            max_frame_ms:values.length?values.at(-1):null, stalled, visibility:document.visibilityState}); };
        const timeout=setTimeout(()=>finish(true),ms+1500);
        const tick = t => { values.push(t-last); last=t;
          if (t-start < ms) raf=requestAnimationFrame(tick);
          else finish(false); };
        raf=requestAnimationFrame(tick);
      });
      (async () => {
        const j = await import('/juce/index.js'); const f = n => j.getNativeFunction(n);
        let t=performance.now(); const sounds=await f('listSounds')();
        window.__bench.list_ms=performance.now()-t; window.__bench.sounds=sounds.length;
        window.__bench.list_bytes=JSON.stringify(sounds).length;
        window.__bench.closed=await frames(1500);
        const toggle=document.getElementById('lib-toggle');
        if (toggle.getAttribute('aria-expanded') !== 'true') toggle.click();
        t=performance.now(); window.__bench.library_painted=await paint();
        window.__bench.library_paint_ms=performance.now()-t;
        window.__bench.open=await frames(1500);
        window.__bench.dom_nodes=document.getElementsByTagName('*').length;
        window.__bench.tile_nodes=document.querySelectorAll('#grid .tile').length;
        window.__bench.stack_nodes=document.querySelectorAll('.content-stack svg').length;
        window.__bench.svg_nodes=document.querySelectorAll('svg').length;
        window.__bench.hover_initial=document.querySelectorAll('.content-card').length;
        const hover=[...document.querySelectorAll('#grid .folder')].find(t=>Number(t.querySelector('.no')?.textContent)>0)?.querySelector('.thumb');
        if (hover) { hover.dispatchEvent(new Event('pointerenter'));
          await new Promise(r=>setTimeout(r,100));
          window.__bench.hover_cards=hover.querySelectorAll('.content-card svg').length; }
        const folder=hover;
        if (folder) { t=performance.now(); folder.click();
          window.__bench.folder_painted=await paint();
          window.__bench.folder_paint_ms=performance.now()-t; }
        window.__bench.done=true;
      })().catch(e=>{window.__bench.error=String(e);window.__bench.done=true;}); return 'started'; })())JS");
    juce::var response;
    for (int tick = 0; tick < 200; ++tick)
    {
        pump (50); response = juce::JSON::parse (evaluate (browser, "JSON.stringify(window.__bench || {})"));
        if ((bool) response["done"]) break;
    }
    emit ("ui", response.isObject() ? response : object());
    if (!(bool) response["done"] || response.hasProperty ("error")) return 1;
    const auto before = memory(); const auto start = now(); pump (2000);
    auto visible = memory(); put (visible, "elapsed_ms", now() - start);
    put (visible, "cpu_delta_seconds", (double) visible["cpu_seconds"] - (double) before["cpu_seconds"]);
    emit ("visible_idle", visible);
    for (auto& editor : editors) editor->setVisible (false);
    pump (200); const auto hiddenStart = memory(); const auto hiddenTime = now(); pump (2000);
    auto hidden = memory(); put (hidden, "elapsed_ms", now() - hiddenTime);
    put (hidden, "javascript_visibility", evaluate (browser, "JSON.stringify({document:document.visibilityState, native: window.__liberoEditorVisible})"));
    put (hidden, "cpu_delta_seconds", (double) hidden["cpu_seconds"] - (double) hiddenStart["cpu_seconds"]);
    emit ("hidden_idle", hidden);
    for (auto& editor : editors) editor->setVisible (true);
    pump (200);
    for (auto& proc : processors)
    {
        for (const auto& setting : { std::pair<const char*, float> { "mode", 0 }, { "voices", 32 } })
            if (auto* param = proc->getState().getParameter (setting.first))
                param->setValueNotifyingHost (param->convertTo0to1 (setting.second));
    }
    LiveAudio audio (processors); audio.startThread (juce::Thread::Priority::high);
    pump (1800); audio.stopThread (2000);
    auto playing = timings (std::move (audio.samples), 256 * 1.e6 / 48000);
    put (playing, "instances", instances); put (playing, "notes_per_instance", 32); put (playing, "finite", audio.finite);
    emit ("audio_with_editors", playing);
    if (!audio.finite) return 1;
    editors.clear(); pump (500); emit ("editors_destroyed", memory());
    processors.clear(); pump (500); emit ("processors_destroyed", memory());
    return 0;
}
}
