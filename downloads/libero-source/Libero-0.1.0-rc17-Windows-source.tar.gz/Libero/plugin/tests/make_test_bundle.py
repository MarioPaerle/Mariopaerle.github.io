#!/usr/bin/env python3
"""Writes a small synthetic Libero bundle for engine tests (stdlib only).

    make_test_bundle.py <out_sound_folder> [--rate 44100] [--no-ir] [--pads] [--takes N]
                        [--dyn N] [--dyn-source cc1] [--rt-decay DB_PER_S] [--humanize C,MS,DB]
                        [--rr-reset MS] [--tune-cents C]

bundle/2 options: --dyn gives each root N dynamics layers (layer k = harmonic k+1 alone, all at
the same RMS, so they are uncorrelated and an equal-power crossfade keeps the level flat).

The folder gets build/manifest.json plus float32 WAV zones: a looped harmonic body at five
roots (mono and stereo), an unpitched noise attack, a pitched tail, an air bed and an IR.
The rate defaults to 44100 so rendering at 48000 exercises the load-time resampler.
"""

import json
import math
import random
import struct
import sys
from pathlib import Path


PREROLL = 0   # samples of silence before sampled layers (--onset-ms)


def write_wav_float(path, channels, rate):
    """channels: list of equal-length lists of floats."""
    name = Path(path).name
    if PREROLL and not (name.startswith('air') or name.startswith('ir')):
        channels = [[0.0] * PREROLL + list(c) for c in channels]
    n = len(channels[0])
    nch = len(channels)
    data = bytearray()
    for i in range(n):
        for c in range(nch):
            data += struct.pack('<f', channels[c][i])
    fmt = struct.pack('<HHIIHH', 3, nch, rate, rate * nch * 4, nch * 4, 32)
    fact = struct.pack('<I', n)
    body = (b'WAVE' + b'fmt ' + struct.pack('<I', len(fmt)) + fmt
            + b'fact' + struct.pack('<I', len(fact)) + fact
            + b'data' + struct.pack('<I', len(data)) + bytes(data))
    Path(path).write_bytes(b'RIFF' + struct.pack('<I', len(body)) + body)


def midi_hz(n):
    return 440.0 * 2 ** ((n - 69) / 12)


def body_zone(root, rate, stereo):
    f = midi_hz(root)
    dur = 2.0
    n = int(dur * rate)
    out_l, out_r = [], []
    for i in range(n):
        t = i / rate
        env = min(1.0, t / 0.01)
        s = (math.sin(2 * math.pi * f * t) * 0.5
             + math.sin(2 * math.pi * 2 * f * t) * 0.2
             + math.sin(2 * math.pi * 3 * f * t) * 0.1) * env * 0.25
        out_l.append(s)
        out_r.append(math.sin(2 * math.pi * f * 1.002 * t) * 0.12 * env + s * 0.5)
    return [out_l, out_r] if stereo else [out_l]


def noise(n, rng, amp):
    return [(rng.random() * 2 - 1) * amp for _ in range(n)]


def drums(folder, rate=44100):
    """Unpitched per-key zones: one-shot kick (36) and a non one-shot twin (40), an open hat
    (46, group 1), a closed hat (42, group 1) and a silent pedal hat (44, chokes group 1)."""
    build = folder / 'build'
    build.mkdir(parents=True, exist_ok=True)

    def tone(name, hz, dur, tau, amp=0.3):
        n = int(dur * rate)
        x = [amp * math.sin(2 * math.pi * hz * i / rate) * math.exp(-i / (tau * rate)) for i in range(n)]
        write_wav_float(build / name, [x], rate)

    tone('body_k036_v127.wav', 110, 3.0, 2.0)
    tone('body_k040_v127.wav', 110, 3.0, 2.0)
    tone('body_k046_v127.wav', 900, 3.0, 3.0)
    tone('body_k042_v127.wav', 1500, 0.1, 0.05)
    tone('body_k044_v127.wav', 1500, 0.05, 0.02, amp=1e-5)
    spec = [(36, {'one_shot': True}), (40, {}), (46, {'one_shot': True, 'choke_group': 1}),
            (42, {'one_shot': True, 'choke_group': 1}), (44, {'one_shot': True, 'chokes': [1]})]
    zones = [dict({'layer': 'body', 'file': f'body_k{k:03d}_v127.wav', 'root': k, 'pitched': False,
                   'lo': k, 'hi': k, 'vel_lo': 1, 'vel_hi': 127, 'gain_db': 0.0, 'loop': None}, **extra)
             for k, extra in spec]
    manifest = {'format': 'libero.bundle/2', 'slug': folder.name, 'title': 'Test Drums', 'subtitle': 'synthetic',
                'tags': ['test'], 'description': 'One-shot and choke test kit.', 'sample_rate': rate,
                'compiled_at': '2026-09-30T12:00:00Z', 'source_hash': 'test', 'zones': zones, 'ir': None,
                'figure': None, 'params': {'amp_release': 100, 'rev_mix': 0, 'lvl_air': -60}}
    (build / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    print(build)


def artic(folder, rate=44100):
    """Articulations: sus (key 24), stacc (key 25), pizz (key 26) and trem (no key, parameter only).
    One body zone each over keys 27..127 (keyswitch keys play nothing): the same note sounds at
    1, 2, 3 and 4 times its pitch, so the active articulation can be read from the spectrum. A
    tail without an articulation belongs to all of them."""
    build = folder / 'build'
    build.mkdir(parents=True, exist_ok=True)
    arts = [('sus', 'Sostenuto', 24), ('stacc', 'Staccato', 25), ('pizz', 'Pizzicato', 26), ('trem', 'Tremolo', None)]
    zones = []
    for i, (aid, _, _) in enumerate(arts):
        f = midi_hz(60) * (i + 1)
        n = int(2.0 * rate)
        x = [0.3 * math.sin(2 * math.pi * f * j / rate) * min(1.0, j / (0.01 * rate)) for j in range(n)]
        name = f'body_{aid}_n060.wav'
        write_wav_float(build / name, [x], rate)
        zones.append({'layer': 'body', 'file': name, 'root': 60, 'pitched': True, 'lo': 27, 'hi': 127,
                      'vel_lo': 1, 'vel_hi': 127, 'gain_db': 0.0,
                      'loop': {'start': int(0.5 * rate), 'end': int(1.5 * rate), 'crossfade': 2048},
                      'articulation': aid})
    manifest = {'format': 'libero.bundle/2', 'slug': folder.name, 'title': 'Test Archi', 'subtitle': 'synthetic',
                'tags': ['test'], 'description': 'Articulation keyswitch test.', 'sample_rate': rate,
                'compiled_at': '2026-09-30T12:00:00Z', 'source_hash': 'test', 'zones': zones, 'ir': None,
                'figure': None, 'articulations': [{'id': a, 'name': n, 'key': k} for a, n, k in arts],
                'params': {'amp_release': 100, 'rev_mix': 0, 'lvl_air': -60, 'lvl_tail': -60, 'lvl_attack': -60}}
    (build / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    print(build)


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(2)
    folder = Path(args[0])
    if '--drums' in args:
        drums(folder)
        return
    if '--artic' in args:
        artic(folder)
        return
    rate = 44100
    with_ir = '--no-ir' not in args
    pads = '--pads' in args
    # --pads: manifest params body only, slow attack, dry (for swap tests)
    opt = lambda name, default=None: args[args.index(name) + 1] if name in args else default
    takes = int(opt('--takes', 1))
    dyn_layers = int(opt('--dyn', 0))
    dyn_attack = int(opt('--dyn-attack', 0))   # attack dynamics layers: independent noise at -12..0 dB
    dyn_source = opt('--dyn-source')
    dyn_xf = opt('--dyn-xf')                   # manifest dynamics.crossfade (0 = hard layer switch)
    rt_decay = opt('--rt-decay')
    humanize = opt('--humanize')
    rr_reset = opt('--rr-reset')
    tune_cents = opt('--tune-cents')
    onset_ms = opt('--onset-ms')          # prepend this much silence to attack/body/tail and declare it
    onset_undeclared = '--onset-undeclared' in args   # same pre-roll, not declared (reference)
    osc_only = '--osc-only' in args
    v2 = (any(x is not None for x in (dyn_source, rt_decay, humanize, rr_reset, tune_cents, onset_ms))
          or dyn_xf is not None or dyn_layers > 0 or dyn_attack > 0 or osc_only)
    if '--rate' in args:
        rate = int(args[args.index('--rate') + 1])
    pre = int(float(onset_ms or 0) * rate / 1000)
    global PREROLL
    PREROLL = pre

    build = folder / 'build'
    build.mkdir(parents=True, exist_ok=True)
    rng = random.Random(1234)

    roots = [36, 48, 60, 72, 84]
    zones = []
    bounds = [0] + [(a + b) // 2 + 1 for a, b in zip(roots, roots[1:])] + [128]
    # Round-robin takes are told apart by level: take t plays at TAKE_GAIN[t].
    take_gain = [1.0, 0.7, 0.5, 0.35, 0.25]
    suffix = (lambda t: f'_t{t}') if takes > 1 else (lambda t: '')
    for k, root in enumerate(roots):
        if dyn_layers:
            for d in range(dyn_layers):
                for t in range(takes):
                    name = f'body_n{root:03d}_d{d}{suffix(t)}.wav'
                    f = midi_hz(root) * (d + 1)
                    x = [0.2 * take_gain[t] * math.sin(2 * math.pi * f * i / rate) * min(1.0, i / (0.01 * rate))
                         for i in range(int(7.0 * rate))]
                    write_wav_float(build / name, [x], rate)
                    z = {'layer': 'body', 'file': name, 'root': root, 'pitched': True,
                         'lo': bounds[k], 'hi': bounds[k + 1] - 1, 'vel_lo': 1, 'vel_hi': 127, 'gain_db': 0.0,
                         'loop': {'start': int(6.0 * rate), 'end': int(6.9 * rate), 'crossfade': 2048},
                         'dyn': [d / dyn_layers, (d + 1) / dyn_layers]}
                    if takes > 1:
                        z['take'] = t
                    zones.append(z)
            continue
        for t in range(takes):
            name = f'body_n{root:03d}_v100{suffix(t)}.wav'
            chans = [[v * take_gain[t] for v in c] for c in body_zone(root, rate, stereo=(k % 2 == 0))]
            write_wav_float(build / name, chans, rate)
            z = {
                'layer': 'body', 'file': name, 'root': root, 'pitched': True,
                'lo': bounds[k], 'hi': bounds[k + 1] - 1, 'vel_lo': 1, 'vel_hi': 127,
                'gain_db': 0.0,
                'loop': {'start': int(0.5 * rate), 'end': int(1.6 * rate), 'crossfade': 2048},
            }
            if takes > 1:
                z['take'] = t
            if tune_cents is not None and root == 60:
                z['tune_cents'] = float(tune_cents)
            zones.append(z)

    n = int(0.06 * rate)
    att = [s * (1 - i / n) ** 2 for i, s in enumerate(noise(n, rng, 0.5))]
    for d in range(dyn_attack):
        gain = 10 ** ((-12 + 12 * d / max(1, dyn_attack - 1)) / 20)
        r2 = random.Random(77 + d)
        x = [(r2.random() * 2 - 1) * 0.4 * gain for _ in range(int(0.08 * rate))]
        name = f'attack_d{d}.wav'
        write_wav_float(build / name, [x, x[::-1]], rate)
        zones.append({'layer': 'attack', 'file': name, 'root': 60, 'pitched': False, 'lo': 0, 'hi': 127,
                      'vel_lo': 1, 'vel_hi': 127, 'gain_db': 0.0, 'loop': None,
                      'dyn': [d / dyn_attack, (d + 1) / dyn_attack]})
    for t in range(takes if not dyn_attack else 0):
        name = f'attack{suffix(t)}.wav'
        write_wav_float(build / name, [[v * take_gain[t] for v in att], [v * take_gain[t] for v in att[::-1]]], rate)
        z = {'layer': 'attack', 'file': name, 'root': 60, 'pitched': False,
             'lo': 0, 'hi': 127, 'vel_lo': 1, 'vel_hi': 127, 'gain_db': -3.0, 'loop': None}
        if takes > 1:
            z['take'] = t
        zones.append(z)

    n = int(0.25 * rate)
    tail = [math.sin(2 * math.pi * midi_hz(60) * i / rate) * 0.3 * math.exp(-i / (0.05 * rate)) for i in range(n)]
    write_wav_float(build / 'tail_n060_v100.wav', [tail], rate)
    tz = {'layer': 'tail', 'file': 'tail_n060_v100.wav', 'root': 60, 'pitched': True,
          'lo': 0, 'hi': 127, 'vel_lo': 1, 'vel_hi': 127, 'gain_db': 0.0, 'loop': None}
    if rt_decay is not None:
        tz['rt_decay'] = float(rt_decay)
        tz['rt_min_db'] = -40.0
    zones.append(tz)

    n = int(3.0 * rate)
    b = [0.0] * 3
    air_l, air_r = [], []
    for i in range(n):
        w = rng.random() * 2 - 1
        b[0] = 0.99 * b[0] + 0.1 * w
        air_l.append(b[0] * 0.2)
        b[1] = 0.99 * b[1] + 0.1 * (rng.random() * 2 - 1)
        air_r.append(b[1] * 0.2)
    write_wav_float(build / 'air.wav', [air_l, air_r], rate)
    zones.append({'layer': 'air', 'file': 'air.wav', 'root': 60, 'pitched': False,
                  'lo': 0, 'hi': 127, 'vel_lo': 1, 'vel_hi': 127, 'gain_db': 0.0, 'loop': None})

    ir_name = None
    if with_ir:
        n = int(1.5 * rate)
        irl = [(rng.random() * 2 - 1) * math.exp(-i / (0.3 * rate)) for i in range(n)]
        irr = [(rng.random() * 2 - 1) * math.exp(-i / (0.3 * rate)) for i in range(n)]
        irl[0] = irr[0] = 1.0
        write_wav_float(build / 'ir.wav', [irl, irr], rate)
        ir_name = 'ir.wav'

    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">'
           '<circle cx="256" cy="256" r="180" fill="none" stroke="#c9a86a" stroke-width="3"/></svg>')
    (build / 'figure.svg').write_text(svg)
    (folder / 'figure.svg').write_text(svg)

    manifest = {
        'format': 'libero.bundle/2' if v2 else 'libero.bundle/1',
        'slug': folder.name,
        'title': 'Test Tone',
        'subtitle': 'sine partials, synthetic',
        'tags': ['test'],
        'description': 'Synthetic bundle used by plugin/tests.',
        'sample_rate': rate,
        'compiled_at': '2026-09-30T12:00:00Z',
        'source_hash': 'test',
        'zones': zones,
        'ir': ir_name,
        'figure': 'figure.svg',
        'accent': '#c9a86a',
        'params': ({'lvl_attack': -60, 'lvl_tail': -60, 'lvl_air': -60, 'amp_attack': 40, 'rev_mix': 0}
                   if pads else {'amp_release': 600, 'rev_mode': 'Basilica', 'rev_mix': 0.25}),
    }
    if dyn_source is not None:
        manifest['dynamics'] = {'source': dyn_source, 'velocity_curve': 1.0}
    if dyn_xf is not None:
        manifest.setdefault('dynamics', {'source': 'velocity', 'velocity_curve': 1.0})['crossfade'] = float(dyn_xf)
    if humanize is not None:
        c, ms, db = (float(x) for x in humanize.split(','))
        manifest['humanize'] = {'cents': c, 'ms': ms, 'db': db}
    if rr_reset is not None:
        manifest['rr_reset_ms'] = float(rr_reset)
    if pre and not onset_undeclared:
        manifest['onset_ms'] = float(onset_ms)
    if osc_only:
        for f in build.glob('*.wav'):
            f.unlink()
        manifest['zones'] = []
        manifest['ir'] = None
        manifest['params'] = {'osc1_level': -6.0, 'osc1_wave': 'Sega', 'osc1_voices': 3, 'rev_mix': 0.0}
    if '--no-loops' in args:
        for zone in manifest['zones']:
            if zone['layer'] == 'body':
                zone['loop'] = None
    (build / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    print(build)


if __name__ == '__main__':
    main()
