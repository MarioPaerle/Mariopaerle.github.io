#!/usr/bin/env python3
"""Stats for float32 WAVs written by libero-render: peak, rms, non-finite count, per-window rms."""
import math, struct, sys

def read(path):
    b = open(path, 'rb').read()
    assert b[:4] == b'RIFF' and b[8:12] == b'WAVE'
    pos, fmt, data = 12, None, None
    while pos < len(b):
        cid, size = b[pos:pos+4], struct.unpack('<I', b[pos+4:pos+8])[0]
        body = b[pos+8:pos+8+size]
        if cid == b'fmt ':
            fmt = struct.unpack('<HHIIHH', body[:16])
        elif cid == b'data':
            data = body
        pos += 8 + size + (size & 1)
    tag, nch, rate, _, _, bits = fmt
    n = len(data) // 4
    vals = struct.unpack('<%df' % n, data)
    return rate, nch, [vals[c::nch] for c in range(nch)]

def stats(path, windows=0):
    rate, nch, ch = read(path)
    allv = [v for c in ch for v in c]
    bad = sum(1 for v in allv if not math.isfinite(v))
    fin = [v for v in allv if math.isfinite(v)]
    peak = max(abs(v) for v in fin) if fin else 0
    rms = math.sqrt(sum(v*v for v in fin) / max(1, len(fin)))
    out = {'rate': rate, 'channels': nch, 'seconds': len(ch[0]) / rate, 'peak': peak, 'rms': rms, 'non_finite': bad}
    if windows:
        w = int(rate * windows)
        out['window_rms_db'] = [round(20*math.log10(max(1e-9, math.sqrt(sum(v*v for v in ch[0][i:i+w])/w))), 1)
                                for i in range(0, len(ch[0]) - w + 1, w)]
    return out

if __name__ == '__main__':
    import json
    win = float(sys.argv[2]) if len(sys.argv) > 2 else 0
    print(json.dumps(stats(sys.argv[1], win)))
