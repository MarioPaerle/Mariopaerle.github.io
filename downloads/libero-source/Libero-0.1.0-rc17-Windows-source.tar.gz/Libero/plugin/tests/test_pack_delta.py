#!/usr/bin/env python3
"""Exercise sparse updates, verified reuse, atomic install, and full-download fallback."""
import functools
import hashlib
import http.server
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import zipfile

host = Path(sys.argv[1]).resolve()
fixture = Path(sys.argv[2]).resolve()
root = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('delta_builder', root/'scripts/build_pack_delta.py')
builder = importlib.util.module_from_spec(spec); spec.loader.exec_module(builder)


def run(home, args, ok=True):
    p = subprocess.run([str(host), *map(str, args)], env=dict(os.environ, LIBERO_HOME=str(home)), capture_output=True, text=True, timeout=120)
    assert (p.returncode == 0) == ok, (args, p.stdout, p.stderr)
    return json.loads(p.stdout.strip().splitlines()[-1])


with tempfile.TemporaryDirectory(prefix='libero-delta-') as td:
    work = Path(td); home = work/'home'; source = work/'base'/'test-bank'
    shutil.copytree(fixture/'build', source/'test-tone/build')
    meta = dict(format='libero.bank/1', slug='test-bank', title='Test', subtitle='', description='', version='1.0.0', author='', license='CC0', created='2026-01-01T00:00:00Z', updated='2026-01-01T00:00:00Z', figure=None)
    (source/'bank.json').write_text(json.dumps(meta))
    (source/'removed.txt').write_text('old')
    def archive(out):
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
            for f in source.rglob('*'):
                if f.is_file(): z.write(f, f.relative_to(source.parent).as_posix())
    before=work/'before.liberobank'; after=work/'after.liberobank'; patch=work/'update.liberodelta'
    archive(before)
    run(home, ['--import-bank',before])
    meta['version']='1.0.1'; (source/'bank.json').write_text(json.dumps(meta))
    (source/'removed.txt').unlink(); (source/'added.txt').write_text('new')
    mpath=source/'test-tone/build/manifest.json'; m=json.loads(mpath.read_text());m['title']='Updated test tone';m['source_hash']='a'*64;mpath.write_text(json.dumps(m))
    archive(after)
    info=builder.build_delta(before,after,patch)
    assert info['bytes'] < after.stat().st_size and info['reused_files'] > 0
    output=work/'reconstructed'
    run(home,['--reconstruct-delta',patch,output,'test-bank','1.0.1'])
    with zipfile.ZipFile(after) as archive:
        assert {f.relative_to(output).as_posix() for f in output.rglob('*') if f.is_file()} == {n.split('/',1)[1] for n in archive.namelist()}
        assert all((output/n.split('/',1)[1]).read_bytes()==archive.read(n) for n in archive.namelist())
    shutil.rmtree(output)
    bank=home/'banks/test-bank'
    base_meta=(bank/'bank.json').read_bytes()
    run(home,['--reconstruct-delta',patch,output,'test-bank','9.0.0'],False)
    with zipfile.ZipFile(patch) as z: contents={n:z.read(n) for n in z.namelist()}
    for label, extra in [('traversal', {'files/../../escape':b'x'}), ('corrupt', {'files/added.txt':b'bad'})]:
        bad=work/f'{label}.zip'
        with zipfile.ZipFile(bad,'w') as z:
            for n,data in (contents|extra).items():z.writestr(n,data)
        run(home,['--reconstruct-delta',bad,output,'test-bank','1.0.1'],False)
        assert (bank/'bank.json').read_bytes()==base_meta
    unchanged=next(f for f in json.loads(contents['delta.json'])['files'] if not f['changed'])['path']
    saved=(bank/unchanged).read_bytes();(bank/unchanged).write_bytes(b'local edit')
    run(home,['--reconstruct-delta',patch,output,'test-bank','1.0.1'],False)
    (bank/unchanged).write_bytes(saved)
    requests=[]
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):requests.append(self.path);super().do_GET()
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(work)))
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    url=f'http://127.0.0.1:{server.server_port}'
    def asset(file):
        return dict(url=url+'/'+file.name,bytes=file.stat().st_size,uncompressed_bytes=10_000_000,sha256=hashlib.sha256(file.read_bytes()).hexdigest())
    entry=dict(id='test-bank',title='Test',version='1.0.1',sounds=1,**asset(after),deltas=[dict(from_version='1.0.0',**asset(patch))])
    cache=home/'cache/pack-catalog.json';cache.parent.mkdir(parents=True,exist_ok=True);cache.write_text(json.dumps(dict(format='libero.pack-catalog/1',packs=[entry])))
    before_inode=(bank/unchanged).stat().st_ino
    result=run(home,['--pack-download-check','test-bank'])
    if os.name != 'nt': assert (bank/unchanged).stat().st_ino == before_inode
    assert result['delta'] and result['received']==patch.stat().st_size and '/after.liberobank' not in requests
    assert not (bank/'removed.txt').exists() and (bank/'added.txt').read_text()=='new'
    # A damaged base transparently downloads the full archive instead of installing incomplete content.
    shutil.rmtree(bank);run(home,['--import-bank',before]);(bank/unchanged).write_bytes(b'local edit')
    requests.clear();result=run(home,['--pack-download-check','test-bank'])
    assert not result['delta'] and '/after.liberobank' in requests
    assert json.loads((bank/'bank.json').read_text())['version']=='1.0.1'
    server.shutdown();thread.join()
    print(json.dumps(dict(ok=True,changed=info['changed_files'],reused=info['reused_files'],patch_bytes=info['bytes'],full_bytes=after.stat().st_size,sparse_network=True,modified_base_fallback=True,unsafe_and_corrupt_rejected=True)))
