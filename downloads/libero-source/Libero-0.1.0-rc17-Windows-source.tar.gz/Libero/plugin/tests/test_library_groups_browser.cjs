// Headless interaction coverage; never opens a foreground window.
const {chromium} = require(process.env.LIBERO_PLAYWRIGHT || 'playwright');
(async () => {
  const browser = await chromium.launch({headless:true,executablePath:process.env.LIBERO_CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
  try {
    const page = await browser.newPage({viewport:{width:1200,height:800}});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto(process.env.LIBERO_UI_URL || 'http://127.0.0.1:8794/?drawer&agent=0');
    await page.locator('#lib-group').waitFor();
    await page.evaluate(async()=>{
      const {library}=await import('/js/library.js');
      document.querySelector('#drawer').remove();
      const node=(tag,id)=>{const n=document.createElement(tag);n.id=id;return n;};
      const drawer=node('section','fixture');drawer.className='drawer open';drawer.setAttribute('aria-hidden','false');
      document.querySelector('#libero')?.append(drawer);if(!drawer.isConnected)document.body.append(drawer);
      const grid=node('div','grid');grid.className='lib-grid';const search=node('input','search');search.type='search';
      const filterBar=node('div','filters'),sortBar=node('div','sort'),bankBar=node('div','banks'),crumb=node('div','crumb');
      const tools=node('div','tools');tools.className='drawer-tools';tools.append(search,filterBar,sortBar);
      drawer.append(crumb,bankBar,tools,grid);
      const banks=[{slug:'aria',title:'Aria',count:2},{slug:'blue',title:'Blue',count:2}];
      const sounds=[
        {slug:'grand',title:'Grand Piano',tags:['piano'],colorTag:1,bank:banks[0]},
        {slug:'felt',title:'Felt Piano',tags:['piano'],colorTag:2,bank:banks[1]},
        {slug:'pad',title:'Warm Pad',tags:['pad','warm','synth'],colorTag:1,bank:banks[0]},
        {slug:'flute',title:'Aulos',tags:['wind'],colorTag:0,bank:banks[1]},
      ].map(s=>({...s,path:'/fixture/'+s.slug,saved:true,favorite:false,figure:'',mtime:1}));
      const bridge={call:async name=>name==='listSounds'?sounds:name==='listBanks'?banks:name==='packDownloadStatus'?{state:'idle'}:null};
      window.groupFixture=library(bridge,{drawer,grid,toggle:node('button','toggle'),close:node('button','close'),count:node('span','count'),strip:node('div','strip'),search,filterBar,sortBar,bankBar,crumb,onChange:()=>{},onColorTag:()=>{},toast:()=>{}});
      await window.groupFixture.refresh();
    });
    const select=page.locator('#lib-group');
    await select.selectOption('instrument');
    await page.locator('[data-folder="@instrument:pianos"] .thumb').click();
    if(await page.locator('#grid .tile:not(.folder)').count()!==2)throw Error('Pianos did not span both packs');
    if(await page.getByRole('button',{name:'Delete pack…',exact:true}).count())throw Error('Group incorrectly exposes delete pack');
    await page.getByRole('button',{name:'Library',exact:true}).click();
    await select.selectOption('type');
    await page.locator('[data-folder="@type:warm"] .thumb').click();
    if(await page.locator('#grid .tile:not(.folder)').count()!==1)throw Error('Wrong warm group');
    await select.selectOption('color');
    await page.locator('[data-folder="@color:1"] .thumb').click();
    if(await page.locator('#grid .tile:not(.folder)').count()!==2)throw Error('Wrong color group');
    await select.selectOption('instrument');
    await page.locator('#search').fill('felt');
    await page.waitForTimeout(120);
    await page.locator('[data-folder="@instrument:pianos"] .thumb').click();
    if(await page.locator('#grid .tile:not(.folder)').count()!==1)throw Error('Search not respected inside group');
    if(await page.evaluate(()=>localStorage.getItem('libero.lib.group'))!=='instrument')throw Error('Group preference not persisted');
    await page.getByRole('button',{name:'Library',exact:true}).click();
    await select.selectOption('pack');
    await page.locator('[data-folder="aria"] .thumb').click();
    if(await page.locator('#grid .tile:not(.folder)').count()!==2)throw Error('Pack navigation changed');
    await page.getByRole('button',{name:'Library',exact:true}).click();
    await select.selectOption('instrument');
    await page.screenshot({path:process.env.LIBERO_GROUP_SCREENSHOT || '/tmp/libero-instrument-groups.png'});
    await page.reload();
    await page.locator('#lib-group').waitFor();
    if(await page.locator('#lib-group').inputValue()!=='instrument')throw Error('Grouping lost after reload');
    await page.locator('#grid .folder').first().waitFor();
    await page.waitForFunction(()=>document.querySelector('#drawer')?.classList.contains('open') && Number(getComputedStyle(document.querySelector('#drawer')).opacity) > .99 && Number(getComputedStyle(document.body).opacity) > .99);
    await page.screenshot({path:'/tmp/libero-grouping-preview.png'});
    if(errors.length)throw Error(errors.join('\n'));
    console.log('PASS: cross-pack instrument/type/color groups, search, counts, persistence, safe actions, pack navigation');
  } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exit(1);});
