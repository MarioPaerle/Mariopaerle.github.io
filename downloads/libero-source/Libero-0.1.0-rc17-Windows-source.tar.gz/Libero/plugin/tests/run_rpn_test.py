"""Build test_rpn against the exact existing universal renderer engine objects.

First: cmake --build build --target libero_render -j2
Then: python/.venv/bin/python plugin/tests/run_rpn_test.py [build-dir]
"""
from pathlib import Path
import shlex,subprocess,sys,tempfile
root=Path(__file__).resolve().parents[2];build=Path(sys.argv[1]if len(sys.argv)>1 else root/'build').resolve()
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','libero_render'],text=True).splitlines()
compile_line=next(x for x in commands if ' -c 'in x and '/plugin/cli/main.cpp'in x)
link_line=commands[-1];args=shlex.split(compile_line);new=[];i=0
with tempfile.TemporaryDirectory(prefix='libero-rpn-test-')as td:
    obj=Path(td)/'rpn.o';exe=Path(td)/'rpn-test'
    while i<len(args):
        a=args[i]
        if a in ['-o','-MF','-MT']:
            if a=='-o':new+=['-o',str(obj)]
            i+=2;continue
        if a in ['-MD','-MMD']:i+=1;continue
        new.append(str(root/'plugin/tests/test_rpn.cpp')if a.endswith('/plugin/cli/main.cpp')else a);i+=1
    subprocess.run(new,cwd=build,check=True)
    args=shlex.split(link_line);begin=next(i for i,a in enumerate(args)if a.endswith('/c++')or a.endswith('/clang++'));args=args[begin:]
    args=args[:args.index('&&')]if '&&'in args else args
    args=[str(obj)if a.endswith('/cli/main.cpp.o')else a for a in args];args[args.index('-o')+1]=str(exe)
    subprocess.run(args,cwd=build,check=True);subprocess.run([str(exe)],check=True)
