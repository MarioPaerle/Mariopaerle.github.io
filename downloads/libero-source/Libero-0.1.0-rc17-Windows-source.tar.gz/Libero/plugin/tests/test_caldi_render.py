"""Native source-music QA. Usage: test_caldi_render.py <renderer> <sound> <output-dir>.

Optional fourth argument is the previous installed renderer: verifies byte-exact
dry backwards compatibility. No changes to the sound, sources or installed binaries.
"""
from pathlib import Path
import hashlib,json,subprocess,sys,time
import numpy as np
import soundfile as sf

exe,sound,out=sys.argv[1],Path(sys.argv[2]),Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
notes='48:0:1.0:40,60:1.3:1.5:100,64:1.3:1.5:100,67:1.3:1.5:100,72:3.2:1:120,60:4.4:60:100'
cases=[('new-dry',None,exe),('explicit-off',dict(caldi_mode='Spento',caldi_amount=.65,caldi_grain=1,caldi_motion=1,caldi_output=3),exe)]
if len(sys.argv)>4:cases.insert(0,('old-dry',None,sys.argv[4]))
cases += [(name,dict(caldi_mode=name,caldi_grain=.2,caldi_motion=.25),exe)for name in ['Velluto','Presenza','Intimo','Blu','Soffio']]
report=[]
for name,params,renderer in cases:
    p=out/(name+'.wav');cmd=[renderer,'--sound',str(sound),'--out',str(p),'--notes',notes,'--tail','2']
    if params:cmd+=['--params',json.dumps(params)]
    started=time.monotonic();subprocess.run(cmd,check=True,capture_output=True);elapsed=time.monotonic()-started
    x,sr=sf.read(p,always_2d=True);peak=float(abs(x).max());held=x[8*sr:58*sr]
    rec=dict(name=name,file=str(p.resolve()),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),peak_db=float(20*np.log10(peak+1e-20)),clipped_samples=int(np.sum(abs(x)>=1)),rms_db=float(20*np.log10(np.sqrt(np.mean(x*x))+1e-20)),render_wall_seconds=elapsed,duration_seconds=len(x)/sr)
    spectrum=abs(np.fft.rfft(held.mean(axis=1)))**2;f=np.fft.rfftfreq(len(held),1/sr)
    rec['held_spectral_band_db']={label:float(10*np.log10(np.sum(spectrum[(f>=a)&(f<b)])+1e-20))for label,a,b in [('body',80,500),('presence',500,3000),('light',3000,12000)]}
    report.append(rec);print(name,round(rec['peak_db'],2),'dBFS',rec['clipped_samples'],'clipped',flush=True)
    assert np.all(np.isfinite(x)) and peak<1,rec
dry=[r for r in report if r['name']in ['old-dry','new-dry','explicit-off']]
assert len({r['sha256']for r in dry})==1,'Default/Spento bypass changed dry audio'
assert len({r['sha256']for r in report if r['name'] not in ['old-dry','new-dry','explicit-off']})==5,'Preset outputs unexpectedly identical'
(out/'report.json').write_text(json.dumps(dict(sound=str(sound.resolve()),default_bypass_bit_exact=True,results=report),indent=2)+'\n')
print('0 failures')
