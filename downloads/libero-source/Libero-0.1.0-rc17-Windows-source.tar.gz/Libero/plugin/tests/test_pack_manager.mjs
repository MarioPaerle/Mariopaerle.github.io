import test from 'node:test';
import assert from 'node:assert/strict';
import { packRows, comparePackVersions, needsPackDownload, monitorPackDownloads, packTransfer } from '../../ui/js/pack-manager.js';
const available = [{ id: 'aria', title: 'Aria', version: '0.1.6', instruments: ['Unusual Music Box', 'Felt Piano'] }, { id: 'flutes', title: 'Flûtes', version: '0.1.6', instruments: ['Aulos'] }];
const installed = [{ slug: 'aria', title: 'Aria', version: '0.1.0', count: 12 }, { slug: 'pink', title: 'Pink', version: '1.1.0', count: 27 }, { slug: 'mie', title: 'My Sounds', builtin: true }];
test('published and local-only packs appear once, built-ins cannot be deleted', () => {
  assert.deepEqual(packRows(available, installed).map(p => p.id), ['aria', 'flutes', 'pink']);
});
test('search finds an instrument within its pack and folds accents', () => {
  assert.equal(packRows(available, installed, 'music box')[0].id, 'aria');
  assert.equal(packRows(available, installed, 'flutes')[0].id, 'flutes');
  assert.equal(packRows(available, installed, 'missing').length, 0);
});
test('installed and available filters retain local-only packs correctly', () => {
  assert.deepEqual(packRows(available, installed, '', 'installed').map(p => p.id), ['aria', 'pink']);
  assert.deepEqual(packRows(available, installed, '', 'available').map(p => p.id), ['aria', 'flutes']);
});
test('updates compare numerical versions and never offer a downgrade', () => {
  assert.ok(comparePackVersions('0.1.10', '0.1.9') > 0);
  assert.equal(comparePackVersions('1.0', '1.0.0'), 0);
  assert.ok(comparePackVersions('0.1.6', '1.1.0') < 0);
});

test('same-version partial packs remain downloadable; complete or newer local packs do not', () => {
  const pack = { id: 'aria', version: '0.1.6', sounds: 12 };
  const partial = { slug: 'aria', title: 'Aria', version: '0.1.6', count: 1 };
  assert.equal(needsPackDownload({ ...pack, installed: partial }), true);
  assert.equal(packRows([pack], [partial], '', 'available').length, 1);
  assert.equal(needsPackDownload({ ...pack, installed: { ...partial, count: 12 } }), false);
  assert.equal(needsPackDownload({ ...pack, installed: { ...partial, version: '1.0.0' } }), false);
});
test('completion refresh is independent of dialogs and deduplicated per job', async () => {
  let job = { state: 'installed', id: 'aria', jobId: 'first' }, refreshes = 0;
  const bridge = { call: async () => job };
  const check = monitorPackDownloads(bridge, async () => { refreshes++; });
  await check(); await check(); assert.equal(refreshes, 1);
  job = { ...job, jobId: 'second' };
  await check(); assert.equal(refreshes, 2);
});

test('Blue GPL is a complete one-instrument pack, separate from Blue', () => {
  const packs = [
    {id:'blue',title:'Blue',version:'0.1.6',sounds:9,instruments:['Electric Piano']},
    {id:'blue-gpl',title:'Blue GPL',version:'0.1.6',sounds:1,instruments:['Five Strings']}
  ];
  const banks = [{slug:'blue-gpl',title:'Blue GPL',version:'0.1.6',count:1}];
  assert.deepEqual(packRows(packs,banks,'','available').map(p=>p.id), ['blue']);
  const gpl = packRows(packs,banks,'Five Strings')[0];
  assert.equal(needsPackDownload(gpl), false);
  assert.deepEqual(gpl.instruments, ['Five Strings']);
});

test('delta size is shown only for the installed base version', () => {
  const delta = {from_version: '1.0.0', bytes: 120};
  const pack = {bytes: 50000, deltas: [delta], installed: {version: '1.0.0'}};
  assert.equal(packTransfer(pack), delta);
  const fresh = {...pack, installed: null}; assert.equal(packTransfer(fresh), fresh);
  const other = {...pack, installed: {version: '0.9.0'}}; assert.equal(packTransfer(other), other);
});
