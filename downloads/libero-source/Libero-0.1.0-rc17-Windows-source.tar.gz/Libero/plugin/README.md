# Libero — plugin

C++ half of Libero: the realtime engine, the VST3/AU instrument, the `libero-render` offline
renderer and the agent socket. The contract is [SPEC.md](../SPEC.md) (§4 bundle, §5 parameters,
§6 socket, §7 renderer, §9 UI bridge).

```
engine/   DSP engine, shared by the plugin and the CLI (JUCE-light: core, audio_formats, dsp)
  Params      the §5 table: ids, ranges, skews, defaults, choices
  Bundle      manifest + WAV zones, load-time resampling (Kaiser sinc), baked loop crossfades
  Voice       attack / body (ADSR) / tail players, drive, TPT SVF + formant filter, string resonator
  Effects     optional Caldi EQ/compression/texture, modal resonator, tape, delay
  Reverb      Chapel, Basilica, Cistern (FDNs), Plate (Dattorro), Imprint (convolution), shimmer
  Engine      voice allocation, air bed, sound hand-over, global chain
cli/      libero-render
src/      the plugin: processor, WebView editor, agent socket, library on disk
tests/    fixtures generator, renderer/socket/editor tests, headless host (host_test.cpp),
          wavstats.py / revmeasure.py / clicks.py for measuring renders
cmake/    ui/ zip packer (embedded into the binary)
```

## Build, install, test

### macOS

Needs CMake + Ninja (Homebrew) and the Command Line Tools. From the repo root:

```sh
scripts/build.sh                       # Release, universal arm64 + x86_64, macOS 11+, into build/
scripts/install.sh                     # ~/Library/Audio/Plug-Ins/{VST3,Components}, ~/.local/bin
plugin/tests/run_tests.sh              # renderer + socket tests (headless)
plugin/tests/run_tests.sh --ui --installed   # + real WebView editor, auval, Carla discovery
```

### Windows

Install Visual Studio 2022 with Desktop development with C++ and CMake.
From PowerShell at the repository root:

```powershell
./scripts/build-windows.ps1
```

The build produces an x64 VST3 in
`build/windows/plugin/Libero_artefacts/Release/VST3/Libero.vst3`. Copy the complete
folder to `C:\Program Files\Common Files\VST3`. Microsoft WebView2 Evergreen
Runtime is required for the editor; its loader and the C++ runtime are linked
into the plugin. No separate WebView2Loader DLL or Python installation is needed
for playback.

Python 3.12 is optional for development checks:

```powershell
python -m pip install numpy scipy soundfile
python plugin/tests/test_windows.py build/windows
```

With Python 3.12 and Inno Setup 6 installed, `./scripts/package-windows.ps1` creates the installer,
ZIP, source archive and checksums. See [Windows installation](../docs/release/install-windows.md).

### Interface and library development

`ui/` is zipped at build time (only `index.html css js themes fonts img`); after adding files
there, re-run `scripts/build.sh` (the glob is `CONFIGURE_DEPENDS`). Set
`LIBERO_UI_DEV_URL=http://localhost:5173` to load the UI from a dev server instead.
`LIBERO_HOME` overrides `~/Libero` for both the plugin and the tests.

**UI without a host restart.** The UI is embedded in the binary, so changing it normally means
rebuilding and restarting the DAW. Instead, copy or symlink `ui/` to `~/Libero/ui-override/` (it
counts once `index.html` is there): the plugin then serves every UI file from that folder, so a
change shows up when you close and reopen the editor. Delete the folder to go back to the embedded
UI. Changes to the C++ still need a rebuild, `scripts/install.sh` and a host restart.

**Sounds without a host restart.** The plugin watches the current sound's `build/manifest.json`
and reloads the bundle about a second after a recompile, keeping the player's parameters;
"Reload" in the UI (or the socket's `reload`) does the same by hand and rescans the library.

## Engine behavior

- **Realtime.** Bundles are decoded and resampled on a loader thread, handed to the audio thread
  through an atomic slot and swapped at a block boundary: old voices fade out (4 ms raised
  cosine), the air bed crossfades (30 ms), the old sound is returned through a lock-free ring and
  freed off the audio thread. Reverb IR buffers are prepared by the loader and handed to
  the processing thread between blocks. UI and agent audition producers are serialized
  outside the audio callback; its FIFO consumer does not acquire their lock. Host MIDI
  uses a reusable buffer, which can still grow for unusually large event blocks.
- **Control rate.** The engine renders in chunks of ≤ 32 samples split at MIDI events; gains and
  mixes are smoothed per sample, filters per chunk. Room, filter and resonator mode changes
  crossfade (50 / 20 / 20 ms); a room coming up ramps its *input*, so nothing inside it arrives as
  a step.
- **Levels.** Layers are unity gain: zones should leave headroom for polyphony (≈ −12 dBFS peak).
  The output has a DC blocker (5 Hz) and a safety ceiling that is transparent below −0.9 dBFS
  and asymptotic to 0 dBFS. It catches output peaks without gain-reduction smoothing.
  Room loudness is compensated so that
  short and long `rev_decay` settings sit within a few dB of each other.
- **Loops.** `loop.end` is exclusive. The loader bakes a crossfade into the samples before `end`
  (from before `start` when available), so playback just jumps `end → start`.
- **Imprint.** `juce::dsp::Convolution` runs on fixed 256-sample blocks so renders don't depend on
  the host block size; that latency is taken out of `rev_predelay`. The IR is normalised to unit
  energy (it arrives peak-normalised). `rev_size`/`rev_decay` don't apply to it. Without `ir.wav`
  the room is Basilica.
- **Determinism.** Same inputs, same bytes (fixed seeds, IR made active synchronously before
  rendering). Different `--block` values differ only by control-rate rounding (< 0.01 dB here).
- **Extras beyond the SPEC.** `libero-render --automation '[{"t": 1.0, "params": {...}}]'` applies
  parameter changes mid-render (used by the click tests). `set_params` also returns
  `rejected: [...]` (and `ok: false`) for ids/values it couldn't apply. Choice params accept the
  string or the index.
- **Hosts.** VST3 exposes JUCE's MIDI-CC parameters (so sustain pedal and pitch bend reach the
  instrument in VST3 hosts). AU code `aumu Lbr0 Lbro`.

## Sample memory

The plugin automatically streams eligible large polyphonic banks whose decoded PCM
would exceed 256 MiB. Long, non-looped WAV, FLAC and AIFF zones keep a 250 ms attack
resident; two process-shared workers fill a fixed pool of playback buffers.
Workers own alternating slots and keep at most 64 readers each, with four
decoded chunks per reader. They run at normal priority; the host controls audio-thread scheduling. Matching
instances share the same attacks and pool. Rate conversion uses the existing sinc
kernel on workers, with continuous global sample positions and source halos.

Looped zones, edited banks and continuously crossfaded dynamics layers remain
resident. Fixed dynamics layers acquire a stream only when audible. Mono/Legato
selection reloads the resident bank; a matching storage upgrade preserves held
voices, their positions and envelopes. Until that reload finishes, playback retains
its polyphonic mode. Offline rendering uses complete resident data.

Each streamed bank reserves 128 MiB of playback buffers (1024 player leases, two
8192-frame stereo float buffers per lease), plus its attacks, resident fallback
zones and metadata. Reader/chunk caches are bounded separately. This is a per-bank
budget, not a global process memory cap; different banks and host processes add
memory. The 1024-lease limit counts Players, including release layers, rather than
MIDI notes. Storage misses, exhausted leases and read failures are reported; the
audio callback does not read files or wait for workers. Missing data fades out and
recovers when ready. Active chunks remain pinned while audio reads them.

For developer comparisons, `LIBERO_SAMPLE_STREAMING=0` disables streaming.
`LIBERO_SAMPLE_STREAMING=1` also tests eligible small banks; normal installations
use automatic selection. Set this environment before launching the host. This
setting changes runtime storage, not bank contents or archive formats.

Tests cover resident/stream parity at 44.1, 48 and 96 kHz, held-note upgrades,
loop/edit/legato fallbacks, offline rendering, missing files and capacity exhaustion.
Real DAW/storage behavior, especially on Windows, still needs validation.

Control-rate smoothing reuses its exact coefficient for repeated block sizes and
skips settled values. Voice dynamics weights, drive gains, echo tone filters and
Caldi EQ coefficients update when their inputs change. These caches preserve the
existing interpolation and automation calculations; prepare invalidates filters
whose coefficients depend on the sample rate.
Unison pan gains, oscillator frequency steps and subharmonic steps also reuse exact
values until their inputs change. Sample-rate preparation invalidates these caches.

Integer-position sample reads use the stored frame directly; fractional playback
retains Hermite interpolation and the existing boundary checks. Voices replaced
before rendering are discarded instead of producing an unnecessary fade. Already
rendered voices keep their normal steal/choke fades.

Host MIDI and bounded UI/agent audition events merge directly in the engine,
without copying the host buffer. Unsupported long MIDI messages keep their timing
boundaries but are not materialized. Equal-time host events precede audition events.
The audition buffer is preallocated for its fixed queue and pending note-off limits;
Panic has an atomic fallback that flushes audition requests if that queue is full.

## Portamento and host pitch automation

For a melodic slide, select `Mode = Legato`, set `Glide` (for example 150 ms),
and overlap the destination note with the held note. Legato keeps the envelope
running across overlapping notes. Mono retriggers the envelope while gliding.
A note after a rest starts at its own pitch. Individual presets choose their
default mode and glide time; the engine defaults are Poly and zero glide.

The Giove Theremin and Trautonium presets use velocity for loudness and the
modulation wheel (CC1) primarily for vibrato depth. With the wheel down, both
loud and quiet notes have straight pitch. Raising the wheel adds vibrato while
changing loudness only slightly. Their velocity curve changes gently in the
upper range and falls faster near zero. Overlapping notes retain the envelope
and vibrato phase; changes in velocity are smoothed over 25 ms.

FL Studio's slide/portamento note flags are restricted to its native instruments;
they are not delivered to Libero as VST/AU slide events. Use overlapping ordinary
notes with Libero's Legato mode, or automate the channel pitch. See the
[FL piano-roll manual](https://www.image-line.com/fl-studio-learning/fl-studio-online-manual/html/pianoroll.htm).

LMMS distinguishes per-note detuning from track pitch automation: its native
per-note frequency curve is not forwarded by VeSTige as a pitch curve to a VST.
Track pitch automation can send MIDI pitch bend and RPN 0 bend sensitivity;
compatibility requires that these messages actually reach the instrument.
Libero now honours RPN 0 (CC101/100 selection, CC6 semitones and CC38 cents),
with a default range of ±2 semitones. A new range also updates a held bend.
Selection and sensitivity are tracked per MIDI channel, while pitch bend retains
the instrument's existing global, last-wheel-channel behaviour. CC121 centres
the bend and clears selection; a full engine reset restores ±2 semitones.
In FL's wrapper, enable **Send pitch bend range** when using host pitch
automation; consult the [wrapper manual](https://www.image-line.com/fl-studio-learning/fl-studio-online-manual/html/plugins/wrapper.htm).
The checked LMMS tree does not directly host Libero's macOS AU/VST3 formats:
VeSTige hosts VST2, so a suitable host/bridge is also required. This does not add
per-note polyphonic bends or native piano-roll slide flags to either DAW.
