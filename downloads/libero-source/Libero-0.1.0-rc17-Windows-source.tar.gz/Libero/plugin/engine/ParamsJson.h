#pragma once

#include "Params.h"

#include <juce_core/juce_core.h>

namespace libero
{

// Applies a JSON object {id: plainValue | choiceString} to a ParamSet. Unknown ids or bad values
// are reported in `rejected` and otherwise ignored.
inline void applyJsonParams (ParamSet& set, const juce::var& obj, juce::StringArray* rejected = nullptr)
{
    auto* d = obj.getDynamicObject();

    if (d == nullptr)
        return;

    // A bare echo_time (no echo_sync) is a pre-sync sound or request: it means the free echo.
    const auto bareEchoTime = d->hasProperty ("echo_time") && ! d->hasProperty ("echo_sync");

    if (bareEchoTime)
        set.setChoice ("echo_sync", "Libero");

    for (const auto& prop : d->getProperties())
    {
        const auto id = prop.name.toString();
        const auto& v = prop.value;
        bool ok = false;

        if (v.isString())
        {
            ok = set.setChoice (id.toStdString(), v.toString().toStdString());

            if (! ok && v.toString().containsOnly ("0123456789.-+eE"))
                ok = set.set (id.toStdString(), v.toString().getFloatValue());
        }
        else if (v.isInt() || v.isInt64() || v.isDouble() || v.isBool())
        {
            ok = set.set (id.toStdString(), (float) (double) v);
        }

        if (! ok && rejected != nullptr)
            rejected->add (id);
    }
}

// The value of a parameter as reported to agents: plain number, or the choice string.
inline juce::var paramToVar (int index, float plain)
{
    const auto& s = spec (index);

    if (s.scale == Scale::choice)
        return juce::String::fromUTF8 (s.choices[juce::jlimit (0, s.numChoices - 1, (int) plain)]);

    if (s.scale == Scale::stepped)
        return (int) plain;

    return (double) plain;
}

} // namespace libero
