#pragma once

#include "SampleBuffer.h"
#include "Dsp.h"
#include <juce_audio_formats/juce_audio_formats.h>
#include <atomic>
#include <memory>
#include <vector>

namespace libero
{
class SampleStreamPool
{
    struct Slot;
    struct Chunk;
public:
    static constexpr int chunkFrames = 8192;
    static constexpr int slotCount = 1024;
    struct Asset
    {
        uint64_t id = 0;
        juce::File file;
        SampleBuffer attack;
        int frames = 0, sourceFrames = 0, channels = 0;
        double ratio = 1;
        float gain = 1;
    };
    struct Stats { int active = 0; uint64_t misses = 0, exhausted = 0, readErrors = 0, decodedChunks = 0, cacheHits = 0, readerOpens = 0; };
    class Cursor
    {
    public:
        Cursor() = default;
        Cursor (const Cursor&);
        Cursor& operator= (const Cursor&);
        Cursor (Cursor&&) noexcept;
        Cursor& operator= (Cursor&&) noexcept;
        ~Cursor() { reset(); }
        void reset() noexcept;
        void beginRead() const noexcept { readMissed = false; }
        bool missedRead() const noexcept { return readMissed; }
        float sample (int channel, int frame) const noexcept;
        void position (int frame) const noexcept;
        void read (int frame, float fraction, float& l, float& r) const noexcept
        {
            if (frame >= maintenanceAt) position (frame);
            if (frame >= window.first && frame < window.end)
            {
                readMissed = ! window.good;
                const auto at = frame - window.start;
                if (fraction == 0.0f)
                {
                    l = window.l[at]; r = window.r ? window.r[at] : l;
                }
                else
                {
                    l = dsp::hermite (window.l[at - 1], window.l[at], window.l[at + 1], window.l[at + 2], fraction);
                    r = window.r ? dsp::hermite (window.r[at - 1], window.r[at], window.r[at + 1], window.r[at + 2], fraction) : l;
                }
                return;
            }
            readSlow (frame, fraction, l, r);
        }
        explicit operator bool() const noexcept { return slot != nullptr; }
    private:
        friend class SampleStreamPool;
        Slot* slot = nullptr;
        SampleStreamPool* pool = nullptr;
        mutable Chunk* pinned[2] {};
        mutable int missedChunk = -1;
        mutable bool readMissed = false;
        mutable int requested = -1;
        mutable int maintenanceAt = 0;
        struct Window { const float* l = nullptr; const float* r = nullptr; int start = 0, first = 1, end = 0; bool good = true; };
        mutable Window window;
        void readSlow (int frame, float fraction, float& l, float& r) const noexcept;
        void copy (const Cursor&) noexcept;
    };
    static std::shared_ptr<SampleStreamPool> create();
    ~SampleStreamPool();
    const Asset* add (const juce::File&, SampleBuffer, int frames, float gain, double ratio = 1, int sourceFrames = 0);
    Cursor acquire (const Asset*) noexcept;
    Stats stats() const noexcept;
private:
    struct Chunk
    {
        // 0 empty, 1 worker writing, 2 ready; each audio reader adds four.
        std::atomic<unsigned> state { 0 };
        int index = -1;
        bool readable = true;
        juce::AudioBuffer<float> pcm;
    };
    struct alignas(64) Slot
    {
        // -1 initializing, zero free; workers hold a reference during a fill.
        std::atomic<int> users { 0 }, requested { 0 }, served { -1 };
        std::atomic<bool> busy { false };
        const Asset* asset = nullptr;
        Chunk chunks[2];
    };
    SampleStreamPool();
    struct Reader
    {
        uint64_t id = 0;
        std::unique_ptr<juce::AudioFormatReader> source;
        juce::AudioBuffer<float> pcm[4], sourceWindow;
        int cached[4] { -1, -1, -1, -1 };
        bool ok[4] {};
        uint64_t used[4] {}, useClock = 0;
    };
    class Scheduler;
    class Worker;
    static Scheduler& scheduler();
    void service (Slot&, juce::AudioFormatManager&, std::vector<Reader>&);
    std::unique_ptr<Slot[]> slots;
    std::vector<std::unique_ptr<Asset>> assets;
    juce::CriticalSection assetLock;
    std::atomic<uint64_t> misses { 0 }, exhausted { 0 }, readErrors { 0 };
    std::atomic<unsigned> nextSlot { 0 };
    std::atomic<uint64_t> decodedChunks { 0 }, cacheHits { 0 }, readerOpens { 0 };
};
}
