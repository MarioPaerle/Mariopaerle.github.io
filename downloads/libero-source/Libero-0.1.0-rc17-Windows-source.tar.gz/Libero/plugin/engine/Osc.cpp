#include "Osc.h"

#include <juce_core/juce_core.h>

#include <cmath>

namespace libero
{

using namespace dsp;

//==============================================================================
WaveTables::WaveTables()
{
    // Quarter-octave levels: 1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 13, 16, ... up to kMaxHarmonics.
    for (int j = 0; ; ++j)
    {
        const auto h = (int) std::floor (std::pow (2.0, j / 4.0));

        if (h > kMaxHarmonics)
            break;

        if (harmonics.empty() || h != harmonics.back())
            harmonics.push_back (h);
    }

    std::vector<double> sinTab (kSize);

    for (int n = 0; n < kSize; ++n)
        sinTab[(size_t) n] = std::sin (2.0 * juce::MathConstants<double>::pi * n / kSize);

    const auto build = [&] (int h, bool tri)
    {
        std::vector<double> acc (kSize, 0.0);

        for (int k = 1; k <= h; ++k)
        {
            double amp;

            if (tri)
            {
                if (k % 2 == 0)
                    continue;

                amp = 8.0 / (juce::MathConstants<double>::pi * juce::MathConstants<double>::pi) / (k * k)
                      * (((k - 1) / 2) % 2 == 0 ? 1.0 : -1.0);
            }
            else
            {
                amp = 2.0 / juce::MathConstants<double>::pi / k * (k % 2 == 1 ? 1.0 : -1.0);
            }

            for (int n = 0; n < kSize; ++n)
                acc[(size_t) n] += amp * sinTab[(size_t) ((k * n) & (kSize - 1))];
        }

        return std::vector<float> (acc.begin(), acc.end());
    };

    for (auto h : harmonics)
    {
        saw.push_back (build (h, false));
        triangle.push_back (build (h, true));
    }

    sine.assign (kSize, 0.0f);

    for (int n = 0; n < kSize; ++n)
        sine[(size_t) n] = (float) sinTab[(size_t) n];
}

const WaveTables& WaveTables::get()
{
    static const WaveTables tables;
    return tables;
}

const float* WaveTables::table (OscWave wave, double cyclesPerSample) const noexcept
{
    if (wave == OscWave::sine)
        return sine.data();

    // Largest level whose top harmonic stays below Nyquist.
    const auto allowed = 0.5 / std::max (1.0e-9, cyclesPerSample);
    int lo = 0, hi = (int) harmonics.size() - 1;

    while (lo < hi)
    {
        const auto mid = (lo + hi + 1) / 2;

        if ((double) harmonics[(size_t) mid] <= allowed)
            lo = mid;
        else
            hi = mid - 1;
    }

    return (wave == OscWave::triangle ? triangle : saw)[(size_t) lo].data();
}

//==============================================================================
void VoiceOscillators::start (uint32_t seed, bool retrigger) noexcept
{
    rng.reseed (seed | 1u);

    for (auto& u : units)
    {
        for (int v = 0; v < kUnison; ++v)
        {
            // Reset: the first voice at zero, the others at fixed golden-ratio offsets (a unison
            // that starts all in phase sounds like one loud click). Free: random.
            const auto golden = std::fmod (0.6180339887 * v, 1.0);
            u.phase[(size_t) v] = retrigger ? golden : (double) rng.uniform();
            u.skew[(size_t) v] = 0.0;
        }

        u.drift = { 0.0f, 0.0f };
        u.driftTarget = { rng.bipolar(), rng.bipolar() };
        u.driftCountdown = 0;
    }

    for (auto& phase : subPhase)
        phase = retrigger ? 0.0 : (double) rng.uniform();
}

void VoiceOscillators::render (const OscControl& c, float pitch, float pwMod, float* l, float* r, int n) noexcept
{
    for (int k = 0; k < 2; ++k)
        renderOsc (k, c.osc[(size_t) k], pitch, pwMod, c.drift, l, r, n);

    // Mixtur subharmonics: independent integer divisors of the current note,
    // sharing pitch bend and legato glide while keeping their physical ratios.
    const auto& tables = WaveTables::get();
    for (int b = 0; b < (int) c.sub.size(); ++b)
    {
        const auto& branch = c.sub[(size_t) b];
        if (branch.gainStart <= 0.0f && branch.gainEnd <= 0.0f)
            continue;
        const auto divisor = std::max (1.0, (double) branch.divisor);
        const auto base = (double) pitch + c.osc[0].offset;
        auto& frequency = subFrequency[(size_t) b];
        if (!frequency.valid || frequency.base != base || frequency.divisor != divisor)
        {
            const auto semis = base - 12.0 * std::log2 (divisor);
            frequency.increment = 440.0 * std::exp2 ((semis - 69.0) / 12.0) / sr;
            frequency.base = base; frequency.divisor = divisor; frequency.valid = true;
        }
        const auto inc = frequency.increment;
        const auto wave = c.subWave == OscControl::SubWave::sine ? OscWave::sine : OscWave::saw;
        const auto* t = tables.table (wave, inc);
        auto& phase = subPhase[(size_t) b];

        for (int i = 0; i < n; ++i)
        {
            const auto g = branch.gainStart + (branch.gainEnd - branch.gainStart) * (float) (i + 1) / (float) n;
            auto y = WaveTables::read (t, phase);

            if (c.subWave == OscControl::SubWave::square)
            {
                auto p2 = phase + 0.5;
                if (p2 >= 1.0) p2 -= 1.0;
                y = (y - WaveTables::read (t, p2)) * 0.8f;
            }

            l[i] += y * g;
            r[i] += y * g;
            phase += inc;

            if (phase >= 1.0)
                phase -= 1.0;
        }
    }
}

void VoiceOscillators::renderOsc (int index, const OscSettings& s, float pitch, float pwMod, float driftAmount,
                                  float* l, float* r, int n) noexcept
{
    if (! s.on())
        return;

    auto& u = units[(size_t) index];
    const auto& tables = WaveTables::get();

    // Slow analogue drift, independent per oscillator and per side (so L/R phase wanders too).
    std::array<float, 2> driftCents { 0.0f, 0.0f };

    if (driftAmount > 0.0f)
    {
        if (--u.driftCountdown <= 0)
        {
            u.driftCountdown = (int) (0.25f * sr / (float) std::max (1, n)) + (int) (rng.uniform() * 0.5f * sr / (float) std::max (1, n));
            u.driftTarget = { rng.bipolar(), rng.bipolar() };
        }

        const auto k = 1.0f - std::exp (-(float) n / (0.35f * sr));

        for (int side = 0; side < 2; ++side)
        {
            u.drift[(size_t) side] += k * (u.driftTarget[(size_t) side] - u.drift[(size_t) side]);
            driftCents[(size_t) side] = u.drift[(size_t) side] * driftAmount * 7.0f;
        }
    }

    const auto voices = juce::jlimit (1, kUnison, s.voices);
    const auto detuneCents = 60.0f * s.detune * s.detune;      // supersaw-like: fine at first, wide at the end
    if (u.layoutVoices != voices || u.layoutSpread != s.spread)
    {
        u.layoutVoices = voices; u.layoutSpread = s.spread;
        u.norm = 1.0f / std::sqrt ((float) voices);
        for (int v = 0; v < voices; ++v)
        {
            const auto x = voices > 1 ? 2.0f * (float) v / (float) (voices - 1) - 1.0f : 0.0f;
            const auto pos = x * clampf (s.spread, 0.0f, 1.0f);
            const auto theta = (pos + 1.0f) * 0.25f * kPi;
            u.position[(size_t) v] = x;
            u.gainL[(size_t) v] = std::cos (theta) * 1.41421356f;
            u.gainR[(size_t) v] = std::sin (theta) * 1.41421356f;
        }
    }
    const auto norm = u.norm;
    const auto base = (double) pitch + s.offset;
    const auto pw = clampf (s.pw + pwMod, 0.05f, 0.95f);
    const auto lr0 = (double) s.phaseLR, dLr = (double) (s.phaseLREnd - s.phaseLR) / n;
    const auto stereoRead = s.phaseLR > 0.0f || s.phaseLREnd > 0.0f || driftAmount > 0.0f || s.wave == OscWave::noise;

    // One table for all unison voices: the one that is safe for the highest of them.
    if (!u.frequencyValid || u.frequencyBase != base || u.frequencyDetune != detuneCents
        || u.frequencyDrift != driftCents || u.frequencyVoices != voices)
    {
        u.maxIncrement = 440.0 * std::exp2 ((base - 69.0 + (detuneCents + std::max (driftCents[0], driftCents[1])) / 100.0) / 12.0) / sr;
        for (int v = 0; v < voices; ++v)
        {
            const auto cents = (double) (u.position[(size_t) v] * detuneCents);
            u.incrementL[(size_t) v] = 440.0 * std::exp2 ((base - 69.0 + (cents + driftCents[0]) / 100.0) / 12.0) / sr;
            u.incrementR[(size_t) v] = 440.0 * std::exp2 ((base - 69.0 + (cents + driftCents[1]) / 100.0) / 12.0) / sr;
        }
        u.frequencyBase = base; u.frequencyDetune = detuneCents;
        u.frequencyDrift = driftCents; u.frequencyVoices = voices; u.frequencyValid = true;
    }
    const auto maxInc = u.maxIncrement;
    const auto* t = tables.table (s.wave == OscWave::triangle ? OscWave::triangle
                                  : s.wave == OscWave::sine ? OscWave::sine : OscWave::saw, maxInc);

    std::array<float, 64> gain {};   // n <= the engine's control block (32)

    for (int i = 0; i < n; ++i)
        gain[(size_t) i] = (s.gainStart + (s.gainEnd - s.gainStart) * (float) (i + 1) / (float) n) * norm;

    for (int v = 0; v < voices; ++v)
    {
        const auto gl = u.gainL[(size_t) v], gr = u.gainR[(size_t) v];
        const auto incL = u.incrementL[(size_t) v], incR = u.incrementR[(size_t) v];

        auto ph = u.phase[(size_t) v];
        auto skew = u.skew[(size_t) v];
        const auto dSkew = incR - incL;

        for (int i = 0; i < n; ++i)
        {
            float yl, yr;

            if (s.wave == OscWave::noise)
            {
                yl = rng.bipolar();
                yr = stereoRead ? rng.bipolar() : yl;
            }
            else
            {
                // A true phase offset: every partial moves by the same fraction of the fundamental's
                // cycle, so partial k cancels in the mono sum where k * offset is near half a cycle.
                auto phR = ph + skew + lr0 + dLr * (i + 1);
                phR -= std::floor (phR);

                if (s.wave == OscWave::square)
                {
                    auto q = ph + pw;
                    if (q >= 1.0) q -= 1.0;
                    yl = WaveTables::read (t, ph) - WaveTables::read (t, q);

                    if (stereoRead)
                    {
                        auto qr = phR + pw;
                        if (qr >= 1.0) qr -= 1.0;
                        yr = WaveTables::read (t, phR) - WaveTables::read (t, qr);
                    }
                    else
                    {
                        yr = yl;
                    }
                }
                else
                {
                    yl = WaveTables::read (t, ph);
                    yr = stereoRead ? WaveTables::read (t, phR) : yl;
                }
            }

            l[i] += yl * gl * gain[(size_t) i];
            r[i] += yr * gr * gain[(size_t) i];

            ph += incL;
            if (ph >= 1.0) ph -= 1.0;
            skew += dSkew;
        }

        u.phase[(size_t) v] = ph;
        u.skew[(size_t) v] = std::fmod (skew, 1.0);
    }
}

//==============================================================================
void Lfo::reset() noexcept
{
    phase = 0.0;
    current = 0.0f;
    rng.reseed (0x1f0u);
    held = rng.bipolar();
    previousHeld = 0.0f;
}

float Lfo::advance (LfoShape shape, float rateHz, int n) noexcept
{
    phase += (double) rateHz * n / sr;

    while (phase >= 1.0)
    {
        phase -= 1.0;
        previousHeld = held;
        held = rng.bipolar();
    }

    const auto p = (float) phase;

    switch (shape)
    {
        case LfoShape::sine:     current = std::sin (kTwoPi * p); break;
        case LfoShape::triangle: current = 1.0f - 4.0f * std::abs (p - 0.5f); break;
        case LfoShape::square:   current = clampf (std::sin (kTwoPi * p) * 8.0f, -1.0f, 1.0f); break;  // soft edges
        case LfoShape::saw:      current = 1.0f - 2.0f * p; break;
        case LfoShape::random:   current = previousHeld + (held - previousHeld) * std::min (1.0f, p * 6.0f); break;
    }

    return current;
}

} // namespace libero
