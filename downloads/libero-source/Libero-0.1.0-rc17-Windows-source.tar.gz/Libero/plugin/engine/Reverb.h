#pragma once

#include "Dsp.h"
#include "Params.h"

#include <juce_dsp/juce_dsp.h>

#include <array>

namespace libero
{

//==============================================================================
struct FdnConfig
{
    int lines = 8;
    std::array<float, 16> delayMs {};
    float sizeMin = 0.5f, sizeMax = 1.3f;       // delay scale at rev_size 0 / 1
    float modDepthMs = 0.2f, modRateMin = 0.3f, modRateMax = 1.0f;
    float hfScale = 1.0f;                       // multiplies the HF/LF decay-time ratio
    float decayScale = 1.0f;
    int diffusers = 4;
    std::array<float, 6> diffMs {};
    float diffG = 0.65f;
    float innerMs = 0.0f, innerG = 0.4f;        // optional allpass inside every feedback line
    int erTaps = 0;                             // early reflections (Cappella)
    float outLowpassHz = 0.0f;                  // extra darkening on the output (Cisterna)
    float gain = 1.0f;
};

// Feedback delay network with Hadamard mixing, modulated delays, Jot-style absorbent filters.
class FdnReverb
{
public:
    void prepare (float sampleRate, const FdnConfig&);
    void reset() noexcept;
    void set (float size, float decaySeconds, float damp) noexcept;
    void process (const float* inL, const float* inR, float* outL, float* outR, int n) noexcept;

private:
    static constexpr int kMax = 16;

    FdnConfig cfg;
    float sampleRate = 48000.0f;

    std::array<dsp::DelayLine, kMax> lines;
    std::array<dsp::Allpass, kMax> inner;
    std::array<dsp::Allpass, 6> diffL, diffR;
    dsp::DelayLine erLine;

    std::array<float, kMax> baseSamples {}, innerSamples {}, gain {}, pole {}, z {};
    std::array<float, kMax> oscC {}, oscS {}, rotC {}, rotS {}, signL {}, signR {}, signIn {};
    std::array<float, 16> erTimeMs {}, erGainL {}, erGainR {};

    dsp::Smoother sizeScale, levelComp;
    dsp::OnePoleLP outLpL, outLpR;
    float modDepth = 0.0f, outNorm = 0.25f, erMix = 1.0f;
    float currentDamp = -1.0f;
};

//==============================================================================
// Dattorro plate (1997), delays scaled from 29761 Hz and by rev_size.
class PlateReverb
{
public:
    void prepare (float sampleRate);
    void reset() noexcept;
    void set (float size, float decaySeconds, float damp) noexcept;
    void process (const float* inL, const float* inR, float* outL, float* outR, int n) noexcept;

private:
    float sampleRate = 48000.0f, k = 1.0f;   // k = sampleRate / 29761

    dsp::OnePoleLP bandwidth, dampL, dampR;
    std::array<dsp::Allpass, 4> inDiff;
    dsp::Allpass modApL, modApR, apL, apR;
    dsp::DelayLine d1L, d2L, d1R, d2R;
    dsp::Smoother sizeScale;

    float decayGain = 0.5f, tankL = 0.0f, tankR = 0.0f;
    double lfoPhase = 0.0;
};

//==============================================================================
// Impronta: the bundle's impulse response. Runs the JUCE convolution on fixed 256-sample blocks
// so the result doesn't depend on the host block size; the added latency is taken out of the
// pre-delay by the caller.
class ConvolutionReverb
{
public:
    static constexpr int kBlock = 256;

    void prepare (float sampleRate);
    void reset() noexcept;
    void set (float damp) noexcept;
    void process (const float* inL, const float* inR, float* outL, float* outR, int n) noexcept;

    // Stereo buffer prepared off-thread. Call on the processing thread between blocks,
    // or while processing is stopped; JUCE takes ownership asynchronously.
    void loadImpulse (juce::AudioBuffer<float>&& ir, double irSampleRate);
    // Non-realtime thread: makes the most recently loaded IR active right now (offline rendering).
    void finishLoading();

private:
    juce::dsp::Convolution conv { juce::dsp::Convolution::NonUniform { kBlock } };
    juce::AudioBuffer<float> block;
    std::array<float, kBlock> outFifoL {}, outFifoR {};
    int fill = 0;
    float sampleRate = 48000.0f;
    dsp::OnePoleLP lpL, lpR;
    bool prepared = false;
};

//==============================================================================
// Octave-up granular shifter: two Hann-windowed grains reading at double speed.
class OctaveShifter
{
public:
    void prepare (float sampleRate);
    void reset() noexcept;
    // Output for the i-th sample of the current chunk, before that chunk's input is pushed.
    float read (int i) noexcept;
    void push (float x) noexcept { line.push (x); }

private:
    dsp::DelayLine line;
    float grain = 2048.0f, minDelay = 48.0f, phase = 0.0f;
};

//==============================================================================
// The Sala section: pre-delay, five rooms with click-free switching, shimmer, width, mix.
class Reverb
{
public:
    void prepare (float sampleRate);
    void reset() noexcept;

    void set (RevMode mode, bool hasIR, float size, float decay, float predelayMs, float damp,
              float width, float shimmer, float mix) noexcept;

    void process (float* l, float* r, int n) noexcept;

    void loadImpulse (juce::AudioBuffer<float>&& ir, double irSampleRate) { convolution.loadImpulse (std::move (ir), irSampleRate); }
    void finishLoading()                                                   { convolution.finishLoading(); }

private:
    static constexpr int kModes = 5;

    void processRoom (int mode, const float* inL, const float* inR, float* outL, float* outR, int n) noexcept;
    void resetRoom (int mode) noexcept;

    FdnReverb cappella, basilica, cisterna;
    PlateReverb plate;
    ConvolutionReverb convolution;
    OctaveShifter shifter;

    dsp::DelayLine preL, preR;
    dsp::Smoother predelay, mix, width, shimmer;
    dsp::OnePoleLP shimLp, shimHpLp;

    std::array<float, kModes> fade {}, fadeTarget {}, inFade {};
    std::array<bool, kModes> live {};
    int activeMode = 1;
    bool networkProcessed = false;
    float decaySeconds = 3.5f;
    float sampleRate = 48000.0f;

    std::array<float, 32> xL {}, xR {}, cL {}, cR {}, wL {}, wR {}, tL {}, tR {}, iL {}, iR {};
};

} // namespace libero
