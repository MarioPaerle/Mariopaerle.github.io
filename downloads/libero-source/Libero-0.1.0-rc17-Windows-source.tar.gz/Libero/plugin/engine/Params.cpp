#include "Params.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <limits>

namespace libero
{

namespace
{
    const char* const kFilterModes[] = { "Basso", "Banda", "Alto", "Vocale" };
    const char* const kResModes[]    = { "Corde", "Vetro", "Legno", "Metallo" };
    const char* const kRevModes[]    = { "Cappella", "Basilica", "Cisterna", "Piastra", "Impronta" };
    const char* const kPlayModes[]   = { "Poli", "Mono", "Legato" };
    const char* const kDynModes[]    = { "Velocità", "Modulazione", "Manopola" };
    const char* const kOscWaves[]    = { "Sega", "Quadra", "Triangolo", "Seno", "Rumore" };
    const char* const kSubWaves[]    = { "Seno", "Quadra", "Sega" };
    const char* const kRetrig[]      = { "Libera", "Riavvia" };
    const char* const kEchoSync[]    = { "Tempo", "Libero" };
    const char* const kEchoDivs[]    = { "1/32", "1/16T", "1/16", "1/16.", "1/8T", "1/8", "1/8.", "1/4T", "1/4", "1/4.", "1/2", "1/1" };
    const char* const kLfoShapes[]   = { "Seno", "Triangolo", "Quadra", "Dente", "Casuale" };
    const char* const kFenvSources[] = { "Ampiezza", "Propria" };
    const char* const kCaldiModes[] = { "Spento", "Velluto", "Presenza", "Intimo", "Blu", "Soffio" };

    constexpr float kLinear = std::numeric_limits<float>::quiet_NaN();

    constexpr ParamSpec fl (const char* id, const char* name, const char* group,
                            float mn, float mx, float def, const char* unit = "", float centre = kLinear)
    {
        return { id, name, group, mn, mx, def, Scale::continuous, centre, unit, nullptr, 0 };
    }

    constexpr ParamSpec st (const char* id, const char* name, const char* group,
                            float mn, float mx, float def, const char* unit)
    {
        return { id, name, group, mn, mx, def, Scale::stepped, kLinear, unit, nullptr, 0 };
    }

    template <size_t N>
    constexpr ParamSpec ch (const char* id, const char* name, const char* group,
                            const char* const (&choices)[N], int def)
    {
        return { id, name, group, 0.0f, (float) (N - 1), (float) def, Scale::choice, kLinear, "", choices, (int) N };
    }

    // Centres match ui/js/params.js so the mock and the plugin feel the same.
    const std::array<ParamSpec, kNumParams> kSpecs {{
        fl ("lvl_attack",    "Attack",          "Layers",    -60.0f, 6.0f,     0.0f,     "dB", -12.0f),
        fl ("lvl_body",      "Body",            "Layers",    -60.0f, 6.0f,     0.0f,     "dB", -12.0f),
        fl ("lvl_tail",      "Tail",             "Layers",    -60.0f, 6.0f,    -6.0f,     "dB", -12.0f),
        fl ("lvl_air",       "Air",             "Layers",    -60.0f, 6.0f,    -18.0f,    "dB", -12.0f),

        fl ("amp_attack",    "Attack",          "Envelope",   0.0f, 5000.0f,   2.0f,     "ms", 150.0f),
        fl ("amp_decay",     "Decay",      "Envelope",   1.0f, 10000.0f,  400.0f,   "ms", 300.0f),
        fl ("amp_sustain",   "Sustain",         "Envelope",   0.0f, 1.0f,      1.0f),
        fl ("amp_release",   "Release",         "Envelope",   1.0f, 15000.0f,  300.0f,   "ms", 500.0f),
        fl ("amp_curve",     "Curve",        "Envelope",  -1.0f, 1.0f,      0.0f),
        fl ("air_attack",    "Air · attack",   "Envelope",   0.0f, 5000.0f,   30.0f,    "ms", 150.0f),
        fl ("air_release",   "Air · release",    "Envelope",   1.0f, 15000.0f,  800.0f,   "ms", 500.0f),
        fl ("air_follow",    "Air · follow",     "Envelope",   0.0f, 1.0f,      1.0f),

        st ("tune",          "Tune",      "Voice",     -24.0f, 24.0f,    0.0f,     "st"),
        fl ("fine",          "Fine",             "Voice",    -100.0f, 100.0f,   0.0f,     "ct"),
        fl ("glide",         "Glide",       "Voice",      0.0f, 2000.0f,   0.0f,     "ms", 150.0f),
        fl ("vel_sens",      "Velocity",         "Voice",      0.0f, 1.0f,      0.7f),
        st ("voices",        "Voices",             "Voice",      1.0f, 32.0f,     16.0f,    ""),

        ch ("flt_mode",      "Filter",           "Tone",       kFilterModes, 0),
        fl ("flt_cutoff",    "Cutoff",           "Tone",       20.0f, 20000.0f, 20000.0f, "Hz", 632.0f),
        fl ("flt_reso",      "Resonance",        "Tone",       0.0f, 1.0f,      0.1f),
        fl ("flt_env",       "Filter envelope", "Tone",      -1.0f, 1.0f,      0.0f),
        fl ("drive",         "Drive",           "Tone",       0.0f, 1.0f,      0.0f),

        ch ("res_mode",      "Resonance",        "Resonances",  kResModes, 0),
        fl ("res_tune",      "Tuning",      "Resonances", -24.0f, 24.0f,    0.0f,     "st"),
        fl ("res_decay",     "Decay",           "Resonances",  0.0f, 1.0f,      0.5f),
        fl ("res_bright",    "Brightness",             "Resonances",  0.0f, 1.0f,      0.5f),
        fl ("res_mix",       "Amount",         "Resonances",  0.0f, 1.0f,      0.0f),

        fl ("tape_wow",      "Wow",              "Tape",     0.0f, 1.0f,      0.0f),
        fl ("tape_flutter",  "Flutter",          "Tape",     0.0f, 1.0f,      0.0f),
        fl ("tape_sat",      "Saturation",      "Tape",     0.0f, 1.0f,      0.0f),
        fl ("tape_age",      "Age",              "Tape",     0.0f, 1.0f,      0.0f),
        fl ("tape_mix",      "Tape",           "Tape",     0.0f, 1.0f,      0.0f),

        fl ("echo_time",     "Time",            "Echo",        10.0f, 2000.0f,  375.0f,   "ms", 250.0f),
        fl ("echo_feedback", "Feedback",          "Echo",        0.0f, 0.95f,     0.35f),
        fl ("echo_tone",     "Tone",           "Echo",        0.0f, 1.0f,      0.5f),
        fl ("echo_spread",   "Width",         "Echo",        0.0f, 1.0f,      0.5f),
        fl ("echo_mix",      "Echo",              "Echo",        0.0f, 1.0f,      0.0f),

        ch ("rev_mode",      "Room",             "Room",       kRevModes, 1),
        fl ("rev_size",      "Size",       "Room",       0.0f, 1.0f,      0.6f),
        fl ("rev_decay",     "Decay",           "Room",       0.1f, 30.0f,     3.5f,     "s", 3.0f),
        fl ("rev_predelay",  "Pre-delay",           "Room",       0.0f, 250.0f,    20.0f,    "ms"),
        fl ("rev_damp",      "Damping",            "Room",       0.0f, 1.0f,      0.4f),
        fl ("rev_width",     "Width",         "Room",       0.0f, 1.0f,      1.0f),
        fl ("rev_shimmer",   "Shimmer",          "Room",       0.0f, 1.0f,      0.0f),
        fl ("rev_mix",       "Room",             "Room",       0.0f, 1.0f,      0.2f),

        fl ("width",         "Stereo",           "Output",     0.0f, 2.0f,      1.0f),
        fl ("master",        "Master",           "Output",    -60.0f, 6.0f,     0.0f,     "dB", -12.0f),

        ch ("mode",          "Mode",             "Voice",      kPlayModes, 0),
        ch ("dyn_mode",      "Dynamics from",      "Voice",      kDynModes, 0),
        fl ("dynamics",      "Dynamics",         "Voice",      0.0f, 1.0f,      0.7f),
        fl ("humanize",      "Humanize",            "Voice",      0.0f, 1.0f,      1.0f),

        ch ("osc1_wave",     "Oscillator 1, wave",           "Oscillators", kOscWaves, 0),
        st ("osc1_oct",      "Oscillator 1, octave",         "Oscillators", -3.0f, 3.0f,    0.0f,    ""),
        st ("osc1_semi",     "Oscillator 1, semitones",       "Oscillators", -12.0f, 12.0f,  0.0f,    "st"),
        fl ("osc1_fine",     "Oscillator 1, fine",           "Oscillators", -100.0f, 100.0f, 0.0f,   "ct"),
        fl ("osc1_level",    "Oscillator 1, level",        "Oscillators", -60.0f, 6.0f,   -60.0f,  "dB", -12.0f),
        fl ("osc1_pw",       "Oscillator 1, pulse width",      "Oscillators", 0.05f, 0.95f,   0.5f),
        fl ("osc1_phase",    "Oscillator 1, right phase",       "Oscillators", 0.0f, 1.0f,     0.0f),
        st ("osc1_voices",   "Oscillator 1, unison",           "Oscillators", 1.0f, 8.0f,     1.0f,    ""),
        fl ("osc1_detune",   "Oscillator 1, unison detune",     "Oscillators", 0.0f, 1.0f,     0.25f),
        fl ("osc1_spread",   "Oscillator 1, unison stereo spread",       "Oscillators", 0.0f, 1.0f,     0.5f),

        ch ("osc2_wave",     "Oscillator 2, wave",           "Oscillators", kOscWaves, 0),
        st ("osc2_oct",      "Oscillator 2, octave",         "Oscillators", -3.0f, 3.0f,    0.0f,    ""),
        st ("osc2_semi",     "Oscillator 2, semitones",       "Oscillators", -12.0f, 12.0f,  0.0f,    "st"),
        fl ("osc2_fine",     "Oscillator 2, fine",           "Oscillators", -100.0f, 100.0f, 0.0f,   "ct"),
        fl ("osc2_level",    "Oscillator 2, level",        "Oscillators", -60.0f, 6.0f,   -60.0f,  "dB", -12.0f),
        fl ("osc2_pw",       "Oscillator 2, pulse width",      "Oscillators", 0.05f, 0.95f,   0.5f),
        fl ("osc2_phase",    "Oscillator 2, right phase",       "Oscillators", 0.0f, 1.0f,     0.0f),
        st ("osc2_voices",   "Oscillator 2, unison",           "Oscillators", 1.0f, 8.0f,     1.0f,    ""),
        fl ("osc2_detune",   "Oscillator 2, unison detune",     "Oscillators", 0.0f, 1.0f,     0.25f),
        fl ("osc2_spread",   "Oscillator 2, unison stereo spread",       "Oscillators", 0.0f, 1.0f,     0.5f),

        fl ("sub_level",     "Sub",              "Oscillators", -60.0f, 6.0f,   -60.0f,  "dB", -12.0f),
        ch ("sub_wave",      "Sub wave",         "Oscillators", kSubWaves, 0),
        fl ("osc_drift",     "Drift",           "Oscillators", 0.0f, 1.0f,     0.15f),
        ch ("osc_retrig",    "Phase",             "Oscillators", kRetrig, 0),

        ch ("lfo_shape",     "Shape",            "Motion",        kLfoShapes, 0),
        fl ("lfo_rate",      "Rate",        "Motion",        0.02f, 20.0f,   5.0f,    "Hz", 1.0f),
        fl ("lfo_delay",     "Delay",          "Motion",        0.0f, 3000.0f,  0.0f,    "ms", 400.0f),
        fl ("lfo_pitch",     "Vibrato",          "Motion",        0.0f, 100.0f,   0.0f,    "ct"),
        fl ("lfo_cutoff",    "To filter",        "Motion",        0.0f, 4.0f,     0.0f,    "oct"),
        fl ("lfo_amp",       "Tremolo",          "Motion",        0.0f, 1.0f,     0.0f),
        fl ("lfo_pw",        "To pulse width",   "Motion",        0.0f, 1.0f,     0.0f),

        fl ("fenv_attack",   "Filter, attack",  "Tone",       0.0f, 5000.0f,  0.0f,    "ms", 150.0f),
        fl ("fenv_decay",    "Filter, decay", "Tone",    1.0f, 10000.0f, 400.0f,  "ms", 300.0f),
        fl ("fenv_sustain",  "Filter, sustain", "Tone",       0.0f, 1.0f,     0.0f),
        fl ("fenv_release",  "Filter, release", "Tone",       1.0f, 15000.0f, 300.0f,  "ms", 500.0f),
        ch ("fenv_source",   "Envelope", "Tone",    kFenvSources, 0),
        fl ("flt_key",       "Key tracking",    "Tone",        0.0f, 1.0f,     0.0f),
        fl ("flt_vel",       "Velocity to filter", "Tone",      0.0f, 1.0f,     0.0f),

        fl ("osc1_phase_mod", "Oscillator 1, moto della fase",  "Oscillators", 0.0f, 1.0f,     0.0f),
        fl ("osc2_phase_mod", "Oscillator 2, moto della fase",  "Oscillators", 0.0f, 1.0f,     0.0f),

        st ("artic",         "Articulation",    "Voice",      0.0f, 15.0f,     0.0f,     ""),

        ch ("echo_sync",     "Sync",           "Echo",        kEchoSync, 0),
        ch ("echo_div",      "Division",     "Echo",        kEchoDivs, 5),
        ch ("caldi_mode", "Character", "Character", kCaldiModes, 0),
        fl ("caldi_amount", "Amount", "Character", 0.0f, 1.0f, 0.65f),
        fl ("caldi_body", "Body", "Character", 0.0f, 1.0f, 0.5f),
        fl ("caldi_light", "Brightness", "Character", 0.0f, 1.0f, 0.5f),
        fl ("caldi_grain", "Grain", "Character", 0.0f, 1.0f, 0.0f),
        fl ("caldi_motion", "Motion", "Character", 0.0f, 1.0f, 0.0f),
        fl ("caldi_output", "Release", "Character", -12.0f, 3.0f, 0.0f, "dB"),
        fl ("flt_dyn", "Tone expression", "Tone", 0.0f, 4.0f, 0.0f, "oct"),
        st ("sub_divisor", "Sub 1 divisor", "Oscillators", 1.0f, 24.0f, 2.0f, ""),
        fl ("sub2_level", "Sub 2 level", "Oscillators", -60.0f, 6.0f, -60.0f, "dB", -12.0f),
        st ("sub2_divisor", "Sub 2 divisor", "Oscillators", 1.0f, 24.0f, 3.0f, ""),
        fl ("sub3_level", "Sub 3 level", "Oscillators", -60.0f, 6.0f, -60.0f, "dB", -12.0f),
        st ("sub3_divisor", "Sub 3 divisor", "Oscillators", 1.0f, 24.0f, 4.0f, ""),
        fl ("amp_dyn", "Pressure", "Voice", 0.0f, 1.0f, 0.0f),
        fl ("lfo_pitch_cc1", "CC1 vibrato depth", "Motion", 0.0f, 100.0f, 0.0f, "cents"),
        fl ("vel_amp_curve", "Velocity amplitude curve", "Voice", 0.0f, 1.0f, 0.0f),
    }};

    bool equalsIgnoreCase (std::string_view a, std::string_view b) noexcept
    {
        if (a.size() != b.size())
            return false;

        for (size_t i = 0; i < a.size(); ++i)
            if (std::tolower ((unsigned char) a[i]) != std::tolower ((unsigned char) b[i]))
                return false;

        return true;
    }

}

const ParamSpec& spec (P p) noexcept        { return kSpecs[(size_t) p]; }
const ParamSpec& spec (int index) noexcept  { return kSpecs[(size_t) index]; }

int findParam (std::string_view id) noexcept
{
    for (int i = 0; i < kNumParams; ++i)
        if (id == kSpecs[(size_t) i].id)
            return i;

    return -1;
}

float clampPlain (const ParamSpec& s, float plain) noexcept
{
    if (! std::isfinite (plain))
        return s.def;

    plain = std::clamp (plain, s.min, s.max);

    if (s.scale == Scale::stepped || s.scale == Scale::choice)
        plain = std::round (plain);

    return plain;
}

float skewFactor (const ParamSpec& s) noexcept
{
    if (s.scale != Scale::continuous || std::isnan (s.centre) || s.centre <= s.min || s.centre >= s.max)
        return 1.0f;

    return std::log (0.5f) / std::log ((s.centre - s.min) / (s.max - s.min));
}

float toNormalised (const ParamSpec& s, float plain) noexcept
{
    plain = clampPlain (s, plain);
    const auto proportion = (plain - s.min) / (s.max - s.min);
    const auto skew = skewFactor (s);
    return skew == 1.0f ? proportion : std::pow (proportion, skew);
}

float fromNormalised (const ParamSpec& s, float norm) noexcept
{
    norm = std::clamp (norm, 0.0f, 1.0f);
    const auto skew = skewFactor (s);

    if (skew != 1.0f)
        norm = std::exp (std::log (std::max (norm, 1.0e-30f)) / skew);

    const auto v = s.min + norm * (s.max - s.min);
    return s.scale == Scale::continuous ? v : std::round (v);
}

int choiceIndex (const ParamSpec& s, std::string_view choice) noexcept
{
    for (int i = 0; i < s.numChoices; ++i)
        if (equalsIgnoreCase (choice, s.choices[i]))
            return i;

    return -1;
}

ParamSet::ParamSet() noexcept
{
    for (int i = 0; i < kNumParams; ++i)
        v[(size_t) i] = kSpecs[(size_t) i].def;
}

bool ParamSet::set (std::string_view id, float plain) noexcept
{
    const auto i = findParam (id);

    if (i < 0 || ! std::isfinite (plain))
        return false;

    v[(size_t) i] = clampPlain (kSpecs[(size_t) i], plain);
    return true;
}

bool ParamSet::setChoice (std::string_view id, std::string_view choice) noexcept
{
    const auto i = findParam (id);

    if (i < 0 || kSpecs[(size_t) i].scale != Scale::choice)
        return false;

    const auto c = choiceIndex (kSpecs[(size_t) i], choice);

    if (c < 0)
        return false;

    v[(size_t) i] = (float) c;
    return true;
}

} // namespace libero
