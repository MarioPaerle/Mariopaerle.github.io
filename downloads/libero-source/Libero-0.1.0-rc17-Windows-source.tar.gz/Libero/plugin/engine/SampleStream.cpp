#include "SampleStream.h"
#include "Bundle.h"
#include <algorithm>
#include <cmath>
#include <utility>
#include <stdexcept>

namespace libero
{
class SampleStreamPool::Scheduler
{
public:
    Scheduler();
    ~Scheduler();
    void add (const std::shared_ptr<SampleStreamPool>& pool)
    {
        const juce::ScopedLock guard (lock);
        pools.push_back (pool);
    }
    void snapshot (std::vector<std::shared_ptr<SampleStreamPool>>& live)
    {
        live.clear();
        const juce::ScopedLock guard (lock);
        for (auto it = pools.begin(); it != pools.end();)
            if (auto pool = it->lock()) { live.push_back (std::move (pool)); ++it; }
            else it = pools.erase (it);
    }
private:
    juce::CriticalSection lock;
    std::vector<std::weak_ptr<SampleStreamPool>> pools;
    std::vector<std::unique_ptr<Worker>> workers;
};
class SampleStreamPool::Worker final : public juce::Thread
{
public:
    explicit Worker (Scheduler& s, int index) : juce::Thread ("Libero sample streaming"), scheduler (s), lane (index) {}
    void run() override
    {
        juce::AudioFormatManager formats;
        formats.registerBasicFormats();
        std::vector<Reader> readers;
        std::vector<std::shared_ptr<SampleStreamPool>> pools;
        readers.reserve (64);
        while (! threadShouldExit())
        {
            // Snapshot owners keep pools alive during fills; audio cursors only hold slot leases.
            try { scheduler.snapshot (pools); }
            catch (...) { wait (10); continue; }
            for (auto& pool : pools)
                for (int i = lane; i < slotCount && ! threadShouldExit(); i += 2)
                    pool->service (pool->slots[i], formats, readers);
            wait (2);
        }
    }
private:
    Scheduler& scheduler;
    const int lane;
};
SampleStreamPool::Scheduler::Scheduler()
{
    for (int i = 0; i < 2; ++i) workers.push_back (std::make_unique<Worker> (*this, i));
    for (auto& worker : workers)
        if (! worker->startThread (juce::Thread::Priority::normal))
        {
            for (auto& started : workers) started->signalThreadShouldExit();
            for (auto& started : workers) started->stopThread (-1);
            throw std::runtime_error ("could not start sample streaming worker");
        }
}
SampleStreamPool::Scheduler::~Scheduler()
{
    for (auto& worker : workers) worker->signalThreadShouldExit();
    for (auto& worker : workers) worker->stopThread (-1);
}
SampleStreamPool::Scheduler& SampleStreamPool::scheduler()
{
    static Scheduler instance;
    return instance;
}
SampleStreamPool::SampleStreamPool() : slots (std::make_unique<Slot[]> (slotCount))
{
    for (int i = 0; i < slotCount; ++i)
        for (auto& chunk : slots[i].chunks) chunk.pcm.setSize (2, chunkFrames);
}
std::shared_ptr<SampleStreamPool> SampleStreamPool::create()
{
    auto pool = std::shared_ptr<SampleStreamPool> (new SampleStreamPool());
    scheduler().add (pool);
    return pool;
}
SampleStreamPool::~SampleStreamPool() = default;
const SampleStreamPool::Asset* SampleStreamPool::add (const juce::File& file, SampleBuffer attack,
                                                    int frames, float gain, double ratio, int sourceFrames)
{
    static std::atomic<uint64_t> nextAsset { 1 };
    auto asset = std::make_unique<Asset>();
    asset->id = nextAsset.fetch_add (1, std::memory_order_relaxed);
    asset->file = file; asset->channels = attack.getNumChannels();
    asset->attack = std::move (attack); asset->frames = frames; asset->gain = gain;
    asset->ratio = ratio; asset->sourceFrames = sourceFrames > 0 ? sourceFrames : frames;
    const auto* result = asset.get();
    const juce::ScopedLock lock (assetLock);
    assets.push_back (std::move (asset));
    return result;
}
SampleStreamPool::Cursor SampleStreamPool::acquire (const Asset* asset) noexcept
{
    const auto first = nextSlot.fetch_add (1, std::memory_order_relaxed);
    for (unsigned i = 0; i < slotCount; ++i)
    {
        auto& slot = slots[(first + i) % slotCount];
        int free = 0;
        if (! slot.users.compare_exchange_strong (free, -1, std::memory_order_acquire)) continue;
        slot.asset = asset;
        slot.requested.store (0, std::memory_order_relaxed);
        slot.served.store (-1, std::memory_order_relaxed);
        for (auto& chunk : slot.chunks) chunk.state.store (0, std::memory_order_relaxed);
        slot.users.store (1, std::memory_order_release);
        Cursor cursor; cursor.slot = &slot; cursor.pool = this;
        cursor.window = { asset->attack.getReadPointer (0), asset->channels > 1 ? asset->attack.getReadPointer (1) : nullptr,
                          0, 1, asset->attack.getNumSamples() - 2 };
        cursor.maintenanceAt = asset->attack.getNumSamples();
        return cursor;
    }
    exhausted.fetch_add (1, std::memory_order_relaxed);
    return {};
}
void SampleStreamPool::Cursor::copy (const Cursor& other) noexcept
{
    slot = other.slot; pool = other.pool; requested = other.requested; missedChunk = other.missedChunk;
    maintenanceAt = other.maintenanceAt; window = other.window;
    if (! slot) return;
    slot->users.fetch_add (1, std::memory_order_relaxed);
    for (int i = 0; i < 2; ++i)
    {
        pinned[i] = other.pinned[i];
        if (pinned[i]) pinned[i]->state.fetch_add (4, std::memory_order_relaxed);
    }
}
SampleStreamPool::Cursor::Cursor (const Cursor& other) { copy (other); }
SampleStreamPool::Cursor& SampleStreamPool::Cursor::operator= (const Cursor& other)
{
    if (this != &other) { reset(); copy (other); }
    return *this;
}
SampleStreamPool::Cursor::Cursor (Cursor&& other) noexcept { *this = std::move (other); }
SampleStreamPool::Cursor& SampleStreamPool::Cursor::operator= (Cursor&& other) noexcept
{
    if (this != &other)
    {
        reset(); slot = std::exchange (other.slot, nullptr); pool = other.pool;
        requested = other.requested; missedChunk = other.missedChunk;
        maintenanceAt = other.maintenanceAt; window = other.window;
        for (int i = 0; i < 2; ++i) pinned[i] = std::exchange (other.pinned[i], nullptr);
    }
    return *this;
}
void SampleStreamPool::Cursor::reset() noexcept
{
    for (auto*& chunk : pinned)
        if (chunk) { chunk->state.fetch_sub (4, std::memory_order_release); chunk = nullptr; }
    if (slot) slot->users.fetch_sub (1, std::memory_order_release);
    slot = nullptr; pool = nullptr; requested = missedChunk = -1;
    window = {}; maintenanceAt = 0;
}
void SampleStreamPool::Cursor::position (int frame) const noexcept
{
    if (! slot) return;
    const auto attackFrames = slot->asset->attack.getNumSamples();
    const auto index = std::max (0, (frame - attackFrames) / chunkFrames);
    maintenanceAt = attackFrames + (index + 1) * chunkFrames + 1;
    for (auto*& chunk : pinned)
        if (chunk)
        {
            const auto end = attackFrames + (chunk->index + 1) * chunkFrames;
            if (frame > end)
            {
                if (window.start == attackFrames + chunk->index * chunkFrames) window = {};
                chunk->state.fetch_sub (4, std::memory_order_release); chunk = nullptr;
            }
            else maintenanceAt = std::min (maintenanceAt, end + 1);
        }
    if (index != requested)
    {
        slot->requested.store (index, std::memory_order_release);
        requested = index;
    }
}
float SampleStreamPool::Cursor::sample (int channel, int frame) const noexcept
{
    if (! slot || frame < 0 || frame >= slot->asset->frames) return 0;
    const auto& asset = *slot->asset;
    const auto attackFrames = asset.attack.getNumSamples();
    channel = std::min (channel, asset.channels - 1);
    if (frame < attackFrames) return asset.attack.getReadPointer (channel)[frame];
    const auto index = (frame - attackFrames) / chunkFrames;
    const auto offset = (frame - attackFrames) % chunkFrames;
    for (auto* chunk : pinned)
        if (chunk && chunk->index == index)
        { if (! chunk->readable) readMissed = true; return chunk->pcm.getReadPointer (channel)[offset]; }
    for (auto& chunk : slot->chunks)
    {
        auto state = chunk.state.load (std::memory_order_acquire);
        while ((state & 3u) == 2u)
        {
            if (! chunk.state.compare_exchange_weak (state, state + 4, std::memory_order_acquire)) continue;
            if (chunk.index == index)
            {
                for (auto*& pin : pinned)
                    if (! pin) { pin = &chunk; missedChunk = -1; if (!chunk.readable) readMissed = true; return chunk.pcm.getReadPointer (channel)[offset]; }
            }
            chunk.state.fetch_sub (4, std::memory_order_release);
            break;
        }
    }
    readMissed = true;
    if (missedChunk != index)
    { pool->misses.fetch_add (1, std::memory_order_relaxed); missedChunk = index; }
    return 0;
}
void SampleStreamPool::Cursor::readSlow (int frame, float fraction, float& l, float& r) const noexcept
{
    if (! slot) { l = r = 0; readMissed = true; return; }
    const auto* asset = slot->asset;
    if (fraction == 0.0f)
    {
        l = sample (0, frame);
        r = asset->channels > 1 ? sample (1, frame) : l;
    }
    else
    {
        l = dsp::hermite (sample (0, frame - 1), sample (0, frame), sample (0, frame + 1), sample (0, frame + 2), fraction);
        r = asset->channels > 1 ? dsp::hermite (sample (1, frame - 1), sample (1, frame), sample (1, frame + 1), sample (1, frame + 2), fraction) : l;
    }
    position (frame);
    for (auto* chunk : pinned)
        if (chunk)
        {
            const auto start = asset->attack.getNumSamples() + chunk->index * chunkFrames;
            const auto end = std::min (asset->frames, start + chunkFrames);
            if (frame >= start && frame < end)
                window = { chunk->pcm.getReadPointer (0), asset->channels > 1 ? chunk->pcm.getReadPointer (1) : nullptr,
                           start, start + 1, end - 2, chunk->readable };
        }
}
void SampleStreamPool::service (Slot& slot, juce::AudioFormatManager& formats,
                               std::vector<Reader>& readers)
{
    if (slot.users.load (std::memory_order_acquire) <= 0) return;
    if (slot.served.load (std::memory_order_acquire) == slot.requested.load (std::memory_order_acquire)) return;
    bool idle = false;
    if (! slot.busy.compare_exchange_strong (idle, true, std::memory_order_acquire)) return;
    auto users = slot.users.load (std::memory_order_acquire);
    while (users > 0 && ! slot.users.compare_exchange_weak (users, users + 1, std::memory_order_acquire)) {}
    if (users <= 0) { slot.busy.store (false, std::memory_order_release); return; }
    try
    {
        const auto* asset = slot.asset;
        const auto wanted = slot.requested.load (std::memory_order_acquire);
        bool complete = true;
        for (int index = wanted; index <= wanted + 1; ++index)
        {
            const auto start = asset->attack.getNumSamples() + index * chunkFrames;
            if (start >= asset->frames) continue;
            bool ready = false;
            for (auto& chunk : slot.chunks)
            {
                // Pin before inspecting the tag, just as an audio reader does.
                auto state = chunk.state.load (std::memory_order_acquire);
                while ((state & 3u) == 2u)
                {
                    if (! chunk.state.compare_exchange_weak (state, state + 4, std::memory_order_acquire)) continue;
                    ready = ready || chunk.index == index;
                    chunk.state.fetch_sub (4, std::memory_order_release);
                    break;
                }
            }
            if (ready) continue;
            for (auto& chunk : slot.chunks)
            {
                unsigned expected = 0;
                bool writable = chunk.state.compare_exchange_strong (expected, 1, std::memory_order_acquire);
                if (! writable && expected == 2)
                {
                    // Ready metadata needs a read pin before deciding to evict it.
                    expected = 2;
                    if (chunk.state.compare_exchange_strong (expected, 6, std::memory_order_acquire))
                    {
                        const bool keep = chunk.index == wanted || chunk.index == wanted + 1;
                        chunk.state.fetch_sub (4, std::memory_order_release);
                        expected = 2;
                        if (! keep) writable = chunk.state.compare_exchange_strong (expected, 1, std::memory_order_acquire);
                    }
                }
                if (! writable) continue;
                bool read = false;
                try
                {
                    auto entry = std::find_if (readers.begin(), readers.end(), [asset] (const auto& item) { return item.id == asset->id; });
                    if (entry == readers.end())
                    {
                        if (readers.size() == 64) readers.erase (readers.begin());
                        readerOpens.fetch_add (1, std::memory_order_relaxed);
                        Reader reader;
                        reader.id = asset->id;
                        reader.source.reset (formats.createReaderFor (asset->file));
                        for (auto& pcm : reader.pcm) { pcm.setSize (2, chunkFrames); pcm.clear(); }
                        readers.push_back (std::move (reader));
                        entry = std::prev (readers.end());
                    }
                    int cached = -1;
                    for (int i = 0; i < 4; ++i) if (entry->cached[i] == index) cached = i;
                    if (cached < 0)
                    {
                        decodedChunks.fetch_add (1, std::memory_order_relaxed);
                        cached = (int) (std::min_element (std::begin (entry->used), std::end (entry->used)) - std::begin (entry->used));
                        auto& pcm = entry->pcm[cached];
                        const auto count = std::min (chunkFrames, asset->frames - start);
                        const bool convert = std::abs (asset->ratio - 1.0) >= 1e-9;
                        const auto halo = convert ? resampleHalo (asset->ratio) : 0;
                        const auto sourceStart = convert ? std::max (0, (int) std::floor (start * asset->ratio) - halo) : start;
                        const auto sourceEnd = convert ? std::min (asset->sourceFrames, (int) std::ceil ((start + count) * asset->ratio) + halo) : start + count;
                        auto& input = convert ? entry->sourceWindow : pcm;
                        if (convert) input.setSize (2, sourceEnd - sourceStart, false, false, true);
                        entry->ok[cached] = entry->source && entry->source->read (&input, 0, sourceEnd - sourceStart, sourceStart, true, asset->channels > 1);
                        if (entry->ok[cached])
                        {
                            for (int c = 0; c < asset->channels; ++c)
                                for (int i = 0; i < sourceEnd - sourceStart; ++i)
                                {
                                    auto& value = input.getWritePointer (c)[i];
                                    if (! std::isfinite (value)) value = 0;
                                    else value *= asset->gain;
                                }
                            if (convert)
                                for (int c = 0; c < asset->channels; ++c)
                                    resampleWindow (input.getReadPointer (c), sourceStart, asset->sourceFrames, asset->ratio,
                                                    start, count, pcm.getWritePointer (c));
                            if (count < chunkFrames) pcm.clear (count, chunkFrames - count);
                        }
                        else pcm.clear();
                        entry->cached[cached] = index;
                    }
                    else cacheHits.fetch_add (1, std::memory_order_relaxed);
                    entry->used[cached] = ++entry->useClock;
                    read = entry->ok[cached];
                    for (int c = 0; c < 2; ++c) chunk.pcm.copyFrom (c, 0, entry->pcm[cached], c, 0, chunkFrames);
                }
                catch (...) { read = false; }
                if (! read) { chunk.pcm.clear(); readErrors.fetch_add (1, std::memory_order_relaxed); }
                chunk.index = index;
                chunk.readable = read;
                chunk.state.store (2, std::memory_order_release);
                ready = true;
                break;
            }
            complete = complete && ready;
        }
        if (complete) slot.served.store (wanted, std::memory_order_release);
    }
    catch (...) { readErrors.fetch_add (1, std::memory_order_relaxed); }
    slot.users.fetch_sub (1, std::memory_order_release);
    slot.busy.store (false, std::memory_order_release);
}
SampleStreamPool::Stats SampleStreamPool::stats() const noexcept
{
    Stats result;
    for (int i = 0; i < slotCount; ++i) if (slots[i].users.load (std::memory_order_relaxed) > 0) ++result.active;
    result.misses = misses.load(); result.exhausted = exhausted.load(); result.readErrors = readErrors.load();
    result.decodedChunks = decodedChunks.load(); result.cacheHits = cacheHits.load(); result.readerOpens = readerOpens.load();
    return result;
}
}
