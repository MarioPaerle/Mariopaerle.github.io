#pragma once

// Live oscillators: band-limited wavetable mipmaps (quarter-octave levels, never above Nyquist),
// unison with detune and stereo spread, a left/right phase offset, analogue-style drift, a sub
// oscillator and one global LFO.

#include "Dsp.h"

#include <array>
#include <vector>

namespace libero
{

enum class OscWave { saw, square, triangle, sine, noise };
enum class LfoShape { sine, triangle, square, saw, random };

//==============================================================================
class WaveTables
{
public:
    static constexpr int kSize = 4096;       // samples per table
    static constexpr int kMaxHarmonics = 512;

    static const WaveTables& get();          // built once; call from a non-audio thread first

    // Table for `wave` (saw / triangle / sine) holding as many harmonics as fit below Nyquist
    // for a fundamental at `cyclesPerSample` (= f / sr).
    const float* table (OscWave wave, double cyclesPerSample) const noexcept;

    static float read (const float* t, double phase) noexcept
    {
        const auto x = phase * kSize;
        const auto i = (int) x;
        const auto f = (float) (x - (double) i);
        const auto a = t[i & (kSize - 1)], b = t[(i + 1) & (kSize - 1)];
        return a + f * (b - a);
    }

private:
    WaveTables();

    std::vector<int> harmonics;              // per level, ascending
    std::vector<std::vector<float>> saw, triangle;
    std::vector<float> sine;
};

//==============================================================================
struct OscSettings
{
    OscWave wave = OscWave::saw;
    float offset = 0.0f;        // semitones: octave * 12 + semi + fine / 100
    float gainStart = 0.0f, gainEnd = 0.0f;   // linear, ramped over the chunk
    float pw = 0.5f;
    float phaseLR = 0.0f, phaseLREnd = 0.0f;   // right channel phase offset (cycles), chunk start / end
    int voices = 1;
    float detune = 0.0f;        // 0..1
    float spread = 0.5f;        // 0..1

    bool on() const noexcept { return gainStart > 0.0f || gainEnd > 0.0f; }
};

struct OscControl
{
    std::array<OscSettings, 2> osc;
    struct SubBranch { float divisor = 2.0f, gainStart = 0.0f, gainEnd = 0.0f; };
    std::array<SubBranch, 3> sub;
    enum class SubWave { sine, square, saw };
    SubWave subWave = SubWave::sine;
    float drift = 0.0f;         // 0..1
    bool retrigger = false;     // true: phases reset at note-on; false: free phases (random start)

    bool any() const noexcept
    {
        if (osc[0].on() || osc[1].on()) return true;
        for (const auto& b : sub) if (b.gainStart > 0.0f || b.gainEnd > 0.0f) return true;
        return false;
    }
};

// The oscillators of one voice.
class VoiceOscillators
{
public:
    static constexpr int kUnison = 8;

    void prepare (float sampleRate) noexcept
    {
        sr = sampleRate;
        for (auto& unit : units) { unit.layoutVoices = -1; unit.frequencyValid = false; }
        for (auto& branch : subFrequency) branch.valid = false;
    }
    void start (uint32_t seed, bool retrigger) noexcept;

    // Adds the oscillator mix for `n` samples at `pitch` (MIDI semitones, fractional) to l/r.
    void render (const OscControl&, float pitch, float pwMod, float* l, float* r, int n) noexcept;

private:
    struct Unit
    {
        std::array<double, kUnison> phase {};
        std::array<double, kUnison> skew {};             // right minus left phase (drift), cycles
        std::array<float, 2> drift {}, driftTarget {};   // cents, per side
        int driftCountdown = 0;
        int layoutVoices = -1, frequencyVoices = 0;
        float layoutSpread = 0.0f, norm = 1.0f, frequencyDetune = 0.0f;
        std::array<float, kUnison> position {}, gainL {}, gainR {};
        std::array<double, kUnison> incrementL {}, incrementR {};
        double frequencyBase = 0.0, maxIncrement = 0.0;
        std::array<float, 2> frequencyDrift {};
        bool frequencyValid = false;
    };

    void renderOsc (int index, const OscSettings&, float pitch, float pwMod, float driftAmount,
                    float* l, float* r, int n) noexcept;

    std::array<Unit, 2> units;
    std::array<double, 3> subPhase {};
    struct SubFrequency { double base = 0, divisor = 0, increment = 0; bool valid = false; };
    std::array<SubFrequency, 3> subFrequency;
    dsp::Rng rng;
    float sr = 48000.0f;
};

//==============================================================================
// One global LFO. value() is in -1..1.
class Lfo
{
public:
    void prepare (float sampleRate) noexcept { sr = sampleRate; reset(); }
    void reset() noexcept;
    // Advances n samples at rateHz; returns the value at the end of the block.
    float advance (LfoShape, float rateHz, int n) noexcept;
    float value() const noexcept { return current; }

private:
    double phase = 0.0;
    float current = 0.0f, held = 0.0f, previousHeld = 0.0f;
    dsp::Rng rng;
    float sr = 48000.0f;
};

} // namespace libero
