#pragma once

#include <juce_core/juce_core.h>

#if JUCE_WINDOWS
 #ifndef NOMINMAX
  #define NOMINMAX
 #endif
 #include <windows.h>
 #include <shellapi.h>
#endif

namespace libero
{
inline juce::StringArray commandLineArguments (int argc, char* argv[])
{
    juce::StringArray arguments;
   #if JUCE_WINDOWS
    int count = 0;
    if (auto** native = CommandLineToArgvW (GetCommandLineW(), &count))
    {
        for (int i = 0; i < count; ++i) arguments.add (juce::String (native[i]));
        LocalFree (native);
        return arguments;
    }
   #endif
    for (int i = 0; i < argc; ++i) arguments.add (juce::String::fromUTF8 (argv[i]));
    return arguments;
}
}
