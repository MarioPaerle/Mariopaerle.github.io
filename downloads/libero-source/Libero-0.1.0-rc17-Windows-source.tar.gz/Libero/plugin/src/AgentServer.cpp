#include "AgentServer.h"
#include "Library.h"

#if JUCE_WINDOWS
 #include <windows.h>
#else
 #include <cerrno>
 #include <csignal>
 #include <unistd.h>
#endif

namespace libero
{
namespace
{
    int currentProcessId() noexcept
    {
       #if JUCE_WINDOWS
        return (int) GetCurrentProcessId();
       #else
        return (int) getpid();
       #endif
    }

    bool processIsAlive (int pid) noexcept
    {
        if (pid <= 0) return false;
       #if JUCE_WINDOWS
        auto handle = OpenProcess (SYNCHRONIZE, FALSE, (DWORD) pid);
        if (handle == nullptr)
            return GetLastError() != ERROR_INVALID_PARAMETER;
        const auto state = WaitForSingleObject (handle, 0);
        CloseHandle (handle);
        return state != WAIT_OBJECT_0;
       #else
        return ::kill (pid, 0) == 0 || errno != ESRCH;
       #endif
    }
}

class AgentServer::Client : public juce::Thread
{
public:
    Client (AgentServer& o, std::unique_ptr<juce::StreamingSocket> s)
        : juce::Thread ("Libero agent client"), owner (o), socket (std::move (s))
    {
    }

    ~Client() override
    {
        signalThreadShouldExit();
        socket->close();
        stopThread (3000);
    }

    void run() override
    {
        static constexpr int maxLineBytes = 4 * 1024 * 1024;
        std::string pending;
        char buffer[8192];

        while (! threadShouldExit())
        {
            const auto ready = socket->waitUntilReady (true, 100);

            if (ready < 0)
                break;

            if (ready == 0)
                continue;

            const auto n = socket->read (buffer, (int) sizeof (buffer), false);

            if (n <= 0)
                break;

            pending.append (buffer, (size_t) n);

            for (auto nl = pending.find ('\n'); nl != std::string::npos; nl = pending.find ('\n'))
            {
                const auto line = juce::String::fromUTF8 (pending.data(), (int) nl).trim();
                pending.erase (0, nl + 1);

                if (line.isEmpty())
                    continue;

                const auto response = processLine (owner.delegate, line, *this) + "\n";
                const auto utf8 = response.toStdString();

                if (socket->write (utf8.data(), (int) utf8.size()) < 0)
                    return;
            }

            if ((int) pending.size() > maxLineBytes)
                break;
        }
    }

private:
    AgentServer& owner;
    std::unique_ptr<juce::StreamingSocket> socket;
};

AgentServer::AgentServer (Delegate& d)
    : juce::Thread ("Libero agent socket"), delegate (d)
{
    instanceId = juce::String::toHexString (juce::Random::getSystemRandom().nextInt (0x1000000)).paddedLeft ('0', 6);
}

AgentServer::~AgentServer()
{
    stop();
}

bool AgentServer::start (const juce::String& host)
{
    if (isThreadRunning())
        return true;

    hostName = host;
    started = juce::Time::getCurrentTime().toISO8601 (true);

    for (int p = firstPort; p <= lastPort; ++p)
    {
        if (listener.createListener (p, "127.0.0.1"))
        {
            port = p;
            break;
        }
    }

    if (port.load() == 0)
        return false;

    cleanStaleInstances();
    writeInstanceFile();
    startThread();
    return true;
}

void AgentServer::stop()
{
    signalThreadShouldExit();
    listener.close();
    stopThread (3000);

    reapClients (true);

    const juce::ScopedLock sl (fileLock);

    if (instanceFile != juce::File())
        instanceFile.deleteFile();

    instanceFile = juce::File();
    port = 0;
}

void AgentServer::setSoundPath (const juce::String& path)
{
    {
        const juce::ScopedLock sl (fileLock);
        soundPath = path;
    }

    if (port.load() != 0)
        writeInstanceFile();
}

void AgentServer::writeInstanceFile()
{
    const juce::ScopedLock sl (fileLock);

    auto* o = new juce::DynamicObject();
    o->setProperty ("id", instanceId);
    o->setProperty ("port", port.load());
    o->setProperty ("pid", currentProcessId());
    o->setProperty ("host", hostName);
    o->setProperty ("sound", soundPath);
    o->setProperty ("started", started);

    const auto dir = library::instancesDir();
    dir.createDirectory();
    instanceFile = dir.getChildFile (instanceId + ".json");
    instanceFile.replaceWithText (juce::JSON::toString (juce::var (o), true) + "\n");
}

void AgentServer::cleanStaleInstances()
{
    const auto dir = library::instancesDir();

    if (! dir.isDirectory())
        return;

    for (const auto& f : dir.findChildFiles (juce::File::findFiles, false, "*.json"))
    {
        const auto v = juce::JSON::parse (f);
        const auto pid = v.isObject() ? (int) v["pid"] : 0;

        if (! processIsAlive (pid))
            f.deleteFile();
    }
}

void AgentServer::reapClients (bool all)
{
    bool changed = false;

    {
        const juce::ScopedLock sl (clientLock);

        for (int i = clients.size(); --i >= 0;)
        {
            if (all || ! clients[i]->isThreadRunning())
            {
                clients.remove (i);
                changed = true;
            }
        }

        numClients = clients.size();
    }

    if (changed)
        delegate.agentClientsChanged();
}

void AgentServer::run()
{
    while (! threadShouldExit())
    {
        reapClients (false);

        if (listener.waitUntilReady (true, 100) <= 0)
            continue;

        std::unique_ptr<juce::StreamingSocket> s (listener.waitForNextConnection());

        if (s == nullptr || threadShouldExit())
            continue;

        {
            const juce::ScopedLock sl (clientLock);
            auto* c = clients.add (new Client (*this, std::move (s)));
            c->startThread();
            numClients = clients.size();
        }

        delegate.agentClientsChanged();
    }
}

juce::String AgentServer::processLine (Delegate& d, const juce::String& line, juce::Thread& caller)
{
    juce::var request;
    const auto parsed = juce::JSON::parse (line, request);

    auto* response = new juce::DynamicObject();
    juce::var responseVar (response);

    if (parsed.failed() || ! request.isObject())
    {
        response->setProperty ("id", juce::var());
        response->setProperty ("error", "invalid JSON request");
        return juce::JSON::toString (responseVar, true);
    }

    response->setProperty ("id", request.getProperty ("id", juce::var()));

    const auto method = request["method"].toString();

    if (method.isEmpty())
    {
        response->setProperty ("error", "missing method");
        return juce::JSON::toString (responseVar, true);
    }

    auto params = request["params"];

    if (! params.isObject())
        params = juce::var (new juce::DynamicObject());

    Reply reply;

    try
    {
        reply = d.handleAgentRequest (method, params, caller);
    }
    catch (const std::exception& e)
    {
        reply = Reply::fail (juce::String ("internal error: ") + e.what());
    }

    if (reply.error.isNotEmpty())
        response->setProperty ("error", reply.error);
    else
        response->setProperty ("result", reply.result);

    return juce::JSON::toString (responseVar, true);
}

} // namespace libero
