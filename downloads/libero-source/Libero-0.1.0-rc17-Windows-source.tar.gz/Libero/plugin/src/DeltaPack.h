#pragma once
#include "Library.h"
#include <juce_cryptography/juce_cryptography.h>
#include <set>
#include <filesystem>

namespace libero::packs
{
// Stage the target tree, linking unchanged verified files. Commit uses the transactional bank importer.
inline juce::Result reconstructDelta (const juce::File& patch, const juce::File& output,
                                      const juce::String& id, const juce::String& version)
{
    const auto fail = [] (const char* text) { return juce::Result::fail (text); };
    const auto safe = [] (const juce::String& name)
    {
        if (name.isEmpty() || name.startsWithChar ('/') || name.containsAnyOf ("\\:\0")) return false;
        for (const auto& part : juce::StringArray::fromTokens (name, "/", ""))
            if (part.isEmpty() || part == "." || part == "..") return false;
        return true;
    };
    if (id.isEmpty() || !id.containsOnly ("abcdefghijklmnopqrstuvwxyz0123456789-")) return fail ("Invalid pack ID.");
    const auto bank = library::home().getChildFile ("banks").getChildFile (id);
    if (bank.isSymbolicLink()) return fail ("Linked base pack.");
    juce::ZipFile zip (patch);
    const auto* header = zip.getEntry ("delta.json");
    if (!header || header->uncompressedSize > 16 * 1024 * 1024) return fail ("Invalid delta manifest.");
    std::unique_ptr<juce::InputStream> stream (zip.createStreamForEntry (*header));
    const auto meta = stream ? juce::JSON::parse (stream->readEntireStreamAsString()) : juce::var();
    const auto installed = juce::JSON::parse (bank.getChildFile ("bank.json"));
    auto* files = meta["files"].getArray();
    if (meta["format"].toString() != "libero.delta/1" || meta["id"].toString() != id
        || meta["version"].toString() != version || meta["from_version"].toString() != installed["version"].toString()
        || !files || files->isEmpty() || files->size() > 100000) return fail ("Delta does not match the installed pack.");
    std::set<juce::String> entries, names;
    for (int i = 0; i < zip.getNumEntries(); ++i)
    {
        const auto* e = zip.getEntry (i);
        if (!e || e->isSymbolicLink || !safe (e->filename) || e->uncompressedSize < 0
            || !entries.insert (e->filename.toLowerCase()).second) return fail ("Unsafe delta archive.");
    }
    if (output.exists() || !output.createDirectory()) return fail ("Could not stage delta files.");
    bool ready = false;
    struct Cleanup { juce::File f; bool& ready; ~Cleanup() { if (!ready) f.deleteRecursively(); } } cleanup {output, ready};
    juce::int64 total = 0;
    int changed = 0;
    for (const auto& row : *files)
    {
        const auto name = row["path"].toString(), hash = row["sha256"].toString();
        const auto size = (juce::int64) row["bytes"];
        if (!safe (name) || hash.length() != 64 || !hash.containsOnly ("0123456789abcdef") || size < 0
            || size > 20ll * 1024 * 1024 * 1024 || !names.insert (name.toLowerCase()).second
            || (total += size) > 32ll * 1024 * 1024 * 1024) return fail ("Invalid delta file inventory.");
        auto source = bank.getChildFile (name);
        for (auto parent = source; parent != bank; parent = parent.getParentDirectory())
            if (parent.isSymbolicLink()) return fail ("Linked base file.");
        if ((bool) row["changed"])
        {
            ++changed;
            const auto* entry = zip.getEntry ("files/" + name);
            if (!entry || entry->uncompressedSize != size) return fail ("Missing delta payload.");
            source = output.getChildFile (name);
            if (!source.getParentDirectory().createDirectory()) return fail ("Could not stage delta payload.");
            std::unique_ptr<juce::InputStream> input (zip.createStreamForEntry (*entry));
            juce::FileOutputStream out (source);
            if (!input || !out.openedOk() || out.writeFromInputStream (*input, size + 1) != size)
                return fail ("Incomplete delta payload.");
            out.flush();
            if (out.getStatus().failed()) return fail ("Could not write delta payload.");
        }
        if (!source.existsAsFile() || source.getSize() != size || juce::SHA256 (source).toHexString() != hash)
            return fail ("Base or changed file does not match its checksum.");
        if (!(bool) row["changed"])
        {
            const auto target = output.getChildFile (name);
            if (!target.getParentDirectory().createDirectory()) return fail ("Could not stage reused file.");
            const auto native = [] (const juce::File& f) {
               #if JUCE_WINDOWS
                return std::filesystem::path (f.getFullPathName().toWideCharPointer());
               #else
                return std::filesystem::path (f.getFullPathName().toRawUTF8());
               #endif
            };
            std::error_code ec;
            std::filesystem::create_hard_link (native (source), native (target), ec);
            if (ec && !source.copyFileTo (target)) return fail ("Could not reuse base file.");
        }
    }
    if (zip.getNumEntries() != changed + 1 || !names.count ("bank.json")) return fail ("Unexpected delta files.");
    ready = true;
    return juce::Result::ok();
}
}
