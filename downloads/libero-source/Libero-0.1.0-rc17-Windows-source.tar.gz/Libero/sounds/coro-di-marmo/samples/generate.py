"""Regenerate the synthesised source samples of Coro di marmo.

    uv --directory python run python ../sounds/coro-di-marmo/samples/generate.py   # from the repo root
"""

from pathlib import Path

from libero import synth

HERE = Path(__file__).resolve().parent
SR = 48000


def breath_in():
    """A choir's shared inhale before the chord: soft 'h' through an open 'a'."""
    nz = synth.noise("pink", 0.55, sr=SR, seed=51, stereo=True)
    h = synth.formant(nz, [(0, "e"), (0.5, "a")], amount=0.7).highpass(250).lowpass(9000)
    return h.envelope([(0, 0), (0.3, 1), (0.45, 0.7), (0.55, 0)], curve="linear").normalize(-14)


def breath_out():
    """The release: a long, falling 'ho' of air."""
    nz = synth.noise("pink", 1.1, sr=SR, seed=52, stereo=True)
    h = synth.formant(nz, [(0, "o"), (1.1, "u")], amount=0.8).highpass(150).lowpass(6000)
    return h.envelope([(0, 0), (0.06, 1), (0.4, 0.5), (1.1, 0)]).normalize(-16)


if __name__ == "__main__":
    for name, fn in (("breath_in", breath_in), ("breath_out", breath_out)):
        a = fn()
        a.save(HERE / f"{name}.wav")
        print(f"{name}.wav  {a}")
