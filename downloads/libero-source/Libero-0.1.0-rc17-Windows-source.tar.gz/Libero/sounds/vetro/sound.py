"""Vetro — glass bell and glass harmonica in one: a rubbed, singing sustain with a
soft struck shimmer on top."""

import numpy as np

from libero import Audio, Sound, synth

sound = Sound(
    title="Vetro",
    subtitle="armonica di vetro, campana sfiorata",
    tags=["glass", "bell", "shimmer", "sustained", "ethereal"],
    roots=[48, 55, 62, 69, 76, 83, 90],
    velocities=[100],
    sample_rate=48000,
    accent="#8fbcbb",
)

LOOP_S = 4.0
# A rubbed glass sings mostly its lowest mode; the upper modes of a bowl (≈ n² spacing) stay faint.
GLASS = [(1.0, 1.0), (2.32, 0.11), (4.25, 0.035), (6.63, 0.012)]


@sound.body
def body(ctx):
    g = synth.LoopGrid(ctx.freq, LOOP_S, ctx.sr)
    dur = 1.0 + 2 * g.seconds
    t = np.arange(int(dur * ctx.sr)) / ctx.sr
    step = 1.0 / g.seconds  # the grid resolution: two voices this far apart beat once per loop
    breathe = 1.0 + 0.07 * np.sin(2 * np.pi * g.rate(0.5) * t)
    chans = []
    for side in (+1, -1):
        y = np.zeros_like(t)
        for i, (ratio, amp) in enumerate(GLASS):
            f = g.snap(g.freq * ratio)
            if f > 0.45 * ctx.sr:
                continue
            # each mode is a slightly split pair (a real glass is never perfectly round): a weaker twin
            # beats against it, above on the left and below on the right, so the shimmer moves across
            # the image while the mono sum never cancels (its depth stays within -6 dB)
            beat = step * (i + 1)
            y += amp * (0.75 * np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * (f + side * beat) * t + i))
        chans.append(y * breathe)
    tone = Audio(np.stack(chans, axis=1), ctx.sr)
    # friction hiss locked to the loop: periodic noise, resonated around the sung mode
    hiss = synth.noise("white", g.seconds, sr=ctx.sr, seed=ctx.seed, stereo=True).tile(dur).highpass(180, order=2)
    sung = hiss.bandpass(g.freq, q=25).gain_db(-3).mix(hiss.bandpass(g.snap(g.freq * 2.32), q=20).gain_db(-12))
    rim = hiss.highpass(2500, order=2).lowpass(9000).gain_db(-26)
    out = tone.normalize(-6).mix(sung.normalize_rms(tone.rms_db - 24), rim)
    return out.fade_in(0.12).normalize_loudness(-17.0)


@sound.attack(pitched=True)
def attack(ctx):
    # the soft rubbed onset: the finger's friction swell, focused onto the note
    rub = ctx.load("rub.wav")
    focus = rub.bandpass(ctx.freq, q=6).mix(rub.bandpass(ctx.freq * 2.32, q=6).gain_db(-8), rub.gain_db(-28))
    focus = focus.fit(0.9).fade_out(0.4).to_stereo().normalize(-15)
    # then, as the finger catches the rim, a light strike: the bell half of the instrument
    # (mono on purpose: independently detuned left/right copies would cancel in a mono sum)
    ting = synth.modal(ctx.freq, "glass", dur=5.0 - 2.0 * ctx.register, hardness=0.2, detune_cents=1.5,
                       decay_scale=0.4, sr=ctx.sr, seed=ctx.seed)
    return focus.place(ting.normalize(-13).to_stereo(), at=0.15).fade_out(0.3)


@sound.tail
def tail(ctx):
    return ctx.load("lift.wav").to_stereo()


@sound.air
def air(ctx):
    shimmer_room = synth.breath(8.0, sr=ctx.sr, seed=41, brightness=0.9, motion=0.3)
    return shimmer_room.highpass(2500, order=2).normalize_rms(-50)


@sound.impulse
def ir(ctx):
    return synth.impulse_response("hall", sr=ctx.sr, seed=17, t60=5.5)


sound.loop(body=True, min_seconds=3.0, region=(0.8, 1.0 + 2 * LOOP_S))
sound.defaults(
    amp_attack=220,
    amp_decay=3000,
    amp_sustain=0.9,
    amp_release=2600,
    amp_curve=-0.3,
    lvl_attack=-2,
    lvl_tail=-14,
    lvl_air=-20,
    vel_sens=0.5,
    rev_mode="Basilica",
    rev_size=0.8,
    rev_decay=7.0,
    rev_predelay=35,
    rev_damp=0.25,
    rev_shimmer=0.3,
    rev_mix=0.34,
    res_mode="Vetro",
    res_decay=0.7,
    res_bright=0.6,
    res_mix=0.22,
)
