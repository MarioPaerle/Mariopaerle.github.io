# Vetro

A glass harmonica that can also ring like a struck glass bell: a finger's rub swells into a pure, slowly beating tone, a soft strike blooms on top, and a shimmering cathedral carries it away.

## Intent

The sound of wet glass under a fingertip: nearly sinusoidal, with the slow "breathing" beat of a rim that is never perfectly round, a trace of friction hiss, and the bell-like ping of the same glass when touched a little harder.

## How it is built

- **Body** (looped, stereo): the glass's lowest mode with three faint upper modes at bowl ratios 2.32, 4.25, 6.63. Each mode has a weaker twin one grid step away — above on the left, below on the right — so the beating moves across the image while the mono sum only dips ~6 dB (equal twins cancelled completely in mono: fixed). A 0.5 Hz breathing swell, and friction hiss made from *tiled* white noise resonated at the sung mode. Every frequency sits on a 4 s `LoopGrid`, so the loop is exact: seam −120 dB on every root.
- **Attack** (pitched, per root): `samples/rub.wav`, a stick-slip friction swell, focused onto the note and its 2.32 mode; at 150 ms a soft mallet strike on the glass modes rings out over ~4 s. The strike is mono on purpose (independently detuned left/right copies cancelled in mono).
- **Tail**: `samples/lift.wav`, the finger leaving the rim.
- **Air**: very faint high shimmer.
- **Impronta IR**: a long hall (T60 5.5 s).

## Defaults

Basilica reverb with Aureola (shimmer) 0.3 and 7 s decay, Vetro resonator at 0.22, slow 220 ms attack and 2.6 s release.

## Regenerating the samples

`samples/generate.py` rebuilds `rub.wav` and `lift.wav`.
