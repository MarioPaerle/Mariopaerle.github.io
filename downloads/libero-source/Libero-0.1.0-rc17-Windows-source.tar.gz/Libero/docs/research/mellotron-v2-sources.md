# Authentic Mellotron source audit, v2

Checked 2026-10-04. This is a source-clearance record, not a legal opinion. No audio was downloaded or added to Libero for this research pass, and no preset or bank was changed.

## Acquisition update — 4 October 2026

The primary-source acquisition blocker described in the source-only pass below has been resolved. The root agent queried Internet Archive's CDX index for the original Leisureland ZIP URLs, recovered four payloads, and verified that each downloaded payload's SHA-1 (base32) exactly matches its CDX digest. SHA-256 acquisition records and the original CDX response are retained in `~/Libero/cache/research/giove/mellotron-original/`.

| Original set | Archived capture | SHA-256 of original ZIP |
|---|---|---|
| Cello | 2013-02-09 11:04:42 | `05bea6841541a3b70b1421e3edf5029e0f933d8181ca1d60c58acdeb55f4be03` |
| MkII Flute | 2023-02-10 17:07:17 | `71a4313d0e4db079afa562e91b582b516c7af7ec0db948ad64cb18bbe5844cd2` |
| MkII Violins | 2023-02-10 16:54:02 | `280604ea76209046defd6d0d22cf7290506f957c8d42e5984721c01524dc2c5d` |
| 8 Choir | 2023-02-10 16:57:19 | `da4c237bcb2103e0a7a380c1791062443d065283d8c190882d2c93829cf47d93` |

Each archive contains 35 original mono 44.1 kHz, 16-bit recordings, G2–F5. All 140 WAVs are preserved unchanged in the four new Giove presets and individually hashed. `Tape Original` retains the finite performance; `Sustained Loop` is a separately labelled derived long-loop articulation. The compiler applies a common recording gain, DC removal and a short edge ramp; source pitch drift is retained. The builder is `python/scripts/build_giove_mellotron_v2.py`.

This resolves acquisition and authenticity of the retrieved Leisureland recordings. It does not turn the author's freeware/no-payware permission into an open-content license, nor resolve the conflicting historical tape-master ownership claims. The four presets are playable in the private library and excluded from the general/open 75-sound candidate. Native verification is recorded separately in `docs/research/giove-mellotron-v2.md` after the check completes.

## Earlier source-only research pass

The following notes record the earlier research state before the archive recovery; statements that no sources had yet been acquired refer to that pass.

## Decision at the source-only checkpoint

I found an author-authored grant that supports use of Taijiguy’s authentic Leisureland Mellotron sample sets in freeware, with attribution and no payware/commercial use. This is a concrete route for a separate freeware/no-payware bank. The remaining blocker is acquisition of the actual full WAVs from the author or a verifiable archive/authorized mirror: Leisureland’s indexed page is currently returning 502, and I could not verify or hash a mirror copy. No samples have been acquired or used yet. “Free for music use” or royalty-free permission alone would not cover packaging samples in an instrument.

There is one genuine but unsuitable **short Mellotron-flute transient** lead: Freesound user menegass published a pack titled “MELLOTRON FLUTE” with twelve chromatic note-labelled files from C through B. I checked all twelve individual item pages; each identifies a note, shows CC0 1.0, and reports 0.133–0.135 seconds, mono, 44.1 kHz, 16-bit, about 11.5–11.8 KB. That is explicit redistribution permission for each posted file, including commercial use, but the files are only tiny snippets, not the Mellotron’s ~7–8-second tape performances. Freesound’s pages display “Login to download”; I did not find a no-login direct preview/download URL. I did not download or use them.

For the classic set, I found a direct, first-person permission statement by Taijiguy on KVR: he says the Leisureland samples are his, are there for people to use freely “including in freeware (no payware please),” and asks that downloaders be told where they came from. In a later KVR post he says the samples may not be used in “commercial, for profit software.” Read together, this supports inclusion in a clearly free, non-payware instrument distribution with attribution, but does not support a paid/commercial Libero product. The statement is an author’s forum grant rather than a formal license text and does not spell out whether a free product may be funded by donations, ads, or other indirect revenue; keep those out of scope unless clarified. The original Leisureland download page is indexed and identifies the instrument sources, sounds, and durations, but live requests returned 502 during this check. I found no verifiable archive copy or author-endorsed mirror from which I could acquire and hash the actual full samples, so none has been downloaded or included.

The same Freesound account’s pack page lists C, C#, D, D#, E, F, F#, G, G#, A, A#, B as separate files, all posted on 27 October 2010. The pack page itself is not a single blanket instrument license; I checked each linked item page individually and each displays CC0. The CC0 deed permits copying, modification, and distribution, including commercially, subject to the deed’s terms and the limits of rights that cannot be waived.

## Findings by route

| Route | What primary evidence says | Redistribution result |
|---|---|---|
| menegass, “MELLOTRON FLUTE” Freesound pack | [Pack page](https://freesound.org/people/menegass/packs/6814/) lists twelve chromatic note-labelled items C–B. I opened all twelve item pages; each displays CC0, and their stated durations range from 0.133 to 0.135 s. Representative pages: [A](https://freesound.org/people/menegass/sounds/107307/), [C](https://freesound.org/people/menegass/sounds/107310/), [G](https://freesound.org/people/menegass/sounds/107317/). [CC0 deed](https://creativecommons.org/publicdomain/zero/1.0/). | **All twelve are CC0, but unsuitable as sustained Mellotron voices.** The tiny clips are not authentic 7–8-second tape performances. Pages show “Login to download”; I did not find a direct preview/download without login. Not downloaded or used. |
| menegass, “Mellotron WW2 Siren” | [Freesound item page](https://freesound.org/people/Analogist/sounds/449907/) describes a CC0 effect recording of an FX reel on an M400. | A real Mellotron-related effect, not flute/violins/choir/cello/brass; not a note-sustaining instrument source. Not downloaded or used. |
| Leisureland / Taijiguy classic sample sets | [Leisureland source page](https://www.leisureland.us/mellotron.htm) (indexed copy) says WAVs came from an M400S and M4000, lists Cello, MkII Violins, MkII Flute, 8 Choir, brass and other frames, and says each ZIP is ~20 MB and each note lasts ~7–8 seconds. [Taijiguy’s 2008 first-person KVR grant](https://www.kvraudio.com/forum/viewtopic.php?start=15&t=236629) says the samples are his and may be used freely “including in freeware (no payware please),” provided downloaders are told where they came from. His [later terms statement](https://www.kvraudio.com/forum/viewtopic.php?t=561309) excludes commercial, for-profit software. The [KVR set thread](https://www.kvraudio.com/forum/viewtopic.php?start=45&t=174365) describes the original WAVs and identifies many classic sets. | **Permission supports a free, non-payware Libero instrument with attribution; no permission for commercial/payware.** The grant is an author forum statement rather than a formal license and does not address donations/ads. The source page returned 502 and no verifiable archive or authorized mirror copy was available to download/hash, so the actual source WAVs remain unacquired. See [prior rights-chain analysis](giove-mellotron-sources-v1.md). |
| Plogue Sforzatron | Plogue’s README says it used Taijiguy’s files with permission. The package terms prohibit redistributing package contents absent written permission. | **Not cleared for extraction/repackaging.** Permission to Plogue does not sublicense Libero. |
| Mellotron tape-master source | [Mellotron’s tape-selection page](https://www.mellotron.com/tapesele.htm) states that Mellotron owns the original Mellotron and Chamberlin tape masters and is the exclusive provider of remastered tapes. The page gives no open sample-bank grant. | **Not cleared.** This conflicts with the public-domain account reported secondhand by Taijiguy; public evidence does not resolve ownership and recording rights. |
| “Free”, “free beer”, or royalty-free sample libraries | Prior leads include LinuxSampler’s “free as in beer” label and music sample packs whose permission is for finished music. | **Insufficient.** Neither phrase proves the right to redistribute raw or transformed samples inside another sampler. |

## Practical next step

The current first-person Taijiguy grant is sufficient evidence for preparing a **separate freeware/no-payware** bank, with source credit preserved and the original file durations/tails intact. It is not clearance for a commercial/general release. Before building that bank, acquire the original WAVs only from Leisureland itself or a verifiable archive/authorized mirror of those exact files, hash them, and record the lineage. If that cannot be done, stop rather than substituting a third-party Sforzatron/other packaged archive. Keep a 7–8-second original tape articulation finite; any looped sustained option must be a separately described derived articulation and must not replace the tape-original one.

The small menegass set may be reconsidered for a short-note/flute transient after individually checking and hashing all twelve files and measuring their real durations, pitches, and content. It should not be presented as a complete Mellotron voice or silently extended into a false sustained tape performance.
