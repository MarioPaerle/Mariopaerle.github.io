# Giove — costruzione e verifica

Obiettivo dell’ascoltatore: strumenti analogici caldi, pieni e distinguibili, con particolare attenzione a Trautonium e Mellotron. Tastiera MIDI con pitch wheel; la priorità è il legato fra le note.

Il motore nativo già mantiene una voce con inviluppo continuo quando si sovrappongono i tasti in modo Legato. I test eseguiti su libero-render installato hanno confermato: attacco non riavviato, dip −1.1 dB, ritorno all’ultima nota ancora premuta [60,67,64,67], transizione senza click (rapporto transienti 1.00), assestamento entro 100 ms con glide zero. La suite render termina con 0 failure. Questi sono test del motore, da integrare con frasi native su ogni preset.

## Progetto della banca

24 voci installate e verificate:

- 6 Theremin/Trautonium/Volk/Mixtur: Sol 6.1, Legato predefinito, portamento regolabile e vibrato automatico continuo. Due Theremin a oscillatori vivi; quattro sintetizzatori a formanti/divisori con sintesi originale esplicita.
- 14 voci: Luna, quattro Moog classici, tre Subsequent 37, tre Solar 42F, due ambient ispirati a Mercury X, due mallets ispirati a Marble Machine. Mercury X è un processore di riverbero, Marble Machine un meccanismo acustico: i preset non sono dichiarati registrazioni di hardware proprietario.
- 4 nuove tastiere a nastro: flauto, corde, ottoni e ance. Registrazioni acustiche CC0 con gesti reali e un’architettura di continuazione per tasto. Non contengono i master di un Mellotron storico e non sono presentate come sue registrazioni.

Il manuale Solar 42F è stato acquisito direttamente dall’URL del produttore e conservato con SHA-256 nella cache di ricerca. Descrive sei drone e due VCO, cinque oscillatori saw per alcune voci drone e due filtri Polivoks da 12 dB. Non si sostituisce il modello F con il nuovo N.

## Nastri pubblicabili

Nastri di Flauto: VSCO 2 CE, flauto realmente registrato, una intensità; note 60–84.
Nastri di Corde: sezioni indipendenti di violini e viole VSCO 2 CE, due intensità registrate; note 55–84.
Nastri di Ottone: tromba, corno e trombone indipendenti VSCO 2 CE; note 48–77.
Nastri di Ance: Squidpipes di Karoryfer, cornamusa realmente registrata; note 43–77. Le sorgenti eleggibili sono 34 registrazioni con ottava fisica misurata (+12 rispetto alla mappa SFZ), mentre g4 ambiguo e sorgenti superiori non misurate sono escluse. Il registro basso usa trasposizione varispeed esplicita; non è dichiarato campionato indipendentemente su ogni tasto.

Ogni lane conserva attacco e movimento. Correzioni statiche centrano la parte effettivamente usata per il loop; niente correzione dinamica del vibrato. Nelle miscele ogni esecutore resta distinto. La continuità è progettata da segmenti della stessa performance, non una dichiarazione di esecuzione acustica infinita. Banda di riproduzione moderata, nessun segnale ritardato dry/wet, wow/flutter zero.

Fonti e licenze: [VSCO ufficiale](https://github.com/sgossner/VSCO-2-CE), [Squidpipes ufficiale](https://shop.karoryfer.com/pages/free-squidpipes), [dedicazione Karoryfer](https://shop.karoryfer.com/pages/free-samples). I campioni storici Mellotron trovati non sono ancora autorizzati per un bundle commerciale pubblico: vedere giove-mellotron-sources-v1.md. È stata presentata all’utente la scelta fra nuove voci pubblicabili e aggiunta separata di quelle storiche per uso personale; intanto si procede con la prima opzione.

## Verifiche e limiti

`build_giove_tapes_v1.py` conserva originali byte per byte, mappa per tasto, hash dei documenti e trasformazioni per ogni lane. `verify_giove_tapes_v1.py` verifica il range completo, dinamiche realmente presenti, loop su ogni key, tre tenute di 60s e otto note v127 a default/massima dinamica. Il pitch di insieme è diagnostico; i centri delle singole lane sono misurati sul segmento di loop. Le verifiche tecniche non attestano gradimento, calore o realismo percepito.

Le sei voci continue sono finite e verificate: le frasi native di otto note sovrapposte hanno variazioni RMS alle transizioni entro 1.35 dB; le tenute di 60 secondi restano attive e la verifica pitch copre tutte le radici/dinamiche (tutti i tasti per i Theremin). Il master portante dei Mixtur e i rami divisori sono misurati separatamente. La prova opzionale di otto note in Poli resta sotto −3 dBFS. La guida MIDI sul legato è inclusa nelle note di ogni preset.

Giove è una banca locale completata. Nessun upload o rilascio effettuato. Non modifica i 200 originali o i 18 sostituti della preparazione pubblica separata.

## Chiusura delle verifiche

- Integrità 24/24 PASS: hash attuali uguali ai manifest, nessun lint FAIL, figure valide, tutte le articolazioni di corpo sostenuto hanno loop. Sei voci Legato con glide e vibrato ritardato; altre diciotto Poli e glide zero. WOW/Flutter zero e Caldi spenti. Runtime totale: 203.5 MB non compressi.
- Dodici synth: 1176 eventi nativi, 49 tasti a due velocity per ciascuno; centro della famiglia del carrier entro 0.771 cents. La prova disabilita soltanto attacco/rilascio lunghi, riverbero, echo e LFO di pitch/cutoff per isolare la misura. I sub dichiarati all’ottava inferiore non sono errori di altezza. Safety separata sui default reali, tre hold60s e stack8 default/Manopola1, PASS.
- Xylophone: 48 performance conservate, sei articolazioni (tre mazze × sostenuto/colpo); 274 celle native misurate, modo fisico entro 3.94 cents. Range MIDI66–108, tutte le intensità coperte con celle comuni. Lint 0 FAIL/4 WARN.
- Marimba: 30 raw conservati, 28 performance attive; F5-soft e C6-soft esclusi per SNR/intonazione ambigua. Nelle celle alte è dichiarata la trasposizione della performance soft verificata più vicina. Due articolazioni sostenuto/colpo, 166 celle native misurate; modo fisico entro 14.99 cents nella prova, con limite di 35c esplicito per attacchi di barre inarmoniche. Range MIDI41–96, niente buchi o sovrapposizioni di dinamica. Lint 0 FAIL/5 WARN.
- Per colpi one-shot, distanziare gli eventi di prova oltre l’intero decadimento: il primo probe con spacing1.55s misurava talvolta la nota precedente ancora attiva. Le prove finali colpo usano8s, sostenuto1.55s. Nessun tuning aggiunto per inseguire lo stimatore YIN nei battimenti inarmonici.

Rapporti: `~/Libero/demo/giove-v1/bank-integrity.json`, `synth-carrier-pitch.json`, `default-safety/report.json`, `tapes/report.json`, `legato-headroom-report.json`, `pitch-native-report.json`; matrice mallets in `~/Libero/demo/giove-luna14/report.json`. Diagnostico indipendente di78 raw VCSL e35 Squid nella cache research/giove. Le verifiche sono tecniche e non attestano gradimento o equivalenza agli hardware storici.
