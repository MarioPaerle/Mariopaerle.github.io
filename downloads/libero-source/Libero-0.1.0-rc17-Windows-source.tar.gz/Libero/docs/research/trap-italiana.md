# Italian trap: measured palette and kit targets

Purpose: give Libero numbers for Italian trap drums and melodic sounds. Everything in the tables is **MEASURED** from full-mix official uploads (YouTube audio, lossy, so content above about 16 kHz is codec-limited). Text marked **INTERPRETATION** is inference, not measurement. No audio, melody or pattern was kept: files were downloaded to `~/Libero/cache/refs/trap-ita/`, measured and deleted. Scripts were throw-away; the methods are described below so they can be redone with `libero.dsp` + scipy.

## 1. Tracks and credits (resolved by web search)

| key | track | artist | producer credit found | year | felt tempo (BPM, double-time in brackets) |
|---|---|---|---|---|---|
| Piove | PIOVE | Lazza, Sfera Ebbasta | Lazza, Low Kidd, Drillionaire (album Sirio) | 2022 | ~84 (168) |
| J | J | Lazza | Drillionaire | 2020 | ~71 (142) |
| Mezzo | MEZZO SPORT (64 Bars) | Lazza and Drillionaire | Drillionaire (Red Bull 64 Bars) | 2021 | ~70 (140) |
| Bimbi | Bimbi | Charlie Charles ft. Izi, Rkomi, Sfera, Tedua, Ghali | Charlie Charles | 2017 | ~67 (134) |
| Freddy | Freddy friendly | Dani Faiv ft. Gemitaiz | **Kanesh** (not one of the three producers) | 2020 | uncertain: 67 (134) by autocorrelation, 150 by kick grid |
| DDA | DDA | Lazza | "Prod. 333 Mob" (Low Kidd; added by me for the Low Kidd signature) | 2017 | ~88 (176) |
| Molotov | MOLOTOV | Lazza | Low Kidd (listed among his Sirio credits; added by me) | 2022 | ~80 (160) |
| Bottiglie | Bottiglie privè | Sfera Ebbasta | Charlie Charles (added by me) | 2020 | ~72 (144) |

Resolutions: "Mezzo Sport" and "64 Bars" are **one** track, "MEZZO SPORT (64 Bars)". "Freddy Friendly" is Dani Faiv/Gemitaiz, produced by Kanesh, so it is a non-producer reference. "Bimbi" is Charlie Charles's own 2017 single. Bottiglie privè: the 4:08 YouTube cut is longer than the 3:09 listed and measures about 4 LU quieter than the others; treat it as **low weight** (different master or video edit).

Sources: Wikipedia (Charlie Charles, Drillionaire, Lazza, Bottiglie privè), it.wikipedia Low Kidd, Shazam/Spotify credit pages. No source describes any of these producers' sound in detail; every "signature" below is measurement plus interpretation.

## 2. Method and limits

Full mixes only: no stems. Vocals contaminate hat/snare detection, so hat and snare numbers are **low confidence** (percussive-component resynthesis, top-15 % peaks in 1.2-5 kHz for snare, 7 kHz+ for hats). 808/kick numbers come from a 200 Hz low-passed, decimated signal; "kick-like" = low onset whose sub envelope falls 15 dB in under 220 ms, "808" = 300 ms or more or cut off by the next hit. Drum-only bars barely exist (6 of 8 tracks have none, drums always run under melody), so drums are measured in-mix. Intros without drums exist in 6 tracks and give clean melodic numbers (section 4). Tempo was taken from the kick-onset grid and autocorrelation. Swing: the 16th-grid residual (20-28 ms rms) is no better than random (about 31 ms at 140 BPM) because the patterns use triplets and rolls; odd-minus-even 16th offset is within 5 ms for 7 of 8 tracks, so **no measurable swing** (Molotov 16 ms is the single exception). Tape wow: not measurable; stable partials wobble 0-4 cents, which is digital-stable.

## 3. Drums, per track (MEASURED)

| metric | Piove | J | Mezzo | Bimbi | Freddy | DDA | Molotov | Bottiglie* |
|---|---|---|---|---|---|---|---|---|
| integrated LUFS | -8.4 | -7.5 | -7.8 | -6.2 | -7.0 | -7.8 | -7.1 | -11.3 |
| short-term LUFS p10/p50/p90 | -12.4/-7.8/-7.0 | -13.5/-7.4/-6.4 | -12.2/-7.6/-6.4 | -9.3/-6.0/-5.4 | -11.2/-7.6/-5.0 | -26/-7.9/-6.8 | -9.1/-7.1/-5.7 | -29/-13.0/-9.5 |
| crest (peak - rms, dB) | 9.8 | 9.2 | 9.7 | 7.1 | 9.3 | 10.0 | 9.4 | 14.3 |
| samples at 0.98 FS or more | 0.08 % | 0.27 % | 0.34 % | 0.88 % | 0.25 % | 0.02 % | 0.18 % | 0.0001 % |
| energy share below 60 / 60-150 Hz (dB re total) | -4.2 / -7.0 | -3.3 / -7.4 | -5.1 / -6.0 | -3.5 / -4.5 | -7.3 / -5.6 | -3.7 / -5.3 | -7.6 / -5.7 | -6.1 / -4.3 |
| 808 fundamental median (p10-p90) Hz | 62 (31-122) | 44 (31-80) | 65 (34-98) | 61 (33-122) | 59 (46-101) | 54 (43-117) | 65 (52-110) | 90 (44-121) |
| 808 decay to -15 dB, median (p75) ms | 190 (452) | 220 (585) | 140 (262) | 115 (425) | 105 (200) | 130 (320) | 145 (175) | 115 (235) |
| share of 808 notes cut off by the next hit | 70 % | 85 % | 91 % | 96 % | 95 % | 97 % | 97 % | 93 % |
| 808 early pitch drop, cents (30-90 vs 90-170 ms) | +50 | +49 | +76 | +36 | -6 | -4 | -70 | +2 |
| 808 drift after 170 ms, cents | +1 | +20 | -31 | -5 | +5 | -3 | +5 | -2 |
| continuous pitch runs (slides) per minute | 3.9 | 0.4 | 0.5 | 0.2 | 0.9 | 2.5 | 0.7 | 0 |
| slide span median, cents | 114 | 302 | 404 | 173 | 178 | 178 | 148 | n/a |
| 808 THD, 2f..5f vs f, dB (mix upper bound) | -6.1 | -8.9 | -5.3 | -14.4 | -1.6 | -13.7 | -3.3 | -8.4 |
| 808 2f / 3f / 4f dB re f | -8/-12/-21 | -20/-10/-25 | -17/-9/-22 | -19/-18/-25 | -7/-12/-14 | -24/-19/-22 | -11/-12/-14 | -13/-17/-21 |
| 150-500 Hz vs 28-120 Hz in 808 tail, dB | -4.9 | -7.4 | -4.5 | -11.9 | +2.9 | -9.0 | -0.2 | -4.6 |
| kick-like hits: median fundamental Hz (15-75 ms) | 132 | 158 | 130 | 55 | 127 | 60 | 53 | 112 |
| kick-like decay to -15 dB, median ms | 80 | 85 | 125 | 50 | 130 | 110 | 115 | 112 |
| kick click (1.5-6 kHz, first 14 ms) vs sub, dB | -5.1 | -0.7 | -16.0 | -10.9 | -11.1 | -12.3 | -14.1 | -9.7 |
| ducking of 150-1500 Hz harmonic bed at kicks, dB | -0.4 | -0.8 | -1.3 | -0.7 | -1.1 | -1.9 | -1.6 | -0.4 |
| snare/clap: decay to -20 dB, median ms (1.2-5 kHz) | 68 | 63 | 78 | 64 | n/a | 52 | 92 | n/a |
| snare level 150 ms after peak, dB re peak | -27 | -22 | -20 | -26 | n/a | -26 | -24 | n/a |
| snare body peak Hz | 284 | 331 | 270 | 292 | n/a | 199 | 123 | n/a |
| snare spectrum dB re total [100-300, 300-1k, 1-3k, 3-8k, 8k+] | -8/-6/-6/-10/-14 | -12/-4/-5/-11/-19 | -8/-5/-6/-9/-17 | -6/-5/-7/-11/-19 | n/a | -4/-4/-11/-12/-16 | -6/-3/-8/-13/-19 | n/a |
| hat decay to -12 dB: median / p90 ms | 18 / 73 | 15 / 66 | 25 / 88 | 29 / 96 | 20 / 24 | 22 / 89 | 18 / 96 | n/a |
| open hats (decay over 120 ms) share | 2 % | 1 % | 5 % | 6 % | 0 % | 5 % | 4 % | n/a |
| hat centroid 3-20 kHz, Hz | 8600 | 6850 | 7890 | 7070 | 7000 | 7250 | 7860 | n/a |
| hat onset interval ms p10 / p50 / p90 | 22/60/235 | 30/174/259 | 23/95/233 | 30/105/266 | n/a | 23/60/171 | 28/138/344 | n/a |
| hat intervals near 1/8 | 4 % | 34 % | 11 % | 17 % | n/a | 17 % | 23 % | n/a |
| hat intervals near 1/32 (rolls) | 8 % | 7 % | 6 % | 15 % | n/a | 17 % | 6 % | n/a |
| sub stereo correlation (below 150 Hz) | 0.998 | 0.92 | 0.71 | 0.99 | 0.99 | 0.99 | 0.98 | 0.97 |
| hat region (over 5 kHz) correlation / side-to-mid dB | 0.95 / -15 | 0.95 / -16 | 0.95 / -16 | 0.91 / -13 | 0.75 / -8 | 0.59 / -6 | 0.77 / -9 | 0.92 / -13 |

\* Bottiglie: low weight. Hat/snare rows in Freddy and Bottiglie are n/a because their detection windows were the few drum-only bars (too few events). Hat interval fractions use the fast tempo as the beat and are noisy (vocal sibilance counts as hats); read them as ordering, not as exact pattern statistics. Percussion (rims, snaps, loops) was not separable in a full mix: **not measured**.

### Reading the drum table

- **Loudness**: six of eight tracks sit at -6.2 to -8.4 LUFS, crest 7-10 dB, with about 0.1-0.9 % of samples at full scale. This is louder and more squashed than the generic hip-hop target in `genres.md` (-9.5..-10). Libero's trap bus should target about -7.5 LUFS with limiting, not -10.
- **Low end dominates**: below 150 Hz holds about 55-70 % of the energy (sum of the two low bands) in all tracks.
- **808**: fundamental mass 31-65 Hz (B0-C2); retriggered rhythmically, so most notes are cut within 100-250 ms; only a minority ring beyond 400 ms. A small downward pitch drop (+35..+75 cents over the first 170 ms) is present in the four loudest-low tracks (Piove, J, Mezzo, Bimbi); zero elsewhere. Glides between notes exist but are rare (0-4 per minute, 1-4 semitones). Distortion is real: THD about -5..-9 dB in most (cleanest Bimbi, DDA about -14); in J, Mezzo, DDA 3f is as strong as or stronger than 2f (odd-heavy clip).
- **Kick vs 808**: in Piove/J/Mezzo/Freddy the kick body sits near 125-160 Hz, 1-1.5 octaves above the 808 fundamental (about 45-65 Hz): the "carve" is by pitch separation. In Bimbi, DDA, Molotov the short hits sit at 53-60 Hz, the same region as the 808: here the 808 itself acts as the short kick (**INTERPRETATION**). Click is 10-14 dB under the sub in most tracks; J (-0.7 dB) and Piove (-5 dB) are clickier.
- **Snare/clap**: short, dry, about 50-90 ms to -20 dB, 150 ms tail 20-27 dB down: almost no reverb. Energy sits at 300 Hz-3 kHz with little above 8 kHz (-14..-19 dB re total); body about 270-330 Hz in the four main tracks. Flutter counts of 4-6 sub-peaks in the first 40 ms suggest a layered or clap-like transient but the detector counts noise too (low confidence).
- **Hats**: tight, 15-30 ms to -12 dB, open hats at most 6 % of events; centroid 6.9-8.6 kHz. Roll content is highest in Bimbi and DDA (15-17 % near 1/32), 1/8 backbone strongest in J.
- **Stereo**: sub is mono (0.98+) in five of eight; Mezzo Sport has a wide sub (0.71, side only 8 dB under mid) and J 0.92, a measured exception. Hats mono-ish (0.95) in the three Lazza/Drillionaire tracks, wide (0.59-0.77) in DDA, Molotov, Freddy.
- **Sidechain**: at most 2 dB ducking of the 150-1500 Hz bed: effectively none. Do not add pumping.

## 4. Melodic palette, per track (MEASURED, melody-only windows)

Windows are drum-free intros/breaks found automatically (5-13 s). Columns marked "mix" are whole-track harmonic component above 250 Hz.

| metric | Piove | J | Bimbi | DDA | Molotov | Freddy* (11 s drum-free tail) |
|---|---|---|---|---|---|---|
| window | 0.1-5.6 s | 0.1-13.4 s | 3.7-8.9 s | 2.8-13.5 s | 3.1-8.9 s | 179-190 s |
| LUFS / crest dB | -16.3 / 13.3 | -13.3 / 15.9 | -19.4 / 17.9 | -22.8 / 14.9 | -14.1 / 12.8 | -10.0 / 11.1 |
| centroid Hz (100 Hz-16 kHz) | 755 | 873 | 961 | 509 | 1090 | 702 |
| rolloff 85 / 95 % Hz | 1480 / 1760 | 810 / 3160 | 910 / 5700 | 790 / 1110 | 2360 / 2740 | 550 / 4470 |
| 4-10 kHz share, dB re window | -49 | -14 | -13 | -33 | -30 | -13 |
| 250 Hz-1 kHz / 1-4 kHz share | -1.4 / -6.1 | -0.6 / -12.1 | -1.9 / -10.9 | -0.4 / -10.9 | -2.2 / -4.3 | -7.0 / -12.8 |
| stereo correlation / side-to-mid dB | 0.25 / -2.2 | -0.39 / +3.6 | 0.54 / -5.2 | 0.63 / -6.4 | -0.31 / +2.8 | 0.71 / -7.7 |
| note rate per s | 1.5 | 2.6 | 3.5 | 2.1 | 3.1 | 3.0 |
| attack (10-90 %) ms, median (5 ms resolution) | 28 | 15 | 15 | 10 | 10 | 10 |
| decay to -20 dB, median ms | n/a (notes overlap) | n/a | 705 | n/a | n/a | 50 |
| note fundamental median (p10-p90) | D4 (276-294 Hz) | C#4 (267-327) | F#3 (147-522) | C#4 (262-349) | B3 (176-311) | D3 (139-172) |
| 2f / 3f / 4f dB re f | -3/-18/-9 | -3/-13/-15 | -25/-24/-32 | -42/-40/-50 | +2/-5/-10 | -7/-7/-13 |
| HF above 10 kHz rms, dBFS | -96 | -46 | -47 | -75 | -85 | -40 |
| stable-partial wobble, cents | n/a | 0 | 1 | 0.4 | 3.7 | 0 |

Whole-mix harmonic bed (above 250 Hz), all eight tracks: centroid 1.0-1.5 kHz, 85 % rolloff 1.2-2.5 kHz, 4 kHz+ share -10..-16 dB re that bed, dominant partial peak median 350-630 Hz (p10 258-352, p90 656-1312). Whole-track side-to-mid: 150 Hz-1 kHz -2..-11 dB, 1-5 kHz -5..-12 dB.

Other measured colour facts: quietest half-second above 10 kHz is -65 to -102 dBFS: **no noise floor, no vinyl or tape bed**; wow/flutter not detectable; no ducking; sustained 2f/3f in melody windows are low (-13..-50 dB) except Molotov/Freddy: little saturation on the melodic bed. Reverb: the tail decay proxy (1-4 kHz harmonic envelope slope) gives T60 about 0.5-1.8 s in the mix (J 0.5, Piove 1.1, Bimbi 1.8, Molotov 1.8, Freddy 1.6, DDA 0.9), but it is confounded by note decay; **treat as upper-bound and low confidence**.

## 5. Per producer (measured facts first, then interpretation)

| | Low Kidd (Piove, DDA, Molotov) | Drillionaire (J, Mezzo, Piove) | Charlie Charles (Bimbi, Bottiglie*) |
|---|---|---|---|
| loudness | -7.1..-8.4 LUFS, crest 9.4-10 | -7.5..-8.4, crest 9.2-9.8 | Bimbi -6.2 LUFS, crest 7.1 (most squashed of the set); Bottiglie -11.3 |
| melodic intro | darkest: centroid 509-1090 Hz, rolloff95 1.1-2.7 kHz, 4-10 kHz share -30..-49 dB | J: centroid 873, rolloff95 3.2 kHz, >4k -14 dB; Piove as left | brightest: Bimbi centroid 961 but rolloff95 5.7 kHz, >4k -13 dB |
| stereo of melody | wide, partly anti-phase (corr -0.31..0.63) | J anti-phase (-0.39, side louder than mid); Piove 0.25 | Bimbi 0.54 |
| note rate / register | 1.5-3.1 notes/s; B3-D4 | 2.6 notes/s (J); C#4 | 3.5 notes/s; F#3, ring 700 ms |
| 808 | median 54-65 Hz; THD -14 (DDA), -6 (Piove), -3 (Molotov); slides 0.7-3.9 per minute (Piove, DDA most) | median 44 Hz in J (deepest), 62-65 in Piove/Mezzo; early pitch drop +49..+76 cents in all three; slides 0.4-0.5 per minute in J/Mezzo | Bimbi: short hits at 55 Hz (808 as kick), decay 50 ms, THD -14 (clean) |
| kick | short hits at 53-60 Hz (DDA, Molotov) or 130 Hz (Piove) | 130-158 Hz body over the 808, J click -0.7 dB (clicky) | Bimbi 55 Hz, click -11 dB |
| hats | mono-ish in Piove, wide in DDA/Molotov; rolls 17 % (DDA) | 1/8 backbone (J 34 %), mono hats | highest roll content (15 % near 1/32 in Bimbi) |

INTERPRETATION (not measured, hedged): Low Kidd's palette reads as dark, low-passed, wide pads or plucks over a deep 808, more atmosphere than hooks. Drillionaire's reads as loud and hard with a clicky kick over a deeper, pitch-dropping 808 and sparse straight hats; the **sliding 808 drill trait is not confirmed**: slides are rare in J and Mezzo Sport. Charlie Charles's Bimbi reads as the most compressed, with short 808-as-kick and a brighter ringing melodic part with fast hat rolls. The measurements cannot say which instrument carries the melodies (piano, bell, choir, pluck): only register, attack and brightness are known. Libero's guide notes call Charlie Charles "melodic piano/bell themes and bounce"; the data here is consistent with ringing bell/key-like timbres in Bimbi (15 ms attack, 700 ms ring) but does not prove it. Freddy Friendly (Kanesh) has a bass-heavy, narrow-melody tail with a wide hat bed: a Machete-style rap reference, not one of the three producers.

## 6. Palette to build (targets)

Every number below is the spread across the measured tracks; aim inside it. Verify each sound with `libero.analysis.features` and compare band shares.

### 6.1 Target kit spec (drums)

| sound | target |
|---|---|
| 808 | fundamental 31-65 Hz median about 55 Hz; tune to the key (B0-C2); early pitch drop 40-75 cents over the first 170 ms then flat; glide 0 by default, player turns it on (slides measured at 0-4 per minute, 1-4 semitones); amp decay to -15 dB 110-220 ms default, long variant 450-600 ms; THD 2f..5f about -6..-9 dB (3f at or above 2f is allowed; clean variant -14 dB); 150-500 Hz content about -5 dB re the sub; mono below 150 Hz (corr 0.98) |
| kick | two variants: (a) body at 125-160 Hz, 80-130 ms to -15 dB, click (1.5-6 kHz) 1-12 dB under the sub, sits above the 808 fundamental; (b) short 808-type hit at 53-60 Hz, 50-110 ms |
| snare/clap | body 270-330 Hz plus 1-3 kHz, spectrum re total about [100-300: -8, 300-1k: -5, 1-3k: -6, 3-8k: -10, 8k+: -17 dB]; length 55-90 ms to -20 dB; tail at 150 ms 20-27 dB down (dry, short plate at most); clap variant with 3-5 micro-onsets in the first 40 ms |
| hat | closed: 15-30 ms to -12 dB, centroid 7-8.6 kHz; open: over 120 ms, 5 % of use; roll intervals 1/8 backbone with some 1/32; velocity variation; hat bed mono-ish (corr 0.95) in one family, wide (0.6-0.77) in another |
| bus | -7.5 LUFS integrated (range -6.2..-8.4), crest 7-10 dB, peak 0 dBFS with 0.1-0.9 % of samples at 0.98 FS: this is limiter territory; ducking of the melodic bed at most 1-2 dB, no pumping; low end (below 150 Hz) about 55-70 % of total energy |
| grid | straight 16ths, no swing offset (within 5 ms); feel comes from rolls, triplet hat bursts and off-grid 808 retriggers, not MPC swing |

### 6.2 Melodic palette

| sound | register | envelope | centroid / brightness | width | space / colour | saturation |
|---|---|---|---|---|---|---|
| dark intro pad/pluck (Low Kidd class) | fundamentals B3-D4 (250-300 Hz), partials to 1-2 kHz | attack 10-30 ms, notes overlap, 1.5-3 notes/s | centroid 500-1100 Hz, 95 % rolloff 1.1-2.7 kHz, 4-10 kHz share -30..-50 dB (low-passed) | decorrelated, corr -0.3..0.6, side up to +3 dB over mid: **check mono fold-down** | none or short; no noise bed | clean (2f/3f under -13 dB) |
| ringing key/bell class (Charlie Charles class) | F#3-A3 with partials to 5 kHz | attack 15 ms, decay 500-700 ms to -20 dB, 3.5 notes/s | centroid about 960 Hz-2 kHz, 95 % rolloff 5-9 kHz, >4k share -13 dB | corr 0.54-0.88, side -5..-12 dB | T60 about 1-1.8 s upper bound; no tape | light: 2f -25 dB |
| hook lead (Drillionaire/J class) | C#4-E4, 2.6-4.7 notes/s | attack 15-50 ms | centroid 0.9-1.5 kHz, rolloff85 0.8-2.2 kHz | anti-phase intro, mono-ish when drums enter | short space | 2f at -3 dB in the intro bed |
| harmonic bed in the full mix | dominant partials 350-630 Hz | n/a | centroid 1.0-1.5 kHz, rolloff85 1.2-2.5 kHz, >4k share -10..-16 dB | side -5..-12 dB (1-5 kHz) | quietest HF (above 10 kHz) -65..-100 dBFS: digital-clean, no vinyl/tape | low |

Missing from the measurements (decide by listening or other sources): instrument identity (piano, bell, choir, strings, flute, vocal chops), percussion loops, reverb pre-delay, tape wow (measured as absent), choir/orchestral stabs.

### 6.3 Concrete mixing targets for Libero

1. Trap bus at -7.5 LUFS, crest 7-10 dB (not the -10 LUFS of the generic hip-hop target).
2. 808 median 55 Hz, mono, THD about -6..-9 dB, early pitch drop of 40-75 cents, 110-220 ms default length, glide 0.
3. Kick body 125-160 Hz above the 808 (variant a) or a short 808-type hit (variant b); click 1-12 dB under the sub.
4. Snare/clap 55-90 ms, dry, 150 ms tail at -20..-27 dB, body 270-330 Hz.
5. Closed hats 15-30 ms, centroid 7-8.6 kHz, open hats about 5 %, rolls at 1/32 on 6-17 % of intervals.
6. No swing, no sidechain pump (at most 2 dB), no noise bed or tape wow.
7. Dark wide pad/pluck with centroid 500-1100 Hz and 95 % rolloff 1.1-2.7 kHz; alternative ringing bell/key with 700 ms ring and rolloff95 5-9 kHz.
8. Melody register centred on F#3-E4 (185-330 Hz fundamentals), harmonic bed centroid 1.0-1.5 kHz.
