# How professional sample libraries are made and played

Research note for Libero. Goal: understand what separates a Kontakt-class
sampled instrument from a "synthetic-sounding" one, and turn it into concrete
engine, bundle-format and recipe-tooling work.

Conventions used below:

- `[Sn]` points to the source list at the end. A claim with no tag is an
  inference or engineering judgement made for this document, not something a
  source states.
- "Library developers" here means the commercial makers named in the brief.
  Most of them publish marketing and manuals, not recipes, so several numbers
  below are taken from product specs and manuals rather than from interviews.
- Some forum pages (VI-Control, Gearspace) could not be fetched directly; where
  they are cited, the claim comes from the search excerpt and is marked
  `(excerpt)`.
- The Libero engine is described as in `SPEC.md` (four layers, takes, velocity
  zones, mono/legato crossfade, live effects). The C++ was not audited.

---------------------------------------------------------------------------

## 0. The short version

A convincing sampled instrument is not "good samples". It is a **performance
model** built out of samples. Five things carry most of the realism:

1. **Dynamics are timbre, not volume.** Each dynamic level is a separate
   recording with its own spectrum, and the engine moves between them
   continuously (CC crossfade), not with a volume knob. [S1][S3][S23]
2. **Nothing repeats exactly.** Round robins (RR), non-repeating random choice,
   tiny timing/tuning/level jitter, and "start of the note" looseness. [S1][S22][S24]
3. **Note endings and note joins are recorded too.** Release samples chosen by
   how long/hard the note was played, legato transitions, repetition samples,
   key/pedal/mechanical noise. [S1][S6][S26][S28]
4. **Space is a mix of real perspectives**, phase-aligned, not one wet file
   with reverb on top. [S1][S2][S7][S38]
5. **The editing is invisible and exact**: true-onset trimming on a grid, fixed
   gain across layers, tuning per note, long loops or no loops. [S3][S5][S11][S37]

A cheap library usually fails on (1)-(3) even when the raw recordings are good
(section 6).

---------------------------------------------------------------------------

## 1. Recording and editing

### 1.1 Mic positions and how they are mixed live

- Spitfire's orchestral libraries ship several "perspectives" of the same
  performance and expose a mixer: **Close** (valve mics near the players),
  **Tree** (a Decca tree of three Neumann M50 above the conductor, the default
  that loads), **Outriggers** (wide, between tree and ambient in character),
  **Ambient** (high in the hall, big stereo spread and room), plus extended
  sets: Gallery, close ribbons, leader spot, a low stereo pair. [S1][S2]
- The Studio Orchestra edition was deliberately recorded in a *dry* room so
  the user controls reverb; the tree 1 position is the only one in the core
  edition, the rest are paid extras. [S2]
- Orchestral Tools Berlin: Close, Decca Tree, Surround, A/B, plus ORTF and
  spot mics in brass; horns get a stereo pair in front and one behind the
  bells; first violins have a mono concertmaster spot. Each can be routed to a
  separate stereo output. [S7][S8]
- Cinesamples: Close/Room/Surround/Mixed for strings, harps; Close/Mid/Far on
  snares; piano sold as four "characters" from mic and mix choices. [S43]
- Piano libraries: audience vs player perspective, close vs ambient rigs
  mixable live [S6]; True Keys offers Close, Player, Side (ribbon) and Mix. [S26]
- The user-facing effect: a *drier* mix reads as nearer, a wetter one as
  farther. [S3] Mixing perspectives is how one recording gets several depths
  without extra sampling.
- **Phase coherence between mics is treated as standard** in professional
  libraries: close mics are delay-compensated so events line up with the distant
  mics, otherwise mixing them combs. Some engineers leave a few samples of
  offset on the close mic to preserve depth. [S38 (excerpt)][SOS multi-mic: S38b]
- Libraries commonly record at **one fixed gain** for the whole session so
  instruments and layers keep their true relative levels (Berlin: same gain for
  all instruments so mod-wheel dynamics balance; VSL: "fixed gain" editing so
  all pitches/layers/articulations match). [S9][S28]

### 1.2 Sample editing

- **Trim to the true onset, on a grid.** Record to a grid so waveforms start on
  regular increments; cut each sample exactly at the start of the waveform, add
  a very short fade-in to avoid clicks. [S3][S15][S14]
- Spitfire cut strings "from the true beginning of the note, as the bow engages
  the string". The result is laggy/irregular latency that feels human, so the
  engine has a **Tightness** control (CC18) that cuts further into the note;
  users then compensate with a negative track delay. [S1]
- **Phase/start alignment across velocity layers** matters because layers are
  crossfaded; without aligned starts/periods a mid-fade sounds hollow or
  chorused (`(excerpt)`; high-end developers "use proprietary phase-alignment
  tools"). [S23][S36]
- **Tuning** is corrected per note. Salamander Piano (Accurate-Salamander
  remaster): all 88 notes individually retuned by a professional tuner; the
  SFZ format limits fine tune to 1 cent resolution, which is still enough. [S11]
- **Noise**: record a "wild track" of room silence for noise reduction later
  [S12]; spectral repair of single bad notes using neighbours (F#1, C3 in
  Salamander), removal of non-piano vibration, narrow-band notches for bad
  overtones, all in floating point. [S11] Breathing/fans matter because noise
  from many overlapping voices accumulates. [S14]
- **Release samples are cleaned and level-normalised separately** (Salamander
  6.2: almost all noise removed, release levels balanced). [S11]
- **Normalisation vs natural dynamics.** Many commercial libraries do *not*
  peak-normalise per sample, to preserve relative levels; level matching is done
  by measuring each layer relative to the loudest layer of that key, since a
  pp-to-ff spread can be 30-40 dB. `(excerpt)` [S37] Another school normalises
  the loudest and scales the rest by RMS. Either way the rule is: *one policy,
  applied to the ladder, never per-file peak normalisation*.
- Even playing technique per note when recording: uneven velocities produce
  notes that jump in loudness up the keyboard. [S4]
- Naming/batching: record all velocities of one note consecutively, speak the
  note name, split by region, batch-export with note+layer in the file name. [S15][S12]

### 1.3 Looping vs long samples, loops and crossfades

- Long articulations are conventionally **attack + looped sustain + release**.
  [S51 (excerpt)] Looping saves RAM, disk streaming and keeps polyphony stable,
  which is why it survived cheap storage. [S4]
- Loop points snap to **zero crossings**; a crossfade loop (fade-out of the loop
  end while fading in the loop start) hides a difficult join. [S5]
- **Loops should be long.** One SOS author takes ~5 s samples and makes ~4 s
  loops; short loops "cycle" audibly unless the envelope hides them. [S5]
- Automatic loop finders use zero-crossing search plus spectral similarity and
  correlation of the two loop ends, then crossfade. [S48 (excerpt)]
- A minority of modern libraries skip looping: Benjamin Wallfisch Strings sells
  ~20 s **unlooped** sustains (with independent up/down bow samples) as a
  feature. [S49 (excerpt)]
- Practical budget rule from Pianobook: record the low notes for about 18 s and
  the top notes about 6 s, because that is how long they take to decay. [S12]
  File length should follow the real decay per register, not a fixed length.
- Crossfading two *correlated* loop halves needs a linear (amplitude-summing)
  law; equal-power is for *uncorrelated* material (see 3.1). [S36]

---------------------------------------------------------------------------

## 2. Mapping

### 2.1 Key zones: every note vs spaced roots, and transposition limits

- Classic rule: sample **every minor third** (every 3 semitones), so no sample
  is moved more than one semitone; about one-third of the memory of sampling
  every note. [S4]
- Earlier SOS guidance: same sample over 3-4 semitones is "accurate enough even
  for the most critical instruments"; larger spreads sound unnatural. [S4]
- Transposition quality depends on the interpolator. Linear interpolation gives
  "metallic mush" when transposed far; 8-point windowed sinc tolerates more. [S4]
- Spread examples: Salamander Piano is sampled in **minor thirds** with 16
  velocity layers and pitch-shifts the gaps; its hammer-noise releases are
  chromatic, string-resonance releases in minor thirds over 3 layers. [S10]
  Pianobook's minimal recipe: **cycle of fifths** (every 7 semitones), pedal
  down, two velocity layers, plus release triggers. [S12][S13]
  Heavy libraries (Vienna Imperial, True Keys, Keyscape) sample every key. [S6][S26][S27]
- Complex sources (e.g. full mixes) stretch/shift poorly: low end is smooth,
  mids/highs break, transients double ("flam"). [S5] Formants move with pitch:
  voice and wind samples sound like "the wrong size of mouth" when moved far,
  which is why choir libraries use vowel/syllable sets with formant shifting
  only for small gaps. [S45 (excerpt)]
- Sizes: Berlin Strings 229 GB, Brass 387 GB, Woodwinds 187 GB, Percussion
  195 GB (installed). [S44 (excerpt)] This is the scale the brief's "Kontakt-class"
  refers to; Libero's agent-built bundles must reach the *perceptual* result
  with orders of magnitude less.

### 2.2 Velocity layers and round robins by family (sourced numbers)

| family | layers / RR / notes | source |
|---|---|---|
| Piano, sampled | 10 (Soundiron, Ivory, Akoustik) to 12 (Blüthner, Keyscape-class up to 32) to 16 (Salamander), 18 (EastWest), 19 incl. "silent strike" (True Keys, ~50k samples over 3 pianos), up to 100 (Vienna Imperial). RR matter less than layers on piano. | [S6][S10][S26][S27][S15] |
| Piano, minimal | 2 layers, every 7th semitone, release triggers | [S12] |
| Strings, sustained | 2-4 dynamic layers for long articulations; 4 legato velocity layers in Berlin Strings | [S7][S44] |
| Strings, shorts | 6 RR at 3-4 dynamic layers (Spitfire spiccato); Berlin shorts sometimes >20 RR | [S1][S44] |
| Woodwinds | true legato with 3 dynamic crossfade layers; staccato 8 RR; VSL Synchron: 8 dynamic levels, up to 10 variations | [S44][S28] |
| Brass | 3-4 dynamic levels per articulation (solo horns 4, trumpet/trombone 3); several real players supply natural variation | [S8] |
| Plucked/guitar | 3 dynamics x 4 RR per articulation plus slide/hammer-on/pull-off legato samples | [S42] |
| Drums/percussion | velocity layers + ~6 RR per component (Superior Drummer); BFD fakes RR by using neighbouring velocities; 100+ layer expansions exist | [S54 (excerpt)] |
| Tuned percussion (Kontakt tutorial) | 3 velocity layers x 4 RR as a teaching example | [S47] |
| Starter recipe | "5 velocity levels, 2 RR" | [S14] |

- RR guidance: 4 RR at a fast 16th-note tempo returns to the first sample in
  about 0.4 s, which is audible; 6-8 RR push the return past ~1 s. [S22]
  Different players/instruments also count as variation. [S8]
- **Velocity mapping is ranges of the 1-127 axis**; one teaching split is
  pp 0-19, p 20-39, mp 40-59, mf 60-79, f 80-99, ff 100-127. [S14]

### 2.3 Zones, exclusive groups, sequences (what the open formats expose)

SFZ (the de-facto open spec) already models most of what a serious engine
needs, and Decent Sampler mirrors much of it; useful as a checklist:

- Loops and crossfade: `loop_mode`, `loop_start`, `loop_crossfade`. [S18][S19]
- Release triggers: `trigger=release`, `rt_decay` (dB of attenuation per second
  of how long the key was held; ~10-15 dB/s for piano treble, less for bass),
  `rt_dead` (skip the release sample if the attack has already ended). [S16][S18]
- Round robin: `seq_length`/`seq_position`, or `lorand`/`hirand` random
  ranges; Decent Sampler `seqMode` = round_robin | random | true_random | always. [S18][S19]
- CC crossfades on any controller: `xfin_loccN`, `xfout_loccN`. [S18]
- Mute groups: `group`/`off_by`; Decent Sampler `tags` + `silencedByTags`
  with `silencingMode` fast/normal. [S18][S19]
- Legato (DS): `trigger="first"` (only when nothing else sounds),
  `trigger="legato"`, `previousNote`, `legatoInterval`, three-group structure
  (initial sustain, transition, sustain tail), `<tags polyphony="1">`. [S20]
- Keyswitches: `sw_last`, `sw_previous`. [S18]
- Randomisation: `offset_random` (start-point randomisation, used against phase
  alignment of layered copies and to vary loop entry; needs a tiny attack to
  avoid clicks), `pitch_random`, `amp_random`, `delay_random`. [S17]
- Per-sample/group: `ampVelTrack`, `tuning`, `loVel/hiVel`, `start/end`,
  `releaseTriggerDecay`, `delay`, `playbackMode` memory|disk_streaming. [S19]

---------------------------------------------------------------------------

## 3. The playback engine: what makes it "play" like an instrument

### 3.1 Dynamics crossfade on a CC vs velocity

- Almost every big library routes **CC1 (mod wheel)** to a *dynamics* crossfade
  between recorded layers; CC11 is an expression volume on top. Velocity is
  then used for note *character* (attack type) and for shorts. [S23][S1][S3]
- Spitfire's manual calls Dynamics "probably the most important controller";
  Vibrato (CC21) crossfades senza-to-molto vibrato, Release (CC17) sets how much
  release trigger, Tightness (CC18), Speed (CC16), Intensity (CC15). There is a
  "CC mapped velocity" option that lets the dynamics slider also set velocity. [S1]
- The known weakness is **phase cancellation in the overlap zone**, mitigated by
  phase-aligned recording/editing; cheap libraries let it show (`(excerpt)`). [S23]
- Crossfade law: equal-power (cos/sin, -3 dB at the midpoint) for uncorrelated
  layers; for highly correlated layers the midpoint should approach -6 dB
  (linear) to avoid a bump. Dynamic layers of one note are partially
  correlated, so the law sits between the two. [S36]
- Another approach: overlap two layers across the whole 0-127 range and
  modulate each layer's *amplitude* with the controller; or morph spectrum
  between layers while the note sounds (Kontakt AET filters). `(excerpt)` [S23]

### 3.2 True legato, portamento, repetition, rebow

- "Legato" in library speak = any recorded *transition* between two notes
  (slur, rebow, portamento). Two implementation styles: sustain + transition
  that flows into the next sustain, or sustain / transition-only / sustain with
  a scripted crossfade. `(excerpt)` [S39]
- The engine is monophonic per line: holding note A while pressing B triggers a
  transition from the *interval* (A to B). [S1]
- Spitfire Performance Legato patches pick the transition from **speed and
  velocity** of the new note: slow playing: vel 1-19 portamento, 20-84 fingered
  slur, 85-127 bowed; faster: fingered fast / accented; very fast: "runs". Attack
  of the first note is controlled by velocity (1-9 smooth). [S1]
- Berlin: transitions for every interval up to 12 semitones up and down, three
  types (slurred / agile / fast runs) selected by playing speed; Berlin Brass
  adds re-tongued vs slurred legato (CC52). [S7][S8]
- VSL: every interval from minor second to octave, up and down (24 variants per
  note), fixed-gain so that blocks join; "Performance Tool" chains them;
  repetition samples with up to nine repeats and three dynamic layers; Bösendorfer
  uses special repetition samples for the change in sound when a still-vibrating
  string is re-struck. [S28][S6]
- Legato speed/intensity/release-blur controls exist *because* recorded
  transitions are laggy by nature; libraries give a knob to trade realism for
  response. [S1]
- Kontakt's factory "Unisono-Portamento" distinguishes Mono ("always retrigger"),
  Legato (no new sample), and Offset (new sample starting where the held note
  was); portamento "Auto" applies only to legato-played notes; "Relative" scales
  glide time with interval size; legato-velocity compression keeps legato notes
  near the first velocity. [S21]

### 3.3 Release samples

- A release sample is what the room/instrument does after the note: room decay,
  damper noise, resonance. Volume and choice depend on **velocity** and on
  **how long the note was held** (a struck piano note that has decayed has no
  sympathetic bloom to release). [S6][S26]
- Kontakt scripts read note duration and scale release volume; SFZ does it with
  `rt_decay` dB/s. `rt_dead` drops the release if the attack has ended. [S16][S18]
- True Keys ships "thousands" of release samples including staccato trails
  responding to velocity and time. [S26]
- Short articulations can switch their release trigger off to tighten a
  staccato (Spitfire "Short Articulations RT"). [S1]
- Release samples are cleaned and balanced separately from sustains. [S11]

### 3.4 Mechanical / pedal / key noises, sympathetic resonance, una corda

- Keyscape models mechanical, pedal and release noise as separate behaviour; up
  to 32 velocity layers with multiple RR; it deliberately keeps "noise,
  imperfection and quirks". [S27]
- The Grand 2 gives hammer release, key action, damper and pedal noises as
  independent mixable elements. [S6]
- True Keys: pedal-down resonance, sympathetic resonance, re-pedal, sample-based
  half pedal, sostenuto, pedal noise responding to pedal speed, separate
  una-corda samples (the hammers strike fewer strings and a different felt
  area, so the tone changes, not only the level). [S26]
- Sympathetic resonance comes in three flavours: separate pedal-up/down
  recordings; dry strings + synthetic resonance; or convolution of measured
  string-to-string transfer. Ivory uses modelling for resonance. [S6][S55 (excerpt)]
  Salamander fakes damper resonance with detuned copies and calibrates half-pedal
  against a Disklavier. [S11]
- Guitar: Orange Tree Evolution adds a string-resonance engine and
  slide/hammer-on/pull-off samples; it combines sampling with physical-model
  scripting. [S42]

### 3.5 Humanisation, tightness, non-repeating RR

- Kontakt's Humanizer randomises note-on/off timing (0-100 ms), velocity (up to
  +/-64), tuning (up to +/-1 semitone), volume (up to +/-6 dB), pan. [S21]
  Those are *maxima*; realistic use is far smaller (see 3.6).
- Non-repeating random RR with a modulo trick (pick any index except the last,
  no loops) with **reset after silence** and to avoid a short audible cycle. [S24][S25]
- Spitfire exposes RR reset (from a key, or on transport start) so a render is
  reproducible, "neighbouring zones" RR (pull from adjacent notes: an 8-RR
  instrument effectively gives 24 variants) and "layer 2x RR" for thicker
  sound at -6 dB. [S1]
- Practical jitter from a mockup guide: 3-6 ms random timing after quantising,
  10-20 % note-length variation on repeated shorts, velocity spread >= 20
  points, and listen whether velocity 40 vs 110 changes *timbre* or only
  volume. [S22]
- `offset_random` and `pitch_random` exist for exactly this. [S17]

### 3.6 Key practical numbers for micro-variation (judgement, guided by S21/S22)

| parameter | subtle | strong |
|---|---|---|
| timing | 0-4 ms | 10-20 ms (sloppy ensemble) |
| tuning | +/-2-5 cents | +/-10-15 cents (ensemble/folk) |
| level | +/-0.5 dB | +/-1.5 dB |
| sample start offset | 0-3 ms (aperiodic transients only) | |
| velocity | +/-3-6 | |

### 3.7 Articulations, keyswitches, tails, voice stealing, body/room convolution

- Articulations are separate patches/groups (Spitfire strings: 46 articulations
  per section in Studio Strings Core, 175 in Mural-class; Berlin: 10+ families),
  switched by keyswitch/UACC CC/velocity/CC range; some engines allow layered
  polyphonic keyswitching (Berlin Brass, up to 4 layered). [S1][S2][S8]
- **Voice stealing**: steal idle voices first, then releasing ones, then held;
  allow a few voices beyond the limit and fade stolen voices over ~5-10 ms;
  clip-edge ramps of 1-3 ms at region ends avoid clicks. [S40 (excerpt)]
- **Convolution**: Chris Hein libraries use two convolution stages: a very short
  **Body** IR to change apparent instrument size/shape and add realism to dry
  recordings, and a **Room** IR. [S41 (excerpt)] Piano libraries use convolution
  to simulate resonances. [S6]
- Stereo width/perspective per mic, surround routing, purge of unused
  articulations to save memory. [S1][S7]

---------------------------------------------------------------------------

## 4. Hybrid / design-oriented libraries

- **Heavyocity**: sources are a mix of orchestral performance (a 12-piece
  string section doing glissandi/atonal slides), ring-modulated synths,
  industrial/mechanical recordings and field recordings, then "devastating
  processing": distortion, digital destruction, reverbs (23 IRs in Gravity),
  compression/saturation. [S29] Gear named for Symphonic Destruction: API
  consoles, Thermionic Culture Vulture, modular rigs, Metasonix, Black Box
  HG-2. [S30 (excerpt)]
- **Architecture, not just samples**: Gravity presets are four layers,
  **Sub, Impact, Tail, Whoosh**, with a motion sequencer, arpeggiator, a
  one-knob "Punish" (compression + saturation + distortion chain), trigger FX
  and a "Twist" phase effect. The Designer engines let the user layer up to
  three source samples from tonal categories (Traditional/Hybrid/Damaged) and
  sequence/process them live. [S29][S30]
- Note how closely Gravity's four layers mirror Libero's attack/body/tail/air:
  the layer idea is already right; what is missing is the *quality of each
  layer's content* and **one-knob macros** that change many things at once.
- **Spitfire LABS / Originals**: archived recordings turned into big textures
  by granular synthesis; washed, saturated synth sounds run through degraded
  tape machines (Sony Walkman, Library of Congress C1 cassette, Tascam), pedals
  and vintage delay chips; results pitch-shifted, tape-spliced, filtered,
  distorted; over 150 layers of tape/granular processing on some instruments. [S31 (excerpt)]
- **Omnisphere**: two layers A/B each with sample or synth oscillator; granular
  engine (smaller grains = more abstract), user audio import, harmonia
  oscillators with FM/ring mod, polyphonic LFO/envelopes; "Composite Morphing"
  morphs harmonic character of one instrument into another; sounds built from
  exotic acoustic sources (e.g. an amplified lightbulb filament). The designer's
  stated principle: use audio as a waveform, then granular, waveshaping, FX
  "to turn your audio into new sounds". [S32][S33]
- **Extreme stretch textures** (Paulstretch family): overlapping FFT windows,
  magnitude kept, **phase randomised**, inverse FFT and overlap-add with a slowed
  read position; window size sets smear; transients smear, so reset at onsets
  and pick "rich but not too busy" sources; treat it as a *source* you then
  record, cut and layer like any sample. [S34]
- **Concatenative (corpus-based) synthesis**: segment a corpus into note/grain/
  beat units, describe each by descriptors (pitch, loudness, brightness,
  noisiness), pick units nearest target descriptors by weighted Euclidean
  distance, concatenate with transformation. Relevant to Libero because the
  agent *is* a unit selector: it can pick, from a pile of sounds, the units
  whose descriptors fit a velocity/pitch ladder. [S35]

---------------------------------------------------------------------------

## 5. Why cheap libraries sound cheap, and the fix for each

| symptom | cause | fix (professional practice) | source |
|---|---|---|---|
| Machine-gun repeats | 1-2 samples per note, cycled | 6-8 RR, non-repeating random, reset logic, tiny timing/tuning/level jitter, start offset | [S22][S24] |
| Dynamics = volume knob | velocity only scales amplitude | distinct recorded layers with different spectra; CC crossfade; 3-4 layers minimum for sustains, 8+ for hero instruments | [S1][S3][S22] |
| Audible layer switching | hard velocity splits | crossfade between phase-aligned layers | [S23][S36] |
| Uneven keyboard | level inconsistency, uneven technique, per-file normalising | fixed-gain recording; level ladder measured; even playing | [S4][S9][S37] |
| Pitch-shift "chipmunk" | roots spread too far, poor interpolation | roots every 3 semitones max for acoustic, sinc interpolation, per-note tuning | [S4][S11] |
| Loop "warble" | short loop, poor join | long loops, zero-crossing+correlation search, crossfade, or unlooped long samples | [S5][S48][S49] |
| Notes end abruptly / all the same | no release samples | release layer chosen by velocity and held time | [S6][S16][S26] |
| Notes join like separate notes | no legato | interval-based recorded transitions, speed classes, portamento | [S1][S7][S28] |
| Lifeless room | one baked reverb, or none | several phase-aligned mics + convolution room/body, dry option | [S1][S2][S41] |
| Sterile | edited too clean | keep real mechanical noise, pedal, key, breath; noise floor consistent | [S27][S26] |
| Piano does not "bloom" | no sympathetic resonance | resonance samples/model, pedal-down states | [S6][S26] |
| Late or rigid starts | everything cut to the transient | cut at true onset, expose tightness, allow jitter | [S1] |
| Clicks, pumping | unmatched noise floor between layers, hard ends, voice steal | fades at edges, consistent noise bed, fast-fade steal | [S12][S40] |

---------------------------------------------------------------------------

## 6. What Libero is, relative to this (from SPEC.md)

Libero already has, in concept: 4 layers (attack/body/tail/air), round-robin
takes (non-repeating, seeded), velocity zones in the manifest, a loop field with
crossfade, mono/legato mode with a phase-aligned ~30 ms body crossfade, a
resonator (sympathetic comb strings), tape/echo/reverb incl. convolution
"Impronta", and compile-time rendering. The velocity axis is a *range of zones
plus an amplitude curve* (`vel_sens`), not a continuous timbre crossfade; the
tail plays "on note-off" without a dependence on held time; there is one
stereo image per zone (no perspectives); there are no recorded transitions.
Because sounds are generated by an agent from synthesis and found samples, the
cheapest path to "Kontakt class" is to **bake the expensive realism into the
compile step** (more zones, aligned, calibrated, linted) and let the engine
do the cheap continuous morphing.

---------------------------------------------------------------------------

## 7. What Libero should adopt

Ratings: **effort** S (days or less) / M (about a week) / L (multi-week);
**gain** = expected improvement of perceived realism for a typical sound
(low / medium / high / very high). Order is by gain per effort.

### 7.1 Engine features (plugin + `libero-render`)

| # | feature | why (evidence) | effort | gain |
|---|---|---|---|---|
| E1 | **Dynamics axis**: a live `dynamics` parameter (CC1, default follows velocity) that crossfades between velocity zones continuously; velocity sets attack character and initial position; equal-power/linear blend by measured correlation; optional "velocity-locked" mode | S1, S3, S23. Replaces hard zone switching, the single biggest audible tell | M | very high |
| E2 | **Release-by-duration and velocity**: tail zones get `rt_decay_db_per_s`, `rt_dead`, and held-time bins (short / medium / long tail takes); release level scales with velocity; optional off for shorts | S16, S6, S26, S1 | S | high |
| E3 | **Micro-humanise block** (per note, seeded): timing 0-10 ms, tuning +/-0-10 c, level +/-0-2 dB, start offset (aperiodic only); macro `Umano` 0..1 | S21, S22, S17 | S | high |
| E4 | **RR hygiene**: never-same-twice (already), reset-after-silence, "neighbouring zones" RR (draw takes from adjacent roots) and a repeated-note counter that swaps to a *repetition* take set | S1, S24, S28 | S | high for plucked/percussion |
| E5 | **Mechanical-noise layer** (`mech`): zones triggered on key-down, key-up, pedal, legato-join, re-strike; velocity-scaled; own level knob | S27, S26, S6 | M | high (acoustic) |
| E6 | **Perspective (mic) layers** in the bundle: `mics: [close, mid, far, room]`, each a full set of zones (or a derived stereo file), a 4-fader mixer, phase-aligned, cheap sum of files | S1, S2, S7, S43 | M | high (space realism; disk cost x N) |
| E7 | **Legato transitions**: `legato` zones keyed by (from-interval up/down up to 12, speed class), `trigger: legato`, crossfade into the sustain; controls Speed/Intensity/Release-blur; fallback = current crossfade | S1, S7, S20, S28 | L | very high for bowed/wind/voice, low for plucked |
| E8 | **Sympathetic/pedal model**: per-note resonance sample set or modal bank, pedal (CC64) + repedal + half-pedal; "una corda" as an alternate zone set | S26, S6, S11 | M | high for piano/harp/zither |
| E9 | **Voice management**: prefer stealing idle, then releasing, then held; 5-10 ms stolen-voice fade; 1-3 ms clip-edge ramps; soft limit of voices+N | S40 | S | medium |
| E10 | **Interpolation quality**: >= 8-point windowed sinc (and a formant-preserving option for vocal/wind `formant: true` zones) for pitch zones | S4 | S-M | medium |
| E11 | **Tightness**: live `tight` ms cut of the zone start, plus bundle `onset_offset` so every zone records its true-onset position | S1 | S | medium |
| E12 | **Articulation sets**: bundle `articulations: [{name, layers..., ks}]` switched by keyswitch / CC / velocity split; recipe decorator `@sound.articulation` | S1, S2, S8 | L | high (playability) |
| E13 | **Loop playback upgrade**: per-voice random loop entry (`offset_random` style), optional two-loop alternation with crossfade, `loop_sustain` only while held | S17, S5 | S | medium |
| E14 | **Body convolution** slot (short IR, before reverb) next to "Impronta"; bundle may ship `body.wav` | S41 | S | medium |
| E15 | **Macro knobs** ("Punish", "Aria", "Umano"): one control driving several params for design-class sounds | S29 | S | medium (modern design) |

### 7.2 Bundle-format extensions (`libero.bundle/2`, backward compatible)

Additive fields only, old bundles keep working (missing = today's behaviour):

```jsonc
"zones": [{ ...,
  "dyn": [0.0, 0.33],            // E1 position on the dynamics axis (replaces hard vel_lo/hi when present)
  "onset": 312,                  // true onset in samples inside the file (E11)
  "gain_db": -3.1,               // measured ladder gain, not peak-normalised (see R2)
  "tune_cents": -4.2,            // per-zone residual, applied live (R5)
  "mic": "close",                // E6
  "rt": {"decay_db_s": 12, "dead": true, "held_ms": [0, 400]}, // E2 (tail zones)
  "trigger": "attack|release|legato|keydown|keyup|pedal_down|pedal_up", // E5, E7
  "legato": {"interval": [-12, 12], "speed": "slow|agile|fast"},        // E7
  "articulation": "sustain",     // E12
  "formant": true                // E10
}],
"mics": ["close", "mid", "far"],
"humanize": {"timing_ms": 3, "cents": 4, "db": 0.6},   // defaults for E3
"pedal": {"resonance": "res_pedal.wav"},               // E8
"body_ir": "body.wav",                                 // E14
"meta": {"calibration": {"ladder_db": [-24, -15, -7, 0]}}  // what the tooling measured, for lint and UI
```

Keep the four-layer model as the top-level grouping; `mech` becomes a fifth
layer name. Keep WAV float32 for authoring, but add an optional **24-bit or
FLAC** packing for shipped bundles (about 2-4x smaller) `[S12]`; budget by real
decay time per register, not a fixed length (see R8).

### 7.3 Recipe and tooling functions for the agent

The constraint is agent time and tokens. Prefer **one call that does a whole
disciplined operation**, and a **lint that tells the agent what is wrong**
instead of making it listen and guess.

| # | function (Python `libero`) | what it does | effort | gain |
|---|---|---|---|---|
| R1 | `Audio.onset_trim(pre_ms=2, detect="energy|hf|xcorr")` and `align_to(reference, max_ms=3, sub_sample=True)` | cut to true onset on a known pre-roll; cross-correlate each layer/take against a reference in the same zone ladder so periods line up (needed for E1) | S | high |
| R2 | `ladder.calibrate(zones, policy="fixed-gain|rms-to-top", target_spread_db=[...])` | measures each layer against the loudest of that key, stores `gain_db`; no per-file peak normalisation; enforces monotonic level *and* monotonic brightness | S | high |
| R3 | `Audio.loop_find(min_s=2, xfade="auto", method="zerox+xcorr+spectral")` (exists as `loop_points`; upgrade) | long loops (>= 2-4 s), equal-power vs linear by measured correlation, returns a click/variance score | S-M | medium |
| R4 | `Audio.denoise(profile=room_tone)` + `noise_bed(match=zones)` | spectral gate from a noise print; re-add one shared noise bed so the floor is identical across layers | S-M | medium |
| R5 | `Audio.tune_to(note, method="partials", report=True)` (exists) + `zone.tune_cents` output | use harmonic-centroid pitch across the steady part, not just YIN; write residual for live correction; flag stretched-partial sources | S | medium |
| R6 | `layers.morph(a, b, n)` | generate in-between velocity layers by spectral-envelope interpolation between two real layers (Omnisphere-style composite morphing idea, S32); lets the agent deliver 5-8 layers from 2-3 sources; must be phase-aligned before morphing | M-L | high |
| R7 | `Audio.release_from(body, decay="room|damper|bloom")` | synthesises a release sample from the body's own tail + damper/room noise for when no real one exists; parameters for `rt` | S | high |
| R8 | `budget(sound)` | reports size = notes x layers x RR x mics x length and suggests root spacing / lengths from register decay (Pianobook 18 s bass / 6 s treble, S12) | S | medium |
| R9 | `freeze(audio, window=, stretch=)`, `granular(audio, grain=, jitter=, reverse_p=)`, `swell(audio, reverse=True)`, `tape(audio, wow=, flutter=, sat=, age=)` | offline design tools from S31-S34: stretched pads, reversed swells before the attack, granular clouds, resampled-through-tape | S-M | high (hybrid) |
| R10 | `libero lint <sound>` | automatic QA (see 7.4) printing a short fail list | M | very high (agent productivity) |
| R11 | `sound.family("plucked|bowed|wind|brass|mallet|percussion|voice|pad|hybrid", quality="fast|slow")` | sets roots / velocities / takes / rt / humanize / loop defaults from the table in 7.5; the agent only supplies the source and overrides | S | high |
| R12 | `pick_units(pool, targets)` | concatenative selection (S35): given a pool of slices, compute descriptors (pitch, loudness, centroid, noisiness) and assign the best unit to each (note, layer) slot instead of the agent eyeballing | M | medium-high |
| R13 | `legato.render(note_a, note_b, style="slur|portamento|rebow")` | offline transition synthesis for synthetic/plucked-bowed sources: end of A + start of B with phase-aligned splice and a pitch glide; used when no recorded transitions exist | M-L | medium |
| R14 | `mics.derive(zone, ["close","mid","far"], irs=[...])` | when only one mic exists, derive perspectives by IR + level + delay (time-aligned, close = nearest) | S | medium |

### 7.4 What `libero lint` should check (cheap, objective)

1. Onset error across layers/takes of a zone: < 1 ms after alignment.
2. Level ladder: monotonic, step sizes within 2-8 dB; per-note spread at equal
   layer within 2 dB across the keyboard.
3. Brightness ladder (spectral centroid or energy > 4 kHz) strictly rising with
   layer: if flat, the layers are the same sound at different volume.
4. Crossfade test: render a dynamics sweep on one key and measure comb/phase
   dips (correlation between adjacent layers in the first 200 ms > 0.6 after
   alignment).
5. Take distinctness: adjacent takes neither identical (corr > 0.98) nor
   different in level/pitch beyond tolerance; minimum RR count per family.
6. Loop: seam discontinuity and RMS/centroid drift across the loop; loop length
   >= 2 s for pitched sustains.
7. Tuning: per-zone residual after `tune_cents`; flag > 10 cents.
8. Noise floor consistency across zones (within 3 dB), DC, clipping, tail
   truncation above -60 dB.
9. Release: present where the family expects it; decays match `rt`.
10. Coverage: no key > 3 semitones from a root for acoustic families (> 4-7 for
    synthetic), no velocity gaps.
11. Machine-gun test: render 16 repeated notes at fixed velocity and report the
    longest exact-repeat interval.

### 7.5 Per-instrument-family recipes (defaults for `sound.family`)

"Fast" = sketch budget; "Slow" = worth-keeping budget. Zones = notes x layers
x takes (before mics). Counts follow the sourced practice above, reduced for an
agent pipeline; every `slow` value is within what a human-edited library of the
same size would do.

| family | root spacing | velocity/dynamic layers | RR | articulations | loop / length | release | other |
|---|---|---|---|---|---|---|---|
| **Piano / keyed, struck strings** | fast: every 7 st; slow: every 3 st (every key for hero) | fast 3, slow 6-10, morph (R6) fills the rest | 1-2 (layers matter more, S15) | sustain pedal down/up, una corda (slow) | unlooped; length by register (bass ~18 s, treble ~6 s) | release layer chromatic hammer/damper + resonance (S10), `rt_decay` 10-15 dB/s treble | pedal noise, key noise, sympathetic resonance (E8), mics close + mid + far |
| **Plucked (harp, guitar, lyre, harpsichord)** | fast: 5-7 st; slow: 3 st | fast 2, slow 3-4 | 4-6 | open, muted, harmonic (slow) | unlooped, 3-6 s | short release, string-noise release, slide/hammer-on legato (S42) | fret/finger noise, resonator Corde |
| **Mallet / tuned percussion** | 3-4 st | 3-5 | 4-6 | hard/soft mallet, dampened | unlooped | damper choke; optional release | velocity = brightness (mallet hardness) |
| **Bowed strings** | 3 st | 3-4 dynamic (S7, S44) for long; 2-3 for shorts | shorts 6+ (S1); long 2 | sustain, spiccato, pizz, tremolo, harmonics; legato transitions (S1) | long loops >= 3 s with crossfade, or 8-20 s unlooped (S49) | light release trigger for long; RT off for stac. | vibrato crossfade (S1), tightness, speed/intensity |
| **Winds / reeds** | 3 st (formant limit) | 3 (S44) | shorts 4-8; long 2 | sustain, staccato, slur/legato, flutter, trill | loops >= 2-3 s, random entry (E13) | breath/tongue release sample | `formant: true` (E10); breath noise in `air`/`mech` |
| **Brass** | 3 st | 3-4 (S8) | 3-6 | sustain, staccato, sforzando, fp, swell; legato | loops >= 2 s | bell/room release | mute variants; real dynamic brightness is essential |
| **Voice / choir** | per vowel, 3-4 st | 3 | 2-4 | vowels (a, e, o, m), syllable/word builder (S45) | loops >= 3 s per vowel | consonant release | formant shift limited; legato L |
| **Percussion / drums / hits** | unpitched: none; toms/timpani 3-4 st | fast 4, slow 8-16 | 6-8 (S22, S54) | hit, rim, flam, roll; damped/open | unlooped, length by decay | choke/damper; room tail | mics close + room; no pitch-shift beyond +/-1 st |
| **Pads / evolving (hybrid)** | 6-12 st (synthetic tolerates it) | 2 (soft/loud) with modwheel morph | 1-2 loops with different phases | - | long loops or frozen stretches (S34) | long release (seconds) | freeze/granular/tape (R9); Sub/Impact/Tail/Whoosh-style layers (S29) |
| **Cinematic hit / braam / riser** | 6-12 st or unpitched | 3 | 3-6 | hit, swell, reverse | unlooped | tail layer is the sound | Punish macro (E15), layered sources, IR tails |
| **Synth-like (Serum-class)** | wavetable or root every 12 st | via live params | - | - | seamless cycle loops | live envelope | keep live control; samples only for texture layers |

### 7.6 Suggested build order

1. **R10 lint + R2 ladder + R1 align + R11 family presets** (S/S/S/S). They make
   every agent-built sound measurably better without touching the engine and
   make the result checkable in one command.
2. **E2 release-by-duration, E3 humanise, E4 RR reset, E9 voice steal, E11
   tightness** (all S). Engine work is small; realism gain is broad.
3. **E1 dynamics axis** (M). Biggest single change in feel; needs R1/R2 to be
   done first or crossfades will phase.
4. **E5 mechanical layer, E6 perspectives, R14 derived mics, E14 body IR** (M).
   Turns "synthetic dry" into "instrument in a space".
5. **E8 sympathetic/pedal**, **R6 layer morph**, **R9 design tools** (M).
6. **E7 legato transitions + R13 render** and **E12 articulation sets** (L).
   Highest ceiling for bowed/wind/voice; worth it only after 1-5.

### 7.7 Risks and traps

- **Do not normalise each file**: it destroys the ladder (S37). Calibrate the
  ladder once, store `gain_db`.
- **Do not hide flat layers behind a crossfade.** If the brightness ladder is
  flat, E1 will only make it smoother and still synthetic (lint item 3).
- **Phase**: any crossfade or mic sum needs onset/phase alignment (R1) or it
  combs (S23, S38).
- **RR must differ in the right dimension**: pitch/noise/onset variation, not
  just level; keep takes within ~1 dB and ~5 cents of each other.
- **Zones multiply**: notes x layers x RR x mics explodes; R8 must gate compile.
- Forum-sourced specifics (marked excerpt) should be verified by listening tests
  before being baked into defaults.

---------------------------------------------------------------------------

## Sources

- S1 Spitfire Symphonic Strings user manual (mics, dynamics/vibrato/tightness CCs, legato, RR): https://spitfire-www-assets.s3.amazonaws.com/manuals/SpitfireSymphonicStrings_UserManual.pdf
- S2 Sound On Sound, Spitfire Studio Orchestra review: https://www.soundonsound.com/reviews/spitfire-audio-studio-orchestra
- S3 Sound On Sound, The Sampled Orchestra part 1: https://www.soundonsound.com/techniques/sampled-orchestra-part1
- S4 Sound On Sound, The Lost Art Of Sampling part 2: https://www.soundonsound.com/techniques/lost-art-sampling-part-2
- S5 Sound On Sound, The Lost Art Of Sampling part 4: https://www.soundonsound.com/techniques/lost-art-sampling-part-4
- S6 Sound On Sound, Software Pianos: https://www.soundonsound.com/reviews/software-pianos
- S7 Sound On Sound, Orchestral Tools Berlin Strings: https://www.soundonsound.com/reviews/orchestral-tools-berlin-strings
- S8 Sound On Sound, Orchestral Tools Berlin Brass: https://www.soundonsound.com/reviews/orchestral-tools-berlin-brass
- S9 Orchestral Tools, Berlin series interview: https://www.orchestraltools.com/magazine/behind-the-scenes/berlin-series-interview-pt1
- S10 Salamander Grand Piano V3 (archive listing; 16 layers, minor-third spacing, release layers): https://archive.org/details/SalamanderGrandPianoV3
- S11 Accurate-Salamander project (retuning, release remaster, resonance): https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/
- S12 Pianobook, recording your piano: https://www.pianobook.co.uk/resources/how-to-sample/recording-your-piano/
- S13 Pianobook, how to sample: https://www.pianobook.co.uk/resources/how-to-sample/
- S14 Nicolas Titeux, Making a virtual instrument: https://www.nicolastiteux.com/en/blog/making-a-virtual-instrument-a-guide-to-sampling/
- S15 KVR, piano sampling workflow thread: https://www.kvraudio.com/forum/viewtopic.php?p=6003244
- S16 SFZ `rt_decay`: https://sfzformat.com/opcodes/rt_decay
- S17 SFZ `offset_random`: https://sfzformat.com/opcodes/offset_random
- S18 SFZ opcode index and headers: https://sfzformat.com/opcodes/ , https://sfzformat.com/headers/
- S19 DecentSampler developer guide, groups/samples: https://decentsampler-developers-guide.readthedocs.io/en/latest/the-groups-element.html
- S20 DecentSampler, true legato guide: https://github.com/DecentSamples/DecentSampler-Developers-Guide/blob/main/docs/source/topic-how-to-implement-true-legato.md
- S21 Native Instruments, Kontakt Factory Library Scripts manual: https://docs.native-instruments.com/pdf-guides/kontakt/Kontakt_Factory_Library_Scripts_Manual_English_21062021.pdf
- S22 modwheel.net, machine-gun ostinatos: https://modwheel.net/guides/why-your-ostinatos-sound-like-a-machine-gun
- S23 modwheel.net, CC1/CC11 and phase cancellation in dynamic crossfades: https://modwheel.net/guides/understanding-midi-ccs
- S24 Orange Tree Samples, non-repeating round robin scripting: https://www.orangetreesamples.com/blog/scripting-nonrepeating-roundrobin
- S25 David Hilowitz, round robins that don't suck: https://www.davidhilowitz.com/2018/09/17/video-tutorial-how-to-make-round-robin-samples-that-dont-suck-using-native-instruments-kontakt/
- S26 VI Labs True Keys: Pianos: https://www.vilabsaudio.com/truekeyspianos
- S27 MusicRadar, Spectrasonics Keyscape review: https://www.musicradar.com/reviews/tech/spectrasonics-keyscape-643857
- S28 Vienna Symphonic Library, Synchron Strings / Vienna Instruments (excerpts): https://www.ilio.com/synchron-strings-1
- S29 Sound On Sound, Heavyocity Gravity: https://www.soundonsound.com/reviews/heavyocity-gravity
- S30 Sound On Sound, Heavyocity Symphonic Destruction (excerpt): https://www.soundonsound.com/reviews/heavyocity-symphonic-destruction
- S31 Spitfire LABS / BlankFor.ms tape and granular processing (excerpt): https://www.soundonsound.com/news/blankforms-tape-synths-spitfire-audio , https://synthanatomy.com/2020/05/spitfire-audio-s-new-free-labs-release-features-granular-whalesong-textures.html
- S32 Sound On Sound, Spectrasonics Omnisphere 2: https://www.soundonsound.com/reviews/spectrasonics-omnisphere-2
- S33 MusicRadar, Eric Persing on Omnisphere 2 sound design: https://www.musicradar.com/news/tech/spectrasonics-eric-persing-talks-omnisphere-2-sound-design-and-more-616236
- S34 PaulXStretch / Paulstretch algorithm explained: https://polarity.me/posts/articles/2026-07-07-paulxstretch-paulstretch-explained/ , https://manpages.org/paulstretch
- S35 Diemo Schwarz, corpus-based concatenative synthesis (eContact): https://econtact.ca/16_2/schwarz_corpus.html
- S36 Crossfade laws: https://support.apple.com/guide/logicpro/fade-between-sample-groups-lgsifc8649f5/mac , https://www.kvraudio.com/forum/viewtopic.php?t=347151
- S37 VI-Control, normalising samples when building a library (excerpt): https://vi-control.net/community/threads/do-you-normalize-samples-when-creating-a-library.99315/
- S38 VI-Control, phase coherency in multi-mic libraries (excerpt): https://vi-control.net/community/threads/phase-coherency-in-multi-mic-orchestral-sample-libraries.149738/ ; S38b Sound On Sound, Making Multi-mic Recordings Work: https://www.soundonsound.com/techniques/making-multi-mic-recordings-work
- S39 VI-Control, how sampled legato works (excerpt): https://vi-control.net/community/threads/ramblings-about-how-sampled-legato-works.77892/
- S40 Sampler voice stealing and click avoidance (excerpts): https://forum.juce.com/t/voice-steal-pops/30923 , https://github.com/lostsync/mooloop/issues/130
- S41 VI-Control, Chris Hein body and room convolution (excerpt): https://vi-control.net/community/threads/question-about-body-convolutions-in-chris-hein-libs-esp-room-a-and-room-b.82280/
- S42 Orange Tree Samples Evolution guitars: https://www.orangetreesamples.com/products/evolution-acoustic-guitar-steel-strings , https://www.samplelibraryreview.com/the-reviews/virtual-acoustic-guitar-showdown-with-orange-tree-samples-evolution-guitars/
- S43 Cinesamples mic/mix perspectives (excerpt): https://www.soundbanks.io/product/cinesamples-cinepiano/ , https://vi-control.net/community/threads/how-to-use-mic-positions-in-sample-libraries.156751/
- S44 Orchestral Tools Berlin Strings notes / sizes (excerpt): https://orchestraltools.helpscoutdocs.com/article/363-berlin-strings-notes
- S45 Native Instruments choir products, syllable builder (excerpt): https://www.native-instruments.com/en/specials/choir-vsts/
- S47 344 Audio, building a Kontakt instrument part 3: https://www.344audio.com/post/article-how-to-build-a-kontakt-instrument-a-complete-guide-for-composers-sound-designers-part-3
- S48 Loop point detection tooling (excerpt): https://audioutilityco.itch.io/zero-crossing-loop-finder
- S49 VI-Control, unlooped sustains in Benjamin Wallfisch Strings (excerpt): https://vi-control.net/community/threads/sample-talk-thread-ot-benjamin-wallfisch-strings.146893/page-3
- S51 Spitfire Symphony Orchestra review, legato crossfade rework (excerpt): https://epicomposer.com/spitfire-symphony-orchestra-professional-review/
- S54 Toontrack / VI-Control drum RR and layer counts (excerpt): https://www.toontrack.com/forums/topic/round-robin-and-velocity-layers-for-own-samples-superior-drummer-3/ , https://vi-control.net/community/threads/drum-libraries-with-the-most-dynamic-layers.98984/
- S55 Sympathetic resonance approaches (excerpt): https://vi-control.net/community/threads/sample-piano-library-with-una-corda-sympathetic-resonance-good-playability-and-dynamics-etc.131763/ , https://vi-control.net/community/threads/adding-pianoteq-resonance-to-sampled-pianos.145427/
