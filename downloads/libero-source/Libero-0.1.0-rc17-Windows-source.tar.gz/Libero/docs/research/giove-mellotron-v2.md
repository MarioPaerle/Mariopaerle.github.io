# Giove Mellotron v2 — provenance and independent QA

## Source and rights

The four sources are original Leisureland Mellotron WAV archives attributed to Taijiguy. Acquisition records retain each Wayback CDX timestamp and archived URL. The ZIPs were checked against the CDX SHA-1 payload digest (base32) and SHA-256; all 140 original WAV files in the presets were compared byte-for-byte with their ZIP members. The ZIPs and preserved source WAVs are not modified by the builder.

| Archive | SHA-256 | WAVs |
|---|---|---:|
| `MkII Flute.zip` | `71a4313d0e4db079afa562e91b582b516c7af7ec0db948ad64cb18bbe5844cd2` | 35 |
| `MkII Violins.zip` | `280604ea76209046defd6d0d22cf7290506f957c8d42e5984721c01524dc2c5d` | 35 |
| `8 Choir.zip` | `da4c237bcb2103e0a7a380c1791062443d065283d8c190882d2c93829cf47d93` | 35 |
| `Cello.zip` | `05bea6841541a3b70b1421e3edf5029e0f933d8181ca1d60c58acdeb55f4be03` | 35 |

Permission is the author's freeware permission statement, not an open sample license. Its restrictions exclude payware and commercial for-profit software; the presets are marked `nc` and must stay out of unrestricted/public sample-data releases. Primary records: [Leisureland source page](https://www.leisureland.us/mellotron.htm), [author's 2008 permission](https://www.kvraudio.com/forum/viewtopic.php?start=15&t=236629), and [later clarification](https://www.kvraudio.com/forum/viewtopic.php?t=561309). The code deliberately makes no claim of endorsement by Mellotron/Streetly or a license to new tape masters.

## Build and measured behavior

Each preset has 35 recorded source notes and 70 compiled zones: one same-take sustained continuation and one finite `tape_original` articulation per source note. The raw ZIP member and extracted WAV remain byte-identical. Compiled finite zones now receive a 12 ms terminal fade to prevent end-step clicks; this changes only the renderer output, not archived/original source audio. The default master is −6 dB.

Native renderer QA used the current repository build. Every preset passed three 60-second sustained holds (low/mid/high), an eight-note velocity-127 stack in default and maximum-dynamics modes, and articulation selection by parameter versus MIDI keyswitch. No test stack clipped; worst measured peak was −7.95 dBFS. Late hold RMS ranged from −32.8 to −28.1 dBFS. Finite original tapes rendered to their full source duration (maximum compiled-vs-source duration delta: 0 seconds), ended while the MIDI gate remained held, and note-off remained responsive. The articulation selector/key-switch renders matched sample-for-sample.

The independently measured broad-period/root audit is **not fully resolved** and should not be described as a global pitch pass. The source filename root is retained separately from `physical_root` in source proof. Flute and strings now use measured physical roots (+12 semitones) as their playable G3–F6 mapping; the original audio files remain unchanged. Cello octave placement is decided per note by the shortest normalized-autocorrelation period that remains above 0.80 in at least two of three windows (plus spectral-family evidence). The choir is polyphonic and remains uncorrected. These are source-period/root measurements, not subjective or cents-perfect calibration:

| Source | Broad finding against filename root | Odd-partial family finding | Interpretation |
|---|---|---|---|
| MkII Flute | all 35 notes +1204…+1214 cents vs filename; median +7.85 cents vs corrected physical root | +12 in all 35 × 3 windows | corrected source root is one octave above filename label; playable roots are G3–F6 |
| MkII Strings | all 35 notes +1180…+1212 cents vs filename; median −3.48 cents vs corrected physical root | +12 in all 35 × 3 windows | corrected source root is one octave above filename label; playable roots are G3–F6 |
| 8 Voice Choir | broad estimator varies from −1206 to +1213 cents | autocorrelation candidates: −12 (3), 0 (16), +12 (13), 3 ambiguous | voices overlap; no per-key physical-root correction applied |
| Cello | broad period alone is octave-ambiguous | shortest-period autocorrelation: −12 semitones (29), filename root (6), consistent windows | per-key root metadata records the periodicity result; several physical roots therefore differ from their filename keys |

The report retains source filename, mapped physical root where established (flute/strings), broad-period windows, odd-partial family, and normalized autocorrelation by note. Cello and choir root mappings remain pending: the Cello autocorrelation proposes mixed octave roots that need a coherent target keyboard-range decision; the choir's voices prevent reliable single-f0 assignment. Native behavior, source integrity and headroom passed, but the four-preset set is not pitch-root frozen. Per-key Cello candidates and nearest octave alternatives are in `demo/giove-v2/mellotron/cello-root-candidates.csv`; representative spectra are in `demo/giove-v2/mellotron/cello-root-diagnostics.png`. No musical-realism or subjective quality claim is made; I did not audition the referenced Instagram clip.

Reproduce with:

```sh
PYTHONPATH=python python/.venv/bin/python python/scripts/build_giove_mellotron_v2.py
PYTHONPATH=python python/.venv/bin/python python/scripts/verify_giove_mellotron_v2.py
```
