# Giove — palette plan for the 14 Luna voices

Prepared 4 October 2026. This is a design plan only; it does not create or compile presets. The bank currently contains 10 independent programmes. Root has asked that the remaining 14 be built only after the steel-string guitar's 9 high-note sustain zones have an honest, fresh hold proof. The agreed roster and Giove bank metadata are owned by root.

## Design routes and identities

| Roster | Route | Distinct physical/design identity | Intended role |
|---|---|---|---|
| Minimoog · Bass Circuit | SYN | Oscillator/sub mix with a warm low-register ladder sweep and stable center | Monophonic bass; short envelope, no baked movement |
| Minimoog · Brass Ladder | SYN | Saw/pulse register, brighter resonant sweep and a restrained sync-like edge created only if live engine supports it | Monophonic lead |
| Moog Modular · Harmonic Reed | SYN | Pulse-width harmonic body through staged formants, no claimed circuit emulation | Lead / drone |
| Taurus · Pedal Foundation | SYN | Focused low-frequency oscillator stack with upper octave definition and a firm envelope | Pedal bass |
| Subsequent 37 · Duo Saw | SYN | Two warm saw oscillators, measured modest detune, central oscillator remains stable | Lead |
| Subsequent 37 · Hard Sync | SYN | Fixed master/slave sync relationship and short filter envelope, if engine supports true sync; otherwise documented original oscillator approximation | Sharp lead |
| Subsequent 37 · Feedback Organ | SYN | Mixer-feedback character through harmonic-rich oscillator levels and short decays, not mislabeled as engine ring modulation | Chord / stab |
| Solar 42F · Five Drones | SYN | Five saw drone voices with separate level/formant roles; pitch anchored and no chorus-by-default | Ambient pad |
| Solar 42F · Polivoks Pair | SYN | Two independent resonant filter paths with contrasting low/mid spectral bands | Dark lead / pad |
| Solar 42F · Dual VCO | SYN | Two principal VCO roles and asymmetric pulse/saw coloration with stable center | Lead / drone |
| Mercury · Glass Current | SYN | Original sparse partials with a long, measured stereo-free envelope and shallow spectral motion; an effect-inspired sound, not a Mercury X recording | Ambient texture |
| Mercury · Deep Orbit | SYN | Original low-mid harmonic body with a restrained, long-decay echo/reverb design only if the engine's live effect chain is explicit and controllable | Ambient texture |
| Marble · Xylophone | REC | VCSL xylophone recording, mapped from measured source roots and preserving pp/ff and medium/hard mallet distinctions as available | Percussive melodic hook |
| Marble · Marimba | REC | Independent VCSL marimba recording, with its own source roots/dynamics and lower resonant bar body | Percussive melodic hook |

The hardware names are inspiration and functional architecture references, not claims that these are recordings or exact circuit clones. The Solar 42F roster is based on the locally cached manufacturer manual (`~/Libero/cache/research/giove/solar42f-manual.pdf`): six drone voices, four of them built from five saw oscillators apiece and two Papa Srapa FM voices, plus two VCOs and dual Polivoks filters. These remain the specific design cues. Avoid substituting the Solar 42N design.

## Source and implementation policy

Moog, Subsequent 37, Solar 42F and Mercury X are synthesis inspirations: make new oscillator-based sounds in Libero and document any approximation where the engine lacks a feature. Do not sample commercial presets or hardware audio. Keep Poli/glide 0, wow/flutter and drive at 0, and CaldiSpento by default unless the final sound demonstrably needs a clearly documented exception. Maintain usable headroom at eight notes and maximum dynamics. Each patch must differ by excitation/oscillator structure, spectrum over time and role, rather than only cutoff or reverb.

The two mallet patches use the local VCSL CC0 source collection at `~/Libero/cache/libraries/vcsl/Idiophones/Struck Idiophones/`. Candidate folders are `Xylophone/Medium Mallets`, `Xylophone/Hard Mallets`, and `Marimba`. Verify VCSL pitch conventions, each file's actual fundamental, pp/ff layers, note coverage and original take count from filenames and waveforms. Preserve all usable originals, source path/hash, source-to-zone map, and the VCSL licence notice. Do not synthesize missing recordings and call them source takes. Because these are struck bars, retain the recorded attack, use velocity-layer hard switching, and design any optional body sustain honestly from the same bar's measured modes. A design-sustain extension is not a naturally infinite performance.

Each programme needs its own explanatory notes, square SVG analysis figure derived from source/synthesis measurements, source/provenance record, reproducible builder output, fresh manifest/source hash, lint 0 FAIL, and a native QA report. For recorded bars verify measured pitch and played mapping at every available root and boundaries; for SYN verify the oscillator fundamental, intended intervals, and sweep/legato behavior. For every sustained preset, render 60-second holds in low/mid/high register and report late-window RMS, seams, peak and clipping. For mallets, verify natural decays and release rather than forcing an infinite hold. Test matched-level phrases and 8-note chords; metrics do not certify warmth or user preference, and no unperformed listening claim will be made.

## Known evidence and limits

The manufacturer manual already cached for Solar 42F is primary source material for feature claims; model names alone do not license any commercial recordings or patches. VCSL's actual licence and the specific sample hashes must be recorded in each mallet preset before build. Mercury X is an ambient inspiration only; no hardware recording will be used. The values and sound character still require native render and listening review after construction.
