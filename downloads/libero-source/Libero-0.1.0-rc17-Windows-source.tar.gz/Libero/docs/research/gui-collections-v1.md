# Collection cards and direct sound navigation

Default AU/VST3 editor size: 1360 × 780, adjustable from 1000 × 560 to 2600 × 1600. Collections use square coloured plates, directional shadows, and a staggered stack of their first four actual sound figures on hover or keyboard focus. SVGs remain sanitized, parsed lazily and cached; empty collections retain their empty state. Reduced-motion preferences remove transitions.

The visible “Torna al suono” control closes the library and focuses the current sound. A successful load returns to its sound page; a load error leaves the catalogue open. Existing search, favourites, colour tags, bank context, previews, and previous/next navigation remain available.

Verified in the browser with 203 mock entries and 30 banks, keyboard-focus card reveal, explicit close and successful load. Verified in the real native WebView: viewport 1360 × 780, close/inert state and focused sound plate; parameter relays, articulations, preview audio and bank actions passed. Universal AU and VST3 compiled and installed; auval and Carla discovery passed for arm64 and x86_64. Evidence: `/Users/mario/Libero/demo/library-expansion-v6/gui-native-tests.log`.

A developer UI override symlink serves the current UI when an editor is reopened. The native default window size needs the host to reload the updated plugin binary; no running DAW was restarted.


Added built-in themes `crema` and `cielo`: warm cream whites and soft blue whites respectively, with matching secondary surfaces and legible tinted inks. Both are also installed in the user's theme directory for existing native instances, and are present in the rebuilt universal AU/VST3 UI archive. Verified selection through the Tema menu, with screenshots at `~/Libero/demo/packs-v7/tema-crema.jpg` and `tema-cielo.jpg`. Theme selection remains user-controlled.
