# Libero first-release audit

Checked 2026-10-04 against the current working tree and existing local build. This is a release-readiness checklist, not legal advice. No files were changed outside this report; no build, install, signing, upload, or release action was performed.

## Current preparation update — 4 October 2026

The root software license is now AGPLv3 (`LICENSE`), with a separate `NOTICE` for JUCE, fonts and sound recordings. This follows the intended free/open-source launch direction. The staged source archive includes the actual working sources and the pinned JUCE source. `scripts/prepare_release.py` stages universal VST3/AU/renderer outputs and inventories sources, notices, compiler versions, SHA-256 hashes and signatures. Original Libero-authored sound data has a separate CC0 preparation policy; third-party recordings retain their terms.

The full Python suite passes 359 tests, and the native engine/socket suite passes with no failures. These are local test results. Apple Developer ID signing/notarization and final release artifact validation remain separate gates; nothing has been published.

The audit below is retained as the earlier read-only checkpoint. Its statements about a missing root license and missing archive tooling describe that earlier state, not the current preparation.

## Earlier audit checkpoint and remaining distribution requirements

- The repository root has no `LICENSE`, `COPYING`, or `NOTICE`. `README.md` describes Libero but does not grant a software license. Choose and add a project license before publishing source or binaries, and preserve a distinct license for sample assets and preset banks.
- `third_party/JUCE` is pinned at JUCE **9.0.3**. Its vendored `LICENSE.md` says JUCE 9 modules are dual-licensed under AGPLv3 and JUCE’s commercial license. This is not the JUCE 7/8 licensing regime. Before a public build, document the chosen path: comply with the applicable AGPL obligations for a combined distributed product, or verify the required JUCE commercial license and seat coverage. JUCE 9 EULA states product owners must license all contributors who modify material transitively dependent on JUCE; static content retaining full functionality without JUCE is exempt. The repository currently has no record of that license choice or seat roster.
- The JUCE submodule carries `third_party/JUCE/LICENSE.md` and `third_party/JUCE/JUCE.spdx.json`, but the current install script copies only the binaries into user plugin directories. A distributable archive should include the applicable JUCE notices/SBOM and notices for other distributed dependencies, with exact versions and license text or durable links as required by each license.
- The existing build emits universal macOS **VST3**, **AU**, and the **`libero-render` CLI**. CMake requests only `FORMATS VST3 AU`; there is no Standalone plugin target. There is no `.app`, `.pkg`, `.dmg`, Windows installer, or Linux package definition in the repository. The current `scripts/install.sh` is a local per-user installer, not a public package: it copies bundles to `~/Library/Audio/Plug-Ins`, copies the CLI to `~/.local/bin`, removes quarantine, and applies ad-hoc signatures. It does not sign with a Developer ID, notarize, or create an installer.
- Existing local build evidence (not a release artifact): three universal arm64/x86_64 Mach-O outputs were present. SHA-256 of the executable payloads at audit time:

  - VST3 `Libero.vst3/Contents/MacOS/Libero`: `632b2403bb1142ad32e121215857bfa6485fd01b8f013111895adb5f9723c51b`
  - AU `Libero.component/Contents/MacOS/Libero`: `57e6ab84292848e9891f98a37eb976117101d0a1c2f138065e92253c7a3fdac7`
  - CLI `libero-render`: `25afb9e86b0d85021a5403578181301eca8a75e0c8ddab33d2f6f7db4663c7b7`

  These are mutable local build outputs from a dirty working tree, not signed/reproducible release checksums. Recompute hashes from the final staged archive and publish those hashes with the release.

## Release checklist

1. **Set software terms.** Add the project license and an explicit contributor/owner identity. Decide whether source/binaries use an AGPL-compatible distribution or a JUCE 9 commercial license. Keep the software license separate from sample/preset terms. JUCE EULA §1.12 restricts distributing Products that create other Products, then says Products made with the software must be licensed by its users. Do not assume an ordinary music render (audio file) is such a Product: JUCE defines a Product as a product, service, or project combining JUCE with other copyrightable work, but does not explicitly classify rendered music as a JUCE Product. The clause is especially relevant if Libero enables users to generate or distribute other software/plugins that themselves include JUCE. Resolve that narrower use case against the EULA and actual product behavior; do not treat ordinary audio rendering by itself as a release blocker.
2. **Inventory dependencies.** Freeze the JUCE commit and the Python environment lock file; record transitive C++ and Python dependencies, licenses, versions, and shipped/not-shipped status. Use the JUCE SPDX SBOM as an input, then produce a release-specific SBOM for the actual binaries. Verify any third-party UI fonts, icons, images, and bundled runtime files individually.
3. **Stage only intended outputs.** Build clean universal VST3, AU, and CLI artifacts from a recorded commit. If a standalone application or installer is a release requirement, add and test those targets separately; none exists in the current CMake build. Include user documentation, version, contact/support details, credits, and dependency/source notices in the package.
4. **Sign and package macOS builds.** Replace the local ad-hoc `codesign -s -` flow with Developer ID signing, hardened-runtime configuration as needed, timestamping, and notarization/stapling for distributable downloads. Validate AU with `auval`, test VST3 discovery/loading in supported hosts and both architectures, and check the CLI from a clean user account. Document macOS minimum-version support (CMake currently sets 11.0).
5. **Provenance and integrity.** Record the source commit, compiler/CMake/Xcode versions, build arguments, architectures, and dependency lock/SBOM hashes. Generate SHA-256 hashes for every final archive and every contained binary after signing. Keep a signed release manifest and verify downloaded artifact hashes before publishing.
6. **Security/release hygiene.** Scan staged files for secrets, debug endpoints, test assets, user-specific paths, unneeded symbols, and quarantined/untrusted inputs. Run the project’s relevant tests against the staged binaries, inspect entitlements and `Info.plist`, verify package contents, and retain the test logs and signature/notarization results. Do not treat a successful local install as a public release check.

## Current packaging facts

| Artifact | Current definition / state | Public packaging status |
|---|---|---|
| VST3 plugin | `plugin/CMakeLists.txt` requests VST3; present locally as universal arm64/x86_64 | Build output exists; no installer/archive, release signing, or notarization configured |
| AU plugin | CMake requests AU; present locally as universal arm64/x86_64 | Build output exists; no installer/archive, release signing, or notarization configured |
| Offline renderer | `juce_add_console_app`; present locally as universal arm64/x86_64 | Executable exists; local install script only |
| Standalone GUI app | No target in current CMake `FORMATS` | Not currently built |
| macOS installer / DMG | No package project or packaging script found | Not currently available |
| Windows/Linux package | No installer/package definitions found | Not currently available |

## Primary references

- JUCE 9.0.3 vendored notice: `third_party/JUCE/LICENSE.md` and `third_party/JUCE/JUCE.spdx.json`.
- [JUCE 9 EULA](https://juce.com/legal/juce-9-licence/) (published 17 June 2026): licence types and thresholds (§1.2), contributor seats (§1.7), distribution (§1.9–1.11), and the limited “Products That Create Products” clause (§1.12). Its scope for audio rendering is not resolved by the wording and should not be assumed.
- [JUCE 9.0.3 LICENSE.md](https://github.com/juce-framework/JUCE/blob/9.0.3/LICENSE.md).
- Local implementation facts: `CMakeLists.txt`, `plugin/CMakeLists.txt`, `scripts/build.sh`, and `scripts/install.sh`.
