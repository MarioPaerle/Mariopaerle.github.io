# Libero release-scope rights audit v2

**Snapshot: 4 October 2026.** Read-only evidence review, not legal advice or publication approval. Uses the frozen 145-preset report and 55-new-pack summary/source reports, with the replacement and Giove audits. Existing proof/audio hashes were inspected; this pass did not rehash the whole library or change presets.

## Summary

The original 200-preset snapshot has **149 conditional entries**: **74 first-party SYN** whose sample-data dedication must be made effective; **18 recordings with a known grant and mapped source evidence** but attribution/export status to complete or reconcile; and **57 records with unresolved lineage, mixed-source mapping, or restrictive terms**.

**51** are currently marked allowed across the component reports and backed by source grants/mapping. Another 18 B entries need credit/archive checks; 98 original SYN entries need an effective data license. After those actions, the evidence-based candidate pool would be **167**. This is not a sound-quality statement or a publication approval.

Counts are 106 conditional in the 145 report plus 43 conditional in the new55 report. The 18 excluded originals remain excluded. Four authentic Mellotron sample sets are freeware/no-payware only, not open-content.

## A — original Libero SYN; owner dedication required (74)

All named inputs are first-party synthesis. A local CC0 statement or generator recipe documents intent, but is not an effective public sample-data dedication. Confirm and apply the chosen license before release.

- **prove:** `chitarra`, `lead-fase`, `lead-fase-live`, `meow-lead`
- **mie:** `coro-di-marmo`, `lira`, `vetro`
- **aria:** `saw-rame`
- **bassi:** `sub-ancora`, `sub-legno`, `sub-rimbalzo`
- **blue:** `blues-formant-blue`, `clavinet-blue`, `fosforo-tasti`, `indaco-ance`, `rame-notturno`
- **green:** `ambra-fm`, `aurora-vetro`, `bosco-largo`, `canneto-elettrico`, `cedro-lead`, `giada-fase`, `miele-pulse`, `muscolo-basso`, `ottone-verde`, `prisma-morbido`, `resina-sync`, `seta-spettrale`
- **sintesi:** `sintesi-pad-calda`, `sintesi-pluck-arpa`
- **trap:** `trap-campana`, `trap-drill-slide`, `trap-lead`, `trap-pad`, `trap-pad-inverso`, `trap-pad-scuro`, `trap-pluck`, `trap-rhodes`, `trap-sub-grit`, `trap-vox`
- **mog:** `apito-de-neon`, `baixo-corrente`, `clap-baile`, `coro-fantasma`, `faisca-cromada`, `gota-de-cobre`, `kick-baile`, `kick-phonk`, `lua-de-viaduto`, `motor-ritual`, `oitao-808`, `poeira-de-concreto`, `reese-de-favela`, `sino-lata`, `sino-lata-quarta`, `sino-lata-terza`, `sino-noite`, `sirene-de-vidro`, `sub-asfalto`, `voz-de-asfalto`
- **venere:** `argo-organ`, `cometa-pluck`, `cratere-fm`, `eclisse-pad`, `elio-sync`, `luna-orbita`, `marea-celeste`, `nido-reese`, `orione-brass`, `polvere-nebula`, `prisma-flusso`, `pulsar-basso`, `quasar-arpeggio`, `sirio-formante`

## B — recorded grant and file mapping evidenced (18)

Seventeen entries have an attribution gap in exported `credits.json`: add the license URI and accurate modification notice and verify they survive final export. The DRSKit Bebop drum set already has a comprehensive notice and a source map with 709 entries and zero missing/hash mismatches; its report still says conditional, so reconcile that status before promotion.

- **aria:** `fagotto-ombra`, `oboe-respiro`, `piano-giocattolo`
- **blue:** `pianet-t`, `wurli-ep200`
- **cielo:** `coro-orizzonte`, `coro-volta`, `donne-mezzo`, `donne-radura`, `trillo-rito`, `uomini-cenere`, `uomini-pietra`
- **bebop:** `bebop-sax-soprano`, `bebop-sax-alto`, `bebop-sax-tenor`, `bebop-sax-bari`, `bebop-clarinet-bb`, `bebop-batteria`

B detail: 12 older BY presets have `source_chain_complete=true` and nonzero proof records but incomplete BY credit fields; five mapped Bebop woodwind presets (four MTG Solo Sax plus TinySOL Bb clarinet) have zero missing/hash/cache mismatches but incomplete credit fields; DRSKit has complete fields and source lineage but needs aggregate-status reconciliation.

## C — lineage or source-term issue unresolved (57)

Do not include these based on the current evidence. A file hash identifies a file, not its upstream source. Named CC0/CC BY libraries still need exact source-to-zone lineage where the source audit says it is missing. Resolve GPL/NC or other format restrictions separately.

- **prove:** `meow-phonk`
- **mie:** `batteria-hiphop`, `batteria-trap`, `duduk-dune`, `flauto-pan`, `sassofono`, `tromba`
- **archi:** `archi-congelati`, `archi-ensemble`, `contrabbassi`, `viole`, `violini`, `violino-solo`, `violoncelli`
- **aria:** `kalimba-legno`, `piano-preparato`
- **bassi:** `basso-flatwound`, `basso-hollowbody`, `contrabbasso-jazz`
- **blue:** `banjo-blue`, `organo-blues`, `rhodes-stage77`
- **chitarre:** `chitarra-acciaio`, `chitarra-acciaio-accordi`, `chitarra-dietro-ponte`, `chitarra-elettrica-crunch`, `chitarra-elettrica-pulita`
- **cielo:** `ellen-ooh-aha`
- **flauti:** `clarinetto-sib`, `flauto-legno`, `flauto-traverso`, `odisseo-aulos`, `pan-canne`
- **ottoni:** `tromba-sordina`, `tromba-v3`
- **percussioni:** `batteria-boombap`, `batteria-hiphop-vera`, `batteria-jazz`, `batteria-rock`, `marimba`, `percussioni-trailer`, `tamburi-epici`, `xilofono`
- **piano:** `piano-feltro`, `piano-rhodes`, `pianoforte`, `pianoforte-concerto`, `steinway`
- **trap:** `trap-archi`, `trap-bell`, `trap-brass-stab`, `trap-flute`, `trap-marimba-scura`, `trap-piano`
- **mog:** `baile-rua`, `drum-phonk-mog`, `memphis-fita`

## Other inventories

### 18 original exclusions

These remain excluded; replacements do not change their status:

- **prove/chitarra-acustica** — FS Seagull Steel String Acoustic Guitar (FlameStudios GigaSamples, SF2 edition) (GNU GPL v3+ (samples); FreePats GPL special exception for compositions)
- **mie/trap-hit** — Philharmonia Orchestra sound samples (french horn, trombone 0.25 s) (free to use in works, not redistributable as samples (private lane)); VSCO 2: Community Edition (cello section spiccato, solo contrabass spiccato) (CC0 1.0)
- **mie/trap-kit** — SampleRadar: 300 free trap samples (Drum_Hits) (royalty-free, no redistribution (private lane)); SampleRadar: 378 free 808 drum samples (Hits) (royalty-free, no redistribution (private lane)); SampleRadar: 105 free 808 weight samples (Type A/D one-shots) (royalty-free, no redistribution (private lane)); libero.forge presets (sub_drop, riser_whoosh, trap_808) (original work)
- **mie/trap-kit-ita** — SampleRadar trap/808 sample packs (Royalty-free music use; redistribution prohibited)
- **archi/archi-armonici** — Philharmonia Orchestra sound samples (Philharmonia sample-use terms: commercial works permitted; as-is samples/sampler-instrument redistribution prohibited)
- **archi/archi-particolari** — Philharmonia Orchestra sound samples (Philharmonia sample-use terms: commercial works permitted; as-is samples/sampler-instrument redistribution prohibited)
- **archi/violoncello-solo** — Philharmonia Orchestra sound samples (Philharmonia sample-use terms: commercial works permitted; as-is samples/sampler-instrument redistribution prohibited)
- **aria/mandolino-dorato** — Philharmonia Orchestra samples (CC BY-SA 3.0)
- **bassi/808-cavo** — Abletunes - 808 · Abletunes - 808 01 E.wav (Abletunes License Agreement (EULA; sampler use in musical productions permitted, redistribution prohibited))
- **bassi/808-colpo** — Abletunes - 808 · Abletunes - 808 28 C.wav (Abletunes License Agreement (EULA; sampler use in musical productions permitted, redistribution prohibited))
- **bassi/808-notte** — Abletunes - 808 · Abletunes - 808 22 A.wav (Abletunes License Agreement (EULA; sampler use in musical productions permitted, redistribution prohibited))
- **chitarre/chitarra-classica** — Philharmonia Orchestra classical guitar samples (Official terms: music-use allowed; as-is sample/sampler redistribution prohibited)
- **chitarre/chitarra-classica-accordi** — Philharmonia Orchestra classical guitar recordings, rendered as chords (Official terms: music-use allowed; as-is sample/sampler redistribution prohibited)
- **ottoni/corno-francese** — Philharmonia Orchestra French horn samples (Official terms: music-use allowed; as-is sample/sampler redistribution prohibited)
- **percussioni/percussioni-mano** — VCSL hand percussion (CC0 1.0); VSCO 2 CE percussion (CC0 1.0); Philharmonia castanets (Official terms: music-use allowed; as-is sample/sampler redistribution prohibited)
- **percussioni/percussioni-texture** — Philharmonia percussion samples (Philharmonia terms restrict as-is sample/sampler redistribution)
- **trap/trap-coro** — Sonatina Symphonic Orchestra 4.0 chorus recordings (Creative Commons Sampling Plus 1.0; no sample-data redistribution)
- **trap/trap-kit-pro** — SampleRadar: 300 free trap samples (Drum_Hits) (royalty-free, no redistribution (private lane)); SampleRadar: 378 free 808 drum samples (Hits) (royalty-free, no redistribution (private lane)); SampleRadar: 105 free 808 weight samples (Type A/D one-shots) (royalty-free, no redistribution (private lane)); libero.forge presets (sub_drop, riser_whoosh, trap_808) (original work)

### 18 replacement presets

The separate audit records 12 source-grant-backed recordings and six first-party SYN sounds with proposed CC0 dedications. Full per-preset source/credit/proof details: [replacement rights audit](/Users/mario/Documents/Libero/docs/research/release-replacements-rights-v1.md) and `/Users/mario/Libero/demo/release-replacements-v1/replacements-rights-audit.json`.

### Giove24

Giove has six third-party CC0 sounds (two VCSL mallets and four acoustic tape-keyboard interpretations) plus 18 first-party SYN with proposed local CC0. The four “Nastri” are acoustic reinterpretations, not historical Mellotron masters. See [Giove audit](/Users/mario/Documents/Libero/docs/research/giove-rights-v1.md) and `/Users/mario/Libero/demo/giove-v1/rights-audit.json`.

### Four authentic Mellotron sample instruments

`mellotron-cello`, `mellotron-mkii-flute`, `mellotron-mkii-strings`, and `mellotron-eight-voice-choir` preserve 35 original finite tape performances per set; `Sustained Loop` is a separate derived articulation. The source author permits freeware/no-payware with attribution, not CC0/open-content or commercial/payware. Keep them outside the general open bundle; a separate free add-on must follow those terms. Archive SHA/CDX evidence is in [mellotron-v2-sources.md](/Users/mario/Documents/Libero/docs/research/mellotron-v2-sources.md).

## Soundpack candidate count

Current status-allowed: **51**. Add 18 source-mapped BY records after credits/export checks, and 98 SYN after effective owner dedication, for **167 potential entries**. The 57 C, 18 excluded originals and four freeware-only Mellotron instruments are not counted.

The component arithmetic is 145 + 55 + 18 replacements + 24 Giove + 4 authentic Mellotron = 246 folders, assuming these inventories are disjoint. Read final bank membership metadata at staging; folder count is not proof of active membership.

## Release actions

1. Confirm a sample-data license for first-party SYN separately from root AGPLv3 software.
2. Complete BY license/change fields for 17 B items and check final archive contents.
3. Reconcile DRSKit status with its existing complete credits and hash map.
4. Finish source-to-audio map and license review for C entries chosen for inclusion.
5. Freeze membership, credits and hashes at final package staging. This audit is a source snapshot, not proof of future package freshness.
