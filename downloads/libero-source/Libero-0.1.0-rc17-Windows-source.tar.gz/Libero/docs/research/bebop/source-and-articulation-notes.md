# Bebop v1 — sources and articulation notes

The bank uses the original recorded performances below. It does not synthesize acoustic instrument timbres and does not create section sounds by copying, delaying, detuning, or pitch-shifting a single recording. Sustain loops are derived from each source take, with the original performance, upstream map and source-file hashes retained alongside the derived audio and loop audit. Longer holds use an exact same-take overlap that preserves the performed pressure; shorter pitched holds use a measured-modal continuation fitted to that recording after the real attack. These are explicit source-derived sustain designs, not claims that the player performed an indefinitely long note. Falls, shorts and staccatos remain performed gestures.

| Parts | Source and license | Kept performances |
|---|---|---|
| Trumpet sustain, vibrato, staccato; trombone sustain, vibrato, staccato; French horn sustain, staccato, muted; tuba sustain, staccato | VSCO 2 Community Edition, upstream SFZ branch, CC0 1.0 | Each instrument is one playable patch with a selector for separately mapped performances. Original mapped roots, velocity layers and round-robin takes are retained. The French-horn mute spans fewer source roots; its map is intentionally range-limited. |
| Old trombone buzz, fall, short | VSCO 2 Community Edition, raw OldTrombone performances, CC0 1.0 | Distinct Buzz, Fall, and Short recordings are included in the trombone patch. Buzz can sustain using same-take loops; Fall and Short are one-shots because they are performed gestures. |
| Clarinet in B♭ | TinySOL, CC BY 4.0 | Three recorded dynamic layers over 42 mapped roots; the ordinary performance is kept as its own clarinet patch. |
| Soprano, alto, tenor, baritone saxophone | MTG Solo Saxophones, CC BY 4.0 | Two recorded dynamics (p/f) for soprano, alto and tenor; three (p/m/f) for baritone; each pitched layer retains its three performed round robins. The SFZ also contains CC-gated breath/key-noise groups that the importer cannot treat as playable notes; their source maps and audio hashes are retained as evidence but those unpitched groups are excluded from the note maps. |
| Piano, upright bass, guitar, drum kit | See the accompanying rhythm-source manifest and each instrument's source credit. | The rhythm helper provides acoustic piano, pizzicato upright bass, clean guitar, and a real jazz-capable recorded drum kit. |

## Limits and use

The engine's compiled instrument format represents a single multisample performance per note, not a true simultaneous multi-instrument ensemble preset. The big-band demo therefore provides an actual multi-track arrangement, with independent saxophone and brass parts voiced in their playable registers. It is not a claim that one preset contains a complete big band. Instruments do not share a common room or microphone; modest shared reverb in the demo helps place the parts but cannot substitute for a live ensemble recording.

Each patch's nearest-root zones are bounded by its lowest and highest sampled roots, so a sparse patch never stretches one note across the whole MIDI keyboard. Some articulation ranges are narrower than the instrument's theoretical range, especially muted horn and the short OldTrombone gestures. All source root/take maps are retained in the patch's `samples/source-maps-original.json`; any implausible upstream tuning opcode is logged in `samples/tuning-corrections.json` and remeasured from the original recording. The final distributed patches use 0 cents humanization, Poli mode, and 0 ms glide by default.

## Primary source references

- VSCO 2 CE source and CC0 license: https://github.com/sgossner/VSCO-2-CE
- MTG Solo Saxophone FreeSound packs: https://freesound.org/people/MTG/packs/20251, https://freesound.org/people/MTG/packs/20239, https://freesound.org/people/MTG/packs/20247, https://freesound.org/people/MTG/packs/20253
- The rhythm manifest contains the primary source URLs and license evidence for its four instruments.
