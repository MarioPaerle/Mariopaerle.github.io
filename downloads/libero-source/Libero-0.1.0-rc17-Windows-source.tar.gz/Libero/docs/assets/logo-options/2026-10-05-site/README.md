# Site-aligned logo studies

Drafts use the current site colors, reverse title labels and thin geometric marks. All symbol segments are straight. Harmonic is a discrete 3:2 trajectory with 32 intervals; Phase uses two offset open paths; Fold is a wireframe folded surface.

Dark and light previews, standalone vector marks and 256 px icons are included. These proposals are not installed in the site or plugin. Wordmark outlines use Inter Tight under SIL OFL 1.1 (ui/fonts/OFL-InterTight.txt).
