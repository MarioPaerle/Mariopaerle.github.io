# Continuous Lissajous logo studies

Six nominal frequency ratios: 3:2, 2:1, 4:3, 5:4, 5:2 and 1:1. Each traces two periods with x frequency offset +0.028. Open cubic paths interpolate analytic sine positions and derivatives; there are no polygon segments. First and second turns have different opacity, with a subtle diagonal stroke gradient.

Dark/light SVG marks and 512 px PNG icon previews are included. Previous studies are preserved; these proposals have not replaced the application or site logo. Wordmark outlines derive from Inter Tight, SIL OFL 1.1 (ui/fonts/OFL-InterTight.txt).
