# Site-aligned logo studies

Drafts use the current site colors, reverse title labels and thin geometric marks. All symbol segments are straight. Harmonic Open uses 32 straight segments with x frequency 3.035 and y frequency 2. The slight frequency offset leaves the two ends separated. This revision preserves the earlier closed proposal in its original directory.

Dark and light previews, standalone vector marks and 256 px icons are included. These proposals are not installed in the site or plugin. Wordmark outlines use Inter Tight under SIL OFL 1.1 (ui/fonts/OFL-InterTight.txt).
