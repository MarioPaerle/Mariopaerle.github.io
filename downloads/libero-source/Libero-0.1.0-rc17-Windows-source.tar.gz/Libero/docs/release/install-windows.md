# Installing the Windows preview

This preview targets Windows 10/11 x64 and a 64-bit DAW supporting VST3. Windows
ARM and 32-bit hosts have not been tested. Sound banks are separate downloads;
the same `.liberobank` packages work on macOS and Windows.

[Download folder on Google Drive](https://drive.google.com/drive/folders/1H8RPLpUjnRy4grvidcRvtLt1DuVlx28L?usp=drive_link)

The current Windows test build is 0.1.0-rc9. Automated native, WebView and installer checks passed. Use Installs for plugin builds and corresponding sources, and Packs for sound banks.

Use the Windows x64 installer or ZIP in Installs.
Sound packs are separate downloads; their installation instructions are in the
[sound-pack guide](sound-packs.md).

1. Close your DAW.
2. Run `Libero-0.1.0-rc9-Windows-x64-Setup.exe`. It installs the VST3 in
   `C:\Program Files\Common Files\VST3\Libero.vst3`.
3. Reopen your DAW and rescan VST3 plugins if required.
4. Open Libero, select Library, then Import. Select multiple `.liberobank` files
   or the Base Bundle ZIP.
5. Review the collections, versions, sizes and warnings, then install the selected packs.

For manual installation, extract the ZIP and copy the whole `Libero.vst3`
folder into that same VST3 directory. Keep its nested `Contents` folder intact.
The ZIP also contains the optional `libero-render.exe` offline tool; Python is
not required to use the plugin or import collections.

Libero uses Microsoft WebView2 Evergreen Runtime for its interface. If it is
missing, the plugin shows an installation link. Install the Runtime from
[Microsoft](https://developer.microsoft.com/microsoft-edge/webview2/), then
close and reopen your DAW. See [Microsoft's distribution guidance](https://learn.microsoft.com/microsoft-edge/webview2/concepts/distribution).
The loader is linked into Libero; no separate WebView2Loader DLL is needed.

Your library is in `%USERPROFILE%\Libero`. Reimporting the same version leaves
the collection unchanged, and older versions cannot replace newer ones. An
update replaces the whole collection, including edits and added sounds; the
import screen warns before confirmation. Back up work you want to keep.
Uninstalling the plugin preserves this library.

The preview installer is unsigned. Automated checks cover engine rendering,
VST3 factory loading, WebView2, MIDI and bank imports; testing in actual DAWs
is still needed. Report your Windows version, DAW/version, sample rate and
buffer size together with reproduction steps.

## First DAW test

- Load one bank, play notes and a chord, then close and reopen the editor.
- Save a DAW project using Libero and reopen it; check the sound and parameters.
- Try sustain, pitch wheel and mod wheel, then overlapping notes in Legato mode.
- Import the same bank again and verify that it is identified as already installed.
- On a simple sampled sound, use the Sample panel to make a personal copy. Move its
  start/end and loop markers, apply, then reload the sound and verify the edits.
- Check resizing, themes, sound navigation, CPU use and playback at 44.1/48 kHz.
