# Installing Libero on macOS

Requires macOS 11 or later and a host that supports VST3 or Audio Units.
Both Apple silicon and Intel code are included.

[Download folder on Google Drive](https://drive.google.com/drive/folders/1H8RPLpUjnRy4grvidcRvtLt1DuVlx28L?usp=drive_link)

The current macOS download is 0.1.0-rc6. Use Installs for plugin builds and corresponding sources, and Packs for sound banks.

1. Close your DAW.
2. Copy `Libero.vst3` to `~/Library/Audio/Plug-Ins/VST3/`.
3. Copy `Libero.component` to `~/Library/Audio/Plug-Ins/Components/` if you use AU.
4. Reopen your DAW and rescan its plugins if necessary.
5. Open Libero, open Library, and select Import. Select several `.liberobank`
   files or the Base Bundle ZIP.
6. Review the collections, versions, number of sounds, sizes and warnings.
7. Install the selected packs, then wait for the per-pack results.

Extract the macOS plugin ZIP before copying its bundles. Keep sound-pack
archives intact; the updated plugin imports multiple `.liberobank` files or
the Base Bundle ZIP directly.

Your sound library lives in `~/Libero`. A matching installed version is skipped,
and an older package cannot replace a newer bank. Updating replaces the whole
collection, including your additions and edits; Libero warns before confirmation
and retains the previous bank in the Trash after success. Back up work you want
to keep independently. An import failure leaves the previous bank installed or
reports the location of its recoverable backup.

The optional `libero-render` command renders presets offline. Place it in a
directory on your PATH, for example `~/.local/bin`. The Python authoring tools
are separate from the plugin and are not required to play installed banks.

This pre-release is ad-hoc signed and has not been notarized. macOS may flag it
as software from an unidentified developer. Signing and distribution details
are recorded in the release manifest.

Uninstall by removing the plugin bundles from the two directories above.
Removing the plugin does not remove your sound library.
