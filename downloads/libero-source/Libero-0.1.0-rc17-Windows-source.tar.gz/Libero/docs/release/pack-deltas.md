# Differential pack updates

Libero rc17 supports optional file-level updates in the existing live catalogue.
Older builds ignore `deltas` and download the full `.liberobank` as before.
First installs and repairs without a matching base also use the full pack.

Build a patch from the exact previously published archive and the new full archive:

```sh
python3 scripts/build_pack_delta.py old.liberobank new.liberobank update.liberodelta
```

The ZIP contains `delta.json` and only changed/new files under `files/`.
The manifest (`libero.delta/1`) specifies the bank ID, base and target versions,
and the complete target inventory: relative path, SHA-256, byte length and
`changed` flag. Files omitted from that inventory are removed in the new version.
No Python recipe is executed during installation.

After uploading and verifying both public downloads, prepare the catalogue:

```sh
python3 scripts/update_download_catalog.py --pack new.liberobank --drive-id FULL_ID \
  --delta update.liberodelta --delta-drive-id DELTA_ID
```

Publish the prepared catalogue only after the files and licences have been checked.
Keep the full archive available for new users, older clients and recovery.
Multiple base versions may be added with separate `--delta` invocations.

The downloader selects the smallest matching patch. It verifies the archive and
all target files, links unchanged local files into a staging tree, and writes
changed files separately. If hard links are unavailable it copies the reused file.
The normal bundle/audio checks run before the staged tree replaces the installed
bank through the existing backup-and-rename transaction. On supporting filesystems,
unchanged audio retains its inode and is neither decoded/re-encoded nor rewritten.
A modified or missing base triggers a verified full download. No partial pack is
committed. The pack must be inactive in every instance of the current process.

The delta manifest lists the entire target, so even tiny patches still require
reading/hashing the reused files. Installation is transactional at pack level;
network transfer and data writes are incremental. Existing user-added files are
not merged and remain recoverable in the prior pack backup, as with full updates.

Headless coverage:

```sh
python3 plugin/tests/test_pack_delta.py /path/to/libero-host-test plugin/tests/fixtures/test-tone
node --test plugin/tests/test_pack_manager.mjs
```

Tests cover added/deleted files, identical target content, preserved file identity,
sparse HTTP transfer, modified-base fallback, invalid versions, corrupt payloads
and unsafe paths. Test HTTP access to loopback is compiled only into the test host.
Production catalogue URLs retain their HTTPS allowlist.
