"""Lira — a plucked lyre with a cypress soundbox."""

from libero import Sound, synth

sound = Sound(
    title="Lira",
    subtitle="corda pizzicata, cassa di cipresso",
    tags=["plucked", "string", "lyre", "warm", "acoustic"],
    roots=[38, 45, 52, 59, 66, 73, 80, 87],
    velocities=[56, 112],
    sample_rate=48000,
    accent="#b5874e",
)


@sound.body
def body(ctx):
    r, v = ctx.register, ctx.vel
    # gut-like strings: long and round in the bass, shorter and brighter up top
    string = synth.karplus(
        ctx.freq,
        dur=6.0 - 3.0 * r,
        bright=0.25 + 0.5 * v + 0.1 * r,
        decay=7.0 - 4.2 * r,
        pick_position=0.14,
        velocity=v,
        sr=ctx.sr,
        seed=ctx.seed,
    )
    box = ctx.load("cypress_body.wav")
    # the box colours the string but must not smear it: half wet, then trim the resonance tail
    out = string.convolve(box, mix=0.55).to_mono().fit(string.duration)
    # no sub-rumble below the lowest string; tame the box's nasal bump
    out = out.highpass(48, order=2).peak(2800, -2.5, 0.9)
    return out.normalize_loudness(-15.0 - 7.0 * (1.0 - v))


@sound.attack
def attack(ctx):
    # the plectrum, harder and brighter on strong notes
    p = ctx.load("pick.wav")
    if ctx.velocity < 80:
        p = p.lowpass(5000).gain_db(-5)
    return p


@sound.tail
def tail(ctx):
    return ctx.load("release.wav")


@sound.air
def air(ctx):
    # a quiet stone room: pink noise, dark, gently moving
    room = synth.breath(8.0, sr=ctx.sr, seed=21, brightness=0.15, motion=0.25)
    return room.lowpass(3500).highpass(90).normalize_rms(-44)


@sound.impulse
def ir(ctx):
    return synth.impulse_response("room", sr=ctx.sr, seed=12, t60=1.1)


sound.defaults(
    amp_attack=0.5,
    amp_decay=6000,
    amp_sustain=1.0,
    amp_release=650,
    lvl_attack=-4,
    lvl_tail=-9,
    lvl_air=-22,
    vel_sens=0.6,
    rev_mode="Cappella",
    rev_size=0.45,
    rev_decay=1.9,
    rev_mix=0.22,
    res_mode="Corde",
    res_decay=0.55,
    res_bright=0.4,
    res_mix=0.1,
)
