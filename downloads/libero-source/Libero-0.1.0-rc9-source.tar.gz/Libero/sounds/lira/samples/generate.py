"""Regenerate the synthesised source samples of Lira.

    uv --directory python run python ../sounds/lira/samples/generate.py   # from the repo root
"""

from pathlib import Path

import numpy as np

from libero import Audio, synth

HERE = Path(__file__).resolve().parent
SR = 48000


def cypress_body() -> Audio:
    """Impulse response of a small cypress soundbox: a Helmholtz air mode near
    120 Hz, top-plate modes up to ~3 kHz, all short (cypress is light and dry)."""
    modes = [
        # (Hz, t60 s, amp)
        (118, 0.16, 0.9), (205, 0.12, 1.0), (262, 0.09, 0.55), (331, 0.08, 0.7), (418, 0.07, 0.6),
        (507, 0.06, 0.45), (644, 0.05, 0.5), (788, 0.045, 0.35), (962, 0.04, 0.35), (1180, 0.035, 0.28),
        (1490, 0.03, 0.22), (1905, 0.025, 0.16), (2410, 0.02, 0.12), (3120, 0.015, 0.08),
    ]
    rng = np.random.default_rng(7)
    n = int(0.35 * SR)
    t = np.arange(n) / SR
    y = np.zeros(n)
    # all modes in phase, as at a driving point (the bridge): keeps the anti-resonances shallow,
    # so no string loses its fundamental in a notch
    for f, t60, a in modes:
        y += a * np.exp(-6.91 * t / t60) * np.sin(2 * np.pi * f * t)
    grain = rng.standard_normal(n) * np.exp(-6.91 * t / 0.02) * 0.25  # wood grain: a short noisy smear
    y += Audio(grain, SR).lowpass(5000).data
    y *= 0.0125
    y[0] += 1.0  # the direct string-to-bridge path dominates; the box only colours
    return Audio(y, SR).remove_dc(20).fade_out(0.05).normalize(-1)


def pick() -> Audio:
    """A horn plectrum: bright click, a tiny scrape along the winding, a soft low thump."""
    click = synth.noise("white", 0.01, sr=SR, seed=3).bandpass(4200, q=0.8).highpass(1500)
    click = click.envelope([(0, 0), (0.0003, 1), (0.003, 0.2), (0.01, 0)])
    scrape = synth.noise("pink", 0.03, sr=SR, seed=4).bandpass(2600, q=1.5)
    scrape = scrape.envelope([(0, 0), (0.002, 0.35), (0.03, 0)])
    f = np.linspace(190, 110, int(0.035 * SR))
    thump = synth.sine(f, 0.035, sr=SR).envelope([(0, 0), (0.0015, 1), (0.035, 0)])
    return click.mix(scrape, thump.gain_db(-11)).pad(after=0.01).normalize(-6)


def release() -> Audio:
    """A fingertip landing on the string to stop it: soft pad noise and a dull tap."""
    touch = synth.noise("pink", 0.12, sr=SR, seed=5).bandpass(1100, q=0.6).lowpass(3500)
    touch = touch.envelope([(0, 0), (0.006, 1), (0.03, 0.35), (0.12, 0)])
    tap = synth.sine(np.linspace(160, 120, int(0.05 * SR)), 0.05, sr=SR).envelope([(0, 0), (0.002, 1), (0.05, 0)])
    return touch.mix(tap.gain_db(-8)).normalize(-12)


if __name__ == "__main__":
    for name, fn in (("cypress_body", cypress_body), ("pick", pick), ("release", release)):
        a = fn()
        a.save(HERE / f"{name}.wav")
        print(f"{name}.wav  {a}")
