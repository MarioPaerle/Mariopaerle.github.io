# Lira

A plucked lyre with a small cypress soundbox: gut-warm in the bass, short and silvery at the top, played close in a stone chapel. Pick and finger are separate layers so the player can bring the plectrum forward or hide it.

## Intent

The ancient lyre as a living instrument, not a harp preset: a round, slightly nasal string, a light and dry box (cypress, not spruce), the click of a horn plectrum, and the soft stop of a fingertip when a note is released.

## How it is built

- **Body**: extended Karplus–Strong, exactly tuned by an allpass, excited by the string's plucked shape (a triangle at 14 % of the length) plus a little grain. The loop filter is scaled per string so upper partials fade at a similar rate on every string. Decay goes from ~7 s (D2) to ~2.8 s (D#6). Two velocity layers: the soft one is darker, not just quieter.
- **Cypress box**: `samples/cypress_body.wav`, fourteen damped modes (Helmholtz air mode near 118 Hz, top-plate modes to 3 kHz) summed in phase at a strong direct path, convolved at mix 0.55. The in-phase sum keeps anti-resonances shallow, so no string loses its fundamental in a notch (an earlier random-phase box dug a −22 dB hole at C#5).
- **Attack**: `samples/pick.wav` — bright 3 ms click, a scrape along the winding, a 190→110 Hz thump. Low-passed and 5 dB down on the soft layer.
- **Tail**: `samples/release.wav` — a fingertip landing on the string.
- **Air**: a dark, slowly moving stone-room bed.
- **Impronta IR**: a small room (T60 ≈ 1.1 s).

Every body zone is normalised to the same momentary loudness (−15.8 LUFS loud, −18.9 LUFS soft) so the range sounds even.

## Defaults

Cappella reverb (22 %), Corde resonator low (10 %) for a hint of sympathetic strings, sustain held at full so the string rings under the key, 650 ms release.

## Regenerating the samples

`samples/generate.py` rebuilds the three WAVs deterministically.
