"""Coro di marmo — a vaporwave choir: a small ensemble of detuned voices singing a slow
'a'→'o', breath in the air, everything on a loop grid so the sustain never seams."""

import math

from libero import Sound, synth

sound = Sound(
    title="Coro di marmo",
    subtitle="coro vaporwave, aria di statue",
    tags=["choir", "pad", "vaporwave", "vocal", "sustained"],
    roots=[36, 43, 50, 57, 64, 71, 78, 85],
    velocities=[100],
    sample_rate=48000,
    accent="#d9a3b8",
)

LOOP_S = 5.0
# (detune cents, pan, vibrato Hz, vibrato cents, level dB): seven singers, none in unison
VOICES = [
    (-13.0, -0.75, 4.8, 11.0, -1.0),
    (-7.0, 0.55, 5.4, 9.0, 0.0),
    (-2.5, -0.25, 5.0, 13.0, 0.0),
    (0.0, 0.0, 5.2, 10.0, 0.0),
    (3.0, 0.3, 4.6, 12.0, -0.5),
    (8.0, -0.55, 5.6, 8.0, -1.0),
    (14.0, 0.8, 4.9, 10.0, -2.0),
]


def vowels(L: float):
    # a → o → a …, one full breath per loop, so the morph is periodic too
    return [(k * L / 2, "a" if k % 2 == 0 else "o") for k in range(6)]


@sound.body
def body(ctx):
    g = synth.LoopGrid(ctx.freq, LOOP_S, ctx.sr)
    dur = 1.2 + 2 * g.seconds
    choir = None
    for i, (cents, pan, vib_hz, vib_c, lvl) in enumerate(VOICES):
        f = synth.vibrato(g.cents(cents), rate=g.rate(vib_hz), cents=vib_c, delay=0.0, phase=1.7 * i)
        v = synth.saw(f, dur, sr=ctx.sr, phase=(0.37 * i) % 1.0).gain_db(lvl).pan(pan)
        choir = v if choir is None else choir.mix(v)
    # a quiet sub-octave singer gives the marble its weight (not in the top register)
    lowest = g.freq
    if ctx.note < 72:
        lowest = g.freq / 2
        sub = synth.saw(synth.vibrato(g.snap(g.freq / 2), rate=g.rate(4.4), cents=8, delay=0.0), dur, sr=ctx.sr,
                        phase=0.61)
        choir = choir.mix(sub.gain_db(-10 - 8 * (ctx.note - 36) / 36))
    # breathiness: periodic noise (tiled over the loop) sung through the same mouth
    breath = synth.noise("pink", g.seconds, sr=ctx.sr, seed=ctx.seed, stereo=True).tile(dur).highpass(300)
    choir = choir.mix(breath.normalize_rms(choir.rms_db - 24))
    shift = 1.0 + 0.08 * ctx.register  # higher roots: slightly younger voices
    sung = synth.formant(choir, vowels(g.seconds), amount=0.85, shift=shift)
    # cassette warmth: a little saturation, then a soft top (after it, so the saturation's own
    # harmonics are filtered too); its slow difference tones between detuned singers are cut
    # below the lowest voice. The plugin's tape adds the wobble.
    sung = sung.saturate(0.12).lowpass(6500, q=0.6, order=2).highshelf(3000, -3)
    sung = sung.highpass(max(30.0, 0.7 * lowest), order=2)
    return sung.fade_in(0.25).normalize_loudness(-16.0)


@sound.attack
def attack(ctx):
    return ctx.load("breath_in.wav")


@sound.tail
def tail(ctx):
    return ctx.load("breath_out.wav")


@sound.air
def air(ctx):
    return synth.breath(10.0, sr=ctx.sr, seed=61, brightness=0.35, motion=0.55).normalize_rms(-40)


@sound.impulse
def ir(ctx):
    # a stone cistern: long, dark, with a few slap-backs off the vault
    return synth.impulse_response("cave", sr=ctx.sr, seed=23, t60=6.0)


sound.loop(body=True, min_seconds=4.0, region=(1.0, 1.2 + 2 * LOOP_S))
sound.defaults(
    amp_attack=1400,
    amp_decay=3000,
    amp_sustain=0.85,
    amp_release=4200,
    amp_curve=0.3,
    lvl_attack=-8,
    lvl_tail=-10,
    lvl_air=-16,
    air_follow=0.6,
    vel_sens=0.4,
    tape_wow=0.0,
    tape_flutter=0.0,
    tape_sat=0.25,
    tape_age=0.45,
    tape_mix=0.7,
    echo_time=480,
    echo_feedback=0.4,
    echo_tone=0.35,
    echo_spread=0.7,
    echo_mix=0.12,
    rev_mode="Cisterna",
    rev_size=0.85,
    rev_decay=7.5,
    rev_predelay=45,
    rev_damp=0.55,
    rev_mix=0.38,
    width=1.2,
)
