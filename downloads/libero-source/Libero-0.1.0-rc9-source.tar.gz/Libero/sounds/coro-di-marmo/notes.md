# Coro di marmo

A vaporwave choir: seven detuned voices singing a slow "a" that opens into "o" and back, breath in the air, a faint sub-octave singer under the low notes, all of it slightly worn like a cassette left in the sun. Statues singing in a cistern.

## Intent

Not a realistic choir but the memory of one: warm saws shaped into vowels, gentle chorus, a long slow attack, an inhale before the chord and an exhale when it ends, tape wobble and a stone cistern around it.

## How it is built

- **Body** (looped, stereo): seven band-limited saws detuned −13…+14 cents, each with its own vibrato (4.6–5.6 Hz, 8–13 cents, different phases) and pan; below C5 a sub-octave voice 10–16 dB down. Breathiness is tiled pink noise sung through the same mouth. A five-formant vowel bank morphs a→o→a once per loop. Saturation, then a soft 6.5 kHz top, then a high-pass under the lowest voice (removes the slow difference tones the saturation makes between detuned singers). Every frequency, vibrato rate and the vowel cycle sit on a 5 s `LoopGrid` (block-aligned for the formant filter; the vibrato keeps its mean frequency exact), so each loop is exact: seam −120 dB. Voices start at different phases, otherwise their edges realign into a click once per loop.
- **Attack**: `samples/breath_in.wav`, the shared inhale.
- **Tail**: `samples/breath_out.wav`, a falling "ho".
- **Air**: `synth.breath`, moving, 60 % note-following.
- **Impronta IR**: a synthetic cistern (cave, T60 6 s, slap-backs).

## Defaults

Tape wow/flutter default to 0. The choir keeps its designed singer vibrato, detuned voices, saturation, EQ, cisterna room and echo; tape drift is an optional live choice. Cisterna reverb 38 %, 7.5 s. A low echo (480 ms, 12 %). 1.4 s attack, 4.2 s release, width 1.2 (wider than that and the mono sum of the reverberant output loses the choir).

## Regenerating the samples

`samples/generate.py` rebuilds the two breath WAVs.
