"""Regenerate the synthesised source samples of Vetro.

    uv --directory python run python ../sounds/vetro/samples/generate.py   # from the repo root
"""

from pathlib import Path

import numpy as np

from libero import Audio, synth

HERE = Path(__file__).resolve().parent
SR = 48000


def rub() -> Audio:
    """A wet fingertip dragging on a glass rim: friction noise chopped by irregular
    stick-slip (40–70 Hz), full-band so the recipe can focus it on any note, with a
    squeaky lift around 1.8 kHz."""
    dur = 1.2
    n = int(dur * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(31)
    rate = 55 + 12 * np.interp(t, np.linspace(0, dur, 9), rng.standard_normal(9))
    ph = np.cumsum(rate / SR)
    slip = np.clip(np.sin(2 * np.pi * ph), 0, 1) ** 3  # short bursts, one per slip
    fr = synth.noise("pink", dur, sr=SR, seed=32).data * (0.25 + slip)
    a = Audio(fr, SR).highpass(70, order=2).lowpass(7000).peak(1800, 4, 0.7)
    return a.envelope([(0, 0), (0.25, 1.0), (0.8, 0.8), (1.2, 0)]).normalize(-6)


def lift() -> Audio:
    """The finger leaving the rim: a short rising squeak and a breath of noise."""
    dur = 0.22
    n = int(dur * SR)
    f = np.linspace(2300, 3100, n)
    squeak = synth.sine(f, dur, sr=SR).envelope([(0, 0), (0.02, 0.6), (0.08, 0.25), (0.22, 0)])
    hiss = synth.noise("pink", dur, sr=SR, seed=33).bandpass(2600, q=0.9)
    hiss = hiss.envelope([(0, 0), (0.01, 1), (0.22, 0)])
    return squeak.gain_db(-14).mix(hiss).normalize(-10)


if __name__ == "__main__":
    for name, fn in (("rub", rub), ("lift", lift)):
        a = fn()
        a.save(HERE / f"{name}.wav")
        print(f"{name}.wav  {a}")
