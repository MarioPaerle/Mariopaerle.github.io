"""Restore finite recorded nylon decays and remove baked clean-guitar saturation."""
from pathlib import Path
import json, shutil, hashlib

ROOT = Path.home()/'Libero'
BANK = ROOT/'banks/chitarre'
BACKUP = ROOT/'demo/guitar-natural-decays-2026-10-07'
BACKUP.mkdir(parents=True,exist_ok=True)
for slug in ('chitarra-classica-libero','chitarra-classica-accordi-libero','chitarra-elettrica-pulita'):
    folder = BANK/slug
    saved = BACKUP/slug
    if not saved.exists():
        saved.mkdir()
        shutil.copy2(folder/'sound.py',saved/'sound.py')
        shutil.copy2(folder/'samples/map.json',saved/'map.json')
        shutil.copytree(folder/'build',saved/'build')
    if slug.startswith('chitarra-classica'):
        mapping = json.loads((folder/'samples/map.json').read_text())
        for region in mapping['body']:
            if slug == 'chitarra-classica-accordi-libero':
                natural = folder/'samples/derived/chord-source'/f"{region['root']:03d}-{region['articulation']}.wav"
            else:
                stem = Path(region['file']).stem.removesuffix('-hold')
                matches = [p for p in (folder/'samples/originals/freepats-nylon').rglob('*')
                           if p.is_file() and p.stem==stem and p.suffix.lower() in ('.wav','.flac')]
                assert len(matches)==1,(stem,matches)
                natural = matches[0]
            assert natural.is_file(),natural
            region['file'] = natural.relative_to(folder/'samples').as_posix()
            region.pop('loop',None)
        (folder/'samples/map.json').write_text(json.dumps(mapping,indent=2)+'\n')
        recipe = (folder/'sound.py').read_text().replace("'loop':'source'","'loop':'none'")
        recipe = recipe.replace('recorded notes and tail modelled from the same take','recorded nylon strings, natural decay')
        (folder/'sound.py').write_text(recipe)
        (folder/'notes-natural-decay.md').write_text('Uses the original recorded decay. No sustain continuation or playback loop.\n'
            + ('Chords use the existing pitch-corrected four-note strums before sustain modelling.\n' if 'accordi' in slug else 'Original FreePats notes retain their keyboard mapping and static tuning correction.\n'))
    else:
        recipe = (folder/'sound.py').read_text()
        lines = [line for line in recipe.splitlines() if 'x = amp.tube(' not in line]
        recipe = '\n'.join(lines)+'\n'
        recipe = recipe.replace('baked clean amp stage','linear clean amp stage').replace('Hofner Club, amp clean, kick drum recorded','Hofner Club, clean amp, recorded plucks')
        (folder/'sound.py').write_text(recipe)
print('Backups saved; recipes and source maps updated.')
