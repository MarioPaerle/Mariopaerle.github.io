#!/usr/bin/env python3
"""Apply a reviewed, measured master-gain plan without altering sample audio."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import math
from pathlib import Path
import shutil


def recipe_audio_ast(text: str) -> str:
    tree = ast.parse(text)
    tree.body = [node for node in tree.body if not (
        isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
        and isinstance(node.value.func, ast.Attribute)
        and node.value.func.attr in ("defaults", "retitle"))]
    return ast.dump(tree, annotate_fields=False)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--banks", type=Path, required=True)
    parser.add_argument("--backup", type=Path)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    entries = plan["entries"]
    changes = []
    seen = set()
    for entry in entries:
        gain = float(entry["gain_db"])
        if not math.isfinite(gain) or not 1 <= gain <= 12:
            raise ValueError("each reviewed boost must be within 1..12 dB")
        folder = (args.banks / entry["bank"] / entry["slug"]).resolve()
        if args.banks.resolve() not in folder.parents or folder in seen:
            raise ValueError("unsafe or duplicate sound path")
        seen.add(folder)
        manifest_path = folder / "build/manifest.json"
        recipe_path = folder / "sound.py"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        before = float(manifest.get("params", {}).get("master", 0))
        if abs(before - float(entry["current_master_db"])) > 0.001:
            raise ValueError(f"master changed since measurement: {folder}")
        if manifest["source_hash"] != entry["source_hash"]:
            raise ValueError(f"source changed since measurement: {folder}")
        after = math.floor((before + gain) * 10 + 1e-8) / 10
        if after > 6 or after < -60:
            raise ValueError(f"master outside supported range: {folder}")
        old_recipe = recipe_path.read_text(encoding="utf-8")
        new_recipe = old_recipe.rstrip() + f"\nsound.defaults(master={after!r})\n"
        if recipe_audio_ast(old_recipe) != recipe_audio_ast(new_recipe):
            raise ValueError(f"calibration changes the audio recipe: {folder}")
        manifest.setdefault("params", {})["master"] = after
        changes.extend([(recipe_path, new_recipe), (manifest_path, json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")])
    print(f"Reviewed {len(entries)} presets; sample files and audio recipes are unchanged.")
    if not args.apply:
        print("Dry run. Pass --apply and a new --backup directory to write these defaults.")
        return
    if args.backup is None or args.backup.exists():
        raise ValueError("--apply requires a new backup directory")
    args.backup.mkdir(parents=True)
    inventory = []
    for path, _ in changes:
        relative = path.relative_to(args.banks.resolve())
        copy = args.backup / relative
        copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, copy)
        inventory.append({"path": relative.as_posix(), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    (args.backup / "inventory.json").write_text(json.dumps(inventory, indent=2) + "\n", encoding="utf-8")
    try:
        for path, contents in changes:
            temporary = path.with_name(path.name + ".calibration-tmp")
            temporary.write_text(contents, encoding="utf-8")
            temporary.replace(path)
    except Exception:
        for path, _ in changes:
            shutil.copy2(args.backup / path.relative_to(args.banks.resolve()), path)
            path.with_name(path.name + ".calibration-tmp").unlink(missing_ok=True)
        raise
    print(f"Applied {len(entries)} preset levels; original metadata saved to {args.backup}.")


if __name__ == "__main__":
    main()
