#!/usr/bin/env python3
"""Relabel display metadata and assemble the reviewed 0.1.6 packs with nine basses."""
import ast, hashlib, json, os, re, shutil, sys, zipfile
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python'))
from libero import library, licenses
HOME=Path('/Users/mario/Libero')
OLD=HOME/'releases/final-refresh-2026-10-07'
OUT=HOME/'releases/names-and-bass-0.1.6'
STAGE=OUT/'staging-home/banks'
NAMES={'archi':'Strings','bassi':'Bass','chitarre':'Guitars','flauti':'Flutes','ottoni':'Brass','percussioni':'Percussion','sintesi':'Synthesis'}
ART={
 'Dita':'Fingerstyle','Corda aperta':'Open String','Gesti e rumori':'Gestures and Noise','Muto':'Muted','Notturno':'Quiet',
 'Dietro il ponte':'Behind the Bridge','Gesti al ponte':'Bridge Gestures','Ponte aperto':'Open Bridge','Percussioni':'Percussion',
 'Aperto':'Open','Pizzicata':'Plucked','Accordo maggiore · strum composto':'Major Chord · Assembled Strum',
 'Accordo minore · strum composto':'Minor Chord · Assembled Strum','Continuo':'Continuous',
 'Basso otto':'Bass 8′','Basso pieno':'Full Bass','Basso sedici I':'Bass 16′ I','Basso sedici II':'Bass 16′ II',
 'Quinta corda':'Fifth String','Otto piedi':'8′ Stop','Quattro piedi · ottava':'4′ Stop · Octave',
 'Pieno':'Full','Pieno rock':'Rock Full','Plettrata ascendente':'Upstroke','Plettrata discendente':'Downstroke',
 'Armonici e corde smorzate':'Harmonics and Muted Strings','Gesti di dita':'Finger Gestures','Sfregamento lento':'Slow Bowing',
 'Sfregamento rapido':'Fast Bowing','Soffietto':'Bellows','Tastiera':'Keyboard','Corde melodiche':'Melody Strings',
 'Registrazione originale':'Original Recording','Registro tremolo':'Tremolo Register','Percussione':'Percussion',
 'Clarinetto':'Clarinet','Corde':'Strings','Flauti':'Flutes','Tromba':'Trumpet','Violini':'Violins',
 'Dritta':'Straight','Morbida':'Soft','Normale':'Normal','Raschio':'Scrape','Risonanza':'Resonance',
 'Seconda Risonanza':'Second Resonance','Secondo Colpo':'Second Strike','Senza pedale':'Without Pedal',
 'Corde aperte':'Open Strings','Corda':'String','Arco':'Bowed','Vibrata':'Vibrato','Staccata':'Staccato',
 'Molto vibrato':'Strong Vibrato','Senza vibrato':'Without Vibrato','Trillo di semitono':'Half-Step Trill',
 'Trillo di tono':'Whole-Step Trill','Sostenuto senza vibrato':'Sustain Without Vibrato',
 'Sul ponticello':'Near the Bridge','Sul tasto':'Over the Fingerboard','Con sordino':'Muted',
 'Col legno battuto':'Col Legno · Struck','Col legno tratto':'Col Legno · Bowed','Au talon':'At the Frog',
 'Scivolate armoniche · integrali':'Harmonic Slides · Complete','Ordinario (TinySOL)':'Normal (TinySOL)',
 'Pizzicato Bartok (snap)':'Bartók Pizzicato (Snap)','Sostenuto':'Sustain','Colpo':'Strike',
}
WORDS={'sostenuto':'Sustain','sostenuti':'Sustain','colpo':'Strike','naturale':'Natural','registrato':'Recorded',
 'registrati':'Recorded','registrazione':'Recording','riprese':'Takes','sezione reale':'Recorded Section',
 'corpo tenuto':'Held Body','corpo derivato':'Derived Body','decadimento registrato':'Recorded Decay',
 'mazza dura':'Hard Mallet','mazza media':'Medium Mallet','mazza morbida':'Soft Mallet',
 'gesti percussivi':'Percussive Gestures','gesti':'Gestures','microfono':'Microphone','coro':'Choir',
 'apertura':'Opening','armonici':'Harmonics','breve':'Short','seconda':'Second','corde':'Strings',
 'sustain modale dalla presa':'Modal Sustain from the Recording','plettro celtico':'Celtic Pick','arco':'Bowed','dita':'Fingerstyle'}
def display(text):
 if text in ART:return ART[text]
 for a,b in sorted(WORDS.items(),key=lambda x:-len(x[0])):
  text=re.sub(r'(?<!\w)'+re.escape(a)+r'(?!\w)',b,text,flags=re.I)
 return text
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(4194304),b''):h.update(chunk)
 return h.hexdigest()
def write(p,value):
 p.parent.mkdir(parents=True,exist_ok=True)
 temp=p.with_name(p.name+'.names-tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');os.replace(temp,p)
def relabel(folder,backup):
 src=folder/'sound.py'
 if src.exists():
  raw=src.read_bytes();lines=raw.splitlines(keepends=True);changes=[]
  for node in ast.walk(ast.parse(raw.decode())):
   if not isinstance(node,ast.Dict):continue
   for k,v in zip(node.keys,node.values):
    if isinstance(k,ast.Constant) and k.value=='name' and isinstance(v,ast.Constant) and isinstance(v.value,str):
     new=display(v.value)
     if new!=v.value:changes.append((sum(map(len,lines[:v.lineno-1]))+v.col_offset,sum(map(len,lines[:v.end_lineno-1]))+v.end_col_offset,repr(new).encode()))
  if changes:
   backup.mkdir(parents=True,exist_ok=True);shutil.copy2(src,backup/'sound.py')
   for start,end,value in sorted(changes,reverse=True):raw=raw[:start]+value+raw[end:]
   temp=src.with_name('sound.py.names-tmp');temp.write_bytes(raw);os.replace(temp,src)
  source_hash=library.source_hash(folder) if changes else None
 else:source_hash=None
 old_hash=None
 for name in ['manifest.json','info.json']:
  p=folder/'build'/name
  if not p.exists():continue
  m=json.loads(p.read_text());before=json.dumps(m,sort_keys=True)
  for art in m.get('articulations',[]):art['name']=display(art.get('name',''))
  if name=='manifest.json':
   old_hash=m.get('source_hash')
   if source_hash:m['source_hash']=source_hash
  if json.dumps(m,sort_keys=True)!=before:
   backup.mkdir(parents=True,exist_ok=True);shutil.copy2(p,backup/name);write(p,m)
 sidecar=folder/'sample-edits.json'
 if source_hash and sidecar.exists():
  m=json.loads(sidecar.read_text())
  for edit in m.get('edits',{}).values():
   if edit.get('source_hash')==old_hash:edit['source_hash']=source_hash
  shutil.copy2(sidecar,backup/'sample-edits.json');write(sidecar,m)
def proof(slug):
 folder=HOME/'banks/bassi'/slug;maps=json.loads((folder/'samples/map-bassi.json').read_text());entries=[]
 trees={}
 for layer,rows in maps.items():
  for row in rows:
   path=Path(row['file']);source=path.parts[0];relative=Path(*path.parts[1:]).as_posix()
   if source not in trees:trees[source]=json.loads((HOME/'cache/libraries'/source/'tree-api.json').read_text())
   upstream=next(x for x in trees[source]['tree'] if x['path']==relative)
   f=folder/'samples'/path;data=f.read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   assert blob==upstream['sha'],f
   entries.append(dict(layer=layer,file=path.as_posix(),git_blob=blob,tree=trees[source]['sha']))
 assert len(entries)==len(json.loads((folder/'build/manifest.json').read_text())['zones'])
 return dict(slug=slug,verified_source_regions=len(entries),sources={s:t['sha'] for s,t in trees.items()},regions=entries)
def main():
 if OUT.exists() and '--resume' not in sys.argv:raise SystemExit('Output already exists; preserve it or choose a fresh release directory.')
 OUT.mkdir(parents=True,exist_ok=True)
 reports=[proof(s) for s in ['contrabbasso-jazz','basso-flatwound','basso-hollowbody']]
 write(OUT/'bass-source-verification.json',reports)
 for root in [HOME/'banks',HOME/'sounds',HOME/'sketches']:
  for mf in sorted(root.glob('*/build/manifest.json')) if root.name!='banks' else sorted(root.glob('*/*/build/manifest.json')):
   folder=mf.parent.parent;relabel(folder,OUT/'metadata-backup'/folder.relative_to(HOME))
 for slug,title in NAMES.items():
  p=HOME/'banks'/slug/'bank.json'
  if p.exists():m=json.loads(p.read_text());m['title']=title;write(p,m)
 shutil.copytree(OLD/'staging-home/banks',STAGE,dirs_exist_ok=True)
 for slug in ['contrabbasso-jazz','basso-flatwound','basso-hollowbody','sub-ancora','sub-legno','sub-rimbalzo']:
  src=HOME/'banks/bassi'/slug;dst=STAGE/'bassi'/slug;dst.mkdir(parents=True,exist_ok=True)
  for p in library._pack_sound_files(src):
   target=dst/p.relative_to(src);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
  if slug.startswith('sub-'):
   credits=[dict(source='Original Libero oscillator synthesis',author='Mario Prignano / Libero',license='CC0 1.0',license_class='cc0',url='https://creativecommons.org/publicdomain/zero/1.0/')]
   assert not json.loads((src/'build/manifest.json').read_text())['zones']
   write(dst/'samples/credits.json',credits)
  else:
   shutil.copy2(src/'samples/map-bassi.json',dst/'samples/map-bassi.json')
   for source in json.loads((src/'samples/map-bassi.json').read_text())['body']:
    name=Path(source['file']).parts[0];base=HOME/'cache/libraries'/name
    license=base/('license' if (base/'license').exists() else 'LICENSE')
    target=dst/'samples/licenses'/name/'LICENSE';target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(license,target)
   report=next(r for r in reports if r['slug']==slug);write(dst/'samples/licenses/source-verification.json',report)
  (dst/'SOUND-DATA-TERMS.md').write_bytes((ROOT/'docs/release/sound-data-terms.md').read_bytes())
 cat=json.loads((OLD/'Packs/Single Packs and terms/catalog.json').read_text());single=OUT/'Packs/Single Packs and terms';single.mkdir(parents=True,exist_ok=True)
 for pack in cat['packs']:
  bank=pack['bank'];folder=STAGE/bank;meta=json.loads((folder/'bank.json').read_text());meta.update(title=NAMES.get(bank,meta['title']),version='0.1.6');write(folder/'bank.json',meta)
  programmes=[]
  if bank=='bassi':
   for diagnostic in folder.glob('*/build/*.png'):diagnostic.unlink()
  for p in sorted(folder.glob('*/build/manifest.json')):
   f=p.parent.parent;relabel(f,OUT/'staging-metadata-backup'/bank/f.name)
   m=json.loads(p.read_text());credits=licenses.read_credits(f) or m.get('credits',[])
   assert licenses.bundle_license(credits)[1] in ('cc0','by','gpl'),f
   assert not library.validate_bundle(f/'build'),f
   programmes.append(dict(slug=f.name,title=m['title'],source_hash=m['source_hash'],license_class=licenses.bundle_license(credits)[1],runtime_files={q.relative_to(f/'build').as_posix():sha(q) for q in sorted((f/'build').rglob('*')) if q.is_file()}))
  filename=NAMES.get(bank,bank).lower()+'-0.1.6.liberobank'
  archive=single/filename
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9 if bank in ('bassi','chitarre') else 3,allowZip64=True) as z:
   for p in sorted(folder.rglob('*')):
    if p.is_file():z.write(p,p.relative_to(STAGE).as_posix())
  pack.update(file=filename,presets=len(programmes),programmes=programmes,sha256=sha(archive),bytes=archive.stat().st_size)
  print(filename,len(programmes),flush=True)
 cat.update(version='0.1.6',preset_count=sum(p['presets'] for p in cat['packs']),compressed_bytes=sum(p['bytes'] for p in cat['packs']))
 write(single/'catalog.json',cat)
 for name in ['SOUND-DATA-TERMS.md','README.txt']:shutil.copy2(OLD/'Packs/Single Packs and terms'/name,single/name)
 readme=single/'README.txt';text=readme.read_text().replace('0.1.5','0.1.6').replace('89 presets','95 presets');readme.write_text(text+'\nBass contains Jazz Double Bass, Flatwound Bass, Hollowbody Bass, three subs and three 808s.\n')
 (single/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(single.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
 groups=[[],[]];sizes=[0,0]
 for pack in sorted(cat['packs'],key=lambda x:-x['bytes']):
  index=0 if sizes[0]<=sizes[1] else 1;groups[index].append(pack);sizes[index]+=pack['bytes']
 for i,group in enumerate(groups,1):
  with zipfile.ZipFile(OUT/'Packs'/f'Libero-Base-Bundle-0.1.6-Part-{i}.zip','w',zipfile.ZIP_STORED,allowZip64=True) as z:
   for pack in group:z.write(single/pack['file'],'Banks/'+pack['file'])
   for name in ['catalog.json','SOUND-DATA-TERMS.md','README.txt','SHA256SUMS']:z.write(single/name,'Banks/'+name)
 (OUT/'Packs/SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted((OUT/'Packs').glob('*.zip'))))
 print('Ready',cat['preset_count'],sizes,flush=True)
if __name__=='__main__':main()
