param()
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$repo = gh repo view --json isPrivate --jq .isPrivate
if ($LASTEXITCODE -ne 0 -or $repo -ne 'true') { throw "This preview transport requires a private repository" }
$tag = "windows-preview-$env:GITHUB_RUN_ID-$env:GITHUB_RUN_ATTEMPT"
$notes = Join-Path $env:RUNNER_TEMP "windows-preview-notes.md"
@"
Internal Windows test build from $env:GITHUB_SHA.

Inspect verification logs and the release manifest before sharing a build.
This draft is not a public release. Sound banks are supplied separately.
"@ | Set-Content $notes -Encoding utf8
& gh release create $tag --draft --target $env:GITHUB_SHA --title "Libero Windows preview — run $env:GITHUB_RUN_ID" --notes-file $notes
if ($LASTEXITCODE) { throw "Could not create the private draft" }
$checks = Join-Path $root 'plugin/tests/out/windows'
if (Test-Path $checks) {
    $archive = Join-Path $env:RUNNER_TEMP "Windows-verification-$env:GITHUB_RUN_ID.zip"
    Compress-Archive -Path "$checks/*" -DestinationPath $archive
    & gh release upload $tag $archive
    if ($LASTEXITCODE) { throw "Could not save verification logs" }
}
$output = Join-Path $root 'build/windows/release'
if (Test-Path "$output/release-manifest.json") {
    $files = @(Get-ChildItem $output -File | ForEach-Object { $_.FullName })
    & gh release upload $tag @files
    if ($LASTEXITCODE) { throw "Could not save Windows packages" }
} elseif (Test-Path "$root/build/windows/plugin/Libero_artefacts/Release/VST3/Libero.vst3") {
    $debug = Join-Path $env:RUNNER_TEMP "Windows-unverified-$env:GITHUB_RUN_ID.zip"
    Compress-Archive -Path "$root/build/windows/plugin/Libero_artefacts/Release/VST3/Libero.vst3" -DestinationPath $debug
    & gh release upload $tag $debug
    if ($LASTEXITCODE) { throw "Could not save the unverified plugin" }
}
