#!/usr/bin/env python3
"""Repackage a frozen sound selection with current terms; preserve audio bytes."""
from __future__ import annotations
import argparse, copy, hashlib, json, re, shutil, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'python'))
from libero import library, licenses

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda: f.read(4*1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--version',required=True)
    ap.add_argument('--finalize-original-cc0',action='store_true',help='Use only after rights-holder approval')
    a=ap.parse_args()
    if not re.fullmatch(r'\d+\.\d+\.\d+',a.version): ap.error('invalid version')
    if a.output.exists(): ap.error('output exists')
    old=json.loads((a.input/'catalog.json').read_text())
    # Verify the complete input before creating an output directory.
    for pack in old['packs']:
        assert Path(pack['file']).name==pack['file']
        assert sha(a.input/pack['file'])==pack['sha256'], pack['file']
    a.output.mkdir(parents=True)
    terms=(ROOT/'docs/release/sound-data-terms.md').read_bytes()
    cat=copy.deepcopy(old); changed=[]; audio_count=0
    for pack in cat['packs']:
        source=a.input/pack['file']; target=a.output/f"{pack['bank']}-{a.version}.liberobank"
        with zipfile.ZipFile(source) as z:
            assert z.testzip() is None
            data={i.filename:z.read(i) for i in z.infolist()}
        root=pack['bank']
        for item in pack['programmes']:
            prefix=f"{root}/{item['slug']}/"
            cp=prefix+'samples/credits.json'
            credits=json.loads(data[cp]); assert credits
            modified=False
            for c in credits:
                if re.search(r'proposed|proposal|not published',c.get('license',''),re.I):
                    assert a.finalize_original_cc0, 'original dedication needs approval'
                    assert 'original' in c.get('source','').lower() and c.get('license_class')=='cc0'
                    c['license']='CC0 1.0'; modified=True
            if modified:
                changed.append(item['slug'])
                data[cp]=(json.dumps(credits,indent=2,ensure_ascii=False)+'\n').encode()
                for name in ('samples/ATTRIBUTION.md','build/ATTRIBUTION.md'):
                    if prefix+name in data: data[prefix+name]=licenses.attribution_text(credits).encode()
                mp=prefix+'build/manifest.json'; m=json.loads(data[mp])
                m['credits']=credits; m['license']=licenses.bundle_license(credits)[0]
                data[mp]=(json.dumps(m,indent=2,ensure_ascii=False)+'\n').encode()
                item['runtime_files']['manifest.json']=hashlib.sha256(data[mp]).hexdigest()
                if prefix+'build/ATTRIBUTION.md' in data:
                    item['runtime_files']['ATTRIBUTION.md']=hashlib.sha256(data[prefix+'build/ATTRIBUTION.md']).hexdigest()
            assert licenses.bundle_license(credits)[1] in ('cc0','by')
            data[prefix+'SOUND-DATA-TERMS.md']=terms
            for name, blob in data.items():
                if name.startswith(prefix+'build/') and name.lower().endswith(('.wav','.flac','.aif','.aiff')):
                    audio_count+=1
                    expected=item['runtime_files'][name[len(prefix+'build/'):]]
                    assert hashlib.sha256(blob).hexdigest()==expected
            item['runtime_files']={name[len(prefix+'build/'):]:hashlib.sha256(blob).hexdigest()
                for name,blob in data.items() if name.startswith(prefix+'build/')}
        bp=f'{root}/bank.json'; meta=json.loads(data[bp]); meta['version']=a.version
        meta['updated']=datetime.now(timezone.utc).isoformat()
        data[bp]=(json.dumps(meta,indent=2,ensure_ascii=False)+'\n').encode()
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
            for name,blob in data.items(): z.writestr(name,blob)
        with zipfile.ZipFile(target) as z: assert z.testzip() is None
        pack.update(file=target.name,sha256=sha(target),bytes=target.stat().st_size)
        print(f"Verified {target.name}: {pack['presets']} presets",flush=True)
    cat.update(created_utc=datetime.now(timezone.utc).isoformat(),
        status='Testing pre-release selection; original sound data CC0; third-party terms retained',
        version=a.version,compressed_bytes=sum(p['bytes'] for p in cat['packs']))
    (a.output/'catalog.json').write_text(json.dumps(cat,indent=2,ensure_ascii=False)+'\n')
    (a.output/'SOUND-DATA-TERMS.md').write_bytes(terms)
    (a.output/'README.txt').write_text(
        'Libero sound packs '+a.version+'\n\n75 presets in 11 collections, from the previously verified selection.\n'
        'Audio bytes are unchanged; this version updates terms and original-data license records.\n'
        'Import the .liberobank files through Libero Library. Review the installation summary.\n'
        'Existing collection identifiers can update installed collections; back up personal edits first.\n'
        'The full bundle contains the same instruments as the individual packs. Choose either download.\n'
        'CC0 sounds permit commercial music without attribution. The VocalSet choir requires CC BY credits.\n'
        'Read SOUND-DATA-TERMS.md and the per-preset credits. Software and demo-music rights are separate.\n'
        'Playback does not require Python. Compile recipes only if you trust their code.\n'
        'This selection excludes restricted/uncertain working-library instruments and authentic Mellotrons.\n'
        'Contact: paerle.music@gmail.com\n')
    proof={'input_catalog_sha256':sha(a.input/'catalog.json'),'audio_files_verified':audio_count,
        'audio_bytes_changed':0,'finalized_original_cc0':changed,
        'source_hash_note':'Original compiler source hashes retained as provenance; no recipe was recompiled.'}
    (a.output/'REPACK-RECORD.json').write_text(json.dumps(proof,indent=2)+'\n')
    files=sorted(p for p in a.output.iterdir() if p.is_file())
    (a.output/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in files))
    print(json.dumps(proof),flush=True)
if __name__=='__main__': main()
