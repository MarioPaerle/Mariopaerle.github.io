#!/usr/bin/env bash
# Configure + build Libero (Release, universal arm64/x86_64) into build/.
#   scripts/build.sh [extra cmake args...]
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
build="${LIBERO_BUILD_DIR:-$root/build}"

if [ ! -f "$root/third_party/JUCE/CMakeLists.txt" ]; then
    git -C "$root" submodule update --init --recursive
fi

cmake -S "$root" -B "$build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0 \
    "$@"

cmake --build "$build" --config Release

art="$build/plugin"
echo
echo "built:"
echo "  $art/Libero_artefacts/Release/VST3/Libero.vst3"
echo "  $art/Libero_artefacts/Release/AU/Libero.component"
echo "  $art/libero_render_artefacts/Release/libero-render"
