param(
    [string]$BuildDir = "",
    [string]$Configuration = "Release"
)
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
if (!$BuildDir) { $BuildDir = Join-Path $root "build/windows" }
$BuildDir = [IO.Path]::GetFullPath($BuildDir)
if (!(Test-Path "$root/third_party/JUCE/CMakeLists.txt")) {
    & git -C $root submodule update --init --recursive
    if ($LASTEXITCODE) { throw "JUCE checkout failed" }
}

$sdkVersion = "1.0.3485.44"
$packages = Join-Path $BuildDir "packages"
$sdk = Join-Path $packages "Microsoft.Web.WebView2.$sdkVersion"
if (!(Test-Path "$sdk/build/native/include/WebView2.h")) {
    New-Item -ItemType Directory -Force $packages | Out-Null
    $download = Join-Path $packages "webview2-sdk.zip"
    Invoke-WebRequest "https://api.nuget.org/v3-flatcontainer/microsoft.web.webview2/$sdkVersion/microsoft.web.webview2.$sdkVersion.nupkg" -OutFile $download
    Expand-Archive $download -DestinationPath $sdk -Force
    Remove-Item $download
}
& cmake -S $root -B $BuildDir -G "Visual Studio 17 2022" -A x64 "-DJUCE_WEBVIEW2_PACKAGE_LOCATION=$packages" -DLIBERO_BUILD_TESTS=ON
if ($LASTEXITCODE) { throw "CMake configuration failed" }
& cmake --build $BuildDir --config $Configuration --parallel 4
if ($LASTEXITCODE) { throw "Windows build failed" }
Write-Host "Built Windows x64 VST3, renderer and test host in $BuildDir"
