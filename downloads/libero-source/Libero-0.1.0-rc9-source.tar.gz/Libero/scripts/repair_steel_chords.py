"""Rebuild steel-guitar notes and chords from unclipped SF2 PCM with linear headroom."""
from pathlib import Path
import struct,json,shutil,re
import numpy as np
import soundfile as sf

home=Path.home()/'Libero';bank=home/'banks/chitarre';backup=home/'demo/guitar-natural-decays-2026-10-07'
source=home/'cache/libraries/flame-sf2/FS_Seagull_Steel_String_Acoustic_Guitar/FS Seagull Steel String Acoustic Guitar.sf2'
data=source.read_bytes()
def chunks(block):
    position=12 if block[:4]==b'RIFF' else 4
    while position+8<=len(block):
        tag=block[position:position+4];length=struct.unpack_from('<I',block,position+4)[0];payload=block[position+8:position+8+length]
        if tag==b'LIST':yield from chunks(payload)
        else:yield tag,payload
        position+=8+length+(length%2)
parts=dict(chunks(data));pcm=np.frombuffer(parts[b'smpl'],dtype='<i2');headers=parts[b'shdr'];recordings={}
for offset in range(0,len(headers),46):
    name,start,end,_,_,rate,_,_,_,_=struct.unpack_from('<20sIIIIIBbHH',headers,offset)
    match=re.fullmatch(r'normSA2(High|Med|Low|Muted) (\d+)',name.rstrip(b'\0').decode(),re.IGNORECASE)
    if match:recordings[(int(match[2]),match[1].lower())]=(pcm[start:end].astype(np.float64)/32768,rate)
assert all((root,layer) in recordings for root in range(40,85) for layer in ('low','med','high'))
for slug in ('chitarra-acciaio','chitarra-acciaio-accordi'):
    f=bank/slug;saved=backup/slug
    if not saved.exists():
        saved.mkdir();shutil.copy2(f/'sound.py',saved/'sound.py');shutil.copy2(f/'samples/map.json',saved/'map.json');shutil.copytree(f/'build',saved/'build')
f=bank/'chitarra-acciaio';mapping=json.loads((f/'samples/map.json').read_text());audit=[]
for region in mapping['body']:
    old=Path(region['file']);match=re.fullmatch(r'k(\d+)_(low|med|high)_t(\d+)',old.stem);assert match,old
    root,layer,take=int(match[1]),match[2],int(match[3]);x,rate=recordings[(root,layer)]
    # Derived takes use only a linear change of pick-position coloration.
    if take:
        delay=max(1,round(rate/(440*2**((root-69)/12))*.045));shift=np.r_[np.zeros(delay),x[:-delay]]
        x=x+(.18 if take==2 else -.18)*shift
    x=x*.55
    dest=f/'samples/seagull-natural'/old.name;dest.parent.mkdir(exist_ok=True);sf.write(dest,x,rate,subtype='PCM_24');region['file']=dest.relative_to(f/'samples').as_posix();region.pop('loop',None)
    audit.append({'file':region['file'],'peak':float(np.max(abs(x))),'source_sample':f'normSA2{layer.title()} {root}'})
(f/'samples/map.json').write_text(json.dumps(mapping,indent=2)+'\n')
opens={'major':{0:[None,3,2,0,1,0],2:[None,None,0,2,3,2],4:[0,2,2,1,0,0],7:[3,2,0,0,0,3],9:[None,0,2,2,2,0]},'minor':{2:[None,None,0,2,3,1],4:[0,2,2,0,0,0],9:[None,0,2,2,1,0]},'seventh':{0:[None,3,2,3,1,0],2:[None,None,0,2,1,2],4:[0,2,0,1,0,0],7:[3,2,0,0,0,1],9:[None,0,2,0,2,0],11:[None,2,1,2,0,2]}}
def fingering(pc,quality):
    if pc in opens[quality]:return opens[quality][pc]
    e=(pc-4)%12;a=(pc-9)%12
    shape=({'major':[0,2,2,1,0,0],'minor':[0,2,2,0,0,0],'seventh':[0,2,0,1,0,0]}[quality] if e<=a else {'major':[None,0,2,2,2,0],'minor':[None,0,2,2,1,0],'seventh':[None,0,2,0,2,0]}[quality]);shift=min(e,a)
    return [None if fret is None else fret+shift for fret in shape]
f=bank/'chitarra-acciaio-accordi';mapping=json.loads((f/'samples/map.json').read_text());open_notes=[40,45,50,55,59,64]
for region in mapping['body']:
    name=Path(region['file']).name;match=re.fullmatch(r'c(\d+)_(low|med|high)_t(\d+)\.wav',name);assert match,name
    key,layer,take=int(match[1]),match[2],int(match[3]);quality='seventh' if key>=72 else 'minor' if key>=60 else 'major'
    pitches=[n+fret for n,fret in zip(open_notes,fingering(key%12,quality)) if fret is not None]
    if take:pitches=list(reversed(pitches))[:4]
    spacing={'low':.021,'med':.014,'high':.0085}[layer];rate=recordings[(pitches[0],layer)][1];mix=np.zeros((round(6.5*rate),))
    for i,pitch in enumerate(pitches):
        x,sr=recordings[(pitch,layer)];assert sr==rate;at=round(i*spacing*rate);length=min(len(x),len(mix)-at);mix[at:at+length]+=x[:length]*.14
    fade=round(.5*rate);mix[-fade:]*=np.linspace(1,0,fade);assert np.max(abs(mix))<.95
    dest=f/'samples/chords-natural'/name;dest.parent.mkdir(exist_ok=True);sf.write(dest,mix,rate,subtype='PCM_24');region['file']=dest.relative_to(f/'samples').as_posix();region.pop('loop',None)
    audit.append({'file':region['file'],'peak':float(np.max(abs(mix))),'pitches':pitches,'quality':quality})
(f/'samples/map.json').write_text(json.dumps(mapping,indent=2)+'\n')
p=f/'sound.py';s=p.read_text().replace('master=-6','master=-10.2');p.write_text(s)
(backup/'steel-natural-source-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print('Restored 405 note zones and 216 unclipped finite chord zones.')
