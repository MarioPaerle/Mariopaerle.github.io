# Site-aligned logo studies

Drafts use the current site colors, reverse title labels and thin geometric marks. All symbol segments are straight. Two Turns uses 64 straight segments across two periods with x frequency 3.035 and y frequency 2. Segment opacity rises from 0.28 to 0.93. The frequency offset keeps the ends separate. Earlier revisions are preserved in their own directories.

Dark and light previews, standalone vector marks and 256 px icons are included. These proposals are not installed in the site or plugin. Wordmark outlines use Inter Tight under SIL OFL 1.1 (ui/fonts/OFL-InterTight.txt).
