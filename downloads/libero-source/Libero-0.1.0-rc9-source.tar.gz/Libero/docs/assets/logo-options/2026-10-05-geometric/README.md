# Geometric logo studies

Four draft marks built from straight segments. Each includes a standalone SVG, square icon and wordmark lockup. These assets have not replaced the application icon.

Lockup letterforms are outlined Inter Tight (SIL OFL 1.1; see ui/fonts/OFL-InterTight.txt).
