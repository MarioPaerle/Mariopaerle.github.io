# Libero logo drafts

Three outlined wordmarks derived from the interface display font, Inter Tight.
01 retains the original letterforms; 02 rounds the L foot; 03 uses that foot, weight 550 and a slight inclination. The small icons keep the full name.

SVG files contain paths and require no font at runtime. Inter Tight is under SIL OFL 1.1: see `ui/fonts/OFL-InterTight.txt`. These drafts have not replaced the application icon.
