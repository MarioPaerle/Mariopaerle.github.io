# Physical modelling for Libero: methods, products, real-time engineering, and a build plan

Status: research report, 2026-09-30. Audience: the engineer(s) implementing `libero.physics` and the agents that will call it.

**Provenance convention.** Claims marked **[src]** were checked against a page fetched while writing this report (URL given). Claims marked **[lit]** come from the standard literature as I know it (citation given, not re-fetched; verify a number before you hard-code it into a preset). Claims marked **[est]** are my own order-of-magnitude or back-of-envelope figures, with the arithmetic shown so they can be checked. Anything a company has not published is labelled "not public" rather than guessed.

**What Libero has today** (read from the repo): `synth.karplus` (extended KS with one-zero loss and a tuned allpass), `synth.modal` (bank of exact two-pole resonators, preset tables `bell/glass/wood/metal_plate/chime`, a mallet exciter), `synth.exciter`, `synth.bow` (a *noise-pulsed* friction imitation driving a lossy waveguide or a modal bank, not a bow-string friction solve), `synth.formant`, `synth.breath`, `synth.impulse_response`. Engine side: `ModalResonator` (live "Corde/Vetro/Legno/Metallo" resonances), `FdnReverb`, `PlateReverb`, `ConvolutionReverb`, `SVF`, `DelayLine`, `Allpass`, `DCBlocker`. There is no wind model, no true bowed-string model, no hammer/string contact, no FDTD, no modal estimation, no spring reverb, no room simulator. Sounds are rendered offline per (root, velocity, take) into zones and replayed, so *offline cost is cheap and determinism matters more than realtime cost*.

---

## 0. Executive summary

1. **Nothing here needs to run live for most instruments.** Libero renders zones offline. A physical model costs whatever it costs; the only constraints are agent iteration time (seconds to a minute per zone set) and the quality of the zone-to-zone interpolation at playback. That makes *accuracy-first* methods (FDTD, high-order modal, oversampled nonlinear loops at 96-192 kHz, Newton solves) affordable. Use numba, run the nonlinear loops oversampled, decimate.
2. **The state of the art in products is modal + waveguide + lumped nonlinear exciters**, with careful excitation and a lot of tuning. Pianoteq, SWAM, Chromaphone, Rings/Elements and the Faust `physmodels` library are all descendants of three ideas: Smith's digital waveguides, Adrien's modal synthesis, McIntyre-Schumacher-Woodhouse's lumped-nonlinearity-plus-linear-resonator decomposition. FDTD (Bilbao) is the research-grade, offline-friendly option for 2D/3D objects (plates, membranes, gongs, plate reverb, rooms); it is the method Libero should use for what modal cannot do (nonlinear plates, cymbal crash, strongly coupled geometries) *because Libero can afford to bake it*.
3. **What makes models convincing is rarely the resonator.** It is (a) the excitation (contact time, hardness, noise, position, the onset transient), (b) small nonlinearities (pitch glide, tension modulation, reed/lip hysteresis), (c) the radiating body (measured or modal IR), (d) per-note parameter *curves* (B, T60, hammer hardness change smoothly but non-trivially across the keyboard), and (e) performance modelling (what the "player" does). Budget effort in that order.
4. **Where models fail:** bowed strings (body coupling, wolf, bow noise, gesture space), expressive winds (attack and tongue noise, vocal tract coupling, multiphonics), and anything with many coupled nonlinear parts (piano action, pedal noises). The best hybrids are *sampled or recorded excitation into a modelled resonator* and *modelled resonator into a recorded body IR*, and, for Libero, **baked physical render + live body/exciter** (section 6).
5. Recommended first deliverables for `libero.physics` (details in section 7): material/instrument parameter tables with real-world ranges; a modal core with estimation from recordings; waveguide strings with dispersion, loss design and hammer/pick contact (commuted option); single-reed and lip-reed wind models with bore/bell radiation; a real friction-curve bow with a Schelleng-diagram guard; a 1D/2D FDTD kernel set with CFL checking; body-IR tools; spring and plate reverb builders that emit an `impulse` for the existing "Impronta" reverb.

---

## 1. Methods

### 1.1 Digital waveguides (DWG)

**Principle.** d'Alembert solution of the 1D wave equation: `y(x,t) = y_r(t - x/c) + y_l(t + x/c)`. Two delay lines carry the travelling waves; terminations are reflection filters; losses and dispersion are lumped into filters in the loop. Cost per sample is a few multiply-adds per filter, independent of the length of the string. Reference: J. O. Smith III, *Physical Audio Signal Processing* (online book, 2010) https://ccrma.stanford.edu/~jos/pasp/ **[lit]**; survey of four decades: https://arxiv.org/abs/2604.12878 (listed in search results; PDF too large to fetch, not read) .

**Karplus-Strong and its extensions.** KS (1983) is a noise burst into a delay loop with a two-point average. Jaffe and Smith 1983 (CMJ 7(2), "Extensions of the Karplus-Strong plucked-string algorithm") added: a tuning allpass so pitch is exact, a pick-position comb on the excitation, a dynamics lowpass (velocity changes brightness), decay stretching and a "drum" variant **[lit]**. The loop gain and filter are chosen so `T60(f)` matches the target; Libero's `synth.karplus` already follows this.

**Loop-filter design from T60.** One-pole loss `H(z) = g (1 + a)/(1 + a z^-1)`: choose `g` from T60 at the fundamental and `a` from T60 at a higher partial (Bank and Valimaki 2003, JAES 51(4), "Robust loss filter design for digital waveguide synthesis of string tones") **[lit]**. With `|H(e^{jw_k})| < 1` the loop gain per round trip at partial `k`, the decay time is `T60_k = 6.91 / (f_k * -ln|H(e^{jw_k})| * ... )` in the per-period form `T60_k = -6.91 / (f_0 ln|H(e^{jw_k})|)` (equivalently `6.91 / (f_0 * (-ln|H|))`); here `f_0` is the loop rate (round trips per second) and `6.91 = ln 1000`.

**Fractional delay.** The loop needs `D = f_s/f_0 - (filter phase delays)` samples, rarely an integer.
- **Thiran allpass** (order N, delay `N-0.5 <= D <= N+0.5` for best behaviour): flat magnitude, stable when `D > N - 1`. First order: `eta = (1 - D)/(1 + D)`, `H(z) = (eta + z^-1)/(1 + eta z^-1)`, with `D` kept in `[0.5, 1.5]`. Phase delay is not flat at high frequency; it has a recursive start-up transient, so **do not modulate it fast** (clicks). Use for static tuning **[lit]** (Valimaki and Laakso, "Splitting the unit delay", IEEE SPM 1996).
- **Lagrange FIR** (order 3 is the common choice), or **cubic Hermite**: safe for time-varying delay (vibrato, glide, bow-induced pitch change), but it acts as a lowpass when the fractional part is near 0.5, which is an extra unwanted loss that must be compensated in the loop filter design.
- For baked renders at a fixed pitch, design the tuning allpass analytically (as `synth.karplus` does) and never modulate it. For gliding notes use Lagrange-3 with a slewed delay.

**Stiffness, inharmonicity, dispersion allpasses.** A real string has partials `f_n = n f_1 sqrt(1 + B n^2)` with, for a circular wire of diameter `d`, Young's modulus `E`, tension `T`, vibrating length `L`:

`B = pi^3 E d^4 / (64 T L^2)`   (clamped-ends correction: `f_n ~ n f_1 sqrt(1+Bn^2)(1 + 2 sqrt(B)/pi + 4B/pi^2)`) **[lit]** (Fletcher and Rossing 1998, ch. 2; Fletcher 1964 JASA 36).

Dispersion in a DWG is modelled by a cascade of allpass filters whose group delay grows toward low frequency (higher partials travel faster). Van Duyne and Smith 1994 ("A simplified approach to modeling dispersion caused by stiffness in strings and plates", ICMC) introduced the approach; Rocchesso and Scalcon 1996-1999 designed allpass chains from target inharmonicity; Abel, Valimaki and Smith 2006 give a Schroeder-style design; Bank and Valimaki's robust design is in the same family **[lit]**. Rule of thumb for order: guitar and violin strings need 1-2 first-order sections (or one second-order); low piano strings up to 4-8 second-order sections; treble piano strings have partials so stretched that only a handful exist below Nyquist and a single section suffices **[est from the above; validate by comparing the measured `f_n` of the chain to `sqrt(1+Bn^2)`]**. Always verify by measuring the rendered partials (the existing analysis module can do this) rather than trusting the design formula.

**Plucked strings.**
- Pick position: comb filter `1 - z^-round(beta * P)` on the excitation, `beta` = pluck point / length (0.1-0.5; guitar plucks around 0.12-0.18 of the vibrating length) **[lit]**.
- Two polarizations (vertical/horizontal) with slightly different decay and pitch produce the two-stage decay and beating of guitar notes; couple them through the bridge (Karjalainen, Valimaki and Tolonen 1998, CMJ 22(3), "Plucked-string models: from the Karplus-Strong algorithm to digital waveguides and beyond") **[lit]**.
- Tension modulation (pitch glide after a hard pluck, "twang"): a nonlinear term that makes the delay length depend on instantaneous string elongation (Tolonen, Erkut, Valimaki 2000; Valimaki, Tolonen, Karjalainen 1999 "Signal-dependent nonlinearities for physical models using time-varying fractional delay filters", ICMC) **[lit]**. Cheap to add: `D(t) = D_0 (1 - eps * E_string(t))`.
- Coupled strings (piano triplets, 12-strings, sitar sympathetic strings): a shared bridge admittance; detune by 0.5-3 cents between unisons to get the beating and double decay (prompt sound then aftersound) that Modartt names "unison width" (https://www.modartt.com/pianoteq_features **[src]**).

**Commuted synthesis.** Because string and body are LTI, order can be swapped: `excitation -> string -> body` is equivalent to `(excitation * body IR) -> string`. Precompute the aggregate, play it from a table into the string loop. The body filter (thousands of taps, or hundreds of modes) disappears from the voice; polyphony cost becomes that of the string alone (https://ccrma.stanford.edu/~jos/pasp/Commuted_Synthesis.html **[src]**; Smith 1993 ICMC "Efficient synthesis of stringed musical instruments"; Smith and Van Duyne 1995 ICMC "Commuted piano synthesis"; Karjalainen, Valimaki, Janosy 1993 "Towards high-quality sound synthesis of the guitar and string instruments" **[lit]**). Practical recipe: record (or simulate) the body response to a bridge tap, invert the string's own contribution if it is present in the recording (deconvolve by the string model with excitation removed) and use the result as excitation. The aggregate table is 0.1-1 s long, shorter for "struck" (piano: soundboard response plus hammer pulse convolved, truncated with a fade) **[lit]**. For Libero this is *free*: the recipe computes `ir * pluck` offline and runs it through `karplus`.
- Limits: the string must be linear (no tension modulation, no hammer interaction feedback), the body must not be excited by the string in a time-varying way, and the aggregate cannot depend on velocity except by a set of layers or a parametric blend (soft and loud hammer blows differ in spectrum, so commuted pianos use a few velocity layers or a filter whose cutoff rises with velocity) **[lit]**.

**Resonator factoring / parallel second-order filters.** For bodies, Bank's "kautz/parallel" filters and modal-based piano synths (Bank, Zambon, Fontana 2010, IEEE TASLP 18(4) "A modal-based real-time piano synthesizer") sit between commuted DWG and pure modal **[lit]**.

### 1.2 Modal synthesis

**Model.** A linear vibrating object = sum of damped sinusoids:
`y(t) = sum_k a_k(x_in, x_out) exp(-sigma_k t) sin(2 pi f_k t + phi_k)`, with `sigma_k = 6.91 / T60_k` (neper/s). Each mode is a 2-pole resonator. Excitation enters through the mode shape at the excitation point, output through the mode shape at the pickup: a struck bar's timbre changes with where it is hit because `a_k ~ phi_k(x_in)`. Adrien 1991, "The missing link: modal synthesis", in *Representations of Musical Signals* (MIT Press); implemented in IRCAM Modalys (Morrison and Adrien 1993, CMJ 17(1) "MOSAIC") https://forum.ircam.fr/projects/detail/modalys/ **[lit]**. Open source: Mutable Instruments Elements/Rings resonators (https://github.com/pichenettes/eurorack, `rings/dsp/resonator.cc`) **[src]**.

**Implementation choices.**
- *Exact two-pole* (impulse-invariant) `y[n] = 2 r cos(w) y[n-1] - r^2 y[n-2] + b x[n]`, `r = exp(-sigma/f_s)`: cheap but its state is coupled to frequency (modulating `w` disturbs amplitude). Use when frequencies are static.
- *Complex one-pole* (phasor rotation) `z[n] = r e^{jw} z[n-1] + x[n]`, output `Re(c z)`: 4 real multiplies, stable under parameter modulation, easily vectorised. Preferred for numba/SIMD.
- *State-variable band-pass* as in Rings (modes as SVF bandpass pairs, "stereo position" via cosine modulation of amplitudes; Q ~ `500 * lut(damping)`; partial frequencies stretched by `stretch += stiffness`, with the multiplier reduced by 0.93 or 0.98 per mode to stop partials folding; modes above 0.49 f_s are clamped and dropped) **[src]**.
- *Offline LTI case:* if the exciter is a known signal (no feedback), skip filters: build `y = sum_k` closed-form damped sinusoids convolved with the force pulse via FFT. Faster than filtering for 1000+ modes and exactly reproducible.

**Damping laws.**
- Uniform per-material loss factor `eta`: `T60_k = 2.2/(pi eta f_k)`... more common: Rayleigh damping `sigma_k = b1 + b2 f_k^2` (Chaigne and Lambourg 2001, JASA 109(4), "Time-domain simulation of damped impacted plates") **[lit]**. Gives the classic behaviour: low partials long, high partials die fast.
- Frequency-dependent "air + thermoelastic + internal friction" for bars: Chaigne and Doutaut 1997 JASA 101(1) "Numerical simulations of xylophones" **[lit]**.
- Radiation damping matters for large plates and soundboards (sound radiates energy), air-loading for membranes (drum partial shifts: timpani modes are lowered by the added mass of air, which is why timpani sounds pitched; Rossing).

**Parameter estimation from recordings.**
1. Peak-pick the average spectrum (long zero-padded FFT, quadratic/parabolic interpolation in log magnitude) for initial `f_k`.
2. Refine with a high-resolution estimator on the decaying tail: Prony/matrix pencil, **ESPRIT** (subspace method; Badeau, David, Richard 2006 "High-resolution spectral analysis of mixtures of complex exponentials modulated by polynomials", IEEE TSP), or per-peak Steiglitz-McBride / STFT log-magnitude slope regression for `sigma_k`.
3. Estimate amplitudes/phases by least-squares for fixed `f_k, sigma_k` (linear problem).
4. Validate by re-synthesis and a spectral/envelope distance (the analysis module already computes spectrograms).
Examples in graphics/audio: van den Doel and Pai 1998 "The sounds of physical shapes" (Presence 7(4)); Ren, Yeh, Lin 2013 "Example-guided physically based modal sound synthesis" (ACM TOG 32(1)); differentiable variants: Diaz et al. 2023 ICASSP "Rigid-body sound synthesis with differentiable modal resonators" **[lit]**. Pitfall: modes closer than ~1/T of the analysis window can't be resolved; plates and bells have *pairs* of near-degenerate modes (split by a tiny asymmetry); keep them as beating pairs, do not merge them. That beating is precisely what makes a real bell shimmer.

**Mode shapes and spatial information.** For strings/bars/membranes closed-form shapes exist (sin(n pi x/L), Bessel `J_m(alpha r/a) cos(m theta)` for circles). For irregular bodies use measured mobility (hammer and accelerometer) or FEM eigenmodes. Libero only needs amplitude vs excitation position to sound real; per-mode "position" weight from an analytic shape is enough.

**Cost [est].** One complex one-pole per mode = 4 real FMA per sample. 1000 modes at 48 kHz = 192 MFLOP/s per voice; with 4-wide NEON/SSE ~ 50 M vector ops/s, i.e. ~1% of a modern core. Sixteen voices x 500 modes is still easy. (Elements: 64 modes; Rings: ~60 modes at 48 kHz on a 168 MHz Cortex-M4 **[src: code]**.)

**Nonlinear modal.** Hard contact, bowing and plates at large amplitude need mode-coupled nonlinearity. For single-point exciter coupling: nonlinear force evaluated in the physical domain at the excitation point, distributed to modes (works for hammer, bow, reed on a modal air column). Nonlinear plate vibration (gongs, cymbals: energy cascades from low to high modes, pitch glides, crash): Ducceschi and Touze 2015 JSV 344 "Modal approach for nonlinear vibrations of damped impacted plates: application to sound synthesis of gongs and cymbals" **[lit]**; practical shortcut is FDTD von Karman (section 1.3).

### 1.3 Finite-difference time-domain (FDTD)

**Why.** The PDE is discretised directly on a grid; geometry, boundaries, nonlinearity, stiffness and loss are explicit; no modal analysis is needed; cost scales with grid size. Reference: S. Bilbao, *Numerical Sound Synthesis*, Wiley 2009 (free sample code at the NESS site http://www.ness.music.ed.ac.uk/) **[lit]**; NESS overview: Bilbao, Desvages, Ducceschi, Hamilton, Harrison-Harsley, Torin, Webb, "Physical modeling, algorithms and sound synthesis: the NESS project", CMJ 43(2-3) 2019 https://direct.mit.edu/comj/article-pdf/43/2-3/15/2005655/comj_a_00516.pdf **[src: title/abstract page]**. NESS (2012-17, Edinburgh + EPCC) did large-scale FDTD on GPUs: bowed strings, brass, guitars, plates, rooms (https://www.epcc.ed.ac.uk/whats-happening/articles/ness-next-generation-sound-synthesis-project-bows-out **[src]**).

**1D wave equation.** `u_tt = c^2 u_xx`. Scheme `u_l^{n+1} = 2 u_l^n - u_l^{n-1} + lambda^2 (u_{l+1}^n - 2 u_l^n + u_{l-1}^n)`, `lambda = c k / h`, `k = 1/f_s`. **CFL condition: `lambda <= 1`**; at `lambda = 1` the scheme is exact (and equals a waveguide with integer delays); `lambda < 1` adds numerical dispersion (partials flat at HF). Choose `h = c k` (then `N = L/h = f_s/(2 f_0)` points).

**Stiff damped string.** `u_tt = c^2 u_xx - kappa^2 u_xxxx - 2 sigma_0 u_t + 2 sigma_1 u_xxt`, `kappa = sqrt(E I/(rho A))` (for a wire `kappa = (d/4) sqrt(E/rho)`). Explicit scheme stable when `lambda^2 + 4 mu^2 <= 1`, `mu = kappa k / h^2`; the optimal grid spacing is `h = sqrt((c^2 k^2 + sqrt(c^4 k^4 + 16 kappa^2 k^2))/2)`. The loss pair (`sigma_0`: frequency-independent, `sigma_1`: proportional to `f^2`) gives two T60 anchors: `sigma(w) = sigma_0 + sigma_1 w^2` (Bilbao 2009 ch. 7) **[lit]**.

**Thin plate (Kirchhoff).** `u_tt = -kappa^2 Delta Delta u`, `kappa = sqrt(D/(rho h_p))`, `D = E h_p^3/(12 (1-nu^2))`. Five-point Laplacian squared: stable for `mu = kappa k/h^2 <= 1/4`, so the minimum grid spacing `h_min = 2 sqrt(kappa k)`. Modes: bending waves have `c_ph ~ sqrt(w kappa)` (dispersive); modal density in 2D is **constant** in frequency, `n(f) = sqrt(3) A/(h_p c_L)` per Hz (`c_L = sqrt(E/(rho(1-nu^2)))`) **[lit]** (Fletcher and Rossing ch. 13 / Cremer-Heckl). This is why plates sound dense and "washy".
Grid-size arithmetic **[est]**: EMT 140-type steel plate 1 x 2 m, `h_p = 0.5 mm`, `c_L ~ 5.2e3 m/s` -> `kappa = h_p c_L / sqrt(12) = 0.75 m^2/s`; at `f_s = 44.1 kHz`, `h_min = 2 sqrt(0.75/44100) = 8.2 mm` -> `~30,000` grid points, `~13`-point stencil, `~2e10` FLOP/s. A single-core CPU with good SIMD can just about do this; it is natural GPU work, and is why Bilbao's plate reverb (JAES 55(3) 2007, "A digital plate reverberation algorithm") and later Arcas and Chaigne 2010 ("On the quality of plate reverberation", Applied Acoustics 71) were offline or barely real-time then **[lit]**. For Libero it is a 30 s numba job per impulse response.

**Membranes (2D wave equation with tension and stiffness).** `u_tt = c^2 Delta u` (plus loss). On a square grid `lambda <= 1/sqrt(2)` (CFL 2D); circular/irregular boundaries need staircase or cut-cell handling; staircasing produces audible pitch errors and spurious mode splitting at low resolution (Bilbao ch. 11) **[lit]**. For circular drums, modal with Bessel zeros (section 3) is cheaper and exact.

**Nonlinear plate (von Karman) for gongs/cymbals.** Adds an Airy-stress-function coupling; scheme energy-conserving; grids 10^4-10^5 points at 44.1 kHz; results: pitch glide, spectrum broadening, crash build-up (Bilbao 2008 "Energy conserving finite difference schemes for nonlinear strings", Acta Acustica; Ducceschi and Touze 2015; Ducceschi, Bilbao, Willemsen, Serafin 2021 JASA "Linearly-implicit schemes for collisions in musical acoustics based on energy quadratisation" for hard-contact with guaranteed stability) **[lit]**.

**Stability beyond CFL.** Von Neumann analysis covers linear constant-coefficient schemes. For nonlinear/time-varying systems, *energy methods*: a numerical energy `H^n >= 0` with `H^{n+1} - H^n <= 0` (or `= 0` if conservative) guarantees boundedness (Bilbao ch. 2-3). Do this whenever you embed a nonlinear contact: conservative or dissipative by construction beats hoping the solver behaves. Practical fall-back: clip the state, limit `u` change per step, run a runtime NaN/energy-growth guard.

**Implicit vs explicit.** Explicit schemes are cheap, need tight `h`; implicit (Crank-Nicolson, theta) are unconditionally stable but need banded solves; for plates with `mu` close to 1/4 the gain is small. Use explicit on CPU/numba, vectorise along the inner axis.

**Boundary conditions.** Simply supported (`u = u_xx = 0`), clamped (`u = u_x = 0`), free (vanishing moment and shear), plus *absorbing* layers for room acoustics. Wrong boundary implementation is the commonest source of unstable schemes.

**Outputs.** Read out by interpolating the field at a point (bilinear or cubic) - the point sets the timbre exactly as a microphone/pickup would; use several points for stereo.

**Mixed FDTD/modal/DWG ("hybrid").** FDTD subdomains joined to DWG sections (Bilbao 2004 *Wave and Scattering Methods for Numerical Simulation*; Karjalainen and Erkut 2004 "Digital waveguides versus finite difference structures: equivalence and mixed modeling", EURASIP JASP) **[lit]**. Useful for a string (DWG) coupled to a plate (FDTD) soundboard: commuted in spirit, exact in interaction.

### 1.4 Mass-spring networks and CORDIS-ANIMA

Cadoz, Luciani, Florens 1993 (CMJ 17(1), "CORDIS-ANIMA: a modeling and simulation system for sound and image synthesis") **[lit]**: everything is point masses (MAT) and interaction modules (LIA: spring, damper, conditional links such as bump/friction/pluck). Forces are computed from positions with an explicit scheme (`x^{n+1} = 2x^n - x^{n-1} + (k^2/m) F^n`), i.e. FDTD at unit CFL on an irregular network. Strengths: intuitive, good for haptic/gesture, arbitrary topologies, nonlinear links are trivial (bow friction is a link with hysteresis). Weaknesses: numerical dispersion is uncontrolled, stability is conditional on link stiffness (`omega_max k < 2`), hard to match measured stiffness/damping. Modern line: Leonard and Villeneuve 2019 (SMC) "Mass-interaction physical models for sound and multi-sensory creation: starting anew"; Faust `mi.lib`. For Libero: low priority - FDTD/modal give better control of quantities an agent reasons about (frequencies, T60, inharmonicity).

### 1.5 Wave digital filters

Fettweis 1986 (Proc. IEEE 74(2)): lumped element networks into wave variables with scattering adaptors; a nonlinear one-port can be attached at the root (Werner 2016 thesis "Virtual analog modeling of audio circuitry using wave digital filters", Stanford; Bernardini et al 2020 on multiple/multi-port nonlinearities) **[lit]**. WDFs shine for *circuits* (amps, pickups, diodes); in acoustics they are a scheduling framework for lumped exciters attached to waveguides (a hammer, a reed, a bow are lumped nonlinear one-ports at a DWG junction). Bilbao's 2004 book unifies WDF, DWG and FDTD as "scattering methods". Medium priority for electromechanical instruments (Rhodes tine + pickup, Clavinet); not needed for acoustic instruments.

### 1.6 Lumped nonlinear exciters

All use the McIntyre-Schumacher-Woodhouse decomposition (1983, JASA 74(5), "On the oscillations of musical instruments"): *memoryless (or low-order) nonlinear junction + linear resonator seen through a reflection function*.

#### 1.6.1 Single reed (clarinet, saxophone)

Quasi-static model (valid below reed resonance, `f << f_r ~ 2-3 kHz`): flow through the reed channel `u = w h(Delta p) sqrt(2|Delta p|/rho) sgn(Delta p)`, `Delta p = p_m - p` (mouth minus mouthpiece pressure), `h(Delta p) = max(0, H - Delta p/K)`, where `H` = rest opening (0.4-0.8 mm, **[lit]**), `K` = reed stiffness per unit area in Pa/m (`~ 4e6 - 1e7` **[lit]**; closing pressure `p_M = K H ~ 3-10 kPa`), `w` ~ 12-14 mm channel width (clarinet), `rho` = 1.2 kg/m^3 **[lit]** (Kergomard et al 2000; Dalmont, Gilbert, Ollivier 2003 "Nonlinear characteristics of single-reed instruments: quasistatic volume flow and reed opening measurements", JASA 114). Non-dimensional control: `gamma = p_m/p_M` (mouth pressure; oscillation threshold `gamma = 1/3` in the ideal cylindrical bore; playing range 0.4-0.7 with the loudest at 0.6-0.7 before the reed closes and beats) and `zeta = Z_c w H sqrt(2/(rho p_M))` (embouchure parameter, ~0.2-0.6). Arithmetic check **[est]**: `Z_c = rho c/(pi a^2)`, `a = 7.5 mm` -> `2.3e6 Pa s/m^3`; with `w = 12 mm, H = 0.6 mm, p_M = 5 kPa`: `zeta ~ 0.3` (inside the stated range). Raman/Schumacher (1981) gives the closed-form `p_out^+ = F(p_in^-)`; the waveguide junction equation, with `q = p_m - 2 p^-` (incoming wave `p^-`, outgoing `p^+`, `p = p^+ + p^-`, `Z_c u = p^+ - p^-`) becomes `Delta p + Z_c F(Delta p) = q`, a scalar monotone equation for reasonable `zeta`, which can be tabulated (Smith 1986 ICMC "Efficient simulation of the reed-bore and bow-string mechanisms", https://ccrma.stanford.edu/~jos/pasp/ has the reed table) **[lit]**; for large `zeta` the curve has a region of negative slope and the map becomes multi-valued: solve by Newton/bisection *with hysteresis state* rather than a table.
Dynamic reed (2nd order): `y_tt + q_r w_r y_t + w_r^2 y = -(p_m - p)/mu_r`, `w_r = 2 pi 2-3 kHz`, `q_r ~ 0.3-1`, gives the "reed squeak" and sharper attack; add when the quasi-static table fails to reproduce bright onsets. Reed pitch-lowering effect (`blowing harder flattens by up to 20-50 cents`) emerges from the dynamic reed.
Bore: cylindrical DWG of length `L_eff = c/(4 f_0)` (D3 clarinet: `343/(4*146.8) = 0.584 m` plus end/mouthpiece corrections, total tube ~0.66 m) **[est]**. Reflection at the open end: `R(w) = -|R| e^{-2 j w l}` with a lowpass `|R|` (radius-dependent: `|R| ~ 1 - (ka)^2/2`, `ka = 2 pi f a/c`, Levine-Schwinger 1948 Phys Rev 73(4): "On the radiation of sound from an unflanged circular pipe"); the radiated pressure is ~ the high-passed (differentiated) version. Tone holes: open hole = shunt impedance + length correction; holes lattice produces a *cutoff frequency* ~1.3-1.7 kHz (clarinet) above which the bore "sees" an essentially open tube and radiation jumps (Benade; Scavone and Smith 1997 ICMC "Digital waveguide modeling of woodwind toneholes") **[lit]**. Practical baked approach: one tube per fingering (don't simulate lattice), radiation = one-pole HP + a shelf at the cutoff.
Conical bores (sax, oboe, bassoon): same DWG in conical-wave variables (Benade; Martinez and Agullo 1988 JASA) or with a pressure-wave scattering junction; clarinet: overblows at the 12th (odd harmonics), sax at the octave (all harmonics) **[lit]**.
Double reed (oboe, bassoon): same junction with different `K`, smaller `H`, flow-dependent closing, higher mouth pressure (oboe 4-10+ kPa), plus a strong *bocal/ conical* bore; the characteristic nasal formant comes from the reed resonance and the conical bore rather than a body. Fricative noise (turbulence at the reed slit, tongue/lip noise) is essential to realism: inject filtered noise modulated by `|u|` (Cook 1992, "A physiological vocal tract model"; Scavone 1997; STK `Clarinet` and `BlowHole` classes https://ccrma.stanford.edu/software/stk/ **[lit]**).

#### 1.6.2 Lip reed (trumpet, trombone, horn, tuba)

One-mass (outward-striking) model: `m y_tt + m w_l y_t / Q_l + m w_l^2 y = S (p_m - p)`... two-directional: Adachi and Sato 1996 (JASA 99(2) "Trumpet sound simulation using a two-dimensional lip vibration model") and Elliott and Bowsher 1982 (JSV 83(2)) **[lit]**. The lip resonance `f_l` is tuned near a bore resonance (a trumpeter changes `f_l` with embouchure tension to select partials: the **control mapping** is (pitch -> f_l, pressure -> p_m, lip aperture/stiffness -> h_0)). Parameter ranges **[lit, approximate]**: lip resonance `f_l` 200-1000 Hz (trumpet), 70-400 Hz (trombone); `Q_l` ~ 3-10; mouth pressure up to ~10-20 kPa (forte trumpet) and ~5-10 kPa (trombone); mouthpiece cup volume ~1-2 cm^3 (trumpet); bore ~1.48 m (Bb trumpet), 2.7 m (Bb trombone).
**Brassiness / nonlinear propagation.** At fortissimo the wave steepens as it travels along the tube (shock-wave formation; Hirschberg, Gilbert, Msallam, Wijnands 1996 Acustica 82 "Shock waves in trombones", JASA 99 abstract; Thompson and Strong 2001 JASA 110 "Inclusion of wave steepening in a frequency-domain model of trumpet bore propagation"; Myers et al 2012 JASA 131, on the "brassiness" of trombone/trumpet and its dependence on dynamic level (title quoted from memory; verify); Msallam, Dequidt, Caussé, Tassart 2000 Acta Acustica 86 "Physical model of the trombone including nonlinear effects" (time-domain, bore segmented, each segment with amplitude-dependent delay) **[lit]**). Implementation: split the bore into 2-6 segments, in each segment the delay depends on the local amplitude (`c_eff = c_0 (1 + (gamma+1)/2 * p/ (rho c^2))`); at each segment boundary apply a weak allpass. FDTD version: Bilbao and Chick 2013 JASA 134 "Finite difference time domain simulation for the brass instrument bore" **[lit]**.
**Bell.** Acts as a highpass radiator: reflects low frequencies back (they build resonances), radiates high (Benade's bell cutoff ~1.5 kHz trumpet, ~0.9 kHz trombone, ~0.4-0.5 kHz tuba **[est]**). In DWG: bell reflection filter `R(w)` (a lowpass with gain ~1 below cutoff, falling above) and radiation filter `T(w) ~ 1 - R` (highpass); get them from a measured bell impedance or from the Webster-horn equation solved by the transmission-line method (Kemp 2002; Braden 2006) **[lit]**. Musical mute = a different `R, T` pair.

#### 1.6.3 Bowed string

Classical friction: `F_f = F_N mu(v_rel)`, `v_rel = v_b - v_s(x_b)`; `mu` decreases with `|v_rel|` (Stribeck). Closed forms: exponential `mu = mu_d + (mu_s - mu_d) e^{-|v|/v_0}` (`mu_s ~ 0.8-1.0`, `mu_d ~ 0.2-0.4` in rosined hair; `v_0 ~ 0.01-0.1 m/s`) and hyperbolic `mu(v) = mu_d + (mu_s - mu_d) / (1 + |v|/v_0)` or Smith's `f = 1/(|Delta v + offset| * slope + 0.75)^4` form used in STK's `BowTable` **[lit]**. Elasto-plastic (Dupont, Hayward, Serafin), thermal (Woodhouse 2003 Acta Acustica 89) and hysteresis models improve attack and noise **[lit]** (Serafin, Avanzini, Rocchesso 2002; Serafin 2004 thesis).
**Schelleng diagram** (1973, JASA 53(1) "The bowed string and the player"): playable region in the (bow force `F`, bow-bridge distance `beta`) plane for given bow speed `v_b`:
`F_max ~ 2 Z v_b / (beta (mu_s - mu_d))`, `F_min ~ Z^2 v_b / (2 R_b beta^2 (mu_s - mu_d))`,
`Z = sqrt(T mu_lin)` string impedance, `beta = x_b/L` relative distance from bridge, `R_b` bridge resistance (real part of body admittance at the string frequency). Between `F_min` and `F_max` you get Helmholtz motion; above `F_max` raucous/"choked"; below `F_min` surface/"whistling" (multiple slips). Use it as a *guard* in agents: the tool warns when the requested (`F`, `v_b`, `beta`) lies outside the Helmholtz region.
Typical ranges for a violin **[lit, Woodhouse 1993 Acustica 78 "On the playability of violins I/II"; Askenfelt 1989 "Measurement of the bowing parameters in violin playing II"; Guettler 2002 (STOCKHOLM ACOUSTICS)]**: bow speed 0.05-1.0 m/s (spiccato to forte detache), force 0.05-1.5 N (up to ~3 N at the frog, forte), `beta = 0.03-0.15` (sul ponticello smaller, sul tasto larger), `Z ~ 0.1-0.4 kg/s` depending on the string (`A` string, `T ~ 55 N`, linear mass 0.6 g/m -> `Z ~ 0.18 kg/s` **[est]**). Helmholtz motion: sticking for fraction `(1 - beta)` of the period, slipping for `beta`, string velocity under the bow in the slip phase `~ -v_b (1 - beta)/beta` (why bowing close to the bridge needs small speed and large force). Attack transients: **Guettler diagram** (Guettler 2002, *Acta Acustica* 88 "On the creation of the Helmholtz motion in bowed strings") - the "perfect" attack needs a particular rate of increase of bow force relative to acceleration; too fast a bow force ramp gives "crunch"; too slow gives multiple-slip "scratch".
Numerics: the bow point is a two-port junction in a DWG (string split in two segments, velocity waves; https://ccrma.stanford.edu/~jos/pasp/Bowed_Strings.html **[src]**). Friction is implicit in `v_s(x_b)`: `v_b - (v_in + (F_f/(2Z)))... `: solve `Z_2 (v_b - v_in) ... = mu(v) F_N` for `v_rel` with Newton (2-3 iterations, warm start from previous sample), or use a table indexed by `v_in` (Smith 1986). Two-polarisation + torsional waves + finite bow width (Desvages and Bilbao 2016 Appl. Sci. 6(5) "Two-polarisation physical model of bowed strings with nonlinear contact and friction forces...") for NESS-style realism **[lit]**.

#### 1.6.4 Hammer-string contact (piano)

Hertzian-type power law, with hysteresis: `F_h = K |y_h - y_s|^p` (`p = 2-3.5`), or Hunt-Crossley `F = K x^p (1 + alpha_hc x_t)`; Stulov 1995 JASA 97(3) "Experimental and computational studies of piano hammers" adds a history-dependent (hereditary) term **[lit]**. Chaigne and Askenfelt 1994 (JASA 95(2), "Numerical simulations of piano strings I"): hammer mass `m_h` 2.2-4.9 g (C7..C2), stiffness exponent `p ~ 2.5-3.5` and `K ~ 1e9-1e11 N/m^p` (increasing with pitch), hammer velocity 0.5-6 m/s (pp to ff), contact time ~ 4 ms bass, 1-2 ms mid-treble, ~0.5 ms top; strike point 1/7-1/9 of the string in the bass (comb notches: `sin(n pi beta)` for partial `n` are the nulls; 7th and 9th partials are attenuated on most pianos) **[lit]**.
Hammer pulse spectral lowpass ~ `1/T_contact`; soft mallet -> long contact (yarn/felt soft, 5-10 ms), hard (brass, wood, plastic) -> 0.2-1 ms. **Two-way coupled:** the string pushes back; in the bass the hammer stays in contact for multiple reflections - only a coupled solve (or a FDTD/DWG-with-contact) reproduces the velocity-dependent timbre. Longitudinal waves and "phantom partials" (Bank and Sujbert 2005 JASA 117(4) "Generation of longitudinal vibrations in piano strings: from physics to sound synthesis") add the metallic "zing" in the bass: a cheap nonlinear term `(dy/dx)^2` of the transverse motion drives a longitudinal mode at twice the transverse frequencies; audible in the bass/mid **[lit]**.
Full piano: Chabassier, Chaigne, Joly 2013 JASA 134(1) "Modeling and simulation of a grand piano" (strings + hammer + soundboard, energy-stable schemes, offline) **[lit]**.

#### 1.6.5 Flute jet / edge tone

Air jet of width `W` leaves the flue, travels to the labium (edge) a distance `W_d`; transverse perturbations grow exponentially while convected at `~0.4 U_j` (Fletcher/Rayleigh jet-drive model; Verge et al 1994 JASA 95 "Jet formation and jet velocity fluctuations in a flue organ pipe"; Fabre, Hirschberg, Wijnands 1996 Acustica 82; Coltman 1976) **[lit]**. Delay `tau = W_d/(0.4 U_j)`; jet offset at the edge `eta(t) = A e^{alpha W_d} eta_0(t - tau)`; force on the pipe via a saturating nonlinearity: Cook (STK `Flute`, 1992) uses a jet delay line, `y = x - x^3`, a DC blocker and a bore DWG with a lowpass reflection **[lit]**. Edge-tone Strouhal number `St = f W_d/U_j ~ 0.2-0.3` for the first stage; overblowing jumps stages. Blowing pressures 0.2-3 kPa (flute), jet speed `U_j = sqrt(2 P/rho) ~ 20-40 m/s` **[lit/est]**. Realism needs: breath noise band-limited and modulated by the jet strength, pitch flattening/sharpening vs level (jet delay `tau` couples to `U_j`), and a very short attack chiff.

### 1.7 Body and radiation filters

- **Linear bodies** (guitar, violin, cello, piano soundboard): modal or FIR mobility; significant low modes: violin air `A0 ~ 270-290 Hz`, main wood resonance `T1 ~ 450-480 Hz`, `B1- / B1+ ~ 480 / 550 Hz`, bridge hill ~2-3.5 kHz (broad boost); cello `A0 ~ 100 Hz`; steel-string guitar `A0 ~ 100 Hz`, top plate `T(1,1) ~ 200 Hz` **[lit, Fletcher and Rossing ch. 9-10; Gough 2016 "Violin acoustics"]**. Parallel bank of 10-60 second-order resonators already gets a recognisable guitar/violin; a measured 0.5-1.5 s IR convolved (partitioned FFT, or baked) gets you the rest.
- **Piano soundboard**: modal density high (~0.3-1 modes/Hz above ~1 kHz [est]), mobility peaks (~50-200 Hz band: "ridge" ribs; "knee" at impedance drop above ~1 kHz); the bridge admittance determines the T60 pattern (the bichord prompt/after decay) and the radiation into the room (radiation efficiency rises with frequency until the coincidence frequency) **[lit]**.
- **Bell radiation for winds/brass**: HP radiation filter `T(w)` and directivity (brass at 2-4 kHz is forward-beamed; omit unless spatialising).
- **Radiation impedance** of tubes: `R(w)` above, `-|R| e^{-2 j w l}` with `l ~ 0.6 a` (unflanged) / `0.85 a` (flanged) **[lit]**.
- **Formant-style body for voice-like wind bodies** already exists (`synth.formant`).

### 1.8 Physical reverbs

| Approach | What it simulates | Cost | Fit for Libero |
|---|---|---|---|
| Image-source | Specular reflections in a convex box (Allen and Berkley 1979 JASA 65(4) "Image method for efficiently simulating small-room acoustics") | O(order^3) sources; early reflections only | Early-reflection part of a baked IR |
| Ray/beam tracing | Stochastic late field; diffuse scattering (Krokstad 1968; Savioja and Svensson 2015 JASA 138(2) overview) | offline seconds-minutes | Late tail, baked IR, frequency-dependent absorption bands |
| FDN tuned to room physics | Delay lengths from mode/ray statistics; per-delay absorption `T60(f)` via attenuation filters (Jot and Chaigne 1991 AES 90th "Digital delay networks for designing artificial reverberators"; Schlecht and Habets 2017 IEEE/ACM TASLP "On lossless feedback delay networks") | ~16-64 delays, very cheap | Live: Libero already has `FdnReverb`; tune delay ratios/gain to a room geometry |
| Scattering delay network (SDN) | Delay network whose nodes sit at first-order reflection points of a rectangular room; exact 1st-order reflections, diffuse beyond (Hacihabiboglu, De Sena, Cvetkovic, Johnston, Smith 2015; De Sena et al 2015 IEEE/ACM TASLP 23(9)) | 6-ish nodes + ports | Live, parametric by room size and source/listener position |
| Waveguide mesh / FDTD 3D | Wave equation in 3D; modes, diffraction (Savioja and Valimaki; Hamilton and Bilbao 2017 TASLP 25(4); Webb and Bilbao 2011 (CUDA)) | cost ~ `(f_max V/c^3)^1` x f_s: a 100 m^3 room to 2 kHz is ~10^9 cells x f_s | Offline only; bake to IR |
| Plate reverb | Dispersive 2D plate (Bilbao 2007; Arcas and Chaigne 2010) | 30k-100k pts FDTD | Bake; or model as dense modal bank (constant modal density, `n(f) = sqrt(3) A/(h c_L)`, `T60` nearly frequency-independent up to a few kHz, decreasing above) |
| Spring reverb | 2-3 helical springs; dispersive (chirp-like "boing"); delay 30-40 ms (Hammond type 4), drive + pickup coils, 1-4 s decay | Parametric | Bake: Abel, Berners, Costello, Smith 2006 AES 121 "Spring reverb emulation using dispersive allpass filters in a waveguide structure"; Valimaki, Parker, Abel 2010 JAES 58(10) "Parametric spring reverberation effect"; Parker 2011 "Spring reverberation: a finite difference approach" (DAFx) |

Notes on EMT 140-type plates **[lit]**: steel, 2 x 1 m, 0.5 mm, tensioned; `T60` set 1-5 s via a damping pad; response is essentially dispersive *delays* spread over 50-100 ms initially, dense from the start (no discrete echoes): mean modal density ~ 0.26 modes/Hz[est: `sqrt(3) * 2 m^2 / (5e-4 * 5200) = 1.3` modes/Hz; check your own number with the formula] so a 1.3 modes/Hz density at each frequency means a 10 s IR has ~13 modes per resolvable bin; use >~ 20 kHz of modes. A *modal plate* (rectangular, simply supported: `f_{mn} = (pi kappa/2)(m^2/a^2 + n^2/b^2)`) with `Rayleigh` damping and random in/out positions, run as an offline modal sum, gives a believable plate in seconds and lets the agent change size/thickness/damping. For T60 by room type: intimate rooms 0.3-0.8 s, concert halls 1.6-2.4 s, cathedrals 4-10 s; absorption at HF (air, `m = 0.0005-0.02 /m` rising with `f^2`) makes `T60(f)` fall above ~4 kHz **[lit]**.

---

## 2. State of the art: products and how they (publicly) work

Everything below is from public material; internals that are not public are flagged.

| Product | What is public | Takeaway for Libero |
|---|---|---|
| **Pianoteq** (Modartt) | Notes are computed live from a model of hammer, strings, soundboard and cabinet; every sound parameter is adjustable (hammer hardness and noise, unison width, sympathetic resonance, duplex scale, soundboard, strike point); ~50 MB install (https://www.modartt.com/pianoteq_features **[src]**). Algorithm and sample rate are not published; user forum posts on "spectral vs physical" are opinion, not Modartt statements **[src]**. Publicly discussed physics: `f_n = n f_1 sqrt(1 + B n^2)` inharmonicity (quoted on their page), strike-point spectrum shaping, detuned unisons, damper/pedal sympathetic resonance | The feature list is a parameter spec: hammer (contact, hardness curve with velocity), per-string inharmonicity and T60, unison detune, strike point, sympathetic strings (all undamped strings excited through the bridge), soundboard/radiation, noises (hammer, pedal, damper). Per-note *curves* carry the realism |
| **Audio Modeling SWAM** (Brass, Woodwinds, Strings; Engine) | "Synchronous Waves Acoustic Modeling": a combination of physical modelling, behavioural modelling (how a player articulates: legato, portamento, vibrato, tonguing) and *phase-synchronous multi-vector sample morphing*; no sample triggering; control via MIDI (CC11 expression, etc.) with very smooth amplitude/bow/pressure mapping (https://vstshop.com/knowledge/swam-physical-modeling-guide/ and Sound on Sound review https://www.soundonsound.com/reviews/audio-modeling-swam-solo-instruments **[src: search summaries]**) | The *performance model* is half the product. SWAM is explicitly hybrid (modelled dynamics + sample-derived timbre morphing) - evidence that pure physics is not enough for expressive solo strings/winds |
| **AAS Chromaphone / String Studio / Objeq / Tassman / Lounge Lizard** | Applied Acoustics Systems (Montreal): modal resonators (string, beam, membrane, plate, tube, marimba...) driven by excitation "objects" (mallet, pick, noise, bow-like), with damping, inharmonicity/material ("Material", "Decay", "Harmonics" controls); String Studio is a waveguide/modal string with body; Lounge Lizard is a modelled electro-mechanical piano. Detailed algorithms not public; the white papers describe modal synthesis and "physical modeling using an original technique" (https://www.applied-acoustics.com/ did not resolve when fetched; rely on product descriptions) | Consistent with: modal core + parametric excitation + frequency-dependent damping + spatial pick-up. `libero.physics.modal` should expose the same controls |
| **Mutable Instruments Elements / Rings / Plaits** | Open source (https://github.com/pichenettes/eurorack): Elements = exciters (bow: friction-like signal, blow: noise/granular "flow", strike: mallet with sample-based strike exciters) + modal resonator (64 modes as SVFs, structure = stiffness/stretch, brightness, damping, position = mode-shape weights via cosine, stereo spread) + reverb; Rings = 3 resonator types: modal, sympathetic strings (comb bank), and a string with nonlinearity/dispersion [src: doc pages https://pichenettes.github.io/mutable-instruments-documentation/modules/rings/ and code `resonator.cc`]. Plaits adds waveguide/modal "virtual analog/physical" engines | Shows what is enough for a *convincing impression* at 64 modes and a few kFLOP: modal + well-designed exciters + a little dispersion. Their stiffness-to-inharmonicity mapping and clamped-frequency logic are worth copying |
| **Sculpture (Logic Pro)** | Apple's modelling synth: a string model excited by up to three "objects" (strike, bow, blow...) with two resonators ("Media loss", "Body EQ"); design is Stanford-CCRMA-lineage (waveguide) **[lit, not re-checked]** | Illustrates the "string + objects + body" ontology that is easy for an agent to drive |
| **Yamaha VL1 / VL70-m** (1994) | Waveguide-based wind/string modelling licensed from Stanford (Smith et al.), played with a breath controller, 2-voice polyphony, real-time DSP hardware **[lit]** | Historical proof: a waveguide reed/bow/lip with breath control is an *instrument*, but had narrow polyphony |
| **Korg OASYS / Z1 / Prophecy (MOSS)** | Prophecy (1995) and Z1 (1997) use MOSS physical-model oscillators (single-reed, lip-reed, plucked string, bowed); OASYS (2005) includes modelled plucked string and more **[lit]** | Same conclusion; hybrid synthesis architecture |
| **Physical Audio** (Edinburgh; NESS alumni, FDTD plug-ins) | FDTD-derived plug-in instruments (e.g. "Derailer") and effects; public statements consistent with real-time FDTD in tuned C++ (https://physicalaudio.co.uk/about/ **[src: search summary]**) | Shows FDTD can run live *for low-dimension systems*; 2D/3D stays offline/GPU |
| **Arturia "Piano V"** and others | Modelled pianos from several vendors: hammer/string/soundboard with sampled noise layers **[lit, unconfirmed details]** | Modelled resonator + sampled noises is the norm |
| **Madrona Labs Kaivo/Aalto** | Synthesisers mixing granular and resonator-style physical models; specifics not public **[not relied upon]** | - |
| **NESS / Bilbao** | Open papers and MATLAB/C++ sample codes; GPU/multicore FDTD of bowed strings, brass, guitar, plates, 3D rooms; music composed for NESS (CMJ 2019 article above **[src]**) | The reference for stable nonlinear schemes (energy methods) |
| **IRCAM Modalys** | Modular modal-synthesis workbench: objects (string, plate, tube, membrane...), connections (bow, reed, hammer, pluck), accesses; computes modes from finite-element meshes; offline and Max | The object/connection/access ontology is the cleanest API precedent for `libero.physics` |
| **Faust `physmodels.lib` (pm.lib)** | Open library (Michon, Smith et al.): strings (`ks`, `nylonString`, `steelString`, `openString`), bowed (`violinBow`, `bowTable`, `violinModel`), clarinet (`clarinetReed`, `clarinetModel`), brass (`brassLips`, `brassModel`), flute (`fluteEmbouchure`, `fluteModel`), modal percussion (marimba bar, djembe, church bells: `churchBell`, `englishBell`, `frenchBell`, `germanBell`, `russianBell`, `standardBell`), plus `waveguide`, `bridgeFilter`, `modeFilter` building blocks (https://faustlibraries.grame.fr/libs/physmodels/ **[src]**; Michon and Smith 2011 "Faust-STK") | The best open *catalogue of working parameter sets* and function structure; port their constants as starting presets, validate by ear and by measurement |
| **STK (Cook and Scavone)** | C++ classes: `Clarinet`, `Saxofony`, `BlowHole`, `Flute`, `Brass`, `Bowed`, `Plucked`, `Mandolin`, `ModalBar`, `Mesh2D`, `BlowBotl`, PhISEM shakers (https://ccrma.stanford.edu/software/stk/) **[lit]** | Small, readable reference implementations of each exciter table |

**What makes these convincing** (synthesised from the above and the literature):
1. *Excitation realism*: hammer/mallet contact force shape and its velocity dependence; bow noise ("scratch"), breath noise, key/finger noise, pick noise; fixed samples of real transients layered on the model (Elements' strike exciters, SWAM's morphing).
2. *Noise and irregularity*: detune/jitter between unisons, random per-note parameter jitter (+-0.2 to 1 cent, +-2-5% T60), round-robin via `takes`.
3. *Nonlinearity*: tension modulation, hammer hysteresis, longitudinal "phantom partials", reed and lip dynamics, bore shock steepening (brass). Even small amounts remove the "clean synth" impression.
4. *Body IR*: recorded or computed body responses (soundboard, guitar top, violin body); radiation filtering.
5. *Control mapping and performance model*: continuous control of pressure/bow force with correct *joint* variation (more breath pressure -> louder, brighter, slightly sharper/flatter; bow force + speed + distance together), legato/portamento behaviour, vibrato with correlated amplitude and pitch.
6. *Sympathetic resonance* (all undamped strings, other bars, the body) - a strong "realness" cue in pianos and harps.

---

## 3. Parameter sheets (starting points for presets)

**3.1 Strings** (for `B = pi^3 E d^4/(64 T L^2)`, `E_steel = 2.0e11`, `rho_steel = 7850`, `E_nylon ~ 3e9`):

| Instrument / note | `f_0` | `L` (m) | `d` (mm) | `T` (N) | `B` (computed **[est]**) | T60 of fundamental [lit, approximate] |
|---|---|---|---|---|---|---|
| Piano C4 (plain steel) | 262 Hz | 0.63 | 1.0 | ~670 | 3.6e-4 | 15-25 s held, ~10 s with damped pedal down |
| Piano mid range A3-C5 | | | | | 2e-4 - 5e-4 | |
| Piano bass (wound, C2) | 65 Hz | ~1.2-2.0 | wound (core 1.5-2 mm) | 800-1000 | 1e-4 - 4e-4 | 20-60 s; very low A0: 40+ s |
| Piano treble (C7) | 2093 Hz | ~0.05-0.1 | 0.8 | 600-800 | 1e-2 - 5e-2 | 1-4 s |
| Steel guitar e1 | 330 Hz | 0.65 | 0.25 | ~75 | 1.2e-5 | 2-4 s |
| Nylon guitar B2 | 247 Hz | 0.65 | 0.7 | ~60 | 1.4e-5 | 1-3 s |
| Violin E | 659 Hz | 0.325 | 0.26 | ~80 | ~5e-5 | sustained by bowing; free decay 1-3 s |
| Harp, dulcimer (brass/steel) | | | | | 1e-4 - 5e-4 | 3-15 s |

Piano `B` is typically smallest around C3-C4 (~1e-4 - 4e-4) and grows 10-100x toward the top; real pianos are stretch-tuned so that octave `n = 2` of a note matches the `n = 1` of the octave above (piano tuners raise treble by up to ~30-40 cents, lower bass 20-30 cents) **[lit: Young 1952; Fletcher, Blackham, Stratton 1962 JASA 34; Railsback curve]**. Decay: bichord/triple: `prompt` fast component `~`1-5 s in mid-range and an `aftersound` of 10-30 s, with different decay rates because unisons are coupled through the bridge.

**3.2 Bars and plates** (frequency ratio `f_n/f_1`, all **[lit]** from Euler-Bernoulli theory / Fletcher and Rossing):
- *Free-free uniform beam* (xylophone, marimba without undercut, glockenspiel, chimes): `beta_n L = 4.730, 7.853, 10.996, 14.137` -> `f_n/f_1 = 1, 2.757, 5.404, 8.933, 13.34`.
- *Marimba/vibraphone bars with undercut*: tuned `1 : 4 : 10` (marimba; some 1 : 4 : 9.9-10.5); vibraphone 1 : 4 : ~10 (`f_3` in `[9.5, 10.5]`); xylophone: 1 : 3 : 6 (hard wood, partial tuned at 3x, by ear the fundamental is weak); glockenspiel: untuned ratios above ("inharmonic bell-like").
- *Clamped-free beam* (kalimba tine, reed, tuning fork tine, Rhodes): `beta_n L = 1.875, 4.694, 7.855, 10.996` -> `1 : 6.267 : 17.55 : 34.39`.
- *Simply supported beam*: `1 : 4 : 9 : 16`.
- *Circular membrane (clamped, ideal)*: `alpha_{mn}` (zeros of `J_m`) `= 2.405 (0,1), 3.832 (1,1), 5.136 (2,1), 5.520 (0,2), 6.380 (3,1), 7.016 (1,2), 7.588 (4,1), 8.417 (2,2)` -> ratios `1, 1.594, 2.136, 2.296, 2.653, 2.917, 3.156, 3.500`. Timpani tuning (air loading, tension, resonance of the kettle): the modes (1,1),(2,1),(3,1),(4,1) sit near `1 : 1.5 : 2 : 2.44 : 2.92` so the drum sounds pitched (first ratios ~1.5 -> "perfect fifth" sits on the `(1,1)` fundamental at 1.0 with the `(1,1)` mode heard as the note) **[lit: Rossing 1982 "Acoustics of drums"; Fletcher and Rossing ch. 18]**. Snare drum / tom: no air-loading pitch correction, partials stay near ideal ratios (unpitched sound).
- *Rectangular simply-supported plate*: `f_{mn} = (pi kappa/2)(m^2/a^2 + n^2/b^2)`, `kappa = sqrt(D/(rho h))`.
- *Church bell* partials relative to the strike note [lit, Rossing 1990 "Science of Percussion Instruments"; Perrin et al 1983; approximate, real bells vary by +-2%]: hum 0.5, prime (fundamental) 1.0, tierce (minor third) 1.2, quint (fifth) 1.5, nominal (octave) 2.0, deciem (major third above nominal) 2.5, undeciem (fourth) 2.67, octave nominal 3.0... then upper partials at 4.0 and higher up to ~9. The *strike note* is perceived at the virtual pitch of the nominal/tierce/quint group (`~` prime). The existing Libero `bell` preset should be checked against this table. Bell beating: each mode splits into two near-degenerate partials ~0.5-3 Hz apart (manufacturing asymmetry) -> slow amplitude beating - model as explicit pairs.
- *Cymbals/gongs*: dense, nonlinear, no useful closed-form ratios; FDTD von Karman or noisy modal.

**3.3 T60 by material** [lit; approximate, fundamental mode; high partials decay faster, `T60 ~ T60_1 (f_1/f)^{0.5-2}`]:

| Object / material | T60 fundamental | Comment |
|---|---|---|
| Church bell (bronze, 1-2 m) | hum 20-60 s, prime 10-30 s, upper 1-5 s | very low internal damping (`eta ~ 1e-4 - 3e-4`) |
| Orchestral tubular bell / chime (brass) | 3-10 s | |
| Vibraphone bar (aluminium) | 4-12 s (bass), 1-3 s (treble); longer with motor off | |
| Glockenspiel / celesta (steel) | 2-8 s | |
| Glass (wine glass / glass harmonica) | 3-15 s | very low damping, sensitive to rim |
| Marimba (rosewood, padauk) | 0.3-0.6 s treble, 1-3 s bass | resonator tubes add 1-2 s at the fundamental |
| Xylophone (rosewood) | 0.15-0.8 s | hard mallets; short |
| Steel plate / sheet | 1-5 s, hugely dependent on boundary | |
| Tuning fork (steel) | 30-60 s | |
| Piano string (see 3.1) | 1-60 s | bridge coupling sets the pattern |
| Plate reverb | 1-5 s nearly flat to ~3 kHz | |
| Spring reverb | 1-4 s; dispersion gives "boing" | |
| Concert hall / cathedral | 1.6-2.4 s / 4-10 s | see 1.8 |

**3.4 Wind parameters** (see 1.6): clarinet `K ~ 5e6 - 1e7 Pa/m`, `H ~ 0.4-0.8 mm`, reed resonance 2-3 kHz, `q_r ~ 0.3-1`; `gamma` 1/3..0.7; `zeta` 0.2-0.6; bore `L_eff = c/(4f_0)` for clarinet, `c/(2f_0)` for sax/oboe/flute (open-open or conical), radius 7.5 mm (Bb clarinet), sax 6-20 mm varying; oboe double reed cane channel `w` ~ 5-8 mm. Trumpet: `f_l` 200-1000 Hz, `Q_l` 3-10, `p_m` up to 15-20 kPa ff, bore 1.48 m; trombone 2.7 m (slide position sets effective `L`, ~ 3 m at 7th position). Flute: `U_j` 20-40 m/s, `W_d` 3-5 mm (flue to edge, `~ 4-5 x` jet width 0.5-1 mm), `f ~ St U_j/W_d`.

**3.5 Bow**: see 1.6.3: force 0.05-1.5 N, speed 0.05-1.0 m/s, `beta` 0.03-0.15, `mu_s ~ 0.8-1.0`, `mu_d ~ 0.2-0.4`, `Z` 0.1-0.4 kg/s. Cello: force 0.3-5 N, speed 0.05-1 m/s, `Z` 0.3-1.5 kg/s.

---

## 4. Real-time engineering

### 4.1 CPU budgets per voice [est unless cited]

Assumptions: 48 kHz, scalar ~ 1-3 GFLOP/s effective per core for well-written numba/C++ non-SIMD, 4-8x with NEON/AVX on regular loops. Libero's engine runs voices plus live effects; leave >=50% headroom.

| Model | per-sample ops | per voice at 48 kHz | Comfortable voices / core |
|---|---|---|---|
| KS / DWG string with 2nd-order allpass + 1-pole loss + tuning allpass | 15-30 flop | 1-1.5 MFLOP/s | hundreds |
| DWG string with 6-8 dispersion allpasses (low piano) | 60-100 flop | ~4 MFLOP/s | 50-100 |
| Modal bank, 500 modes (complex 1-pole) | ~2000 flop | ~100 MFLOP/s (SIMD: ~15% of a core with 16 voices) | 10-20 |
| Modal, 64 modes (Elements-like) | 250 flop | 12 MFLOP/s | 100+ |
| Reed + cylindrical bore + radiation, 2x oversampled | 60-120 flop | 6-10 MFLOP/s | 100 |
| Bowed string with Newton friction (3 iterations) | 100-200 flop | ~10 MFLOP/s | 50-100 |
| FDTD stiff string (220 points, A2) | ~10 flop/pt x 220 = 2200 | ~100 MFLOP/s | 10-20 |
| FDTD plate (30k pts) | ~13 flop/pt x 30k = 4e5 | ~2e10 FLOP/s | offline only (or GPU) |
| Partitioned FFT convolution with a 1.5 s body IR, stereo | ~100-300 flop/sample | 5-15 MFLOP/s | 20+ (shared IR: one conv per note group, not per voice) |

Commuted synthesis or baking removes the body from the per-voice budget; *that is the main cost lever*.

### 4.2 Oversampling for nonlinearities

The nonlinearity (reed table, bow friction, hammer contact, waveshaping in brass) creates harmonics of harmonics that fold back. In *feedback loops* the loop filter attenuates high partials each round trip, so aliasing is often less audible than in open-loop waveshapers, but it still colours onsets. Strategies:
- *Offline bake (Libero):* simulate at 2-4 x the target rate (96-192 kHz), decimate with a linear-phase FIR (>100 dB stopband) - no real-time cost, the nonlinear loop becomes cleaner, and the tuning allpass behaves better (shorter delays cost relatively less phase error). Keep the delay-line lengths in *oversampled* samples: a 2x rate doubles memory but nothing else.
- *Live:* 2x with half-band filters around *only* the nonlinear junction; keep the delay loop at 1x where possible. Antiderivative antialiasing (Parker, Zavalishin, Le Bivic 2016 DAFx "Reducing the aliasing of nonlinear waveshaping using continuous-time convolution") works for memoryless shapers but not inside a feedback loop without care **[lit]**.

### 4.3 Stability

- Prefer **passive/energy-bounded** formulations: reflection coefficients `|R| <= 1`, loop gain below 1 at all frequencies, WDF-style passive adaptors, energy-method FDTD (section 1.3). A *negative-resistance* junction (reed, bow) is stable only together with the passive resonator; verify by running long (30-60 s) noise-driven tests and checking that state energy is bounded.
- Hard contact (hammer rebound, reed closing, bow sticking) is a stiff discontinuity: use Newton with a safeguard (bisection fallback), sub-step (run the contact equation at 2-4x the loop rate), or energy quadratisation (Ducceschi et al 2021).
- Avoid **denormals**: add `1e-18` DC noise or set flush-to-zero in C++ (Libero's `Dsp.h` should already; in numba use explicit clamps).
- **DC offsets**: reed and jet models have DC via `p_m`; add a DC blocker (one-pole HP at ~10-20 Hz) in the loop or at the output.
- Numerical dispersion of FDTD lowers the upper partials; use the optimal grid (`lambda` at its limit) and verify partial frequencies after rendering.
- Set a **per-render energy guard** in the tool: abort and report if peak exceeds a limit or the state NaNs; agents then see a clear error instead of a blown render.

### 4.4 Parameter smoothing and control

- Controls that enter a *delay length* (pitch): slew in samples (Lagrange-3); never jump the delay or the tuning allpass.
- Controls that enter a *gain* (pressure, bow force): 5-20 ms one-pole smoothing (audible "zipper" on brass at >40 ms steps). For *offline* renders drive from breakpoint envelopes instead (see 4.6).
- Nonlinear parameters (reed `K`, lip `f_l`): change slowly; an abrupt `H` change can re-trigger the reed oscillation (a good "attack" but uncontrolled).
- Randomisation per note (seed-driven) must be deterministic: same `(note, velocity, take, seed)` -> same samples (the compiler caches by source hash).

### 4.5 SIMD and polyphony strategies

- Modal banks: structure-of-arrays (separate `re[], im[], c_re[], c_im[]` float32 arrays), one loop over modes per sample or, better, **per-block** (process all modes for a block of 32-128 samples in the outer loop, which keeps state in registers and lets the compiler vectorise). Libero's engine chunk is 32 samples (`kChunk`).
- DWG strings: delay lines are memory-bound and branchy per voice; vectorise *across voices* (SoA lanes) rather than within a voice.
- Polyphony: voice stealing with short fades; share resonators (body, sympathetic bank, reverb) across voices - commuted or sampled excitations keep a single shared body. For modal resonators shared across notes (Rings-style "sympathetic strings") run them once on the summed bus.
- Level of detail: reduce the mode count of released or quiet voices (modes below -80 dB of the loudest contribute nothing) - dynamic mode pruning gives a 2-5x saving on decaying tails.

### 4.6 Control mapping

- **Velocity (keyboard)** -> hammer velocity (piano: `v_h ~ 0.5 + 5 (vel/127)^1.5` m/s, *not* linear in MIDI velocity since felt nonlinearity compresses), pluck amplitude and brightness (hardness), mallet contact time, breath pressure onset speed. Tip: make the mapping a function the agent can edit (table or exponent).
- **Breath / CC2 / aftertouch / CC11** -> `p_m` (`gamma`), with a *floor* below the oscillation threshold (`1/3` for reeds) so low breath = silence, not a quiet tone; expression curves on winds are roughly `gamma = gamma_min + (gamma_max - gamma_min) * x^1.5`.
- **Embouchure** (reed: `H`, `K` effective via lip damping; brass: `f_l`, `Q_l`, aperture; flute: jet offset) - map to *pitch-stable* ranges; let vibrato modulate lip/ pressure, not the delay line directly (the pitch modulation and amplitude/brightness modulation are correlated in real wind vibrato).
- **Bow**: `(F_N, v_b, beta)` triple. Offer a single gesture parameter for agents (e.g. `intensity` 0..1) that moves along a *safe path inside the Schelleng Helmholtz region* and expose the triple only for experts; generate attacks with a Guettler-style force ramp.
- For baked zones these gestures are **time-varying envelopes inside the render** (attack ramp, sustain, release). The compiled sample then replays the gesture; live expression comes from filter/envelope/tape effects, not from re-simulation.

### 4.7 What is realistic live in Libero's C++ engine vs baked offline

Libero's architecture makes a **three-level split**:

1. **Fully baked (default):** simulation runs in Python/numba; output zones replay. Best for: anything with FDTD, nonlinear plates, brass shock nonlinearity, long bowed or blown notes with gesture in the render, plate/spring/room reverbs (as `ir.wav`), commuted piano/guitar (one IR, many pitches), bells, marimba, glass.
2. **Baked physics + live body and exciter colouring:** the zone contains the *string/reed/bell* rendered with a *neutral* (dry) body; a live `ModalResonator` (already in the engine: "Corde/Vetro/Legno/Metallo") or convolution body (live `ConvolutionReverb`-style partitioned FFT) adds the radiating body; live noise beds (`air`) provide breath, bow rosin hiss, hammer thud. Gives the player body-size, material and brightness controls without re-simulation. The one extra requirement: render *dry* zones and tag them (`sound.defaults(res_mode=...)` already exists).
3. **Live DSP models** (engine additions, worth doing only where playing parameters must be *continuous*): (a) a live **single-reed or bowed-string voice** driven by breath/bow controllers *if* a mono expressive lead is a goal; (b) a live **modal struck/plucked** resonator bank with physically-parametrised mode shapes (cheap, 16 voices); (c) **live spring/plate-style dispersive reverbs**; (d) **sympathetic resonance bank** shared across voices (piano/harp/sitar). Each can start as a cheap C++ class next to `ModalResonator`.

Hybrids explicitly worth building: (i) *baked attack + live modal tail*: the first 50-300 ms from a high-fidelity offline simulation (hammer contact, bow attack) crossfaded to a live resonator that carries the decay with player-controlled damping; (ii) *multi-sample physical render*: 5-6 velocity layers x 5 roots baked with a full piano model, live sympathetic/soundboard bank on top.

---

## 5. Where physical models still fail, and the best hybrid tricks

**Why a violin is hard.**
1. *Body coupling:* the string-body system is strongly coupled at the bridge; the body's 10-20 low modes (A0, T1, B1-, B1+, CBR, ...) and the wolf note (when a string frequency coincides with a strongly resonant body mode, the Helmholtz motion breaks down) must be in the loop, not just after it. Commuted synthesis fails (bow is nonlinear and time-varying). A modal body with ~100-500 measured modes inside the bridge admittance works but requires measured data.
2. *Friction physics:* rosin friction is thermal and history dependent; simple `mu(v)` curves miss the noise, the initial "scratch" of an attack and the subtle pitch fluctuation; good models (Woodhouse 2003; Serafin 2002; Desvages and Bilbao 2016) are expensive to tune.
3. *Gesture space:* bow force, speed, position, tilt, bow hair contact width, finger, vibrato, bow changes, string crossings, pizzicato/spiccato are a continuous, correlated control space; the sound depends on trajectories, not on values. SWAM's product premise (performance model plus sample morphing) is the industry acknowledgement of this.
4. *Validation:* objective measures (spectrum) don't capture "playable" (Schelleng) or "alive" (micro-variations of Helmholtz motion).
5. Similar issues for oboe/clarinet/sax in expressive use: multiphonics, register breaks, tonguing, key noises, vocal-tract coupling (formants of the player modulate the reed flow).

**Best hybrids** (ranked by value for Libero):
1. **Recorded / measured body IR** convolved onto a clean modelled string/tube (bake or live). Body IRs can be measured with a bridge tap, or from a recording by deconvolution, or synthesised from a modal fit.
2. **Sampled excitation into a modelled resonator:** record a bow noise, pick, breath, fingertip, real mallet hit; use it (band-limited) as the excitation of the modal/DWG resonator (Elements' strike exciters; commuted synthesis; "sample-driven physical model"). Gives instant excitation realism, loses exact physical coupling; acceptable for nearly all plucked/struck sounds.
3. **Modelled resonator, sampled residual:** synthesise the pitched part, subtract from a recording and keep the residual (noise, bow hiss, key clicks) as a layer (Libero's `air`/`attack` layers already do this).
4. **Analysis-by-synthesis fitting:** estimate modal/DWG parameters (`f_k`, `T60_k`, `B`, `beta`, excitation spectrum) from a recording of the real instrument by optimisation (spectral distance on partial envelopes), then render a *dry, controllable* version. Use a differentiable renderer (DDSP-style, Engel et al. 2020 ICLR "DDSP") if the fit needs gradients **[lit]**.
5. **Nonlinear-enriched sampled layers:** render physical-model velocity layers at 4-6 levels so the playback interpolation between layers is what the model would have done (Libero's `velocities` does this).
6. **Gesture from data:** fit bow/breath envelopes (force, speed, pressure) from recordings; store the curves in the recipe so the same "performance" can be replayed at other pitches.

---

## 6. Sources (by section)

Core texts and primary literature:
- J. O. Smith III, *Physical Audio Signal Processing*, CCRMA (online): https://ccrma.stanford.edu/~jos/pasp/ (commuted synthesis: .../Commuted_Synthesis.html **[src]**; bowed strings: .../Bowed_Strings.html **[src]**)
- S. Bilbao, *Numerical Sound Synthesis*, Wiley, 2009; NESS project: http://www.ness.music.ed.ac.uk/ ; CMJ 43(2-3) paper https://direct.mit.edu/comj/article-pdf/43/2-3/15/2005655/comj_a_00516.pdf **[src]**; EPCC overview https://www.epcc.ed.ac.uk/whats-happening/articles/ness-next-generation-sound-synthesis-project-bows-out **[src]**
- N. H. Fletcher and T. D. Rossing, *The Physics of Musical Instruments*, 2nd ed., Springer 1998
- A. Chaigne and J. Kergomard, *Acoustics of Musical Instruments*, Springer 2016
- K. Karjalainen, V. Valimaki, T. Tolonen, "Plucked-string models...", CMJ 22(3), 1998
- D. A. Jaffe and J. O. Smith, "Extensions of the Karplus-Strong plucked-string algorithm", CMJ 7(2), 1983
- M. E. McIntyre, R. T. Schumacher, J. Woodhouse, "On the oscillations of musical instruments", JASA 74(5), 1983
- J. O. Smith, "Efficient simulation of the reed-bore and bow-string mechanisms", ICMC 1986
- J. Dalmont, J. Gilbert, S. Ollivier, JASA 114 (2003) (reed quasistatic measurements)
- A. Hirschberg et al., "Shock waves in trombones", JASA 99, 1996; Msallam et al. Acta Acustica 86, 2000; Bilbao and Chick, JASA 134, 2013; Myers et al., JASA 131, 2012
- F. Avanzini, "Computational issues in physically-based sound models" (PhD thesis, Padova) on friction; S. Serafin, "The sound of friction", PhD Stanford 2004
- J. C. Schelleng, JASA 53(1), 1973; K. Guettler, Acta Acustica 88, 2002; J. Woodhouse, Acustica 78, 1993
- A. Chaigne and A. Askenfelt, JASA 95(2), 1994; A. Stulov, JASA 97(3), 1995; B. Bank and L. Sujbert, JASA 117(4), 2005; B. Bank et al., "Physically informed signal processing methods for piano sound synthesis: a research overview", EURASIP JASP 2003; J. Chabassier, A. Chaigne, P. Joly, JASA 134(1), 2013
- B. Bank, V. Valimaki, "Robust loss filter design for digital waveguide synthesis of string tones", IEEE SPL 10(1), 2003
- V. Valimaki et al., "Splitting the unit delay", IEEE SPM 13(1), 1996; Van Duyne and Smith, ICMC 1994 (dispersion)
- J.-M. Adrien, "The missing link: modal synthesis", 1991; IRCAM Modalys https://forum.ircam.fr/projects/detail/modalys/
- K. van den Doel and D. K. Pai, "The sounds of physical shapes", Presence 7(4), 1998; Z. Ren, H. Yeh, M. Lin, ACM TOG 32(1), 2013
- C. Cadoz, A. Luciani, J.-L. Florens, CMJ 17(1), 1993; Leonard and Villeneuve, SMC 2019
- A. Fettweis, Proc. IEEE 74(2), 1986; K. Werner, PhD thesis, Stanford 2016
- Reverbs: Allen and Berkley, JASA 65(4), 1979; Jot and Chaigne, AES 90th, 1991; Schlecht and Habets, TASLP 2017; De Sena et al., IEEE/ACM TASLP 23(9), 2015 (SDN); Bilbao, JAES 55(3), 2007 (plate); Arcas and Chaigne, Applied Acoustics 71, 2010; Abel et al., AES 121 (2006) and Valimaki, Parker, Abel, JAES 58(10), 2010 (spring); Savioja and Svensson, JASA 138(2), 2015; Hamilton and Bilbao, TASLP 25(4), 2017
- Nonlinear plates: O. Thomas, C. Touze, A. Chaigne, Int. J. Solids Struct. 2005; M. Ducceschi and C. Touze, JSV 344, 2015; Ducceschi et al., JASA 2021 (collisions)
- Products and tools: Modartt Pianoteq features https://www.modartt.com/pianoteq_features **[src]**; SWAM summary https://vstshop.com/knowledge/swam-physical-modeling-guide/ and https://www.soundonsound.com/reviews/audio-modeling-swam-solo-instruments **[src: search summaries]**; Mutable Instruments Rings https://pichenettes.github.io/mutable-instruments-documentation/modules/rings/ and code https://github.com/pichenettes/eurorack (`rings/dsp/resonator.cc` **[src]**); Faust physmodels https://faustlibraries.grame.fr/libs/physmodels/ **[src]**; STK https://ccrma.stanford.edu/software/stk/; Physical Audio https://physicalaudio.co.uk/about/
- Survey (not read in full): "Four Decades of Digital Waveguides", https://arxiv.org/abs/2604.12878

Caveat: literature values in sections 3-4 are from memory of standard references and have not all been re-checked against the original papers; the **[est]** arithmetic is reproducible from the formulas printed beside it. Treat every preset number as a prior to be confirmed against a measurement (`libero.analysis`) of the rendered zone.

---

## 7. What Libero should build

Design principles for an *agent-facing* toolkit: (1) **named, physical, unit-bearing parameters** (Hz, m, N, kg/s, seconds of T60) with documented real-world ranges, not abstract 0..1 knobs, plus an "easy" layer of descriptive presets; (2) **every renderer returns the analysis needed to validate it** (measured partials, T60 per partial, peak level, energy-growth flag); (3) **deterministic** (`seed`, `take`); (4) **fail loudly** (Schelleng guard, CFL check, stability guard) with actionable messages; (5) each model is a thin layer over a few shared numba kernels; (6) return `libero.Audio` so it slots into the existing `Sound` recipe.

### 7.1 Proposed `libero.physics` layout (priority order; effort S <= 1 day, M = 2-5 days, L = 1-2 weeks)

| # | Module / API | Purpose and key signature | Effort |
|---|---|---|---|
| P0 | `physics.materials` / `physics.presets` | Tables: Young's modulus, density, loss factor, `T60`-vs-frequency laws (Rayleigh `sigma = b1 + b2 f^2`), instrument presets for strings (d, L, T, B) and wind bores (length, radius, K, H), bell/bar/plate ratio tables from section 3. `material("bronze")`, `string_preset("piano", note=60)`, `bar_ratios("marimba")`. Every entry carries a source tag and range. | S |
| P0 | `physics.modal` | `ModalBank(freqs, t60s, amps, pos=None)`; constructors `bar(kind, f0, ...)`, `membrane(f0, circular=True, air_loading=...)`, `plate(a, b, h, material)`, `bell(f0, kind="church", pairs=True)`, `tube(...)`; `render(excitation: Audio | Hammer | Pluck, dur, pickup, sr)`; complex one-pole numba kernel + FFT closed-form path; `detune_pairs` beating; `prune(db)`. Replaces/extends `synth.modal` | M |
| P0 | `physics.modal.estimate` | `fit_modes(audio, n_modes, method="esprit")` -> `ModalBank`; peak pick + ESPRIT/Prony + LS amplitudes; report residual. Enables "match this recording" for the slow workflow | M |
| P0 | `physics.exciters` | `hammer(contact_ms, hardness, v, p)` (raised-cosine / Hertz), `mallet`, `pick`, `finger`, `bow_noise`, `breath_noise`, `noise_burst`; `Excitation` object consumed by modal/string | S |
| P0 | `physics.string` | `waveguide_string(f0, t60, B, pluck_pos, pickup_pos, dispersion=auto, polarizations=2, detune_cents)`, `StringBank` (coupled unisons + sympathetic strings), auto dispersion-allpass design from `B`, loop-filter design from `T60(f)` (Bank-Valimaki), tension modulation option; `hammer_string(...)` with Hunt-Crossley contact (two-way coupled, oversampled contact); `piano_note(midi, velocity)` using per-note curves (B(n), T60(n), hammer hardness, strike point) | L |
| P0 | `physics.body` | `body_ir(kind="guitar"|"violin"|"soundboard", ...)` from modal mobility tables; `from_recording(ir_audio)`; `commute(body_ir, excitation)` -> aggregate excitation; `radiation_filter(kind="bell"|"tube")`; convolution helpers with FFT partitions | M |
| P1 | `physics.wind` | `clarinet(f0|fingering, gamma, zeta, reed=..., breath=Envelope, noise=...)`, `sax`, `oboe`, `bore(radius, length, conical, radiation=True)`; reed junction with table + Newton, optional dynamic reed; 2x/4x oversampled render; `flute(f0, jet_speed, ...)`; breath-noise model modulated by flow | L |
| P1 | `physics.brass` | `lip_reed(f_lip, Q, ...)`, `brass(bore_segments, bell_cutoff, nonlinear=True, mute=...)`, amplitude-dependent segment delays for brassiness | L |
| P1 | `physics.bow` | `friction_curve(kind, mu_s, mu_d, v0)`, `schelleng(Z, beta, v_b, mu_s, mu_d)` -> (F_min, F_max) and `is_playable(...)`, `bowed_string(f0, F(t), v(t), beta(t), body=ModalBank|IR)` with Newton friction; Guettler attack helper `attack_ramp(...)`; `gesture("legato"|"detache"|"spiccato"|"sul_pont", intensity)` returns safe envelope triples | L |
| P1 | `physics.reverb` | `spring_ir(n_springs, delay_ms, dispersion, t60)` (dispersive allpass chain + chirp), `plate_ir(size, thickness, material, t60(f), in_pos, out_pos)` (modal rectangular plate, stereo), `room_ir(dims, absorption_bands, src, lis, method="ism+fdn"|"sdn")` (image-source early + FDN tail), all returning stereo `Audio` for `sound.impulse`; add `t60_measure(ir)` | M |
| P1 | `physics.fdtd` | numba kernels: `String1D` (stiff, damped, nonlinear option), `Bar`, `Membrane2D`, `Plate2D` (Kirchhoff, optional von Karman), boundary types, `cfl_check()`, optimal grid chooser, multi-point readout, energy monitor; `render_plate(...)` for gongs/cymbal/ tam-tam | L |
| P1 | `physics.analysis` | `measure_partials`, `measure_t60_per_partial`, `inharmonicity(audio)` -> B, `schelleng_report`, `aliasing_report(audio, sr)`, `compare(ref, sim)` (spectral envelope + T60 distance) for the slow workflow | M |
| P2 | `physics.coupled` | generic `Network` (Modalys-style objects + connections: `Object`, `Connection`, `Access`), mass-spring/CORDIS-ANIMA nodes for exotic topologies | L |
| P2 | `physics.friction_hysteresis` | elasto-plastic/thermal bow friction for higher-quality violin | M |
| P2 | `physics.nonlinear_modal` | quadratic coupling of modes for gong/cymbal/steel-pan-ish bodies; or FDTD-baked alternative | L |
| P3 | differentiable fitting (PyTorch/JAX) | gradient-based parameter estimation of `ModalBank`/`string` | L |

MCP surface: a small number of *high-level* tools, not one per function: `physics_preview(kind, params)` (short render + measured partial/T60 report), `physics_presets(kind)` (list with ranges and sources), `physics_fit(audio)` (modal fit), plus documentation as a guide (`guide("physics")`) that embeds sections 1-5 of this file in condensed form and the parameter sheets of section 3.

### 7.2 Optional live C++ components (engine)

| # | Component | Notes | Effort |
|---|---|---|---|
| C0 | **Modal resonator with physical mode sets** (extend `ModalResonator`): load per-sound mode list from the bundle (`resonances.json` from `physics.modal.fit_modes`), pitch-tracked, `T60` and brightness scaling live, position control | Low risk; matches existing "Corde/Vetro/Legno/Metallo" UI. | S-M |
| C1 | **Shared sympathetic bank** across voices (piano/harp/sitar): tuned string comb or modal bank excited by the summed note bus with a damper state | 10-40% extra CPU for 88 strings at 1-pole modal cost | M |
| C2 | **Partitioned-FFT body convolver per sound** (reuse `ConvolutionReverb` code) on the *summed* pre-reverb signal, with `body.wav` in the bundle | Cheap, high impact for commuted/dry-rendered zones | S-M |
| C3 | **Spring and plate character for the reverb** (`DispersiveSpring` allpass chain; plate via existing `PlateReverb`): new "Molla" (spring) room; parameter T60, dispersion, drive | Follows Valimaki/Parker/Abel 2010 | M |
| C4 | **Live reed/bow exciter feeding a DWG string/tube voice** (monophonic lead mode, breath/CC11 and bow pressure mapped to `gamma`/`F_N`) | Only if expressive continuous control is a product goal; 2x oversampled junction; 100 MFLOP/s budget | L |
| C5 | **Bell radiation / brightness filter** (live HP/shelf pair per sound) | trivial | S |
| C6 | **Per-note parameter jitter and round-robin noise** already in `takes`; add live micro-detune of unisons and random `T60` scatter in the engine's voice start | Gives "alive" feel cheaply | S |
| C7 | **Nonlinear contact at note-on** (live hammer-string at velocity): compute a 50-200 ms attack on the fly from velocity into the baked tail | Complex; only after P0 string model is proven offline | L |

Recommended order: P0 modules (materials, modal + estimation, exciters, strings, body) and C2/C0 in the engine first - these convert the current synth stubs into accurate physical instruments and give the largest audible gain for least cost. P1 winds/bow/reverb/FDTD next, since they unlock whole instrument families (reeds, brass, bowed, plates, rooms). Everything else only when a concrete sound needs it.

### 7.3 Validation checklist for each model (for the second pass)

1. Partial frequencies vs formula (`sqrt(1 + B n^2)` for strings, bar/membrane ratio tables, bell table) within 2 cents on the first 8 partials.
2. `T60` per partial recovered from the render within +-15% of the design.
3. No energy growth in 60 s stress test (noise excitation, extreme parameters); parameter sweeps do not crash.
4. Oversampled render vs non-oversampled: aliasing residual below -60 dB relative.
5. Schelleng/`gamma`/`zeta`/CFL guards fire with a human-readable reason.
6. Determinism: identical bytes for identical `(params, seed, take)`.
7. A/B against a reference recording through `libero.analysis` (spectral envelope, onset time, decay) for at least one sound per family before it becomes a documented preset.
