# Sample sources and ingestion for Libero

Status: research, 2026-09-30. Scope: which multisample sources an agent can legally download and build on,
which one wins per instrument family, how Libero ingests real libraries, and how sampled bodies combine
with synthesis. How commercial libraries are produced is covered elsewhere.

Conventions: "verified" means I read the source page, repo, or file during this research. "unverified"
means a search snippet or memory only; check before shipping. Licence notes are a practical reading for
engineering decisions, not legal advice. Where a source is ambiguous, this report takes the stricter reading.

Local facts that shape the design (from the repo and the machine):

- The bundle format is float32 WAV zones plus `manifest.json` (SPEC section 4). Zones carry `root`, `lo/hi`,
  `vel_lo/vel_hi`, `loop`, `take`. Layers: body, attack, tail, air. `takes` is capped at 8.
- `download.py` already has `attribute()` (appends to `samples/ATTRIBUTION.md`), `fetch_url`, and Freesound
  search/download. Freesound download uses the HQ preview (OGG, about 192 kbps, 44.1 kHz) because originals need
  OAuth. A preview is not good enough for a foundation sound; it is fine for noises and transients.
- The disk has about 38 GB free (96% used) and `~/Libero` is already 1.5 GB. A storage budget is a real
  constraint, not an afterthought (section 5).
- No `sfizz_render`, `fluidsynth` or `flac` binary is installed. `ffmpeg` is (it decodes FLAC).

---

## 1. The licence rules that decide what we may ship

Libero sounds are bundles that may be shared or sold. A bundle made of a source's samples is a derivative.

| Licence | Use in a sound we keep privately | Ship / redistribute the bundle | Constraint that propagates |
|---|---|---|---|
| CC0 / public domain | yes | yes | none; credit anyway as a courtesy |
| CC BY 3.0 / 4.0 | yes | yes | credit in the bundle, keep a licence link |
| CC BY-SA 3.0 / 4.0 | yes | yes, but the bundle must itself be BY-SA | share-alike infects the bundle (not the plugin code) |
| CC Sampling Plus 1.0 | yes | only transformed material; no unmodified redistribution; no advertising use | needs a judgment call; treat as "private lane" until decided |
| CC BY-NC (any) | yes, non-commercial only | no, if Libero sounds are sold or bundled with a product | blocks commercial shipping |
| Site EULA (Pianobook, Garritan, Karoryfer paid, etc.) | yes, inside your own music | no: redistribution of the library or its derivatives is forbidden | "private lane" only |
| "Free, use without restriction" notices (Iowa) | yes | informal permission, no formal licence text | keep attribution, keep the URL and date in `ATTRIBUTION.md` |

Consequence for the tool design: every imported source gets a `license_class` (`cc0`, `by`, `by-sa`, `sampling+`,
`nc`, `eula`, `unknown`). A sound's bundle licence is the most restrictive class among its sources. `sound_save` and
any future "export/share" must refuse or warn when the class is `nc`, `eula` or `unknown`. Private-lane sounds work
fine locally; they just cannot leave the machine.

---

## 2. Source catalogue

### 2.1 Tier A: usable as foundations (CC0 or CC BY)

| Source | Instruments | Layers / RR / articulations | Format, rate, depth | Size | Licence | Download | Verdict |
|---|---|---|---|---|---|---|---|
| **Salamander Grand Piano V3** (Alexander Holm, Yamaha C5, two AKG C414 AB pair about 12 cm above strings) | grand piano | 16 velocity layers, minor-third spacing from A0, separate hammer-noise release (chromatic), string-resonance releases (minor thirds, 3 layers), pedal noises, natural and retuned banks | SFZ v2 + ARIA extensions, FLAC, 48 kHz / 24 bit | about 1.9 GB archive (394+ MB compressed per SFZ listing) | CC BY 3.0 (verified) | https://github.com/sfzinstruments/SalamanderGrandPiano ; https://archive.org/details/SalamanderGrandPianoV3 | Best free piano. The SFZ uses `#define`, `#include`, CC-driven amplitude and `sw_last`; a naive region parser is not enough (verified by reading the file). |
| **VCSL** (Versilian Community Sample Library) | about 100 instrument folders: Steinway B (352 files), Kawai grand (229), Yamaha and Knight uprights (143/145), 5 harpsichords, concert and folk harp, pipe organ and renaissance organ, saxello, tenor sax, recorders (4), ocarinas, didgeridoo, harmonicas, dan tranh, balafon, kalimba/mbira (5 sets), marimba, vibraphone, xylophone, glockenspiel, tubular bells (3), timpani (2: 204 files), snares, toms, bass drums, cymbals, TX81Z FM voices | mostly 1 round robin and 2-3 velocity layers; 20-75 MB per instrument raw | WAV 44.1/48 kHz, 16/24 bit, stereo; SFZ auto-generated from a Python utility in the repo | repo about 4,500 files; "VCSL Keys" 680 MB in FLAC | CC0 (verified) | https://github.com/sgossner/VCSL ; https://versilian-studios.com/vcsl-keys/ | Widest CC0 pool, especially for ethnic, mallets, harpsichord, organ. Consistent pitch accuracy, thin layering. Good second tier. (File counts from the GitHub tree API, verified.) |
| **VSCO 2: Community Edition** | solo violin, solo contrabass, violin/viola/cello sections, harp; flute, oboe, clarinet, bassoon, piccolo; horn, trumpet, tenor trombone, old trombone, tuba; upright pianos (2), organ; glockenspiel, marimba, xylophone, timpani; VSCO 1 drums and metal/wood percussion | per articulation (sustain with vibrato, no vibrato, staccato, spiccato, pizzicato, tremolo, etc.); solo violin arco-vib has 2 velocity layers (split at 62/63, verified), no loop points, keyswitch variants; short notes use `seq_length/seq_position` or `lorand` round robins (verified) | WAV 44.1 kHz, 16 or 24 bit, stereo; SFZ branch | about 3 GB; solo violin 135 MB, solo bass 156 MB, cello section 186 MB, flute 120 MB | CC0 (verified) | https://github.com/sgossner/VSCO-2-CE (branch `SFZ`) ; https://versilian-studios.com/vsco-community/ | The best free orchestral starting point (cleanly recorded, consistent naming). Sustained notes are fixed length with no loops, so Libero's loop finder is mandatory. |
| **Karoryfer Samples (free catalogue)** | Bigcat Cello (527 samples, 24 bit), Meatbass and Smolken double bass, Sneakybass, String Cyborgs, Weresax, Bear Sax (1926 Conn baritone), War Tuba, Squidpipes, Emilyguitar, Shinyguitar, Black and Green guitars, Etherealwinds Harp II CE, Horse Pulse, drums (Big Rusty 2.3 GB, Swirly 1.6 GB, Unruly 2 GB, Frankensnare 900 MB, Gogodze Phu 133 MB), Caveman Cosmonaut and Cowsynth (synths from samples) | character instruments, often several round robins; drums multi-velocity | SFZ + WAV, 24 bit, 44.1/48 kHz | 100 MB to 2.3 GB each | CC0-1.0 for the free ones; many other Karoryfer titles are **commercial** (Merciful Cello, Vengeful strings, Hadziha choir, Nanfo, etc.) and must not be mistaken for free | https://github.com/sfzinstruments (one repo per instrument); listing https://sfzinstruments.github.io/ | Excellent for character/cinematic layers; gaps where the paid line is better. Always check the per-repo `LICENSE`. |
| **TinySOL** (IRCAM, via Zenodo) | 14 orchestral instruments (incl. violin, viola, contrabass, brass, winds, accordion), ordinario only | 2,913 single notes across dynamics, ordinario technique | WAV, 44.1 kHz | small (hundreds of MB) | CC BY 4.0 (verified) | https://zenodo.org/records/3685367 | Clean anechoic-style studio notes; good for the "real timbre, then hybrid" path. No release samples, no loops. OrchideaSOL (extended techniques) is **not** openly downloadable: it needs an IRCAM Forum account and is non-commercial, so exclude it. |
| **Headroom Piano**, **Greg Sullivan E-Pianos**, **Splendid Grand Piano**, **MSLP Vibes** | upright/grand character piano; classic electric pianos (21.5 MB); small grand (77 MB, public domain); vibraphone (3 octaves, 1 layer) | small libraries, 1-3 layers | SFZ | 20-160 MB | Headroom CC BY 4.0; Sullivan CC BY 3.0; Splendid public domain; MSLP CC BY 3.0 (all from the sfzinstruments listing, verified) | https://sfzinstruments.github.io/pianos/ | Electric-piano options are thin (see section 3). |
| **DRS Kit, Muldjord Kit** (DrumGizmo ports), **Naked Drums**, **SM Drums** | full drum kits | multi-mic (DrumGizmo kits use many close + room mics), many velocity layers, up to 10 round robins (Naked Drums) | SFZ | 350 MB to 2.2 GB | CC BY 4.0 / CC BY 4.0 / CC BY 4.0 / public domain | https://sfzinstruments.github.io/drums/ | These are the libraries that force mic layers and high RR counts (section 5). |
| **AKWF** (Adventure Kid waveforms) | single-cycle synth waveforms (thousands) | n/a (wavetable) | WAV | small | CC0-1.0 | https://github.com/KristofferKarlAxelEkstrand/AKWF-FREE | Raw material for synth bodies. |
| **SHLD Minifreak Pads / Wavestate Pads** | cinematic pad soundscapes recorded from hardware | long loops | SFZ | 160-265 MB | CC0-1.0 | https://sfzinstruments.github.io/synthesizers/ | Useful pad beds for hybrid cinematic sounds. |
| **Freesound (CC0 and CC BY filtered)** | anything, including violin body impulse responses (for example user pe_mace) | one-shots, rarely multisampled | mixed; originals need OAuth, API gives previews only | per file | per sound: CC0 / CC BY OK; CC BY-NC and Sampling+ blocked | https://freesound.org/ ; licence FAQ https://freesound.org/help/faq/ | Transients, breath, noise, single IRs. Always filter `license:"Creative Commons 0"` or `"Attribution"`. Existing `freesound_search` supports this. |

### 2.2 Tier B: usable with conditions

| Source | What it is | Licence reading | Condition / risk | Verdict |
|---|---|---|---|---|
| **Philharmonia Orchestra samples** (20 instrument zips, about 250 MB: violin, viola, cello, bass, flute, oboe, cor anglais, clarinet, bass clarinet, bassoon, contrabassoon, sax, horn, trumpet, trombone, tuba, guitar, banjo, mandolin, percussion) | Real orchestral players, MP3-era origin, individual notes in several dynamics and lengths | Sources disagree: the project pages say CC BY-SA 3.0, the Internet Archive item says CC BY-SA 4.0. Terms text: free for any use including commercial releases, but the samples must not be sold or distributed "as is", i.e. as a sample pack or sampler instrument (verified via the GitHub mirror README and Internet Archive page; the official Philharmonia page refused to load) | A Libero bundle that is merely trimmed and pitched raw samples is arguably "as is". Only ship bundles that are substantially transformed (layered, looped, processed, resynthesised), label them BY-SA. Keep raw zips out of shared folders. | Great real-player timbre, unusual instruments (cor anglais, contrabassoon). Use as a **hybrid ingredient**, not as a zone pack. |
| **Sonatina Symphonic Orchestra** (Westlund, Eastman) | full orchestra in SFZ: solo and ensemble strings, brass, winds, percussion, piano, harp, harpsichord, organ | CC Sampling Plus 1.0 | Unmodified redistribution and advertising use are restricted; the author also notes that some very old soundfont sources are assumed public domain. 16 bit / 44.1 kHz, minor-third spacing, 2x+ RR on short notes | Private lane. Quality is decent but dated; VSCO CE is cleaner. |
| **Virtual Playing Orchestra 3** (Battersby) | SFZ orchestra built from SSO, Iowa, No Budget Orchestra and others | composite: Sampling+, CC BY-SA 3.0/4.0, CC0, Iowa terms | you can repackage only under a Creative Commons licence with credit; mixed provenance makes the bundle licence BY-SA at best | Use only for ideas about articulation mapping; prefer the primary sources. |
| **University of Iowa Musical Instrument Samples** | flute, oboe, clarinet, sax, bassoon, horn, trumpet, trombone, tuba, violin, viola, cello, bass, marimba, xylophone, vibraphone, cymbals, gongs, piano, etc. | "use freely without restriction" (verified on the site); no formal licence text | No formal licence to cite. Keep the URL and date in `ATTRIBUTION.md`. Pre-2011: one Neumann KM84, 16 bit / 44.1 kHz, mono, pp/mf/ff, chromatic, AIFF; post-2011: Decent-tree stereo 24 bit / 96 kHz (verified) | The dry anechoic recordings are the best base for convolution with a body or room IR. Plain, but honest. |
| **Good-sounds (UPF)** | 12 solo instruments (flute, clarinet, trumpet, violin, cello, oboe, piccolo, four saxes, bass) | Zenodo record 4588740 states **CC BY-NC 4.0** (verified); some pages mention an older/newer CC BY 4.0 | **Exclude** unless the exact file version is confirmed CC BY. 13.9 GB, 48 kHz / 32 bit FLAC, several mics per take | Research only for us. Not a sample source. |
| **FreePats** | many small GM-style banks (piano, organ, guitar, harp, strings, flutes, ethnic, kits) | per-bank; many CC0 or CC BY (unverified per bank: the index page does not list licences) | Check each bank's page | Low-fidelity GM material; fallback only. https://freepats.zenvoid.org/ |
| **Hauptwerk / GrandOrgue free sets** (Piotr Grabowski, Lars Palo, etc.) | pipe organs, many ranks | per organ; some are Creative Commons with non-commercial terms that extend to derived samples (forum reports) | Formats are Hauptwerk/GrandOrgue, not SFZ; licence often NC | Not a source for shipping. VCSL pipe organ and VSCO organ (both CC0) come first. |

### 2.3 Tier C: not usable as sample sources (and why)

| Source | Reason |
|---|---|
| **Pianobook** | Uploader-owned packs. Commercial use is allowed only inside your own musical compositions; resale or redistribution of the library **or its derivatives**, including "reformatted for another sampler", is forbidden (verified on the terms page). A shared Libero bundle is such a derivative. Private lane only; fine for the owner's own sketches if he accepts they cannot be distributed. https://www.pianobook.co.uk/terms-conditions/ |
| **MedleyDB / MedleyDB 2.0** | CC BY-NC-SA 4.0, non-commercial research; stems of mixed songs (not isolated notes). https://zenodo.org/records/1715175 |
| **NSynth** | CC BY 4.0, but 16 kHz, 4-second notes, mostly commercial-library renderings: useful for ML, not for Kontakt-class sound. https://magenta.tensorflow.org/datasets/nsynth |
| **IRMAS** | instrument-recognition excerpts of polyphonic music, research use; not notes. |
| **Garritan, Production Voices, VG*, Ivy Audio "Piano in 162", Maestro Concert Grand (custom)** | commercial or custom terms; listed in the SFZ directory but not free to redistribute. |
| **OrchideaSOL, FullSOL** | account-gated, non-commercial / premium. |
| **Jeff Learman jRhodes3c/3d** | CC BY-NC(-SA): good Rhodes, but NC. Private lane only. |
| **MF Tin Whistle** | CC BY-NC-SA 3.0. |
| **Kay 5-string banjo** | GPL-3.0-or-later: copyleft for samples is ill-defined; avoid. |
| **Wikimedia Commons instrument clips** | scattered, many CC BY-SA, mostly single phrases, not multisamples; use only for a specific rare instrument after checking each file. |

### 2.4 Impulse responses (room and body)

| Source | Content | Terms | Notes |
|---|---|---|---|
| **OpenAIR** (University of York) | churches, halls, cisterns, B-format and stereo IRs with metadata | mostly Creative Commons, chosen per contribution; page states CC BY 4.0 for the library; licence is at the bottom of each item page | The original `openair.hosted.york.ac.uk` host returned "account suspended" on the day of this research; `openairlib.net` is live. Good for the "Impronta" reverb and for the sacred spaces in the project's style. https://www.openairlib.net |
| **EchoThief** | about 100 natural spaces (caves, stairwells, glaciers) | free for personal use and derivative work; commercial terms are not spelled out in what I could read | Ask the author before shipping. http://www.echothief.com |
| **Voxengo free IRs** | reverb IRs | royalty-free for any purpose, including commercial use, but the IR files may not be sold or redistributed on their own | Good for private sketches; do not embed in a shared bundle. https://www.voxengo.com/impulses/ |
| **Instrument body IRs** | Freesound violin body IRs (CC0, user pe_mace) ; Bodilizer free plug-in with 27 body IRs (guitars, mandolin, violin, fiddle, piano); Princeton **NBody** project (directional IRs of six stringed instruments, 12 mics) | Freesound: CC0 for the one I saw; Bodilizer and NBody: check terms before embedding | The only practical route to "resonant body" convolution for plucked/bowed sounds. Freesound: https://freesound.org/people/pe_mace/packs/38764/ ; NBody paper https://www.cs.princeton.edu/~prc/ism98fin.pdf |

---

## 3. Best source and fallback per family

| Family | Best source (legal, shippable) | Fallback | Honest quality verdict | What must be added |
|---|---|---|---|---|
| **Piano (grand)** | Salamander Grand Piano V3 (CC BY 3.0). 16 layers, release and resonance layers. | VCSL Steinway B (CC0, fewer layers) or Kawai grand | Near Kontakt-class as raw multisample. The cost is size (see section 5) and the SFZ complexity. | Release layer (hammer and string resonance), pedal noise as optional air layer, velocity crossfades |
| **Piano (upright)** | VCSL Yamaha upright / Knight upright; VSCO CE upright nr 1 and 2 (all CC0) | LivingRoom Upright Micro (CC BY-SA 4.0, 107 MB) | Good, less detail than Salamander | Felt/mute variants as separate sounds |
| **Electric piano** | Greg Sullivan E-Pianos (CC BY 3.0, 21.5 MB) | Discord GM bank Rhodes (CC0, low fidelity); jRhodes (NC, private only) | **Weak gap.** No strong CC0/CC BY Rhodes or Wurlitzer exists in the free pool. | Build it as a hybrid: sampled tine attack + Libero's resonator and tape + a modal tine synth; or record/commission |
| **Organ** | VCSL pipe organ and renaissance organ; VSCO CE organ (CC0) | Hauptwerk sets (private only, NC risk) | Pipe organ OK (static timbre loops well). Tonewheel/Hammond: nothing free. | Tonewheel = additive synth with key-click sample; draw-bars as live parameters |
| **Solo strings** | Bowed: VSCO CE solo violin (CC0, 2 layers, 5 articulations); Bigcat Cello (CC0, 24 bit); Karoryfer double basses (CC0). Also TinySOL violin/viola/contrabass (CC BY 4.0) and Iowa strings (dry, pp/mf/ff) for layers | SSO solo strings; Philharmonia strings (BY-SA, transformed only) | **Solo violin remains the hardest case.** Sampled sustains with no legato or bow-direction changes give a "note player", not a violinist. Expect roughly pad-grade realism for sustains and good realism for pizzicato and spiccato. | Bow-noise and rosin layer, vibrato crossfade (vib/no-vib), attack transients, body IR convolution, dynamic morphing between pp/mf/ff layers (see section 6) |
| **String sections** | VSCO CE violin/viola/cello sections (CC0) | SSO sections | Good for cinematic beds; the section realism comes from the recording, which is an advantage | Loops, longer release, optional chorus from the engine |
| **Woodwinds** | VSCO CE flute, oboe, clarinet, bassoon, piccolo (CC0); VCSL saxello and tenor sax; Karoryfer Weresax and Bear Sax (CC0); MTG solo sax (CC BY 4.0) | Iowa, SSO, Philharmonia (transformed only) | Good as multisamples; winds are breath-sensitive, so the breath layer matters | Breath noise layer tied to velocity, vibrato control, legato mode |
| **Brass** | VSCO CE horn, trumpet, trombone, tuba (CC0); Karoryfer War Tuba (CC0) | Iowa, TinySOL, Philharmonia | Good for mf/f; soft-to-loud timbre change is the test | Dynamic layers crossfaded by velocity and filter, not just volume |
| **Plucked: harp** | VSCO CE harp (35 MB), VCSL concert and folk harp, Etherealwinds Harp II CE (all CC0) | FreePats harp | Good | Sympathetic resonance from the engine's "Corde" resonator |
| **Plucked: guitar, bass, lute** | Karoryfer Emilyguitar, Shinyguitar, Black and Green (CC0) | Philharmonia guitar/mandolin/banjo (BY-SA, transformed only); Karplus-Strong in `synth.py` | Electric/archtop fine; classical nylon and steel acoustic are weak | Body IR convolution, pick transients |
| **Mallets, bells** | VCSL marimba, vibraphone, xylophone, glockenspiel, tubular bells (3 sets), hand bells, kalimba, mbira (CC0); VSCO CE Glock/Marimba/Xylo | MSLP Vibes (CC BY 3.0) | Very good (short decays tolerate few layers) | Mallet hardness as velocity-mapped attack layer |
| **Choir / voice** | **No strong free source.** The vocal entries in the SFZ directory are paid (Karoryfer Hadziha, Torgbe, Hadzi-Fia) or niche (CC0 death-metal vocals). Signature Sounds children's choirs (CC0) are FX recordings. | Formant synthesis + breath; Freesound CC0 one-shots | **Weakest family.** Do not promise it from free sources. | Formant-filter choir (engine's `Vocale` filter), a sampled breath/consonant layer, unison detune; or a purchased/commissioned dataset kept in a private lane |
| **Drums / percussion** | Karoryfer Big Rusty, Swirly, Unruly, Frankensnare (CC0); SM Drums (public domain); DRS Kit, Muldjord, Naked Drums (CC BY 4.0) ; VCSL for orchestral percussion and ethnic drums | Salamander Drumkit (BY-SA 3.0) | Kontakt-class for kits (multi-mic, many layers, RR) | Needs mic layers and up to 10 RR (section 5) |
| **Ethnic / ancient winds (duduk, ney, aulos-like reeds)** | Nothing multisampled under a clean licence. Freesound has a few duduk recordings (user juskiddink, 3 files; licence not visible in the page I fetched: check per file) and a CC0 duduk sample; VCSL has ocarina, recorders, didgeridoo; shakuhachi free pack on Noiiz/Samplephonics (terms unverified, likely non-redistributable) | Transform a real reed: VSCO CE oboe, Philharmonia cor anglais (BY-SA, transformed), Iowa oboe/bassoon, then formant-shift and add reed buzz | **Library gap; synthesis wins.** Libero's own double-reed/flute model plus a sampled breath layer will beat any single Freesound note. | The `libero-slow` workflow: record-like measurements from 1-3 real notes, then model and compare spectra |
| **Synth sources** | AKWF (CC0), Karoryfer Caveman Cosmonaut and Cowsynth (CC0), SHLD pads (CC0), VCSL TX81Z voices (CC0) | Mellotron "Sforzatron" (Plogue; licence unspecified: verify) | Fine; synth material does not need a recording | Wavetable body type in the recipe API |

---

## 4. Reading the SFZ files (what I checked)

I fetched two real SFZ files into `~/Libero/cache/research/` to see what an importer must cope with.

**Salamander V3** (`salamander.sfz`, 2 KB main file, verified):
- `#define`, `#include "Data/notes.txt"`, `default_path=Samples/`, `$EXT flac`.
- Region data lives in included files; the main file has one visible `trigger=release` directive.
- `amplitude_oncc`, `amp_veltrack_oncc`, `ampeg_release_oncc`, `hdcc`, `sw_last` keyswitch between natural and retuned banks, `note_polyphony`, `off_time`, `<curve>`.
- Consequence: the main file is a **control surface**, not a region list. Parsing it literally loses the string-resonance, hammer and pedal layers.

**VSCO CE `SViolinVib.sfz`** (verified):
- Plain `<control>`/`<global>`/`<group>`/`<region>`, backslash paths (`default_path=Strings\Solo Violin\Arco Vib\`), `tune=-20` on C4, `lovel=0 hivel=62` / `lovel=63 hivel=127` (two layers), `volume=21` per region, `ampeg_dynamic`, no loop opcodes.
- The KS (keyswitch) file adds `sw_default/sw_lokey/sw_last`, `seq_length=2 seq_position=1/2` and `lorand/hirand`.

These two samples bracket the problem: VSCO is easy to map directly; Salamander needs either an evaluator or a
render-based import.

Opcodes the importer must understand (names confirmed on https://sfzformat.com/opcodes/): `sample`, `key`,
`lokey/hikey/pitch_keycenter`, `lovel/hivel`, `xfin_lovel` (velocity crossfade), `loop_mode`, `loop_start/loop_end`,
`trigger=release` with `rt_decay`, `seq_length/seq_position`, `lorand/hirand`, `group/off_by`, `amp_veltrack`,
`sw_last`, `locc/hicc`, `tune`, `offset`, `end`, `ampeg_release`, `output`.

---

## 5. Ingestion design

### 5.1 Two import modes

Implementing all of ARIA is not sensible (sfizz, BSD-2, implements it, but the repository was **archived on
2026-06-21** and is read-only; still usable as a vendored dependency). So:

1. **Structural import (default).** Parse SFZ (with `#define`, `#include`, `<control>/<global>/<master>/<group>/<region>`
   inheritance, `default_path`), resolve regions, and map them straight into Libero zones. Fast, preserves the
   real samples, handles VSCO, VCSL, SSO, Karoryfer, DrumGizmo ports.
2. **Bake import (for exotic SFZ like Salamander).** Drive a renderer (`sfizz_render`, or a small sfizz-linked tool built
   into `libero-render`) to play every (note, velocity) and export a one-shot WAV, then feed those WAVs to the compiler
   like recorded notes. This gets CC-driven layers (resonance, pedal, release) for free, at the cost of baking a fixed
   setting of each CC. Bake is also the escape hatch for DecentSampler and SF2 if a parser is not worth writing.

Other formats:
- **SF2**: write a tiny reader (RIFF sfbk: `pdta` presets, instruments, sample headers, zones) or shell out to `ffmpeg`/`fluidsynth` to bake; GM banks are low fidelity anyway, so this is optional (S for a bake via a one-off script, M for a parser).
- **DecentSampler `.dspreset`**: plain XML (`<sample path rootNote loNote hiNote loVel hiVel seqPosition loopStart loopEnd trigger>`; `trigger="release"` exists; docs https://decentsampler-developers-guide.readthedocs.io/). A parser is about 100 lines of Python. Worth doing because many free libraries ship it.
- **WAV-only libraries with names like `Instr_Art_A#3_rr1_Main.wav`** (VCSL): a naming-pattern importer (regex for note, dynamic/velocity, rr, mic) is often simpler than the SFZ.

### 5.2 What the manifest lacks

Current manifest (SPEC section 4) already has velocity ranges, takes (max 8), loops, key ranges. Gaps, in order of importance:

| Need | Why | Proposed manifest addition |
|---|---|---|
| Storage efficiency | float32 WAV is 2x to 4x too large for real libraries; Salamander raw is several GB | `"encoding": "int16" \| "int24" \| "flac"` per bundle; engine decodes on the loader thread. Keep float32 as the default for synthesised sounds. |
| Velocity crossfades | Hard vel splits sound like steps; real libraries crossfade (`xfin_*`, `ampeg_dynamic`) | zone fields `vel_xfade` (velocity units) or `gain_curve` per layer; engine blends adjacent layers |
| Round-robin count | Naked Drums has 10 RR; SSO uses 2 to 4 | raise `takes` cap to 16; add `take_policy`: `random_no_repeat` (today), `cycle` |
| Release layer | Piano releases, harp buzz, organ chiff-off, guitar string noise | `tail` zones get `release_trigger: true`, `rt_decay_db_per_s`, `held_min_ms`, `held_max_ms` (release by duration: short notes get a different release than long held ones), and `pitched: true` with `root` |
| Mic layers | DrumGizmo and orchestral libs ship close/mid/far/room | zone field `mic`: `"close" \| "mid" \| "room" \| ...`; new params `lvl_mic_*`. Default import **pre-mixes** mics at import time (one stereo file) to control size; keep mics separate only when the agent asks |
| Tuning per zone | Real libs have per-sample fine tuning (`tune=-20`) | `tune_cents` per zone; importer also measures pitch and proposes a correction |
| Sustain/loop info | VSCO has no loops; Salamander decays naturally | `loop.crossfade`, `loop.mode` (`continuous`, `sustain`, `none`), optional `one_shot: true` so the zone ignores note-off |
| Articulations / keyswitches | Libraries hold 5-10 articulations on keyswitches | Do **not** add a keyswitch engine to a v1 manifest: import each articulation as its own sound (`slug-violin-vib`, `slug-violin-pizz`) and let the agent combine; later add `articulations: [...]` with `switch` param |
| Pedal / CC-gated layers | Salamander pedal noise, resonance | handled by bake mode or dropped; do not model |
| Provenance | Legal gating | `credits: [{source, url, author, license, license_class, retrieved}]` and `bundle_license` (most restrictive), shown in the UI and copied to `build/` |
| Sample streaming | A 2 GB library will not fit a preload | Engine option: preload the first N ms of each zone and stream the rest from disk on a reader thread. Not needed if the importer keeps the RAM budget under about 400 MB per sound. |

### 5.3 The RAM and disk budget: decide, don't hope

The importer takes a `max_mb` budget (default 300) and reduces the library before writing:
1. pick the velocity layers to keep (4 to 6 for piano; 2 for winds/strings);
2. widen the root spacing (minor thirds to major thirds or fourths where tuning permits: pitch-shifting two semitones is inaudible on most instruments, much less on piano basses and on formant-heavy winds/voices, which keep dense spacing);
3. trim sample lengths (8 s for piano; sustained instruments need only 2 to 4 s plus a loop);
4. pre-mix mics to one stereo file;
5. store int16/int24/FLAC.

Rough numbers at 48 kHz stereo, 16-bit: 4 layers × 30 roots × 10 s is about 230 MB; with FLAC it is about 120 MB.

Storage strategy on this machine (38 GB free):
- Downloads: `~/Libero/cache/libraries/<library-id>/` (raw archive + extracted files, kept so re-import does not re-download). Budget warning when cache exceeds 10 GB; `library_prune()` evicts least-recently-used libraries.
- Downloaded sources that are large (Salamander 1.9 GB, VSCO 3 GB, VCSL 4 GB, Big Rusty 2.3 GB): download only the **subset** an instrument needs. GitHub repos support sparse checkout and per-file raw URLs; VSCO and VCSL release assets are ZIPs, so use the tree API (`git/trees/<branch>?recursive=1`, verified to work) to list files, then fetch only the wanted ones via raw URLs.
- Sound bundles live in `sounds/<slug>/build/`; sample cache stays out of the sound folder except the trimmed working copies (`samples/`).
- `library_fetch` must show the size before it downloads and require a confirmation flag above 500 MB.

### 5.4 Loop, tuning and release processing in the importer

- **Loops**: if the library has loop points, keep them. If not (VSCO), run the existing loop finder on each sustained zone and crossfade; report loop quality (spectral flatness delta, click energy).
- **Pitch**: measure f0 per zone (YIN or the compiler's analysis) and warn when it differs from `pitch_keycenter` by more than 10 cents; write `tune_cents`.
- **Release triggers**: `trigger=release` regions become tail zones with `held_min/held_max`; if the source lacks them, synthesise a short release from the body tail (fade + lowpass).
- **Velocity**: map `lovel/hivel` to `vel_lo/vel_hi` directly. When the library has only 2 layers, insert a crossfade and let `vel_sens` and the filter do the rest.
- **Dynamic layers**: `hivel=62` style splits become `vel_lo/vel_hi` ranges; write the raw dB offset (`volume=21`) into `gain_db` so the layers balance.

### 5.5 MCP tool signatures

All tools are additive to the existing `sample_*`, `freesound_*`, `compile`, `preview` tools.

```text
library_search(instrument: str, family: str = "", license: str = "shippable",
               max_results: int = 8) -> [LibraryCard]
    # LibraryCard: {id, name, instruments[], articulations[], layers, rr, sample_rate, bit_depth,
    #               size_mb, license, license_class, shippable: bool, quality: 1-5, url, notes}
    # `license="shippable"` hides nc/eula/unknown; "any" shows everything with a warning.

library_info(id: str) -> {full card + file tree summary (instrument folders, counts, sizes)}

library_fetch(id: str, subset: str = "", confirm: bool = False) -> {path, files, size_mb, cached}
    # subset = instrument folder or glob, e.g. "Strings/Solo Violin/Arco Vib".
    # Refuses above 500 MB unless confirm=True. Verifies checksum when the source publishes one.

import_sfz(slug: str, path: str, region_filter: str = "", mode: str = "auto",
           max_mb: int = 300, velocities: int = 0, root_spacing: int = 0,
           mics: str = "mix", max_len_s: float = 0.0, loop: str = "auto",
           articulation: str = "", attribute: str = "") -> {zones, size_mb, warnings[], credits}
    # mode: "structural" | "bake" | "auto" (structural, fall back to bake when the file uses
    # unsupported opcodes like oncc amplitude). velocities/root_spacing = 0 means "chosen by the budget".
    # Writes samples/*.flac-or-wav, a generated body layer in sound.py, and a credits block.

import_dspreset(slug, path, ...)    # same contract, XML input
import_sf2(slug, path, preset: int|str, ...)   # optional; bake-based at first
import_wav_set(slug, folder, pattern: str, ...)   # regex with {note} {vel} {rr} {mic} fields, e.g. VCSL names

library_audition(id_or_slug: str, notes="36 48 60 72 84", velocities="40 80 120") -> [audio + spectrogram]
    # Cheap preview of a fetched subset before committing, to keep token use low.

sound_licenses(slug: str) -> {sources[], bundle_license, shippable: bool, issues[]}
```

Token economy for the agent: the agent should reach a first playable sound in about 4 calls:
`library_search("solo violin")` → `library_fetch(id, subset)` → `import_sfz(slug, path)` → `preview(slug)`.
Every import result returns a compact report (zones, MB, warnings), not file lists.

### 5.6 Attribution

- Extend `download.attribute()` so imports write one structured line per source into `samples/ATTRIBUTION.md` **and**
  a machine-readable `samples/credits.json` (`source, author, url, license, license_class, retrieved, files`).
- The compiler copies credits into `manifest.json` (`credits`, `bundle_license`) and into `build/ATTRIBUTION.md`.
- Sources requiring attribution (CC BY 3.0/4.0, BY-SA) produce ready-to-paste text: for example
  "Salamander Grand Piano V3 by Alexander Holm, CC BY 3.0, https://archive.org/details/SalamanderGrandPianoV3".
- BY-SA sources set `bundle_license: "CC BY-SA 4.0"` and the UI shows it; `sound_save` warns about NC/EULA sources.

---

## 6. Hybrid sounds: combining a sampled body with synthesis and processing

All of these already fit the four-layer model (attack, body, tail, air); the point is to add a few operators
and an objective check.

| Technique | How it is done in Libero | When it helps |
|---|---|---|
| **Sample the sustain, synthesise the rest** | real body zones + a synthesised `air` bed and `tail` | cinematic pads, breathy flutes, ethereal strings |
| **Real transient over a synthetic sustain** (or the reverse) | `sample_attach_transient` already does this; an importer option `attack_from=<zone>` would cut the first 40-80 ms of a real sample into the `attack` layer and synthesise or loop the rest | violin/cello bow onsets, flute chiff, plucked strings on a sustained pad |
| **Resampling** | bake a processed chain (saturation, chorus, filter) into new zones (`workbench`), then import those zones as the body | heavy sounds where the live chain would cost CPU; also gives the "tape-on-strings" character |
| **Convolution with instrument bodies** | `sample_convolve(slug, sample, body_ir, mix)`; use a violin/guitar body IR on a dry source (Iowa, TinySOL) or on a string model; use an organ-church IR through the `Impronta` reverb | adds wood resonance to dry or synthetic sounds; makes a Karplus-Strong string sound like a guitar |
| **Dynamic layer morphing** | map velocity to pp/mf/ff crossfade, plus spectral tilt from the filter envelope (`flt_env`) | brass and winds, where loud is brighter |
| **Vibrato / non-vibrato blend** | import both VSCO "SusVib" and "SusNV" as two body layers; expose a `lvl_body` macro or a second body layer | solo violin expressiveness without legato samples |
| **Layered texture** | `sample_layer` with different regions: Iowa dry violin at -6 dB + VSCO section at -14 dB + pad bed | "big strings" cinematic patch |
| **Formant/pitch transform** | `sample_pitch` and the `Vocale` filter to turn an oboe or cor anglais into a duduk/aulos-like reed | ethnic winds with no library |
| **Physical model plus sample** | Karplus-Strong or bowed/reed model for sustain, real sample for attack and release | violin/cello; aulos-like reeds |

Quality check to require before a hybrid is "done": `compare` the compiled render against a reference clip with
spectrogram plus a short list of numbers (centroid, attack time, decay, harmonic-to-noise ratio).
The `libero-slow` skill already drives that loop.

---

## 7. What Libero should build

Priority, with effort. S is about a day, M a few days, L a week or more.

| # | Item | Effort | Why |
|---|---|---|---|
| 1 | **Library registry** (`libraries.json` shipped in the repo): id, name, instruments, licence, `license_class`, URL/tree-API source, sizes, quality rating; seeded with Tier A and B rows from this report. Tools: `library_search`, `library_info`. | S | Gets the agent to the right source in one call and avoids hallucinated URLs. |
| 2 | **Licence gate**: `license_class` per source, `bundle_license`, `sound_licenses`, warn/refuse in `sound_save` for nc/eula/unknown, structured `credits.json` and manifest `credits`. | S-M | The legal risk is the reason to be selective; do this before imports exist. |
| 3 | **`library_fetch` with subset download** (GitHub tree API + raw URLs, archive.org, Zenodo), size preview, confirmation over 500 MB, cache under `~/Libero/cache/libraries/`, LRU prune. | M | Makes 3 GB libraries usable on a 38 GB disk. |
| 4 | **`import_sfz` structural mode** (parser with `#define/#include`, inheritance, `default_path`, backslash paths; regions to zones; velocity ranges, round robins from `seq_*` and `lorand`, loop points, `tune`, `volume` to `gain_db`; release regions to tail). Covers VSCO CE, VCSL, SSO, Karoryfer. | M | Immediate access to most CC0 libraries; the biggest quality jump for the least code. |
| 5 | **Budget reducer** (`max_mb`, layer subsetting, wider root spacing, trimming, mic pre-mix) and **storage encoding** (`int16/int24/FLAC` in the manifest and engine loader). | M | Without this, a real piano cannot be loaded; engine change is the only C++ part. |
| 6 | **Manifest extensions**: `tune_cents`, `vel_xfade`, `takes` up to 16, tail `release_trigger/rt_decay/held_min/held_max`, `encoding`, `mic` (optional). Engine support in `libero-render` and the plugin. | M-L | Needed to represent real libraries faithfully; release-by-duration and velocity crossfades are audible. |
| 7 | **Importer conveniences**: automatic loop search on unlooped sustains, per-zone pitch check and correction, `attack_from` (cut real onset into the attack layer), articulation-per-sound import. | M | Turns VSCO/SSO sustains into usable instruments; supports the hybrid path. |
| 8 | **Bake mode** (`sfizz_render` or a vendored sfizz inside `libero-render`) for Salamander-class SFZ, plus `import_wav_set` for VCSL-style naming, plus `import_dspreset`. | M (bake via CLI), L (vendored engine) | Salamander is the best free piano; it needs this. DecentSampler and naming importers are cheap wins. |
| 9 | **Body/room IR shelf**: curated IRs (OpenAIR CC BY, Freesound CC0 violin body, EchoThief pending author reply) as registry items with `ir_fetch`, plus `Impronta` default per family. | S-M | Cheap realism gain for dry sources and plucked strings. |
| 10 | **Reference sounds per family built end to end** as shipped examples: piano (Salamander), solo violin (VSCO CE + Iowa layers + bow noise + body IR), flute, cello (Bigcat), harp, marimba, pipe organ, drum kit. Each with a notes file that records what worked. | L | Proves the pipeline and gives the agent templates to imitate, which is what saves tokens. |
| 11 | **Gap strategy, stated to the owner**: electric piano, choir, tonewheel organ, duduk/aulos and cinematic vocal textures have no strong free source. Options: (a) physical/hybrid models built with the `libero-slow` workflow; (b) a private lane for libraries the owner buys or records himself; (c) commissioning a short multisample session. | decision | Avoids promising "best piano / best violin" where the legal free pool cannot deliver. |
| 12 | **Streaming from disk** for libraries above the RAM budget. | L | Only if we later want raw multi-GB pianos; budget reduction covers most needs first. |

Suggested order: 1 and 2, then 3 and 4 (first playable result: VSCO CE violin, VCSL harp/marimba), then 5 and 6, then
8 (Salamander), then 7 and 9, and build the reference sounds (10) as each piece lands.

The solo violin will stay the hardest case. The honest target is convincing pizzicato, spiccato and sustained
section sounds, with a solo sustain that reads as real wood and horsehair but not a live player; the hybrid layers
in section 6 are how we push it as far as the free pool allows.

---

## 8. Sources consulted

- Salamander Grand Piano: https://github.com/sfzinstruments/SalamanderGrandPiano , https://archive.org/details/SalamanderGrandPianoV3
- VCSL: https://github.com/sgossner/VCSL ; VSCO 2 CE: https://github.com/sgossner/VSCO-2-CE , https://versilian-studios.com/vsco-community/ , https://versilian-studios.com/vcsl-keys/
- SFZ instruments directory (all category pages): https://sfzinstruments.github.io/
- Philharmonia mirror and archive: https://github.com/skratchdot/philharmonia-samples/ , https://archive.org/details/philharmonicorchestrasamples
- Sonatina Symphonic Orchestra: https://github.com/peastman/sso ; Virtual Playing Orchestra: https://virtualplaying.com/virtual-playing-orchestra-faq/
- University of Iowa MIS: https://theremin.music.uiowa.edu/mis.html
- TinySOL / OrchideaSOL: https://zenodo.org/records/3685367 , https://arxiv.org/pdf/2007.00763
- Good-sounds: https://zenodo.org/records/4588740 ; NSynth: https://magenta.tensorflow.org/datasets/nsynth ; MedleyDB: https://zenodo.org/records/1715175
- Pianobook terms: https://www.pianobook.co.uk/terms-conditions/ and FAQ https://www.pianobook.co.uk/faq/are-pianobook-sample-packs-royalty-free-or-free-for-commercial-use/
- Freesound licences: https://freesound.org/help/faq/ ; AKWF: https://github.com/KristofferKarlAxelEkstrand/AKWF-FREE
- FreePats: https://freepats.zenvoid.org/ ; OpenAIR: https://www.openairlib.net ; EchoThief: https://www.echothief.com/downloads/ ; Voxengo: https://www.voxengo.com/impulses/
- Instrument body IRs: https://freesound.org/people/pe_mace/packs/38764/ , https://www.cs.princeton.edu/~prc/ism98fin.pdf
- sfizz: https://github.com/sfztools/sfizz ; SFZ opcode reference: https://sfzformat.com/opcodes/ ; DecentSampler format: https://decentsampler-developers-guide.readthedocs.io/
