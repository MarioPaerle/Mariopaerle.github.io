# Giove · piano tecnico per sei strumenti a nastro e tastiera

Stato: piano di ricerca storico; i sei preset sono stati implementati. Il controllo espressivo aggiornato del 4 ottobre usa velocity per il volume e CC1 per la profondità del vibrato. Con CC1 a zero il vibrato di base è zero; il legato mantiene inviluppo e fase. La curva `vel_amp_curve` è opt-in e i preset precedenti conservano il comportamento originale. Verifica nativa: `~/Libero/demo/giove-v2/expression/expression-report-v2.json`, zero errori. Le proposte di vibrato automatico nel piano seguente sono state sostituite da questo controllo.

Obiettivo: sei strumenti elettronici suonabili, pieni e distinguibili: due Theremin, un Trautonium, un Volkstrautonium e due Mixturtrautonium. Sono costruzioni sintetiche ispirate ai circuiti e ai gesti documentati, non registrazioni acustiche né repliche elettriche esatte. La preferenza esplicita dell’ascoltatore prevale qui sui default generali della skill: **modo Legato predefinito**, vibrato automatico continuo e uso con tastiera MIDI/pitch wheel.

## Fonti primarie e cosa documentano

- Il [manuale originale Trautoniks del Trautonium VT 2012](https://trautoniks.de/com/downloads/VT2012/vt2012_manual_en.pdf) descrive un generatore a dente di sega, un pre-filtro selezionabile 100 Hz/spento/500 Hz, due filtri formanti separati da 12 dB, scelta BP/LP e due intervalli di frequenza (640 Hz e 6 kHz). Specifica inoltre tre ottave circa F1–C4, fine e coarse tuning, regolazione della dinamica e controllo manuale di volume. Le sue posizioni delle formanti e la risposta del circuito sono regolabili: i valori di questo documento sono riferimenti di progetto, non misure complete della risposta elettrica.
- La pagina [Trautoniks dei moduli Mixtur](https://trautoniks.de/com/modules.html) dichiara due VCO, quattro subarmoniche, tre banchi di registrazioni, controlli indipendenti 0–32, filtro/rumore/VCA per ciascuna subarmonica e l’unità “Schlagwerk” che unisce LFO e ADSR. Il secondo VCO detunabile permette di uscire dal limite degli accordi minori prodotto dal solo generatore subarmonico.
- La spiegazione tecnica [Doepfer sul Trautonium](https://doepfer.de/traut/traut_e.htm) precisa il principio: quattro divisori indipendenti con rapporti interi selezionabili da 1 a 24; ciascuna uscita è una forma d’onda a dente di sega ricca di armoniche, non una sinusoide pura. Le combinazioni subarmoniche comuni possono imporre una progressione minore. Le tre “mixture” storiche sono registri di quattro divisori, non tre accordi MIDI congelati.
- [Trautoniks definisce il VT](https://www.trautoniks.de/com/product.html) una realizzazione moderna paragonabile al Volkstrautonium storico. Quindi i due programmi affini qui sotto vanno distinti dalla loro architettura/registro e non presentati come due circuiti storici completamente indipendenti.
- Per Theremin: il [brevetto originale di Léon Theremin del 1928](https://patents.google.com/patent/US1661058A/en) descrive la variazione di frequenza e timbro tramite capacità/prossimità; il [manuale Moog Etherwave](https://api.moogmusic.com/sites/default/files/2022-04/Etherwave-Theremin_Manual_2022.pdf) conferma il controllo di altezza tramite antenna pitch e distanza della mano. L’antenna non è parte dell’interfaccia qui: tastiera e wheel forniscono il controllo discreto e continuo in modo dichiaratamente adattato.

## Sestetto proposto

| Preset (titolo provvisorio) | Ruolo/identità | Costruzione e distinzione |
|---|---|---|
| **Theremin · Vetro** | Solista chiaro, sottile, intonato | Fondamentale quasi sinusoidale più seconda armonica regolata e una punta superiore molto controllata. Attacco morbido ma udibile; formanti minime, non un pad generico. Vibrato lento che cresce dopo l’attacco; glissando ampio e pulito. |
| **Theremin · Ambra** | Solista caldo e pieno | Fondamentale più densa miscela di triangolo/dente di sega filtrato, corpo concentrato nei medi e una seconda banda formante. Conserva l’intonazione centrale; più peso e colore di Vetro senza allargamento d’unisono o chorus come scorciatoia. |
| **Trautonium · Due Formanti** | Timbro monofonico legnoso, vocale ma non “vowel synth” | Un dente di sega principale, percorso diretto disponibile e due filtri BP/LP indipendenti. Separare le bande, con una componente medio-bassa e una più alta; i livelli delle due formanti muovono il carattere, mentre pitch-wheel resta indipendente. Imitazione funzionale della sezione VT, non circuito-clone. |
| **Volkstrautonium · Manuale** | Registro più grave, essenziale e incisivo | Dente di sega più spoglio, pre-filtro commutabile equivalente a 100/500 Hz, due formanti meno pronunciate e controllo di volume/pressione lento. Target iniziale tre ottave circa; registri verificati prima di fissare il range. Deve restare chiaramente distinto da Due Formanti anche a pari volume. |
| **Mixturtrautonium · Quarta Aperta** | Voce ampia, stabile e armonicamente ricca | Quattro divisori modellati come quattro saw indipendenti a rapporti **1, 2, 3, 4** rispetto al master, con livello separato, limitazione armonica per frequenza e filtraggio per ramo. La miscela privilegia fondamentale e ottave; il divisore 3 aggiunge la quinta/fourth nel registro basso. Nessun terzo minore imposto come default. |
| **Mixturtrautonium · Frange** | Colore più obliquo, scuro e mobile | Quattro rami **1, 2, 4, 7**, con livelli e bande diverse: tre ancore su fondamentale/ottave e un settimo divisore come colore distante, non come triade minore. Eventuale secondo VCO resta a unisono al default; micro-scostamento controllabile e piccolo solo se la misura dimostra stabilità e non appanna l’intonazione. |

I rapporti sono una proposta di registri sintetici, non una trascrizione certificata delle posizioni dei registri di Oskar Sala o di una specifica macchina. Nella fase di preset si renderanno udibili i quattro rami separatamente e insieme, quindi si confronteranno i registri a pari fondamentale e loudness. Se uno dei rapporti non produce una tinta musicalmente utile, si sostituirà l’intero set documentandone intervalli e motivazione, non si “correggerà” con una triade minore fissa.

## Architettura Libero e comportamento su MIDI

- **Route SYN** per tutti e sei: oscillatori live oppure render originali di sintesi se la somma di quattro divisori e quattro catene di formante supera i due filtri simultanei supportati da `libero.forge.Patch`. Un render multizona resta sintesi originale; non si importa audio non autorizzato come surrogato.
- Il Forge espone `Voice("legato", glide=..., glide_legato_only=True)`: note sovrapposte mantengono una sola voce, non retriggerano inviluppo/attacco e possono scorrere al nuovo pitch. I preset Libero hanno lo stesso comportamento tramite `mode="Legato"`. **L’overlap MIDI è essenziale**: con eventi che terminano prima del successivo, il motore può iniziare un nuovo attacco. La demo e il test in host useranno note-on della destinazione prima del note-off della precedente, cioè una vera frase legata. Un ulteriore test con note esattamente adiacenti chiarirà se l’utente richiede anche transizioni senza overlap e quindi un intervento al motore.
- Glide iniziale proposto 80–120 ms e limitato al solo legato; accordi non sono il modo d’uso primario. Amp attack 5–20 ms per la prima nota, sustain pieno, rilascio breve-moderato. Durante gli overlap non deve riapparire un transiente di attacco.
- Vibrazione automatica su tutti e sei: LFO pitch libero/non retriggerato, centrato, sinusoide liscia a circa 5–6 Hz. Partire con profondità modesta (Theremin 8–12 centesimi, Trautonium 4–8) e aumentarla solo dopo A/B a pari volume. Se l’LFO disponibile si riavvia alla nota, provare frase sovrapposta in renderer/host e correggere solo con una modalità globale/fade LFO già supportata; niente vibrato casuale diverso ad ogni nota. La pitch wheel resta separata dal vibrato.
- Plugin e host documentano MIDI pitch bend e RPN 0: range iniziale ±2 semitoni, modificabile dal messaggio RPN. Verificare su MIDI reale che la wheel muova una nota tenuta, che il ritorno a zero ripristini il centro, che bend+vibrato si sommino senza scalini, e che il range impostato dall’host sia rispettato. Non dichiarare supporto al pitch per-nota/MPE.
- Default speciali richiesti dall’ascoltatore: **Legato, glide attivo e vibrato automatico leggero**. Il principio generale del slow skill (`Poli`, glide zero) è intenzionalmente sovrascritto per questo sestetto dal requisito espresso dall’utente. Altri effetti di nastro, wow, flutter, chorus e drive partono a zero; lo spazio resta appena percepibile e subordinato al corpo.

## Range, intonazione e differenze da misurare

Range iniziali da verificare, non da spacciare per specifiche definitive: Theremin MIDI 36–84; VT e Volk circa 36–72 (all’incirca tre ottave utili, da adattare ai filtri/registri); Mixtur 36–84 solo se divisori più alti restano udibili, senza aliasing o sub fuori banda. Ogni range è ristretto se il fondamentale/registro non è stabile; niente extrapolazione per riempire i tasti.

Per ogni preset: sweep cromatico e misure al root, limiti e semitoni intermedi; errore di centro ≤5 centesimi e nessun NaN/silenzio falso-PASS. Check anti-alias sulle armoniche superiori, DC, rumore spurio, peak e RMS a vel 36/80/116, note tenute 60 s in basso/centro/alto, release e zero clipping. Per i Mixtur controllare ogni divisore a tre frequenze master e la relazione `f_master / divisore` più armoniche proprie; confrontare anche la nota suonata (master) con il tono percepito dominante per dichiarare correttamente root e range. Testare default Legato su più passaggi e tenute con wheel a −2/0/+2 semitoni. Vibrazione: centro nel tempo, rate e profondità separati; non correggere l’intonazione inseguendo un massimo FFT mobile.

Per distinguere i sei: render di 2 frasi identiche in registro medio e basso, matched a RMS entro 0.5 dB; note singole sustain e transizione legata; confrontare spettro/centro e banda 100–800 Hz, 0.8–3 kHz, 3–8 kHz. I test numerici attestano pitch/headroom/continuity, non “calore” o gradimento. La valutazione timbrica finale richiede ascolto umano dei sei a volume pareggiato.

## Sequenza dopo autorizzazione

1. Confermare lo snapshot e sbloccare la creazione delle sole sei cartelle Giove.
2. Costruire un prototype per famiglia: Theremin Vetro e Mixtur Quarta Aperta; validare la voce Legato, wheel, vibrato continuo e quattro rami prima di moltiplicare ricette.
3. Congelare i circuiti/parametri di base, poi realizzare le quattro identità rimanenti senza duplicati di sola EQ/riverbero.
4. Produrre demo isolated + 2 frasi MIDI (una a note sovrapposte, una con bends), report native e source/design proof; far ascoltare la palette prima di dichiararla finita.

## Riferimenti Libero consultati

- `python/libero/forge/patch.py`: `Voice` e passaggio Legato senza retrigger per note sovrapposte.
- `python/libero/guides/forge.md`, sezione 7: comportamento delle frasi e glide.
- `python/libero/guides/sound_design.md`, “Realism for played instruments: takes and legato”.
- `python/libero/params.py`: `mode`, `glide`, `lfo_rate`, `lfo_pitch` e controlli di filtro.
- `plugin/README.md`, “Portamento and host pitch automation”: pitch bend/RPN 0, range di default e note host.

Piano originale preparato il 4 ottobre 2026, prima della costruzione dei preset.


Implementazione locale completata: sei preset, frasi Legato native sovrapposte, pitch di carrier/rami divisori, hold60s e headroom opzionale Poli verificati. Guida MIDI inclusa nelle notes. Rapporti finali in demo/giove-v1; riepilogo in giove-v1.md.
