# Libero performance measurements — 8 October 2026

These measurements use the native test host on an Apple M5 with 24 GB RAM,
running on battery with Low Power Mode enabled. The library contains 247 entries.
They are local engineering measurements, not a comparison against other plugins.

## Results

| Measurement | Reference | Optimized |
| --- | ---: | ---: |
| Three loaded Steinway instances, host physical footprint before opening editors | 1,609 MB | 559 MB |
| Second piano instance load | 174 ms | 10.4 ms |
| Third piano instance load | 180 ms | 10.6 ms |
| Observed WebKit RSS with one editor and the library open | 259 MB | 187 MB |
| Observed WebKit RSS with three editors | 575 MB | 440 MB |
| Library DOM elements, one editor | 9,533 | 4,052 |
| Warm library opening, one editor | 207 ms | 108 ms |
| Warm library opening, three-editor run | 212 ms | 89 ms |

MB uses decimal units. UI reference values are medians of two runs; optimized
values above are the final validation runs. Earlier optimized repetitions showed
the same direction of change. The reference UI retains eager tile creation,
eager hover SVG cloning, and catalogue refresh on every opening. Both UI variants
use the same native engine. The sample-sharing reference uses
`LIBERO_DISABLE_SAMPLE_CACHE=1` with the same instrument and native host.

WebKit processes launch through macOS rather than as direct children of the host.
The collector records newly appearing WebKit PIDs during each isolated run. That
association is useful here, but is not proof of ownership if another application
opens a WebView simultaneously. RSS includes shared pages; do not add host
physical footprint and WebKit RSS and call the result precise total memory.

Frame probes remained around 30 FPS in this environment before and after the
changes. There is no measured FPS improvement. First-editor readiness remains
roughly 0.6–1.0 seconds, with variation from WebKit initialization and OS caches.
An interrupted three-editor probe was discarded and rerun; final probes completed
with the measured page visible and no frame-probe timeout.

## Audio processing and latency

The profiler measures individual native engine calls after a 200 ms warmup,
across two seconds of audio per case. It tests 0, 1, 8 and 32 held notes at
64, 128 and 256 samples, with the instrument defaults and with global effect
mixes set to zero. Reported active-voice counts confirm the 32-voice cases.

| Instrument, 32 voices, 128 samples | Mean processing | 99th percentile | Block budget | Mean share of budget |
| --- | ---: | ---: | ---: | ---: |
| Steinway, 48 kHz | 214 µs | 231 µs | 2,667 µs | 8.0% |
| Steinway, 44.1 kHz | 204 µs | 221 µs | 2,902 µs | 7.0% |
| Volkstrautonium, 48 kHz | 103 µs | 137 µs | 2,667 µs | 3.9% |

No measured engine call exceeded its block budget across these matrices; output
was finite. The three-piano test also runs 32 notes per instance through the
processor while all three editors exist. Its combined 256-sample calls remained
below the 5,333 µs budget. These are timing observations, not a guarantee against
dropouts in a DAW with other plugins and hardware drivers.

The processor reports zero added latency samples. A 128-sample buffer at 48 kHz
spans 2.67 ms; that is not an end-to-end MIDI-to-speaker latency measurement.
Hardware I/O, the host's scheduling, and each instrument's attack still matter.
No physical audio loopback measurement was performed.

## Changes

- Unchanged decoded PCM is shared by instances in the same host process.
  Each instance keeps independent engine, voice, parameter and effect state.
- Concurrent loads of the same instrument share one decode. The cache holds
  weak references and retains no PCM after the last owning instrument releases it.
  Allocator and WebKit caches can keep resident memory above the initial baseline.
- Sample-buffer writes detach shared PCM before editing. Cache keys include
  sample rate, path, manifest contents, sample-edit contents, and audio/IR file
  size and modification time. Different rates and changed files use different entries.
- Sample-rate matches reuse the decoded buffer without a full PCM copy.
- Sound tiles are created when their collection or search results are displayed.
  Hover cards keep lightweight placeholders so the existing animation works;
  their SVG contents are cloned on hover or keyboard focus.
- Recently refreshed catalogue data is reused for five seconds when reopening
  the drawer. Explicit refreshes after library operations still fetch current data.
- Hidden editors stop native visualization collection and JavaScript animation.
  Repeated silent scope frames and unchanged playhead events are suppressed.
  Playhead expiry no longer requires a permanent idle interval.
- Waveform start/end/loop controls require exactly one manifest sample zone.
  The frontend requires an explicit count from the native backend and hides the
  previous instrument's panel during sound changes.

Sample sharing does not extend across separate host or sandbox processes.
Large first-time instruments still load decoded PCM into RAM. Disk streaming,
sample-rate-specific disk caches and first-editor startup remain future targets.
Windows performance needs measurements on an actual Windows machine.

## Validation and reproduction

The native suite with the WebView checks passed, including reference render
hashes, sample edits, import/export, articulation changes, controls, automation
relays and host state. Dedicated cache checks cover shared reads, isolated writes
and parameters, invalidation, different sample rates, release and concurrent loads.
macOS VST3/AU builds are universal Intel/Apple silicon.

`scripts/measure_performance.py` drives the native host and records JSON. Use an
isolated `LIBERO_HOME` directory containing links to the library and, optionally,
`ui-override`; the profiler does not need an audio device. For example:

```sh
python3 scripts/measure_performance.py \
  --host build/plugin/libero_host_test_artefacts/Release/libero-host-test \
  --sound /path/to/instrument --home /path/to/isolated-profile-home \
  --instances 3 --output plugin/tests/out/performance/current-ui.json
```

Use `--no-cache` for the sample-sharing reference, or `--audio --rate 48000` for
the engine matrix. The collector's process-memory measurements currently target
macOS. WebKit CPU counters are converted from Mach ticks with the system timebase;
this conversion was checked against the collector's own POSIX CPU usage.

The summary is in `libero-performance-2026-10-08.json`. Detailed run records,
the local reference UI snapshot and validation logs are kept in
`plugin/tests/out/performance/`, which is excluded from Git.


## Window state and repeated loads

The editor now stores its dimensions per processor instance and in the DAW state.
Closing immediately after a resize also saves the global fallback size. The native
editor check covers immediate close, two independently sized instances and state
restoration; all three passed.

A bounded disk cache stores lossless float PCM after sample-rate conversion. Cache
identity includes source path, size, modification time, target rate and gain; the
payload checksum is verified before use. Corrupt entries fall back to the source.
The cache is limited to 1 GiB, entries to 128 MiB, and new writes require 2 GiB of
free disk space. Superseded loading requests are cancelled between zones.

On the same Mac, with the in-memory sample cache disabled, Steinway at 44.1 kHz
took 2,648 / 2,412 / 2,228 ms without the disk cache. With it, the initial load took
2,654 ms and subsequent loads took 70 / 73 ms. Dedicated checks verified identical
sample data, recovery from a damaged cache and cancellation. First loads still
need to decode and convert the original samples. Measurements are in
`plugin/tests/out/performance/loading-v2/`; the full native suite and UI checks
passed. The updated VST3 and AU were installed locally, and AU validation passed.
Windows loading performance remains unmeasured.
