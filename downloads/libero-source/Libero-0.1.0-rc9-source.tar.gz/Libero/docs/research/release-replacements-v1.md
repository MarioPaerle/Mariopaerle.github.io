# Preparazione del bundle pubblico — 3 ottobre 2026

Stato: 18 sostituti costruiti e congelati nell’audit delle fonti; 51 candidati esportati localmente in 10 banche. Import isolato verificato: 51/51 manifest validi, tutti i byte runtime uguali alle sorgenti, riproduzione nativa non silenziosa su ogni preset. Nessuna pubblicazione o upload. I 200 originali sono preservati byte per byte nella libreria personale.

## Dimensioni misurate prima dei sostituti

GB decimali; dati non compressi. Runtime = contenuto delle cartelle build dei 200 preset originali. Include suoni esclusi: non è ancora il peso del bundle pubblico definitivo.

| Pack | Preset | Runtime GB | Materiali completi GB |
|---|---:|---:|---:|
| prove | 6 | 0.183 | 0.424 |
| mie | 12 | 0.343 | 0.855 |
| archi | 10 | 0.876 | 2.624 |
| aria | 20 | 0.566 | 2.699 |
| bassi | 9 | 0.551 | 1.962 |
| bebop | 13 | 1.523 | 4.049 |
| blue | 18 | 1.594 | 3.887 |
| chitarre | 7 | 0.548 | 2.013 |
| cielo | 8 | 4.074 | 8.332 |
| flauti | 5 | 0.175 | 0.454 |
| green | 12 | 0.395 | 0.835 |
| mog | 28 | 0.200 | 0.442 |
| ottoni | 3 | 0.054 | 0.168 |
| percussioni | 10 | 0.815 | 2.788 |
| piano | 5 | 1.049 | 3.128 |
| sintesi | 2 | 0.046 | 0.046 |
| trap | 18 | 0.617 | 1.010 |
| venere | 14 | 0.239 | 0.738 |
| Totale | 200 | 13.848 | 36.453 |

## Distribuzione proposta

Prima beta: un `.liberobank` versionato per banca, plugin in un installer separato, una pagina indice con contenuti, demo, dimensioni e SHA-256. Conservare crediti, testi delle licenze e descrizione delle modifiche nel pacchetto. Non distribuire cache e sorgenti vietate. Google Drive può ospitare i download iniziali con accesso lettore via link; account gratuito fino a 15 GB condivisi tra Drive, Gmail e Foto. Un bundle base curato e più piccolo, con Cielo e altri pack grandi opzionali, evita un download iniziale di quasi 14 GB.

Fonti ufficiali: [spazio Google](https://support.google.com/drive/answer/9312312?hl=it), [condivisione Google](https://support.google.com/drive/answer/2494822?hl=it).

## Gate del rilascio

Prima dell’upload: audit delle fonti e attribuzioni per ogni nuovo preset; scelta della licenza degli asset originali; file pubblico contenente solo preset approvati; import del pacchetto in una libreria isolata e verifica manifest/zone/dimensioni/checksum. La licenza del software e gli obblighi JUCE restano un controllo separato dai diritti sui campioni.

Il formato attuale nativo `.liberobank` è un archivio ZIP con radice banca, `bank.json`, build e figure/note/credits. L’esportazione della banca personale intera può restare bloccata finché contiene gli originali vietati: serve una selezione pubblica separata, senza eliminarli.

## Prima selezione verificata: 33 preset

Archivi locali candidati in `~/Libero/demo/release-replacements-v1/candidate-33/`, senza upload. 33 preset già classificati allowed; 4 banche selezionate, non le banche personali complete. Totale misurato degli archivi: 2.058 GB compressi.

| Selezione | Preset | Archivio MB |
|---|---:|---:|
| aria | 13 | 222.8 |
| bebop | 7 | 1096.2 |
| blue | 8 | 709.2 |
| mog | 5 | 29.4 |

`catalog.json` e `SHA256SUMS` identificano ogni file. La selezione non include alcuno dei 18 preset esclusi; i relativi sostituti verranno aggiunti solo dopo verifica delle fonti e QA.

## Selezione ampliata: 51 candidati

Gli archivi locali `candidate-51` aggiungono i 18 sostituti ai 33 già autorizzati. Peso effettivo: **2.587 GB compressi**, in dieci file versionati `.liberobank` 0.2.0. Le voci originali escluse non sono incluse. I dati dei 200 originali rimangono invariati.

| Banca | Preset | Archivio MB |
|---|---:|---:|
| archi | 3 | 125.8 |
| aria | 14 | 245.5 |
| bassi | 3 | 22.6 |
| bebop | 7 | 1096.2 |
| blue | 8 | 709.2 |
| chitarre | 3 | 72.8 |
| trap | 5 | 185.8 |
| mog | 5 | 29.4 |
| ottoni | 1 | 42.8 |
| percussioni | 2 | 56.8 |

Dodici sostituti usano fonti di terzi già autorizzate; sei includono sintesi originale con proposta locale di dedicazione CC0, da adottare nella pubblicazione. Non ci sono blocchi identificati sui diritti dei campioni di terzi. Gli obblighi della licenza software e JUCE restano separati. La chitarra acustica mantiene un corpo molto quieto nel registro basso (MIDI 40: circa −52.8 dBFS tardivi), stabile fino a 60 secondi; gli attacchi e le vecchie 36 zone automatiche sono preservati, nove nuove continuazioni risolvono le note alte finite.

Giove è una banca aggiuntiva separata e non rientra in questi 51 candidati. La preparazione degli archivi non equivale alla loro pubblicazione.
