# Sound-design method: which route for which sound, per genre

Research note for Libero. Question: what is the right *method* to make a sound, and when
to use oscillators, physical models, samples, or a mix. Evidence: producer and engineer
write-ups, sample-library practice, timbre-perception literature, and the notes of our own
banks (`~/Libero/banks/*/*/notes.md`, `~/Libero/sketches/*/notes.md`).

Honesty about the sources: most producer material is tutorial-grade (blogs, forums, vendor
pages), not measurement. Claims marked (T) are tutorial consensus, not measured. Numbers
that Libero measured itself in its own reference work are marked (L). Loudness medians per
genre come from a large survey of released tracks (see sources). Where a source did not say
something (e.g. crest factor by genre, details of Mace / Calcutta production) this document
does not invent it.

---

## 1. The principle behind every route choice

Three families of sound generation, and what each is good at:

| route | strength | weakness | Libero tool |
|---|---|---|---|
| **recording** (multisample) | the only route that carries the *irreproducible detail* of a real instrument and room: transients, noise, body, micro-timing. Full interchangeability for a single played note. | static: one captured gesture per layer; legato, growl, overblow, bowing changes are hard; RAM; blind to anything not recorded | `guide("sampled")`, `import_sfz`, `library_*` |
| **oscillator synthesis** (subtractive / wavetable / FM / additive) | total control, infinite variation, perfect tuning, small, *is* the genre's native sound for electronic music | clean and lifeless unless modulation, noise and imperfection are added; unconvincing for acoustic instruments | live `osc*/flt/fenv` params, `libero.forge` (`guide("forge")`) |
| **physical model** (waveguide, modal, reed/lip, membrane) | performance expression (continuous bow/breath/pressure), nonlinear behaviour, exact tuning, tiny memory; response to *how* it is played | high compute; the exciter and body are hard; sounds "model-ish" without a real transient and room; poor for guitar-with-nothing-under-it (our own failure) | `libero.physics`, `guide("physics")` |

J. O. Smith's framing: sampling synthesis gives full interchangeability for a single played
note, while model-based techniques give parity over a wider variety of performance
expression with far less memory but more compute; growl and overblowing are hard to get from
samples, easy from a model (CCRMA, *Viewpoints on the History of Digital Synthesis*; *Physical
Modeling Synthesis Update*). The practical corollary used throughout this note: **record what
cannot be modelled (transient, room, noise, body of a specific instrument), model what cannot
be recorded (continuous expression, nonlinear transitions), synthesise what has no acoustic
original (808, supersaw, reese, riser).**

Sample-library practice agrees: velocity changes timbre, not just loudness; round robins and
release samples are what separate a library from a keyboard patch; true legato needs interval
samples (Renoise/KVR developer threads; SampleRobot notes; Performance Samples). Our contract
rules 1-2 already encode this.

### What timbre research says to *look at*

McAdams & Siedenburg (*Perception of musical timbre*; Caclin et al. 2005, JASA, confirmatory
study with synthetic tones): the acoustic correlates most reliably tied to timbre
dimensions are
1. **attack time** (log) — separates blown/bowed from struck/plucked;
2. **spectral centroid** — "brightness";
3. **spectral deviation / irregularity** of the envelope (odd-even structure);
4. spectral flux (change of spectrum over the note) — real but less consistently salient,
   and strongly present in brass.

This is the justification for the measurement list in section 4: a match is judged first on
**attack, centroid, and the time evolution of the centroid**, before fine partial detail.

---

## 2. Genre by genre

For each genre: palette by role, signature processing, "right vs cheap", routes. Route key:
**REC** recording, **SYN** oscillator synthesis, **PM** physical model, **HYB** hybrid.

### 2.1 Trap (incl. phonk-adjacent)

Palette
- Drums: kick (short, punchy, often layered click + knock), snare/clap (layered, tight), hi-hats
  with double/triple-time rolls and pitch/velocity variation, rims, open hat, percussion one-shots.
- Bass: **808** — sine/tone sub with a decaying pitch, longer sustained notes, tuned to the key.
- Chords/leads: dark pads, bells, plucks, detuned piano, flute/choral stabs, vocal chops; often minor.
- FX: risers, vocal adlibs, reverse swells, tails, auto-tuned vocal.

Signature processing
- 808: **saturation/distortion for harmonic weight**; typical advice is to distort a parallel
  copy of the tail with the sub filtered out of the distorted copy, or tape/tube saturation at
  low drive to bring harmonics up so the 808 survives small speakers (T: Unison, Melodics,
  MusicRadar). Build the 808 as layers: click transient + short knock + synthesised tonal
  tail (T: Unison).
- Compression/clip on kick and snare bus; hats kept bright and sparse in the low mids.
- Short plates for snares; long reverb used sparingly and on vocal/pad only.

Right vs cheap
- Right: low end is **loud and clean at once** (the 808 translates to a phone because of its
  harmonics, not its sub), consistent tuning of 808s to the song key, hats with velocity
  variation and rolls, kick and 808 not fighting (sidechain or different decay), peaks glued.
- Cheap: thin tanh-sub 808, one variant across the keyboard, peaks at -6 dBFS with no
  bus glue, crunch/lo-fi on the snare (that is boom-bap, not trap), identical hat velocities.
  (L: this is exactly why `batteria-hiphop` was judged terrible; `batteria-trap/notes.md`.)
- Italian trap (Sfera Ebbasta, Ghali, Charlie Charles, Sick Luke): hats in double/triple time,
  syncopation, 808s, "threatening" synths and heavy autotune; Charlie Charles' signature is
  described as machine-gun kicks, giant bass, dimensionless snares (Wikipedia, Rolling Stone
  Italia).

Routes
| role | route | why |
|---|---|---|
| 808 | **SYN** (sine/triangle + saturation, pitch env, glide only if the player wants it) | no acoustic original; saturation design is the whole job |
| kick/snare/clap | **HYB**: recorded or synthesised click layer + synthesised body | transient from a recording is more convincing; body tuned and short |
| hats | **SYN** (metal noise / FM ratios) or **REC** one-shots | both work; variation (velocity, open/closed, choke) is what matters |
| bells/plucks/pads | **SYN** (FM, wavetable) | genre-native |
| vocal chops, flute | **REC** (processed) | formants are real |

### 2.2 Drill (UK / Brooklyn / Italian)

UK drill: ~138-144 BPM half-time, sliding 808s (the differentiator from trap's static
808), sparse minor melodies, skittering hats, sharp snares, detuned pianos, eerie pads and
choral stabs (T: Hit Producer Stash, Navid Hamidi, SoundsSpace). Routes as trap; the 808 is
**SYN with portamento/slides as a player choice (glide 0 in the default; the *player* turns
glide on**), pads/choirs **HYB** (recorded choir/strings, processed dark).
Cheap: static 808s, bright major chords, hats on a straight grid.

### 2.3 Boom-bap and lo-fi hip-hop

Palette
- Drums: dusty kick and snare with long-ish tails, swing, hats ghosted; the sound is the
  *sampler* as much as the sample.
- Bass: upright bass or sampled/filtered bass, short Moog-ish bass.
- Chords/leads: chopped jazz/soul samples, Rhodes, vibraphone, guitar licks, horn stabs.
- Texture: vinyl crackle, room hiss, tape.

Signature processing
- **12-bit / ~26 kHz sampler character** (SP-1200: 26.04 kHz, 12-bit, drop-sample pitch
  shifting, analog filter chips): aliasing folds high frequencies back as dusty top end, plus
  quantisation grit (E-mu SP-1200 description; Beat Production; audioplugin.deals).
- Tape: wow (slow) and flutter (fast) pitch modulation, tape saturation, high-frequency roll-off. Wow/flutter are zero by default; add them only for a clear tape-machine reference or brief, and audition the rendered mix because the modulated wet path can sound flanged against the direct signal.
- Swing: MPC-style off-grid placement; J Dilla's unquantised feel is the reference
  (LANDR, Ruff Draft).
- Texture: crackle bed, gentle noise floor.
- Our own measurements of four 90s tracks (L, `batteria-boombap/notes.md`) show whole-track
  integrated loudness from about -17 to -11.5 LUFS and crest factors from 10 to 16 dB: this genre
  is **not** loud and **not** squashed.

Right vs cheap
- Right: warm, dull top (rolled off above roughly 8 kHz; the exact slope must be measured per reference), tails and room kept, swing
  and velocity/timing variation, one coherent "sampler" colour across drums and loops.
- Cheap: bit-crush applied uniformly to everything, crackle louder than the music, perfectly
  quantised hats, modern bright drums over a "lo-fi" loop.

Routes
| role | route | why |
|---|---|---|
| drums | **REC** (real kit, multi-mic) through a *sampler chain* (resample 26 kHz, 12-bit, soft clip, filter) | the grit is a process, the source is a recording (L: `batteria-boombap`) |
| bass | **REC** upright, or **SYN** short sine/saw with filter | |
| keys/Rhodes | **REC** (or **PM/HYB** electric-piano model) + tape | |
| texture | **REC** noise/crackle (CC0) or **SYN** noise | |

### 2.4 Pop (contemporary)

Palette: tight programmed or hybrid drums (claps layered, finger snaps, 808 sub), synth
and sampled bass, piano / guitar / pluck chords, stacked vocal harmonies, FX transitions,
and a **small number of parts**. Max Martin's stated rule is "if you can't hear it, delete it"
(T: Frant; ResearchGate study of hook-driven production).

Signature processing
- Vocal chain focus: compression (1176-type), de-essing, doubles panned L/R, stereo
  widening from a separate bus keeping the centre clean; choruses wider than verses
  (T: Sound On Sound vocal production, MusicRadar Finneas, Gearspace).
- Sidechain on pads/bass for pulse; bright top, tight low.

Right vs cheap
- Right: **fewer parts, each one finished** — each layer has a defined register and role;
  width comes from doubles and stereo layers, not from a widening plugin on everything; hooks
  are audible at every moment.
- Cheap: many mid-heavy layers stacked, mono-incompatible widening, vocal-less "demo" feel.

Routes
| role | route |
|---|---|
| drums | **HYB** (sampled acoustic/electronic one-shots, layered) |
| bass | **SYN** (sub + saw) or **REC** electric/synth bass |
| chords | **REC** piano/guitar or **SYN** pluck/pad |
| leads | **SYN** |
| texture/FX | **SYN** + processed **REC** |

### 2.5 R&B (contemporary and neo-soul)

Palette: Rhodes/Wurlitzer, warm pads, soft guitar, 808 sub or fingered/synth bass,
micro-edited percussion with lots of negative space, melismatic and stacked vocals
(T: Output blog, Soundverse, Orphiq).

Processing: tape/cassette saturation, reverse reverb swells, granular textures, spacious
long reverb on vocals, filtered movement; tasteful, not glossy.

Right vs cheap: right = space and **texture around a close, warm vocal**, jazz-informed extended
chords; cheap = dense drums, bright thin pads, identical samples copied.

Routes: keys **REC** (electric piano) with HYB model for tine/pickup behaviour; pads **SYN** or
**HYB** (recorded breath/strings, granular); bass **SYN** sub; drums **HYB**.

### 2.6 House, techno, EDM, ambient

**House/techno**
- Palette: TR-909/808-style kick, clap, hats, rim, toms; sub bass or rolling bass; stabs,
  chord organ/piano, acid 303 line, pads, noise risers; techno adds **rumble** (kick reverb,
  sidechained, filtered), dub techno adds chords through long delay/reverb (T: Waxadisc,
  We Make Dance Music, Levels).
- Processing: kick layering (909 body + sub), bus compression with fast attack ~50 ms release,
  parallel saturation; **sidechain** is a rhythmic device (pumping sub between kicks).
- Right: tight, tuned, mono low end; kick-bass relationship; groove from hats/shuffle; **cheap**: kick
  and bass overlapping at the same frequency, pumping applied to everything equally.
- Route: almost entirely **SYN** (it is the native sound); recordings only for textures,
  vocal samples, percussion loops.

**EDM / festival**
- Supersaw lead (many detuned saws), reese bass (two saws detuned ~15-25 cents through
  a lowpass, with a locked sine underneath), big-room kick; sidechain depth varies by role
  (bass 6-9 dB, lead 2-4 dB) (T: Ghost Production, MonoSounds).
- Route: **SYN** (forge); sound design is the work.

**Ambient**
- Pads, drones, granular textures from field recordings, tape loops (Eno: loops of different
  lengths so phase relationships never reset), long reverbs. Add tape wow/flutter only when
  the brief calls for that machine drift; use synthesis movement when a pad needs slow motion.
- Grain sizes 50-100 ms for smooth pads (T). Slow irregular drift is what makes a pad feel
  hand-made rather than generated.
- Route: **HYB**: processed recordings (freeze, granular, reverse) + SYN pads. `sample_texture`
  is the Libero tool.

### 2.7 Jazz

Palette: upright bass, piano, drums with brushes/sticks, sax/trumpet/guitar/vibes.
Processing: **almost none** — the sound is in mic choice and room; EQ only shelves; room
reverb rather than effects; "the majority of the work needs to happen in the live room"
(Sound On Sound jazz trio mix rescue; Gearspace threads; Emastered). Loudness is lowest of
all pop genres (survey median about -12.8 LUFS versus about -9.5 for pop).
Right: dynamics, natural decay, brush noise, bass body; cheap: sample-like repeated notes,
dead dry sound, over-compressed ride.
Routes: everything **REC** (multisample with RR and release); PM only as hybrid layers
(e.g. upright bass body resonance). **No pure synthesis.** (`batteria-jazz`, `contrabbasso-jazz` are the model.)

### 2.8 Rock and metal

Rock palette: kit (Glyn Johns four-mic method: two overheads, kick, snare gives the "big, live,
open" Bonham-era sound; 80s gated reverb = ambience mics through a gate keyed from the close
mics) (Far Out, zZounds, Wikipedia), bass guitar, rhythm guitars (crunch), lead guitar, organ.
Metal: quad-tracked guitars — outer pair brighter/tighter (100 %), inner pair darker with more
low-mid (70-80 %) with **low gain**, DI recorded for re-amping; bass and kick carry the low
end ("modern metal is 70 % bass and kick, 30 % guitar", highpass about 100 Hz,
cut ~250 Hz); drum sample replacement; the loudest, most compressed genre (T: Gearspace, Nail
The Mix, Chernobyl Audio).
Right: guitars are **recorded DI through a real cabinet IR** (our `chitarra-elettrica-crunch`) ;
cheap: fizzy high gain (too much distortion thins the sound), single doubled track, no cab.
Routes: drums **REC**; guitars **REC DI + cab IR + amp stage (synthesis of the distortion)**; bass **REC**
or SYN; synth/organ **SYN**.

### 2.9 Classical, orchestral, cinematic

Palette: strings (sections and solo), woodwinds, brass, harp, timpani/percussion, choir;
cinematic adds **hybrid** layers: synth pulses/ostinati, sound-design hits, trailer percussion,
risers, sub drops. Hybrid scoring practice: horn sections layered (several horn patches +
marcato + solo trombone), brass with saturation/delay/imaging, pitch-bending synth under
brass (T: Cinematic Composing, VI-Control).
Processing: the room is half the sound; ensemble libraries are recorded in a hall or
scoring stage (CSS: scoring-stage ensemble famous for legato); do not stack reverbs.
Right: **legato, dynamics (pp->ff = darker->brighter), release tails, a consistent room**;
cheap: mixed dry and wet libraries, synthetic strings, every note the same, no bow noise.
Routes: **REC** for every named instrument (libero rule 1); **SYN** and processed REC for the
hybrid layer; PM for bowed/blown expression layered under recordings if legato is missing.

### 2.10 Folk / acoustic / singer-songwriter

Palette: acoustic guitar (steel, nylon), banjo, mandolin, fiddle, upright bass, light
percussion, harmonica, voice. Close mic (about 15 cm) plus a room mic is the normal two-mic
approach; ribbons for smoothness, small-diaphragm condensers for bright dark guitars; the
issue is **string and finger noise** (Recording Magazine; Audient; Gearspace).
Right: intimate, a little room, real noises; cheap: perfectly clean, uniform picking.
Routes: all **REC** (with release and fret-noise layers); PM only layered (Karplus pluck on
instruments with no recording, e.g. banjo, with **honest labelling**).
(L: `sketches/chitarra` = pure waveguide guitar -> judged unusable.)

### 2.11 Latin (reggaeton, dembow, Latin pop)

Dembow pattern: kick on beat 1 and the "and" of 2, snare/rim on the "and" of 1 and on 3
(two-bar phrase) (Wikipedia, Orphiq). Palette: 808/trap kicks and subs, bright open hats,
congas/bongos/timbales/guiro, synth leads and brass stabs, Latin-pop guitars (T: Splice
packs, Melodigging). Perreo 85-100 BPM; heavy sidechain.
Routes: drums **HYB** (808-type kits, **SYN**), aux percussion **REC** (percussioni-mano),
guitars/brass **REC**, leads **SYN**. Salsa/bossa/cumbia ensembles are **REC**.

### 2.12 Italian pop and rap

- Rap/trap: see 2.1/2.2 (Charlie Charles, Sick Luke, Dark Polo Gang lineage; French influence
  noted for Charlie Charles).
- Pop: collaborations like Dardust, Charlie Charles and Mahmood show the mix of electropop,
  baile funk, R&B and trap rhythm under pop songwriting (Wikipedia, "Soldi", "Calipso",
  "Nei letti degli altri"). Dardust is a pianist-producer: **piano and pop piano are
  central**. We did not find sourced detail on the studio chain of Mace or Calcutta; do not
  assume it. Reference tracks must be **measured**.
- Cantautorato/folk-pop: acoustic guitar, piano, strings (REC).
Routes: follow the sub-genre above; piano **REC**; drums **HYB**.

---

## 3. Decision tree (cross-genre)

1. **Is the thing a named acoustic instrument?** -> **REC**. No legal recording -> stop and report the gap
   (do not ship a model). Then ask: does the brief need continuous expression the samples lack
   (legato, growl, bowed swell)? -> add a **PM** layer.
2. **Is it native to electronic music (808, kick synth, lead, pad, reese, arp, riser, laser, "meow" hook)?** -> **SYN** with
   `libero.forge`. Add imperfection: slow drift, per-voice detune, noise floor, filter envelope. Never sample the
   thing it resembles.
3. **Is it a kit hit** (kick/snare/hat)? -> by genre: acoustic genres (jazz, rock, boom-bap, folk) **REC**
   multi-mic; electronic genres (trap, house, techno, reggaeton) **SYN** body + a recorded or synthesised transient.
4. **Is it a texture/atmosphere?** -> **HYB**: record or find the source, process (freeze, granular, tape, reverse)
   and place under or over synthesised pads.
5. **Does it need a performance gesture that is not in the samples?** (bow pressure, breath, slide) -> **PM**.
6. **Always layer by role**: transient (REC or noise click), body (REC / SYN / PM), air (noise bed / room), tail
   (release). The Libero layer model already is this (attack/body/tail/air).
7. **Mix approaches when**: the real thing is missing a quality that you can name and measure (e.g. real guitar with
   no sub; synth lead with no breath; drum recording that is too clean). Name the missing quality first, then choose the layer to add;
   if you cannot name it, do not add a layer.

Mixing rules that follow from the evidence:
- Layers must **differ in register or role** (click vs knock vs tail; sub vs mid vs top); two layers with the same
  spectrum are one layer louder.
- A synthesised body under a recorded transient reads as real; a recorded body under a synthetic transient reads as fake.
- Add saturation *after* layering (one stage glues), not per layer.
- Keep room and reverb **live**, never baked (Libero rule).

---

## 4. What to measure when matching a reference

Judge in this order (order follows the timbre literature and our past errors). All computable with
`analyze` / `compare` / `spectrogram`, or a small script:

| # | metric | why | pass-ish target (matched role) |
|---|---|---|---|
| 1 | **onset time to peak / attack (ms)** | most salient timbre dimension | within about 30 % of the reference |
| 2 | **spectral centroid, and its trajectory over the first 300 ms** | brightness and its evolution (flux) | within ~15 %; same direction (opening or closing) |
| 3 | **pitch stability** (cents drift, vibrato rate/depth, scoop at onset) | separates a held synth lead from a voice, and a meow from a chord | spread < 10 cents for held tones |
| 4 | **harmonic count and odd/even balance, rolloff dB/oct** | spectrum identity (square-ish vs saw-ish vs sine) | match rolloff slope within 3 dB/oct |
| 5 | **spectral flatness / noise-to-harmonic ratio** | breath, bow, noise bed | within a few dB |
| 6 | **energy per band**: sub (<60 Hz), low mid (200-500), presence (2-5 kHz), air (>10 kHz) | low-end weight and "dark vs bright" | within ~3 dB per band |
| 7 | **decay / T60 and tail shape** | 808 length, room, release | within ~25 % |
| 8 | **LUFS, crest factor, peak** | glue and genre (trap/EDM compressed, jazz/classical dynamic; survey medians: pop about -9.5, hip-hop about -9.7, jazz about -12.8 LUFS; classical/folk/ambient often -16 to -18 LUFS) | crest within about 2 dB |
| 9 | **stereo**: correlation, side/mid ratio, low-end mono | width and mono compatibility | low end correlation > 0.9 |
| 10 | **harmonic distortion / saturation**: share of energy at 2f, 3f, clipped sample fraction | 808 and drum glue | match the reference (e.g. % samples near full scale) |
| 11 | **velocity behaviour**: centroid soft vs loud | dynamics layers get brighter, not just louder | loud brighter by a reference-sized step |
| 12 | **aliasing >16 kHz, DC, clicks, loop seams** | defects (lint) | per contract |

Method traps already learned (kept from `libero-slow`): loudness-match before comparing spectra; measure the spread
*between* references as the realistic target; reference mixes contain bleed and codec edges (lossy sources unreliable below about -60 dB).
Add: **never trust a "name" for a sound**: measure first, then label (see "meow" below).

---

## 5. Our own failures and what method would have avoided them

| failure | cause | method that avoids it |
|---|---|---|
| **Hip-hop kit judged terrible** (`batteria-hiphop`) | mixed trap and boom-bap in one map; 11-bit crunch on snares; hits at -2.5..-10 dBFS with no bus glue; thin tanh 808 with one variant for the keyboard; two-layer boom-bap kick as the main kick | **route by genre first**: the genre decides whether the grit is a *process on recordings* (boom-bap) or *clean, loud, glued synthesis* (trap). One genre per kit. Measure reference LUFS, crest, 808 band energy before building (done in the later `batteria-trap` and `batteria-boombap`). |
| **Synthetic guitar** (`sketches/chitarra`, pure waveguide) | rule broken: no recording under an acoustic instrument; waveguide without a real body and noise sounds like a model | acoustic instrument -> **REC first**; if no legal recording, stop and say so. PM only as an added layer (resonance, sympathetic strings). Electric guitar: **REC DI + cab IR + amp stage** (`chitarra-elettrica-crunch`). |
| **Duduk / pan-flute reconstructions** | no duduk/pan-flute notes.md exists under `~/Libero/banks` or `sketches`, so the cause is **not verified here**; the likely mechanism (inferred, not measured) is rebuilding a reed/breath instrument from flute-like or synthetic material without measuring its reed buzz, breath noise and formants | measure on **isolated** passages and separate voices (multi-voice trackers mark most frames unvoiced); use the spread between references as target; check harmonic tables against energy above 4 kHz; hybrid = recorded breath/transient over a reed model. The aulos (`odisseo-aulos`) is the worked model: real flute recordings retuned and spectrally shaped to measurement. |
| **"Meow" mistaken for a cat** | named by resemblance; the sound was a held, pitch-stable chord-like tonal bed with a filtered sweep (a synth lead). A cat chop was built instead; the notes themselves admit no cat vocal could be isolated | **recognise synth sounds first**: measure pitch stability, harmonic count, centroid over time, onset sweep. Pitch-stable + sweep = oscillators + filter envelope (`libero.forge`). Never sample the thing the name suggests. |

Common thread: **the label of the sound decided the route before anything was measured**. The
method must run measure -> classify (acoustic / electronic / hybrid, genre, role) -> route -> build.

---

## Sources

Timbre and synthesis theory
- McAdams, S. & Siedenburg, K., *Perception of musical timbre* (McGill MPCL, 2019): https://www.mcgill.ca/mpcl/files/mpcl/mcadams_2019_foundmuspsychol.pdf
- Caclin, McAdams et al., *Acoustic correlates of timbre space dimensions: a confirmatory study using synthetic tones*, JASA 2005: https://www.mcgill.ca/mpcl/files/mpcl/caclin_2005_jasa_0.pdf
- Caetano et al., *Audio content descriptors of timbre*: https://comma.eecs.qmul.ac.uk/assets/pdf/Caetano_chap11.pdf
- Smith, J. O., *Viewpoints on the History of Digital Synthesis*: https://ccrma.stanford.edu/~jos/kna/kna.pdf ; *Physical Modeling Synthesis Update*: https://ccrma.stanford.edu/~jos/pmupd/pmupd.pdf
- Sampling practice: SampleRobot, https://samplerobot.com/blogs/news/creating-velocity-sensitive-instruments ; Renoise forum on velocity layers, https://forum.renoise.com/t/how-come-software-samplers-use-multi-layer-samples-for-velocity-layer/36598 ; KVR round-robin vs velocity, https://www.kvraudio.com/forum/viewtopic.php?t=579176

Hip-hop / trap / drill / lo-fi
- Unison, 808 sound design: https://unison.audio/808-sound-design/ ; transforming 808s: https://unison.audio/transforming-your-808s/
- MusicRadar, 10 tricks every trap producer should know: https://www.musicradar.com/tuition/tech/10-tricks-every-trap-producer-should-know-638684
- Melodics, Using 808s: https://melodics.com/blog/using-808s-in-your-music
- UK drill: https://www.hitproducerstash.com/blog/how-to-make-drill-type-beat ; https://navidhamidi.com/key-elements-of-a-classic-uk-drill-beat/
- SP-1200: https://en.wikipedia.org/wiki/E-mu_SP-1200 ; https://beatproduction.net/sp1200-drums/ ; https://audioplugin.deals/articles/classic-boom-bap-amp-lo-fi-plugins-sp1200-s950/
- Lo-fi / tape / swing: https://blog.landr.com/lofi/ ; https://audioplugin.deals/blog/the-ultimate-guide-to-lofi-hip-hop-production/ ; https://en.wikipedia.org/wiki/Ruff_Draft

Pop / R&B
- Max Martin analysis: https://www.thefrant.com/2025/innovation-technology/max-martins-songwriting-production-mastery-a-deep-analysis/ ; ResearchGate study: https://www.researchgate.net/publication/404944393
- Sound On Sound, Vocal production: https://www.soundonsound.com/techniques/vocal-production ; MusicRadar, Billie Eilish / Finneas vocals: https://www.musicradar.com/how-to/billie-eilish-vocals
- R&B: https://output.com/blog/best-plugins-for-rnb-neo-soul ; https://orphiq.com/resources/r-and-b-vs-soul-comparison

Electronic
- 909 and house/techno: https://www.waxadisc.com/post/keep-it-simple-how-i-mix-my-909-drums-for-house-and-techno ; https://www.wemakedancemusic.com/en/news/how-to-make-the-techno-rumble-by-mikas ; https://www.levelsmusicproduction.com/blog/teach-me-how-to-make-dub-techno
- EDM: https://theghostproduction.com/festival-edm-bigger-drop-session/ ; https://monosounds.studio/best-serum-2-bass-presets/
- Ambient: https://www.lucidsamples.com/blog/crafting-ambient-pads-from-non-musical-field-recordings-a-guide ; https://blog.imseankim.com/ambient-music-granular-synthesis-sound-design-guide/

Acoustic genres
- Jazz: https://www.soundonsound.com/techniques/mix-rescue-jazz-trio ; https://www.soundonsound.com/techniques/recording-jazz-quartet-budget ; https://emastered.com/blog/mixing-jazz
- Rock drums: https://faroutmagazine.co.uk/glyn-johns-created-led-zeppelin-drum-sound-john-bonham/ ; https://blog.zzounds.com/2020/07/23/glyn-johns-and-beyond/ ; https://en.wikipedia.org/wiki/Gated_reverb
- Metal guitars: https://www.nailthemix.com/neural-dsp-quad-cortex ; https://chernobylaudio.com/blogs/news/recording-black-metal-guitars-amp-simulators ; https://en.wikipedia.org/wiki/Re-amp
- Orchestral/hybrid: https://app.cinematiccomposing.com/store/product/143 ; https://vi-control.net/community/threads/favorite-sample-library-combinations-for-orchestration.156145/
- Folk: https://www.recordingmag.com/resources/recording-info/mics-miking/miking-the-acoustic-guitar/ ; https://audient.com/tutorial/5-essential-tips-for-recording-acoustic-guitar/

Latin / Italian
- Dembow: https://en.wikipedia.org/wiki/Dembow_beat ; https://orphiq.com/resources/what-is-dembow
- Italian trap/pop: https://it.wikipedia.org/wiki/Trap_in_Italia ; https://www.rollingstone.it/musica/interviste-musica/due-chiacchiere-con-charlie-charles/308056/ ; https://en.wikipedia.org/wiki/Charlie_Charles ; https://en.wikipedia.org/wiki/Calipso_(song)

Loudness
- Average LUFS by genre (314,876 tracks): https://freshlybakedstudios.com/blog/average-lufs-by-genre ; streaming targets: https://matlefflerschulman.com/mastering-articles/loudness-targets-and-mastering-for-streaming-platforms

Internal: `~/Libero/banks/percussioni/batteria-trap/notes.md`, `.../batteria-boombap/notes.md`, `~/Libero/banks/chitarre/chitarra-elettrica-crunch/notes.md`, `~/Libero/banks/flauti/odisseo-aulos/notes.md`, `~/Libero/sketches/{chitarra,meow-phonk,meow-lead}/notes.md`, `docs/research/{physical-modeling,sample-libraries,sample-sources}.md`.

## Green v6: sintesi originale e verifiche del corpo

Le dodici voci Green separano meccanismi reali: unisono continuo/PWM nel motore per Cedro, Miele, Ottone Verde e Bosco Largo; phase distortion, FM, formanti, morph, spettri di corde, hard sync e risonanze inarmoniche nelle altre otto. Il multisample originale è utile quando il motore non esprime quel meccanismo: otto registri, due dinamiche dichiaratamente progettate, ciclo di 24 s con portanti e movimenti periodici e attacco escluso dal loop. Una fondamentale centrale e lati filtrati sotto 180 Hz preservano il corpo in mono. Non basta allargare con riverbero.

La verifica del sustain deve leggere l’energia in finestre successive: un file lungo 60 s può contenere 50 s di silenzio. Distinguere inoltre il default continuo dalle articolazioni corte: una glissata prima nell’elenco può rendere sbagliato il preset anche con un pizzicato continuo disponibile. Gli strumenti acustici suonati a pressione richiedono loop della stessa registrazione che mantengano il gesto; l’estrapolazione modale di un oggetto colpito va dichiarata come sustain progettato.

Esempi: Ottone Verde ha ricevuto una square centrale per ridurre i vuoti di battimento; Aurora di Vetro cambia indici FM e peso delle risonanze tra le due dinamiche, anziché usare due livelli dello stesso timbro. Le prove native includono fondamentali ai confini delle zone, mono, accordi, release e due attraversamenti completi dei cicli. Le metriche non sostituiscono il giudizio dell’utente.

Il controllo della nota deve distinguere attacco, corpo e armonia della registrazione: nei synth Blue il passaggio dall’ingresso al ciclo avviene a 0,72 s, quindi una FFT che attraversa quel passaggio può produrre una stima falsa di 40 cent pur con portanti corrette. Le prove definitive analizzano una finestra successiva. Nei pizzicati e nei mantici il pitch della prima eccitazione può essere diverso da quello stabile: calibrare la fondamentale del corpo per take, mantenendo il movimento relativo dell’esecuzione. Lo zither ungherese con strum contiene bordoni fissi in Sol: è una vera articolazione musicale, ma le corde melodiche separate sono il default adatto alla tastiera cromatica.

### Green: riempire il corpo senza usare il volume come giudizio

Feedback dell’ascoltatore: Green v1 circa 6–7/10, piacevoli ma vuoti; Aria e Blue migliori. La revisione conserva i ruoli e aumenta i registri utili: portanti FM in Ambra, formanti armoniche dell’ancia in Canneto, saw centrale e supporto all’ottava in Cedro, corpo centrale nel morph di Prisma. Le anteprime prima/dopo sono confrontate a RMS simile, con margine sugli accordi e controllo mono. Ridurre automaticamente il taglio o aggiungere sub/riverbero a tutti avrebbe prodotto variazioni della stessa ricetta. Il controllo di pitch di un unisono misura separatamente la mappatura con le voci collassate: il picco FFT di un insieme in battimento non è una singola frequenza. Le misure non certificano il voto musicale; il confronto nativo è in `~/Libero/demo/library-expansion-v6/green-prima-arricchito.wav`.
