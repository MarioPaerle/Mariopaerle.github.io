# Libero: first-year market and revenue estimate

**Snapshot: 4 October 2026.** This is a planning model, not a sales forecast. Libero has no measured audience, conversion rate, mailing list, or sales history in the material reviewed, so the customer counts below are scenarios, not inferred demand. The model uses USD, direct Gumroad sales, no paid advertising, and separates cash left after platform fees from the value of the creator’s time.

**Decisione attuale:** software AGPLv3 e banche gratuite. Le vendite valgono quindi **$0** per scelta; senza pubblico o storico, le donazioni non sono stimabili. Solo come alternativa futura ipotetica, una banca originale a pagamento darebbe nello scenario base **23 acquirenti, $575 lordi e circa $248 di cassa** dopo costi modellati; nello scenario upside **160 acquirenti, $4.640 lordi e circa $3.572 di cassa**. Questi numeri sono ipotesi di scenario, non clienti osservati né un valore atteso statistico; la cassa è prima di imposte sul reddito e del lavoro del creatore.

## What the market evidence does and does not say

The visible price range is broad. The current Decent Samples shop lists 244 products, from free downloads and $7–$20 instruments to $29 sale/$59 list offers and a $149 product. SampleScience’s current Gumroad shop shows 144 products, including free/pay-what-you-want offers, $15 instruments, $20–$30 products, and bundles from $42 to $107. These are asking prices, not sales counts. Their product/review totals do not disclose units sold or revenue. [Decent Samples shop](https://www.decentsamples.com/), [SampleScience store](https://samplescience.gumroad.com/)

Vital’s official press kit lists Basic as free, Plus at $25, Pro at $80, and a $5 monthly subscription, while describing paid packs as containing additional presets, wavetables, samples, and LFO patterns. The page’s factsheet is tied to the 2020 release, so I treat it as a historical positioning example, not a freshly verified checkout price. [Vital press kit](https://vital.audio/presskit/)

There is one concrete but weak comparator: in a February 2018 JUCE forum post, the developer of Temper reported that his $10 plugin made 14 sales in its first two weeks (after a July 2017 launch), then only five more during the next five months as he stopped actively promoting it. He said he had promoted on KVR, Reddit, and social media and spent about $30 on Reddit ads; the initial 14 sales netted about $130 after Sellfy fees. This is one self-reported historical example, not an average, but it illustrates how launch attention can fade without continued visibility. [Temper developer’s account](https://forum.juce.com/t/indie-vst-developer-expectations/20518?page=2)

Free/open-source products can build reach, but the comparators do not establish a revenue rate for Libero. Pianobook says its community has over 1,000 free instruments and runs paid “Pianobook Artists” projects to support selected freelance samplers; its EULA allows the samples in users’ own commercial music but prohibits reselling or repackaging its libraries. Surge XT is free and GPL-3.0, and its FAQ explicitly says users own and may commercially distribute their audio output. Neither publishes a reliable sales conversion figure that can be transferred to Libero. [Pianobook model](https://www.pianobook.co.uk/about/), [Pianobook EULA](https://www.pianobook.co.uk/terms-conditions/), [Surge XT FAQ](https://surge-synthesizer.github.io/faq/)

## Libero’s current launch constraints

The repository’s stated first-release target is macOS 11 or later, universal arm64/x86_64, in AU and VST3 formats; the CMake target declares `VST3 AU`. There is an offline renderer, but no standalone music-making app. The checked release plan and available build target are macOS-focused; JUCE can target other platforms, but Windows/Linux builds, packaging, and QA have not been verified here. The install script installs local bundles with ad-hoc signing. The repository now has root `LICENSE` and `NOTICE` files preparing the software for AGPLv3, and the [first-release guide](/Users/mario/Documents/Libero/docs/release/first-release.md) records that direction. That settles the intended software-license choice for this planning model, but does not change individual sound-bank licenses. Developer ID signing, notarization, and final release validation remain open. See [README.md](/Users/mario/Documents/Libero/README.md), [plugin/CMakeLists.txt](/Users/mario/Documents/Libero/plugin/CMakeLists.txt), [scripts/install.sh](/Users/mario/Documents/Libero/scripts/install.sh), [LICENSE](/Users/mario/Documents/Libero/LICENSE), and [NOTICE](/Users/mario/Documents/Libero/NOTICE).

So the near-term market is macOS users who already own a compatible AU/VST3 host, not all musicians or all downloaders. A polished direct macOS release may use the Apple Developer Program; Apple currently lists it at $99 per year. [Apple enrollment pricing](https://developer.apple.com/programs/enroll/)

The current plan is the AGPLv3 route documented in the repository, so the baseline scenarios do not include a proprietary JUCE license fee. JUCE’s commercial Indie pricing is relevant only as an optional comparison if the project later changes to a closed-source distribution; current published terms list $40 per month or $800 perpetual, while the Starter tier has a $20,000 annual revenue/funding threshold and is not a substitute for complying with AGPL obligations. The threshold is not profit and is not reduced by Gumroad fees. [JUCE pricing](https://juce.com/get-juce/), [JUCE 9 EULA](https://juce.com/legal/juce-9-licence/)

## Scenarios

The detailed inputs and arithmetic are in [libero-market-year-one.json](/Users/mario/Documents/Libero/docs/research/libero-market-year-one.json). “Qualified visits” means people who actually reach a relevant product page, not general plugin downloads, social impressions, or mailing-list subscribers. All buyer counts, conversion rates, and scenario weights are explicit assumptions, not observed demand or measured probabilities; weighted totals are arithmetic over chosen scenarios, not a statistical expected value.

For the current **all-free and open-source** direction, including banks, sales revenue is **$0 by design**. Optional donations/support are possible, but there is no Libero audience or donation history from which to estimate them. For scale only—not as a forecast—100 supporters × $5 would be $500 gross before fees/refunds; 20 supporters would be $100. This is a sensitivity example, not observed donor demand. The paid-bank rows below are a separate hypothetical future route, not a recommendation to sell the current CC0-prepared banks.

| Route and case | Qualified visits | Assumed conversion | Orders | Average order | Gross | After modeled direct platform/refund fees |
|---|---:|---:|---:|---:|---:|---:|
| Free plugin + optional authored banks, quiet | 300 | 1.0% | 3 | $19 | $57 | $46 |
| Free plugin + optional authored banks, base | 1,500 | 1.5% | 23 | $25 | $575 | $467 |
| Free plugin + optional authored banks, upside | 8,000 | 2.0% | 160 | $29 | $4,640 | $3,791 |
| Paid plugin + banks, quiet | 300 | 0.5% | 2 | $39 | $78 | $64 |
| Paid plugin + banks, base | 1,500 | 0.8% | 12 | $39 | $468 | $386 |
| Paid plugin + banks, upside | 8,000 | 1.2% | 96 | $39 | $3,744 | $3,085 |

For the **free-core plus future paid-bank** route, the weighted scenario arithmetic is **about 26 orders, $697 gross, and $568 after modeled direct fees/refunds**. After an assumed $219 baseline fixed cost ($99 Apple membership plus a $120 planning allowance for domain/hosting), that leaves roughly **$349 cash before income taxes and labor**. This is not the all-free route, and it is not a statistical estimate. A proprietary JUCE Indie license is an optional closed-source comparison only; if that future route were selected, subtract another $800. Valuing 75 hours of first-year work at $25/hour leaves **about −$1,526** before any optional JUCE cost, or **−$2,326** with the $800 license.

For the all-paid route, the hypothetical weighted result is **about 15 orders, $581 gross, and $479 after platform fees/refunds**. After the same baseline cost, that is **$260 cash before labor**, or **−$1,615** after valuing 75 hours at $25/hour. This route uses lower conversion assumptions than the free-core route, but both sets of rates remain guesses until Libero has an actual funnel.

The cross-platform illustration is conditional, not a forecast: 5,000 qualified visits × 2% × $29 gives 100 orders and $2,900 gross; the modeled variable net is $2,369, or $2,150 after baseline fixed costs. It omits cross-platform engineering, signing, QA, support and hosting costs. At 200 incremental hours valued at $25/hour, it becomes **−$2,850** before those other costs. Reaching more platforms only helps financially if distribution also creates enough new qualified buyers.

## Fees, break-even, and the “real money” bar

Gumroad’s current direct-link fee is 10% + $0.50, plus card processing at 2.9% + $0.30. Its Discover marketplace fee is 30%; the scenarios assume direct sales, not discovery. Gumroad says it returns its own fee for refunded orders but retains the payment-processor portion. The calculation assumes 3% full refunds and models that retained processing fee. Gumroad’s merchant-of-record service handles applicable indirect sales-tax collection/remittance; that does not settle the creator’s income-tax, business-registration, accounting, or deductible-expense position. [Gumroad pricing](https://gumroad.com/pricing), [fee and refund details](https://gumroad.com/help/article/66-gumroads-fees)

At a $25 average order, the modeled expected cash after platform fees and refunds is about **$20.32 per order**. After the $219 baseline fixed cost, the approximate sales needed are:

- **$5,000 operating cash surplus:** 257 orders; **$10,000:** 504 orders.
- Including 75 hours valued at $25/hour: **350 orders** for $5,000 and **596** for $10,000.
- If an $800 JUCE Indie perpetual license is also needed: **389** and **635** orders, respectively, including that labor allowance.

Those targets are materially above the hypothetical base scenario’s 23 paid orders. To get 257 buyers requires about **25,700 qualified visits at 1% conversion, 17,134 at 1.5%, or 12,850 at 2%**. For a first release focused on macOS AU/VST3 and with no demonstrated audience, those traffic levels are the central bottleneck; they are not implied by downloads, stars, or the existence of free users.

## Recommendation for a low-time, no-marketing-team launch

If the goal is everything free/open source, keep the plugin and soundbanks free, make donations optional, and treat year one as validation/community building rather than revenue generation. Track real downloads, qualified page visits, donations, support requests, and repeat engagement instead of forecasting income without an audience. If the owner later chooses a paid route, test one or two distinct original banks around $15–$25 with a direct checkout and a strict time cap; do that only after deciding whether the sound license should remain CC0. A proposed 90-day checkpoint is a management rule, not an industry benchmark. The Temper account above is a reminder that an initial release spike can fade quickly without ongoing visibility.

One important economics caveat: Libero’s newly authored bank sounds have been prepared with proposed CC0 dedications. If those are used in public, people can redistribute the files themselves. That is consistent with an all-free/open release; it makes current banks a poor basis for exclusive paid-sample sales. Any future paid soundbank route should use original material whose license and contributor agreements intentionally support that model.

Keep authentic Taijiguy Mellotron recordings out of paid products. The source permission documented separately is freeware/no-payware only, so it does not become CC0 merely because Libero’s engine is open source. A separate, free add-on could fit that permission if all attribution and distribution terms are followed; do not call it open-content or bundle it with paid items.

## Known limits

This is a small-sample business model, not an addressable-market calculation. No reliable public comparable unit sales/revenue were found for the listed stores, and free-download or review totals are not treated as buyers. The model excludes income tax, VAT on business costs, payment-country variation, chargebacks, affiliate splits, paid marketing, legal/accounting costs, support beyond the stated labor allowance, and any income from donations. Any future proprietary JUCE route would have separate license and funding-threshold terms; that optional comparison is not included in the current AGPLv3 baseline. It is not tax or legal advice.
