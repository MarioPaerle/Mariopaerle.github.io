# Sound data terms for the release candidate

The release preparation uses CC0 1.0 for original Libero-generated audio, preset
figures and preset metadata authored for the public selection. This is separate
from the software's AGPLv3. The full CC0 instrument is available at
https://creativecommons.org/publicdomain/zero/1.0/legalcode.en .

Third-party source recordings retain their original terms. Read each preset's
`samples/credits.json`, `samples/ATTRIBUTION.md` and any included source-license
files. CC BY recordings require attribution, source/license links and a record
of modifications. Libero does not grant rights that the recording author did
not grant. A permissive software license does not make every working-library
sound eligible for an open bank.

## Commercial music

The selected CC0, CC BY 3.0 and CC BY 4.0 sounds may be used in music that you sell,
stream, license or otherwise monetize. CC0 does not require attribution or
royalty payments. CC BY instruments include the VocalSet choir, Pianet T,
Concert Grand Piano, Felt Piano, Toy Piano and the TinySOL-based winds. Retain
the required attribution, source and license links, and modification information
from each instrument's included credits. These permissions concern the included
sound recordings; they do not clear someone else's composition or performance.
The software's AGPLv3 does not, merely through using the plugin, require your
music or DAW project to be released under AGPLv3.

Authoring recipes execute Python with the user's account permissions. Importing
and playing a compiled pack does not require executing its recipe. Review any
recipe before compiling it; the authoring subprocess is not a security sandbox.

The 18 restricted original presets remain outside the public selection; their
new cleared replacements are separate presets. Authentic Taijiguy Mellotron
recordings have freeware/no-payware terms rather than CC0 or an unrestricted
open-content license. When supplied, they appear in the separate Giove Freeware
collection with their own notice. Taijiguy's stated commercial restriction concerns
software distribution; the notice describes the publisher's free-use grant and
does not assign an open-content license.

Five Strings, when supplied in Blue GPL, retains GPL-3.0-or-later for its sample
and instrument data, with the preferred editable source included. The original
FlameStudios author separately states that music made with his samples may be
released under the musician's own license and that the musician keeps royalties.
Read the Blue GPL notice and included author statement. This exception is specific
to that source; it is not a rule about all GPL-licensed audio.

Review the catalog and the separation of software, original sound data and
third-party recording terms with each release. The working library is broader
than the published selection. Rights and attribution reports may be sent to
paerle.music@gmail.com; identify the file and supporting rights information.
