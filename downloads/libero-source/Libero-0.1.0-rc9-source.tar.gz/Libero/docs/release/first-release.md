# Libero pre-release

Libero 0.1.0 is being prepared for a quiet testing release. The supported builds
are macOS 11+ universal arm64/x86_64 AU and VST3, and Windows 10/11 x64 VST3.
Software, sound packs and authoring sources have separate downloads and licenses.

## Download location

[GitHub Releases](https://github.com/MarioPaerle/Libero/releases)

Pre-release 0.1.0-rc4 is prepared as a draft. It contains platform binaries,
corresponding sources and the audited 0.1.1 banks: 75 presets across 11
collections. The complete bundle is supplied as two independent ZIP parts below
GitHub's 2 GiB per-asset limit. Both parts can be imported in one selection.
See [contents, import instructions and licenses](sound-packs.md).

The repository is private until the author approves public visibility and
publication. The [previous Drive release](https://drive.google.com/drive/folders/1H8RPLpUjnRy4grvidcRvtLt1DuVlx28L?usp=drive_link)
remains an older fallback. Keep versioned files unchanged after distribution.

Only the selected banks are cleared by this release audit. The working library
contains additional restricted, conditional and unresolved recordings. Authentic
freeware-only Mellotron samples are excluded from this open selection; the
Giove tape-inspired instruments are separate presets. The software's AGPLv3
license does not replace source-recording terms.

## Installation

- [macOS installation](install-macos.md): copy the AU/VST3 bundles into user
  plugin folders. No guided PKG installer is supplied.
- [Windows installation](install-windows.md): run the x64 EXE installer or copy
  the complete VST3 folder. The editor requires Microsoft WebView2 Runtime.
- [Sound packs](sound-packs.md): import inside Libero and review version and
  replacement warnings before installation.

Python and a source checkout are not required to use downloaded plugin builds.
The macOS preview is ad-hoc signed and not notarized. The Windows installer is
unsigned. Developer signing remains work for a later distribution build.

## Build and package

For macOS, build with `scripts/build.sh`, install with `scripts/install.sh`,
then run `plugin/tests/run_tests.sh --ui --installed`. After validation, stage
outside the repository in a fresh output directory:

```sh
python3 scripts/prepare_release.py --output "$HOME/Libero/releases/0.1.0-rc4-macos" \
  --label 0.1.0-rc4
```

The packager validates both architectures, includes dependency notices, archives
corresponding sources and writes hashes and signing details. It refuses to
replace an existing stage. An optional `--banks-dir` argument can produce a
combined plugin-and-banks ZIP. The GitHub release distributes plugin builds
and the two sound-bundle ZIP parts separately.

For Windows, install Visual Studio 2022 C++ tools, CMake and Python 3.12, then:

```powershell
./scripts/build-windows.ps1
python -m pip install numpy scipy soundfile
python plugin/tests/test_windows.py build/windows
./scripts/package-windows.ps1
```

Packaging requires Inno Setup 6 and produces the x64 installer, ZIP, matching
source archive and checksums. Automated Windows checks cover rendering, MIDI,
agent communication, sample edits, VST3 loading, Unicode paths, bank import and
update handling, the embedded WebView2 UI and installer execution.

Private preview builds and logs currently use draft GitHub release attachments
because Actions artifact storage is unavailable. This transport is skipped for
public repositories; native and installer checks still run. Public binary
downloads use the shared release folder. Automated artifact publication for a
public repository remains separate from these checks.

## Validation and release records

Before distributing a build, retain:

- Source snapshot and inventory, compiler versions and dependency notices.
- Archive hashes, sound catalog, recording credits and applicable licenses.
- Native rendering, MIDI, state restoration and bank-import test results.
- Plugin discovery and editor checks, plus installation results for each OS.
- Known issues and the remaining actual-DAW test checklist.

The 75 selected presets were imported into an isolated library and rendered with
the native engine; archive integrity and runtime-file hashes were checked.
Windows testing in users' DAWs is still needed. Reports should identify OS,
DAW/version, sample rate, buffer size and reproduction steps.

## Website and blog

The existing GitHub Pages site can host the Libero page and the author's blog.
Link to the shared download folder, source repository, installation guides and
issue tracker. Keep sound archives on the file host rather than in the website
repository. Blog posts are written by the project author.
