# Packs the shipped parts of UI_DIR into OUT (zip), paths relative to UI_DIR.
# Only index.html, css/, js/, themes/, fonts/, img/ are embedded (docs/ and mock/ are dev-only).
# Works with a missing or partial ui/.

set(UI_ITEMS index.html css js themes fonts img)

file(REMOVE_RECURSE "${STAGE}")
file(MAKE_DIRECTORY "${STAGE}")

foreach(item IN LISTS UI_ITEMS)
    if(IS_DIRECTORY "${UI_DIR}/${item}")
        file(COPY "${UI_DIR}/${item}" DESTINATION "${STAGE}" PATTERN ".DS_Store" EXCLUDE)
    elseif(EXISTS "${UI_DIR}/${item}")
        file(COPY "${UI_DIR}/${item}" DESTINATION "${STAGE}")
    endif()
endforeach()

file(GLOB_RECURSE files RELATIVE "${STAGE}" "${STAGE}/*")

if(NOT files)
    file(WRITE "${STAGE}/.empty" "")
    set(files ".empty")
endif()

list(SORT files)
file(REMOVE "${OUT}")
execute_process(
    COMMAND ${CMAKE_COMMAND} -E tar cf "${OUT}" --format=zip -- ${files}
    WORKING_DIRECTORY "${STAGE}"
    RESULT_VARIABLE rv)

if(NOT rv EQUAL 0)
    message(FATAL_ERROR "failed to create ${OUT}")
endif()
