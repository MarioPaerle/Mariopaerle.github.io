#pragma once

#include "../engine/ParamsJson.h"
#include "../engine/RateCache.h"
#include <chrono>
#include <numeric>
#if JUCE_MAC
 #include <mach/mach.h>
 #include <sys/resource.h>
#endif

namespace performance
{
inline int editorSizeCheck()
{
    auto a = std::make_unique<libero::LiberoProcessor>();
    auto b = std::make_unique<libero::LiberoProcessor>();
    {
        std::unique_ptr<juce::AudioProcessorEditor> editor (a->createEditorAndMakeActive());
        editor->setSize (1410, 830);
        a->editorBeingDeleted (editor.get());
    }
    const auto cfg = libero::library::readConfig()["editor_size"];
    const bool immediate = (int) cfg["width"] == 1410 && (int) cfg["height"] == 830;
    {
        std::unique_ptr<juce::AudioProcessorEditor> editor (b->createEditorAndMakeActive());
        editor->setSize (1660, 920);
        b->editorBeingDeleted (editor.get());
    }
    std::unique_ptr<juce::AudioProcessorEditor> reopened (a->createEditorAndMakeActive());
    const bool independent = reopened->getWidth() == 1410 && reopened->getHeight() == 830;
    juce::MemoryBlock state; a->getStateInformation (state);
    auto restored = std::make_unique<libero::LiberoProcessor>();
    restored->setStateInformation (state.getData(), (int) state.getSize());
    std::unique_ptr<juce::AudioProcessorEditor> session (restored->createEditorAndMakeActive());
    const bool roundtrip = session->getWidth() == 1410 && session->getHeight() == 830;
    a->editorBeingDeleted (reopened.get());
    restored->editorBeingDeleted (session.get());
    std::cout << "editor-size: immediate-close=" << immediate << " independent=" << independent << " state-roundtrip=" << roundtrip << std::endl;
    return immediate && independent && roundtrip ? 0 : 1;
}
inline int loadingCheck (const juce::String& path)
{
    if (juce::SystemStats::getEnvironmentVariable ("LIBERO_DISABLE_SAMPLE_CACHE", {}) != "1"
        || juce::SystemStats::getEnvironmentVariable ("LIBERO_HOME", {}).isEmpty()) return 2;
    juce::String error;
    auto a = libero::SoundData::load (juce::File (path), 48000, error);
    auto b = libero::SoundData::load (juce::File (path), 48000, error);
    const auto equal = [&] (const auto& x, const auto& y)
    {
        if (!x || !y || x->zones.size() != y->zones.size()) return false;
        for (size_t i = 0; i < x->zones.size(); ++i)
            if (libero::rateCache::checksum (x->zones[i].audio) != libero::rateCache::checksum (y->zones[i].audio)) return false;
        return true;
    };
    const bool identical = equal (a, b);
    auto files = libero::rateCache::directory().findChildFiles (juce::File::findFiles, false, "*.lpcm");
    const bool populated = !files.isEmpty();
    if (populated)
    {
        juce::FileOutputStream stream (files[0]);
        stream.setPosition (0); stream.writeInt (0); stream.flush();
    }
    auto recovered = libero::SoundData::load (juce::File (path), 48000, error);
    const bool recovery = populated && equal (a, recovered);
    std::array<std::unique_ptr<libero::SoundData>, 8> simultaneous;
    std::array<juce::File, 8> sources;
    for (auto& source : sources)
    {
        source = juce::File::createTempFile ("-libero-parallel-load");
        if (!juce::File (path).copyDirectoryTo (source)) return 1;
    }
    std::vector<std::thread> loaders;
    for (size_t i = 0; i < sources.size(); ++i)
        loaders.emplace_back ([&, i]
        {
            juce::String loadError;
            simultaneous[i] = libero::SoundData::load (sources[i], 48000, loadError);
        });
    for (auto& loader : loaders) loader.join();
    const bool concurrent = std::all_of (simultaneous.begin(), simultaneous.end(),
        [&] (const auto& loaded) { return equal (a, loaded); });
    for (auto& source : sources) source.deleteRecursively();
    error.clear();
    auto cancelled = libero::SoundData::load (juce::File (path), 48000, error, [] { return true; });
    const bool immediate = !cancelled && error == "load cancelled";
    std::atomic<int> calls { 0 }; error.clear();
    auto interrupted = libero::SoundData::load (juce::File (path), 48000, error, [&] { return ++calls > 8; });
    const bool midLoad = !interrupted && error == "load cancelled";
    std::cout << "loading: populated=" << populated << " bit-identical=" << identical << " corruption-recovery=" << recovery
              << " concurrent-distinct=" << concurrent << " immediate-cancel=" << immediate << " mid-load-cancel=" << midLoad << std::endl;
    return populated && identical && recovery && concurrent && immediate && midLoad ? 0 : 1;
}
inline int sampleCacheCheck (const juce::String& source)
{
    const auto folder = juce::File::createTempFile ("-libero-cache");
    if (!juce::File (source).copyDirectoryTo (folder)) return 1;
    juce::String error;
    auto a = libero::SoundData::load (folder, 48000, error);
    auto b = libero::SoundData::load (folder, 48000, error);
    if (!a || !b || a->zones.empty() || b->zones.empty()) { folder.deleteRecursively(); return 1; }
    const auto original = b->zones[0].audio.getSample (0, 0);
    const bool shared = a->zones[0].audio.getReadPointer (0) == b->zones[0].audio.getReadPointer (0);
    a->zones[0].audio.getWritePointer (0)[0] = original + 1;
    const bool isolated = b->zones[0].audio.getSample (0, 0) == original;
    a->params.getDynamicObject()->setProperty ("master", 17);
    const bool paramsIsolated = (double) b->params["master"] != 17;
    auto differentRate = libero::SoundData::load (folder, 44100, error);
    const bool rateIsolated = differentRate && differentRate->zones[0].audio.getReadPointer (0) != b->zones[0].audio.getReadPointer (0);
    folder.getChildFile ("sample-edits.json").replaceWithText ("{\"edits\":{}}");
    auto changedEdits = libero::SoundData::load (folder, 48000, error);
    const bool editsInvalidate = changedEdits && changedEdits->zones[0].audio.getReadPointer (0) != b->zones[0].audio.getReadPointer (0);
    const auto manifestFile = folder.getChildFile ("build/manifest.json");
    auto manifest = juce::JSON::parse (manifestFile);
    manifest.getDynamicObject()->setProperty ("title", "Cache refresh");
    manifestFile.replaceWithText (juce::JSON::toString (manifest));
    auto changedManifest = libero::SoundData::load (folder, 48000, error);
    const bool manifestInvalidates = changedManifest && changedManifest->title == "Cache refresh"
        && changedManifest->zones[0].audio.getReadPointer (0) != changedEdits->zones[0].audio.getReadPointer (0);
    const auto sample = folder.getChildFile ("build").getChildFile (manifest["zones"][0]["file"].toString());
    sample.setLastModificationTime (sample.getLastModificationTime() + juce::RelativeTime::seconds (2));
    auto changedFile = libero::SoundData::load (folder, 48000, error);
    const bool fileInvalidates = changedFile && changedFile->zones[0].audio.getReadPointer (0) != changedManifest->zones[0].audio.getReadPointer (0);
    const std::weak_ptr<const libero::SoundData> lifetime = b->cacheBacking;
    a.reset(); b.reset();
    const bool released = lifetime.expired();
    changedEdits.reset(); changedManifest.reset(); changedFile.reset(); differentRate.reset();
    std::array<std::unique_ptr<libero::SoundData>, 4> concurrent;
    std::vector<std::thread> threads;
    for (size_t i = 0; i < concurrent.size(); ++i)
        threads.emplace_back ([&, i] { juce::String loadError; concurrent[i] = libero::SoundData::load (folder, 48000, loadError); });
    for (auto& thread : threads) thread.join();
    bool singleFlight = concurrent[0] != nullptr;
    for (size_t i = 1; i < concurrent.size(); ++i)
        singleFlight = singleFlight && concurrent[i] && concurrent[i]->zones[0].audio.getReadPointer (0) == concurrent[0]->zones[0].audio.getReadPointer (0);
    folder.deleteRecursively();
    std::cout << "sample-cache: shared=" << shared << " write-isolated=" << isolated << " params-isolated=" << paramsIsolated
              << " rate-isolated=" << rateIsolated << " edits-invalidate=" << editsInvalidate
              << " manifest-invalidates=" << manifestInvalidates << " file-invalidates=" << fileInvalidates
              << " released=" << released << " concurrent-shared=" << singleFlight << std::endl;
    return shared && isolated && paramsIsolated && rateIsolated && editsInvalidate && manifestInvalidates && fileInvalidates && released && singleFlight ? 0 : 1;
}
inline juce::var object() { return juce::var (new juce::DynamicObject()); }
inline void put (juce::var& v, const char* key, juce::var value) { v.getDynamicObject()->setProperty (key, value); }
inline double now() { return juce::Time::getMillisecondCounterHiRes(); }
inline int loadProfile (const juce::String& path, double rate)
{
    for (int i = 0; i < 3; ++i)
    {
        juce::String error; const auto start = now();
        auto sound = libero::SoundData::load (juce::File (path), rate, error);
        if (!sound) { std::cerr << error << std::endl; return 1; }
        auto report = object(); put (report, "run", i); put (report, "load_ms", now() - start);
        put (report, "rate", rate); put (report, "zones", (int) sound->zones.size());
        put (report, "first_zone_checksum", sound->zones.empty() ? juce::String() : juce::String::toHexString (libero::rateCache::checksum (sound->zones.front().audio)));
        std::cout << juce::JSON::toString (report, true) << std::endl;
    }
    return 0;
}
inline juce::var memory()
{
    auto v = object();
   #if JUCE_MAC
    task_vm_info_data_t info {};
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    if (task_info (mach_task_self(), TASK_VM_INFO, reinterpret_cast<task_info_t> (&info), &count) == KERN_SUCCESS)
    {
        put (v, "resident_bytes", (juce::int64) info.resident_size);
        put (v, "footprint_bytes", (juce::int64) info.phys_footprint);
    }
    rusage usage {};
    if (getrusage (RUSAGE_SELF, &usage) == 0)
        put (v, "cpu_seconds", usage.ru_utime.tv_sec + usage.ru_utime.tv_usec * 1.e-6
                                + usage.ru_stime.tv_sec + usage.ru_stime.tv_usec * 1.e-6);
   #endif
    return v;
}
inline void emit (const char* stage, juce::var v)
{
    put (v, "stage", stage);
    std::cout << juce::JSON::toString (v, true) << std::endl;
}
inline juce::var timings (std::vector<double> us, double budgetUs)
{
    auto v = object();
    if (us.empty()) return v;
    const auto mean = std::accumulate (us.begin(), us.end(), 0.0) / us.size();
    const int exceeded = (int) std::count_if (us.begin(), us.end(), [budgetUs] (double t) { return t > budgetUs; });
    std::sort (us.begin(), us.end());
    const auto q = [&] (double p) { return us[(size_t) (p * (us.size() - 1))]; };
    put (v, "blocks", (int) us.size()); put (v, "mean_us", mean);
    put (v, "median_us", q (.5)); put (v, "p95_us", q (.95)); put (v, "p99_us", q (.99));
    put (v, "max_us", us.back()); put (v, "budget_us", budgetUs);
    put (v, "mean_budget_percent", 100.0 * mean / budgetUs);
    put (v, "blocks_above_budget", exceeded);
    return v;
}

inline int audio (const juce::String& path, double rate)
{
    auto initial = memory(); put (initial, "sample_rate", rate); emit ("baseline", initial);
    juce::String error;
    const double start = now();
    auto sound = libero::SoundData::load (juce::File (path), rate, error);
    if (!sound) { std::cerr << error << std::endl; return 1; }
    auto loaded = memory();
    put (loaded, "load_ms", now() - start); put (loaded, "zones", (int) sound->zones.size());
    juce::int64 pcm = 0;
    for (const auto& z : sound->zones) pcm += (juce::int64) z.audio.getNumChannels() * z.audio.getNumSamples() * sizeof (float);
    put (loaded, "decoded_zone_bytes", pcm); emit ("loaded", loaded);
    libero::ParamSet defaults;
    libero::applyJsonParams (defaults, sound->params);
    defaults.setChoice ("mode", "Poli"); defaults.set ("voices", 32);
    libero::Engine engine;
    engine.setParameters (defaults); engine.prepare (rate, 256);
    engine.submitSound (std::move (sound)); engine.finishLoadingOffline();
    for (const int block : { 64, 128, 256 })
        for (const bool bypass : { false, true })
            for (const int notes : { 0, 1, 8, 32 })
            {
                auto params = defaults;
                if (bypass)
                    for (const char* id : { "rev_mix", "echo_mix", "tape_mix", "res_mix", "caldi_amount" }) params.set (id, 0);
                engine.setParameters (params); engine.prepare (rate, block); engine.reset();
                std::vector<float> left ((size_t) block), right ((size_t) block);
                juce::MidiBuffer midi;
                for (int n = 0; n < notes; ++n) midi.addEvent (juce::MidiMessage::noteOn (1, 48 + n, (juce::uint8) 90), 0);
                engine.process (left.data(), right.data(), block, midi); midi.clear();
                const int warmup = (int) (.2 * rate / block);
                for (int i = 0; i < warmup; ++i) engine.process (left.data(), right.data(), block, midi);
                const int count = (int) (2 * rate / block);
                std::vector<double> us; us.reserve ((size_t) count);
                bool finite = true; int maxVoices = 0, minVoices = 32;
                for (int i = 0; i < count; ++i)
                {
                    const auto t = now(); engine.process (left.data(), right.data(), block, midi);
                    us.push_back ((now() - t) * 1000);
                    maxVoices = std::max (maxVoices, engine.getActiveVoiceCount());
                    minVoices = std::min (minVoices, engine.getActiveVoiceCount());
                    for (int k = 0; k < block; ++k) finite = finite && std::isfinite (left[(size_t) k]) && std::isfinite (right[(size_t) k]);
                }
                auto row = timings (std::move (us), block * 1.e6 / rate);
                put (row, "block", block); put (row, "requested_notes", notes);
                put (row, "min_active_voices", minVoices); put (row, "max_active_voices", maxVoices);
                put (row, "effect_mixes_zero", bypass); put (row, "finite", finite); emit ("audio", row);
                if (!finite) return 1;
            }
    return 0;
}

inline void pump (int ms) { juce::MessageManager::getInstance()->runDispatchLoopUntil (ms); }
inline int initialLoadCheck (const juce::String& path)
{
    if (juce::SystemStats::getEnvironmentVariable ("LIBERO_HOME", {}).isEmpty()) return 2;
    const auto previous = libero::library::readConfig()["last_sound"];
    if (!libero::library::writeConfigValue ("last_sound", path)) return 1;
    auto automatic = std::make_unique<libero::LiberoProcessor>();
    auto requested = std::make_unique<libero::LiberoProcessor>();
    bool replied = false, failed = false;
    requested->loadSound (juce::File (path).getChildFile ("missing-sound"), true,
        [&] (bool ok, juce::String) { replied = true; failed = !ok; });
    pump (1500);
    const bool defaultLoaded = automatic->getCurrentSoundPath() == juce::File (path).getFullPathName();
    const bool choicePreserved = replied && failed && requested->getCurrentSoundPath().isEmpty();
    libero::library::writeConfigValue ("last_sound", previous);
    std::cout << "initial-load: default=" << defaultLoaded << " explicit-choice-preserved=" << choicePreserved << std::endl;
    return defaultLoaded && choicePreserved ? 0 : 1;
}
inline juce::String evaluate (juce::WebBrowserComponent& browser, const juce::String& js)
{
    struct Result { bool done = false; juce::String text; };
    auto result = std::make_shared<Result>();
    browser.evaluateJavascript (js, [result] (juce::WebBrowserComponent::EvaluationResult r)
    {
        if (auto* v = r.getResult()) result->text = v->toString();
        result->done = true;
    });
    for (int i = 0; i < 200 && !result->done; ++i) pump (10);
    return result->text;
}
class LiveAudio : public juce::Thread
{
public:
    explicit LiveAudio (std::vector<std::unique_ptr<libero::LiberoProcessor>>& p)
        : Thread ("Libero performance audio"), processors (p) { samples.reserve (4096); }
    void run() override
    {
        juce::AudioBuffer<float> buffer (2, 256);
        juce::MidiBuffer midi;
        const auto start = now(); int blocks = 0;
        while (!threadShouldExit())
        {
            const auto t = now();
            for (auto& proc : processors)
            {
                buffer.clear(); midi.clear();
                if (blocks == 0)
                    for (int n = 0; n < 32; ++n) midi.addEvent (juce::MidiMessage::noteOn (1, 48 + n, (juce::uint8) 90), 0);
                proc->processBlock (buffer, midi);
                for (int c = 0; c < 2; ++c)
                    for (int n = 0; n < 256; ++n) finite = finite && std::isfinite (buffer.getSample (c, n));
            }
            if (samples.size() < 4096) samples.push_back ((now() - t) * 1000);
            ++blocks;
            const auto remaining = start + blocks * 256.0 * 1000 / 48000 - now();
            if (remaining >= 1) wait ((int) remaining);
        }
    }
    std::vector<double> samples;
    bool finite = true;
private:
    std::vector<std::unique_ptr<libero::LiberoProcessor>>& processors;
};
inline int ui (const juce::String& path, int instances)
{
    emit ("baseline", memory());
    std::vector<std::unique_ptr<libero::LiberoProcessor>> processors;
    std::vector<std::unique_ptr<juce::AudioProcessorEditor>> editors;
    for (int i = 0; i < instances; ++i)
    {
        auto proc = std::make_unique<libero::LiberoProcessor>();
        proc->setPlayConfigDetails (0, 2, 48000, 256); proc->prepareToPlay (48000, 256);
        const double start = now();
        bool done = false, ok = false;
        juce::String loadError;
        proc->loadSound (juce::File (path), true, [&] (bool loaded, juce::String message) { ok = loaded; loadError = message; done = true; });
        for (int tick = 0; tick < 3000 && !done; ++tick) pump (10);
        if (!done || !ok) { std::cerr << "load failed: " << path << ": " << loadError << std::endl; return 1; }
        // Install the pending sound without a capture buffer or a hardware audio device.
        juce::AudioBuffer<float> buffer (2, 256); juce::MidiBuffer midi; buffer.clear(); proc->processBlock (buffer, midi);
        auto row = memory(); put (row, "instances", i + 1); put (row, "load_ms", now() - start);
        put (row, "reported_latency_samples", proc->getLatencySamples()); emit ("processor_loaded", row);
        processors.push_back (std::move (proc));
    }
    for (int i = 0; i < instances; ++i)
    {
        const auto start = now();
        std::unique_ptr<juce::AudioProcessorEditor> editor (processors[(size_t) i]->createEditorAndMakeActive());
        const auto construction = now() - start;
        editor->addToDesktop (juce::ComponentPeer::windowHasTitleBar);
        editor->setTopLeftPosition (80 + i * 40, 80 + i * 40); editor->setVisible (true);
        editor->toFront (true);
        auto& browser = static_cast<libero::LiberoEditor*> (editor.get())->getBrowser();
        bool ready = false;
        for (int tick = 0; tick < 600 && !ready; ++tick)
        {
            pump (20);
            ready = evaluate (browser, "String(!!document.getElementById('lib-count')?.textContent)") == "true";
        }
        if (!ready) { std::cerr << "editor readiness timed out" << std::endl; return 1; }
        evaluate (browser, "document.querySelector('#lib-crumb button')?.click(); 'root'");
        auto row = memory(); put (row, "editors", i + 1); put (row, "construction_ms", construction);
        put (row, "ready_ms", now() - start); emit ("editor_ready", row);
        editors.push_back (std::move (editor));
    }
    auto& browser = static_cast<libero::LiberoEditor*> (editors.back().get())->getBrowser();
    evaluate (browser, R"JS((() => {
      window.__bench = { done: false };
      const paint=()=>new Promise(resolve=>{let raf=0;
        const timeout=setTimeout(()=>{cancelAnimationFrame(raf);resolve(false);},500);
        raf=requestAnimationFrame(()=>{raf=requestAnimationFrame(()=>{clearTimeout(timeout);resolve(true);});});});
      const frames = ms => new Promise(resolve => {
        const values = []; let last = performance.now(), start = last;
        let raf=0, complete=false;
        const finish = stalled => { if(complete)return;complete=true;cancelAnimationFrame(raf);clearTimeout(timeout);
          values.sort((a,b)=>a-b);resolve({frames:values.length, fps:values.length*1000/(performance.now()-start),
            p95_frame_ms:values.length?values[Math.floor(.95*(values.length-1))]:null,
            max_frame_ms:values.length?values.at(-1):null, stalled, visibility:document.visibilityState}); };
        const timeout=setTimeout(()=>finish(true),ms+1500);
        const tick = t => { values.push(t-last); last=t;
          if (t-start < ms) raf=requestAnimationFrame(tick);
          else finish(false); };
        raf=requestAnimationFrame(tick);
      });
      (async () => {
        const j = await import('/juce/index.js'); const f = n => j.getNativeFunction(n);
        let t=performance.now(); const sounds=await f('listSounds')();
        window.__bench.list_ms=performance.now()-t; window.__bench.sounds=sounds.length;
        window.__bench.list_bytes=JSON.stringify(sounds).length;
        window.__bench.closed=await frames(1500);
        const toggle=document.getElementById('lib-toggle');
        if (toggle.getAttribute('aria-expanded') !== 'true') toggle.click();
        t=performance.now(); window.__bench.library_painted=await paint();
        window.__bench.library_paint_ms=performance.now()-t;
        window.__bench.open=await frames(1500);
        window.__bench.dom_nodes=document.getElementsByTagName('*').length;
        window.__bench.tile_nodes=document.querySelectorAll('#grid .tile').length;
        window.__bench.stack_nodes=document.querySelectorAll('.content-stack svg').length;
        window.__bench.svg_nodes=document.querySelectorAll('svg').length;
        window.__bench.hover_initial=document.querySelectorAll('.content-card').length;
        const hover=[...document.querySelectorAll('#grid .folder')].find(t=>Number(t.querySelector('.no')?.textContent)>0)?.querySelector('.thumb');
        if (hover) { hover.dispatchEvent(new Event('pointerenter'));
          await new Promise(r=>setTimeout(r,100));
          window.__bench.hover_cards=hover.querySelectorAll('.content-card svg').length; }
        const folder=hover;
        if (folder) { t=performance.now(); folder.click();
          window.__bench.folder_painted=await paint();
          window.__bench.folder_paint_ms=performance.now()-t; }
        window.__bench.done=true;
      })().catch(e=>{window.__bench.error=String(e);window.__bench.done=true;}); return 'started'; })())JS");
    juce::var response;
    for (int tick = 0; tick < 200; ++tick)
    {
        pump (50); response = juce::JSON::parse (evaluate (browser, "JSON.stringify(window.__bench || {})"));
        if ((bool) response["done"]) break;
    }
    emit ("ui", response.isObject() ? response : object());
    if (!(bool) response["done"] || response.hasProperty ("error")) return 1;
    const auto before = memory(); const auto start = now(); pump (2000);
    auto visible = memory(); put (visible, "elapsed_ms", now() - start);
    put (visible, "cpu_delta_seconds", (double) visible["cpu_seconds"] - (double) before["cpu_seconds"]);
    emit ("visible_idle", visible);
    for (auto& editor : editors) editor->setVisible (false);
    pump (200); const auto hiddenStart = memory(); const auto hiddenTime = now(); pump (2000);
    auto hidden = memory(); put (hidden, "elapsed_ms", now() - hiddenTime);
    put (hidden, "javascript_visibility", evaluate (browser, "JSON.stringify({document:document.visibilityState, native: window.__liberoEditorVisible})"));
    put (hidden, "cpu_delta_seconds", (double) hidden["cpu_seconds"] - (double) hiddenStart["cpu_seconds"]);
    emit ("hidden_idle", hidden);
    for (auto& editor : editors) editor->setVisible (true);
    pump (200);
    for (auto& proc : processors)
    {
        for (const auto& setting : { std::pair<const char*, float> { "mode", 0 }, { "voices", 32 } })
            if (auto* param = proc->getState().getParameter (setting.first))
                param->setValueNotifyingHost (param->convertTo0to1 (setting.second));
    }
    LiveAudio audio (processors); audio.startThread (juce::Thread::Priority::high);
    pump (1800); audio.stopThread (2000);
    auto playing = timings (std::move (audio.samples), 256 * 1.e6 / 48000);
    put (playing, "instances", instances); put (playing, "notes_per_instance", 32); put (playing, "finite", audio.finite);
    emit ("audio_with_editors", playing);
    if (!audio.finite) return 1;
    editors.clear(); pump (500); emit ("editors_destroyed", memory());
    processors.clear(); pump (500); emit ("processors_destroyed", memory());
    return 0;
}
}
