#!/usr/bin/env python3
"""Rough pitch (MIDI) of the left channel in given windows: autocorrelation peak, parabolic refine."""
import math, sys
sys.path.insert(0, __import__('os').path.dirname(__file__))
from wavstats import read

def midi_at(ch, rate, t0, t1, lo=100.0, hi=2000.0):
    x = ch[0][int(t0 * rate):int(t1 * rate)]
    n = len(x)
    best, lag = -1e30, 0
    lags = range(int(rate / hi), int(rate / lo))
    r = {}
    for L in lags:
        s = sum(x[i] * x[i + L] for i in range(0, n - L, 2)) / (n - L)
        r[L] = s
    # first strong peak: largest correlation, preferring the shortest lag within 10 % of it
    top = max(r.values())
    for L in lags:
        if L - 1 in r and L + 1 in r and r[L] >= r[L - 1] and r[L] >= r[L + 1] and r[L] > 0.9 * top:
            lag = L
            break
    a, b, c = r[lag - 1], r[lag], r[lag + 1]
    d = (a - c) / (2 * (a - 2 * b + c)) if (a - 2 * b + c) != 0 else 0
    f = rate / (lag + d)
    return 69 + 12 * math.log2(f / 440)

if __name__ == '__main__':
    rate, _, ch = read(sys.argv[1])
    for w in sys.argv[2:]:
        t0, t1 = map(float, w.split('-'))
        print(w, round(midi_at(ch, rate, t0, t1), 2))


def midi_zc(ch, rate, t0, t1):
    """Precise pitch (MIDI, fractional) from interpolated upward zero crossings of the left channel.
    For clean, fundamental-dominated tones only."""
    x = ch[0][int(t0 * rate):int(t1 * rate)]
    ups = [i + x[i] / (x[i] - x[i + 1]) for i in range(len(x) - 1) if x[i] < 0 <= x[i + 1]]
    if len(ups) < 3:
        return float('nan')
    f = (len(ups) - 1) * rate / (ups[-1] - ups[0])
    return 69 + 12 * math.log2(f / 440)
