#!/usr/bin/env python3
"""libero-render tests (SPEC §7): determinism, safety at extreme settings, every room and resonator.

    test_render.py <libero-render> <fixtures dir>
"""

import filecmp
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from wavstats import read, stats  # noqa: E402
from pitchtrack import midi_at, midi_zc  # noqa: E402
import hashlib  # noqa: E402
import platform  # noqa: E402

# sha256 of reference renders (arm64 build), re-recorded when the default filter became an
# open lowpass: with mode=Poli and single-take bundles the engine must stay byte-identical.
GOLDEN = {
    'a': ('60:0:1.2:100,64:0.5:1.0:90,67:1:1:80,60:1.5:0.5:60', None,
          '5e49dfca1da1abf31b605fdc80ef3d9a98eec51c80477f288ddd01739b7b0ea7'),
    'b': ('48:0:2:127,52:0.1:2:100,55:0.2:1:90,72:0.3:1:80',
          {'glide': 120, 'voices': 2, 'res_mix': 0.5, 'flt_mode': 'Vocale', 'tape_mix': 0.5, 'echo_mix': 0.3, 'echo_time': 375},
          '4dee617479a72d40aeae256af5e4319ec60f131be10c40c7716ec65ba295c014'),
}
TAKE_GAIN_DB = [0.0, 20 * math.log10(0.7), 20 * math.log10(0.5)]

failures = []
OUT = Path(__file__).parent / 'out'


def check(cond, what):
    print(('ok   ' if cond else 'FAIL ') + what)
    if not cond:
        failures.append(what)


def render(exe, sound, out, notes=None, params=None, extra=()):
    cmd = [exe, '--sound', str(sound), '--out', str(out)]
    if notes:
        cmd += ['--notes', notes]
    if params is not None:
        cmd += ['--params', json.dumps(params)]
    cmd += list(extra)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        return None, r.stderr.strip()
    return json.loads(r.stdout.strip().splitlines()[-1]), r.stderr.strip()


def window_rms_db(path, seconds):
    rate, _, ch = read(path)
    w = int(rate * seconds)
    out = []
    for i in range(0, len(ch[0]) - w + 1, w):
        e = sum(v * v for c in ch for v in c[i:i + w]) / (w * len(ch))
        out.append(10 * math.log10(max(e, 1e-24)))
    return out


def click_ratio(path, times):
    """Peak |2nd difference| near each time vs the steady state before and after it."""
    rate, _, ch = read(path)

    def d2(a, b):
        return max(abs(c[i] - 2 * c[i - 1] + c[i - 2]) for c in ch for i in range(max(2, a), min(len(c), b)))

    worst = 0.0
    for t in times:
        s = int(t * rate)
        at = d2(s - int(0.01 * rate), s + int(0.05 * rate))
        ref = max(d2(s - int(0.25 * rate), s - int(0.05 * rate)), d2(s + int(0.15 * rate), s + int(0.35 * rate)), 1e-9)
        worst = max(worst, at / ref)
    return worst


EXTREME = {
    'echo_feedback': 0.95, 'echo_mix': 0.6, 'echo_time': 10,
    'rev_shimmer': 1, 'rev_mix': 0.7, 'rev_decay': 30, 'rev_size': 1, 'rev_damp': 0,
    'flt_mode': 'Banda', 'flt_reso': 1, 'flt_cutoff': 300, 'flt_env': 1, 'drive': 1,
    'res_mix': 1, 'res_decay': 1, 'res_bright': 1,
    'tape_mix': 1, 'tape_wow': 1, 'tape_flutter': 1, 'tape_sat': 1, 'tape_age': 1,
    'lvl_attack': 6, 'lvl_body': 6, 'lvl_tail': 6, 'lvl_air': 6, 'master': 6, 'width': 2,
}
CHORD = '36:0:1.5:127,48:0:1.5:127,60:0.2:1.5:127,72:0.4:1:127,84:0.6:1:127,96:0.8:0.6:127'


def main():
    exe, fixtures = sys.argv[1], Path(sys.argv[2])
    tone, noir = fixtures / 'test-tone', fixtures / 'test-noir'
    OUT.mkdir(exist_ok=True)

    # Basic render + summary line.
    s, err = render(exe, tone, OUT / 'basic.wav', '60:0:1.2:100,64:0.5:1.0:90')
    check(s is not None and set(s) == {'out', 'seconds', 'peak_db', 'rms_db'}, f'summary line {s} {err}')
    st = stats(OUT / 'basic.wav')
    check(st['channels'] == 2 and st['rate'] == 48000 and abs(st['seconds'] - 4.5) < 0.01, f'float WAV 48k stereo 4.5 s {st}')
    check(st['non_finite'] == 0 and 1e-3 < st['peak'] < 1.0, f'basic render finite, audible, below 0 dBFS (peak {st["peak"]:.3f})')

    # Every room x every resonator at extreme settings: deterministic, finite, bounded, audible.
    for rev in ['Cappella', 'Basilica', 'Cisterna', 'Piastra', 'Impronta']:
        for res in ['Corde', 'Vetro', 'Legno', 'Metallo']:
            p = dict(EXTREME, rev_mode=rev, res_mode=res)
            a, b = OUT / 'ext_a.wav', OUT / 'ext_b.wav'
            s1, _ = render(exe, tone, a, CHORD, p, ['--tail', '5'])
            s2, _ = render(exe, tone, b, CHORD, p, ['--tail', '5'])
            st = stats(a)
            w = window_rms_db(a, 0.5)
            same = s1 is not None and s2 is not None and filecmp.cmp(a, b, shallow=False)
            check(same and st['non_finite'] == 0 and st['peak'] <= 1.0 and st['rms'] > 1e-3
                  and max(w[-4:]) <= max(w) + 0.01,
                  f'{rev:9s} {res:8s} deterministic, finite, peak {20 * math.log10(st["peak"]):6.2f} dBFS, '
                  f'rms {20 * math.log10(st["rms"]):6.1f} dB, not growing at the end')

    # Extreme but unboosted (no +6 dB gains): the chain itself must stay bounded and decay.
    for rev in ['Basilica', 'Piastra', 'Cisterna']:
        for res in ['Corde', 'Metallo']:
            p = dict(EXTREME, rev_mode=rev, res_mode=res, lvl_attack=0, lvl_body=0, lvl_tail=0, lvl_air=-60,
                     master=0, width=1, rev_decay=8)
            render(exe, tone, OUT / 'ext_c.wav', '48:0:1:100,60:0:1:100', p, ['--tail', '12'])
            w = window_rms_db(OUT / 'ext_c.wav', 1.0)
            st = stats(OUT / 'ext_c.wav')
            check(st['non_finite'] == 0 and w[-1] < max(w) - 12,
                  f'{rev:9s} {res:8s} unboosted extreme decays: peak window {max(w):6.1f} dB, last {w[-1]:6.1f} dB')

    # Defaults of the SPEC and the manifest params are what the renderer uses.
    s_manifest, _ = render(exe, tone, OUT / 'm1.wav', '60:0:1:100')
    s_explicit, _ = render(exe, tone, OUT / 'm2.wav', '60:0:1:100', {'amp_release': 600, 'rev_mode': 'Basilica', 'rev_mix': 0.25})
    check(filecmp.cmp(OUT / 'm1.wav', OUT / 'm2.wav', shallow=False), 'manifest params applied before --params')

    pf = OUT / 'params.json'
    pf.write_text(json.dumps({'rev_mode': 'Piastra', 'flt_mode': 1, 'tune': 7}))
    s1, _ = render(exe, tone, OUT / 'pf1.wav', '60:0:1:100', None, ['--params-file', str(pf)])
    s2, _ = render(exe, tone, OUT / 'pf2.wav', '60:0:1:100', {'rev_mode': 3, 'flt_mode': 'Banda', 'tune': 7})
    check(s1 is not None and filecmp.cmp(OUT / 'pf1.wav', OUT / 'pf2.wav', shallow=False),
          '--params-file and choice strings/indices are equivalent')

    s, err = render(exe, tone, OUT / 'bad.wav', '60:0:1:100', {'no_such_param': 1})
    check(s is not None and 'no_such_param' in err, 'unknown params are ignored with a warning')

    # Impronta without an IR falls back to Basilica.
    render(exe, noir, OUT / 'fb1.wav', '60:0:1:100', {'rev_mode': 'Impronta', 'rev_mix': 0.6})
    render(exe, noir, OUT / 'fb2.wav', '60:0:1:100', {'rev_mode': 'Basilica', 'rev_mix': 0.6})
    check(filecmp.cmp(OUT / 'fb1.wav', OUT / 'fb2.wav', shallow=False), 'Impronta without ir.wav == Basilica')

    # Impronta with the IR differs from Basilica and is audible.
    render(exe, tone, OUT / 'ir1.wav', '60:0:1:100', {'rev_mode': 'Impronta', 'rev_mix': 1})
    render(exe, tone, OUT / 'ir2.wav', '60:0:1:100', {'rev_mode': 'Basilica', 'rev_mix': 1})
    st = stats(OUT / 'ir1.wav')
    check(not filecmp.cmp(OUT / 'ir1.wav', OUT / 'ir2.wav', shallow=False) and st['rms'] > 1e-3,
          f'Impronta convolves with ir.wav (rms {20 * math.log10(st["rms"]):.1f} dB)')

    # Sample rates and block sizes.
    for sr in [44100, 96000]:
        s, _ = render(exe, tone, OUT / f'sr{sr}.wav', '60:0:1:100', None, ['--sr', str(sr)])
        st = stats(OUT / f'sr{sr}.wav')
        check(s is not None and st['rate'] == sr and st['non_finite'] == 0 and st['rms'] > 1e-3, f'--sr {sr}')

    levels = []
    for blk in [32, 256, 2048]:
        s, _ = render(exe, tone, OUT / f'blk{blk}.wav', '60:0:1:100,67:0.3:1:100', None, ['--block', str(blk)])
        levels.append(s['rms_db'])
    check(max(levels) - min(levels) < 0.2, f'block size barely matters (rms {levels})')

    # Pitch: a zone rendered at another key is resampled (octave up = twice the zero crossings).
    def zero_crossings(path):
        rate, _, ch = read(path)
        x = ch[0][int(0.3 * rate):int(2.8 * rate)]
        return sum(1 for a, b in zip(x, x[1:]) if a < 0 <= b)
    flat = {'rev_mix': 0, 'lvl_air': -60, 'lvl_attack': -60}
    render(exe, tone, OUT / 'p60.wav', '60:0:3:100', flat)
    render(exe, tone, OUT / 'p61.wav', '61:0:3:100', flat)
    render(exe, tone, OUT / 'p60t.wav', '60:0:3:100', dict(flat, tune=12))
    z60, z61, z72 = zero_crossings(OUT / 'p60.wav'), zero_crossings(OUT / 'p61.wav'), zero_crossings(OUT / 'p60t.wav')
    check(abs(z61 / z60 - 2 ** (1 / 12)) < 0.004 and abs(z72 / z60 - 2) < 0.01,
          f'pitch tracking: 61/60 = {z61 / z60:.4f}, tune +12 = {z72 / z60:.3f}')

    # Switching rooms, filters and resonators mid-note does not click.
    auto = [
        {'t': 1.0, 'params': {'rev_mode': 'Piastra'}},
        {'t': 1.5, 'params': {'flt_mode': 'Vocale'}},
        {'t': 2.0, 'params': {'rev_mode': 'Cisterna', 'flt_mode': 'Banda'}},
        {'t': 2.5, 'params': {'res_mode': 'Vetro', 'res_mix': 0.6}},
        {'t': 3.0, 'params': {'res_mode': 'Metallo', 'flt_mode': 'Basso'}},
        {'t': 3.5, 'params': {'rev_mode': 'Impronta', 'res_mode': 'Corde'}},
        {'t': 4.0, 'params': {'rev_mode': 'Cappella', 'master': -6}},
        {'t': 4.5, 'params': {'tape_mix': 0.8, 'tape_wow': 0.6, 'echo_mix': 0.4}},
        {'t': 5.0, 'params': {'rev_mode': 'Basilica', 'tape_mix': 0, 'drive': 0.5}},
        {'t': 5.5, 'params': {'rev_mode': 'Piastra', 'flt_mode': 'Alto', 'flt_cutoff': 200}},
    ]
    render(exe, tone, OUT / 'switch.wav', '48:0:6:100,60:0:6:100,64:0:6:100',
           {'lvl_air': -60, 'rev_mix': 0.3, 'flt_cutoff': 700, 'flt_mode': 'Basso'},
           ['--tail', '0.5', '--automation', json.dumps(auto)])
    worst = click_ratio(OUT / 'switch.wav', [a['t'] for a in auto])
    check(worst < 2.0, f'mode switches are click-free (worst transient ratio {worst:.2f})')

    # ---- Poli with single-take bundles is unchanged, byte for byte.
    if platform.machine() == 'arm64':
        for name, (notes, params, digest) in GOLDEN.items():
            render(exe, tone, OUT / f'golden_{name}.wav', notes, params)
            got = hashlib.sha256((OUT / f'golden_{name}.wav').read_bytes()).hexdigest()
            check(got == digest, f'Poli render {name} byte-identical to the reference render')
    else:
        print('skip golden hashes (recorded on arm64)')

    # ---- Round-robin takes.
    takes = fixtures / 'test-takes'
    starts = [i * 0.5 for i in range(16)]
    notes = ','.join(f'60:{t}:0.3:100' for t in starts)
    dry = {'rev_mix': 0, 'lvl_air': -60, 'lvl_tail': -60, 'amp_release': 30}

    def take_sequence(path, t0, t1):
        rate, _, ch = read(path)
        levels = []
        for t in starts:
            a, b = int((t + t0) * rate), int((t + t1) * rate)
            e = sum(v * v for c in ch for v in c[a:b]) / (2 * (b - a))
            levels.append(10 * math.log10(max(e, 1e-20)))
        top = max(levels)
        return [min(range(3), key=lambda k: abs((lv - top) - TAKE_GAIN_DB[k])) for lv in levels]

    render(exe, takes, OUT / 'takes_body.wav', notes, dict(dry, lvl_attack=-60))
    render(exe, takes, OUT / 'takes_body2.wav', notes, dict(dry, lvl_attack=-60))
    render(exe, takes, OUT / 'takes_att.wav', notes, dict(dry, lvl_body=-60))
    body_seq = take_sequence(OUT / 'takes_body.wav', 0.1, 0.25)
    att_seq = take_sequence(OUT / 'takes_att.wav', 0.0, 0.03)
    check(filecmp.cmp(OUT / 'takes_body.wav', OUT / 'takes_body2.wav', shallow=False),
          'take choice is deterministic across renders')
    check(all(a != b for a, b in zip(body_seq, body_seq[1:])) and set(body_seq) == {0, 1, 2},
          f'takes rotate without immediate repeats: {body_seq}')
    check(att_seq == body_seq, f'attack takes follow the body take when counts match: {att_seq}')

    # ---- Mono / Legato. 60 held, 67 overlaps it (another body zone), 64 pressed and released
    # inside 67 (note memory returns to 67).
    seq = '60:0:1.0:100,67:0.8:1.2:100,64:1.5:0.3:100'
    runs = {}
    for mode in ['Poli', 'Mono', 'Legato']:
        render(exe, tone, OUT / f'mode_{mode}.wav', seq, dict(dry, mode=mode), ['--tail', '0.5'])
        rate, _, ch = read(OUT / f'mode_{mode}.wav')

        def rms_db(t0, t1):
            a, b = int(t0 * rate), int(t1 * rate)
            return 10 * math.log10(max(sum(v * v for c in ch for v in c[a:b]) / (2 * (b - a)), 1e-20))

        def hf_db(t0, t1):  # first difference energy: the noise attack layer dominates it
            a, b = int(t0 * rate), int(t1 * rate)
            return 10 * math.log10(max(sum((c[i] - c[i - 1]) ** 2 for c in ch for i in range(a + 1, b)) / (2 * (b - a)), 1e-20))

        runs[mode] = {
            'attack_at_2nd': hf_db(0.8, 0.86) - hf_db(0.7, 0.76),
            'dip': min(rms_db(t, t + 0.01) for t in [0.78 + k * 0.01 for k in range(15)]) - rms_db(0.6, 0.78),
            'pitches': [round(midi_at(ch, rate, a, b)) for a, b in [(0.3, 0.4), (1.1, 1.2), (1.65, 1.75), (1.9, 1.98)]],
        }
    check(runs['Poli']['attack_at_2nd'] > 20 and runs['Mono']['attack_at_2nd'] > 20,
          f'Poli/Mono retrigger the attack at the second note (+{runs["Poli"]["attack_at_2nd"]:.0f} / '
          f'+{runs["Mono"]["attack_at_2nd"]:.0f} dB of transient)')
    check(runs['Legato']['attack_at_2nd'] < 6,
          f'Legato does not retrigger the attack (+{runs["Legato"]["attack_at_2nd"]:.1f} dB)')
    check(runs['Legato']['dip'] > -3, f'Legato transition has no dip > 3 dB ({runs["Legato"]["dip"]:+.1f} dB)')
    check(runs['Legato']['pitches'] == [60, 67, 64, 67] and runs['Mono']['pitches'] == [60, 67, 64, 67],
          f'last-note priority with note memory: legato {runs["Legato"]["pitches"]}, mono {runs["Mono"]["pitches"]}')
    check(runs['Poli']['pitches'][0] == 60, 'Poli unchanged')

    # Legato with glide 0 still slurs (no click) and settles quickly.
    render(exe, tone, OUT / 'slur.wav', '60:0:1.0:100,67:0.8:1.2:100', dict(dry, mode='Legato', glide=0), ['--tail', '0.3'])
    rate, _, ch = read(OUT / 'slur.wav')
    check(abs(midi_at(ch, rate, 0.9, 1.0) - 67) < 0.1, 'legato slur reaches the new pitch within 100 ms')
    worst = click_ratio(OUT / 'slur.wav', [0.8])
    check(worst < 2.0, f'legato transition is click-free (transient ratio {worst:.2f})')

    # ---- libero.bundle/2 ------------------------------------------------------------------
    dynb, human, rrb = fixtures / 'test-dyn', fixtures / 'test-human', fixtures / 'test-rr'
    quiet = {'rev_mix': 0, 'lvl_air': -60, 'lvl_attack': -60}

    def goertzel(x, f, rate):
        k = 2 * math.cos(2 * math.pi * f / rate)
        s1 = s2 = 0.0
        for v in x:
            s1, s2 = v + k * s1 - s2, s1
        return math.sqrt(max(0.0, s1 * s1 + s2 * s2 - k * s1 * s2)) / len(x)

    def harmonics(path, t0, t1, f0=261.626):
        rate, _, ch = read(path)
        x = ch[0][int(t0 * rate):int(t1 * rate)]
        return [goertzel(x, f0 * h, rate) for h in (1, 2, 3)]

    # Dynamics on CC1: a slow sweep over a held note crosses three layers (harmonic 1, 2, 3
    # alone, equal RMS, uncorrelated). Equal power keeps the level flat; no step > 1 dB.
    sweep = ','.join(f'{0.5 + i * 0.01:.2f}:1:{round(i * 127 / 500)}' for i in range(501))
    render(exe, dynb, OUT / 'dyn_sweep.wav', '60:0:6:100', dict(quiet, dyn_mode='Modulazione'),
           ['--tail', '0.1', '--cc', '0:1:0,' + sweep])
    rate, _, ch = read(OUT / 'dyn_sweep.wav')
    w = int(0.02 * rate)
    lv = [10 * math.log10(sum(v * v for v in ch[0][i:i + w]) / w) for i in range(int(0.3 * rate), int(5.7 * rate), w)]
    steps = max(abs(a - b) for a, b in zip(lv, lv[1:]))
    h_lo, h_hi = harmonics(OUT / 'dyn_sweep.wav', 0.3, 0.45), harmonics(OUT / 'dyn_sweep.wav', 5.6, 5.75)
    h_mid = harmonics(OUT / 'dyn_sweep.wav', 2.95, 3.1)
    check(steps < 1.0 and max(lv) - min(lv) < 1.0,
          f'CC1 dynamics crossfade is continuous and equal-power (largest step {steps:.2f} dB, '
          f'range {max(lv) - min(lv):.2f} dB)')
    check(h_lo[0] > 10 * h_lo[2] and h_hi[2] > 10 * h_hi[0] and h_mid[1] > 3 * max(h_mid[0], h_mid[2]),
          'the sweep moves from the soft layer through the middle one to the loud one')

    # Velocity picks the position on the axis; the knob (Manopola) drives it directly.
    render(exe, dynb, OUT / 'dyn_v20.wav', '60:0:0.6:20', quiet)
    render(exe, dynb, OUT / 'dyn_v127.wav', '60:0:0.6:127', quiet)
    render(exe, dynb, OUT / 'dyn_knob.wav', '60:0:0.6:20', dict(quiet, dyn_mode='Manopola', dynamics=0.5))
    a, b, k = (harmonics(OUT / f, 0.3, 0.5) for f in ('dyn_v20.wav', 'dyn_v127.wav', 'dyn_knob.wav'))
    check(a[0] > 10 * a[2] and b[2] > 10 * b[0] and k[1] > 10 * max(k[0], k[2]),
          'velocity 20 plays the soft layer, 127 the loud one; the Manopola knob at 0.5 the middle one')

    # dynamics.crossfade = 0: a note plays exactly one layer, chosen at note-on. Velocity 40 and
    # 46 straddle the middle of the soft/mid gap (legacy: both layers blend there).
    hard, hardcc = fixtures / 'test-dyn-hard', fixtures / 'test-dyn-hard-cc'
    render(exe, dynb, OUT / 'dyn_legacy_v40.wav', '60:0:0.6:40', quiet)
    render(exe, hard, OUT / 'dyn_hard_v40.wav', '60:0:0.6:40', quiet)
    render(exe, hard, OUT / 'dyn_hard_v46.wav', '60:0:0.6:46', quiet)
    lg, h40, h46 = (harmonics(OUT / f, 0.3, 0.5) for f in ('dyn_legacy_v40.wav', 'dyn_hard_v40.wav', 'dyn_hard_v46.wav'))
    check(lg[0] > 0.3 * lg[1] and lg[1] > 0.3 * lg[0],
          'absent dynamics.crossfade keeps the old behaviour: two layers blend between centres')
    check(h40[0] > 50 * h40[1] and h40[0] > 50 * h40[2] and h46[1] > 50 * h46[0] and h46[1] > 50 * h46[2],
          'crossfade 0 plays exactly one layer per note (velocity 40: layer 1, velocity 46: layer 2)')
    render(exe, hardcc, OUT / 'dyn_hardcc.wav', '60:0.3:5:100', dict(quiet, dyn_mode='Modulazione'),
           ['--tail', '0.1', '--cc', '0:1:20,' + sweep])
    c0, c1 = harmonics(OUT / 'dyn_hardcc.wav', 0.4, 0.6), harmonics(OUT / 'dyn_hardcc.wav', 5.0, 5.2)
    check(c0[0] > 50 * c0[1] and c1[0] > 50 * c1[1] and c1[0] > 50 * c1[2],
          'crossfade 0 with CC dynamics picks the layer at note-on: the CC sweep does not switch it mid-note')

    # Release by duration: tails lose rt_decay (12) dB per second held, floored at rt_min_db (-40).
    tail_only = {'lvl_body': -60, 'lvl_attack': -60, 'lvl_air': -60, 'rev_mix': 0}
    render(exe, dynb, OUT / 'rt.wav', '60:0:0.2:100,60:1:1.5:100,60:3.5:4:100', tail_only, ['--tail', '0.5'])
    rate, _, ch = read(OUT / 'rt.wav')

    def tail_db(off):
        a, b = int(off * rate), int((off + 0.2) * rate)
        return 10 * math.log10(sum(v * v for c in ch for v in c[a:b]) / (2 * (b - a)))

    t1, t2, t3 = tail_db(0.2), tail_db(2.5), tail_db(7.5)
    check(abs((t1 - t2) - 12 * 1.3) < 0.5 and abs((t1 - t3) - (40 - 12 * 0.2)) < 0.5,
          f'rt_decay attenuates tails by held time ({t1 - t2:.1f} dB for +1.3 s, floor {t1 - t3:.1f} dB)')

    # Humanize: seeded, bounded by the manifest (5 cents, 4 ms, 1 dB), 0 = off. tune_cents +30.
    notes12 = ','.join(f'60:{i * 0.5}:0.4:100' for i in range(12))
    hp = {'rev_mix': 0, 'lvl_air': -60, 'lvl_tail': -60, 'amp_release': 20}
    render(exe, human, OUT / 'hum_a.wav', notes12, hp)
    render(exe, human, OUT / 'hum_b.wav', notes12, hp)
    render(exe, human, OUT / 'hum_0.wav', notes12, dict(hp, humanize=0))

    def per_note(path):
        rate, _, ch = read(path)
        ons, lvl, cents = [], [], []
        for i in range(12):
            s0 = int(i * 0.5 * rate)
            k = next(j for j in range(s0, s0 + int(0.05 * rate)) if abs(ch[0][j]) > 1e-3)
            ons.append((k - s0) / rate * 1000)
            a, b = int((i * 0.5 + 0.15) * rate), int((i * 0.5 + 0.3) * rate)
            lvl.append(10 * math.log10(sum(v * v for v in ch[0][a:b]) / (b - a)))
            cents.append((midi_zc(ch, rate, i * 0.5 + 0.1, i * 0.5 + 0.35) - 60) * 100)
        return ons, lvl, cents

    o1, l1, c1 = per_note(OUT / 'hum_a.wav')
    o0, l0, c0 = per_note(OUT / 'hum_0.wav')
    chunk_ms = 32 / 48.0
    check(filecmp.cmp(OUT / 'hum_a.wav', OUT / 'hum_b.wav', shallow=False), 'humanize is deterministic')
    check(max(o0) == 0 and max(abs(c - 30) for c in c0) < 0.3 and max(l0) - min(l0) < 0.01,
          f'humanize 0 is exact; tune_cents +30 applied ({c0[0]:.2f} cents)')
    check(min(o1) >= 0 and max(o1) <= 4 + chunk_ms and len(set(o1)) > 3,
          f'onset jitter within 0..4 ms (+ one {chunk_ms:.2f} ms control block): {[round(x, 1) for x in o1]}')
    check(max(abs(c - 30) for c in c1) <= 5.3 and max(c1) - min(c1) > 2,
          f'tuning jitter within ±5 cents: {[round(c - 30, 1) for c in c1]}')
    check(max(abs(a - b) for a, b in zip(l1, l0)) <= 1.05 and max(l1) - min(l1) > 0.3,
          f'level jitter within ±1 dB: {[round(a - b, 2) for a, b in zip(l1, l0)]}')

    # rr_reset_ms (300): after enough silence the take cycle restarts at take 0.
    rr_notes = '60:0:0.1:100,60:0.15:0.1:100,60:0.3:0.1:100,60:1.5:0.1:100,60:1.65:0.1:100,60:3:0.1:100'
    render(exe, rrb, OUT / 'rr.wav', rr_notes, {'rev_mix': 0, 'lvl_air': -60, 'lvl_tail': -60, 'lvl_attack': -60,
                                                'amp_release': 10})
    rate, _, ch = read(OUT / 'rr.wav')
    lv = []
    for item in rr_notes.split(','):
        t = float(item.split(':')[1])
        a, b = int((t + 0.03) * rate), int((t + 0.09) * rate)
        lv.append(10 * math.log10(sum(v * v for c in ch for v in c[a:b]) / (2 * (b - a))))
    top = max(lv)
    seq = [min(range(3), key=lambda k: abs((x - top) - TAKE_GAIN_DB[k])) for x in lv]
    check(seq[0] == 0 and seq[3] == 0 and seq[5] == 0 and all(a != b for a, b in zip(seq[:3], seq[1:3])),
          f'rr_reset restarts the cycle at take 0 after silence: {seq}')

    # ---- Drums: one-shot and choke groups.
    drums = fixtures / 'test-drums'
    dflat = {'rev_mix': 0, 'lvl_air': -60, 'amp_release': 100}

    def seg_db(path, t0, t1):
        rate, _, ch = read(path)
        x = ch[0][int(t0 * rate):int(t1 * rate)]
        return 10 * math.log10(max(sum(v * v for v in x) / max(1, len(x)), 1e-24))

    render(exe, drums, OUT / 'os_on.wav', '36:0:0.2:100', dflat, ['--tail', '2'])
    render(exe, drums, OUT / 'os_off.wav', '40:0:0.2:100', dflat, ['--tail', '2'])
    on, off = seg_db(OUT / 'os_on.wav', 1.0, 1.2), seg_db(OUT / 'os_off.wav', 1.0, 1.2)
    check(on > -30 and off < -70, f'one_shot keeps ringing after note-off ({on:.1f} dB) and the plain zone stops ({off:.1f} dB)')

    render(exe, drums, OUT / 'choke_none.wav', '46:0:2:100', dflat, ['--tail', '1'])
    render(exe, drums, OUT / 'choke_on.wav', '46:0:2:100,44:1.0:0.1:100', dflat, ['--tail', '1'])
    render(exe, drums, OUT / 'choke_grp.wav', '46:0:2:100,42:1.0:0.1:100', dflat, ['--tail', '1'])
    ref = seg_db(OUT / 'choke_none.wav', 1.03, 1.05)
    before = seg_db(OUT / 'choke_on.wav', 0.9, 1.0)
    after = seg_db(OUT / 'choke_on.wav', 1.03, 1.05)
    check(ref > -30 and before > -30 and after < -70,
          f'chokes: [1] fades the open hat within 30 ms (before {before:.1f}, after {after:.1f}, unchoked {ref:.1f} dB)')
    grp_after = seg_db(OUT / 'choke_grp.wav', 1.12, 1.2)
    check(grp_after < -70, f'a note of the same choke group fades the open hat ({grp_after:.1f} dB after the closed hat ends)')
    worst = click_ratio(OUT / 'choke_on.wav', [1.0])
    check(worst < 2.0, f'choke fade is click-free (worst transient ratio {worst:.2f})')

    # ---- Portamento only between overlapping notes (never across a rest), in every mode.
    glide_q = {'glide': 150, 'lvl_attack': -60, 'lvl_tail': -60, 'lvl_air': -60, 'rev_mix': 0, 'amp_release': 1}
    for mode in ['Poli', 'Mono', 'Legato']:
        render(exe, tone, OUT / 'g_rest.wav', '81:0:0.5:100,53:1.0:0.5:100', dict(glide_q, mode=mode))
        render(exe, tone, OUT / 'g_over.wav', '81:0:1.02:100,53:1.0:0.5:100', dict(glide_q, mode=mode))
        rate, _, ch = read(OUT / 'g_rest.wav')
        after_rest = midi_zc(ch, rate, 1.03, 1.08)
        rate, _, ch = read(OUT / 'g_over.wav')
        overlapped = midi_zc(ch, rate, 1.03, 1.08)
        check(abs(after_rest - 53) < 0.3 and overlapped > 56,
              f'{mode}: a note after a rest starts on pitch ({after_rest:.2f}); an overlapping one glides ({overlapped:.2f})')

    # ---- Attack layers with `dyn` crossfade (per note) instead of switching: a velocity sweep
    # over three attack layers at -12/-6/0 dB has no level step.
    dyn_att = fixtures / 'test-dyn-attack'
    vels = list(range(1, 128, 2))
    att_notes = ','.join(f'60:{i * 0.25}:0.1:{v}' for i, v in enumerate(vels))
    render(exe, dyn_att, OUT / 'att_sweep.wav', att_notes,
           {'lvl_body': -60, 'lvl_tail': -60, 'lvl_air': -60, 'rev_mix': 0, 'vel_sens': 0, 'amp_release': 1})
    rate, _, ch = read(OUT / 'att_sweep.wav')
    lv = []
    for i in range(len(vels)):
        a, b = int(i * 0.25 * rate), int((i * 0.25 + 0.04) * rate)
        lv.append(10 * math.log10(sum(v * v for c in ch for v in c[a:b]) / (2 * (b - a))))
    step = max(abs(x - y) for x, y in zip(lv, lv[1:]))
    check(step < 1.0 and max(lv) - min(lv) > 8,
          f'attack dynamics layers crossfade with velocity (largest step {step:.2f} dB over a {max(lv) - min(lv):.1f} dB range)')

    # ---- Articulations (bundle/2): keyswitches, the `artic` parameter, default = first.
    art = fixtures / 'test-artic'
    aflat = {'rev_mix': 0, 'lvl_air': -60, 'amp_release': 100}

    def partials(path, t0, t1):
        """Amplitudes at 1x..4x of C4 in [t0, t1): the active articulation sounds one of them."""
        from spectrum import goertzel
        rate, _, ch = read(path)
        f0 = 440.0 * 2 ** ((60 - 69) / 12)
        n = int((t1 - t0) * rate)
        x = ch[0][int(t0 * rate):int(t0 * rate) + n]
        cyc = int(rate / f0 * 40)   # a whole-ish number of cycles keeps the bins clean
        x = x[:cyc]
        return [abs(goertzel(x, f0 * k, rate)) for k in (1, 2, 3, 4)]

    def which(path, t0, t1):
        a = partials(path, t0, t1)
        top = max(range(4), key=lambda i: a[i])
        return top if a[top] > 0.05 and sorted(a)[-2] < 0.2 * a[top] else -1

    render(exe, art, OUT / 'art_def.wav', '60:0:1:100', aflat)
    check(which(OUT / 'art_def.wav', 0.2, 0.9) == 0, 'articulations: the first one (sus) is the default')
    # Real compiled banks can list pizzicato zones before sustain zones. The
    # default comes from articulations, independently of the order of zones.
    shuffled_art = OUT / 'test-artic-shuffled'
    shutil.copytree(art, shuffled_art, dirs_exist_ok=True)
    shuffled_manifest = shuffled_art / 'build' / 'manifest.json'
    shuffled = json.loads(shuffled_manifest.read_text())
    shuffled['zones'].reverse()
    shuffled_manifest.write_text(json.dumps(shuffled))
    render(exe, shuffled_art, OUT / 'art_shuffled.wav', '60:0:1:100', aflat)
    check(which(OUT / 'art_shuffled.wav', 0.2, 0.9) == 0,
          'default sustain is selected even when another articulation zone comes first')
    render(exe, art, OUT / 'art_ks.wav', '25:0:0.05:100,60:0.2:0.8:100', aflat)
    check(which(OUT / 'art_ks.wav', 0.4, 0.9) == 1, 'keyswitch 25 selects staccato (zones filtered by articulation)')
    render(exe, art, OUT / 'art_ks2.wav', '26:0:0.05:100,60:0.2:0.5:100,24:0.8:0.05:100,60:1.0:0.5:100', aflat)
    check(which(OUT / 'art_ks2.wav', 0.3, 0.7) == 2 and which(OUT / 'art_ks2.wav', 1.1, 1.5) == 0,
          'keyswitches 26 then 24 switch pizz then back to sus')
    render(exe, art, OUT / 'art_silent.wav', '24:0:0.3:100,25:0.4:0.3:127,26:0.8:0.3:100', aflat, ['--tail', '0.5'])
    peak = stats(OUT / 'art_silent.wav')['peak']
    check(peak < 1e-6, f'keyswitch keys make no sound (peak {peak:.2e})')
    render(exe, art, OUT / 'art_param.wav', '60:0:1:100', dict(aflat, artic=2))
    check(which(OUT / 'art_param.wav', 0.2, 0.9) == 2, 'the artic parameter selects an articulation (pizz)')
    render(exe, art, OUT / 'art_param3.wav', '60:0:1:100', dict(aflat, artic=3))
    check(which(OUT / 'art_param3.wav', 0.2, 0.9) == 3, 'an articulation without a keyswitch key is reachable from the parameter (trem)')
    render(exe, art, OUT / 'art_over.wav', '24:0:0.05:100,60:0.2:0.6:100', dict(aflat, artic=2))
    check(which(OUT / 'art_over.wav', 0.3, 0.7) == 0, 'a keyswitch overrides the parameter value')
    render(exe, art, OUT / 'art_clamp.wav', '60:0:1:100', dict(aflat, artic=9))
    check(which(OUT / 'art_clamp.wav', 0.2, 0.9) == 3, 'an artic value past the list clamps to the last articulation')
    render(exe, art, OUT / 'art_new.wav', '60:0:1.5:100,25:0.7:0.05:100,60:0.9:0.5:100', aflat)
    check(which(OUT / 'art_new.wav', 0.3, 0.6) == 0, 'a switch leaves the sounding note alone (new notes only)')
    render(exe, tone, OUT / 'art_none.wav', '24:0:0.3:100', {'rev_mix': 0})
    check(stats(OUT / 'art_none.wav')['peak'] > 1e-3, 'a sound without articulations plays key 24 normally')

    # ---- Echo synced to the host tempo (SPEC §5).
    onset_params = {'echo_mix': 1.0, 'echo_feedback': 0.0, 'echo_spread': 0.0, 'rev_mix': 0, 'lvl_air': -60,
                    'lvl_tail': -60, 'amp_release': 30}

    def first_above(path, frac):
        rate, _, ch = read(path)
        peak = max(abs(v) for c in ch for v in c) or 1.0
        for i in range(len(ch[0])):
            if any(abs(c[i]) > frac * peak for c in ch):
                return i / rate * 1000.0
        return None

    render(exe, tone, OUT / 'echo_dry.wav', '60:0.3:0.05:100', dict(onset_params, echo_mix=0), ['--tail', '3'])
    dry_on = first_above(OUT / 'echo_dry.wav', 0.2)
    cases = [(120, '1/8', 0.5), (90, '1/8', 0.5), (60, '1/4.', 1.5), (140, '1/16T', 1 / 6), (200, '1/4', 1.0),
             (75, '1/2', 2.0), (100, '1/32', 0.125), (120, '1/8.', 0.75), (150, '1/4T', 2 / 3)]
    bad = []
    for bpm, div, beats in cases:
        want = beats * 60000.0 / bpm
        render(exe, tone, OUT / 'echo_t.wav', '60:0.3:0.05:100', dict(onset_params, echo_div=div), ['--tail', '3', '--bpm', str(bpm)])
        got = first_above(OUT / 'echo_t.wav', 0.2)
        if got is None or dry_on is None or abs(got - dry_on - want) > 2.0:
            bad.append((bpm, div, want, None if got is None else got - dry_on))
    check(not bad, f'synced echo delay equals the division at {len(cases)} tempo/division pairs {bad}')
    render(exe, tone, OUT / 'echo_t0.wav', '60:0.3:0.05:100', dict(onset_params), ['--tail', '3'])
    check(abs(first_above(OUT / 'echo_t0.wav', 0.2) - dry_on - 250.0) < 2.0, 'no --bpm: 120 BPM, default division 1/8 = 250 ms')
    render(exe, tone, OUT / 'echo_lib.wav', '60:0.3:0.05:100', dict(onset_params, echo_sync='Libero', echo_time=300),
           ['--tail', '2', '--bpm', '60'])
    check(abs(first_above(OUT / 'echo_lib.wav', 0.2) - dry_on - 300.0) < 2.0, 'Libero mode ignores the tempo (echo_time 300 ms)')

    held = {'echo_mix': 0.5, 'echo_feedback': 0.6, 'echo_spread': 0.3, 'rev_mix': 0, 'lvl_air': -60, 'echo_div': '1/8'}
    render(exe, tone, OUT / 'echo_tempo.wav', '60:0:4:100,64:0:4:90', held,
           ['--tail', '1', '--bpm', '120', '--automation', json.dumps([{'t': 2.0, 'bpm': 170}])])
    worst = click_ratio(OUT / 'echo_tempo.wav', [2.0])
    check(worst < 2.0, f'a tempo change mid-render is click-free (worst transient ratio {worst:.2f})')
    render(exe, tone, OUT / 'echo_div.wav', '60:0:4:100,64:0:4:90', held,
           ['--tail', '1', '--automation', json.dumps([{'t': 2.0, 'params': {'echo_div': '1/4.'}}])])
    worst = click_ratio(OUT / 'echo_div.wav', [2.0])
    check(worst < 2.0, f'a division change mid-render is click-free (worst transient ratio {worst:.2f})')

    # Old bundles: a manifest that sets echo_time (and no echo_sync) keeps the free echo.
    old = OUT / 'test-tone-old'
    shutil.rmtree(old, ignore_errors=True)
    shutil.copytree(tone, old)
    mp = (old / 'build' / 'manifest.json') if (old / 'build' / 'manifest.json').exists() else old / 'manifest.json'
    man = json.loads(mp.read_text())
    man['params'] = dict(man.get('params') or {}, echo_time=375, echo_mix=0.3)
    mp.write_text(json.dumps(man))
    render(exe, old, OUT / 'echo_old.wav', '60:0:1.2:100,64:0.5:1:90', {'lvl_air': -60})
    render(exe, tone, OUT / 'echo_old_ref.wav', '60:0:1.2:100,64:0.5:1:90', {'lvl_air': -60, 'echo_mix': 0.3, 'echo_time': 375})
    check(filecmp.cmp(OUT / 'echo_old.wav', OUT / 'echo_old_ref.wav', shallow=False),
          'a manifest with echo_time and no echo_sync renders as the free echo (migration)')
    render(exe, tone, OUT / 'echo_new_ref.wav', '60:0:1.2:100,64:0.5:1:90', {'lvl_air': -60, 'echo_mix': 0.3})
    check(not filecmp.cmp(OUT / 'echo_old.wav', OUT / 'echo_new_ref.wav', shallow=False),
          'a sound that sets neither gets the synced echo (Tempo)')

    # Errors.
    r = subprocess.run([exe, '--sound', str(OUT / 'nope'), '--out', str(OUT / 'x.wav')], capture_output=True, text=True)
    check(r.returncode != 0 and 'manifest' in r.stderr, 'missing bundle is an error')

    print(f'\n{len(failures)} failure(s)')
    sys.exit(1 if failures else 0)


if __name__ == '__main__':
    main()
