// libero-render: offline renderer, same engine as the plugin (SPEC §7).

#include "Engine.h"
#include "ParamsJson.h"
#include "Arguments.h"

#include <juce_audio_formats/juce_audio_formats.h>

#include <cstdio>
#include <iostream>

namespace
{
    struct NoteSpec
    {
        int pitch = 60;
        double start = 0.0, duration = 1.0;
        int velocity = 100;
    };

    struct Event
    {
        juce::int64 sample;
        bool on;
        int pitch, velocity;
        int cc = -1;          // >= 0: a controller change (number), value in `velocity`
    };

    void usage()
    {
        std::cerr <<
            "usage: libero-render [--sound <folder or build dir>] --out out.wav   (no --sound: oscillators only)\n"
            "                     [--notes \"60:0:1.2:100,64:0.5:1.0:90\"]   pitch:start_s:dur_s:velocity\n"
            "                     [--params '{\"rev_mix\":0.3}'] [--params-file p.json]\n"
            "                     [--tail 3.0] [--sr 48000] [--block 256] [--bpm 120]   host tempo for the synced echo\n"
            "                     [--cc \"0:1:0,2.5:1:127\"]   time_s:controller:value (e.g. CC1 dynamics)\n"
            "                     [--automation '[{\"t\": 1.0, \"params\": {\"rev_mode\": \"Piastra\"}, \"bpm\": 140}]']\n";
    }

    int fail (const juce::String& message, int code = 1)
    {
        std::cerr << "libero-render: " << message << std::endl;
        return code;
    }

    bool parseNotes (const juce::String& text, std::vector<NoteSpec>& notes, juce::String& error)
    {
        for (auto item : juce::StringArray::fromTokens (text, ",", ""))
        {
            item = item.trim();

            if (item.isEmpty())
                continue;

            const auto f = juce::StringArray::fromTokens (item, ":", "");

            if (f.size() < 1 || f.size() > 4)
            {
                error = "bad note spec '" + item + "'";
                return false;
            }

            NoteSpec n;
            n.pitch = f[0].trim().getIntValue();
            if (f.size() > 1) n.start = f[1].trim().getDoubleValue();
            if (f.size() > 2) n.duration = f[2].trim().getDoubleValue();
            if (f.size() > 3) n.velocity = f[3].trim().getIntValue();

            if (n.pitch < 0 || n.pitch > 127 || n.start < 0.0 || n.duration <= 0.0)
            {
                error = "note out of range '" + item + "'";
                return false;
            }

            n.velocity = juce::jlimit (1, 127, n.velocity);
            notes.push_back (n);
        }

        return true;
    }

    double toDb (double x) { return x > 1.0e-6 ? 20.0 * std::log10 (x) : -120.0; }

    juce::String jsonNumber (double v)
    {
        return juce::String (v, 3);
    }
}

int main (int argc, char* argv[])
{
    const auto arguments = libero::commandLineArguments (argc, argv);
    argc = arguments.size();
    juce::String soundPath, outPath, notesText = "60:0:1.5:100", paramsText, paramsFile, automationText, ccText;
    double tail = 3.0, sampleRate = 48000.0, bpm = 120.0;
    int block = 256;

    for (int i = 1; i < argc; ++i)
    {
        const auto a = arguments[i];
        const auto next = [&]() -> juce::String { return i + 1 < argc ? arguments[++i] : juce::String(); };

        if      (a == "--sound")       soundPath = next();
        else if (a == "--out")         outPath = next();
        else if (a == "--notes")       notesText = next();
        else if (a == "--params")      paramsText = next();
        else if (a == "--params-file") paramsFile = next();
        else if (a == "--tail")        tail = next().getDoubleValue();
        else if (a == "--sr")          sampleRate = next().getDoubleValue();
        else if (a == "--block")       block = next().getIntValue();
        else if (a == "--bpm")         bpm = next().getDoubleValue();
        else if (a == "--automation")  automationText = next();
        else if (a == "--cc")          ccText = next();
        else if (a == "-h" || a == "--help") { usage(); return 0; }
        else
        {
            usage();
            return fail ("unknown argument " + a, 2);
        }
    }

    if (outPath.isEmpty())
    {
        usage();
        return fail ("--out is required", 2);
    }

    if (sampleRate < 8000.0 || sampleRate > 384000.0)
        return fail ("--sr out of range", 2);

    block = juce::jlimit (1, 8192, block);
    tail = juce::jlimit (0.0, 120.0, tail);

    const auto cwd = juce::File::getCurrentWorkingDirectory();
    const auto soundFile = cwd.getChildFile (soundPath);
    const auto outFile = cwd.getChildFile (outPath);

    std::vector<NoteSpec> notes;
    juce::String error;

    if (! parseNotes (notesText, notes, error))
        return fail (error, 2);

    // No --sound (or "none"): the oscillators alone, as the plugin plays with nothing loaded.
    std::unique_ptr<libero::SoundData> sound;

    if (soundPath.isNotEmpty() && soundPath != "none")
    {
        sound = libero::SoundData::load (soundFile, sampleRate, error);

        if (sound == nullptr)
            return fail (error);
    }

    // Parameters: SPEC defaults <- manifest params <- --params-file <- --params.
    libero::ParamSet params;
    juce::StringArray rejected;

    if (sound != nullptr)
        libero::applyJsonParams (params, sound->params, &rejected);

    if (paramsFile.isNotEmpty())
    {
        const auto f = cwd.getChildFile (paramsFile);
        const auto parsed = juce::JSON::parse (f);

        if (! parsed.isObject())
            return fail ("--params-file is not a JSON object: " + f.getFullPathName(), 2);

        libero::applyJsonParams (params, parsed, &rejected);
    }

    if (paramsText.isNotEmpty())
    {
        juce::var parsed;
        const auto result = juce::JSON::parse (paramsText, parsed);

        if (result.failed() || ! parsed.isObject())
            return fail ("--params is not a JSON object", 2);

        libero::applyJsonParams (params, parsed, &rejected);
    }

    for (const auto& r : rejected)
        std::cerr << "libero-render: warning: ignored parameter '" << r << "'" << std::endl;

    // Optional parameter changes during the render, applied at the first block boundary at or
    // after each time. Used to check that switches (rooms, filters, sounds' params) don't click.
    struct Automation { juce::int64 sample; juce::var values; double bpm; };
    std::vector<Automation> automation;

    if (automationText.isNotEmpty())
    {
        juce::var parsed;

        if (juce::JSON::parse (automationText, parsed).failed() || ! parsed.isArray())
            return fail ("--automation must be a JSON array of {t, params}", 2);

        for (const auto& item : *parsed.getArray())
            automation.push_back ({ (juce::int64) std::llround ((double) item["t"] * sampleRate), item["params"], item.hasProperty ("bpm") ? (double) item["bpm"] : 0.0 });

        std::stable_sort (automation.begin(), automation.end(), [] (const Automation& x, const Automation& y) { return x.sample < y.sample; });
    }

    libero::Engine engine;
    engine.setParameters (params);
    engine.setTempo (bpm);
    engine.prepare (sampleRate, block);
    if (sound != nullptr)
        engine.submitSound (std::move (sound));

    engine.finishLoadingOffline();
    engine.reset();

    std::vector<Event> events;
    double end = 0.0;

    for (const auto& n : notes)
    {
        const auto on = (juce::int64) std::llround (n.start * sampleRate);
        const auto off = std::max (on + 1, (juce::int64) std::llround ((n.start + n.duration) * sampleRate));
        events.push_back ({ on, true, n.pitch, n.velocity });
        events.push_back ({ off, false, n.pitch, 0 });
        end = std::max (end, n.start + n.duration);
    }

    for (auto item : juce::StringArray::fromTokens (ccText, ",", ""))
    {
        const auto f = juce::StringArray::fromTokens (item.trim(), ":", "");

        if (item.trim().isEmpty())
            continue;

        if (f.size() != 3 || f[0].getDoubleValue() < 0.0)
            return fail ("bad --cc item '" + item + "' (want time_s:controller:value)", 2);

        const auto t = f[0].getDoubleValue();
        events.push_back ({ (juce::int64) std::llround (t * sampleRate), false, 0,
                            juce::jlimit (0, 127, f[2].getIntValue()), juce::jlimit (0, 127, f[1].getIntValue()) });
        end = std::max (end, t);
    }

    // At the same instant: note-offs, then controllers, then note-ons (repeated notes retrigger
    // cleanly and a note starts with the controller value set at its time).
    const auto rank = [] (const Event& e) { return e.cc >= 0 ? 1 : (e.on ? 2 : 0); };
    std::stable_sort (events.begin(), events.end(), [rank] (const Event& a, const Event& b)
    {
        return a.sample != b.sample ? a.sample < b.sample : rank (a) < rank (b);
    });

    const auto total = (juce::int64) std::ceil ((end + tail) * sampleRate);
    juce::AudioBuffer<float> out (2, (int) std::max<juce::int64> (1, total));
    out.clear();

    juce::MidiBuffer midi;
    size_t next = 0, nextAutomation = 0;

    for (juce::int64 pos = 0; pos < total; pos += block)
    {
        const auto n = (int) std::min<juce::int64> (block, total - pos);
        midi.clear();

        if (nextAutomation < automation.size() && automation[nextAutomation].sample <= pos)
        {
            while (nextAutomation < automation.size() && automation[nextAutomation].sample <= pos)
            {
                libero::applyJsonParams (params, automation[nextAutomation].values, &rejected);

                if (automation[nextAutomation].bpm > 0.0)
                    engine.setTempo (bpm = automation[nextAutomation].bpm);

                ++nextAutomation;
            }

            engine.setParameters (params);
        }

        while (next < events.size() && events[next].sample < pos + n)
        {
            const auto& e = events[next++];
            const auto offset = (int) (e.sample - pos);
            if (e.cc >= 0)
                midi.addEvent (juce::MidiMessage::controllerEvent (1, e.cc, e.velocity), offset);
            else
                midi.addEvent (e.on ? juce::MidiMessage::noteOn (1, e.pitch, (juce::uint8) e.velocity)
                                    : juce::MidiMessage::noteOff (1, e.pitch), offset);
        }

        engine.process (out.getWritePointer (0, (int) pos), out.getWritePointer (1, (int) pos), n, midi);
        engine.collectGarbage();
    }

    double peak = 0.0, sumSq = 0.0;

    for (int c = 0; c < 2; ++c)
    {
        const auto* d = out.getReadPointer (c);

        for (int i = 0; i < out.getNumSamples(); ++i)
        {
            peak = std::max (peak, (double) std::abs (d[i]));
            sumSq += (double) d[i] * d[i];
        }
    }

    const auto rms = std::sqrt (sumSq / (2.0 * out.getNumSamples()));

    outFile.getParentDirectory().createDirectory();
    outFile.deleteFile();

    std::unique_ptr<juce::OutputStream> stream = std::make_unique<juce::FileOutputStream> (outFile);

    if (static_cast<juce::FileOutputStream*> (stream.get())->failedToOpen())
        return fail ("cannot write " + outFile.getFullPathName());

    juce::WavAudioFormat wav;
    auto writer = wav.createWriterFor (stream, juce::AudioFormatWriterOptions{}
                                                   .withSampleRate (sampleRate)
                                                   .withNumChannels (2)
                                                   .withBitsPerSample (32)
                                                   .withSampleFormat (juce::AudioFormatWriterOptions::SampleFormat::floatingPoint));

    if (writer == nullptr || ! writer->writeFromAudioSampleBuffer (out, 0, out.getNumSamples()))
        return fail ("failed to write " + outFile.getFullPathName());

    writer.reset();

    auto json = juce::String ("{\"out\": ") + juce::JSON::toString (outFile.getFullPathName())
              + ", \"seconds\": " + jsonNumber ((double) total / sampleRate)
              + ", \"peak_db\": " + jsonNumber (toDb (peak))
              + ", \"rms_db\": " + jsonNumber (toDb (rms)) + "}";

    std::cout << json << std::endl;
    return 0;
}
