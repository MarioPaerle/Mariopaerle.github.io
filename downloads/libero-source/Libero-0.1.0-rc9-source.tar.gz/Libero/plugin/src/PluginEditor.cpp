#include "PluginEditor.h"
#include "Library.h"
#include "LiberoBinaryData.h"

namespace libero
{

namespace
{
    juce::ZipFile* uiZip()
    {
        static std::unique_ptr<juce::ZipFile> zip = []
        {
            int size = 0;
            const auto* data = LiberoBinary::getNamedResource ("libero_ui_zip", size);

            if (data == nullptr || size <= 0)
                return std::unique_ptr<juce::ZipFile>();

            return std::make_unique<juce::ZipFile> (std::make_unique<juce::MemoryInputStream> (data, (size_t) size, false));
        }();

        return zip.get();
    }

    const char* mimeFor (const juce::String& path)
    {
        const auto ext = path.fromLastOccurrenceOf (".", false, false).toLowerCase();

        static const std::map<juce::String, const char*> types {
            { "html", "text/html" }, { "htm", "text/html" }, { "css", "text/css" },
            { "js", "text/javascript" }, { "mjs", "text/javascript" }, { "json", "application/json" },
            { "map", "application/json" }, { "svg", "image/svg+xml" }, { "png", "image/png" },
            { "jpg", "image/jpeg" }, { "jpeg", "image/jpeg" }, { "gif", "image/gif" }, { "webp", "image/webp" },
            { "ico", "image/vnd.microsoft.icon" }, { "woff2", "font/woff2" }, { "woff", "font/woff" },
            { "ttf", "font/ttf" }, { "otf", "font/otf" }, { "txt", "text/plain" }, { "md", "text/plain" },
            { "wav", "audio/wav" }
        };

        const auto it = types.find (ext);
        return it != types.end() ? it->second : "application/octet-stream";
    }

    std::vector<std::byte> toBytes (juce::InputStream& in)
    {
        juce::MemoryBlock mb;
        in.readIntoMemoryBlock (mb);
        const auto* p = static_cast<const std::byte*> (mb.getData());
        return { p, p + mb.getSize() };
    }

    const char* const fallbackPage =
        "<!doctype html><meta charset=utf-8><title>Libero</title>"
        "<body style='background:#14120f;color:#d8cfc0;font:15px Georgia,serif;display:grid;place-items:center;height:100vh;margin:0'>"
        "<div style='text-align:center'><div style='font-size:32px;letter-spacing:.3em'>LIBERO</div>"
        "<p style='opacity:.6'>The interface was not built into this binary.</p></div></body>";

    juce::var obj (std::initializer_list<std::pair<const char*, juce::var>> props)
    {
        auto* o = new juce::DynamicObject();

        for (const auto& [k, v] : props)
            o->setProperty (k, v);

        return juce::var (o);
    }

    juce::String currentThemeName()
    {
        const auto t = library::readConfig()["theme"].toString();
        return t.isNotEmpty() ? t : juce::String ("harmonic");
    }

    juce::File decodedResourceFolder (const juce::String& path, const juce::String& prefix)
    {
        const auto native = path.fromFirstOccurrenceOf (prefix, false, false);
       #if ! JUCE_WINDOWS
        return juce::File ("/" + native);
       #else
        return juce::File::isAbsolutePath (native) ? juce::File (native) : juce::File();
       #endif
    }
}

std::optional<juce::WebBrowserComponent::Resource> LiberoEditor::getResource (const juce::String& url)
{
    auto path = url.upToFirstOccurrenceOf ("?", false, false).upToFirstOccurrenceOf ("#", false, false);
    path = juce::URL::removeEscapeChars (path).trimCharactersAtStart ("/");

    if (path.isEmpty())
        path = "index.html";

    // A bank's cover, by folder: /bankfig/<absolute bank folder>.
    if (path.startsWith ("bankfig/"))
    {
        const auto folder = decodedResourceFolder (path, "bankfig/");
        const auto f = folder.isAChildOf (library::banksDir()) ? library::bankFigureFile (folder) : juce::File();

        if (f == juce::File())
            return std::nullopt;

        juce::MemoryBlock mb;
        f.loadFileAsData (mb);
        const auto* p = static_cast<const std::byte*> (mb.getData());
        return juce::WebBrowserComponent::Resource { { p, p + mb.getSize() }, "image/svg+xml" };
    }

    // A sound's figure, by folder: /fig/<absolute folder path>. Only figure.svg inside the library.
    if (path.startsWith ("fig/"))
    {
        const auto folder = decodedResourceFolder (path, "fig/");
        auto f = folder.getChildFile ("build").getChildFile ("figure.svg");

        if (! f.existsAsFile())
            f = folder.getChildFile ("figure.svg");

        if (! f.isAChildOf (library::home()) || ! f.existsAsFile() || f.getSize() > 4 * 1024 * 1024)
            return std::nullopt;

        juce::MemoryBlock mb;
        f.loadFileAsData (mb);
        const auto* p = static_cast<const std::byte*> (mb.getData());
        return juce::WebBrowserComponent::Resource { { p, p + mb.getSize() }, "image/svg+xml" };
    }

    // A sound's preview, by folder: /preview/<absolute folder path>. build/preview.m4a or .wav only.
    if (path.startsWith ("preview/"))
    {
        const auto folder = decodedResourceFolder (path, "preview/");

        for (const auto* name : { "preview.m4a", "preview.wav" })
        {
            auto f = folder.getChildFile ("build").getChildFile (name);

            if (! f.existsAsFile())
                f = folder.getChildFile (name);

            if (! f.isAChildOf (library::home()) || ! f.existsAsFile() || f.getSize() > 4 * 1024 * 1024)
                continue;

            juce::MemoryBlock mb;
            f.loadFileAsData (mb);
            const auto* p = static_cast<const std::byte*> (mb.getData());
            return juce::WebBrowserComponent::Resource { { p, p + mb.getSize() }, f.hasFileExtension ("m4a") ? "audio/mp4" : "audio/wav" };
        }

        return std::nullopt;
    }

    // Developer escape hatch: ~/Libero/ui-override/ replaces the embedded interface, so UI work
    // doesn't need a host restart (reopen the editor to pick up changes).
    const auto overrideDir = library::home().getChildFile ("ui-override");

    if (path != "juce/index.js" && overrideDir.getChildFile ("index.html").existsAsFile())
    {
        const auto f = overrideDir.getChildFile (path);

        if (f.isAChildOf (overrideDir) && f.existsAsFile())
        {
            juce::MemoryBlock mb;
            f.loadFileAsData (mb);
            const auto* p = static_cast<const std::byte*> (mb.getData());
            return juce::WebBrowserComponent::Resource { { p, p + mb.getSize() }, mimeFor (path) };
        }

        return std::nullopt;
    }

    if (path == "juce/index.js")
    {
        int size = 0;

        if (const auto* data = LiberoBinary::getNamedResource ("index_js", size))
        {
            const auto* p = reinterpret_cast<const std::byte*> (data);
            return juce::WebBrowserComponent::Resource { { p, p + size }, "text/javascript" };
        }

        return std::nullopt;
    }

    if (auto* zip = uiZip())
    {
        if (const auto* entry = zip->getEntry (path))
        {
            std::unique_ptr<juce::InputStream> in (zip->createStreamForEntry (*entry));

            if (in != nullptr)
                return juce::WebBrowserComponent::Resource { toBytes (*in), mimeFor (path) };
        }
    }

    if (path == "index.html")
    {
        const juce::String html (fallbackPage);
        const auto* p = reinterpret_cast<const std::byte*> (html.toRawUTF8());
        return juce::WebBrowserComponent::Resource { { p, p + html.getNumBytesAsUTF8() }, "text/html" };
    }

    return std::nullopt;
}

juce::StringArray LiberoEditor::getBuiltinThemes()
{
    juce::StringArray names;

    if (auto* zip = uiZip())
    {
        for (int i = 0; i < zip->getNumEntries(); ++i)
        {
            const auto name = zip->getEntry (i)->filename;

            if (name.startsWith ("themes/") && name.endsWith (".css") && ! name.substring (7).containsChar ('/'))
                names.add (name.substring (7).dropLastCharacters (4));
        }
    }

    names.sort (true);
    return names;
}

juce::String LiberoEditor::readBuiltinText (const juce::String& path)
{
    if (auto* zip = uiZip())
        if (const auto* entry = zip->getEntry (path))
            if (std::unique_ptr<juce::InputStream> in (zip->createStreamForEntry (*entry)); in != nullptr)
                return in->readEntireStreamAsString();

    return {};
}

void LiberoEditor::addNativeFunctions (juce::WebBrowserComponent::Options& options)
{
    using Completion = juce::WebBrowserComponent::NativeFunctionCompletion;
    using Args = juce::Array<juce::var>;

    juce::Component::SafePointer<LiberoEditor> safe (this);
    auto* owner = &proc;

    const auto arg = [] (const Args& args, int i) { return i < args.size() ? args[i] : juce::var(); };

    // Runs `work` off the message thread, completes on the message thread.
    const auto async = [safe] (std::function<juce::var()> job, Completion complete)
    {
        juce::Thread::launch ([editor = safe, run = std::move (job), done = std::move (complete)]
        {
            auto result = run();
            juce::MessageManager::callAsync ([editor, done, result]
            {
                if (editor != nullptr)
                    done (result);
            });
        });
    };

    options = options
        .withNativeFunction ("listSounds", [async] (const Args&, Completion complete)
        {
            async ([] { return library::listSounds(); }, std::move (complete));
        })
        .withNativeFunction ("loadSound", [owner, safe, arg] (const Args& args, Completion complete)
        {
            const auto path = arg (args, 0).toString();

            if (path.isEmpty() || ! juce::File::isAbsolutePath (path))
            {
                complete (library::makeResult (false, "invalid path"));
                return;
            }

            owner->loadSound (juce::File (path), true, [safe, complete] (bool ok, juce::String msg)
            {
                if (safe != nullptr)
                    complete (library::makeResult (ok, ok ? juce::String() : msg));
            });
        })
        .withNativeFunction ("reloadSound", [owner, safe] (const Args&, Completion complete)
        {
            owner->reloadSound (false, [safe, complete] (bool ok, juce::String msg)
            {
                if (safe != nullptr)
                    complete (library::makeResult (ok, ok ? juce::String() : msg));
            });
        })
        .withNativeFunction ("resetSound", [owner] (const Args&, Completion complete)
        {
            const auto ok = owner->resetSound();
            complete (library::makeResult (ok, ok ? juce::String() : juce::String ("no sound loaded")));
        })
        .withNativeFunction ("saveSoundAs", [owner, safe, arg] (const Args& args, Completion complete)
        {
            owner->saveSoundAs (arg (args, 0).toString(), [safe, complete] (bool ok, juce::String msg)
            {
                if (safe == nullptr)
                    return;

                auto r = library::makeResult (ok, ok ? juce::String() : msg);

                if (ok)
                    r.getDynamicObject()->setProperty ("path", msg);

                complete (r);
            });
        })
        .withNativeFunction ("setFavorite", [owner, arg] (const Args& args, Completion complete)
        {
            complete (owner->setFavorite (juce::File (arg (args, 0).toString()), (bool) arg (args, 1)));
        })
        .withNativeFunction ("currentSound", [owner] (const Args&, Completion complete)
        {
            complete (owner->getCurrentSoundInfo());
        })
        .withNativeFunction ("resizeEditor", [safe, arg] (const Args& args, Completion complete)
        {
            const double width = (double) arg (args, 0), height = (double) arg (args, 1);
            if (safe == nullptr || ! std::isfinite (width) || ! std::isfinite (height))
            {
                complete (library::makeResult (false, "invalid window size"));
                return;
            }
            safe->setSize ((int) juce::jlimit (1000.0, 2600.0, width), (int) juce::jlimit (560.0, 1600.0, height));
            complete (library::makeResult (true));
        })
        .withNativeFunction ("sampleEditorInfo", [owner, async] (const Args&, Completion complete)
        {
            const auto folder = juce::File (owner->getCurrentSoundPath());
            async ([folder] { return LiberoProcessor::sampleEditorInfoForFolder (folder); }, std::move (complete));
        })
        .withNativeFunction ("sampleEditorWaveform", [owner, async, arg] (const Args& args, Completion complete)
        {
            const auto zone = arg (args, 0).toString();
            const auto folder = juce::File (owner->getCurrentSoundPath());
            async ([folder, zone] { return LiberoProcessor::sampleEditorWaveformForFolder (folder, zone); }, std::move (complete));
        })
        .withNativeFunction ("applySampleEditorEdit", [owner, safe, arg] (const Args& args, Completion complete)
        {
            owner->applySampleEditorEdit (arg (args, 0), [safe, complete] (bool ok, juce::String message)
            {
                if (safe != nullptr)
                    complete (library::makeResult (ok, ok ? juce::String() : message));
            });
        })
        .withNativeFunction ("saveSound", [owner, arg] (const Args& args, Completion complete)
        {
            const auto from = library::soundFolderFor (juce::File (arg (args, 0).toString()));
            auto result = library::saveSound (from);

            if ((bool) result["ok"])
                owner->soundMoved (from, juce::File (result["path"].toString()));

            complete (result);
        })
        .withNativeFunction ("listBanks", [async] (const Args&, Completion complete)
        {
            async ([] { return library::listBanks(); }, std::move (complete));
        })
        .withNativeFunction ("moveSound", [owner, arg] (const Args& args, Completion complete)
        {
            const auto from = library::soundFolderFor (juce::File (arg (args, 0).toString()));
            auto result = library::moveSound (from, arg (args, 1).toString());

            if ((bool) result["ok"])
                owner->soundMoved (from, juce::File (result["path"].toString()));

            complete (result);
        })
        .withNativeFunction ("setColorTag", [owner, arg] (const Args& args, Completion complete)
        {
            complete (owner->setColorTag (juce::File (arg (args, 0).toString()), (int) arg (args, 1)));
        })
        .withNativeFunction ("createBank", [arg] (const Args& args, Completion complete)
        {
            complete (library::createBank (arg (args, 0).toString(), arg (args, 1).toString()));
        })
        .withNativeFunction ("editBank", [arg] (const Args& args, Completion complete)
        {
            complete (library::editBank (arg (args, 0).toString(), arg (args, 1)));
        })
        .withNativeFunction ("exportBank", [async, arg] (const Args& args, Completion complete)
        {
            const auto slug = arg (args, 0).toString();
            const auto given = arg (args, 1).toString();

            if (given.isNotEmpty() && juce::File::isAbsolutePath (given))
            {
                async ([slug, given] { return library::exportBank (slug, juce::File (given)); }, std::move (complete));
                return;
            }

            auto chooser = std::make_shared<juce::FileChooser> ("Export bank", juce::File::getSpecialLocation (juce::File::userDesktopDirectory)
                                                                                      .getChildFile (slug + ".liberobank"), "*.liberobank");
            chooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
                                      | juce::FileBrowserComponent::warnAboutOverwriting,
                                  [chooser, slug, async, complete] (const juce::FileChooser& fc)
                                  {
                                      auto out = fc.getResult();

                                      if (out == juce::File())
                                      {
                                          auto r = library::makeResult (false);
                                          r.getDynamicObject()->setProperty ("cancelled", true);
                                          complete (r);
                                          return;
                                      }

                                      if (! out.hasFileExtension (".liberobank"))
                                          out = out.withFileExtension (".liberobank");

                                      async ([slug, out] { return library::exportBank (slug, out); }, complete);
                                  });
        })
        .withNativeFunction ("inspectBank", [async, arg] (const Args& args, Completion complete)
        {
            const auto given = arg (args, 0).toString();
            if (given.isNotEmpty() && juce::File::isAbsolutePath (given))
            {
                async ([given] { return library::inspectBank (juce::File (given)); }, std::move (complete));
                return;
            }
            auto chooser = std::make_shared<juce::FileChooser> ("Inspect bank", juce::File::getSpecialLocation (juce::File::userDesktopDirectory),
                                                                "*.liberobank");
            chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                                  [chooser, async, complete] (const juce::FileChooser& fc)
                                  {
                                      const auto f = fc.getResult();
                                      if (f == juce::File())
                                      {
                                          auto* o = new juce::DynamicObject();
                                          o->setProperty ("ok", false); o->setProperty ("cancelled", true);
                                          o->setProperty ("code", "CANCELLED"); o->setProperty ("bank", juce::var());
                                          o->setProperty ("installedVersion", ""); o->setProperty ("action", "");
                                          o->setProperty ("soundCount", 0); o->setProperty ("compressedBytes", 0);
                                          o->setProperty ("uncompressedBytes", 0); o->setProperty ("warnings", juce::Array<juce::var>());
                                          complete (juce::var (o)); return;
                                      }
                                      async ([f] { return library::inspectBank (f); }, complete);
                                  });
        })
        .withNativeFunction ("inspectBankCollection", [async, arg] (const Args& args, Completion complete)
        {
            const auto given = arg (args, 0);
            if (! given.isVoid())
            {
                juce::Array<juce::File> files;
                const auto append = [&files] (const juce::var& path)
                {
                    const auto text = path.toString();
                    if (juce::File::isAbsolutePath (text)) files.add (juce::File (text));
                };
                if (auto* paths = given.getArray())
                    for (const auto& path : *paths) append (path);
                else append (given);
                async ([files] { return library::inspectBankCollection (files); }, std::move (complete));
                return;
            }
            auto chooser = std::make_shared<juce::FileChooser> ("Import sound packs", juce::File::getSpecialLocation (juce::File::userDesktopDirectory),
                                                               "*.liberobank;*.zip");
            chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles
                                    | juce::FileBrowserComponent::canSelectMultipleItems,
                                  [chooser, async, complete] (const juce::FileChooser& fc)
                                  {
                                      const auto files = fc.getResults();
                                      if (files.isEmpty())
                                      {
                                          auto result = library::makeResult (false);
                                          result.getDynamicObject()->setProperty ("cancelled", true);
                                          complete (result);
                                          return;
                                      }
                                      async ([files] { return library::inspectBankCollection (files); }, complete);
                                  });
        })
        .withNativeFunction ("importBankCollectionEntry", [async, arg] (const Args& args, Completion complete)
        {
            const auto session = arg (args, 0).toString();
            const auto index = (int) arg (args, 1);
            async ([session, index] { return library::importBankCollectionEntry (session, index); }, std::move (complete));
        })
        .withNativeFunction ("cleanupBankCollection", [async, arg] (const Args& args, Completion complete)
        {
            const auto session = arg (args, 0).toString();
            async ([session] { return library::cleanupBankCollection (session); }, std::move (complete));
        })
        .withNativeFunction ("importBank", [async, arg] (const Args& args, Completion complete)
        {
            const auto given = arg (args, 0).toString();

            if (given.isNotEmpty() && juce::File::isAbsolutePath (given))
            {
                async ([given] { return library::importBank (juce::File (given)); }, std::move (complete));
                return;
            }

            auto chooser = std::make_shared<juce::FileChooser> ("Import bank", juce::File::getSpecialLocation (juce::File::userDesktopDirectory),
                                                                "*.liberobank");
            chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                                  [chooser, async, complete] (const juce::FileChooser& fc)
                                  {
                                      const auto f = fc.getResult();

                                      if (f == juce::File())
                                      {
                                          auto r = library::makeResult (false);
                                          r.getDynamicObject()->setProperty ("cancelled", true);
                                          complete (r);
                                          return;
                                      }

                                      async ([f] { return library::importBank (f); }, complete);
                                  });
        })
        .withNativeFunction ("discardSketch", [arg] (const Args& args, Completion complete)
        {
            complete (library::discardSketch (juce::File (arg (args, 0).toString())));
        })
        .withNativeFunction ("revealSound", [arg] (const Args& args, Completion complete)
        {
            const juce::File f (arg (args, 0).toString());

            if (f.exists())
                f.revealToUser();

            complete (library::makeResult (f.exists(), f.exists() ? juce::String() : juce::String ("no such folder")));
        })
        .withNativeFunction ("listThemes", [] (const Args&, Completion complete)
        {
            juce::StringArray user;

            for (const auto& f : library::themesDir().findChildFiles (juce::File::findFiles, false, "*.css"))
                user.add (f.getFileNameWithoutExtension());

            juce::Array<juce::var> list;

            for (const auto& name : getBuiltinThemes())
                if (! user.contains (name))
                    list.add (obj ({ { "name", name }, { "builtin", true } }));

            user.sort (true);

            for (const auto& name : user)
                list.add (obj ({ { "name", name }, { "builtin", false } }));

            complete (list);
        })
        .withNativeFunction ("getTheme", [arg] (const Args& args, Completion complete)
        {
            auto name = arg (args, 0).toString();

            if (name.isEmpty())
                name = currentThemeName();

            const auto user = library::themesDir().getChildFile (name + ".css");

            if (! name.containsAnyOf ("/\\") && user.existsAsFile())
            {
                complete (obj ({ { "name", name }, { "css", user.loadFileAsString() } }));
                return;
            }

            auto css = name.containsAnyOf ("/\\") ? juce::String() : readBuiltinText ("themes/" + name + ".css");

            if (css.isEmpty())
            {
                name = "harmonic";
                css = readBuiltinText ("themes/harmonic.css");
            }

            complete (obj ({ { "name", name }, { "css", css } }));
        })
        .withNativeFunction ("setTheme", [arg] (const Args& args, Completion complete)
        {
            const auto name = arg (args, 0).toString();

            if (name.isEmpty() || name.containsAnyOf ("/\\"))
            {
                complete (library::makeResult (false, "invalid theme name"));
                return;
            }

            const auto ok = library::writeConfigValue ("theme", name);
            complete (library::makeResult (ok, ok ? juce::String() : juce::String ("could not write config.json")));
        })
        .withNativeFunction ("agentStatus", [owner] (const Args&, Completion complete)
        {
            complete (owner->getAgentStatus());
        })
        .withNativeFunction ("audition", [owner, arg] (const Args& args, Completion complete)
        {
            const auto pitch = arg (args, 0);
            const auto velocity = arg (args, 1);
            owner->queueNote (pitch.isVoid() ? 60 : (int) pitch, velocity.isVoid() ? 100 : (int) velocity, 700);
            complete (library::makeResult (true));
        });
}

juce::WebBrowserComponent::Options LiberoEditor::buildOptions()
{
    auto options = juce::WebBrowserComponent::Options{}
                       .withNativeIntegrationEnabled()
                       .withKeepPageLoadedWhenBrowserIsHidden();

   #if JUCE_WINDOWS
    const auto cache = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                          .getChildFile ("Libero/WebView2");
    options = options.withBackend (juce::WebBrowserComponent::Options::Backend::webview2)
                     .withWinWebView2Options (juce::WebBrowserComponent::Options::WinWebView2{}
                         .withUserDataFolder (cache)
                         .withStatusBarDisabled());
   #endif

    for (auto& r : sliderRelays)
        options = options.withOptionsFrom (*r);

    for (auto& r : comboRelays)
        options = options.withOptionsFrom (*r);

    addNativeFunctions (options);

    const auto devUrl = juce::SystemStats::getEnvironmentVariable ("LIBERO_UI_DEV_URL", {});
    std::optional<juce::String> allowedOrigin;

    if (devUrl.isNotEmpty())
        allowedOrigin = juce::URL (devUrl).getOrigin();

    return options.withResourceProvider ([] (const juce::String& url) { return getResource (url); }, allowedOrigin);
}

LiberoEditor::LiberoEditor (LiberoProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    auto& state = proc.getState();

    for (int i = 0; i < kNumParams; ++i)
    {
        const auto& s = spec (i);

        if (s.scale == Scale::choice)
            comboRelays.push_back (std::make_unique<juce::WebComboBoxRelay> (s.id));
        else
            sliderRelays.push_back (std::make_unique<juce::WebSliderRelay> (s.id));
    }

    auto browserOptions = buildOptions();
    bool browserAvailable = true;
   #if JUCE_WINDOWS
    browserAvailable = juce::WebBrowserComponent::areOptionsSupported (browserOptions);
   #endif
    browser = std::make_unique<juce::WebBrowserComponent> (browserOptions);

    size_t slider = 0, combo = 0;

    for (int i = 0; i < kNumParams; ++i)
    {
        const auto& s = spec (i);
        auto* param = state.getParameter (s.id);

        if (s.scale == Scale::choice)
            comboAttachments.push_back (std::make_unique<juce::WebComboBoxParameterAttachment> (*param, *comboRelays[combo++], &proc.getUndoManager()));
        else
            sliderAttachments.push_back (std::make_unique<juce::WebSliderParameterAttachment> (*param, *sliderRelays[slider++], &proc.getUndoManager()));
    }

    if (browserAvailable)
    {
        addAndMakeVisible (*browser);
        const auto devUrl = juce::SystemStats::getEnvironmentVariable ("LIBERO_UI_DEV_URL", {});
        browser->goToURL (devUrl.isNotEmpty() ? devUrl : juce::WebBrowserComponent::getResourceProviderRoot());
    }
    else
    {
        runtimeNotice.setText ("Libero needs Microsoft WebView2 Runtime to display its interface.\n"
                               "Install the Evergreen Runtime, then close and reopen your DAW.",
                               juce::dontSendNotification);
        runtimeNotice.setColour (juce::Label::textColourId, juce::Colour (0xffeee9df));
        runtimeNotice.setJustificationType (juce::Justification::centred);
        addAndMakeVisible (runtimeNotice);
        addAndMakeVisible (runtimeDownload);
    }

    const auto savedSize = library::readConfig()["editor_size"];
    const auto ownSize = proc.preferredEditorSize();
    setResizable (true, true);
    setResizeLimits (1000, 560, 2600, 1600);
    setSize (juce::jlimit (1000, 2600, ownSize.x > 0 ? ownSize.x : (int) savedSize.getProperty ("width", 1360)),
             juce::jlimit (560, 1600, ownSize.y > 0 ? ownSize.y : (int) savedSize.getProperty ("height", 780)));

    proc.addLiberoListener (this);
    startTimerHz (30);
}

LiberoEditor::~LiberoEditor()
{
    stopTimer();
    if (resizeSaveCountdown > 0)
        library::writeConfigValue ("editor_size", obj ({ { "width", getWidth() }, { "height", getHeight() } }));
    proc.setVisualisationActive (false);
    proc.removeLiberoListener (this);
}

void LiberoEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff14120f));
}

void LiberoEditor::resized()
{
    if (getWidth() >= 1000 && getHeight() >= 560)
        proc.rememberEditorSize (getWidth(), getHeight());
    browser->setBounds (getLocalBounds());
    for (auto* child : getChildren())
        if (dynamic_cast<juce::ResizableCornerComponent*> (child) != nullptr)
            child->toFront (false);
    runtimeNotice.setBounds (getWidth() / 2 - 320, getHeight() / 2 - 70, 640, 80);
    runtimeDownload.setBounds (getWidth() / 2 - 190, getHeight() / 2 + 20, 380, 36);
    resizeSaveCountdown = 15;
}

void LiberoEditor::soundChanged()
{
    browser->emitEventIfBrowserIsVisible ("soundChanged", proc.getCurrentSoundInfo());
}

void LiberoEditor::soundLoading (const juce::var& info)
{
    browser->emitEventIfBrowserIsVisible ("soundLoading", info);
}

void LiberoEditor::soundLoadFailed (const juce::String& error)
{
    auto* o = new juce::DynamicObject();
    o->setProperty ("error", error);
    browser->emitEventIfBrowserIsVisible ("soundError", juce::var (o));
}

void LiberoEditor::soundReloaded (bool automatic)
{
    browser->emitEventIfBrowserIsVisible ("soundReloaded", obj ({ { "auto", automatic } }));
}

void LiberoEditor::soundModifiedChanged (bool modified)
{
    browser->emitEventIfBrowserIsVisible ("soundModified", obj ({ { "modified", modified } }));
}

void LiberoEditor::articulationChanged (int index, const juce::String& id)
{
    browser->emitEventIfBrowserIsVisible ("articulationChanged", obj ({ { "index", index }, { "id", id } }));
}

void LiberoEditor::agentStatusChanged()
{
    browser->emitEventIfBrowserIsVisible ("agentStatus", proc.getAgentStatus());
}

void LiberoEditor::timerCallback()
{
    if (resizeSaveCountdown > 0 && --resizeSaveCountdown == 0)
        library::writeConfigValue ("editor_size", obj ({ { "width", getWidth() }, { "height", getHeight() } }));
    const bool visible = browser->isShowing();
    proc.setVisualisationActive (visible);
    if (visible != visualisationVisible)
    {
        visualisationVisible = visible;
        browser->evaluateJavascript (juce::String ("window.dispatchEvent(new CustomEvent('libero-editor-visibility', {detail:")
                                     + (visible ? "true" : "false") + "}));");
    }
    if (! visible)
        return;
    proc.pollArticulation();

    Voice::Playback playback;
    if (proc.readSamplePlayback (playback)
        && (playback.soundId != lastPlayback.soundId || playback.zone != lastPlayback.zone
            || playback.note != lastPlayback.note || ! juce::exactlyEqual (playback.seconds, lastPlayback.seconds)
            || playback.looped != lastPlayback.looped))
    {
        lastPlayback = playback;
        browser->emitEventIfBrowserIsVisible ("samplePlayback", obj ({
            { "sound_id", playback.soundId }, { "zone", playback.zone }, { "note", playback.note },
            { "seconds", playback.seconds }, { "looped", playback.looped }
        }));
    }

    float level = 0.0f;

    if (! proc.readScope (scopeL, scopeR, level))
        return;

    const auto quiet = [] (float value) { return std::abs (value) < 0.00005f; };
    const bool silent = quiet (level) && std::all_of (scopeL.begin(), scopeL.end(), quiet)
                                     && std::all_of (scopeR.begin(), scopeR.end(), quiet);
    if (silent && scopeWasSilent)
        return;
    scopeWasSilent = silent;

    juce::Array<juce::var> l, r;
    l.ensureStorageAllocated (64);
    r.ensureStorageAllocated (64);

    for (size_t i = 0; i < 64; ++i)
    {
        l.add (std::round (scopeL[i] * 10000.0f) / 10000.0f);
        r.add (std::round (scopeR[i] * 10000.0f) / 10000.0f);
    }

    browser->emitEventIfBrowserIsVisible ("scope", obj ({ { "l", l }, { "r", r }, { "level", level } }));
}

} // namespace libero
