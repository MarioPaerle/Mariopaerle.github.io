#pragma once

#include <juce_core/juce_core.h>

#include <atomic>
#include <memory>

namespace libero
{

// Agent socket (SPEC §6): newline-delimited JSON over TCP on 127.0.0.1:47800..47899.
// One listener thread plus one thread per client. Requests are handed to the Delegate on the
// client's thread; the Delegate decides what must hop to the message thread.
class AgentServer : private juce::Thread
{
public:
    struct Reply
    {
        juce::var result;
        juce::String error;

        static Reply ok (juce::var r)             { return { std::move (r), {} }; }
        static Reply fail (juce::String message)  { return { {}, std::move (message) }; }
    };

    struct Delegate
    {
        virtual ~Delegate() = default;
        virtual Reply handleAgentRequest (const juce::String& method, const juce::var& params, juce::Thread& caller) = 0;
        virtual void agentClientsChanged() {}
    };

    static constexpr int firstPort = 47800, lastPort = 47899;

    explicit AgentServer (Delegate&);
    ~AgentServer() override;

    bool start (const juce::String& hostName);
    void stop();

    int getPort() const noexcept        { return port.load(); }
    int getNumClients() const noexcept  { return numClients.load(); }
    juce::String getInstanceId() const  { return instanceId; }

    void setSoundPath (const juce::String& path);

    // One request line in, one response line out (no trailing newline). Pure: used by tests too.
    static juce::String processLine (Delegate&, const juce::String& line, juce::Thread& caller);

    // Removes instance files whose process is gone.
    static void cleanStaleInstances();

private:
    class Client;

    void run() override;
    void writeInstanceFile();
    void reapClients (bool all);

    Delegate& delegate;
    juce::StreamingSocket listener;
    juce::OwnedArray<Client> clients;
    juce::CriticalSection clientLock, fileLock;

    std::atomic<int> port { 0 }, numClients { 0 };
    juce::String instanceId, hostName, soundPath, started;
    juce::File instanceFile;
};

} // namespace libero
