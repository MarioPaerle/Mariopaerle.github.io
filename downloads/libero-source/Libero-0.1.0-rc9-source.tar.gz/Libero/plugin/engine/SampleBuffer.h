#pragma once

#include <juce_audio_basics/juce_audio_basics.h>
#include <memory>

namespace libero
{
// Copies share decoded PCM. Load-time edits detach before writing; playback only reads.
class SampleBuffer
{
public:
    SampleBuffer() = default;
    SampleBuffer& operator= (juce::AudioBuffer<float> buffer)
    {
        data = std::make_shared<juce::AudioBuffer<float>> (std::move (buffer));
        return *this;
    }
    int getNumChannels() const noexcept { return data ? data->getNumChannels() : 0; }
    int getNumSamples() const noexcept { return data ? data->getNumSamples() : 0; }
    const float* getReadPointer (int channel) const noexcept { return data->getReadPointer (channel); }
    float getSample (int channel, int sample) const noexcept { return data->getSample (channel, sample); }
    float* getWritePointer (int channel)
    {
        if (data.use_count() != 1) data = std::make_shared<juce::AudioBuffer<float>> (*data);
        return data->getWritePointer (channel);
    }
private:
    std::shared_ptr<juce::AudioBuffer<float>> data;
};
}
