#pragma once

#include <juce_audio_formats/juce_audio_formats.h>
#include <bit>

namespace libero::rateCache
{
inline bool enabled() { return juce::SystemStats::getEnvironmentVariable ("LIBERO_DISABLE_RATE_CACHE", {}) != "1"; }
inline juce::File directory()
{
    const auto configured = juce::SystemStats::getEnvironmentVariable ("LIBERO_HOME", {});
    const auto home = configured.isEmpty() ? juce::File::getSpecialLocation (juce::File::userHomeDirectory).getChildFile ("Libero")
                                         : juce::File (configured);
    return home.getChildFile (".cache/resampled-v1");
}
inline juce::String key (const juce::File& source, double rate, float gain)
{
   #if JUCE_ARM
    const juce::String architecture = "arm-le:";
   #else
    const juce::String architecture = "intel-le:";
   #endif
    return architecture + source.getFullPathName() + ":" + juce::String (source.getSize()) + ":"
        + juce::String (source.getLastModificationTime().toMilliseconds()) + ":" + juce::String (rate, 12)
        + ":" + juce::String::toHexString (std::bit_cast<uint32_t> (gain));
}
inline juce::File fileFor (const juce::String& identity)
{
    return directory().getChildFile (juce::String::toHexString (identity.hashCode64()) + ".lpcm");
}
template<typename Buffer> inline uint64_t checksum (const Buffer& buffer)
{
    uint64_t hash = 14695981039346656037ull;
    for (int c = 0; c < buffer.getNumChannels(); ++c)
        for (int i = 0; i < buffer.getNumSamples(); ++i)
            hash = (hash ^ std::bit_cast<uint32_t> (buffer.getSample (c, i))) * 1099511628211ull;
    return hash;
}
inline bool read (const juce::String& identity, juce::AudioBuffer<float>& out, double& sourceRate, int& sourceFrames)
{
    if (!enabled()) return false;
    const auto file = fileFor (identity);
    juce::FileInputStream stream (file);
    if (!stream.openedOk() || stream.readInt() != 0x4c504331) return false;
    const auto length = stream.readInt();
    const auto utf8 = identity.toUTF8();
    if (length <= 0 || (size_t) length != identity.getNumBytesAsUTF8() || length > 32768) return false;
    juce::MemoryBlock stored ((size_t) length);
    if (stream.read (stored.getData(), length) != length || std::memcmp (stored.getData(), utf8.getAddress(), (size_t) length) != 0) return false;
    sourceRate = stream.readDouble(); sourceFrames = stream.readInt();
    const int channels = stream.readInt(), frames = stream.readInt();
    const auto expected = (uint64_t) stream.readInt64();
    const auto bytes = (juce::int64) channels * frames * (int) sizeof (float);
    if (!std::isfinite (sourceRate) || sourceRate <= 0 || sourceRate > 768000 || sourceFrames < 1
        || sourceFrames > 120 * sourceRate || channels < 1 || channels > 2 || frames < 1
        || bytes > 128 * 1024 * 1024 || stream.getTotalLength() - stream.getPosition() != bytes) return false;
    out.setSize (channels, frames);
    for (int c = 0; c < channels; ++c)
        if (stream.read (out.getWritePointer (c), frames * (int) sizeof (float)) != frames * (int) sizeof (float)) return false;
    if (checksum (out) != expected) return false;
    file.setLastModificationTime (juce::Time::getCurrentTime());
    return true;
}
inline void write (const juce::String& identity, const juce::AudioBuffer<float>& buffer, double sourceRate, int sourceFrames)
{
    const auto bytes = (juce::int64) buffer.getNumChannels() * buffer.getNumSamples() * (int) sizeof (float);
    if (!enabled() || bytes < 1 || bytes > 128 * 1024 * 1024) return;
    const auto dir = directory();
    if (!dir.createDirectory() || dir.getBytesFreeOnVolume() < 2ll * 1024 * 1024 * 1024) return;
    juce::TemporaryFile temporary (fileFor (identity));
    {
        juce::FileOutputStream stream (temporary.getFile());
        if (!stream.openedOk()) return;
        stream.writeInt (0x4c504331); stream.writeInt ((int) identity.getNumBytesAsUTF8());
        stream.write (identity.toRawUTF8(), identity.getNumBytesAsUTF8());
        stream.writeDouble (sourceRate); stream.writeInt (sourceFrames);
        stream.writeInt (buffer.getNumChannels()); stream.writeInt (buffer.getNumSamples());
        stream.writeInt64 ((juce::int64) checksum (buffer));
        for (int c = 0; c < buffer.getNumChannels(); ++c)
            if (!stream.write (buffer.getReadPointer (c), (size_t) buffer.getNumSamples() * sizeof (float))) return;
        stream.flush();
        if (stream.getStatus().failed()) return;
    }
    temporary.overwriteTargetFileWithTemporary();
}
inline void prune()
{
    if (!enabled()) return;
    auto files = directory().findChildFiles (juce::File::findFiles, false, "*.lpcm");
    juce::int64 total = 0;
    for (const auto& file : files) total += file.getSize();
    std::sort (files.begin(), files.end(), [] (const auto& a, const auto& b) { return a.getLastModificationTime() < b.getLastModificationTime(); });
    for (const auto& file : files)
    {
        if (total <= 1024ll * 1024 * 1024) break;
        const auto size = file.getSize();
        if (file.deleteFile()) total -= size;
    }
}
}
