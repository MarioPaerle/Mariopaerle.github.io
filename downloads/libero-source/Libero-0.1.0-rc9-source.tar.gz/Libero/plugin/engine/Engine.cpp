#include "Engine.h"

#include <algorithm>

namespace libero
{

using namespace dsp;

static_assert (kChunk == 32, "Reverb scratch buffers assume 32-sample chunks");

namespace
{
    // Transparent below 0.9, asymptotic to 1.0 above: a safety net, not a limiter.
    inline float ceiling (float x) noexcept
    {
        const auto a = std::abs (x);

        if (a <= 0.9f)
            return x;

        const auto y = 0.9f + 0.1f * fastTanh ((a - 0.9f) * 10.0f);
        return x < 0.0f ? -y : y;
    }
}

//==============================================================================
void Engine::AirPlayer::read (double inc, float& l, float& r) noexcept
{
    l = r = 0.0f;

    if (zone == nullptr)
        return;

    const auto& a = zone->audio;
    const auto len = zone->length();
    const auto loopEnd = zone->looped ? zone->loopEnd : len;
    const auto loopStart = zone->looped ? zone->loopStart : 0;

    const auto i0 = (int) pos;
    const auto f = (float) (pos - i0);
    auto i1 = i0 + 1;

    if (i1 >= loopEnd)
        i1 = loopStart;

    const auto* d0 = a.getReadPointer (0);
    l = d0[i0] + f * (d0[i1] - d0[i0]);

    if (a.getNumChannels() > 1)
    {
        const auto* d1 = a.getReadPointer (1);
        r = d1[i0] + f * (d1[i1] - d1[i0]);
    }
    else
    {
        r = l;
    }

    pos += inc;

    while (pos >= (double) loopEnd)
        pos -= (double) std::max (1, loopEnd - loopStart);
}

//==============================================================================
Engine::Engine()
{
    for (auto& r : retired)
        r.store (nullptr);
}

Engine::~Engine()
{
    delete pending.exchange (nullptr);
    delete outgoing;
    delete current;

    collectGarbage();
}

void Engine::prepare (double rate, int)
{
    sampleRate = rate;
    sr = (float) rate;

    for (auto& v : voices)
        v.prepare (sr);

    for (auto* s : { &gAttack, &gBody, &gTail, &gAir, &cordeAmt, &modalAmt, &widthS, &masterS })
        s->setTimeMs (20.0f, sr);

    for (auto* s : { &cutoffLog, &reso, &fltEnv, &drive })
        s->setTimeMs (15.0f, sr);

    dynSmooth.setTimeMs (20.0f, sr);
    lfoPitchCc1.setTimeMs (12.0f, sr);
    pitchOffset.setTimeMs (8.0f, sr);

    for (auto* s : { &osc1Gain, &osc2Gain, &phaseS[0], &phaseS[1] })
        s->setTimeMs (20.0f, sr);
    for (auto& s : subGain)
        s.setTimeMs (20.0f, sr);

    WaveTables::get();   // built once, here rather than on the audio thread
    lfo.prepare (sr);

    modal.prepare (sr);
    tape.prepare (sr);
    caldi.prepare (sr);
    echo.prepare (sr);
    reverb.prepare (sr);
    outDcL.setup (sr, 5.0f);
    outDcR.setup (sr, 5.0f);

    reset();
}

void Engine::snapSmoothers() noexcept
{
    const auto& p = params;
    caldi.set ((int) p[P::caldi_mode], p[P::caldi_amount], p[P::caldi_body], p[P::caldi_light], p[P::caldi_grain], p[P::caldi_motion], p[P::caldi_output]);
    gAttack.reset (dbToGain (p[P::lvl_attack]));
    gBody.reset (dbToGain (p[P::lvl_body]));
    gTail.reset (dbToGain (p[P::lvl_tail]));
    gAir.reset (dbToGain (p[P::lvl_air]));

    const auto isCorde = (int) p[P::res_mode] == (int) ResMode::corde;
    cordeAmt.reset (isCorde ? p[P::res_mix] : 0.0f);
    modalAmt.reset (isCorde ? 0.0f : p[P::res_mix]);

    widthS.reset (p[P::width]);
    masterS.reset (dbToGain (p[P::master]));
    osc1Gain.reset (dbToGain (p[P::osc1_level]));
    phaseS[0].reset (p[P::osc1_phase]);
    phaseS[1].reset (p[P::osc2_phase]);
    motionPhase = { 0.0, 2.1, 4.4 };
    osc2Gain.reset (dbToGain (p[P::osc2_level]));
    subGain[0].reset (dbToGain (p[P::sub_level]));
    subGain[1].reset (dbToGain (p[P::sub2_level]));
    subGain[2].reset (dbToGain (p[P::sub3_level]));
    cutoffLog.reset (std::log2 (p[P::flt_cutoff]));
    reso.reset (p[P::flt_reso]);
    fltEnv.reset (p[P::flt_env]);
    drive.reset (p[P::drive]);
    pitchOffset.reset (p[P::tune] + p[P::fine] * 0.01f);

    fltModeA = fltModeB = (int) p[P::flt_mode];
    fltMix = 1.0f;
}

void Engine::reset()
{
    for (auto& v : voices)
        v.kill();

    keyDown.fill (false);
    heldCount = 0;
    monoIndex = -1;
    takeRng.reseed (0x5eed7a4eu);
    humanRng.reseed (0x0da7e5u);
    cc1 = cc11 = -1.0f;
    idleSamples = 0;
    dynSmooth.reset (clampf (params[P::dynamics], 0.0f, 1.0f));
    lfoPitchCc1.reset (0.0f);
    oscRng.reseed (0x05c1u);
    lfo.reset();
    lastTake.fill (-1);
    sustainPedal = false;
    pitchBend = 0.0f;
    bendChannels.fill(BendChannel{});
    bendChannel=0;
    lastNote = -1.0f;
    airEnv = 0.0f;
    airSwap = 1.0f;
    airOld.zone = nullptr;
    air.pos = 0.0;

    snapSmoothers();

    const auto& p = params;
    tape.set (p[P::tape_wow], p[P::tape_flutter], p[P::tape_sat], p[P::tape_age], p[P::tape_mix]);
    echo.set (p[P::echo_time], p[P::echo_feedback], p[P::echo_tone], p[P::echo_spread], p[P::echo_mix]);
    echo.setSynced (p[P::echo_sync] < 0.5f, kEchoDivBeats[std::clamp ((int) p[P::echo_div], 0, kNumEchoDivs - 1)], hostBpm);
    reverb.set ((RevMode) (int) p[P::rev_mode], current != nullptr && current->hasIR(),
                p[P::rev_size], p[P::rev_decay], p[P::rev_predelay], p[P::rev_damp],
                p[P::rev_width], p[P::rev_shimmer], p[P::rev_mix]);

    modal.reset();
    tape.reset();
    caldi.reset();
    echo.reset();
    reverb.reset();
    outDcL.reset();
    outDcR.reset();
}

//==============================================================================
void Engine::submitSound (std::unique_ptr<SoundData> sd)
{
    if (sd == nullptr)
        return;

    if (sd->hasIR())
    {
        juce::AudioBuffer<float> ir (sd->ir);
        reverb.loadImpulse (std::move (ir), sd->irSampleRate);
    }

    // If an earlier submission was never picked up, we own it again and can free it here.
    delete pending.exchange (sd.release());
    collectGarbage();
}

void Engine::finishLoadingOffline()
{
    if (auto* p = pending.exchange (nullptr))
    {
        delete outgoing;
        outgoing = nullptr;

        for (auto& v : voices)
            v.kill();

        delete current;
        current = p;
        lastTake.fill (-1);
        monoIndex = -1;
        lastArticParam = (int) std::lround (params[P::artic]);
        activeArt.store (current->numArticulations() > 0 ? juce::jmin (lastArticParam, current->numArticulations() - 1) : -1,
                         std::memory_order_relaxed);
        air.start (current->airZone >= 0 ? &current->zones[(size_t) current->airZone] : nullptr);
        airOld.zone = nullptr;
        airSwap = 1.0f;
    }

    reverb.finishLoading();
}

void Engine::collectGarbage()
{
    for (auto& r : retired)
        delete r.exchange (nullptr);
}

bool Engine::retire (SoundData* sd) noexcept
{
    for (auto& r : retired)
    {
        SoundData* expected = nullptr;

        if (r.compare_exchange_strong (expected, sd))
            return true;
    }

    return false;
}

void Engine::swapSoundIfPending() noexcept
{
    if (outgoing != nullptr)
    {
        bool inUse = airSwap < 1.0f;

        for (const auto& v : voices)
            inUse = inUse || (v.isActive() && v.getSound() == outgoing);

        if (! inUse && retire (outgoing))
            outgoing = nullptr;

        return;
    }

    if (pending.load (std::memory_order_relaxed) == nullptr)
        return;

    auto* next = pending.exchange (nullptr);

    if (next == nullptr)
        return;

    if (current != nullptr)
    {
        // Old voices fade in a few ms; the air bed crossfades. The old sound stays alive until
        // nothing references it, then goes back to a non-audio thread to be freed.
        for (auto& v : voices)
            if (v.isActive())
                v.steal();

        outgoing = current;
        airOld = air;
        airSwap = 0.0f;
    }

    current = next;
    air.start (current->airZone >= 0 ? &current->zones[(size_t) current->airZone] : nullptr);
    lastTake.fill (-1);
    monoIndex = -1;

    // A new sound starts on the articulation the parameter holds (the first after a reset).
    lastArticParam = (int) std::lround (params[P::artic]);
    activeArt.store (current->numArticulations() > 0 ? juce::jmin (lastArticParam, current->numArticulations() - 1) : -1,
                     std::memory_order_relaxed);
}

//==============================================================================
void Engine::allNotesOff (bool hard) noexcept
{
    keyDown.fill (false);
    heldCount = 0;
    sustainPedal = false;

    for (auto& v : voices)
    {
        if (! v.isActive())
            continue;

        if (hard)
            v.steal();
        else
            v.noteOff();
    }
}

int Engine::getActiveVoiceCount() const noexcept
{
    int n = 0;

    for (const auto& v : voices)
        n += v.isActive() ? 1 : 0;

    return n;
}

int Engine::chooseTake (int group, int count) noexcept
{
    if (count <= 1 || group < 0)
        return 0;

    // Random without immediate repeat, from a seeded generator (renders stay reproducible).
    auto& last = lastTake[(size_t) group % lastTake.size()];
    int t;

    if ((last < 0 || last >= count) && snd().rrResetMs >= 0.0f)
    {
        t = 0;   // the cycle restarts at take 0 (after rr_reset_ms of silence, and at the start)
    }
    else if (last < 0 || last >= count)
    {
        t = (int) (takeRng.nextU32() % (uint32_t) count);
    }
    else
    {
        t = (int) (takeRng.nextU32() % (uint32_t) (count - 1));
        t += t >= last ? 1 : 0;
    }

    last = (int16_t) t;
    return t;
}

Takes Engine::chooseTakes (int note, int velocity, int art) noexcept
{
    Takes t;
    const auto bodyGroup = snd().findGroup (Layer::body, note, velocity, -1.0f, art);
    const auto bodyCount = snd().takeCount (bodyGroup);
    t.body = chooseTake (bodyGroup, bodyCount);

    // Attack and tail follow the body's take when they have as many, else choose on their own.
    for (auto layer : { Layer::attack, Layer::tail })
    {
        const auto g = snd().findGroup (layer, note, velocity, -1.0f, art);
        const auto n = snd().takeCount (g);
        (layer == Layer::attack ? t.attack : t.tail) = (n == bodyCount) ? t.body : chooseTake (g, n);
    }

    return t;
}

void Engine::stackRemove (int note) noexcept
{
    for (int i = 0; i < heldCount; ++i)
    {
        if (heldStack[(size_t) i] == note)
        {
            for (int k = i; k + 1 < heldCount; ++k)
                heldStack[(size_t) k] = heldStack[(size_t) k + 1];

            --heldCount;
            return;
        }
    }
}

Voice* Engine::monoVoice() noexcept
{
    if (monoIndex < 0)
        return nullptr;

    auto& v = voices[(size_t) monoIndex];

    if (! v.isActive() || v.isStealing() || v.getOrder() != monoOrder)
        return nullptr;

    return &v;
}

Voice* Engine::startVoice (int note, int velocity, int limit, float glideFrom) noexcept
{
    const auto countPlaying = [this]
    {
        int n = 0;
        for (const auto& v : voices)
            n += (v.isActive() && ! v.isStealing()) ? 1 : 0;
        return n;
    };

    // Voice stealing: released voices first (the quietest of them), then the oldest held one.
    for (auto playing = countPlaying(); playing >= limit; --playing)
    {
        Voice* victim = nullptr;

        for (auto& v : voices)
        {
            if (! v.isActive() || v.isStealing())
                continue;

            const auto bothReleased = v.isReleased() && victim != nullptr && victim->isReleased();

            if (victim == nullptr
                || (v.isReleased() && ! victim->isReleased())
                || (bothReleased && v.getLevel() < victim->getLevel())
                || (! v.isReleased() && ! victim->isReleased() && v.getOrder() < victim->getOrder()))
                victim = &v;
        }

        if (victim == nullptr)
            break;

        victim->steal();
    }

    Voice* slot = nullptr;

    for (auto& v : voices)
        if (! v.isActive()) { slot = &v; break; }

    if (slot == nullptr)
    {
        // Every slot is busy fading out: reuse the oldest one outright.
        for (auto& v : voices)
            if (slot == nullptr || v.getOrder() < slot->getOrder())
                slot = &v;

        slot->kill();
    }

    VoiceControl c;
    c.glideMs = params[P::glide];
    c.velSens = params[P::vel_sens];
    slot->start (snd(), note, velocity, glideFrom, ++voiceOrder, c, setupNote (note, velocity));

    if (const auto* nz = slot->leadBodyZone(); nz != nullptr && (nz->chokeGroup > 0 || ! nz->chokes.empty()))
        for (auto& v : voices)
        {
            if (&v == slot || ! v.isActive())
                continue;

            const auto* vz = v.leadBodyZone();

            if (vz == nullptr || vz->chokeGroup <= 0)
                continue;

            if (vz->chokeGroup == nz->chokeGroup
                || std::find (nz->chokes.begin(), nz->chokes.end(), vz->chokeGroup) != nz->chokes.end())
                v.choke();
        }
    lastNote = (float) note;
    return slot;
}

float Engine::liveDynamicsTarget() const noexcept
{
    // Modulazione = CC1; Velocità = the bundle's own source (velocity unless it says cc1/cc11);
    // Manopola = the `dynamics` knob. A controller that hasn't moved yet reads as the knob.
    const auto mode = (DynMode) (int) params[P::dyn_mode];
    const auto knob = clampf (params[P::dynamics], 0.0f, 1.0f);

    if (mode == DynMode::manopola)
        return knob;

    auto source = SoundData::DynSource::cc1;

    if (mode == DynMode::velocita)
        source = current != nullptr ? current->dynSource : SoundData::DynSource::velocity;

    if (source == SoundData::DynSource::velocity)
        return -1.0f;

    const auto cc = source == SoundData::DynSource::cc11 ? cc11 : cc1;
    return cc < 0.0f ? knob : cc;
}

NoteSetup Engine::setupNote (int note, int velocity) noexcept
{
    NoteSetup s;

    // Round robin restarts after enough silence.
    if (snd().rrResetMs >= 0.0f && (double) idleSamples >= snd().rrResetMs * 0.001 * sampleRate)
        lastTake.fill (-1);

    s.art = activeArt.load (std::memory_order_relaxed);
    s.takes = chooseTakes (note, velocity, s.art);
    s.oscSeed = oscRng.nextU32();
    s.oscRetrigger = (int) params[P::osc_retrig] == 1;

    const auto live = liveDynamicsTarget();
    s.dyn = live >= 0.0f ? dynSmooth.current
                         : std::pow ((float) velocity / 127.0f, snd().velocityCurve);

    if (snd().hasHumanize && params[P::humanize] > 0.0f)
    {
        // Seeded per engine reset, three draws per note: renders stay reproducible.
        const auto h = clampf (params[P::humanize], 0.0f, 1.0f);
        s.detune = humanRng.bipolar() * snd().humanizeCents * h * 0.01f;
        s.delay = (int) (humanRng.uniform() * snd().humanizeMs * h * 0.001f * sr);
        s.gain = dbToGain (humanRng.bipolar() * snd().humanizeDb * h);
    }

    const auto velocityNorm = (float) juce::jlimit (1, 127, velocity) / 127.0f;
    const auto legacyVelocityGain = lerp (1.0f, velocityNorm * std::sqrt (velocityNorm),
                                           clampf (params[P::vel_sens], 0.0f, 1.0f));
    // Optional smooth knee: steep near silence, then progressively flatter
    // through the useful forte range. A zero setting keeps the legacy path.
    constexpr float velocityKnee = 0.32f;
    const auto shapedVelocityGain = velocityNorm * (1.0f + velocityKnee)
                                    / (velocityNorm + velocityKnee);
    const auto curve = clampf (params[P::vel_amp_curve], 0.0f, 1.0f);
    s.velocityGain = lerp (legacyVelocityGain, shapedVelocityGain, curve) * s.gain;
    s.hasVelocityGain = curve > 0.0f;

    return s;
}

void Engine::legato (Voice& v, int note, int velocity) noexcept
{
    auto s = setupNote (note, velocity);
    s.delay = 0;   // a slur is continuous: no onset to humanise
    v.legatoTo (note, s);
    lastNote = (float) note;
}

void Engine::noteOn (int note, int velocity) noexcept
{
    // With no bundle loaded the oscillators still play (the plugin is a synth out of the box).
    keyDown[(size_t) note] = true;
    keyVelocity[(size_t) note] = (uint8_t) velocity;
    stackRemove (note);
    const auto othersHeld = heldCount > 0;

    // Portamento only between overlapping notes: from the most recent key still held, never
    // across a rest.
    const auto glideFrom = othersHeld ? (float) heldStack[(size_t) heldCount - 1] : -1.0f;
    heldStack[(size_t) heldCount++] = (uint8_t) note;

    const auto mode = (PlayMode) (int) params[P::mode];

    if (mode == PlayMode::poli)
    {
        startVoice (note, velocity, juce::jlimit (1, kMaxVoices, (int) params[P::voices]), glideFrom);
        return;
    }

    // Mono / Legato: one voice, last-note priority.
    if (auto* v = monoVoice(); v != nullptr && mode == PlayMode::legato && othersHeld && ! v->isReleased())
    {
        legato (*v, note, velocity);
        return;
    }

    auto* v = startVoice (note, velocity, 1, glideFrom);
    monoIndex = (int) (v - voices.data());
    monoOrder = v->getOrder();
}

void Engine::releaseVoice (Voice& v) noexcept
{
    if (sustainPedal)
        v.holdBySustain();
    else
        v.noteOff();
}

void Engine::noteOff (int note) noexcept
{
    keyDown[(size_t) note] = false;
    stackRemove (note);

    const auto mode = (PlayMode) (int) params[P::mode];
    Voice* mono = nullptr;

    if (mode != PlayMode::poli && current != nullptr)
    {
        mono = monoVoice();

        if (mono != nullptr && mono->getNote() == note && mono->isKeyDown())
        {
            if (heldCount > 0)
            {
                // Note memory: fall back to the most recent key still held.
                const auto back = (int) heldStack[(size_t) heldCount - 1];
                const auto vel = (int) keyVelocity[(size_t) back];

                if (mode == PlayMode::legato)
                {
                    legato (*mono, back, vel);
                }
                else
                {
                    auto* v = startVoice (back, vel, 1, (float) note);   // back from the note that sounded
                    monoIndex = (int) (v - voices.data());
                    monoOrder = v->getOrder();
                }
            }
            else
            {
                releaseVoice (*mono);
            }
        }
    }

    for (auto& v : voices)
    {
        if (&v == mono || ! v.isActive() || v.getNote() != note || ! v.isKeyDown())
            continue;

        releaseVoice (v);
    }
}

void Engine::updatePitchBend() noexcept
{
    const auto& b=bendChannels[(size_t)bendChannel];
    pitchBend=(float)(b.wheel-8192)/8192.f*((float)b.semitones+.01f*(float)b.cents);
}

void Engine::handleMidi (const juce::MidiMessage& m) noexcept
{
    if (m.isNoteOn() || m.isNoteOff())
    {
        // A keyswitch key selects an articulation and makes no sound; it never reaches the voices.
        if (const auto ks = snd().keyswitch[(size_t) juce::jlimit (0, 127, m.getNoteNumber())]; ks >= 0)
        {
            if (m.isNoteOn())
                activeArt.store (ks, std::memory_order_relaxed);

            return;
        }
    }

    if (m.isNoteOn())
        noteOn (m.getNoteNumber(), m.getVelocity());
    else if (m.isNoteOff())
        noteOff (m.getNoteNumber());
    else if (m.isSustainPedalOn())
        sustainPedal = true;
    else if (m.isSustainPedalOff())
    {
        sustainPedal = false;

        for (auto& v : voices)
            if (v.isActive() && v.sustained)
            {
                v.sustained = false;
                v.noteOff();
            }
    }
    else if (m.isAllSoundOff())
        allNotesOff (true);
    else if (m.isResetAllControllers())
    {
        auto& b=bendChannels[(size_t)juce::jlimit(0,15,m.getChannel()-1)];
        b.rpnMsb=b.rpnLsb=127; b.wheel=8192;
        // CC121 clears controller state/selection, not the registered bend
        // sensitivity. A full engine reset restores the default ±2 on all channels.
        if(m.getChannel()-1==bendChannel)updatePitchBend();
        allNotesOff(false);
    }
    else if (m.isAllNotesOff())
        allNotesOff (false);
    else if (m.isPitchWheel())
    {
        bendChannel=juce::jlimit(0,15,m.getChannel()-1);
        bendChannels[(size_t)bendChannel].wheel=m.getPitchWheelValue();
        updatePitchBend();
    }
    else if (m.isController() && (m.getControllerNumber()==100 || m.getControllerNumber()==101
                              || m.getControllerNumber()==98 || m.getControllerNumber()==99
                              || m.getControllerNumber()==6 || m.getControllerNumber()==38))
    {
        const int channel=juce::jlimit(0,15,m.getChannel()-1),cc=m.getControllerNumber();
        const auto value=(uint8_t)m.getControllerValue();auto& b=bendChannels[(size_t)channel];
        if(cc==100)b.rpnLsb=value;
        else if(cc==101)b.rpnMsb=value;
        else if(cc==98 || cc==99)b.rpnMsb=b.rpnLsb=127; // NRPN selection cancels RPN
        else if(b.rpnMsb==0 && b.rpnLsb==0)
        {
            if(cc==6)b.semitones=value;else b.cents=value;
            if(channel==bendChannel)updatePitchBend(); // change a held bend immediately
        }
    }
    else if (m.isController() && m.getControllerNumber() == 1)
        cc1 = (float) m.getControllerValue() / 127.0f;
    else if (m.isController() && m.getControllerNumber() == 11)
        cc11 = (float) m.getControllerValue() / 127.0f;
}

//==============================================================================
Voice::Playback Engine::samplePlayback() const noexcept
{
    Voice::Playback result;
    uint64_t newest = 0;
    for (const auto& voice : voices)
        if (voice.getSound() == current && !voice.isStealing() && voice.getOrder() >= newest)
        {
            const auto candidate = voice.playback();
            if (candidate.zone >= 0) { result = candidate; newest = voice.getOrder(); }
        }
    return result;
}

void Engine::process (float* l, float* r, int n, const juce::MidiBuffer& midi) noexcept
{
    juce::ScopedNoDenormals noDenormals;

    swapSoundIfPending();

    // The `artic` parameter selects an articulation; keyswitches (handleMidi) override it until it moves.
    if (const auto p = (int) std::lround (params[P::artic]); p != lastArticParam)
    {
        lastArticParam = p;
        activeArt.store (snd().numArticulations() > 0 ? juce::jmin (p, snd().numArticulations() - 1) : -1,
                         std::memory_order_relaxed);
    }

    auto it = midi.begin();
    const auto end = midi.end();
    int pos = 0;

    while (pos < n)
    {
        while (it != end && (*it).samplePosition <= pos)
        {
            handleMidi ((*it).getMessage());
            ++it;
        }

        auto next = n;

        if (it != end)
            next = std::min (n, std::max (pos + 1, (*it).samplePosition));

        const auto len = std::min (kChunk, next - pos);
        renderChunk (l + pos, r + pos, len);
        pos += len;
    }

    while (it != end)
    {
        handleMidi ((*it).getMessage());
        ++it;
    }
}

void Engine::renderChunk (float* outL, float* outR, int n) noexcept
{
    auto effectiveParams = params;
    const auto artIndex = activeArt.load (std::memory_order_relaxed);
    if (current != nullptr && artIndex >= 0 && artIndex < current->numArticulations())
        for (const auto& [index, value] : current->articulations[(size_t) artIndex].profile)
            if (index >= 0 && index < kNumParams)
                effectiveParams.v[(size_t) index] = value;
    const auto& p = effectiveParams;

    // --- control rate ---------------------------------------------------------------------
    gAttack.target = dbToGain (p[P::lvl_attack]);
    gBody.target   = dbToGain (p[P::lvl_body]);
    gTail.target   = dbToGain (p[P::lvl_tail]);
    gAir.target    = dbToGain (p[P::lvl_air]);

    const auto resMode = (ResMode) (int) p[P::res_mode];
    cordeAmt.target = resMode == ResMode::corde ? p[P::res_mix] : 0.0f;
    modalAmt.target = resMode == ResMode::corde ? 0.0f : p[P::res_mix];

    widthS.target  = p[P::width];
    masterS.target = dbToGain (p[P::master]);

    for (int i = 0; i < n; ++i)
    {
        aAtt[(size_t) i]   = gAttack.next();
        aBody[(size_t) i]  = gBody.next();
        aTail[(size_t) i]  = gTail.next();
        aCorde[(size_t) i] = cordeAmt.next();
        aModal[(size_t) i] = modalAmt.next();
    }

    cutoffLog.target = std::log2 (clampf (p[P::flt_cutoff], 20.0f, 20000.0f));
    reso.target = p[P::flt_reso];
    fltEnv.target = p[P::flt_env];
    drive.target = p[P::drive];
    pitchOffset.target = p[P::tune] + p[P::fine] * 0.01f;

    // Filter mode changes crossfade A -> B over 20 ms, ramped per sample inside the voices.
    const auto mode = (int) p[P::flt_mode];

    if (mode != fltModeB)
    {
        fltModeA = fltMix >= 0.5f ? fltModeB : fltModeA;
        fltModeB = mode;
        fltMix = 0.0f;
    }
    else if (fltMix >= 1.0f)
    {
        fltModeA = fltModeB;
    }

    const auto fltMixStart = fltMix;

    if (fltMix < 1.0f)
        fltMix = std::min (1.0f, fltMix + (float) n / (0.02f * sr));

    VoiceControl c;
    c.sampleRate = sr;
    c.playbackScale = current != nullptr ? (float) (current->sampleRate / sampleRate) : 1.0f;
    c.gAttack = aAtt.data();
    c.gBody = aBody.data();
    c.gTail = aTail.data();
    c.corde = aCorde.data();
    c.attackMs = p[P::amp_attack];
    c.decayMs = p[P::amp_decay];
    c.sustain = p[P::amp_sustain];
    c.releaseMs = p[P::amp_release];
    c.curve = p[P::amp_curve];
    c.pitchOffset = pitchOffset.advance (n) + pitchBend;
    c.glideMs = p[P::glide];
    c.velSens = p[P::vel_sens];
    c.fltModeA = fltModeA;
    c.fltModeB = fltModeB;
    c.fltMix = fltMix;
    c.fltMixStart = fltMixStart;
    c.cutoff = std::exp2 (cutoffLog.advance (n));
    c.reso = reso.advance (n);
    c.fltEnv = fltEnv.advance (n);
    c.drive = drive.advance (n);
    c.resTune = p[P::res_tune];
    c.resDecay = p[P::res_decay];
    c.resBright = p[P::res_bright];

    // Oscillators and LFO.
    const auto motion = [this] { return (float) ((std::sin (motionPhase[0]) + std::sin (motionPhase[1]) + std::sin (motionPhase[2])) / 3.0); };
    const auto phaseMotion = motion();

    for (int m = 0; m < 3; ++m)
    {
        static constexpr double rates[3] = { 0.4, 0.83, 1.37 };
        motionPhase[(size_t) m] = std::fmod (motionPhase[(size_t) m] + 2.0 * juce::MathConstants<double>::pi * rates[m] * n / sampleRate,
                                             2.0 * juce::MathConstants<double>::pi);
    }

    const auto phaseMotionEnd = motion();
    const auto base = [&p] (int k, P first) { return [&p, k, first] (int i) { return p.v[(size_t) ((int) first + k * 10 + i)]; }; };
    dsp::Smoother* gains[2] = { &osc1Gain, &osc2Gain };

    for (int k = 0; k < 2; ++k)
    {
        const auto at = base (k, P::osc1_wave);   // wave, oct, semi, fine, level, pw, phase, voices, detune, spread
        auto& s = oscControl.osc[(size_t) k];
        s.wave = (OscWave) (int) at (0);
        s.offset = at (1) * 12.0f + at (2) + at (3) * 0.01f;
        gains[k]->target = dbToGain (at (4));
        s.gainStart = gains[k]->current;
        s.gainEnd = gains[k]->advance (n);
        s.pw = at (5);

        // L/R phase offset, smoothed, plus its slow internal motion (three incommensurate rates).
        const auto modDepth = p[k == 0 ? P::osc1_phase_mod : P::osc2_phase_mod] * 0.25f;
        phaseS[(size_t) k].target = at (6);
        s.phaseLR = phaseS[(size_t) k].current + modDepth * phaseMotion;
        s.phaseLREnd = phaseS[(size_t) k].advance (n) + modDepth * phaseMotionEnd;
        s.voices = (int) at (7);
        s.detune = at (8);
        s.spread = at (9);
    }

    const P subLevelParams[3] = { P::sub_level, P::sub2_level, P::sub3_level };
    const P subDivisorParams[3] = { P::sub_divisor, P::sub2_divisor, P::sub3_divisor };
    for (int i = 0; i < 3; ++i)
    {
        auto& gain = subGain[(size_t) i];
        gain.target = dbToGain (p[subLevelParams[i]]);
        oscControl.sub[(size_t) i].gainStart = gain.current;
        oscControl.sub[(size_t) i].gainEnd = gain.advance (n);
        oscControl.sub[(size_t) i].divisor = p[subDivisorParams[i]];
    }
    oscControl.subWave = (int) p[P::sub_wave] == 1 ? OscControl::SubWave::square
                         : (int) p[P::sub_wave] == 2 ? OscControl::SubWave::saw
                                                      : OscControl::SubWave::sine;
    oscControl.drift = p[P::osc_drift];
    c.osc = &oscControl;

    c.lfoStart = lfo.value();
    c.lfoEnd = lfo.advance ((LfoShape) (int) p[P::lfo_shape], p[P::lfo_rate], n);
    lfoPitchCc1.target = (cc1 < 0.0f ? 0.0f : clampf (cc1, 0.0f, 1.0f)) * p[P::lfo_pitch_cc1];
    c.lfoPitch = p[P::lfo_pitch] + lfoPitchCc1.advance (n);
    c.lfoCutoff = p[P::lfo_cutoff];
    c.lfoAmp = p[P::lfo_amp];
    c.lfoPw = p[P::lfo_pw];
    c.lfoDelayMs = p[P::lfo_delay];

    c.fenvOwn = (int) p[P::fenv_source] == 1;
    c.fenvAttack = p[P::fenv_attack];
    c.fenvDecay = p[P::fenv_decay];
    c.fenvSustain = p[P::fenv_sustain];
    c.fenvRelease = p[P::fenv_release];
    c.fltKey = p[P::flt_key];
    c.fltVel = p[P::flt_vel];
    c.fltDyn = p[P::flt_dyn];
    c.ampDyn = p[P::amp_dyn];

    // Dynamics axis: live sources glide (~20 ms) on every sounding voice.
    const auto liveDyn = liveDynamicsTarget();
    c.dynLive = liveDyn >= 0.0f;

    if (c.dynLive)
    {
        dynSmooth.target = liveDyn;
        c.dynStart = dynSmooth.current;
        c.dynEnd = dynSmooth.advance (n);
    }

    // --- voices -------------------------------------------------------------------------------
    std::fill (sumL.begin(), sumL.begin() + n, 0.0f);
    std::fill (sumR.begin(), sumR.begin() + n, 0.0f);

    bool anyActive = false;

    for (auto& v : voices)
    {
        if (v.isActive())
        {
            v.render (c, sumL.data(), sumR.data(), n);
            anyActive = true;
        }
    }

    idleSamples = anyActive || heldCount > 0 ? 0 : idleSamples + n;

    modal.set (resMode == ResMode::corde ? ResMode::vetro : resMode, p[P::res_tune], p[P::res_decay], p[P::res_bright]);
    modal.process (sumL.data(), sumR.data(), aModal.data(), n);

    // --- air bed ------------------------------------------------------------------------------
    bool gate = false;

    for (auto k : keyDown)
        gate = gate || k;

    for (const auto& v : voices)
        gate = gate || (v.isActive() && v.sustained);

    const auto airAttackStep  = 1.0f / std::max (1.0f, p[P::air_attack] * 0.001f * sr);
    const auto airReleaseStep = 1.0f / std::max (1.0f, p[P::air_release] * 0.001f * sr);
    const auto follow = clampf (p[P::air_follow], 0.0f, 1.0f);
    const auto airInc = c.playbackScale;
    const auto swapStep = 1.0f / (0.03f * sr);

    for (int i = 0; i < n; ++i)
    {
        airEnv = gate ? std::min (1.0f, airEnv + airAttackStep) : std::max (0.0f, airEnv - airReleaseStep);
        const auto g = gAir.next() * ((1.0f - follow) + follow * airEnv);

        float al, ar;
        air.read (airInc, al, ar);

        if (airSwap < 1.0f)
        {
            airSwap = std::min (1.0f, airSwap + swapStep);
            float ol, orr;
            airOld.read (airInc, ol, orr);
            const auto gi = std::sin (airSwap * 1.5707963f), go = std::cos (airSwap * 1.5707963f);
            al = al * gi + ol * go;
            ar = ar * gi + orr * go;

            if (airSwap >= 1.0f)
                airOld.zone = nullptr;
        }

        sumL[(size_t) i] += al * g;
        sumR[(size_t) i] += ar * g;
    }

    // --- global chain -------------------------------------------------------------------------
    caldi.set ((int) p[P::caldi_mode], p[P::caldi_amount], p[P::caldi_body], p[P::caldi_light], p[P::caldi_grain], p[P::caldi_motion], p[P::caldi_output]);
    caldi.process (sumL.data(), sumR.data(), n);
    tape.set (p[P::tape_wow], p[P::tape_flutter], p[P::tape_sat], p[P::tape_age], p[P::tape_mix]);
    tape.process (sumL.data(), sumR.data(), n);

    echo.set (p[P::echo_time], p[P::echo_feedback], p[P::echo_tone], p[P::echo_spread], p[P::echo_mix]);
    echo.setSynced (p[P::echo_sync] < 0.5f, kEchoDivBeats[std::clamp ((int) p[P::echo_div], 0, kNumEchoDivs - 1)], hostBpm);
    echo.process (sumL.data(), sumR.data(), n);

    reverb.set ((RevMode) (int) p[P::rev_mode], current != nullptr && current->hasIR(),
                p[P::rev_size], p[P::rev_decay], p[P::rev_predelay], p[P::rev_damp],
                p[P::rev_width], p[P::rev_shimmer], p[P::rev_mix]);
    reverb.process (sumL.data(), sumR.data(), n);

    for (int i = 0; i < n; ++i)
    {
        const auto w = widthS.next();
        const auto g = masterS.next();
        const auto l = outDcL.tick (sumL[(size_t) i]);
        const auto r = outDcR.tick (sumR[(size_t) i]);
        const auto mid = 0.5f * (l + r);
        const auto side = 0.5f * (l - r) * w;
        outL[i] = ceiling (sanitize ((mid + side) * g));
        outR[i] = ceiling (sanitize ((mid - side) * g));
    }
}

} // namespace libero
