#pragma once

#include <array>
#include <cstddef>
#include <string>
#include <string_view>

namespace libero
{

// Parameter table (SPEC §5). Order is internal; ids are the stable contract.
enum class P : int
{
    lvl_attack, lvl_body, lvl_tail, lvl_air,
    amp_attack, amp_decay, amp_sustain, amp_release, amp_curve,
    air_attack, air_release, air_follow,
    tune, fine, glide, vel_sens, voices,
    flt_mode, flt_cutoff, flt_reso, flt_env, drive,
    res_mode, res_tune, res_decay, res_bright, res_mix,
    tape_wow, tape_flutter, tape_sat, tape_age, tape_mix,
    echo_time, echo_feedback, echo_tone, echo_spread, echo_mix,
    rev_mode, rev_size, rev_decay, rev_predelay, rev_damp, rev_width, rev_shimmer, rev_mix,
    width, master,
    mode,           // appended later (Pitch group in the SPEC): kept last so host indices stay stable
    dyn_mode, dynamics, humanize,
    osc1_wave, osc1_oct, osc1_semi, osc1_fine, osc1_level, osc1_pw, osc1_phase, osc1_voices, osc1_detune, osc1_spread,
    osc2_wave, osc2_oct, osc2_semi, osc2_fine, osc2_level, osc2_pw, osc2_phase, osc2_voices, osc2_detune, osc2_spread,
    sub_level, sub_wave, osc_drift, osc_retrig,
    lfo_shape, lfo_rate, lfo_delay, lfo_pitch, lfo_cutoff, lfo_amp, lfo_pw,
    fenv_attack, fenv_decay, fenv_sustain, fenv_release, fenv_source, flt_key, flt_vel,
    osc1_phase_mod, osc2_phase_mod,
    artic,          // articulation index into the manifest's list (bundle/2)
    echo_sync, echo_div,   // echo time from the host tempo (Tempo) or echo_time in ms (Libero)
    caldi_mode, caldi_amount, caldi_body, caldi_light, caldi_grain, caldi_motion, caldi_output,
    flt_dyn,        // CC1/Manopola timbre sweep in octaves; independent of played pitch
    sub_divisor, sub2_level, sub2_divisor, sub3_level, sub3_divisor, amp_dyn,
    lfo_pitch_cc1, vel_amp_curve,
    count
};

constexpr int kNumParams = (int) P::count;

enum class Scale
{
    continuous,   // JUCE-style power skew: value `centre` sits at mid-travel (linear if centre is 0/unset)
    stepped,      // integer steps, linear
    choice
};

struct ParamSpec
{
    const char* id;
    const char* name;
    const char* group;
    float min, max, def;
    Scale scale;
    float centre;            // continuous only; NaN = linear
    const char* unit;
    const char* const* choices;
    int numChoices;
};

const ParamSpec& spec (P p) noexcept;
const ParamSpec& spec (int index) noexcept;
int findParam (std::string_view id) noexcept;   // -1 if unknown

float toNormalised (const ParamSpec&, float plain) noexcept;
float fromNormalised (const ParamSpec&, float norm) noexcept;
float clampPlain (const ParamSpec&, float plain) noexcept;
float skewFactor (const ParamSpec&) noexcept;   // JUCE NormalisableRange skew (1 = linear)

// Echo divisions (echo_div), in quarter-note beats; index = choice index.
constexpr int kNumEchoDivs = 12;
constexpr float kEchoDivBeats[kNumEchoDivs] = { 0.125f, 1.0f / 6.0f, 0.25f, 0.375f, 1.0f / 3.0f, 0.5f, 0.75f,
                                                2.0f / 3.0f, 1.0f, 1.5f, 2.0f, 4.0f };
constexpr float kDefaultBpm = 120.0f;

// Choice lists (strings exactly as in SPEC §5).
enum class FilterMode { basso, banda, alto, vocale };
enum class ResMode    { corde, vetro, legno, metallo };
enum class RevMode    { cappella, basilica, cisterna, piastra, impronta };
enum class PlayMode   { poli, mono, legato };
enum class DynMode    { velocita, modulazione, manopola };
// Oscillator waves: Sega, Quadra, Triangolo, Seno, Rumore (see OscWave); LFO shapes: Seno,
// Triangolo, Quadra, Dente, Casuale (see LfoShape); sub: Seno, Quadra; retrigger: Libera, Riavvia.

// A full set of plain values, used by the engine and the CLI.
struct ParamSet
{
    std::array<float, kNumParams> v {};

    ParamSet() noexcept;                                 // SPEC defaults
    float  operator[] (P p) const noexcept { return v[(size_t) p]; }
    float& operator[] (P p) noexcept       { return v[(size_t) p]; }

    // Accepts a plain number or, for choice params, the choice string. Returns false if the
    // id is unknown or the value can't be interpreted.
    bool set (std::string_view id, float plain) noexcept;
    bool setChoice (std::string_view id, std::string_view choice) noexcept;
};

int choiceIndex (const ParamSpec&, std::string_view choice) noexcept;   // -1 if not found

} // namespace libero
