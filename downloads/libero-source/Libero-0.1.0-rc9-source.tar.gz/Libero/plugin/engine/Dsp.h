#pragma once

// Small realtime DSP building blocks. Header-only, no allocation outside prepare().

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace libero::dsp
{

constexpr float kPi    = 3.14159265358979f;
constexpr float kTwoPi = 6.28318530717959f;

inline float dbToGain (float db) noexcept         { return db <= -59.9f ? 0.0f : std::pow (10.0f, db * 0.05f); }
inline float clampf (float x, float a, float b) noexcept { return std::min (b, std::max (a, x)); }
inline float lerp (float a, float b, float t) noexcept   { return a + (b - a) * t; }

// Pade-style tanh, accurate to ~1e-3 in [-3, 3], exact saturation beyond.
inline float fastTanh (float x) noexcept
{
    if (x > 3.0f)  return 1.0f;
    if (x < -3.0f) return -1.0f;
    const auto x2 = x * x;
    return x * (27.0f + x2) / (27.0f + 9.0f * x2);
}

inline float sanitize (float x) noexcept
{
    return std::isfinite (x) ? x : 0.0f;
}

// Coefficient of a one-pole smoother reaching ~63% in timeMs.
inline float onePoleCoeff (float timeMs, float sampleRate) noexcept
{
    if (timeMs <= 0.0f)
        return 1.0f;

    return 1.0f - std::exp (-1.0f / (timeMs * 0.001f * sampleRate));
}

// Coefficient of a one-pole lowpass with the given -3 dB frequency.
inline float lowpassCoeff (float hz, float sampleRate) noexcept
{
    hz = clampf (hz, 1.0f, 0.49f * sampleRate);
    return 1.0f - std::exp (-kTwoPi * hz / sampleRate);
}

// Four-point, third-order Hermite interpolation. x0 is the sample before the frac position.
inline float hermite (float xm1, float x0, float x1, float x2, float t) noexcept
{
    const auto c = (x1 - xm1) * 0.5f;
    const auto v = x0 - x1;
    const auto w = c + v;
    const auto a = w + v + (x2 - x0) * 0.5f;
    const auto b = w + a;
    return ((a * t - b) * t + c) * t + x0;
}

//==============================================================================
struct Rng
{
    uint32_t state = 0x9e3779b9u;

    explicit Rng (uint32_t seed = 0x9e3779b9u) noexcept { reseed (seed); }

    void reseed (uint32_t seed) noexcept { state = seed ? seed : 0x9e3779b9u; }

    uint32_t nextU32() noexcept
    {
        // xorshift32
        auto x = state;
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        return state = x;
    }

    float uniform() noexcept   { return (float) (nextU32() >> 8) * (1.0f / 16777216.0f); }   // [0, 1)
    float bipolar() noexcept   { return uniform() * 2.0f - 1.0f; }                           // [-1, 1)
};

//==============================================================================
struct Smoother
{
    float current = 0.0f, target = 0.0f, coeff = 1.0f;

    void setTimeMs (float ms, float sampleRate) noexcept { coeff = onePoleCoeff (ms, sampleRate); }
    void reset (float v) noexcept                        { current = target = v; }
    float next() noexcept                                { current += coeff * (target - current); return current; }

    // Advance n samples at once (control-rate use).
    float advance (int n) noexcept
    {
        const auto k = 1.0f - std::pow (1.0f - coeff, (float) n);
        current += k * (target - current);

        if (std::abs (target - current) < 1e-7f)
            current = target;

        return current;
    }
};

//==============================================================================
// Topology-preserving-transform state variable filter (Zavalishin). All outputs per tick.
struct SVF
{
    float g = 0.0f, k = 1.0f, a1 = 1.0f, a2 = 0.0f, a3 = 0.0f;
    float ic1 = 0.0f, ic2 = 0.0f;
    float lp = 0.0f, bp = 0.0f, hp = 0.0f;

    void setup (float hz, float q, float sampleRate) noexcept
    {
        hz = clampf (hz, 5.0f, 0.47f * sampleRate);
        g = std::tan (kPi * hz / sampleRate);
        k = 1.0f / std::max (0.05f, q);
        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;
    }

    void reset() noexcept { ic1 = ic2 = lp = bp = hp = 0.0f; }

    void tick (float x) noexcept
    {
        const auto v3 = x - ic2;
        const auto v1 = a1 * ic1 + a2 * v3;
        const auto v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.0f * v1 - ic1;
        ic2 = 2.0f * v2 - ic2;
        lp = v2;
        bp = v1;
        hp = x - k * v1 - v2;
    }
};

//==============================================================================
struct OnePoleLP
{
    float a = 1.0f, z = 0.0f;
    void setHz (float hz, float sampleRate) noexcept { a = lowpassCoeff (hz, sampleRate); }
    float tick (float x) noexcept                     { z += a * (x - z); return z; }
    void reset() noexcept                             { z = 0.0f; }
};

struct DCBlocker
{
    float r = 0.995f, x1 = 0.0f, y1 = 0.0f;
    void setup (float sampleRate, float hz = 10.0f) noexcept { r = 1.0f - kTwoPi * hz / sampleRate; }
    float tick (float x) noexcept          { const auto y = x - x1 + r * y1; x1 = x; y1 = y; return y; }
    void reset() noexcept                  { x1 = y1 = 0.0f; }
};

//==============================================================================
// Power-of-two circular delay line with fractional reads.
struct DelayLine
{
    std::vector<float> buf;
    uint32_t mask = 0, w = 0;

    void allocate (int maxDelaySamples)
    {
        uint32_t size = 16;
        while ((int) size < maxDelaySamples + 8)
            size <<= 1;

        buf.assign (size, 0.0f);
        mask = size - 1;
        w = 0;
    }

    void reset() noexcept { std::fill (buf.begin(), buf.end(), 0.0f); w = 0; }
    int capacity() const noexcept { return (int) mask - 4; }

    void push (float x) noexcept { buf[w] = x; w = (w + 1) & mask; }

    // Delay in samples measured from the most recently pushed sample (delay 0 = last push).
    float at (int d) const noexcept { return buf[(w - 1 - (uint32_t) d) & mask]; }

    float readLinear (float d) const noexcept
    {
        d = clampf (d, 0.0f, (float) capacity());
        const auto i = (int) d;
        const auto f = d - (float) i;
        const auto a = at (i), b = at (i + 1);
        return a + f * (b - a);
    }

    float readHermite (float d) const noexcept
    {
        d = clampf (d, 1.0f, (float) capacity() - 2.0f);
        const auto i = (int) d;
        const auto f = d - (float) i;
        return hermite (at (i - 1), at (i), at (i + 1), at (i + 2), f);
    }
};

// Schroeder allpass on its own delay line.
struct Allpass
{
    DelayLine line;
    float g = 0.5f;

    void allocate (int maxDelay) { line.allocate (maxDelay); }
    void reset() noexcept        { line.reset(); }

    float tick (float x, float delay) noexcept
    {
        const auto d = line.readLinear (delay - 1.0f);
        const auto v = x + g * d;
        line.push (v);
        return d - g * v;
    }

    float tickInt (float x, int delay) noexcept
    {
        const auto d = line.at (delay - 1);
        const auto v = x + g * d;
        line.push (v);
        return d - g * v;
    }
};

} // namespace libero::dsp
