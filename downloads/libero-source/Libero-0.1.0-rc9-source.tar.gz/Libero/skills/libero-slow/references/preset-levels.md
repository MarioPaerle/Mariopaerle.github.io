# Preset output levels

The 4 October 2026 audit changed only preset master defaults: 112 working sounds
and 56 of the 75 public programmes. The sample audio stayed byte-identical. This
addressed quiet output; it was not a new listening evaluation of their timbres.

Measure through the native renderer with the preset's own defaults. For a
pitched sound, hold a playable recorded root for six seconds at velocities 100
and 127. Record the strongest 400 ms RMS window after the attack, attack RMS
separately, and the complete event peak. A whole-file average includes silence
and release tails and can misclassify an otherwise strong preset. Slow pads
need a measurement window after their amp attack has completed.

Use actual mapped drum roots for percussion. An empty BODY mapping often means
an oscillator-only synth; it does not establish that a sound is a one-shot.
Render those synths as sustained sounds in their intended register. Distinguish
physical decay, low sustained energy and genuinely weak output before changing
anything.

Check velocity-127 representative chords and the lowest/highest recorded roots
of each authored articulation. Root names alone are insufficient: shared tags
such as `sub37` can describe a synth model rather than a bass role. The public
programme can have different defaults from its working-library counterpart;
measure the actual distributed build whenever those differ.

The audit used a conservative −6 dBFS peak guard for the tested notes/chords,
an additive gain cap of 12 dB, and the existing master maximum of +6 dB. These
are starting constraints for a measured correction, not a loudness guarantee
for every possible performance. Retain natural crest factors and velocity
response. If a quiet body shares a preset with an already loud articulation,
retain the master level and report the limitation.

When a trial render already includes a proposed boost, compute the allowable
boost as `tested_gain + (peak_guard − measured_trial_peak)`. Subtracting the
trial peak from the guard without restoring the tested gain counts the boost
twice. If the trial engages the output ceiling, render again at the reduced
level instead of extrapolating through the nonlinear ceiling. Round the final
master downward to the chosen precision so rounding cannot consume headroom.

Apply the approved master to both `sound.py` defaults and `manifest.params`.
`defaults()` is excluded from the compiler's audio-recipe hash; a level change
needs no rewritten source samples or compiled zone audio. Back up the original
metadata and compare audio hashes before and after. The reviewed-plan consumer
is `scripts/calibrate_levels.py`; dry-run it before `--apply`.

For example, a quiet Mog programme allowed roughly +12 dB while keeping its
absolute master below +6 dB. String Harmonics had a loud lower recorded root,
so its proposed boost was excluded despite a quiet central note. Those outcomes
require different decisions even though both central-note measurements were low.

Version updated banks so existing users can import the correction. Whole-bank
updates replace local bank edits; preserve personal sounds with Save as first.
Reload preserves live parameter changes. Selecting the preset again, or Reset
after its updated manifest is loaded, applies the new defaults. Saved DAW
projects retain their stored parameters.
