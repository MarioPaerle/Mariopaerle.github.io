"""Pictures and numbers about a sound, made to be read by a designer (human or model).

`spectrogram`, `waveform` and `compare` return PNG bytes in the Libero palette;
`features` returns a dict and `format_features` a compact text summary.
"""

from __future__ import annotations

import io
import math

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402
from scipy import signal  # noqa: E402

from . import dsp  # noqa: E402
from .audio import Audio  # noqa: E402

# ---------------------------------------------------------------- palette

GROUND = "#f3eee3"   # warm ivory / marble
GROUND_2 = "#e9e2d3"
INK = "#1d1a24"
INK_SOFT = "#5a5563"
INK_FAINT = "#a39c90"
GOLD = "#b08a3a"
TWILIGHT = LinearSegmentedColormap.from_list(
    "libero_twilight",
    ["#14121c", "#1d2b3f", "#1f5561", "#3f8a86", "#a4708d", "#d9899a", "#f4c9b8", "#fbf4e8"],
)
SERIF = ["Iowan Old Style", "Hoefler Text", "Baskerville", "Georgia", "DejaVu Serif"]
MONO = ["Menlo", "DejaVu Sans Mono"]


def _style():
    plt.rcParams.update({
        "figure.facecolor": GROUND,
        "axes.facecolor": GROUND,
        "savefig.facecolor": GROUND,
        "axes.edgecolor": INK_FAINT,
        "axes.labelcolor": INK_SOFT,
        "xtick.color": INK_SOFT,
        "ytick.color": INK_SOFT,
        "text.color": INK,
        "font.family": "serif",
        "font.serif": SERIF,
        "font.size": 9,
        "axes.titlesize": 12,
        "axes.titleweight": "normal",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 3,
        "ytick.major.size": 3,
    })


def _png(fig, dpi: int = 100) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight", pad_inches=0.18)
    plt.close(fig)
    return buf.getvalue()


def _title(ax, title: str, sub: str = ""):
    ax.set_title(title, loc="left", fontsize=12.5, color=INK, pad=6)
    if sub:
        ax.text(1.0, 1.02, sub, transform=ax.transAxes, ha="right", va="bottom", fontsize=8.5,
                color=INK_SOFT, family=MONO)


def _segment(audio: Audio, t0, t1) -> tuple[Audio, float, float]:
    t0 = 0.0 if t0 is None else max(0.0, float(t0))
    t1 = audio.duration if t1 is None else min(audio.duration, float(t1))
    if t1 <= t0:
        t1 = min(audio.duration, t0 + 0.05)
    return audio.trim(t0, t1), t0, t1


# ---------------------------------------------------------------- spectrogram

def _stft_db(audio: Audio, t0: float, t1: float, fmin: float):
    """Power STFT of [t0, t1] computed with real audio as context on both sides, so the
    edges of a zoomed view show the sound and not the analysis window. Times are absolute."""
    sr = audio.sr
    seconds = t1 - t0
    # frequency resolution good enough for fmin, time resolution for short windows
    n_fft = 1 << int(np.clip(math.ceil(math.log2(sr / max(fmin, 10) * 2.5)), 9, 14))
    if seconds < 0.25:
        n_fft = min(n_fft, 2048 if fmin < 150 else 512)
    elif seconds < 1.0:
        n_fft = min(n_fft, 4096)
    n_seg = int(seconds * sr)
    hop = max(16, min(n_fft // 4, n_seg // 700 or 16))
    half = n_fft // 2
    a = int(round(t0 * sr)) - half
    b = int(round(t1 * sr)) + half
    x = dsp.mono(audio.data.astype(np.float64))
    seg = x[max(0, a): min(len(x), b)]
    seg = np.pad(seg, (max(0, -a), max(0, b - len(x))))  # silence only where the audio really ends
    # Blackman-Harris: -92 dB sidelobes, so a 90 dB picture shows the sound, not the window
    f, t, Z = signal.stft(seg, sr, window="blackmanharris", nperseg=n_fft, noverlap=n_fft - hop, boundary=None,
                          padded=False)
    P = np.abs(Z) ** 2
    return f, t + a / sr, P


def _draw_spec(ax, f, t, P, ref, db_range, fmin, fmax, log_freq, t_offset):
    S = 10 * np.log10(np.maximum(P, 1e-20) / ref)
    S = np.clip(S, -db_range, 0)
    sel = (f >= (fmin if log_freq else 0)) & (f <= fmax)
    im = ax.pcolormesh(t + t_offset, f[sel], S[sel], cmap=TWILIGHT, vmin=-db_range, vmax=0, shading="auto",
                       rasterized=True)
    if log_freq:
        ax.set_yscale("log")
    ax.set_ylim(max(fmin, f[1] if len(f) > 1 else fmin) if log_freq else 0, fmax)
    ax.set_facecolor(TWILIGHT(0.0))
    ticks = [f_ for f_ in (31.25, 62.5, 125, 250, 500, 1000, 2000, 4000, 8000, 16000) if fmin <= f_ <= fmax]
    if log_freq and ticks:
        ax.set_yticks(ticks)
        ax.set_yticklabels([f"{v/1000:g}k" if v >= 1000 else f"{v:g}" for v in ticks])
        ax.minorticks_off()
        # note names at every C on the right edge
        for octave in range(0, 10):
            fc = dsp.midi_to_freq(12 * (octave + 1))
            if fmin <= fc <= fmax:
                ax.axhline(fc, color="#fbf4e8", lw=0.3, alpha=0.18)
                ax.text(1.005, fc, f"C{octave}", transform=ax.get_yaxis_transform(), fontsize=7, color=INK_FAINT,
                        va="center", ha="left", family=MONO)
    ax.set_ylabel("Hz")
    return im


def spectrogram(audio: Audio, t0: float | None = None, t1: float | None = None, fmin: float = 30.0,
                fmax: float | None = None, log_freq: bool = True, db_range: float = 90.0,
                title: str = "Spettrogramma", small: bool = False) -> bytes:
    """Spectrogram of [t0, t1] as PNG bytes (log-frequency, dB relative to the loudest bin),
    with the RMS envelope in gold above it."""
    _style()
    seg, t0, t1 = _segment(audio, t0, t1)
    fmax = min(fmax or audio.sr / 2, audio.sr / 2)
    x = dsp.mono(seg.data.astype(np.float64))
    if len(x) < 64:
        x = np.pad(x, (0, 64 - len(x)))
    f, t, P = _stft_db(audio, t0, t1, fmin)
    ref = P.max() if P.max() > 0 else 1.0
    size = (6.4, 3.2) if small else (10, 4.8)
    fig = plt.figure(figsize=size)
    gs = fig.add_gridspec(2, 1, height_ratios=[1, 6], hspace=0.05)
    ax_e = fig.add_subplot(gs[0])
    ax = fig.add_subplot(gs[1], sharex=ax_e)
    te, e = dsp.rms_envelope(x, audio.sr, 0.01)
    edb = 20 * np.log10(np.maximum(e, 1e-6))
    ax_e.fill_between(te + t0, -80, np.maximum(edb, -80), color=GOLD, alpha=0.25, lw=0)
    ax_e.plot(te + t0, np.maximum(edb, -80), color=GOLD, lw=0.9)
    ax_e.set_ylim(max(-80, edb.max(initial=-80) - 60), max(edb.max(initial=-80), -79) + 3)
    ax_e.set_yticks([])
    ax_e.tick_params(labelbottom=False, bottom=False)
    for s in ("left", "bottom"):
        ax_e.spines[s].set_visible(False)
    sub = f"{t0:.2f}–{t1:.2f} s · peak {seg.peak_db:.1f} dBFS · rms {seg.rms_db:.1f} dBFS · {db_range:.0f} dB range"
    _title(ax_e, title, sub if not small else f"{t0:.2f}–{t1:.2f} s · peak {seg.peak_db:.1f} dB")
    _draw_spec(ax, f, t, P, ref, db_range, fmin, fmax, log_freq, 0.0)
    ax.set_xlim(t0, t1)
    ax.set_xlabel("s")
    return _png(fig, 90 if small else 100)


def compare(a: Audio, b: Audio, name_a: str = "A", name_b: str = "B", t0: float | None = None,
            t1: float | None = None, fmin: float = 30.0, fmax: float | None = None, db_range: float = 90.0) -> bytes:
    """Two spectrograms stacked on the same time axis and the same dB reference."""
    _style()
    t1 = t1 if t1 is not None else max(a.duration, b.duration)
    fmax = min(fmax or min(a.sr, b.sr) / 2, min(a.sr, b.sr) / 2)
    fig, axes = plt.subplots(2, 1, figsize=(10, 7.2), sharex=True, gridspec_kw={"hspace": 0.28})
    specs = []
    for au in (a, b):
        seg, s0, s1 = _segment(au, t0, t1)
        specs.append((_stft_db(au, s0, s1, fmin), s0, seg))
    ref = max(s[0][2].max() for s in specs) or 1.0
    for ax, ((f, t, P), s0, seg), name in zip(axes, specs, (name_a, name_b)):
        _draw_spec(ax, f, t, P, ref, db_range, fmin, fmax, True, 0.0)
        _title(ax, name, f"peak {seg.peak_db:.1f} dBFS · rms {seg.rms_db:.1f} dBFS")
    axes[1].set_xlim(t0 or 0.0, t1)
    axes[1].set_xlabel("s")
    return _png(fig)


# ---------------------------------------------------------------- waveform

def waveform(audio: Audio, t0: float | None = None, t1: float | None = None, title: str = "Forma d'onda",
             small: bool = False) -> bytes:
    """Waveform of [t0, t1]: min/max body in ink with the 10 ms RMS envelope in gold;
    zoomed below ~2500 samples it draws the individual samples."""
    _style()
    seg, t0, t1 = _segment(audio, t0, t1)
    chans = [seg.data] if seg.channels == 1 else [seg.data[:, 0], seg.data[:, 1]]
    labels = ["mono"] if seg.channels == 1 else ["L", "R"]
    size = (6.4, 2.6) if small else (10, 2.6 + 1.6 * len(chans))
    fig, axes = plt.subplots(len(chans), 1, figsize=size, sharex=True, squeeze=False,
                             gridspec_kw={"hspace": 0.12})
    n = seg.n
    tt = t0 + np.arange(n) / audio.sr
    lim = max(1e-4, float(np.abs(seg.data).max(initial=0))) * 1.08
    for i, (ax, x, lab) in enumerate(zip(axes[:, 0], chans, labels)):
        x = x.astype(np.float64)
        ax.axhline(0, color=INK_FAINT, lw=0.5)
        if n <= 2500:
            ax.plot(tt, x, color=INK, lw=0.8)
            if n <= 400:
                ax.plot(tt, x, "o", ms=2.2, color=GOLD)
        else:
            cols = 1400
            per = int(math.ceil(n / cols))
            m = n // per * per
            blk = x[:m].reshape(-1, per)
            tb = tt[:m].reshape(-1, per)[:, 0]
            ax.fill_between(tb, blk.min(axis=1), blk.max(axis=1), color=INK, lw=0, alpha=0.85)
            te, e = dsp.rms_envelope(x, audio.sr, 0.01)
            ax.plot(te + t0, e, color=GOLD, lw=1.0)
            ax.plot(te + t0, -e, color=GOLD, lw=1.0)
        ax.set_ylim(-lim, lim)
        ax.set_ylabel(lab)
        ax.spines["bottom"].set_visible(i == len(chans) - 1)
    sub = f"{t0:.4f}–{t1:.4f} s · {n} samples · peak {seg.peak_db:.1f} dBFS"
    _title(axes[0, 0], title, sub)
    axes[-1, 0].set_xlim(t0, t1)
    axes[-1, 0].set_xlabel("s")
    return _png(fig, 90 if small else 100)


# ---------------------------------------------------------------- features

def features(audio: Audio) -> dict:
    """Numbers that describe a sound; see `format_features` for the compact text form."""
    sr = audio.sr
    x = audio.data.astype(np.float64)
    m = dsp.mono(x)
    n = len(m)
    out: dict = {
        "duration_s": round(audio.duration, 3),
        "sample_rate": sr,
        "channels": audio.channels,
        "peak_db": round(audio.peak_db, 2),
        "rms_db": round(audio.rms_db, 2),
    }
    if n < 32 or np.abs(m).max(initial=0) < 1e-7:
        out["silent"] = True
        return out
    out["loudness_lufs"] = round(dsp.integrated_loudness(x, sr), 1)
    out["dc_offset_db"] = round(dsp.db(abs(float(np.mean(m)))), 1)
    clip = int(np.sum(np.abs(x) >= 0.999))
    out["clipped_samples"] = clip

    # envelope: attack and decay
    te, e = dsp.rms_envelope(m, sr, 0.005)
    ipk = int(np.argmax(e))
    pk = e[ipk]
    above10 = np.nonzero(e >= 0.1 * pk)[0]
    above90 = np.nonzero(e >= 0.9 * pk)[0]
    t_att_end = float(te[above90[0]]) if len(above90) else 0.0
    if len(above10) and len(above90):
        out["attack_ms"] = round(max(0.0, (t_att_end - te[above10[0]]) * 1000), 1)
    out["peak_at_s"] = round(float(te[ipk]), 3)
    tail_rms = float(np.sqrt(np.mean(m[int(0.9 * n):] ** 2))) if n > 20 else 0.0
    if tail_rms > pk * 10 ** (-12 / 20):
        out["t60_s"] = "sustained"
    else:
        out["t60_s"] = _t60(m[int(te[ipk] * sr):], sr)
    out["onsets_s"] = dsp.onset_times(m, sr, 8)
    # "body" = after the attack: where pitch and spectrum are measured
    b0 = min(n - 1, int(min(t_att_end + 0.05, 0.3 * audio.duration) * sr))

    times, f0, aper, rms = dsp.yin(m, sr)
    voiced = np.isfinite(f0) & (aper < 0.3)
    out["voiced_fraction"] = round(float(voiced.mean()), 2)
    out["noisiness"] = round(float(np.median(aper[rms > rms.max() * 0.01])) if (rms > 0).any() else 1.0, 2)
    f0_med = float("nan")
    if voiced.sum() >= 3:
        loud = voiced & (rms > np.percentile(rms[voiced], 25) * 0.5)
        f0_med = float(np.median(f0[loud if loud.sum() else voiced]))
        seg = m[b0:]
        if len(seg) > sr // 8:
            f0_med = dsp.refine_f0(seg[: 4 * sr], sr, f0_med)
        c = 1200 * np.log2(f0[voiced] / f0_med)
        out["f0_hz"] = round(f0_med, 2)
        out["f0_note"] = dsp.describe_freq(f0_med)
        out["f0_spread_cents"] = round(float(np.percentile(c, 75) - np.percentile(c, 25)), 1)
        q = max(1, voiced.sum() // 4)
        out["f0_drift_cents"] = round(float(np.median(c[-q:]) - np.median(c[:q])), 1)

    # spectrum over the body (after the attack), Welch
    body = m[b0: b0 + 6 * sr] if n - b0 > sr // 10 else m
    nper = min(len(body), 8192)
    fw, pw = signal.welch(body, sr, nperseg=nper, window="hann")
    tot = pw.sum() + 1e-30
    out["centroid_hz"] = round(float((fw * pw).sum() / tot), 1)
    cum = np.cumsum(pw) / tot
    out["rolloff85_hz"] = round(float(fw[np.searchsorted(cum, 0.85)]), 1)
    band = (fw > 40) & (fw < 16000)
    pb = pw[band] + 1e-30
    out["flatness"] = round(float(np.exp(np.mean(np.log(pb))) / np.mean(pb)), 3)
    out["energy_above_16k_db"] = round(10 * math.log10(pw[fw >= 16000].sum() / tot + 1e-20), 1)
    out["energy_above_18k_db"] = round(10 * math.log10(pw[fw >= 18000].sum() / tot + 1e-20), 1)
    out["energy_below_40hz_db"] = round(10 * math.log10(pw[fw < 40].sum() / tot + 1e-20), 1)

    # partials from a long FFT of the body
    parts = _partials(body[: 3 * sr], sr, 12)
    ref = f0_med if np.isfinite(f0_med) else (parts[0][0] if parts else float("nan"))
    if parts and np.isfinite(ref):
        lowest = min(p[0] for p in parts)
        if not np.isfinite(f0_med):
            ref = lowest
        out["partials"] = [{"hz": round(fp, 1), "ratio": round(fp / ref, 3), "db": round(a, 1)} for fp, a in parts]
        rs = np.array([fp / ref for fp, _ in parts])
        amps = np.array([10 ** (a / 20) for _, a in parts])
        ok = rs >= 0.9
        if ok.any():
            dev = np.abs(1200 * np.log2(rs[ok] / np.maximum(1, np.round(rs[ok]))))
            out["inharmonicity_cents"] = round(float(np.average(dev, weights=amps[ok])), 1)

    if audio.channels == 2:
        L, R = x[:, 0], x[:, 1]
        denom = math.sqrt(float(np.dot(L, L) * np.dot(R, R))) + 1e-30
        out["stereo_correlation"] = round(float(np.dot(L, R) / denom), 3)
        mid, side = (L + R) / 2, (L - R) / 2
        out["side_to_mid_db"] = round(dsp.db(math.sqrt(np.mean(side**2))) - dsp.db(math.sqrt(np.mean(mid**2))), 1)
    return out


def _t60(x: np.ndarray, sr: int):
    """Decay time from Schroeder backward integration (T20 × 3, or EDT when short)."""
    if len(x) < sr // 20:
        return None
    e = x.astype(np.float64) ** 2
    sch = np.cumsum(e[::-1])[::-1]
    if sch[0] <= 0:
        return None
    L = 10 * np.log10(np.maximum(sch / sch[0], 1e-30))
    t = np.arange(len(L)) / sr

    def fit(hi, lo):
        sel = (L <= hi) & (L >= lo)
        if sel.sum() < sr // 100:
            return None
        slope = np.polyfit(t[sel], L[sel], 1)[0]
        return -60.0 / slope if slope < 0 else None

    # the tail of a finite file makes Schroeder curves dive; only trust up to -25 dB
    v = fit(-5, -25) if L.min() < -30 else None
    if v is None:
        v = fit(-1, -11) if L.min() < -15 else None
        if v is None:
            return "sustained"
        return f"~{v:.2f} (EDT)"
    return round(float(v), 2)


def _partials(x: np.ndarray, sr: int, k: int) -> list[tuple[float, float]]:
    if len(x) < 1024:
        return []
    w = np.hanning(len(x))
    nfft = 1 << int(math.ceil(math.log2(len(x) * 2)))
    S = np.abs(np.fft.rfft(x * w, nfft))
    f = np.fft.rfftfreq(nfft, 1 / sr)
    Sdb = 20 * np.log10(S + 1e-20)
    Sdb -= Sdb.max()
    df = f[1]
    dist = max(1, int(15 / df))
    peaks, props = signal.find_peaks(Sdb, height=-70, prominence=12, distance=dist)
    peaks = peaks[f[peaks] > 20]
    if len(peaks) == 0:
        return []
    top = peaks[np.argsort(Sdb[peaks])[::-1][:k]]
    out = []
    for p in sorted(top):
        if 1 <= p < len(S) - 1:
            a, b, c = Sdb[p - 1], Sdb[p], Sdb[p + 1]
            den = a - 2 * b + c
            sh = 0.5 * (a - c) / den if den != 0 else 0.0
        else:
            sh = 0.0
        out.append((float((p + sh) * df), float(Sdb[p])))
    return out


def format_features(ft: dict, name: str = "") -> str:
    """Compact multi-line text of `features()` for a model to read."""
    if ft.get("silent"):
        return f"{name}: silent ({ft['duration_s']} s)"
    lines = []
    head = f"{name}: " if name else ""
    ch = "stereo" if ft["channels"] == 2 else "mono"
    lines.append(f"{head}{ft['duration_s']} s {ch} {ft['sample_rate']} Hz | peak {ft['peak_db']} dBFS, "
                 f"rms {ft['rms_db']} dBFS, ~{ft.get('loudness_lufs')} LUFS")
    t60 = ft.get("t60_s")
    t60 = f"{t60} s" if isinstance(t60, (int, float)) else str(t60)
    env = f"attack {ft.get('attack_ms', '-')} ms (peak at {ft.get('peak_at_s')} s), T60 {t60}"
    if ft.get("onsets_s"):
        env += f", onsets {ft['onsets_s']}"
    lines.append("envelope: " + env)
    if "f0_hz" in ft:
        lines.append(f"pitch: {ft['f0_hz']} Hz = {ft['f0_note']} | voiced {ft['voiced_fraction']:.0%}, "
                     f"spread {ft['f0_spread_cents']}c, drift {ft['f0_drift_cents']:+}c")
    else:
        lines.append(f"pitch: none detected (voiced {ft.get('voiced_fraction', 0):.0%})")
    lines.append(f"spectrum: centroid {ft['centroid_hz']:.0f} Hz, rolloff85 {ft['rolloff85_hz']:.0f} Hz, "
                 f"flatness {ft['flatness']}, noisiness {ft['noisiness']}, >16k {ft['energy_above_16k_db']} dB, "
                 f"<40Hz {ft['energy_below_40hz_db']} dB")
    if ft.get("partials"):
        ps = " ".join(f"{p['ratio']:g}×({p['db']:.0f})" for p in ft["partials"])
        inh = ft.get("inharmonicity_cents")
        lines.append(f"partials (ratio×(dB)): {ps}" + (f" | inharmonicity {inh}c" if inh is not None else ""))
    extra = []
    if "stereo_correlation" in ft:
        extra.append(f"stereo corr {ft['stereo_correlation']}, side/mid {ft['side_to_mid_db']} dB")
    extra.append(f"DC {ft['dc_offset_db']} dB")
    if ft.get("clipped_samples"):
        extra.append(f"CLIPPED {ft['clipped_samples']} samples")
    lines.append("; ".join(extra))
    return "\n".join(lines)
