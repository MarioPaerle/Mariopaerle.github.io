"""Bringing audio into a sound's samples/: local files, URLs, Freesound."""

from __future__ import annotations

import datetime as _dt
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import httpx
import soundfile as sf

from . import library
from .audio import Audio

MAX_BYTES = 200 * 1024 * 1024
OK_TYPES = ("audio/", "application/octet-stream", "binary/octet-stream", "application/ogg", "video/ogg")
FREESOUND = "https://freesound.org/apiv2"
USER_AGENT = "libero/0.1 (+sound design library)"


class DownloadError(Exception):
    pass


def to_wav(src: Path, dst: Path) -> Audio:
    """Decode any readable format into a 32-bit float WAV at `dst`. Tries libsndfile,
    then macOS afconvert, then ffmpeg."""
    try:
        a = Audio.load(src)
        a.save(dst)
        return a
    except (RuntimeError, sf.LibsndfileError, ValueError):
        pass
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td) / "conv.wav"
        tools = []
        if shutil.which("afconvert"):
            tools.append(["afconvert", "-f", "WAVE", "-d", "LEF32", str(src), str(tmp)])
        if shutil.which("ffmpeg"):
            tools.append(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", str(src), "-c:a", "pcm_f32le",
                          str(tmp)])
        for cmd in tools:
            try:
                r = subprocess.run(cmd, capture_output=True, timeout=120)
            except subprocess.TimeoutExpired:
                continue
            if r.returncode == 0 and tmp.exists():
                a = Audio.load(tmp)
                a.save(dst)
                return a
    raise DownloadError(f"cannot decode {src.name} (no decoder for this format; install ffmpeg)")


def attribute(folder: Path, name: str, line: str):
    p = folder / "samples" / "ATTRIBUTION.md"
    head = "" if p.exists() else "# Sample sources and licences\n\n"
    stamp = _dt.date.today().isoformat()
    with open(p, "a") as f:
        f.write(f"{head}- `{name}` — {line} (added {stamp})\n")


def import_local(folder: Path, src: str | Path, name: str) -> tuple[Path, Audio]:
    sp = Path(src).expanduser()
    if not sp.is_file():
        raise DownloadError(f"{sp} is not a file")
    dst = library.out_sample_path(folder, name)
    a = to_wav(sp, dst)
    attribute(folder, dst.name, f"local file `{sp.name}`")
    return dst, a


def fetch_url(folder: Path, url: str, name: str, max_bytes: int = MAX_BYTES,
              attribution: str | None = None) -> tuple[Path, Audio]:
    u = urlparse(url)
    if u.scheme not in ("http", "https"):
        raise DownloadError("only http(s) URLs")
    dst = library.out_sample_path(folder, name)
    suffix = Path(u.path).suffix.lower() if Path(u.path).suffix.lower() in library.AUDIO_SUFFIXES else ".bin"
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td) / f"download{suffix}"
        with httpx.stream("GET", url, follow_redirects=True, timeout=60.0,
                          headers={"User-Agent": USER_AGENT}) as r:
            if r.status_code != 200:
                raise DownloadError(f"HTTP {r.status_code} for {url}")
            ctype = r.headers.get("content-type", "").split(";")[0].strip().lower()
            if ctype and not ctype.startswith(OK_TYPES):
                raise DownloadError(f"{url} is '{ctype}', not audio")
            clen = int(r.headers.get("content-length") or 0)
            if clen > max_bytes:
                raise DownloadError(f"file is {clen / 1e6:.0f} MB (limit {max_bytes / 1e6:.0f} MB)")
            got = 0
            with open(tmp, "wb") as f:
                for chunk in r.iter_bytes(1 << 16):
                    got += len(chunk)
                    if got > max_bytes:
                        raise DownloadError(f"download exceeded {max_bytes / 1e6:.0f} MB")
                    f.write(chunk)
        a = to_wav(tmp, dst)
    attribute(folder, dst.name, attribution or f"<{url}>")
    return dst, a


# ---------------------------------------------------------------- Freesound

def _api_key() -> str:
    key = os.environ.get("FREESOUND_API_KEY") or library.config().get("freesound_api_key")
    if not key:
        raise DownloadError(
            "no Freesound API key. Get one at https://freesound.org/apiv2/apply and either set "
            f"FREESOUND_API_KEY or add \"freesound_api_key\" to {library.home() / 'config.json'}")
    return key


def _fs_get(path: str, params: dict) -> dict:
    r = httpx.get(f"{FREESOUND}{path}", params=params, timeout=30.0,
                  headers={"Authorization": f"Token {_api_key()}", "User-Agent": USER_AGENT})
    if r.status_code == 401:
        raise DownloadError("Freesound rejected the API key (401)")
    if r.status_code != 200:
        raise DownloadError(f"Freesound HTTP {r.status_code}: {r.text[:200]}")
    return r.json()


def freesound_search(query: str, filters: str | None = None, page_size: int = 15, sort: str = "score") -> list[dict]:
    """Text search. `filters` uses Freesound filter syntax, e.g.
    'duration:[0.5 TO 6] license:"Creative Commons 0" samplerate:48000'."""
    params = {"query": query, "page_size": max(1, min(page_size, 50)), "sort": sort,
              "fields": "id,name,duration,license,username,tags,avg_rating,num_downloads,samplerate,channels,url"}
    if filters:
        params["filter"] = filters
    data = _fs_get("/search/text/", params)
    out = []
    for s in data.get("results", []):
        out.append({
            "id": s["id"], "name": s.get("name"), "seconds": round(float(s.get("duration") or 0), 2),
            "license": _short_license(s.get("license", "")), "by": s.get("username"),
            "tags": (s.get("tags") or [])[:8], "rating": round(float(s.get("avg_rating") or 0), 1),
            "downloads": s.get("num_downloads"), "sr": s.get("samplerate"), "channels": s.get("channels"),
            "url": s.get("url"),
        })
    return out


def _short_license(url: str) -> str:
    u = url.lower()
    for key, name in (("publicdomain/zero", "CC0"), ("by-nc", "CC BY-NC"), ("by/", "CC BY"),
                      ("sampling+", "Sampling+")):
        if key in u:
            return name
    return url or "unknown"


def freesound_download(folder: Path, sound_id: int, name: str) -> tuple[Path, Audio, dict]:
    """Download a Freesound sound into samples/<name>.wav.

    With an API token Freesound serves the high-quality preview (OGG ~192 kbps,
    44.1 kHz); full-resolution originals require an OAuth2 login, which this
    library does not do. License and attribution go into samples/ATTRIBUTION.md."""
    meta = _fs_get(f"/sounds/{int(sound_id)}/", {"fields": "id,name,username,license,url,previews,duration"})
    previews = meta.get("previews") or {}
    url = previews.get("preview-hq-ogg") or previews.get("preview-hq-mp3") or previews.get("preview-lq-ogg")
    if not url:
        raise DownloadError(f"sound {sound_id} has no downloadable preview")
    lic = _short_license(meta.get("license", ""))
    credit = (f"Freesound #{meta['id']} \"{meta.get('name')}\" by {meta.get('username')}, {lic} "
              f"<{meta.get('url')}> (HQ preview)")
    dst, a = fetch_url(folder, url, name, attribution=credit)
    return dst, a, {"license": lic, "by": meta.get("username"), "title": meta.get("name"), "url": meta.get("url")}
