"""Waveguide strings: pluck, hammer (piano), bow, coupled unisons and sympathetic strings.

One engine drives everything. Each string is a bidirectional digital waveguide of velocity
waves with a rigid nut and a lossy, dispersive, fractional-delay bridge termination. The
excitation sits at a junction a fraction `position` of the length from the bridge:

    pluck    initial shape released from rest (finger = rounded, plectrum = sharp)
    hammer   nonlinear felt contact (Hunt-Crossley power law), two-way coupled to the string
    bow      friction curve with stick-slip, produces Helmholtz motion between F_min and F_max

Tuning is analytic: the loop's total phase delay at `freq` (integer delay lines + one-pole loss
+ dispersion allpasses + a fractional allpass) is solved to be exactly fs/freq. The lowest
partial therefore sits on `freq`; partial k sits at k*freq*sqrt((1+B k^2)/(1+B)).

Units: freq Hz, times seconds (T60 = time to decay 60 dB). `position` is a fraction of the
string length measured from the bridge.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy import optimize

from ..audio import DEFAULT_SR, Audio
from . import _common as cm
from ._kernels import string_kernel


# ------------------------------------------------------------------ loop design

@dataclass
class _Loop:
    Ln: int
    Lb: int
    extra: int
    lp_g: float
    lp_p: float
    ap_a: float
    disp_a: float
    disp_M: int
    freq: float


def design_dispersion(freq: float, B: float, sr: int, budget: float) -> tuple[int, float]:
    """Cascade of M identical first-order allpass sections (coefficient a < 0) whose phase
    delay reproduces the stretched partials f_k = k f sqrt((1+B k^2)/(1+B)).
    `budget` is the most delay (samples) the cascade may add at `freq`. Returns (M, a)."""
    if B <= 1e-9:
        return 0, 0.0
    kmax = int(min(40, 0.42 * sr / freq))
    ks = np.arange(1, max(kmax, 2) + 1)
    fk = freq * ks * np.sqrt((1 + B * ks**2) / (1 + B))
    keep = fk < 0.42 * sr
    fk, ks = fk[keep], ks[keep]
    if len(fk) < 2:
        return 0, 0.0
    target = ks * sr / fk  # required loop phase delay at each partial
    w = 1.0 / ks
    best = (np.inf, 0, 0.0)
    for M in (1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48):
        def cost(a, M=M):
            d0 = M * float(cm.allpass_phase_delay(a, freq, sr))
            if d0 > budget:
                return 1e9 + (d0 - budget)
            d = M * cm.allpass_phase_delay(a, fk, sr)
            err_s = (d - d[0]) - (target - target[0])
            cents = 1200 / math.log(2) * err_s / target
            return float(np.sum(w * cents**2))
        res = optimize.minimize_scalar(cost, bounds=(-0.98, -1e-6), method="bounded", options={"xatol": 1e-7})
        if res.fun < best[0] * 0.98:
            best = (float(res.fun), M, float(res.x))
    return best[1], best[2]


def design_loop(freq: float, sr: int, decay: float, decay_hf: float, B: float, position: float,
                min_half: int = 3) -> _Loop:
    """Loss, dispersion and delay lines for one string tuned to `freq`."""
    D = sr / freq
    period = 1.0 / freq
    g0 = cm.t60_to_trip_gain(decay, period)
    f_ref = min(10.0 * freq, 0.40 * sr)
    g1 = cm.t60_to_trip_gain(max(decay * decay_hf, 1e-3), period)
    lp_g, lp_p = cm.fit_onepole(freq, g0, f_ref, g1, sr) if f_ref > 1.5 * freq else (g0, 0.0)
    tau_l = cm.onepole_phase_delay(lp_g, lp_p, freq, sr)
    budget = max(0.0, D - tau_l - 2 * min_half - 2.0)
    M, a_d = design_dispersion(freq, B, sr, budget)
    tau_d = M * float(cm.allpass_phase_delay(a_d, freq, sr)) if M else 0.0
    R = D - tau_l - tau_d
    K = int(math.floor(R - 0.5))
    if K < 2 * min_half:
        raise ValueError(f"{freq:.0f} Hz is too high for this string model at {sr} Hz")
    Ls, extra = K // 2, K % 2
    a_f = cm.solve_allpass(R - K, freq, sr)
    Lb = int(np.clip(round(position * Ls), 1, Ls - 1))
    return _Loop(Ls - Lb, Lb, extra, lp_g, lp_p, a_f, a_d, M, freq)


def _pack(loops: list[_Loop]):
    lens = np.zeros((len(loops), 4), dtype=np.int64)
    for i, lp in enumerate(loops):
        lens[i] = (lp.Ln, lp.Lb, lp.Lb + lp.extra, lp.Ln)
    return lens, np.zeros((len(loops), 4, int(lens.max())))


def _pluck_init(loops: list[_Loop], buf, hardness: float, n_drv: int):
    for i in range(n_drv):
        lp = loops[i]
        Ls = lp.Ln + lp.Lb
        x = np.arange(Ls + 1, dtype=np.float64)
        xp = lp.Ln
        y = np.where(x <= xp, x / xp, (Ls - x) / (Ls - xp))
        width = (1.0 - hardness) ** 1.5 * 0.12 * Ls
        if width >= 1.0:
            k = int(width) | 1
            ker = np.hanning(k + 2)[1:-1]
            ker /= ker.sum()
            y = np.convolve(np.pad(y, k, mode="edge"), ker, mode="same")[k:-k]
            y = y - y[0] * (1 - x / Ls) - y[-1] * (x / Ls)
        dy = np.gradient(y)
        vR, vL = -0.5 * dy, 0.5 * dy
        Ln, Lb, e = lp.Ln, lp.Lb, lp.extra
        j = np.arange(Ln)
        buf[i, 0, :Ln] = vR[np.clip(Ln - 1 - j, 0, Ls)]
        j = np.arange(Lb)
        buf[i, 1, :Lb] = vR[np.clip(Ln + Lb - 1 - j, 0, Ls)]
        j = np.arange(Lb + e)
        buf[i, 2, : Lb + e] = vL[np.clip(Ln + j, 0, Ls)]
        j = np.arange(Ln)
        buf[i, 3, :Ln] = vL[np.clip(j, 0, Ls)]


def _comb_pickup(y: np.ndarray, pickup: float | None, freq: float, sr: int) -> np.ndarray:
    """A pickup `pickup` (fraction of the length from the bridge) sees the wave plus its
    reflection: a feed-forward comb y[n] - y[n - m] with m = pickup * period."""
    if pickup is None or pickup <= 0:
        return y
    m = pickup * sr / freq
    mi = int(m)
    fr = m - mi
    z = np.zeros_like(y)
    if mi + 1 < len(y):
        z[mi:] += (1 - fr) * y[: len(y) - mi]
        z[mi + 1:] += fr * y[: len(y) - mi - 1]
    return y - z


def _unison_freqs(freq: float, strings: int, detune_cents: float, rng) -> list[float]:
    """Symmetric spread of +-detune_cents with a small seeded jitter."""
    if strings == 1:
        return [freq]
    c = np.linspace(-1, 1, strings) * detune_cents + rng.uniform(-0.15, 0.15, strings) * detune_cents
    return [freq * 2 ** (ci / 1200.0) for ci in c]


def _bridge_coupling(n_total: int, bridge_t60: float | None, freq: float) -> float:
    """Common-mode leakage c = 2 rho/(1 + N rho); in-phase motion decays with T60 = bridge_t60."""
    if not bridge_t60 or bridge_t60 <= 0:
        return 0.0
    rho = 6.91 / (bridge_t60 * 2.0 * n_total * freq)
    return float(2.0 * rho / (1.0 + n_total * rho))


# ------------------------------------------------------------------ public renderers

def pluck(freq: float, dur: float = 3.0, *, velocity: float = 0.7, decay: float = 4.0, decay_hf: float = 0.25,
          inharmonicity: float = 0.0, position: float = 0.15, pickup: float | None = None, hardness: float = 0.6,
          strings: int = 1, detune_cents: float = 1.0, bridge_t60: float | None = None,
          sympathetic=(), sympathetic_t60: float = 6.0, sr: int = DEFAULT_SR, seed: int = 0,
          peak_db: float | None = -6.0) -> Audio:
    """Plucked string (guitar, harp, lute, banjo; hardness=1 for harpsichord-like).

    freq           fundamental, Hz (15 .. sr/6). Exactly in tune.
    velocity       0..1. Louder plucks are brighter (less rounding of the initial shape).
    decay          T60 of the fundamental, seconds. Nylon guitar 2-4, steel 3-6, harp 3-10.
    decay_hf       T60 of the 10th harmonic as a fraction of `decay` (0.03 dull .. 1 no extra
                   damping). Gut/nylon 0.1-0.25, steel 0.25-0.5, harp 0.3.
    inharmonicity  B in f_k = k f sqrt((1+B k^2)/(1+B)). Guitar 1e-5..1e-4, harp/dulcimer 1e-4..5e-4.
    position       pluck point, fraction of length from the bridge (0.05 bright/nasal .. 0.5 hollow).
    pickup         optional listening point (fraction from the bridge); None = bridge force.
    hardness       0 soft finger flesh (round shape) .. 1 plectrum/nail (sharp corner).
    strings        coupled unison strings (1-4) detuned by +-detune_cents; `bridge_t60` (seconds)
                   sets how fast the in-phase motion decays into the bridge: with 2-3 strings and
                   bridge_t60 ~ 0.3*decay you get the piano-like double decay and beating.
    sympathetic    iterable of frequencies (Hz) of undriven strings resting on the same bridge.
    Output is the bridge force; feed it to a body (`physics.body`). Normalised to `peak_db`.
    """
    return _render(freq, dur, "pluck", sr, seed, peak_db, decay=decay, decay_hf=decay_hf, B=inharmonicity,
                   position=position, pickup=pickup, hardness=hardness * (0.55 + 0.45 * velocity),
                   strings=strings, detune_cents=detune_cents, bridge_t60=bridge_t60,
                   sympathetic=sympathetic, sympathetic_t60=sympathetic_t60)


@dataclass
class Hammer:
    """Felt hammer, force F = K d^p (1 + alpha d'). mass kg (2-5 g), stiffness K N/m^p, exponent p (2-4),
    damping alpha s/m (Hunt-Crossley, 0..5), speed m/s (0.5 pp .. 5 ff), impedance = string sqrt(T mu) in
    kg/s (piano: 5 bass .. 0.5 treble). K and p go together: pick the force F0 you want at the 0.5 mm
    compression of a mezzo-forte blow (10-30 N) and set K = F0 / 0.0005^p. A larger p makes the felt
    harden with force, so loud notes get much brighter (mid piano: +9 dB of harmonics above the 6th from
    pp to ff; treble +25 dB)."""
    mass: float = 0.004
    stiffness: float = 5.8e9
    exponent: float = 2.6
    damping: float = 1.0
    speed: float = 2.5
    impedance: float = 1.6


def strike(freq: float, dur: float = 4.0, *, hammer: Hammer | None = None, velocity: float | None = 0.7,
           decay: float = 8.0, decay_hf: float = 0.2, inharmonicity: float = 3e-4, position: float = 0.125,
           pickup: float | None = None, strings: int = 3, detune_cents: float = 0.6,
           bridge_t60: float | None = None, sympathetic=(), sympathetic_t60: float = 10.0, sr: int = DEFAULT_SR,
           seed: int = 0, peak_db: float | None = -6.0) -> Audio:
    """Hammered string: nonlinear felt contact (Hunt-Crossley), solved implicitly each sample.

    velocity   0..1 -> hammer speed 0.5 + 4.5 v^1.5 m/s. Pass None to use `hammer.speed` as is.
    position   strike point, fraction of the length from the bridge (piano 1/8..1/9): partials k
               with sin(k pi position) ~ 0 are suppressed (7th, 9th).
    Other arguments as `pluck`. See `Hammer` for the felt parameters; `physics.presets.piano`
    chooses all of them from the MIDI note."""
    h = hammer or Hammer()
    if velocity is not None:
        h = Hammer(h.mass, h.stiffness, h.exponent, h.damping, 0.5 + 4.5 * float(velocity) ** 1.5, h.impedance)
    return _render(freq, dur, "hammer", sr, seed, peak_db, decay=decay, decay_hf=decay_hf, B=inharmonicity,
                   position=position, pickup=pickup, hammer=h, strings=strings, detune_cents=detune_cents,
                   bridge_t60=bridge_t60, sympathetic=sympathetic, sympathetic_t60=sympathetic_t60)


def schelleng(speed: float, position: float, freq: float) -> tuple[float, float]:
    """(k_min, k_max): bow force window, in velocity units (F_N / 2Z), inside which this model
    keeps Helmholtz motion. Calibrated on the solver (sawtooth force spectrum, strict periodicity):
    the ceiling scales as speed/position (Schelleng's F_max ~ v_b/beta) and falls slowly with pitch;
    the floor is ~0.18 of it (lighter and the string whistles or multiple-slips).
    `bow` maps pressure 0..1 logarithmically between them."""
    c_hi = float(np.clip(0.45 * (130.8 / freq) ** 0.4, 0.15, 0.6))
    k_max = c_hi * speed / max(position, 1e-3)
    return 0.18 * k_max, k_max


def bow(freq: float, dur: float = 3.0, *, speed=0.25, pressure=0.6, position: float = 0.1, decay: float = 2.0,
        decay_hf: float = 0.15, inharmonicity: float = 5e-5, mu_static: float = 0.8, mu_dynamic: float = 0.3,
        friction_slope: float = 0.1, noise: float = 0.25, sympathetic=(), sympathetic_t60: float = 4.0,
        autotune: bool = True, sr: int = DEFAULT_SR, seed: int = 0, peak_db: float | None = -6.0) -> Audio:
    """Bowed string with a stick-slip friction junction (Helmholtz motion).

    speed     bow speed m/s: scalar or array over time (see `performance.bow_stroke`).
              0.05 (pp, near the bridge) .. 0.6 (forte detache). Sets loudness and brightness.
    pressure  0..1 inside the playable window for this speed and position (Schelleng diagram):
              0 lightest that still speaks (whistly), 0.5 normal, 1 heaviest before it chokes
              (raucous). Scalar or array over time.
    position  bow-bridge distance / string length: 0.04 sul ponticello (bright) .. 0.15 sul tasto.
    decay     T60 of the free string, seconds, with decay_hf the HF damping of the loop: sets how
              bright the Helmholtz sawtooth stays. Cello 1.5-3, violin 1-2, decay_hf 0.1-0.3.
    noise     0..1 hair/rosin noise.
    autotune  measure the rendered pitch and correct the loop length (stick-slip flattens a few cents).
    mu_static/mu_dynamic/friction_slope: rosin friction curve (0.8-1.0, 0.2-0.4, 0.05-0.2 m/s).
    Output is the bridge force; put it through a body (`physics.body.cello()` etc.)."""
    n = int(round(dur * sr))
    rng = np.random.default_rng(seed)
    v_arr = cm.as_control(speed, n, "speed")
    p_arr = np.clip(cm.as_control(pressure, n, "pressure"), 0.0, 1.0)
    nz = cm.smooth_noise(n, sr, 600.0, rng)
    nz2 = cm.smooth_noise(n, sr, 40.0, rng)
    vb = v_arr * (1.0 + 0.04 * noise * nz2) + 0.012 * noise * nz * np.minimum(1.0, v_arr / 0.05)
    kmin, kmax = schelleng(1.0, position, freq)

    def run(f, cand):
        sc, bm = cand
        p = np.clip(p_arr * sc, 0.0, 1.0)
        kn = v_arr * np.exp(math.log(kmin) + (math.log(kmax) - math.log(kmin)) * p) * (1.0 + 0.05 * noise * nz2)
        return _render(f, dur, "bow", sr, seed, None, decay=decay, decay_hf=decay_hf, B=inharmonicity * bm,
                       position=position, bow_v=vb, bow_k=kn, mu_s=mu_static, mu_d=mu_dynamic, v0=friction_slope,
                       sympathetic=sympathetic, sympathetic_t60=sympathetic_t60, raw=True)

    cands = [(sc, bm) for bm in (1.0, 4.0, 0.25) for sc in (1.0, 0.8, 1.25, 0.65, 1.5, 0.5)]
    y = cm.locked(cands, run, freq, sr, autotune, accept=lambda y: cm.sawtooth_like(y, sr, freq))
    return cm.finish(y, sr, peak_db)


# ------------------------------------------------------------------ engine

def _render(freq, dur, kind, sr, seed, peak_db, *, decay, decay_hf, B, position, pickup=None, hardness=0.6,
            strings=1, detune_cents=1.0, bridge_t60=None, sympathetic=(), sympathetic_t60=6.0,
            hammer: Hammer | None = None, bow_v=None, bow_k=None, mu_s=0.8, mu_d=0.3, v0=0.1, raw=False):
    freq = cm.check_freq(freq, sr)
    if dur <= 0:
        raise ValueError("dur must be positive")
    strings = int(np.clip(strings, 1, 4))
    position = float(np.clip(position, 0.02, 0.5))
    rng = np.random.default_rng(seed)
    n = int(round(dur * sr))
    loops = [design_loop(f, sr, decay, decay_hf, B, position) for f in _unison_freqs(freq, strings, detune_cents, rng)]
    n_drv = len(loops)
    for f in sympathetic:
        if 0 < float(f) * 6 <= sr:
            loops.append(design_loop(float(f), sr, sympathetic_t60, 0.3, 0.0, 0.13))
    lens, buf = _pack(loops)
    S = len(loops)
    lp_g = np.array([l.lp_g for l in loops])
    lp_p = np.array([l.lp_p for l in loops])
    ap_a = np.array([l.ap_a for l in loops])
    d_a = np.array([l.disp_a for l in loops])
    d_M = np.array([l.disp_M for l in loops], dtype=np.int64)
    if d_M.max(initial=0) > 64:
        raise ValueError("dispersion cascade too long")
    coupling = 0.0
    if S > 1:
        coupling = _bridge_coupling(S, bridge_t60 or (6.0 * decay if S > n_drv else None), freq)
    mode, Z = 0, 1.0
    ctl1 = ctl2 = np.zeros(1)
    hp = np.zeros(6)
    if kind == "pluck":
        _pluck_init(loops, buf, hardness, n_drv)
    elif kind == "hammer":
        mode, Z = 1, hammer.impedance
        hp[:] = [hammer.mass, hammer.stiffness, hammer.exponent, hammer.damping, hammer.speed, 0.0]
    elif kind == "bow":
        mode = 2
        ctl1, ctl2 = np.ascontiguousarray(bow_v), np.ascontiguousarray(bow_k)
    y = string_kernel(n, mode, n_drv, 1.0 / sr, Z, lens, buf, lp_g, lp_p, ap_a, d_a, d_M, coupling,
                      ctl1, ctl2, hp, float(mu_s), float(mu_d), float(v0))
    y = _comb_pickup(y, pickup, freq, sr)
    return y if raw else cm.finish(y, sr, peak_db)
