"""Physical rooms and reverbs as impulse responses (stereo `Audio`), for `@sound.impulse` or
`Audio.convolve`.

    shoebox_ir     image-source early reflections for a rectangular room (per-wall, per-octave-band
                   absorption, air absorption, spaced-pair stereo) + a feedback-delay-network late
                   tail whose per-band RT60 follows Sabine/Eyring from the same absorption
    spring_ir      dispersive spring reverb ('boing': a chirp recirculating in a delay loop)
    plate_ir       steel plate reverb from a finite-difference Kirchhoff plate (stereo pickups)

Conventions: dimensions in metres, x/y horizontal, z up; walls are ordered
(x=0, x=Lx, y=0, y=Ly, floor z=0, ceiling z=Lz). Absorption coefficients are energy coefficients
alpha in 0..1 per octave band 125, 250, 500, 1k, 2k, 4k, 8k Hz.
"""

from __future__ import annotations

import math

import numpy as np

from ..audio import DEFAULT_SR, Audio
from . import _common as cm
from .body import air_absorption_db_per_m
from ._kernels import fdn_kernel, spring_kernel

BANDS = cm.octave_bands()

# Octave-band absorption coefficients (125 Hz .. 8 kHz), typical published values.
MATERIALS: dict[str, list[float]] = {
    "concrete": [0.01, 0.01, 0.02, 0.02, 0.02, 0.03, 0.04],
    "brick": [0.03, 0.03, 0.03, 0.04, 0.05, 0.07, 0.08],
    "plaster": [0.013, 0.015, 0.02, 0.03, 0.04, 0.05, 0.06],
    "glass": [0.35, 0.25, 0.18, 0.12, 0.07, 0.04, 0.03],
    "wood_floor": [0.15, 0.11, 0.10, 0.07, 0.06, 0.07, 0.08],
    "carpet": [0.02, 0.06, 0.14, 0.37, 0.60, 0.65, 0.65],
    "curtain": [0.07, 0.31, 0.49, 0.75, 0.70, 0.60, 0.55],
    "acoustic_tile": [0.50, 0.70, 0.60, 0.70, 0.70, 0.50, 0.40],
    "audience": [0.39, 0.57, 0.80, 0.94, 0.92, 0.87, 0.80],
    "marble": [0.01, 0.01, 0.01, 0.01, 0.02, 0.02, 0.02],
    "wood_panel": [0.28, 0.22, 0.17, 0.09, 0.10, 0.11, 0.11],
}

# (dims, per-wall material names [x0, x1, y0, y1, floor, ceiling], source, listener, note)
ROOMS = {
    "studio": dict(dims=(5.0, 4.0, 2.8), walls=["plaster", "plaster", "curtain", "plaster", "carpet", "acoustic_tile"]),
    "living_room": dict(dims=(6.0, 4.5, 2.6), walls=["plaster", "glass", "plaster", "curtain", "wood_floor", "plaster"]),
    "hall": dict(dims=(28.0, 18.0, 11.0), walls=["plaster", "plaster", "wood_panel", "wood_panel", "audience", "plaster"]),
    "cathedral": dict(dims=(60.0, 24.0, 28.0), walls=["plaster", "plaster", "wood_panel", "wood_panel", "wood_floor", "plaster"]),
    "bathroom": dict(dims=(2.8, 2.2, 2.5), walls=["marble", "marble", "marble", "glass", "marble", "plaster"]),
    "chapel": dict(dims=(18.0, 8.0, 9.0), walls=["brick", "plaster", "brick", "brick", "marble", "wood_panel"]),
}


def room_absorption(walls) -> np.ndarray:
    """(6, 7) absorption from a scalar, a material name, a 7-list, a dict of wall-index/name -> any of
    those, or a list of 6 of them."""
    def one(v):
        if isinstance(v, str):
            if v not in MATERIALS:
                raise ValueError(f"unknown material '{v}'; choose from {sorted(MATERIALS)}")
            return np.array(MATERIALS[v])
        a = np.asarray(v, dtype=np.float64)
        if a.ndim == 0:
            return np.full(7, float(a))
        if a.shape != (7,):
            raise ValueError("absorption must be a scalar, a material name or 7 octave-band values")
        return a

    names = ["x0", "x1", "y0", "y1", "floor", "ceiling"]
    if isinstance(walls, np.ndarray) and walls.shape == (6, 7):
        return np.clip(walls, 0.001, 0.999)
    if isinstance(walls, dict):
        base = one(walls.get("all", 0.2))
        out = np.tile(base, (6, 1))
        for k, v in walls.items():
            if k == "all":
                continue
            i = names.index(k) if isinstance(k, str) else int(k)
            out[i] = one(v)
        return np.clip(out, 0.001, 0.999)
    if isinstance(walls, (list, tuple)) and len(walls) == 6:
        return np.clip(np.stack([one(v) for v in walls]), 0.001, 0.999)
    return np.clip(np.tile(one(walls), (6, 1)), 0.001, 0.999)


def reverberation_time(dims, absorption, formula: str = "eyring", air: bool = True, temperature_c=20.0, humidity=50.0):
    """RT60 (s) per octave band for a shoebox: Sabine 0.161 V / A, or Eyring 0.161 V / (-S ln(1 - a_mean)),
    plus the air term 4 m V. `absorption` as in `room_absorption`."""
    Lx, Ly, Lz = dims
    V = Lx * Ly * Lz
    areas = np.array([Ly * Lz, Ly * Lz, Lx * Lz, Lx * Lz, Lx * Ly, Lx * Ly])
    S = areas.sum()
    a = room_absorption(absorption)
    abar = (areas[:, None] * a).sum(0) / S
    m = air_absorption_db_per_m(BANDS, temperature_c, humidity) / 8.686 if air else np.zeros(7)
    if formula == "sabine":
        A = (areas[:, None] * a).sum(0)
        return 0.161 * V / (A + 4 * m * V)
    if formula != "eyring":
        raise ValueError("formula must be 'eyring' or 'sabine'")
    return 0.161 * V / (-S * np.log(1.0 - np.minimum(abar, 0.999)) + 4 * m * V)


def _band_partition(nfft: int, sr: int) -> np.ndarray:
    """Partition of unity over log-frequency: 7 triangular windows centred on the octave bands."""
    fr = np.fft.rfftfreq(nfft, 1.0 / sr)
    lf = np.log2(np.maximum(fr, 1.0) / 1000.0)
    centres = np.log2(BANDS / 1000.0)
    W = np.zeros((7, len(fr)))
    for i, c in enumerate(centres):
        w = np.clip(1.0 - np.abs(lf - c), 0.0, 1.0)
        W[i] = w
    W[0] = np.where(lf < centres[0], 1.0, W[0])
    W[-1] = np.where(lf > centres[-1], 1.0, W[-1])
    return W


def _sinc_add(h: np.ndarray, pos: np.ndarray, amp: np.ndarray, half: int = 4):
    """Add amp at fractional sample positions pos with a Hann-windowed sinc of 2*half taps."""
    i0 = np.floor(pos).astype(np.int64)
    fr = pos - i0
    for k in range(-half + 1, half + 1):
        d = k - fr
        w = np.sinc(d) * (0.5 + 0.5 * np.cos(np.pi * d / half))
        idx = i0 + k
        ok = (idx >= 0) & (idx < h.shape[-1])
        np.add.at(h, idx[ok], (amp * w)[ok])


def _image_sources(src, lis, dims, max_dist):
    """All image sources within max_dist of the listener: distances and wall-reflection counts (K, 6)."""
    src = np.asarray(src, dtype=np.float64)
    lis = np.asarray(lis, dtype=np.float64)
    dims = np.asarray(dims, dtype=np.float64)
    N = [int(math.ceil(max_dist / (2 * L))) + 1 for L in dims]
    per_axis = []
    for ax in range(3):
        rows = []
        for n in range(-N[ax], N[ax] + 1):
            for p in (0, 1):
                pos = (1 - 2 * p) * src[ax] + 2 * n * dims[ax]
                c0 = abs(n - p)  # reflections off the wall at 0
                c1 = abs(n)  # off the wall at L
                rows.append((pos - lis[ax], c0, c1))
        per_axis.append(np.array(rows))
    X, Y, Z = per_axis
    dx = X[:, 0][:, None, None]
    dy = Y[:, 0][None, :, None]
    dz = Z[:, 0][None, None, :]
    dist = np.sqrt(dx**2 + dy**2 + dz**2)
    keep = dist <= max_dist
    cnt = np.zeros(dist.shape + (6,))
    cnt[..., 0] = X[:, 1][:, None, None]
    cnt[..., 1] = X[:, 2][:, None, None]
    cnt[..., 2] = Y[:, 1][None, :, None]
    cnt[..., 3] = Y[:, 2][None, :, None]
    cnt[..., 4] = Z[:, 1][None, None, :]
    cnt[..., 5] = Z[:, 2][None, None, :]
    return dist[keep], cnt[keep]


def shoebox_ir(dims=(6.0, 4.5, 3.0), absorption="plaster", *, source=None, listener=None, rt60: float | None = None,
               sr: int = DEFAULT_SR, duration: float | None = None, mix_time: float = 0.06, ear_spacing: float = 0.17,
               temperature_c: float = 20.0, humidity: float = 50.0, late: bool = True, seed: int = 0,
               peak_db: float | None = -1.0) -> Audio:
    """Stereo impulse response of a shoebox room.

    dims        (Lx, Ly, Lz) metres.
    absorption  material name ('plaster', 'carpet', 'audience', ... see MATERIALS), a scalar alpha, a
                7-band list, a dict {'floor': 'carpet', 'ceiling': 0.4, 'all': 'plaster'} or a list of 6.
    source      (x, y, z) m, default 1/3 of the way in on the long axis, ~1.2 m high.
    listener    (x, y, z) m; the two channels are microphones `ear_spacing` apart along y (AB pair).
    rt60        override the late-tail RT60 (s, scalar or 7 octave-band values). None = Eyring from the
                absorption (this is what the image sources also imply, so early and late agree).
    mix_time    s; image-source reflections up to here, FDN tail after a crossfade.
    duration    IR length, default 1.1 * max RT60 (between 0.3 and 6 s).
    late        False returns the early reflections only.
    Levels follow 1/r: the direct sound is 1/distance; output is peak-normalised to `peak_db`."""
    Lx, Ly, Lz = (float(d) for d in dims)
    if min(Lx, Ly, Lz) < 0.5:
        raise ValueError("room dimensions must be at least 0.5 m")
    alpha = room_absorption(absorption)
    src = np.array(source if source is not None else (Lx / 3, Ly / 2, min(1.2, Lz * 0.5)), dtype=np.float64)
    lis = np.array(listener if listener is not None else (2 * Lx / 3, Ly / 2 + 0.2 * Ly, min(1.2, Lz * 0.5)),
                   dtype=np.float64)
    for p, nm in ((src, "source"), (lis, "listener")):
        if np.any(p <= 0) or np.any(p >= np.array([Lx, Ly, Lz])):
            raise ValueError(f"{nm} must be inside the room")
    t60b = np.broadcast_to(np.asarray(rt60, dtype=np.float64), (7,)).copy() if rt60 is not None else \
        reverberation_time((Lx, Ly, Lz), alpha, air=True, temperature_c=temperature_c, humidity=humidity)
    dur = duration or float(np.clip(1.1 * t60b.max(), 0.3, 6.0))
    n = int(dur * sr)
    nfft = 1 << int(math.ceil(math.log2(n + 4096)))
    beta = np.sqrt(1.0 - alpha)  # (6, 7) amplitude reflection
    air_db = air_absorption_db_per_m(BANDS, temperature_c, humidity)
    W = _band_partition(nfft, sr)
    t_mix = float(min(mix_time, dur * 0.8))
    chans = []
    mics = []
    for s in (-0.5, 0.5):
        m = lis.copy()
        m[1] = float(np.clip(m[1] + s * ear_spacing, 0.05, Ly - 0.05))
        mics.append(m)
    for m in mics:
        dist, cnt = _image_sources(src, m, (Lx, Ly, Lz), (t_mix + 0.004) * cm.C_AIR)
        pos = dist / cm.C_AIR * sr
        spec = np.zeros(nfft // 2 + 1, dtype=np.complex128)
        logb = np.log(beta)  # (6, 7)
        for b in range(7):
            amp = np.exp(cnt @ logb[:, b] - air_db[b] / 8.686 * dist) / np.maximum(dist, 0.3)
            h = np.zeros(nfft)
            _sinc_add(h, pos, amp)
            spec += W[b] * np.fft.rfft(h)
        early = np.fft.irfft(spec, nfft)[:n]
        chans.append(early)
    early_raw = np.stack(chans, axis=1)
    t = np.arange(n) / sr
    early = early_raw * np.clip((t_mix + 0.004 - t) / 0.008, 0.0, 1.0)[:, None]
    out = early
    if late:
        tail = _fdn_tail((Lx, Ly, Lz), t60b, sr, n, seed)
        # match the tail's level to the image-source energy decay around the mixing time
        w0, w1 = int((t_mix - 0.03) * sr), int(t_mix * sr)
        w0 = max(w0, 0)
        e_ism = float(np.sum(early_raw[w0:w1] ** 2)) + 1e-30
        e_fdn = float(np.sum(tail[w0:w1] ** 2)) + 1e-30
        tail = tail * math.sqrt(e_ism / e_fdn)
        rise = np.clip((t - (t_mix - 0.004)) / 0.008, 0.0, 1.0)[:, None]
        out = early + tail * rise
    return cm.finish(out, sr, peak_db, dc_hz=0.0, meta={"rt60": [round(float(x), 2) for x in t60b]})


def _fdn_tail(dims, t60b, sr, n, seed, N: int = 12) -> np.ndarray:
    """Late reverberation: FDN with RT60 per band (one-pole fit through the 250 Hz and 4 kHz values)."""
    Lx, Ly, Lz = dims
    V = Lx * Ly * Lz
    S = 2 * (Lx * Ly + Lx * Lz + Ly * Lz)
    mfp = 4 * V / S / cm.C_AIR  # mean free time, s
    rng = np.random.default_rng(seed)
    lo = max(0.6 * mfp, 0.010) * sr
    hi = max(1.6 * mfp, 0.030) * sr
    cands = np.sort(rng.uniform(lo, hi, N))
    delays = np.array([_next_prime(int(c)) for c in cands], dtype=np.int64)
    coef = np.stack([_line_filter(int(d), t60b, sr) for d in delays])
    in_g = np.ones(N) / math.sqrt(N)
    out_g = np.stack([np.ones(N), np.where(np.arange(N) % 2 == 0, 1.0, -1.0) * np.where(np.arange(N) % 3 == 0, -1.0, 1.0)])
    out_g = out_g / math.sqrt(N)
    x = np.zeros(1)
    x[0] = 1.0
    y = fdn_kernel(n, delays, coef, in_g, out_g, x)
    return y.T.copy()


def _line_filter(d: int, t60b, sr: int) -> np.ndarray:
    """Biquad (b0, b1, b2, a1, a2) whose magnitude follows the per-pass loss 10^(-3 d / (sr T60)) of a
    delay line of d samples at the seven octave bands: two real poles, two real zeros and a gain,
    least-squares fitted in dB, then scaled so |H| <= 1 everywhere."""
    from scipy import optimize
    target_db = -60.0 * d / (sr * np.asarray(t60b, dtype=np.float64))
    w = 2 * math.pi * BANDS / sr
    z1 = np.exp(-1j * w)

    def resp(theta, z):
        g, p1, p2, q1, q2 = theta
        return g * (1 - q1 * z) * (1 - q2 * z) / ((1 - p1 * z) * (1 - p2 * z))

    def res(theta):
        return 20 * np.log10(np.abs(resp(theta, z1)) + 1e-12) - target_db

    t0 = np.array([10 ** (target_db[2] / 20), 0.3, 0.0, 0.0, 0.0])
    sol = optimize.least_squares(res, t0, bounds=([1e-4, -0.95, -0.95, -1.2, -1.2], [1.0, 0.985, 0.985, 1.2, 1.2]))
    th = sol.x
    zg = np.exp(-1j * np.linspace(1e-3, math.pi, 512))
    peak = float(np.abs(resp(th, zg)).max())
    if peak > 0.9995:
        th[0] *= 0.9995 / peak
    g, p1, p2, q1, q2 = th
    b = g * np.array([1.0, -(q1 + q2), q1 * q2])
    a = np.array([-(p1 + p2), p1 * p2])
    return np.array([b[0], b[1], b[2], a[0], a[1]])


def _next_prime(n: int) -> int:
    n = max(n, 2)
    while True:
        if all(n % k for k in range(2, int(n**0.5) + 1)):
            return n
        n += 1


def preset(name: str, **kw) -> Audio:
    """Shoebox IR of a named room: studio, living_room, hall, cathedral, bathroom, chapel. Extra keyword
    arguments go to `shoebox_ir` (e.g. source=, listener=, sr=, seed=)."""
    if name not in ROOMS:
        raise ValueError(f"room must be one of {sorted(ROOMS)}")
    r = ROOMS[name]
    return shoebox_ir(r["dims"], r["walls"], **kw)


def spring_ir(dur: float = 3.0, *, length_ms: float = 34.0, sections: int = 70, dispersion: float = 0.62,
              decay: float = 2.6, damping: float = 3800.0, springs: int = 2, sr: int = DEFAULT_SR, seed: int = 0,
              peak_db: float | None = -1.0) -> Audio:
    """Spring reverb IR (stereo). A delay loop (`length_ms`: round trip of the spring, 25-60 ms) containing
    `sections` first-order allpass sections with coefficient -`dispersion`: high frequencies arrive
    before low ones, the typical 'drip' chirp that recirculates and decays with T60 `decay` (1-4 s).
    damping (Hz) is the loop lowpass; `springs` 1-3 run slightly different lengths (left/right differ
    so the result is stereo)."""
    if not 0.0 <= dispersion < 0.95:
        raise ValueError("dispersion must be in 0..0.95")
    n = int(dur * sr)
    rng = np.random.default_rng(seed)
    x = np.zeros(1)
    x[0] = 1.0
    ys = []
    for k in range(max(1, min(springs, 3))):
        scale = 1.0 + 0.11 * k + 0.02 * rng.standard_normal()
        gd = sections * (1 + dispersion) / (1 - dispersion)  # group delay of the chain at DC, samples
        D = max(int(length_ms * 1e-3 * sr * scale) - int(gd * 0.35), 16)
        loop = (D + gd * 0.35) / sr
        g = cm.t60_to_trip_gain(decay, loop)
        p = math.exp(-2 * math.pi * damping / sr)
        ys.append(spring_kernel(n, D, sections, -dispersion, g, p, x))
    L = ys[0] + (ys[2] * 0.6 if len(ys) > 2 else 0)
    R = ys[1] if len(ys) > 1 else np.roll(ys[0], int(0.0007 * sr))
    out = np.stack([L, R + (ys[2] * 0.6 if len(ys) > 2 else 0)], axis=1)
    out = _highpass(out, sr, 90.0)
    return cm.finish(out, sr, peak_db, dc_hz=0.0)


def _highpass(x, sr, f):
    from scipy import signal
    sos = signal.butter(2, f, "highpass", fs=sr, output="sos")
    return signal.sosfilt(sos, x, axis=0)


def plate_ir(dur: float = 2.5, *, size: tuple[float, float] = (0.6, 0.5), thickness_mm: float = 0.5, t60: float = 3.5,
             t60_hf: float = 1.4, drive: tuple[float, float] = (0.3, 0.4),
             pickups=((0.65, 0.55), (0.25, 0.75)), sr: int = DEFAULT_SR, seed: int = 0,
             peak_db: float | None = -1.0) -> Audio:
    """Plate reverb IR (stereo) from a finite-difference Kirchhoff plate (simply supported steel sheet).

    size          (width, height) m of the sheet; bigger = more modes, denser, but slower to compute
                  (cost ~ area / thickness). The studio EMT 140 is 2 x 1 m x 0.5 mm; 0.6 x 0.5 m is a
                  good compromise (about 2-4 s to render).
    thickness_mm  stiffness: thinner = lower mode frequencies and denser.
    t60, t60_hf   decay at 500 Hz and at 5 kHz (plates decay nearly flat, 1-5 s; HF a bit faster).
    drive, pickups  positions as fractions of the sheet; two pickups give left and right."""
    from .modal import _fd_run
    Lx, Ly = size
    kappa = thickness_mm * 1e-3 * math.sqrt(2.0e11 / (12 * 7800 * (1 - 0.3**2)))
    f11 = kappa * math.pi**2 * (1 / Lx**2 + 1 / Ly**2) / (2 * math.pi)
    res = _fd_run(f11, dur, "plate", Lx / Ly, t60, t60_hf, 0.0, False, drive, pickups[:2], 0.6, 0.7, 12, sr,
                  impulse=True, in_pos=drive, loss_ref=(500.0, 5000.0))
    if res.shape[0] == 1:
        res = np.vstack([res, res])
    out = _highpass(res.T, sr, 60.0)
    return cm.finish(out, sr, peak_db, dc_hz=0.0, meta={"f11": round(f11, 2)})
