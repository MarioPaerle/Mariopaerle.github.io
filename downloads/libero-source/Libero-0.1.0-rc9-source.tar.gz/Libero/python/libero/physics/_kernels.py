"""numba kernels. Everything here works on plain float64 arrays; the public modules
design the filters and call these."""

from __future__ import annotations

import math

import numpy as np
from numba import njit


# ---------------------------------------------------------------- waveguide strings

@njit(cache=True, fastmath=False)
def string_kernel(n, mode, nd, dt, Z, lens, buf, lp_g, lp_p, ap_a, disp_a, disp_M, coupling,
                  ctl1, ctl2, hp, mu_s, mu_d, v0_fric):
    """Bidirectional velocity-wave strings on a shared bridge, S strings, the first `nd` driven
    by one excitation junction (mode 0 none, 1 hammer, 2 bow).

    Per string i four ring buffers (lines): 0 nut->junction, 1 junction->bridge, 2 bridge->junction,
    3 junction->nut, lengths lens[i, :]. Bridge termination: one-pole loss, M dispersion
    allpasses, fractional-delay allpass, rigid reflection (-1) plus `coupling` common-mode
    leakage so that the strings exchange energy (double decay, sympathetic resonance).
    Hammer: hp = [mass, K, p, alpha, v0, y0]; ctl1/ctl2 unused. Bow: ctl1 = bow velocity,
    ctl2 = friction capacity k_n (velocity units: F_N / 2Z).
    Returns the summed bridge-arriving wave (bridge force) per sample."""
    S = lens.shape[0]
    out = np.zeros(n)
    ptr = np.zeros((S, 4), dtype=np.int64)
    lp_y = np.zeros(S)
    dstate = np.zeros((S, 64))
    fstate = np.zeros(S)
    aR = np.zeros(S)
    aL = np.zeros(S)
    eB = np.zeros(S)
    eN = np.zeros(S)
    apo = np.zeros(S)

    # hammer state
    mh = hp[0]
    Kc = hp[1]
    pc = hp[2]
    alpha = hp[3]
    v_h = hp[4]
    y_h = 0.0
    y_s = 0.0
    active = mode == 1
    Zeff = Z * max(nd, 1)

    for t in range(n):
        for i in range(S):
            aR[i] = buf[i, 0, ptr[i, 0]]
            eB[i] = buf[i, 1, ptr[i, 1]]
            aL[i] = buf[i, 2, ptr[i, 2]]
            eN[i] = buf[i, 3, ptr[i, 3]]

        f = 0.0
        if nd > 0 and mode != 0:
            vfree = 0.0
            for i in range(nd):
                vfree += aR[i] + aL[i]
            vfree /= nd
            if mode == 1:
                if active:
                    delta = y_h - y_s
                    b = dt * (dt / mh + 1.0 / (2.0 * Zeff))
                    a = delta + dt * (v_h - vfree)
                    F = 0.0
                    if a > 0.0:
                        # g(F) = F - K d^p (1 + alpha ddot), monotone on [0, a/b]
                        g0 = -Kc * a ** pc * (1.0 + alpha * (a - delta) / dt)
                        if g0 < 0.0:
                            lo = 0.0
                            hi = a / b
                            for _ in range(40):
                                mid = 0.5 * (lo + hi)
                                d_new = a - b * mid
                                if d_new < 0.0:
                                    d_new = 0.0
                                gm = mid - Kc * d_new ** pc * (1.0 + alpha * (d_new - delta) / dt)
                                if gm < 0.0:
                                    lo = mid
                                else:
                                    hi = mid
                            F = 0.5 * (lo + hi)
                    f = F / (2.0 * Zeff)
                    v_h -= dt * F / mh
                    y_h += dt * v_h
                    y_s += dt * (vfree + f)
                    if F == 0.0 and y_h - y_s < 0.0 and (v_h - vfree) < 0.0:
                        active = False
            else:
                vb = ctl1[t]
                kn = ctl2[t]
                dm = vfree - vb
                cap = kn * mu_s
                if abs(dm) <= cap:
                    f = -dm
                else:
                    sgn = 1.0 if dm > 0.0 else -1.0
                    lo = 0.0
                    hi = abs(dm)
                    for _ in range(36):
                        mid = 0.5 * (lo + hi)
                        gm = mid + kn * (mu_d + (mu_s - mu_d) * math.exp(-mid / v0_fric)) - abs(dm)
                        if gm < 0.0:
                            lo = mid
                        else:
                            hi = mid
                    x = 0.5 * (lo + hi)
                    f = -kn * (mu_d + (mu_s - mu_d) * math.exp(-x / v0_fric)) * sgn

        tot = 0.0
        for i in range(S):
            add = f if i < nd else 0.0
            buf[i, 1, ptr[i, 1]] = aR[i] + add
            buf[i, 3, ptr[i, 3]] = aL[i] + add
            buf[i, 0, ptr[i, 0]] = -eN[i]
            # bridge branch
            x = eB[i]
            y = lp_g[i] * (1.0 - lp_p[i]) * x + lp_p[i] * lp_y[i]
            lp_y[i] = y
            x = y
            a_d = disp_a[i]
            for m in range(disp_M[i]):
                y = a_d * x + dstate[i, m]
                dstate[i, m] = x - a_d * y
                x = y
            a_f = ap_a[i]
            y = a_f * x + fstate[i]
            fstate[i] = x - a_f * y
            apo[i] = y
            tot += y
        cm = coupling * tot
        for i in range(S):
            buf[i, 2, ptr[i, 2]] = -apo[i] + cm
            for k in range(4):
                p = ptr[i, k] + 1
                if p >= lens[i, k]:
                    p = 0
                ptr[i, k] = p
        out[t] = tot
    return out


# ---------------------------------------------------------------- winds

@njit(cache=True, inline="always")
def _lag(buf, L, w, d):
    """Cubic Lagrange read of a ring buffer at fractional delay d >= 2 samples.
    x[t-k] lives at index (w - k) mod L, w = index about to be written."""
    di = int(math.floor(d))
    fr = d - di
    y0 = buf[(w - (di - 1)) % L]
    y1 = buf[(w - di) % L]
    y2 = buf[(w - di - 1) % L]
    y3 = buf[(w - di - 2) % L]
    c1 = 0.5 * (y2 - y0)
    c2 = y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3
    c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2)
    return ((c3 * fr + c2) * fr + c1) * fr + y1


@njit(cache=True, inline="always")
def _reed_flow(x, m, omin):
    """Dimensionless reed-channel flow for x = pressure drop / closing pressure."""
    if x >= 0.0:
        op = 1.0 - x
        if op < omin:
            op = omin
        if op > 1.0:
            op = 1.0
        else:
            op = op ** m if op > 0.0 else 0.0
        return op * math.sqrt(x)
    op = 1.0 - x
    if op > 1.5:
        op = 1.5
    return -op * math.sqrt(-x)


@njit(cache=True)
def reed_kernel(n, D, ap_a, lp_g, lp_p, re_tau, gamma, zeta, kappa, noise, noise_gain, m, omin, leak):
    """Reed + bore loop (McIntyre-Schumacher-Woodhouse, dimensionless, Z0 = 1).

    p+ travels down the bore (delay D, one-pole lowpass `lp_*`, fractional allpass `ap_a`), the
    open end reflects it with inversion, it returns as p-. The reed junction solves, per sample,
        (1 + kappa) x + zeta F(x) = (1 + kappa) gamma - 2 p- + sigma,     p = gamma - x,  p+ = p - p-
    by bisection (x = pressure drop / closing pressure). `kappa` > 0 adds the inertance of a cone
    apex (sigma integrates p), which turns the cylinder's odd-harmonic loop into a conical bore.
    Returns (radiated pressure, flow u, bore pressure p)."""
    L = D + 4
    line = np.zeros(L)
    w = 0
    lp_y = 0.0
    ap_s = 0.0
    sigma = 0.0
    y_out = np.zeros(n)
    u_out = np.zeros(n)
    p_out = np.zeros(n)
    for t in range(n):
        arr = line[(w - D) % L]
        y = lp_g * (1.0 - lp_p) * arr + lp_p * lp_y
        lp_y = y
        yy = ap_a * y + ap_s
        ap_s = y - ap_a * yy
        pm = -yy
        g = gamma[t] + noise_gain * noise[t]
        kap = kappa[t]
        z = zeta[t]
        q = (1.0 + kap) * g - 2.0 * pm + sigma
        lo = -1.5
        hi = 3.0
        for _ in range(34):
            mid = 0.5 * (lo + hi)
            if (1.0 + kap) * mid + z * _reed_flow(mid, m, omin) < q:
                lo = mid
            else:
                hi = mid
        x = 0.5 * (lo + hi)
        p = g - x
        pp = p - pm
        sigma = leak * sigma + 2.0 * kap * p if kap > 0.0 else 0.0
        line[w] = pp
        w += 1
        if w >= L:
            w = 0
        y_out[t] = arr - yy
        u_out[t] = pp - pm
        p_out[t] = p
    return y_out, u_out, p_out


@njit(cache=True)
def flute_kernel(n, Db, Dj, lp_g, lp_p, breath, noise, jet_ref, end_ref, dc_r):
    """Jet-driven flute (after Cook/Verge): breath pressure minus the bore's returning wave drives
    a jet delay line and the cubic sigmoid x^3 - x; the result plus a fraction of the returning wave
    re-enters the bore delay line. Db, Dj are fractional delays in samples (Dj = jet transit)."""
    Lb = int(Db) + 8
    Lj = int(Dj) + 8
    bore = np.zeros(Lb)
    jet = np.zeros(Lj)
    wb = 0
    wj = 0
    lp_y = 0.0
    lp_y2 = 0.0
    dcx = 0.0
    dcy = 0.0
    out = np.zeros(n)
    for t in range(n):
        ret = _lag(bore, Lb, wb, Db)
        y = lp_g * (1.0 - lp_p) * ret + lp_p * lp_y
        lp_y = y
        y = (1.0 - lp_p) * y + lp_p * lp_y2  # second pole: the bore must not sustain its upper modes
        lp_y2 = y
        dcy = y - dcx + dc_r * dcy
        dcx = y
        temp = dcy
        pd = breath[t] + noise[t] - jet_ref * temp
        jet[wj] = pd
        wj += 1
        if wj >= Lj:
            wj = 0
        jd = _lag(jet, Lj, wj, Dj)
        j = jd * (jd * jd - 1.0)
        if j > 1.0:
            j = 1.0
        elif j < -1.0:
            j = -1.0
        bore[wb] = j + end_ref * temp
        wb += 1
        if wb >= Lb:
            wb = 0
        out[t] = ret
    return out


@njit(cache=True)
def lip_kernel(n, D, lp_g, lp_p, ap_a, hp_c, gamma, zeta, h0, lip_b, lip_a, lip_gain, nl, hmax, noise, noise_gain,
               kick):
    """Lip-reed + bore (Adachi/Sato-style one-mass lip, dimensionless waveguide).

    The lip opening h follows a two-pole resonator driven by the pressure drop x of the previous
    sample (outward-striking: higher mouth pressure opens the lips). Flow u = zeta h sqrt|x|,
    solved in closed form from x + zeta h sqrt|x| sgn x = gamma - 2 p-.
    Bore: delay D with one-pole bell/loss filter and fractional allpass, reflection +1 (harmonic
    series f_k = k c / 2L). `nl` > 0 shortens the delay in proportion to the wave's amplitude
    (nonlinear steepening = brassiness). Returns (radiated pressure, bore pressure)."""
    L = D + 12
    line = np.zeros(L)
    w = 0
    lp_y = 0.0
    ap_s = 0.0
    x1 = 0.0
    x2 = 0.0
    y1 = 0.0
    y2 = 0.0
    xprev = 0.0
    hx = 0.0
    hy = 0.0
    y_out = np.zeros(n)
    p_out = np.zeros(n)
    for t in range(n):
        if nl > 0.0:
            a0 = _lag(line, L, w, float(D))
            dd = float(D) - nl * a0
            if dd < 4.0:
                dd = 4.0
            arr = _lag(line, L, w, dd)
        else:
            arr = line[(w - D) % L]
        y = lp_g * (1.0 - lp_p) * arr + lp_p * lp_y
        lp_y = y
        yy = ap_a * y + ap_s
        ap_s = y - ap_a * yy
        hy = yy - hx + hp_c * hy  # reflection must vanish at DC so the mean flow can pass
        hx = yy
        pm = hy
        # lip resonator (biquad lowpass driven by previous pressure drop)
        yl = lip_b[0] * xprev + lip_b[1] * x1 + lip_b[2] * x2 - lip_a[0] * y1 - lip_a[1] * y2
        x2 = x1
        x1 = xprev
        y2 = y1
        y1 = yl
        h = h0[t] + lip_gain * yl
        if h < 0.0:
            h = 0.0
        if h > hmax:
            h = hmax
        g = gamma[t] + noise_gain * noise[t] + kick * math.exp(-t / 96.0)  # tongue burst seeds the buzz
        q = g - 2.0 * pm
        zh = zeta[t] * h
        if q >= 0.0:
            s = 0.5 * (-zh + math.sqrt(zh * zh + 4.0 * q))
            x = s * s
        else:
            s = 0.5 * (-zh + math.sqrt(zh * zh - 4.0 * q))
            x = -s * s
        xprev = x
        p = g - x
        pp = p - pm
        line[w] = pp
        w += 1
        if w >= L:
            w = 0
        y_out[t] = arr - yy
        p_out[t] = p
    return y_out, p_out


# ---------------------------------------------------------------- modal synthesis

@njit(cache=True)
def modal_kernel(n, freqs, t60, gains, exc, sr):
    """Bank of exact two-pole resonators driven by `exc` (length <= n, zero after).
    Mode k: y[t] = 2 r cos(w) y[t-1] - r^2 y[t-2] + g sin(w) x[t-1]; r from T60 (-60 dB)."""
    out = np.zeros(n)
    m = exc.shape[0]
    for k in range(freqs.shape[0]):
        w = 2.0 * math.pi * freqs[k] / sr
        if freqs[k] >= 0.5 * sr or gains[k] == 0.0:
            continue
        r = 10.0 ** (-3.0 / (max(t60[k], 1e-4) * sr))
        a1 = 2.0 * r * math.cos(w)
        a2 = -r * r
        b = gains[k] * math.sin(w)
        y1 = 0.0
        y2 = 0.0
        xp = 0.0
        for t in range(n):
            y = a1 * y1 + a2 * y2 + b * xp
            xp = exc[t] if t < m else 0.0
            y2 = y1
            y1 = y
            out[t] += y
    return out


# ---------------------------------------------------------------- finite-difference plates

@njit(cache=True)
def fd_plate_kernel(n, nx, ny, k, h, kappa, c, sigma0, sigma1, exc, ex, ey, outs, clamped):
    """Explicit scheme for u_tt = -kappa^2 lap^2 u + c^2 lap u - 2 sigma0 u_t + 2 sigma1 lap u_t
    on an nx x ny grid (spacing h, step k), boundary: simply supported (u = lap u = 0) or
    clamped (u = u_n = 0). Force `exc` (length m) is injected at (ex, ey). `outs` is a (P, 2) array
    of readout points. Returns (P, n) displacements."""
    P = outs.shape[0]
    res = np.zeros((P, n))
    W = nx + 5
    H = ny + 5
    u0 = np.zeros((W, H))
    u1 = np.zeros((W, H))
    u2 = np.zeros((W, H))
    lap1 = np.zeros((W, H))
    lap0 = np.zeros((W, H))
    h2 = h * h
    den = 1.0 + sigma0 * k
    m = exc.shape[0]
    a_s = 2.0 * sigma1 * k / h2
    for t in range(n):
        # ghost cells of u1 (index offset 2): simply supported -> antisymmetric, clamped -> symmetric
        for j in range(H):
            if clamped:
                u1[1, j] = u1[3, j]
                u1[nx + 3, j] = u1[nx + 1, j]
            else:
                u1[1, j] = -u1[3, j]
                u1[nx + 3, j] = -u1[nx + 1, j]
        for i in range(W):
            if clamped:
                u1[i, 1] = u1[i, 3]
                u1[i, ny + 3] = u1[i, ny + 1]
            else:
                u1[i, 1] = -u1[i, 3]
                u1[i, ny + 3] = -u1[i, ny + 1]
        for i in range(1, nx + 4):
            for j in range(1, ny + 4):
                lap1[i, j] = (u1[i + 1, j] + u1[i - 1, j] + u1[i, j + 1] + u1[i, j - 1] - 4.0 * u1[i, j]) / h2
        for i in range(3, nx + 2):
            for j in range(3, ny + 2):
                bil = (lap1[i + 1, j] + lap1[i - 1, j] + lap1[i, j + 1] + lap1[i, j - 1] - 4.0 * lap1[i, j]) / h2
                v = (2.0 * u1[i, j] - (1.0 - sigma0 * k) * u0[i, j]
                     - k * k * kappa * kappa * bil + k * k * c * c * lap1[i, j]
                     + a_s * h2 * (lap1[i, j] - lap0[i, j]))
                u2[i, j] = v / den
        if t < m:
            u2[ex + 2, ey + 2] += k * k * exc[t] / (h2 * den)
        for q in range(P):
            res[q, t] = u2[int(outs[q, 0]) + 2, int(outs[q, 1]) + 2]
        # rotate
        for i in range(W):
            for j in range(H):
                lap0[i, j] = lap1[i, j]
                u0[i, j] = u1[i, j]
                u1[i, j] = u2[i, j]
    return res


# ---------------------------------------------------------------- reverberators

@njit(cache=True)
def fdn_kernel(n, delays, coef, in_gain, out_gain, x):
    """Feedback delay network with a Householder feedback matrix and one biquad (b0, b1, b2, a1, a2 in
    coef[i]) per delay line carrying that line's frequency-dependent loss (|H| <= 1: stable).
    out_gain is (C, N); returns (C, n)."""
    N = delays.shape[0]
    C = out_gain.shape[0]
    L = int(delays.max()) + 2
    buf = np.zeros((N, L))
    wpos = np.zeros(N, dtype=np.int64)
    s1 = np.zeros(N)
    s2 = np.zeros(N)
    ly = np.zeros(N)
    s = np.zeros(N)
    out = np.zeros((C, n))
    m = x.shape[0]
    for t in range(n):
        acc = 0.0
        for i in range(N):
            s[i] = buf[i, (wpos[i] - delays[i]) % L]
            y = coef[i, 0] * s[i] + s1[i]
            s1[i] = coef[i, 1] * s[i] - coef[i, 3] * y + s2[i]
            s2[i] = coef[i, 2] * s[i] - coef[i, 4] * y
            ly[i] = y
            acc += y
        acc *= 2.0 / N
        xin = x[t] if t < m else 0.0
        for i in range(N):
            buf[i, wpos[i]] = ly[i] - acc + in_gain[i] * xin
            wpos[i] = (wpos[i] + 1) % L
        for c in range(C):
            v = 0.0
            for i in range(N):
                v += out_gain[c, i] * s[i]
            out[c, t] = v
    return out


@njit(cache=True)
def spring_kernel(n, D, M, a, g, p, x):
    """Spring reverb loop: delay D, M cascaded first-order allpass (coefficient a < 0 makes highs
    arrive first: the 'boing' chirp), one-pole lowpass p, loop gain g."""
    L = D + 2
    buf = np.zeros(L)
    w = 0
    st = np.zeros(M)
    out = np.zeros(n)
    lp = 0.0
    m = x.shape[0]
    for t in range(n):
        d = buf[(w - D) % L]
        xin = x[t] if t < m else 0.0
        u = xin + g * d
        for k in range(M):
            y = a * u + st[k]
            st[k] = u - a * y
            u = y
        lp = (1.0 - p) * u + p * lp
        buf[w] = lp
        w = (w + 1) % L
        out[t] = lp
    return out
