"""Plucked string: Karplus–Strong body through a small wooden box, a pick
transient, a soft finger-release tail and a faint room."""

from libero import Sound, synth

sound = Sound(
    title="__TITLE__",
    subtitle="__SUBTITLE__",
    tags=["plucked", "string"],
    roots=[36, 48, 60, 72, 84],
    velocities=[100],
    sample_rate=48000,
)


@sound.body
def body(ctx):
    # higher strings ring shorter and a touch brighter
    string = synth.karplus(ctx.freq, dur=4.5 - 2.0 * ctx.register, bright=0.45 + 0.2 * ctx.register,
                           decay=5.5 - 3.5 * ctx.register, pick_position=0.16, velocity=ctx.vel,
                           sr=ctx.sr, seed=ctx.seed)
    box = synth.impulse_response("wood", sr=ctx.sr, seed=3)
    return string.convolve(box, mix=0.45).to_mono().highpass(55).normalize(-3)


@sound.attack
def attack(ctx):
    # pick: a bright 6 ms click plus a tiny low thump
    click = synth.noise("white", 0.012, sr=ctx.sr, seed=ctx.seed).bandpass(3500, q=0.9)
    click = click.envelope([(0, 0), (0.0004, 1), (0.006, 0.08), (0.012, 0)])
    thump = synth.sine(140, 0.03, sr=ctx.sr).envelope([(0, 0), (0.001, 1), (0.03, 0)])
    return click.mix(thump.gain_db(-12)).normalize(-10)


@sound.tail
def tail(ctx):
    # the finger touching the string on release
    return (synth.noise("pink", 0.09, sr=ctx.sr, seed=ctx.seed).bandpass(900, q=0.7)
            .envelope([(0, 0), (0.004, 1), (0.09, 0)]).normalize(-26))


@sound.air
def air(ctx):
    return synth.noise("pink", 6.0, sr=ctx.sr, seed=11, stereo=True).lowpass(5000).highpass(120).normalize_rms(-42)


@sound.impulse
def ir(ctx):
    return synth.impulse_response("room", sr=ctx.sr, seed=5)


sound.defaults(amp_attack=1, amp_decay=4000, amp_sustain=0.0, amp_release=450, rev_mode="Cappella",
               rev_mix=0.18, res_mode="Corde", res_mix=0.12, lvl_air=-24)
