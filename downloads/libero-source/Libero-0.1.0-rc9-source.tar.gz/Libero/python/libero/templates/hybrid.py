"""Sample-based hybrid: drop a recording into samples/source.wav (any pitch,
any rate). The recipe tunes it to each root, loops its sustain, attaches a
synthetic transient and adds an air bed. Until a source exists it uses a
synthesised stand-in so the sound compiles out of the box."""

from libero import Sound, synth

sound = Sound(
    title="__TITLE__",
    subtitle="__SUBTITLE__",
    tags=["hybrid", "sampled"],
    roots=[36, 48, 60, 72, 84],
    velocities=[100],
    sample_rate=48000,
)

SOURCE_NOTE = None  # set to the MIDI note of samples/source.wav to skip pitch detection


def source(ctx):
    if ctx.has("source.wav"):
        return ctx.load("source.wav").to_mono()
    # stand-in: a bowed tone at C3
    return synth.bow(130.81, dur=5.0, pressure=0.4, bright=0.5, vibrato_cents=6.0, sr=ctx.sr, seed=1)


@sound.body
def body(ctx):
    src = source(ctx).trim_silence(-50)
    if SOURCE_NOTE is not None:
        tuned = src.pitch(ctx.note - SOURCE_NOTE)
    else:
        tuned = src.tune_to(ctx.note)
    if tuned.duration < 3.0:  # shifting up shortens it: stretch back so the loop has room
        tuned = tuned.stretch(3.5 / tuned.duration)
    return tuned.fit(max(2.0, min(tuned.duration, 6.0))).normalize_loudness(-17)


@sound.attack
def attack(ctx):
    click = synth.noise("white", 0.015, sr=ctx.sr, seed=ctx.seed).bandpass(2800, q=0.8)
    thump = synth.sine(90, 0.04, sr=ctx.sr)
    return click.mix(thump.gain_db(-10)).envelope([(0, 0), (0.0005, 1), (0.015, 0.1), (0.04, 0)]).normalize(-14)


@sound.air
def air(ctx):
    return synth.noise("pink", 6.0, sr=ctx.sr, seed=2, stereo=True).lowpass(6000).normalize_rms(-40)


sound.loop(body=True, min_seconds=0.8)
sound.defaults(amp_attack=5, amp_release=600, rev_mode="Basilica", rev_mix=0.25)
