"""Tuned percussion: struck wooden bars (marimba-like modal body) with a
mallet knock, velocity layers that brighten the strike."""

from libero import Sound, synth

sound = Sound(
    title="__TITLE__",
    subtitle="__SUBTITLE__",
    tags=["percussion", "mallet", "wood"],
    roots=[48, 60, 72, 84],
    velocities=[50, 90, 125],
    sample_rate=48000,
)


@sound.body
def body(ctx):
    bar = synth.modal(ctx.freq, "wood", dur=2.5 - ctx.register, hardness=0.2 + 0.75 * ctx.vel,
                      decay_scale=1.4, sr=ctx.sr, seed=ctx.seed)
    tube = synth.modal(ctx.freq, [(1.0, 1.6, 1.0), (2.0, 0.4, 0.1)], dur=2.5 - ctx.register, sr=ctx.sr,
                       seed=ctx.seed)  # the resonator tube under the bar
    return bar.mix(tube.gain_db(-9)).normalize(-3 - 9 * (1 - ctx.vel))


@sound.attack
def attack(ctx):
    knock = synth.noise("pink", 0.025, sr=ctx.sr, seed=ctx.seed).bandpass(1200 + 2500 * ctx.vel, q=1.2)
    return knock.envelope([(0, 0), (0.0005, 1), (0.025, 0)]).normalize(-12 - 10 * (1 - ctx.vel))


sound.defaults(amp_attack=0, amp_decay=2500, amp_sustain=0.0, amp_release=400, rev_mode="Cappella",
               rev_mix=0.2, vel_sens=0.9)
