"""Client for the agent socket of running plugin instances (SPEC §6)."""

from __future__ import annotations

import itertools
import json
import os
import socket
from pathlib import Path

from . import library


class PluginError(Exception):
    pass


def _alive(pid) -> bool:
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except (TypeError, ValueError):
        return False
    return True


def instances(include_dead: bool = False) -> list[dict]:
    """Running instances from $LIBERO_HOME/instances/*.json, newest first; dead pids skipped."""
    d = library.instances_dir()
    out = []
    if not d.is_dir():
        return out
    for p in d.glob("*.json"):
        try:
            info = json.loads(p.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        info["_file"] = str(p)
        info["alive"] = _alive(info.get("pid"))
        if info["alive"] or include_dead:
            out.append(info)
    out.sort(key=lambda i: str(i.get("started", "")), reverse=True)
    return out


class PluginClient:
    _ids = itertools.count(1)

    def __init__(self, port: int, host: str = "127.0.0.1", timeout: float = 5.0):
        self.addr = (host, int(port))
        self.timeout = timeout

    def call(self, method: str, **params):
        req = {"id": next(self._ids), "method": method, "params": params}
        try:
            with socket.create_connection(self.addr, timeout=self.timeout) as s:
                # load answers only once the bundle is decoded: seconds for a large multisample.
                s.settimeout(max(self.timeout, 60.0) if method == "load" else self.timeout)
                s.sendall((json.dumps(req) + "\n").encode())
                buf = b""
                while b"\n" not in buf:
                    chunk = s.recv(65536)
                    if not chunk:
                        break
                    buf += chunk
        except OSError as e:
            raise PluginError(f"cannot reach the plugin on port {self.addr[1]}: {e}") from None
        line = buf.split(b"\n", 1)[0]
        if not line:
            raise PluginError("the plugin closed the connection without answering")
        try:
            resp = json.loads(line)
        except json.JSONDecodeError:
            raise PluginError(f"unparseable reply: {line[:200]!r}") from None
        if "error" in resp and resp["error"]:
            raise PluginError(str(resp["error"]))
        return resp.get("result")


def pick(instance: str | None = None) -> dict:
    live = instances()
    if not live:
        raise PluginError("no running Libero instance found (open the plugin in a DAW; instances register in "
                          f"{library.instances_dir()})")
    if instance is None:
        return live[0]
    for i in live:
        if str(i.get("id")) == str(instance) or str(i.get("port")) == str(instance):
            return i
    raise PluginError(f"no running instance '{instance}'; live: {[i.get('id') for i in live]}")


def client(instance: str | None = None) -> PluginClient:
    return PluginClient(pick(instance)["port"])


def call(method: str, instance: str | None = None, **params):
    return client(instance).call(method, **params)


def sound_path_for_plugin(folder: Path) -> str:
    return str(Path(folder).resolve())
