"""Low-level DSP shared by `Audio`, `synth` and `analysis`.

Everything here works on plain numpy arrays: mono is shape (n,), stereo (n, 2).
"""

from __future__ import annotations

import math

import numpy as np
from scipy import signal

NOTE_NAMES = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")


# ---------------------------------------------------------------- pitch names

def midi_to_freq(note: float) -> float:
    return 440.0 * 2.0 ** ((note - 69.0) / 12.0)


def freq_to_midi(freq: float) -> float:
    return 69.0 + 12.0 * math.log2(freq / 440.0)


def note_name(note: int) -> str:
    return f"{NOTE_NAMES[int(note) % 12]}{int(note) // 12 - 1}"


def parse_note(n) -> int:
    """'A4' / 'C#3' / 'Db5' / 60 → MIDI note number."""
    if isinstance(n, (int, np.integer)):
        return int(n)
    if isinstance(n, float):
        return int(round(n))
    s = str(n).strip()
    if s.lstrip("-").isdigit():
        return int(s)
    letter = s[0].upper()
    base = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}[letter]
    rest = s[1:]
    while rest and rest[0] in "#b♯♭":
        base += 1 if rest[0] in "#♯" else -1
        rest = rest[1:]
    return base + (int(rest) + 1) * 12


def describe_freq(freq: float) -> str:
    """440.0 → 'A4 +0c'."""
    if not freq or freq <= 0 or not np.isfinite(freq):
        return "-"
    m = freq_to_midi(freq)
    n = int(round(m))
    cents = (m - n) * 100.0
    return f"{note_name(n)} {cents:+.1f}c"


# ---------------------------------------------------------------- shape helpers

def as_2d(x: np.ndarray) -> np.ndarray:
    return x[:, None] if x.ndim == 1 else x


def mono(x: np.ndarray) -> np.ndarray:
    return x if x.ndim == 1 else x.mean(axis=1)


def db(x: float, floor: float = -200.0) -> float:
    return float(max(floor, 20.0 * math.log10(max(float(x), 1e-12))))


def undb(d: float) -> float:
    return 10.0 ** (d / 20.0)


# ---------------------------------------------------------------- filters

def rbj_biquad(kind: str, freq: float, sr: float, q: float = 0.7071, gain_db: float = 0.0) -> np.ndarray:
    """RBJ cookbook biquad as a single SOS row [b0 b1 b2 1 a1 a2]."""
    freq = float(np.clip(freq, 1.0, 0.499 * sr))
    w0 = 2.0 * math.pi * freq / sr
    cw, sw = math.cos(w0), math.sin(w0)
    alpha = sw / (2.0 * max(q, 1e-4))
    A = 10.0 ** (gain_db / 40.0)
    if kind == "lowpass":
        b = [(1 - cw) / 2, 1 - cw, (1 - cw) / 2]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    elif kind == "highpass":
        b = [(1 + cw) / 2, -(1 + cw), (1 + cw) / 2]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    elif kind == "bandpass":  # constant 0 dB peak gain
        b = [alpha, 0.0, -alpha]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    elif kind == "notch":
        b = [1.0, -2 * cw, 1.0]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    elif kind == "peak":
        b = [1 + alpha * A, -2 * cw, 1 - alpha * A]
        a = [1 + alpha / A, -2 * cw, 1 - alpha / A]
    elif kind in ("lowshelf", "highshelf"):
        sq = 2 * math.sqrt(A) * alpha
        if kind == "lowshelf":
            b = [A * ((A + 1) - (A - 1) * cw + sq), 2 * A * ((A - 1) - (A + 1) * cw), A * ((A + 1) - (A - 1) * cw - sq)]
            a = [(A + 1) + (A - 1) * cw + sq, -2 * ((A - 1) + (A + 1) * cw), (A + 1) + (A - 1) * cw - sq]
        else:
            b = [A * ((A + 1) + (A - 1) * cw + sq), -2 * A * ((A - 1) + (A + 1) * cw), A * ((A + 1) + (A - 1) * cw - sq)]
            a = [(A + 1) - (A - 1) * cw + sq, 2 * ((A - 1) - (A + 1) * cw), (A + 1) - (A - 1) * cw - sq]
    else:
        raise ValueError(f"unknown filter kind '{kind}'")
    b = np.asarray(b) / a[0]
    a = np.asarray(a) / a[0]
    return np.concatenate([b, a])[None, :]


def sosfilt(sos: np.ndarray, x: np.ndarray, zero_phase: bool = False) -> np.ndarray:
    x64 = x.astype(np.float64)
    if zero_phase:
        return signal.sosfiltfilt(sos, x64, axis=0)
    return signal.sosfilt(sos, x64, axis=0)


def dc_block(x: np.ndarray, sr: float, cutoff: float = 8.0) -> np.ndarray:
    sos = signal.butter(2, cutoff, "highpass", fs=sr, output="sos")
    y = signal.sosfilt(sos, x.astype(np.float64) - x.mean(axis=0), axis=0)
    return y


# ---------------------------------------------------------------- resampling

def resample_ratio(x: np.ndarray, ratio: float) -> np.ndarray:
    """Resample so len(out) ≈ len(x) * ratio, with a long Kaiser anti-alias filter.

    The ratio is approximated by a fraction good to ~0.01 cent.
    """
    from fractions import Fraction

    if abs(ratio - 1.0) < 1e-12:
        return x.copy()
    fr = Fraction(ratio).limit_denominator(4000)
    up, down = fr.numerator, fr.denominator
    # keep the polyphase filter size sane for awkward ratios
    while max(up, down) > 8000:
        fr = Fraction(ratio).limit_denominator(max(2, fr.denominator // 2))
        up, down = fr.numerator, fr.denominator
    return signal.resample_poly(x.astype(np.float64), up, down, axis=0, window=("kaiser", 10.0))


def resample_to(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    if sr_in == sr_out:
        return x.copy()
    g = math.gcd(int(sr_in), int(sr_out))
    return signal.resample_poly(x.astype(np.float64), sr_out // g, sr_in // g, axis=0, window=("kaiser", 10.0))


# ---------------------------------------------------------------- YIN

def yin(x: np.ndarray, sr: int, fmin: float = 30.0, fmax: float = 4000.0, frame: int | None = None,
        hop: int | None = None, threshold: float = 0.15):
    """YIN f0 tracker (de Cheveigné & Kawahara 2002), vectorised with FFTs.

    Returns (times, f0, aperiodicity, rms). f0 is NaN where unvoiced.
    """
    x = mono(np.asarray(x, dtype=np.float64))
    max_tau = int(math.ceil(sr / fmin))
    min_tau = max(2, int(math.floor(sr / fmax)))
    W = frame or max(1024, 1 << int(math.ceil(math.log2(max_tau * 1.5))))
    hop = hop or max(256, W // 4)
    L = W + max_tau
    if len(x) < L:
        x = np.pad(x, (0, L - len(x)))
    starts = np.arange(0, len(x) - L + 1, hop)
    if len(starts) == 0:
        starts = np.array([0])
    idx = starts[:, None] + np.arange(L)[None, :]
    frames = x[idx]  # (F, L)
    nfft = 1 << int(math.ceil(math.log2(L + W)))
    # r(tau) = sum_{j<W} x[j] x[j+tau]
    A = np.fft.rfft(frames, nfft, axis=1)
    B = np.fft.rfft(frames[:, :W], nfft, axis=1)
    r = np.fft.irfft(A * np.conj(B), nfft, axis=1)[:, : max_tau + 1]
    sq = np.concatenate([np.zeros((len(starts), 1)), np.cumsum(frames**2, axis=1)], axis=1)
    e0 = sq[:, W] - sq[:, 0]
    taus = np.arange(max_tau + 1)
    etau = sq[:, taus + W] - sq[:, taus]
    d = e0[:, None] + etau - 2.0 * r
    d[:, 0] = 0.0
    d = np.maximum(d, 0.0)
    cum = np.cumsum(d[:, 1:], axis=1)
    cmnd = np.ones_like(d)
    cmnd[:, 1:] = d[:, 1:] * np.arange(1, max_tau + 1)[None, :] / np.maximum(cum, 1e-20)

    F = len(starts)
    f0 = np.full(F, np.nan)
    aper = np.ones(F)
    rms = np.sqrt(e0 / W)
    for i in range(F):
        c = cmnd[i]
        below = np.nonzero(c[min_tau:max_tau] < threshold)[0]
        if len(below):
            t = below[0] + min_tau
            while t + 1 < max_tau and c[t + 1] < c[t]:
                t += 1
        else:
            t = int(np.argmin(c[min_tau:max_tau])) + min_tau
            if c[t] > 0.35:
                aper[i] = min(1.0, c[t])
                continue
        aper[i] = c[t]
        # parabolic interpolation on the raw difference function
        if 1 <= t < max_tau:
            a, b, cc = d[i, t - 1], d[i, t], d[i, t + 1]
            den = a - 2 * b + cc
            shift = 0.5 * (a - cc) / den if den > 1e-20 else 0.0
            shift = float(np.clip(shift, -1, 1))
        else:
            shift = 0.0
        f0[i] = sr / (t + shift)
    silent = rms < max(1e-5, rms.max() * 10 ** (-50 / 20)) if len(rms) else rms < 0
    f0[silent] = np.nan
    times = (starts + W / 2) / sr
    return times, f0, aper, rms


def refine_f0(x: np.ndarray, sr: int, f0: float, harmonics: int = 6) -> float:
    """Sharpen an f0 estimate from a long zero-padded FFT of the first harmonics."""
    x = mono(np.asarray(x, dtype=np.float64))
    n = len(x)
    if n < 2048 or not np.isfinite(f0):
        return f0
    w = np.hanning(n)
    nfft = 1 << int(math.ceil(math.log2(n * 4)))
    spec = np.abs(np.fft.rfft(x * w, nfft))
    df = sr / nfft
    ests, weights = [], []
    for k in range(1, harmonics + 1):
        fk = f0 * k
        if fk > 0.45 * sr:
            break
        lo = int((fk * 0.97) / df)
        hi = int((fk * 1.03) / df) + 1
        if hi - lo < 3:
            continue
        seg = spec[lo:hi]
        p = int(np.argmax(seg)) + lo
        if spec[p] < 8.0 * np.median(seg):  # no real partial here, just noise: skip it
            continue
        if 1 <= p < len(spec) - 1:
            a, b, c = np.log(spec[p - 1] + 1e-20), np.log(spec[p] + 1e-20), np.log(spec[p + 1] + 1e-20)
            den = a - 2 * b + c
            sh = 0.5 * (a - c) / den if den != 0 else 0.0
            ests.append((p + sh) * df / k)
            weights.append(spec[p])
    if not ests:
        return f0
    ests = np.asarray(ests)
    weights = np.asarray(weights)
    good = (np.abs(1200 * np.log2(ests / f0)) < 30) & (weights > 0.01 * weights.max())
    if not good.any():
        return f0
    f1 = float(np.average(ests[good], weights=weights[good]))
    # second pass: power centroid of each harmonic within ±30 cents. For one sinusoid this equals
    # the peak; for an ensemble (chorus, detuned voices) it is the centre of the cluster, which
    # is what the ear tunes to, instead of whichever voice happens to be loudest.
    P = spec**2
    ests2, w2 = [], []
    for k in range(1, harmonics + 1):
        fk = f1 * k
        if fk > 0.45 * sr:
            break
        lo = int(fk * 2 ** (-30 / 1200) / df)
        hi = int(fk * 2 ** (30 / 1200) / df) + 2
        seg = P[lo:hi]
        if seg.sum() <= 0 or np.sqrt(seg.max()) < 8.0 * np.median(spec[max(0, lo - (hi - lo)): hi + (hi - lo)]):
            continue
        fc = float((np.arange(lo, hi) * seg).sum() / seg.sum()) * df
        ests2.append(fc / k)
        w2.append(np.sqrt(seg.max()))
    if not ests2:
        return f1
    return float(np.average(ests2, weights=w2))


def estimate_f0(x: np.ndarray, sr: int, fmin: float = 30.0, fmax: float = 4000.0) -> tuple[float, float]:
    """Median f0 of the voiced, loud frames → (f0 Hz or NaN, voiced fraction)."""
    times, f0, aper, rms = yin(x, sr, fmin, fmax)
    voiced = np.isfinite(f0) & (aper < 0.3)
    if voiced.sum() == 0:
        return float("nan"), 0.0
    loud = rms > np.percentile(rms[voiced], 25) * 0.5
    sel = voiced & loud
    if sel.sum() == 0:
        sel = voiced
    med = float(np.median(f0[sel]))
    return med, float(voiced.mean())


# ---------------------------------------------------------------- envelopes & onsets

def rms_envelope(x: np.ndarray, sr: int, win_s: float = 0.01, hop: int | None = None):
    m = mono(np.asarray(x, dtype=np.float64))
    win = max(8, int(win_s * sr))
    hop = hop or max(1, win // 2)
    if len(m) < win:
        m = np.pad(m, (0, win - len(m)))
    c = np.concatenate([[0.0], np.cumsum(m**2)])
    starts = np.arange(0, len(m) - win + 1, hop)
    e = np.sqrt(np.maximum((c[starts + win] - c[starts]) / win, 0.0))
    t = (starts + win / 2) / sr
    return t, e


def onset_sample(x: np.ndarray, sr: int, rel_db: float = -30.0) -> int:
    """First sample where the 1 ms RMS envelope crosses `rel_db` below its maximum."""
    m = mono(np.asarray(x, dtype=np.float64))
    if len(m) == 0:
        return 0
    win = max(4, int(0.001 * sr))
    c = np.concatenate([[0.0], np.cumsum(m**2)])
    e = np.sqrt(np.maximum((c[win:] - c[:-win]) / win, 0.0))
    if len(e) == 0 or e.max() <= 0:
        return 0
    thr = e.max() * 10 ** (rel_db / 20)
    i = int(np.argmax(e >= thr))
    return max(0, i)


def onset_times(x: np.ndarray, sr: int, max_onsets: int = 16) -> list[float]:
    """Spectral-flux onsets with adaptive threshold."""
    m = mono(np.asarray(x, dtype=np.float64))
    n_fft, hop = 1024, 256
    if len(m) < n_fft:
        return [0.0] if np.abs(m).max(initial=0) > 1e-4 else []
    f, t, Z = signal.stft(m, sr, nperseg=n_fft, noverlap=n_fft - hop, boundary=None, padded=False)
    mag = np.log1p(100 * np.abs(Z))
    flux = np.maximum(np.diff(mag, axis=1), 0).sum(axis=0)
    flux = np.concatenate([[mag[:, 0].sum()], flux])
    if flux.max() <= 0:
        return []
    med = signal.medfilt(flux, 15) if len(flux) >= 15 else np.full_like(flux, np.median(flux))
    thr = med + 0.25 * flux.max()
    peaks, _ = signal.find_peaks(flux, height=thr, distance=max(1, int(0.05 * sr / hop)))
    times = t[peaks] - (n_fft / 2) / sr
    times = np.maximum(times, 0.0)
    order = np.argsort(flux[peaks])[::-1][:max_onsets]
    return sorted(float(round(v, 4)) for v in times[order])


# ---------------------------------------------------------------- dynamics

def limit(x: np.ndarray, sr: int, ceiling_db: float = -1.0, attack_ms_per_db: float = 0.3,
          release_ms_per_db: float = 4.0) -> tuple[np.ndarray, float]:
    """Offline peak limiter with unlimited look-ahead. Returns (y, max gain reduction dB).

    The gain curve in dB is the tightest curve above the required reduction whose
    slope is bounded: ramps down ahead of each peak at `attack_ms_per_db`, recovers
    at `release_ms_per_db`. Computed exactly with running minima (min-plus
    convolution with a linear ramp), so no clicks and no per-sample loop.
    """
    ceiling = undb(ceiling_db)
    x2 = as_2d(np.asarray(x, dtype=np.float64))
    peak = np.abs(x2).max(axis=1)
    if peak.max(initial=0) <= ceiling:
        return x.astype(np.float64), 0.0
    need = np.minimum(0.0, 20 * np.log10(ceiling / np.maximum(peak, 1e-12)))  # <= 0 dB
    k = np.arange(len(need), dtype=np.float64)
    rel = 1.0 / (release_ms_per_db * 1e-3 * sr)  # dB per sample
    att = 1.0 / (attack_ms_per_db * 1e-3 * sr)
    g = rel * k + np.minimum.accumulate(need - rel * k)  # release forward in time
    g = np.minimum(g, 0.0)
    g = np.minimum.accumulate((g + att * k)[::-1])[::-1] - att * k  # attack backward in time
    g = np.minimum(g, need)
    gain = 10 ** (g / 20)
    y = x2 * gain[:, None]
    y = y[:, 0] if x.ndim == 1 else y
    return y, float(g.min())


# ---------------------------------------------------------------- loudness (BS.1770-4)

def k_weighting_sos(sr: int) -> np.ndarray:
    # Pre-filter (high shelf) and RLB high-pass, derived for any sample rate.
    f0, G, Q = 1681.974450955533, 3.999843853973347, 0.7071752369554196
    K = math.tan(math.pi * f0 / sr)
    Vh = 10 ** (G / 20)
    Vb = Vh**0.4996667741545416
    a0 = 1 + K / Q + K * K
    b = [(Vh + Vb * K / Q + K * K) / a0, 2 * (K * K - Vh) / a0, (Vh - Vb * K / Q + K * K) / a0]
    a = [1.0, 2 * (K * K - 1) / a0, (1 - K / Q + K * K) / a0]
    f1, Q1 = 38.13547087602444, 0.5003270373238773
    K = math.tan(math.pi * f1 / sr)
    a1 = [1.0, 2 * (K * K - 1) / (1 + K / Q1 + K * K), (1 - K / Q1 + K * K) / (1 + K / Q1 + K * K)]
    b1 = [1.0, -2.0, 1.0]
    return np.array([b + a, b1 + a1])


def _block_power(x: np.ndarray, sr: int) -> np.ndarray:
    """K-weighted power of 400 ms blocks with 75 % overlap, summed over channels."""
    x2 = as_2d(np.asarray(x, dtype=np.float64))
    if len(x2) < int(0.4 * sr):
        x2 = np.pad(x2, ((0, int(0.4 * sr) - len(x2)), (0, 0)))
    y = signal.sosfilt(k_weighting_sos(sr), x2, axis=0)
    blk, hop = int(0.4 * sr), int(0.1 * sr)
    c = np.concatenate([np.zeros((1, y.shape[1])), np.cumsum(y**2, axis=0)])
    starts = np.arange(0, len(y) - blk + 1, hop)
    return ((c[starts + blk] - c[starts]) / blk).sum(axis=1)


def momentary_max(x: np.ndarray, sr: int) -> float:
    """Loudest 400 ms momentary loudness (LUFS): comparable across decaying and sustained sounds."""
    p = _block_power(x, sr)
    return float(-0.691 + 10 * np.log10(max(float(p.max(initial=0.0)), 1e-20)))


def integrated_loudness(x: np.ndarray, sr: int) -> float:
    """BS.1770-4 gated integrated loudness in LUFS (mono counts as one front channel)."""
    power = _block_power(x, sr)
    lk = -0.691 + 10 * np.log10(np.maximum(power, 1e-20))
    gate = lk > -70
    if not gate.any():
        return -120.0
    rel = -0.691 + 10 * np.log10(power[gate].mean()) - 10
    gate &= lk > rel
    if not gate.any():
        return -120.0
    return float(-0.691 + 10 * np.log10(power[gate].mean()))
