"""Wavetables: a stack of single-cycle frames you can morph through, with band-limited mip levels.

    from libero.forge import Wavetable

    wt = Wavetable.classic("saw")                                   # procedural classic
    wt = Wavetable.from_formula(lambda ph, pos: np.sin(2*np.pi*ph + 6*pos*np.sin(2*np.pi*ph)), frames=32)
    wt = Wavetable.from_harmonics([[1, .5, .25], [1, 0, .33, 0, .2]])   # one spectrum per frame
    wt = Wavetable.from_additive(lambda k, pos: 1/k * (k <= 2 + 30*pos), harmonics=64, frames=48)
    wt = Wavetable.from_audio(libero.load("voice.wav"), frames=64)      # slice a sample into frames
    wt = Wavetable.from_cycle(one_cycle_audio)                          # single-cycle resynthesis

Every frame is stored with 2048 points. For playback the table is pre-filtered into half-octave
mip levels (1024, 724, 512 ... 1 harmonics); the oscillator picks the level whose highest
harmonic stays below Nyquist, so plain playback does not alias. Position 0..1 morphs linearly
between neighbouring frames.
"""

from __future__ import annotations

import math
from typing import Callable, Sequence

import numpy as np
from scipy.signal import resample

from .. import dsp
from ..audio import Audio

SIZE = 2048
LEVELS = [int(math.floor(1024 * 2.0 ** (-l / 2.0))) for l in range(21)]
LEVELS = [h for i, h in enumerate(LEVELS) if h >= 1 and (i == 0 or h != LEVELS[i - 1])]
MAX_FRAMES = 256

VOWELS = {  # formant frequencies (Hz), approximate adult male values
    "a": (800, 1150, 2900, 3900), "e": (400, 1600, 2700, 3300), "i": (350, 1700, 2700, 3400),
    "o": (450, 800, 2830, 3500), "u": (325, 700, 2530, 3300),
}


def _align(cycle: np.ndarray) -> np.ndarray:
    """Rotate a cycle so its fundamental has zero phase (keeps the relative phase of the harmonics),
    so neighbouring frames of a pitch-synchronous slice morph without comb-filtering."""
    s = np.fft.rfft(cycle)
    ph = np.angle(s[1]) if abs(s[1]) > 1e-9 * (np.abs(s).max() + 1e-30) else 0.0
    s = s * np.exp(-1j * ph * np.arange(len(s)))
    return np.fft.irfft(s, len(cycle))


class Wavetable:
    """Frames of one cycle each (F x 2048), normalised per frame (`normalize='frame'`), per table
    ('table') or not at all (None). Use the `from_*` and `classic` constructors; `Wavetable(array)`
    accepts a (F, N) or (N,) array of any cycle length N and resamples it to 2048 points."""

    def __init__(self, frames, name: str = "custom", normalize: str | None = "frame"):
        a = np.asarray(frames, dtype=np.float64)
        if a.ndim == 1:
            a = a[None, :]
        if a.ndim != 2 or a.shape[0] < 1 or a.shape[1] < 4:
            raise ValueError("wavetable frames must be a (frames, samples) array")
        if a.shape[0] > MAX_FRAMES:
            idx = np.linspace(0, a.shape[0] - 1, MAX_FRAMES).round().astype(int)
            a = a[idx]
        if a.shape[1] != SIZE:
            a = resample(a, SIZE, axis=1)
        a = a - a.mean(axis=1, keepdims=True)
        if not np.all(np.isfinite(a)):
            raise ValueError("wavetable contains NaN/inf")
        if normalize == "frame":
            a = a / np.maximum(np.abs(a).max(axis=1, keepdims=True), 1e-9)
        elif normalize == "table":
            a = a / max(np.abs(a).max(), 1e-9)
        self.frames = a
        self.name = name
        self._mips: np.ndarray | None = None

    # ------------------------------------------------------------ properties

    @property
    def n_frames(self) -> int:
        return int(self.frames.shape[0])

    def __repr__(self) -> str:
        return f"Wavetable('{self.name}', frames={self.n_frames})"

    def frame(self, position: float) -> np.ndarray:
        """The 2048-point cycle at position 0..1 (linear morph between frames)."""
        p = float(np.clip(position, 0, 1)) * (self.n_frames - 1)
        i = int(p)
        j = min(i + 1, self.n_frames - 1)
        return self.frames[i] * (1 - (p - i)) + self.frames[j] * (p - i)

    @property
    def mips(self) -> np.ndarray:
        """(levels, frames, 2048) float32 band-limited copies; level l keeps `LEVELS[l]` harmonics."""
        if self._mips is None:
            spec = np.fft.rfft(self.frames, axis=1)
            out = np.empty((len(LEVELS), self.n_frames, SIZE), dtype=np.float32)
            for l, h in enumerate(LEVELS):
                s = spec.copy()
                s[:, h + 1:] = 0.0
                s[:, 0] = 0.0
                out[l] = np.fft.irfft(s, SIZE, axis=1)
            self._mips = out
        return self._mips

    def level_harmonics(self) -> np.ndarray:
        return np.asarray(LEVELS, dtype=np.float64)

    def to_audio(self, freq: float = 110.0, dur: float = 2.0, sr: int = 48000, sweep: bool = True) -> Audio:
        """Quick preview: play the table at `freq`, sweeping position 0 -> 1 over `dur` (or frame 0)."""
        from .osc import Osc
        from .patch import Patch
        osc = Osc(table=self, pos=0.0)
        p = Patch("preview", oscs=[osc])
        if sweep:
            from .modulation import LFO, Mod
            p = Patch("preview", oscs=[osc], lfos=[LFO("saw", rate=1.0 / dur, mode="trig")],
                      mods=[Mod("lfo1", "osc1.pos", 0.5, bipolar=False)])
        return p.render(dsp.freq_to_midi(freq), 100, dur, sr, tail=0.0)

    # ------------------------------------------------------------ constructors

    @classmethod
    def from_formula(cls, fn: Callable, frames: int = 32, name: str = "formula", oversample: int = 4,
                     normalize: str | None = "frame") -> "Wavetable":
        """Table from `fn(phase, position) -> samples`, where `phase` is an array in [0, 1) and
        `position` a float 0..1 (frame index / (frames-1)). Evaluated at `oversample` x resolution and
        band-limited to the table's top level, so sharp formulas (saw, clip) do not fold back."""
        n = SIZE * oversample
        ph = np.arange(n) / n
        out = np.empty((frames, SIZE))
        for i in range(frames):
            pos = i / max(frames - 1, 1)
            try:
                y = np.asarray(fn(ph, pos), dtype=np.float64)
                if y.shape != ph.shape:
                    raise ValueError
            except (TypeError, ValueError):
                y = np.array([float(fn(float(p), pos)) for p in ph])
            s = np.fft.rfft(y)[: SIZE // 2 + 1]
            s[LEVELS[0] + 1:] = 0.0
            out[i] = np.fft.irfft(s, SIZE) * (SIZE / n)
        return cls(out, name, normalize)

    @classmethod
    def from_harmonics(cls, spectra: Sequence[Sequence[float]], phases: Sequence[Sequence[float]] | None = None,
                       name: str = "harmonics", normalize: str | None = "frame") -> "Wavetable":
        """One frame per spectrum: `spectra[i][k]` is the amplitude of harmonic k+1 (cosine-phase 0 =
        sine unless `phases[i][k]` radians are given). Exactly band-limited."""
        out = np.zeros((len(spectra), SIZE))
        for i, amps in enumerate(spectra):
            amps = np.asarray(amps, dtype=np.float64)[: SIZE // 2 - 1]
            ph = np.zeros_like(amps) if phases is None else np.asarray(phases[i], dtype=np.float64)[: len(amps)]
            spec = np.zeros(SIZE // 2 + 1, dtype=np.complex128)
            spec[1: len(amps) + 1] = amps * np.exp(1j * (ph - np.pi / 2))
            out[i] = np.fft.irfft(spec, SIZE) * (SIZE / 2)
        return cls(out, name, normalize)

    @classmethod
    def from_additive(cls, amp: Callable, phase: Callable | None = None, harmonics: int = 64, frames: int = 32,
                      name: str = "additive", normalize: str | None = "frame") -> "Wavetable":
        """Additive series: `amp(k, position)` is the amplitude of harmonic `k` (an int array 1..harmonics)
        at morph position 0..1; optional `phase(k, position)` in radians. Vectorised over k."""
        k = np.arange(1, harmonics + 1)
        spectra, phases = [], []
        for i in range(frames):
            pos = i / max(frames - 1, 1)
            spectra.append(np.broadcast_to(np.asarray(amp(k, pos), dtype=np.float64), k.shape))
            if phase is not None:
                phases.append(np.broadcast_to(np.asarray(phase(k, pos), dtype=np.float64), k.shape))
        return cls.from_harmonics(spectra, phases if phase is not None else None, name, normalize)

    @classmethod
    def from_cycle(cls, audio: Audio, name: str = "cycle") -> "Wavetable":
        """One-frame table from a recorded single cycle (any length): resampled to 2048 points, DC removed."""
        x = dsp.mono(audio.data.astype(np.float64))
        if len(x) < 8:
            raise ValueError("cycle too short")
        return cls(_align(resample(x - x.mean(), SIZE))[None, :], name)

    @classmethod
    def from_audio(cls, audio: Audio, frames: int = 64, mode: str = "auto", f0: float | None = None,
                   t0: float = 0.0, t1: float | None = None, name: str = "audio") -> "Wavetable":
        """Slice a sample into `frames` morphing frames between t0 and t1.
        mode 'cycle': pitch-synchronous, each frame is exactly one period (needs f0; detected when
        omitted) - best for voiced, pitched material. 'window': each frame is a window of ~2048
        samples read as a cycle - gritty, good for noise, drums, textures. 'spectral': the magnitude
        spectrum of each window, rebuilt as harmonics of 2048 (timbre without phase). 'auto' picks
        'cycle' when a pitch is found, else 'window'."""
        x = dsp.mono(audio.data.astype(np.float64))
        sr = audio.sr
        a, b = int(t0 * sr), len(x) if t1 is None else int(t1 * sr)
        x = x[a:b]
        if len(x) < 64:
            raise ValueError("sample region too short")
        if mode == "auto":
            if f0 is None:
                f0v, voiced = dsp.estimate_f0(x, sr, 40.0, 1500.0)
                f0 = f0v if np.isfinite(f0v) and voiced > 0.4 else None
            mode = "cycle" if f0 else "window"
        elif mode == "cycle" and f0 is None:
            f0, _ = dsp.estimate_f0(x, sr, 40.0, 1500.0)
            if not np.isfinite(f0):
                raise ValueError("no pitch found; pass f0= or use mode='window'")
        centers = np.linspace(0, len(x), frames + 2)[1:-1].astype(int)
        out = np.zeros((frames, SIZE))
        if mode == "cycle":
            L = sr / f0
            for i, c in enumerate(centers):
                s = int(np.clip(c - L / 2, 0, max(len(x) - L - 2, 0)))
                seg = x[s: s + int(round(L))]
                out[i] = _align(resample(seg - seg.mean(), SIZE)) if len(seg) > 8 else 0.0
        elif mode == "window":
            win = min(SIZE, len(x))
            for i, c in enumerate(centers):
                s = int(np.clip(c - win // 2, 0, len(x) - win))
                seg = x[s: s + win]
                out[i] = resample(seg, SIZE) if win != SIZE else seg
        elif mode == "spectral":
            win = min(4096, len(x))
            hann = np.hanning(win)
            for i, c in enumerate(centers):
                s = int(np.clip(c - win // 2, 0, len(x) - win))
                mag = np.abs(np.fft.rfft(x[s: s + win] * hann))
                fr = np.fft.rfftfreq(win, 1 / sr)
                k = np.arange(1, 256)
                base = f0 or 110.0
                amps = np.interp(k * base, fr, mag)
                spec = np.zeros(SIZE // 2 + 1, dtype=np.complex128)
                spec[1:256] = amps * np.exp(-1j * np.pi / 2)
                out[i] = np.fft.irfft(spec, SIZE)
        else:
            raise ValueError("mode must be auto, cycle, window or spectral")
        return cls(out, name)

    @classmethod
    def morph(cls, *tables: "Wavetable", frames_each: int = 16, name: str = "morph") -> "Wavetable":
        """Chain tables end to end, crossfading `frames_each` frames between their last/first frames."""
        parts = []
        for i, t in enumerate(tables):
            parts.append(t.frames)
            if i + 1 < len(tables):
                a, b = t.frames[-1], tables[i + 1].frames[0]
                w = np.linspace(0, 1, frames_each + 2)[1:-1, None]
                parts.append(a[None] * (1 - w) + b[None] * w)
        return cls(np.concatenate(parts), name)

    @classmethod
    def classic(cls, name: str = "saw", frames: int | None = None) -> "Wavetable":
        """Procedural classic tables (all exactly band-limited, generated not sampled):

        sine, saw, square, tri       single-frame basics
        pulse        pulse width sweeping 50% -> 4%
        pwm          square whose duty sweeps 50% -> 5% (identical spectrum family, many frames)
        sine_saw     sine -> saw, harmonics fade in
        saw_square   saw -> square
        tri_saw      triangle -> saw
        supersaw     saw -> stack of phase-offset saws (comb-like thickness inside one cycle)
        vocal        formant vowels a e i o u, morphing
        digital      harsh digital: random-phase harmonic series that tighten with position
        organ        drawbar organ registrations
        fm           2-op FM sweep, index 0 -> 8
        bell         inharmonic-ish bell-like partial set (harmonic approximation)
        noise_cycle  random cycle per frame (a buzzy noise table)"""
        key = name.lower()
        fr = frames
        k = np.arange(1, 512)
        if key == "sine":
            return cls.from_harmonics([[1.0]], name=key)
        if key == "saw":
            return cls.from_harmonics([1.0 / k], [np.full(k.shape, np.pi)], name=key)
        if key == "square":
            return cls.from_harmonics([np.where(k % 2 == 1, 1.0 / k, 0.0)], name=key)
        if key == "tri":
            sgn = np.where(((k - 1) // 2) % 2 == 0, 1.0, -1.0)
            return cls.from_harmonics([np.where(k % 2 == 1, sgn / k**2, 0.0)], name=key)
        if key in ("pulse", "pwm"):
            fr = fr or (32 if key == "pulse" else 64)
            spectra, phases = [], []
            for i in range(fr):
                duty = 0.5 - 0.46 * i / max(fr - 1, 1)
                c = (1.0 - np.exp(-2j * np.pi * k * duty)) / k
                spectra.append(np.abs(c))
                phases.append(np.angle(c))
            return cls.from_harmonics(spectra, phases, name=key)
        if key == "sine_saw":
            return cls.from_additive(lambda kk, p: np.where(kk == 1, 1.0, (1.0 / kk) * p ** 1.5), harmonics=511, frames=fr or 32, name=key)
        if key == "saw_square":
            return cls.from_additive(lambda kk, p: (1.0 / kk) * np.where(kk % 2 == 1, 1.0, 1.0 - p), harmonics=511, frames=fr or 32, name=key)
        if key == "tri_saw":
            return cls.from_additive(lambda kk, p: (1.0 / kk) * np.where(kk % 2 == 1, 1.0 / np.maximum(kk ** (1 - p), 1.0), p), harmonics=511, frames=fr or 32, name=key)
        if key == "supersaw":
            fr = fr or 32
            spectra, phases = [], []
            rng = np.random.default_rng(7)
            offs = np.array([0.0, 0.113, 0.331, 0.529, 0.787, 0.941, 0.221])
            for i in range(fr):
                p = i / max(fr - 1, 1)
                n_saws = 1 + int(round(6 * p))
                c = sum(np.exp(-2j * np.pi * k * offs[j] * 0.35) * (1 - 0.15 * j) for j in range(n_saws))
                c = c * (1.0 + 0.15 * p * np.exp(1j * rng.uniform(0, 2 * np.pi, k.shape)))
                spectra.append(np.abs(c) / k)
                phases.append(np.angle(c))
            return cls.from_harmonics(spectra, phases, name=key)
        if key == "vocal":
            fr = fr or 40
            vs = list(VOWELS.values())
            f0 = 110.0
            spectra = []
            for i in range(fr):
                p = i / max(fr - 1, 1) * (len(vs) - 1)
                a, fl = int(min(p, len(vs) - 2)), p - int(min(p, len(vs) - 2))
                forms = [vs[a][j] * (1 - fl) + vs[a + 1][j] * fl for j in range(4)]
                freq = k * f0
                env = sum(g / (1 + ((freq - f) / (0.07 * f + 40)) ** 2) for f, g in zip(forms, (1.0, 0.6, 0.35, 0.2)))
                spectra.append((1.0 / k**0.9) * (env + 0.02))
            return cls.from_harmonics(spectra, name=key)
        if key == "digital":
            fr = fr or 32
            rng = np.random.default_rng(11)
            ph = rng.uniform(0, 2 * np.pi, k.shape)
            spectra = [(1.0 / k ** (0.25 + 0.75 * (1 - i / max(fr - 1, 1)))) * (0.5 + 0.5 * np.sin(k * (0.5 + 5 * i / max(fr - 1, 1))))
                       for i in range(fr)]
            return cls.from_harmonics(spectra, [ph] * fr, name=key)
        if key == "organ":
            fr = fr or 16
            regs = np.zeros((fr, 9))
            rng = np.random.default_rng(3)
            for i in range(fr):
                regs[i] = rng.integers(0, 9, 9) / 8.0 if i else np.array([8, 8, 8, 0, 0, 0, 0, 0, 0]) / 8.0
            harm = [1, 3, 2, 4, 6, 8, 10, 12, 16]
            spectra = []
            for i in range(fr):
                s = np.zeros(20)
                for j, h in enumerate(harm):
                    s[h - 1] += regs[i, j] + 0.02
                spectra.append(s)
            return cls.from_harmonics(spectra, name=key)
        if key == "fm":
            fr = fr or 32
            return cls.from_formula(lambda ph, p: np.sin(2 * np.pi * ph + 8 * p * np.sin(2 * np.pi * ph * 2)), fr, key)
        if key == "bell":
            fr = fr or 24
            return cls.from_additive(lambda kk, p: np.where((kk * 7) % 11 < 4 + 7 * p, 1.0 / kk ** (1.0 - 0.5 * p), 0.02 / kk), harmonics=128, frames=fr, name=key)
        if key == "noise_cycle":
            fr = fr or 16
            rng = np.random.default_rng(5)
            return cls(rng.standard_normal((fr, SIZE)), key)
        raise ValueError(f"unknown classic table '{name}': {', '.join(CLASSICS)}")


CLASSICS = ("sine", "saw", "square", "tri", "pulse", "pwm", "sine_saw", "saw_square", "tri_saw", "supersaw",
            "vocal", "digital", "organ", "fm", "bell", "noise_cycle")

_cache: dict[str, Wavetable] = {}


def get_table(t) -> Wavetable:
    """A Wavetable from a Wavetable, a classic name, an Audio (single cycle) or a (F,N) array."""
    if isinstance(t, Wavetable):
        return t
    if isinstance(t, str):
        if t not in _cache:
            _cache[t] = Wavetable.classic(t)
        return _cache[t]
    if isinstance(t, Audio):
        return Wavetable.from_cycle(t)
    return Wavetable(t)
