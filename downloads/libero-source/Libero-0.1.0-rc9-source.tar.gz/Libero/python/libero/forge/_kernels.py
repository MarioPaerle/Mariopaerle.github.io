"""numba kernels for libero.forge. Plain float64 arrays in, arrays out; the public modules
prepare per-sample parameter arrays and call these."""

from __future__ import annotations

import math

import numpy as np
from numba import njit

LN2 = math.log(2.0)


# ---------------------------------------------------------------- oscillator

@njit(cache=True, inline="always")
def _warp(mode, a, x):
    """Phase warp: returns (new phase in [0,1), bandwidth multiplier used to pick the mip level)."""
    if mode == 0 or a <= 0.0:
        return x, 1.0
    if mode == 1:  # sync
        r = 1.0 + 7.0 * a
        y = x * r
        return y - math.floor(y), r
    if mode == 2:  # bend +
        k = 1.0 + 3.0 * a
        return x ** k, k
    if mode == 3:  # bend -
        k = 1.0 + 3.0 * a
        return 1.0 - (1.0 - x) ** k, k
    if mode == 4:  # bend +/-  (0.5 neutral)
        s = (a - 0.5) * 2.0
        k = 1.0 + 3.0 * abs(s)
        if s >= 0.0:
            return x ** k, k
        return 1.0 - (1.0 - x) ** k, k
    if mode == 5:  # pwm: waveform squeezed into the first part of the cycle, then held
        w = 1.0 - 0.92 * a
        y = x / w
        if y > 0.999999:
            y = 0.999999
        return y, 1.0 / w
    if mode == 6 or mode == 7:  # asym + / -
        w = 0.5 + 0.45 * a if mode == 6 else 0.5 - 0.45 * a
        if x < w:
            y = 0.5 * x / w
        else:
            y = 0.5 + 0.5 * (x - w) / (1.0 - w)
        m = w if w < 1.0 - w else 1.0 - w
        return y, 0.5 / m
    if mode == 8:  # mirror
        return (1.0 - a) * x + a * (1.0 - abs(2.0 * x - 1.0)), 1.0 + a
    if mode == 9:  # remap: phase distortion
        return x - 0.9 * a * math.sin(6.283185307179586 * x) / 6.283185307179586, 1.0 + 2.0 * a
    if mode == 10:  # quantize phase
        s = 2.0 + 254.0 * (1.0 - a) ** 2
        return math.floor(x * s) / s, 4.0
    return x, 1.0


@njit(cache=True)
def osc_kernel(tabs, lvlh, freq, pos, m1, a1, m2, a2, mm, am, ext, dcents, u, w, panl, panr, ph0, sr):
    """Wavetable oscillator with unison. tabs (L,F,N) mip tables, lvlh (L,) harmonics per level.
    m1/m2: phase-warp mode ids with per-sample amounts a1/a2. mm/am: amplitude-stage mode
    (0 none, 21 AM, 22 RM) and its amount. ext: modulator signal for FM/AM/RM. Voice v runs at
    freq*2^(u[v]*dcents/1200). Returns (n,2)."""
    L = tabs.shape[0]
    F = tabs.shape[1]
    N = tabs.shape[2]
    n = freq.shape[0]
    V = u.shape[0]
    out = np.zeros((n, 2))
    ph = ph0.copy()
    nyq = 0.49 * sr
    mask = N - 1
    for j in range(n):
        fpos = pos[j] * (F - 1)
        if fpos < 0.0:
            fpos = 0.0
        if fpos > F - 1:
            fpos = float(F - 1)
        fr0 = int(fpos)
        frf = fpos - fr0
        fr1 = fr0 + 1 if fr0 + 1 < F else fr0
        e = ext[j]
        fb = freq[j]
        dc = dcents[j]
        for v in range(V):
            f = fb * math.exp(u[v] * dc * LN2 / 1200.0) if dc != 0.0 else fb
            inc = f / sr
            phi = ph[v]
            x = phi
            x, b1 = _warp(m1, a1[j], x)
            x, b2 = _warp(m2, a2[j], x)
            bw = b1 * b2
            if m1 == 20 or m2 == 20:
                am_ = a1[j] if m1 == 20 else a2[j]
                x = x + 2.0 * am_ * e
                x = x - math.floor(x)
                bw = bw * (1.0 + 3.0 * am_)
            lv = 0
            feff = f * bw
            while lv < L - 1 and lvlh[lv] * feff > nyq:
                lv += 1
            idx = x * N
            i0 = int(idx)
            fr = idx - i0
            i0 = i0 & mask
            i1 = (i0 + 1) & mask
            s0 = tabs[lv, fr0, i0] * (1.0 - fr) + tabs[lv, fr0, i1] * fr
            if frf > 0.0:
                s1 = tabs[lv, fr1, i0] * (1.0 - fr) + tabs[lv, fr1, i1] * fr
                s0 = s0 * (1.0 - frf) + s1 * frf
            if mm == 21:
                s0 = s0 * ((1.0 - am[j]) + am[j] * (0.5 + 0.5 * e))
            elif mm == 22:
                s0 = s0 * ((1.0 - am[j]) + am[j] * e)
            s0 *= w[v]
            out[j, 0] += s0 * panl[v]
            out[j, 1] += s0 * panr[v]
            phi += inc
            phi -= math.floor(phi)
            ph[v] = phi
    return out


# ---------------------------------------------------------------- modulators

@njit(cache=True, inline="always")
def _curve(x, c):
    if abs(c) < 1e-3:
        return x
    return (math.exp(c * 6.0 * x) - 1.0) / (math.exp(c * 6.0) - 1.0)


@njit(cache=True)
def env_kernel(trig, gate, sr, delay, att, hold, dec, sus, rel, ca, cd, cr):
    n = trig.shape[0]
    out = np.zeros(n)
    ds = int(delay * sr)
    as_ = max(1, int(att * sr))
    hs = int(hold * sr)
    dcs = max(1, int(dec * sr))
    rs = max(1, int(rel * sr))
    state = 0
    val = 0.0
    v0 = 0.0
    t = 0
    for i in range(n):
        if trig[i]:
            state = 1 if ds > 0 else 2
            t = 0
            v0 = val
        if state > 0 and state < 6 and not gate[i]:
            state = 6
            t = 0
            v0 = val
        if state == 1:
            t += 1
            if t >= ds:
                state = 2
                t = 0
                v0 = val
        elif state == 2:
            x = t / as_
            val = v0 + (1.0 - v0) * _curve(x, ca)
            t += 1
            if t >= as_:
                val = 1.0
                state = 3 if hs > 0 else 4
                t = 0
        elif state == 3:
            val = 1.0
            t += 1
            if t >= hs:
                state = 4
                t = 0
        elif state == 4:
            x = t / dcs
            val = sus + (1.0 - sus) * (1.0 - _curve(x, cd))
            t += 1
            if t >= dcs:
                val = sus
                state = 5
        elif state == 5:
            val = sus
        elif state == 6:
            x = t / rs
            val = v0 * (1.0 - _curve(x, cr))
            t += 1
            if t >= rs:
                val = 0.0
                state = 0
        out[i] = val
    return out


@njit(cache=True, inline="always")
def _bp_interp(xs, ys, cs, p):
    m = xs.shape[0]
    if p <= xs[0]:
        return ys[0]
    for k in range(m - 1):
        if p < xs[k + 1]:
            span = xs[k + 1] - xs[k]
            q = (p - xs[k]) / span if span > 0 else 1.0
            q = _curve(q, cs[k])
            return ys[k] + (ys[k + 1] - ys[k]) * q
    return ys[m - 1]


@njit(cache=True, inline="always")
def _lfo_shape(shape, p, cur, nxt, xs, ys, cs):
    if shape == 0:
        return math.sin(6.283185307179586 * p)
    if shape == 1:
        return 4.0 * p - 1.0 if p < 0.5 else 3.0 - 4.0 * p
    if shape == 2:
        return 2.0 * p - 1.0
    if shape == 3:
        return 1.0 - 2.0 * p
    if shape == 4:
        return 1.0 if p < 0.5 else -1.0
    if shape == 5:
        return cur
    if shape == 6:
        q = 0.5 - 0.5 * math.cos(math.pi * p)
        return cur + (nxt - cur) * q
    return _bp_interp(xs, ys, cs, p)


@njit(cache=True)
def lfo_kernel(trig, rate, sr, shape, mode, phase0, t0, delay, fade, seed, xs, ys, cs):
    """mode 0 trig (phase reset on trigger), 1 free (phase from absolute time), 2 env (one cycle per trigger)."""
    n = trig.shape[0]
    out = np.zeros(n)
    np.random.seed(seed)
    cur = np.random.uniform(-1.0, 1.0)
    nxt = np.random.uniform(-1.0, 1.0)
    p = phase0 - math.floor(phase0)
    if mode == 1:
        p = (phase0 + rate[0] * t0 / sr) % 1.0
    since = 0
    running = mode != 2
    done = False
    for i in range(n):
        if trig[i]:
            since = 0
            if mode != 1:
                p = phase0 - math.floor(phase0)
                cur = nxt
                nxt = np.random.uniform(-1.0, 1.0)
                running = True
                done = False
        v = _lfo_shape(shape, p, cur, nxt, xs, ys, cs)
        if done:
            v = _lfo_shape(shape, 0.999999, cur, nxt, xs, ys, cs)
        g = 1.0
        if since < delay:
            g = 0.0
        elif fade > 0 and since < delay + fade:
            g = (since - delay) / fade
        out[i] = v * g
        since += 1
        if running and not done:
            p += rate[i] / sr
            if p >= 1.0:
                if mode == 2:
                    done = True
                    p = 0.999999
                else:
                    p -= math.floor(p)
                    cur = nxt
                    nxt = np.random.uniform(-1.0, 1.0)
    return out


# ---------------------------------------------------------------- filters

@njit(cache=True)
def svf_kernel(x, fc, res, drive, morph, mode, poles, sr):
    """TPT state-variable filter. mode 0 lp, 1 hp, 2 bp, 3 notch, 4 morph (lp->bp->hp)."""
    n = x.shape[0]
    y = np.empty(n)
    ic1 = np.zeros(2)
    ic2 = np.zeros(2)
    nst = 2 if poles == 2 else 1
    fmax = 0.49 * sr
    for i in range(n):
        f = fc[i]
        if f < 10.0:
            f = 10.0
        if f > fmax:
            f = fmax
        g = math.tan(math.pi * f / sr)
        r = res[i]
        d = 1.0 + 6.0 * drive[i]
        s = x[i]
        if drive[i] > 1e-4:
            s = math.tanh(d * s) / math.sqrt(d)
        for st in range(nst):
            xin = s
            if poles == 2:
                qb = 0.5412 if st == 0 else 1.3065
                if mode >= 2:
                    qb = 0.7071
                q = qb * (1.0 + 12.0 * r * r)
            else:
                q = 0.7071 * (1.0 + 24.0 * r * r)
            k = 1.0 / q
            a1 = 1.0 / (1.0 + g * (g + k))
            a2 = g * a1
            a3 = g * a2
            v3 = xin - ic2[st]
            v1 = a1 * ic1[st] + a2 * v3
            v2 = ic2[st] + a2 * ic1[st] + a3 * v3
            ic1[st] = 2.0 * v1 - ic1[st]
            ic2[st] = 2.0 * v2 - ic2[st]
            if drive[i] > 1e-4:
                ic1[st] = math.tanh(ic1[st])
            if mode == 0:
                s = v2
            elif mode == 1:
                s = xin - k * v1 - v2
            elif mode == 2:
                s = k * v1
            elif mode == 3:
                s = xin - k * v1
            else:
                m = morph[i]
                wl = 1.0 - 2.0 * m
                if wl < 0.0:
                    wl = 0.0
                wh = 2.0 * m - 1.0
                if wh < 0.0:
                    wh = 0.0
                wb = 1.0 - wl - wh
                s = wl * v2 + wb * k * v1 + wh * (xin - k * v1 - v2)
        y[i] = s
    return y


@njit(cache=True)
def ladder_kernel(x, fc, res, drive, sr, diode):
    """Zero-delay-feedback 4-pole ladder. Cutoff = frequency of the resonance peak.
    diode=1 gives an asymmetric, softer-slope diode-style variant."""
    n = x.shape[0]
    y = np.empty(n)
    z = np.zeros(4)
    hpz = 0.0
    fmax = 0.45 * sr
    for i in range(n):
        f = fc[i]
        if f < 10.0:
            f = 10.0
        if f > fmax:
            f = fmax
        g = math.tan(math.pi * f / sr)
        G = g / (1.0 + g)
        k = 3.95 * res[i]
        if diode == 1:
            k = 3.3 * res[i]
        S = (G * G * G * z[0] + G * G * z[1] + G * z[2] + z[3]) / (1.0 + g)
        if diode == 1:
            hpz += 0.004 * (S - hpz)
            S = S - hpz
        u = (x[i] - k * S) / (1.0 + k * G * G * G * G)
        d = 1.0 + 6.0 * drive[i]
        u = math.tanh(d * u) / math.sqrt(d)
        s_in = u
        for st in range(4):
            v = (s_in - z[st]) * G
            ys = v + z[st]
            z[st] = ys + v
            if diode == 1:
                ys = math.tanh(ys + 0.2) - 0.19738
            s_in = ys
        y[i] = s_in
    return y


@njit(cache=True)
def comb_kernel(x, fc, res, sign, flange, sr):
    """Feedback comb (flange=0) or flanger-style feed-forward/back mix (flange=1). Delay = 1/cutoff."""
    n = x.shape[0]
    size = int(sr / 10.0) + 8
    buf = np.zeros(size)
    y = np.empty(n)
    w = 0
    dz = 0.0
    fmax = 0.45 * sr
    for i in range(n):
        f = fc[i]
        if f < 20.0:
            f = 20.0
        if f > fmax:
            f = fmax
        d = sr / f - 0.1765
        if d < 1.0:
            d = 1.0
        if d > size - 4:
            d = size - 4.0
        r = w - d
        i0 = int(math.floor(r))
        fr = r - i0
        a = buf[i0 % size]
        b = buf[(i0 + 1) % size]
        wet = a * (1.0 - fr) + b * fr
        dz += 0.85 * (wet - dz)
        fb = 0.97 * res[i] * sign
        if flange == 1:
            buf[w] = x[i] + fb * dz
            y[i] = 0.5 * (x[i] + sign * dz)
        else:
            o = x[i] + fb * dz
            buf[w] = o
            y[i] = o * (1.0 - 0.7 * abs(fb))
        w += 1
        if w >= size:
            w = 0
    return y


@njit(cache=True)
def phaser_kernel(x, fc, fb, nst, depth, sr):
    n = x.shape[0]
    y = np.empty(n)
    z = np.zeros(16)
    last = 0.0
    fmax = 0.45 * sr
    for i in range(n):
        f = fc[i]
        if f < 20.0:
            f = 20.0
        if f > fmax:
            f = fmax
        t = math.tan(math.pi * f / sr)
        a = (t - 1.0) / (t + 1.0)
        s = x[i] + fb[i] * last
        for k in range(nst):
            o = a * s + z[k]
            z[k] = s - a * o
            s = o
        last = math.tanh(s)
        dp = depth[i]
        y[i] = x[i] * (1.0 - 0.5 * dp) + 0.5 * dp * s
    return y


@njit(cache=True)
def formant_kernel(x, shift, morph, res, sr, vf, vq, vg):
    n = x.shape[0]
    y = np.empty(n)
    ic1 = np.zeros(3)
    ic2 = np.zeros(3)
    nv = vf.shape[0]
    fmax = 0.45 * sr
    for i in range(n):
        m = morph[i] * (nv - 1)
        i0 = int(m)
        if i0 >= nv - 1:
            i0 = nv - 2
        fr = m - i0
        acc = 0.0
        for b in range(3):
            fl = math.log(vf[i0, b]) * (1.0 - fr) + math.log(vf[i0 + 1, b]) * fr
            f = math.exp(fl) * shift[i]
            if f > fmax:
                f = fmax
            q = (vq[i0, b] * (1.0 - fr) + vq[i0 + 1, b] * fr) * (0.5 + 1.5 * res[i])
            gn = vg[i0, b] * (1.0 - fr) + vg[i0 + 1, b] * fr
            g = math.tan(math.pi * f / sr)
            k = 1.0 / q
            a1 = 1.0 / (1.0 + g * (g + k))
            a2 = g * a1
            a3 = g * a2
            v3 = x[i] - ic2[b]
            v1 = a1 * ic1[b] + a2 * v3
            v2 = ic2[b] + a2 * ic1[b] + a3 * v3
            ic1[b] = 2.0 * v1 - ic1[b]
            ic2[b] = 2.0 * v2 - ic2[b]
            acc += gn * k * v1
        y[i] = acc
    return y


# ---------------------------------------------------------------- fx kernels

@njit(cache=True)
def mod_delay_kernel(x, dly, fb, damp):
    """Delay line with per-sample delay (in samples, linear interpolation); returns the wet signal."""
    n = x.shape[0]
    size = int(dly.max()) + 4
    buf = np.zeros(size)
    out = np.empty(n)
    w = 0
    dz = 0.0
    for i in range(n):
        d = dly[i]
        if d < 1.0:
            d = 1.0
        r = w - d
        i0 = int(math.floor(r))
        fr = r - i0
        a = buf[i0 % size]
        b = buf[(i0 + 1) % size]
        wet = a * (1.0 - fr) + b * fr
        dz += (1.0 - damp) * (wet - dz)
        buf[w] = x[i] + fb * dz
        out[i] = wet
        w += 1
        if w >= size:
            w = 0
    return out


@njit(cache=True)
def delay_kernel(xl, xr, tl, tr, fb, mode, a_lp, a_hp):
    """Stereo delay. mode 0 stereo, 1 ping-pong, 2 mono. Feedback is low/high-passed (one-pole)."""
    n = xl.shape[0]
    size = int(max(tl, tr)) + 4
    bl = np.zeros(size)
    br = np.zeros(size)
    ol = np.empty(n)
    orr = np.empty(n)
    w = 0
    lpl = 0.0
    lpr = 0.0
    hpl = 0.0
    hpr = 0.0
    for i in range(n):
        rl = w - tl
        i0 = int(math.floor(rl))
        fr = rl - i0
        dl = bl[i0 % size] * (1.0 - fr) + bl[(i0 + 1) % size] * fr
        rr = w - tr
        i0 = int(math.floor(rr))
        fr = rr - i0
        dr = br[i0 % size] * (1.0 - fr) + br[(i0 + 1) % size] * fr
        lpl += a_lp * (dl - lpl)
        lpr += a_lp * (dr - lpr)
        hpl += a_hp * (lpl - hpl)
        hpr += a_hp * (lpr - hpr)
        fl = lpl - hpl
        frr = lpr - hpr
        f = fb[i]
        if mode == 1:
            m = 0.5 * (xl[i] + xr[i])
            bl[w] = m + f * frr
            br[w] = f * fl
        elif mode == 2:
            m = 0.5 * (xl[i] + xr[i])
            bl[w] = m + f * fl
            br[w] = m + f * frr
        else:
            bl[w] = xl[i] + f * fl
            br[w] = xr[i] + f * frr
        ol[i] = dl
        orr[i] = dr
        w += 1
        if w >= size:
            w = 0
    return ol, orr


@njit(cache=True)
def fdn_kernel(inl, inr, lens, g, damp, pre, dlens, mod_depth, mod_rate, sr):
    """8-line feedback delay network with Hadamard mixing, input diffusion and slowly modulated lines."""
    n = inl.shape[0]
    L = lens.shape[0]
    maxlen = int(lens.max()) + int(mod_depth) + 8
    buf = np.zeros((L, maxlen))
    pbuf = np.zeros(max(pre, 1) + 2)
    nd = dlens.shape[0]
    dbuf = np.zeros((nd, int(dlens.max()) + 2))
    dptr = np.zeros(nd, dtype=np.int64)
    lp = np.zeros(L)
    rd = np.zeros(L)
    outl = np.empty(n)
    outr = np.empty(n)
    w = 0
    pw = 0
    t = np.zeros(L)
    ph = np.zeros(L)
    for k in range(L):
        ph[k] = k / L
    for i in range(n):
        m = 0.5 * (inl[i] + inr[i])
        if pre > 0:
            pbuf[pw] = m
            pw = (pw + 1) % (pre + 1)
            m = pbuf[pw]
        for k in range(nd):
            dl = int(dlens[k])
            p = dptr[k]
            dv = dbuf[k, p]
            v = m + 0.6 * dv
            dbuf[k, p] = v
            m = dv - 0.6 * v
            dptr[k] = (p + 1) % dl
        for k in range(L):
            dd = lens[k] + mod_depth * math.sin(6.283185307179586 * (ph[k] + mod_rate * i / sr))
            r = w - dd
            i0 = int(math.floor(r))
            fr = r - i0
            a = buf[k, i0 % maxlen]
            b = buf[k, (i0 + 1) % maxlen]
            v = a * (1.0 - fr) + b * fr
            lp[k] += damp * (v - lp[k])
            rd[k] = lp[k] * g[k]
        # fast Walsh-Hadamard (L = 8)
        h = 1
        for k in range(L):
            t[k] = rd[k]
        while h < L:
            for s in range(0, L, 2 * h):
                for q in range(s, s + h):
                    a2 = t[q]
                    b2 = t[q + h]
                    t[q] = a2 + b2
                    t[q + h] = a2 - b2
            h *= 2
        sc = 1.0 / math.sqrt(L)
        ol = 0.0
        orr = 0.0
        for k in range(L):
            buf[k, w] = m * 0.35 + t[k] * sc
            if k % 2 == 0:
                ol += lp[k]
            else:
                orr += lp[k]
        outl[i] = ol * 1.6
        outr[i] = orr * 1.6
        w += 1
        if w >= maxlen:
            w = 0
    return outl, outr


@njit(cache=True)
def comp_kernel(xl, xr, thr_db, ratio, knee, att, rel, sr, rms):
    n = xl.shape[0]
    ol = np.empty(n)
    orr = np.empty(n)
    gr = np.empty(n)
    ac = 1.0 - math.exp(-1.0 / (max(att, 1e-5) * sr))
    rc = 1.0 - math.exp(-1.0 / (max(rel, 1e-4) * sr))
    env = 0.0
    slope = 1.0 / ratio - 1.0
    for i in range(n):
        if rms == 1:
            lv = math.sqrt(0.5 * (xl[i] * xl[i] + xr[i] * xr[i]))
        else:
            lv = max(abs(xl[i]), abs(xr[i]))
        if lv > env:
            env += ac * (lv - env)
        else:
            env += rc * (lv - env)
        db = 20.0 * math.log10(env + 1e-9)
        over = db - thr_db
        if 2.0 * over < -knee:
            red = 0.0
        elif 2.0 * abs(over) <= knee:
            red = slope * (over + knee / 2.0) ** 2 / (2.0 * knee)
        else:
            red = slope * over
        gl = 10.0 ** (red / 20.0)
        ol[i] = xl[i] * gl
        orr[i] = xr[i] * gl
        gr[i] = red
    return ol, orr, gr


@njit(cache=True)
def ott_band_kernel(xl, xr, dthr, dratio, uthr, uratio, att, rel, sr, maxgain, down_on, up_on):
    n = xl.shape[0]
    ol = np.empty(n)
    orr = np.empty(n)
    ac = 1.0 - math.exp(-1.0 / (max(att, 1e-5) * sr))
    rc = 1.0 - math.exp(-1.0 / (max(rel, 1e-4) * sr))
    ec = 1.0 - math.exp(-1.0 / (0.004 * sr))
    env = 0.0
    gs = 0.0
    for i in range(n):
        lv2 = 0.5 * (xl[i] * xl[i] + xr[i] * xr[i])
        env += ec * (lv2 - env)
        db = 10.0 * math.log10(env + 1e-12)
        g = 0.0
        if db > dthr and down_on == 1:
            g = (dthr + (db - dthr) / dratio) - db
        elif db < uthr and up_on == 1:
            fade = (db + 75.0) / 12.0
            if fade < 0.0:
                fade = 0.0
            if fade > 1.0:
                fade = 1.0
            g = ((uthr + (db - uthr) / uratio) - db) * fade
            if g > maxgain:
                g = maxgain
        if g < gs:
            gs += ac * (g - gs)
        else:
            gs += rc * (g - gs)
        gl = 10.0 ** (gs / 20.0)
        ol[i] = xl[i] * gl
        orr[i] = xr[i] * gl
    return ol, orr
