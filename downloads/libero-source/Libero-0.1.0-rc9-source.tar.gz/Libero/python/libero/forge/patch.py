"""Patch: oscillators + filters + modulation + FX rack, rendered offline to a stereo `Audio`.

    from libero.forge import Patch, Osc, Filter, Env, LFO, Mod, FX

    p = Patch("wobble", oscs=[Osc("saw", unison=5, detune=0.3), Osc("square", octave=-1)],
              filters=[Filter("lp24", cutoff=500, res=0.4)],
              lfos=[LFO("sine", sync="1/8", mode="free")],
              mods=[Mod("lfo1", "filter1.cutoff", 0.25)],
              fx=[FX.Distortion("tube", drive=0.3)])
    a = p.render(36, velocity=110, duration=2.0, sr=48000, seed=1)      # libero.Audio, stereo
    ph = p.render_phrase([(36, 0.0, 0.5), (39, 0.5, 0.5)], sr=48000)   # mono/poly/legato phrase

Signal flow per voice: [osc1, osc2, sub, noise] -> (filtered ones) filter 1 / filter 2 (serial or
parallel) + unfiltered ones -> amp envelope (env1) x velocity -> FX rack on the stereo sum.
Deterministic: same arguments and seed give identical samples.
"""

from __future__ import annotations

import copy
import difflib
import math
import re
from dataclasses import dataclass

import numpy as np

from .. import dsp
from ..audio import Audio
from . import fx as FX
from .filters import apply_filter
from .modulation import (SOURCES_BASE, Env, ForgeError, LFO, Mod, ModEngine, static_ranges)
from .osc import Noise, Osc, Sub, WARP_MODES, render_osc


@dataclass
class Voice:
    """Voice behaviour. mode 'poly' (every note its own voice, overlapping releases), 'mono' (one voice,
    envelopes retrigger on every note), 'legato' (one voice; overlapping notes glide without
    retriggering). glide: seconds to slide between notes (mono/legato; 'exp' or 'linear' shape);
    glide_legato_only: glide only into overlapping notes."""

    mode: str = "poly"
    glide: float = 0.0
    glide_shape: str = "exp"
    glide_legato_only: bool = False

    def __post_init__(self):
        if self.mode not in ("poly", "mono", "legato"):
            raise ForgeError("Voice.mode must be poly, mono or legato")


class _Timeline:
    __slots__ = ("n", "pitch", "gate", "trig", "vel", "key", "rnd", "t0")


def _timeline(events, n, sr, voice: Voice, seed: int, from_note=None, t0: int = 0) -> _Timeline:
    tl = _Timeline()
    tl.n, tl.t0 = n, t0
    tl.pitch = np.empty(n)
    tl.gate = np.zeros(n, dtype=np.uint8)
    tl.trig = np.zeros(n, dtype=np.uint8)
    tl.vel = np.zeros(n)
    tl.key = np.zeros(n)
    tl.rnd = np.zeros(n)
    rng = np.random.default_rng(seed + 12345)
    max_off = -1
    first = events[0]
    tl.pitch[: min(first[2], n)] = first[0] if from_note is None else from_note
    rv = rng.random()
    for k, (note, v, on, off) in enumerate(events):
        end = events[k + 1][2] if k + 1 < len(events) else n
        on, end, offc = min(on, n), min(end, n), min(off, n)
        if on >= n:
            break
        overlap = k > 0 and max_off > on
        tl.gate[on:offc] = 1
        if not (voice.mode == "legato" and overlap):
            tl.trig[on] = 1
            rv = rng.random()
        tl.vel[on:end] = v
        tl.key[on:end] = note / 127.0
        tl.rnd[on:end] = rv
        start = tl.pitch[on - 1] if on > 0 else (note if from_note is None else from_note)
        if k == 0 and from_note is None:
            start = note
        gl = voice.glide * sr
        if k > 0 and voice.glide_legato_only and not overlap:
            gl = 0
        seg = end - on
        if gl <= 0 or seg <= 0:
            tl.pitch[on:end] = note
        else:
            x = np.minimum(np.arange(seg) / gl, 1.0)
            shape = (1 - np.exp(-5.0 * x)) / (1 - math.exp(-5.0)) if voice.glide_shape == "exp" else x
            tl.pitch[on:end] = start + (note - start) * shape
        max_off = max(max_off, off)
    if events[-1][2] >= n:
        tl.pitch[:] = events[0][0]
    return tl


def _beats_to_bpm(bpm):
    return float(bpm)


class Patch:
    """A complete synthesizer patch. All arguments are optional and every part is a plain object you
    can inspect and change (`patch.oscs[0].pos = 0.3`), or copy with changes via `patch.set(path, value)`.

    oscs      list of Osc (1-4; the first two are 'osc1' 'osc2')
    sub, noise   Sub / Noise sources (level 0 = off)
    filters   list of 0-2 Filter; filter_routing 'serial' or 'parallel' (then filter_mix 0..1 = share of filter2)
    envs      list of Env; env1 is the amplitude envelope. lfos: list of LFO. macros: {'macro1': 0..1, ...}
    mods      list of Mod (the matrix). fx: list of effects in rack order (forge.fx)
    voice     Voice(mode, glide). vel_amp 0..1: how much velocity scales loudness. volume_db: output trim
    bpm       tempo for synced LFOs and delays. description/tags: documentation for presets
    note_range (low, high) MIDI range the patch is designed for; macro_labels names the macros
    """

    def __init__(self, name: str = "init", oscs=None, sub: Sub | None = None, noise: Noise | None = None,
                 filters=(), filter_routing: str = "serial", filter_mix: float = 0.5, envs=None, lfos=None,
                 macros: dict | None = None, mods=(), fx=(), voice: Voice | None = None, vel_amp: float = 0.5,
                 volume_db: float = -6.0, bpm: float = 120.0, description: str = "", tags=(),
                 note_range=(24, 96), macro_labels: dict | None = None, safe: bool = True):
        self.name = name
        self.oscs = list(oscs) if oscs is not None else [Osc()]
        self.sub = sub or Sub()
        self.noise = noise or Noise()
        self.filters = list(filters)
        if len(self.filters) > 2:
            raise ForgeError("at most 2 filters")
        if filter_routing not in ("serial", "parallel"):
            raise ForgeError("filter_routing must be 'serial' or 'parallel'")
        self.filter_routing = filter_routing
        self.filter_mix = filter_mix
        self.envs = list(envs) if envs is not None else [Env(), Env(0.01, 0.4, 0.0, 0.3), Env(0.01, 0.4, 0.0, 0.3), Env(0.01, 0.4, 0.0, 0.3)]
        self.lfos = list(lfos) if lfos is not None else [LFO(), LFO(), LFO(), LFO()]
        self.macros = {f"macro{i}": 0.0 for i in range(1, 5)}
        self.macros.update(macros or {})
        self.macro_labels = dict(macro_labels or {})
        self.mods = [m if isinstance(m, Mod) else Mod(*m) for m in mods]
        self.fx = list(fx)
        self.voice = voice or Voice()
        self.vel_amp = vel_amp
        self.volume_db = volume_db
        self.bpm = bpm
        self.description = description
        self.tags = list(tags)
        self.note_range = tuple(note_range)
        self.safe = safe

    # ------------------------------------------------------------ introspection / editing

    def copy(self) -> "Patch":
        return copy.deepcopy(self)

    def _ranges(self) -> dict:
        r = static_ranges(len(self.oscs), len(self.filters), len(self.lfos))
        for i, f in enumerate(self.fx, start=1):
            for p, rng in f.MOD.items():
                r[f"fx{i}.{p}"] = rng
        return r

    def targets(self) -> list[str]:
        """Every destination name a `Mod` may use."""
        out = sorted(self._ranges())
        counts: dict[str, int] = {}
        for i, f in enumerate(self.fx, start=1):
            counts[f.KIND] = counts.get(f.KIND, 0) + 1
            suffix = "" if counts[f.KIND] == 1 else str(counts[f.KIND])
            out += [f"fx.{f.KIND}{suffix}.{p}" for p in f.MOD]
        return out

    def sources(self) -> list[str]:
        return ([f"env{i}" for i in range(1, len(self.envs) + 1)] + [f"lfo{i}" for i in range(1, len(self.lfos) + 1)]
                + sorted(self.macros) + list(SOURCES_BASE))

    def _resolve_dst(self, dst: str) -> str:
        m = re.fullmatch(r"fx\.([a-z_]+?)(\d*)\.(\w+)", dst)
        if m:
            kind, nth, param = m.group(1), int(m.group(2) or 1), m.group(3)
            idx = [i for i, f in enumerate(self.fx, start=1) if f.KIND == kind]
            if len(idx) < nth:
                raise ForgeError(f"no {kind} #{nth} in the rack (rack: {[f.KIND for f in self.fx]})")
            return f"fx{idx[nth - 1]}.{param}"
        return dst

    def _resolved_mods(self) -> list[Mod]:
        ranges = self._ranges()
        srcs = set(self.sources())
        out = []
        for m in self.mods:
            d = self._resolve_dst(m.dst)
            if d not in ranges:
                close = difflib.get_close_matches(m.dst, self.targets(), n=4)
                raise ForgeError(f"unknown mod destination '{m.dst}'. Close matches: {close}; all: Patch.targets()")
            for s in (m.src, m.aux):
                if s and s not in srcs:
                    raise ForgeError(f"unknown mod source '{s}'. Sources: {sorted(srcs)}")
            out.append(Mod(m.src, d, m.amount, m.bipolar, m.aux, m.curve))
        return out

    def set(self, path: str, value) -> "Patch":
        """Copy of the patch with one value changed. Paths: 'osc1.pos', 'osc2.warp1' (a mode name sets the
        mode, a number the amount), 'filter1.cutoff', 'env2.attack', 'lfo1.rate', 'sub.level', 'noise.level',
        'macro1', 'fx.delay.mix', 'fx2.feedback', or a Patch attribute ('bpm', 'volume_db', 'vel_amp')."""
        p = self.copy()
        head, _, rest = path.partition(".")
        m = re.fullmatch(r"(osc|filter|env|lfo)(\d+)", head)
        try:
            if m:
                lst = {"osc": p.oscs, "filter": p.filters, "env": p.envs, "lfo": p.lfos}[m.group(1)]
                obj = lst[int(m.group(2)) - 1]
                if m.group(1) == "osc" and rest in ("warp1", "warp2"):
                    if isinstance(value, str):
                        setattr(obj, rest, value)
                    else:
                        setattr(obj, rest + "_amount", float(value))
                else:
                    if not hasattr(obj, rest):
                        raise AttributeError(rest)
                    setattr(obj, rest, value)
                if m.group(1) == "osc":
                    obj.__post_init__()
            elif head in ("sub", "noise"):
                setattr(getattr(p, head), rest, value)
            elif re.fullmatch(r"macro\d+", path):
                p.macros[path] = float(value)
            elif head.startswith("fx"):
                dst = p._resolve_dst(path)
                idx, param = re.fullmatch(r"fx(\d+)\.(\w+)", dst).groups()
                setattr(p.fx[int(idx) - 1], param, value)
            elif hasattr(p, path):
                setattr(p, path, value)
            else:
                raise AttributeError(path)
        except (AttributeError, IndexError, TypeError) as e:
            raise ForgeError(f"cannot set '{path}': {e}") from e
        return p

    def mod(self, src: str, dst: str, amount: float = 1.0, **kw) -> "Patch":
        """Copy of the patch with one more mod-matrix row."""
        p = self.copy()
        p.mods.append(Mod(src, dst, amount, **kw))
        p._resolved_mods()
        return p

    def describe(self) -> str:
        lines = [f"{self.name}: {self.description}".strip(": ")]
        for i, o in enumerate(self.oscs, 1):
            w = [f"{o.warp1}({o.warp1_amount:g})"] if o.warp1 != "none" else []
            w += [f"{o.warp2}({o.warp2_amount:g})"] if o.warp2 != "none" else []
            lines.append(f"  osc{i}: {o.table.name} pos={o.pos:g} unison={o.unison} detune={o.detune:g} "
                         f"oct={o.octave} level={o.level:g} {' '.join(w)}")
        for i, f in enumerate(self.filters, 1):
            lines.append(f"  filter{i}: {f.type} cutoff={f.cutoff:g} res={f.res:g} drive={f.drive:g} key={f.keytrack:g}")
        for m in self.mods:
            lines.append(f"  mod: {m.src} -> {m.dst} {m.amount:+g}" + (f" x {m.aux}" if m.aux else ""))
        if self.fx:
            lines.append("  fx: " + " > ".join(f.KIND for f in self.fx))
        return "\n".join(lines)

    # ------------------------------------------------------------ rendering

    def _tail(self, tail) -> float:
        if tail is not None:
            return float(tail)
        return min(self.envs[0].release * 1.2 + FX.rack_tail(self.fx) + 0.02, 14.0)

    def _sources(self, tl: _Timeline, sr: int, bpm: float, macros: dict, controls: dict, seed: int, eng_holder: dict,
                 mods: list[Mod]) -> dict:
        n = tl.n
        need = {"env1"}
        for m in mods:
            need.add(m.src)
            if m.aux:
                need.add(m.aux)
        src: dict[str, np.ndarray] = {}
        eng = ModEngine(mods, src, self._ranges(), n)
        eng_holder["eng"] = eng
        for name in sorted(need):
            if name == "velocity":
                src[name] = tl.vel
            elif name == "note":
                src[name] = tl.key
            elif name == "random":
                src[name] = tl.rnd
            elif name in ("modwheel", "aftertouch"):
                src[name] = np.full(n, float(controls.get(name, 0.0)))
            elif name.startswith("macro"):
                src[name] = np.full(n, float(macros.get(name, 0.0)))
        for i, e in enumerate(self.envs, 1):
            if f"env{i}" in need:
                src[f"env{i}"] = e.render(tl.trig, tl.gate, sr)
        for i, l in enumerate(self.lfos, 1):
            if f"lfo{i}" in need:
                rate = None
                if eng.has(f"lfo{i}.rate"):
                    rate = eng.arr(f"lfo{i}.rate", l.rate_hz(bpm))
                src[f"lfo{i}"] = l.render(tl.trig, sr, bpm, rate, tl.t0, seed * 13 + i)
        return src

    def _osc_order(self) -> list[int]:
        n = len(self.oscs)
        deps = {}
        for i, o in enumerate(self.oscs):
            uses = any(WARP_MODES[w] >= 20 for w in (o.warp1, o.warp2)) and (o.warp1_amount > 0 or o.warp2_amount > 0
                                                                                or any(m.dst.startswith(f"osc{i + 1}.warp") for m in self.mods))
            src = o.fm_src if o.fm_src is not None else (1 - i if n > 1 else None)
            deps[i] = src if uses and src is not None and src != i and 0 <= src < n else None
        order, seen = [], set()

        def visit(i, stack=()):
            if i in seen:
                return
            if i in stack:
                raise ForgeError("oscillator FM/AM/RM sources form a cycle")
            if deps[i] is not None:
                visit(deps[i], stack + (i,))
            seen.add(i)
            order.append(i)

        for i in range(n):
            visit(i)
        return order, deps

    def _voice(self, tl: _Timeline, sr: int, seed: int, eng: ModEngine) -> np.ndarray:
        n = tl.n
        pitch_mod = eng.value("pitch", 0.0)
        base_pitch = tl.pitch + pitch_mod
        filt = np.zeros((n, 2))
        dry = np.zeros((n, 2))
        raws: dict[int, np.ndarray] = {}
        order, deps = self._osc_order()

        def route(sig, filtered):
            nonlocal filt, dry
            if filtered:
                filt += sig
            else:
                dry += sig

        for i in order:
            o = self.oscs[i]
            if not o.enabled:
                continue
            k = i + 1
            semis = base_pitch + o.tune_semitones + eng.value(f"osc{k}.pitch", 0.0) + eng.value(f"osc{k}.fine", 0.0)
            freq = 440.0 * 2.0 ** ((np.broadcast_to(semis, (n,)) - 69.0) / 12.0)
            ext = None
            if deps[i] is not None and deps[i] in raws:
                ext = raws[deps[i]]
            raw = render_osc(o, freq, eng.arr(f"osc{k}.pos", o.pos), eng.arr(f"osc{k}.warp1", o.warp1_amount),
                             eng.arr(f"osc{k}.warp2", o.warp2_amount), eng.value(f"osc{k}.detune", o.detune),
                             eng.value(f"osc{k}.blend", o.blend), eng.value(f"osc{k}.spread", o.spread), ext, sr,
                             seed * 101 + i)
            raws[i] = np.clip(0.5 * (raw[:, 0] + raw[:, 1]), -1.5, 1.5)
            lv = eng.value(f"osc{k}.level", o.level)
            pan = np.asarray(eng.value(f"osc{k}.pan", o.pan))
            ang = (pan + 1.0) * math.pi / 4.0
            g = np.stack([np.cos(ang) * math.sqrt(2), np.sin(ang) * math.sqrt(2)], axis=-1) if pan.ndim else \
                np.array([math.cos(ang) * math.sqrt(2), math.sin(ang) * math.sqrt(2)])
            lvc = np.asarray(lv)[:, None] if np.ndim(lv) else lv
            route(raw * lvc * g, o.filtered)

        sub_lv = eng.value("sub.level", self.sub.level)
        if np.any(np.asarray(sub_lv) > 0) or eng.has("sub.level"):
            freq = 440.0 * 2.0 ** ((np.broadcast_to(base_pitch, (n,)) - 69.0) / 12.0)
            s = self.sub.render(freq, sr, seed * 101 + 50)
            lvc = np.asarray(sub_lv)[:, None] if np.ndim(sub_lv) else sub_lv
            ang = (self.sub.pan + 1.0) * math.pi / 4.0
            route(s * lvc * np.array([math.cos(ang), math.sin(ang)]) * math.sqrt(2), self.sub.filtered)
        nz_lv = eng.value("noise.level", self.noise.level)
        if np.any(np.asarray(nz_lv) > 0) or eng.has("noise.level"):
            s = self.noise.render(n, sr, seed * 101 + 60, np.broadcast_to(base_pitch, (n,)))
            lvc = np.asarray(nz_lv)[:, None] if np.ndim(nz_lv) else nz_lv
            ang = (self.noise.pan + 1.0) * math.pi / 4.0
            route(s * lvc * np.array([math.cos(ang), math.sin(ang)]) * math.sqrt(2), self.noise.filtered)

        sig = filt
        active = [(j, f) for j, f in enumerate(self.filters, 1) if f.enabled]
        if active:
            def run(j, f, x):
                kt = f.cutoff * 2.0 ** (f.keytrack * (tl.pitch - 60.0) / 12.0) if f.keytrack else f.cutoff
                cut = eng.arr(f"filter{j}.cutoff", kt) if (f.keytrack or eng.has(f"filter{j}.cutoff")) else f.cutoff
                y = apply_filter(f.type, x, cut, eng.value(f"filter{j}.res", f.res), eng.value(f"filter{j}.drive", f.drive),
                                 eng.value(f"filter{j}.morph", f.morph), sr)
                m = eng.value(f"filter{j}.mix", f.mix)
                if np.ndim(m) == 0 and float(m) >= 1.0:
                    return y
                mc = np.asarray(m)[:, None] if np.ndim(m) else m
                return x * (1.0 - mc) + y * mc

            if self.filter_routing == "serial" or len(active) == 1:
                for j, f in active:
                    sig = run(j, f, sig)
            else:
                (j1, f1), (j2, f2) = active[:2]
                a, b = run(j1, f1, sig), run(j2, f2, sig)
                sig = a * (1.0 - self.filter_mix) + b * self.filter_mix
        sig = sig + dry
        amp = eng.sources["env1"]
        vel = (1.0 - self.vel_amp) + self.vel_amp * tl.vel
        vol = eng.value("volume", 1.0)
        return sig * (amp * vel * vol)[:, None]

    def _events(self, notes, sr):
        ev = []
        for note, start, dur, vel in notes:
            ev.append((float(dsp.parse_note(note)) if not isinstance(note, float) else note, vel / 127.0,
                       int(round(start * sr)), int(round((start + dur) * sr))))
        ev.sort(key=lambda e: e[2])
        return ev

    def _render(self, notes, sr, seed, tail, macros, controls, bpm, from_note=None) -> Audio:
        if not notes:
            raise ForgeError("no notes to render")
        sr = int(sr)
        bpm = float(bpm or self.bpm)
        mac = dict(self.macros)
        mac.update(macros or {})
        ctl = dict(controls or {})
        mods = self._resolved_mods()
        tail_s = self._tail(tail)
        ev = self._events(notes, sr)
        end = max(e[3] for e in ev)
        N = end + int(round(tail_s * sr))
        voice_tail = int(round((self.envs[0].release * 1.2 + 0.02) * sr)) if tail is None else int(round(tail_s * sr))
        h: dict = {}
        poly_multi = self.voice.mode == "poly" and len(ev) > 1
        if poly_multi:
            out = np.zeros((N, 2))
            for k, (note, v, on, off) in enumerate(ev):
                n_loc = min(N - on, (off - on) + voice_tail)
                tl = _timeline([(note, v, 0, off - on)], n_loc, sr, Voice("poly"), seed + k, t0=on)
                self._sources(tl, sr, bpm, mac, ctl, seed + k, h, mods)
                out[on:on + n_loc] += self._voice(tl, sr, seed + k * 7919, h["eng"])
        else:
            gl = _timeline(ev, N, sr, self.voice, seed, from_note)
            self._sources(gl, sr, bpm, mac, ctl, seed, h, mods)
            out = self._voice(gl, sr, seed, h["eng"])
        if self.fx:
            if poly_multi:
                gl = _timeline(ev, N, sr, Voice("mono"), seed)
                self._sources(gl, sr, bpm, mac, ctl, seed, h, [m for m in mods if m.dst.startswith("fx")])
            out = FX.run_rack(self.fx, out, sr, seed, bpm, h["eng"])
        out = out * dsp.undb(self.volume_db)
        if self.safe:
            a = np.abs(out)
            k = 0.8
            out = np.where(a <= k, out, np.sign(out) * (k + (1 - k) * np.tanh((a - k) / (1 - k))))
        out = np.nan_to_num(out)
        if tail is None:
            nz = np.flatnonzero(np.max(np.abs(out), axis=1) > 1e-4)
            if len(nz):
                keep = min(len(out), int(nz[-1]) + int(0.02 * sr))
                out = out[:keep]
                f = min(int(0.02 * sr), len(out))
                out[-f:] *= np.linspace(1, 0, f)[:, None]
        return Audio(out.astype(np.float32), sr)

    def render(self, note=60, velocity: int = 100, duration: float = 1.0, sr: int = 48000, seed: int = 0,
               tail: float | None = None, macros: dict | None = None, controls: dict | None = None,
               bpm: float | None = None, from_note=None) -> Audio:
        """Render one note to stereo `Audio`.

        note      MIDI number or name ('C2'); a float is a fractional MIDI pitch
        velocity  1..127;  duration  seconds the key is held;  tail  seconds of release/FX ring-out after
                  that (None = automatic from the amp release and the FX, silence trimmed)
        macros    {'macro1': 0..1} override;  controls {'modwheel': .., 'aftertouch': ..}
        from_note glide start pitch (mono/legato voice with glide > 0)
        """
        n = note if isinstance(note, float) else dsp.parse_note(note)
        return self._render([(n, 0.0, duration, int(velocity))], sr, seed, tail, macros, controls, bpm, from_note)

    def render_phrase(self, notes, sr: int = 48000, seed: int = 0, tail: float | None = None,
                      macros: dict | None = None, controls: dict | None = None, bpm: float | None = None,
                      sequential: bool = False) -> Audio:
        """Render a phrase with the patch's Voice mode (poly / mono / legato, glide). `notes` is a list of
        (note, start_s, duration_s[, velocity]); with `sequential=True` of (note, duration_s[, velocity])
        placed back to back. Overlapping notes in 'legato' mode glide without retriggering."""
        norm, cur = [], 0.0
        for it in notes:
            if sequential:
                note, dur = it[0], it[1]
                vel = it[2] if len(it) > 2 else 100
                norm.append((note, cur, dur, vel))
                cur += dur
            else:
                norm.append((it[0], it[1], it[2], it[3] if len(it) > 3 else 100))
        return self._render(norm, sr, seed, tail, macros, controls, bpm)


# ---------------------------------------------------------------- integration with recipes

def layer(patch: Patch, duration=None, tail: float | None = None, macros=None, gain_db: float = 0.0,
          velocity=None, normalize_db: float | None = None, seed_salt: int = 0):
    """Wrap a Patch as a recipe layer function: `sound.body(forge.layer(patch, duration=3.0))`.

    duration  seconds the key is held (float, or callable(ctx) -> float; default 3.0)
    macros    dict, or callable(ctx) -> dict (e.g. brighter at higher ctx.dyn)
    velocity  None uses ctx.velocity; an int fixes it; a callable(ctx) -> 1..127 overrides
    normalize_db  scale each zone to this peak (dBFS) after gain; gain_db trim in dB
    The compiler bakes it per root and velocity layer; the seed is ctx.seed, so renders are reproducible."""

    def fn(ctx):
        dur = duration(ctx) if callable(duration) else (3.0 if duration is None else float(duration))
        vel = velocity(ctx) if callable(velocity) else (ctx.velocity if velocity is None else int(velocity))
        mac = macros(ctx) if callable(macros) else macros
        a = patch.render(ctx.note, vel, dur, ctx.sr, ctx.seed + seed_salt, tail=tail, macros=mac)
        if normalize_db is not None:
            a = a.normalize(normalize_db)
        return a.gain_db(gain_db) if gain_db else a

    fn.patch = patch
    return fn


def recording(name: str, root=None, gain_db: float = 0.0):
    """Layer function that plays a recording from the sound's samples/ folder. With `root` (a MIDI note
    or name: the pitch it was recorded at) it is repitched to ctx.note; without, it plays as is."""

    def fn(ctx):
        a = ctx.load(name, ctx.sr)
        if root is not None:
            a = a.pitch(ctx.note - dsp.parse_note(root))
        return a.gain_db(gain_db) if gain_db else a

    return fn


def stack(*fns, gains_db=None):
    """Mix several layer functions (forge layers, recordings, lambdas) into one, aligned at t = 0."""

    def fn(ctx):
        parts = []
        for i, f in enumerate(fns):
            a = f(ctx)
            if a is None:
                continue
            g = 0.0 if gains_db is None else gains_db[i]
            parts.append(a.gain_db(g) if g else a)
        if not parts:
            return None
        return parts[0].mix(*parts[1:]) if len(parts) > 1 else parts[0]

    return fn
