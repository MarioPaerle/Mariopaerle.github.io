# Sampled instruments: Kontakt-class sound in a few calls

When the user names a real instrument ("piano", "violin", "marimba", "tuba",
"drum kit") the best sound Libero can make starts from **recordings**, not from
synthesis. The plugin plays real multisamples with a continuous dynamics axis,
round robins, release samples and humanisation; the live controls (filter,
resonators, tape, echo, rooms) stay on top, Serum-style. Your job is to pick the
best legal source, bring in the right subset, let the compiler edit it like a
sample editor would, and check the result objectively.

## 1. The five-call path

```
library_search("grand piano")                       → salamander-grand-v3 ★5 CC BY 3.0 …
library_fetch("salamander-grand-v3", "layers8")     → 367 MB, cached
import_sfz("pianoforte", "salamander-grand-v3:Salamander Grand Piano V3.sfz", family="piano",
           title="Pianoforte", subtitle="gran coda")
compile("pianoforte")
lint("pianoforte")            → fix FAIL/WARN, recompile
preview("pianoforte", "36 48 60 72 84")
```

For folders of note-named files (VCSL, TinySOL, your recordings) use
`import_wav_set(slug, "<library-id>:<folder>", family=…, include="<mic>")`.
`family_preset(family)` shows what the family implies; `library_info(id)` lists a
library's folders, SFZ files and named subsets.

## 2. Choosing the source

- Search with `license="shippable"` (default). Sources marked PRIVATE (NC,
  EULA, unknown terms) may be used for the user's own music but the sound must
  never be shared; say so when you use one. `sound_licenses(slug)` tells.
- Quality ranking: Salamander for grand piano; VSCO 2 CE for orchestral
  (strings, winds, brass, harp, organ); VCSL for mallets, harpsichord, ethnic,
  pipe organ; Karoryfer for character basses, cello, saxes, drums; TinySOL and
  Iowa for clean dry single notes to hybridise.
- **Honest gaps** (no strong free recordings): electric piano, choir/voice,
  tonewheel organ, duduk/aulos-like reeds. Build these as hybrids (a real
  transient or breath layer over a modelled body) and tell the user.
- The disk is nearly full: fetch subsets. Anything over 500 MB needs
  `confirm=True`, over `max_mb` (1500) is refused. Files are linked, not copied,
  into the sound folder.

## 3. What the compiler does to recorded regions (`sound.multisample`)

Per region: resample to 48 kHz; **true-onset trim** (found at peak−20 dB, walked
back down the attack to the noise floor) with a 2 ms faded pre-roll so every
note starts alike; cut where the note has decayed (`end_db`) or at a length that
follows the register (`max_seconds`, e.g. 10 s in the bass, 3.5 s at the top of
a piano); fade; long loop search if the family loops (`loop="auto"`, ≥ 2-4 s).

Per key: **phase-align** every dynamics layer and take to the top layer
(cross-correlation of the attack, ≤ `align_ms`) so the engine's crossfades do not
comb; **tuning** — `tune="smooth"` keeps an instrument's own stretch tuning but
corrects layers that disagree with their key and keys that jump off the curve,
`"detect"` tunes every zone to equal temperament (winds, strings, mallets),
`"source"` trusts the library; **level ladder** — one gain for the whole
instrument (loudest note at `peak_db`, −9 dBFS for pianos so chords have
headroom) plus small corrections for notes that stand out from their
neighbours and steps between layers above `max_step_db`. **Files are never
normalised one by one**: that would destroy the dynamics.

Velocity layers become **dynamics layers** (`dyn`) that the engine crossfades
continuously; `sound.performance(dynamics_source="cc1")` puts them on the mod
wheel (bowed, winds, brass), `velocity_curve` shapes the velocity mapping,
`humanize={"cents","ms","db"}` and `rr_reset_ms` make repeated notes breathe.
Release samples (`trigger=release` in SFZ, or "rel" files) become the tail with
`rt_decay`: a note held long releases quieter.

Region fields you may edit in `samples/map.json`: `file, root, lo, hi,
vel | dyn, take, tune_cents, gain_db, loop, offset, end, rt_decay, rt_min_db,
pitched`. Process options live in `sound.py` (see `family_preset`).

## 4. Lint instead of listening

`lint(slug)` measures what a sample editor would check: coverage, tuning spread
inside a key and along the keyboard, level and brightness ladders (a flat
brightness ladder means the layers are one sound at two volumes), onset
alignment (< 1 ms), clicks at starts/ends/loop seams, DC, aliasing, silent
zones, round robins that are identical, a missing release where the family
needs one, loudness jumps between neighbouring keys, noise-floor spread.
Typical fixes:

| finding | fix |
|---|---|
| onset | raise `align_ms` a little, or check the region's `offset` |
| ladder not rising | a mislabelled layer: fix its `vel`/`dyn` in map.json |
| steps too big | more layers (`layers=`), or `sample_morph` in-between layers |
| brightness flat | the source layers are volume copies: add a filter-envelope (`flt_env`) or a brighter attack layer |
| loudness jump | `gain_db` on that key's regions |
| tuning jump | `tune="smooth"` or `tune_cents` on that key |
| release missing | recorded releases, or `sample_release` (damper / room / bloom) as the tail |
| loop seam | longer `loop_min_s`, `max_seconds`, or no loop for decaying sounds |

## 5. Beyond the recording: hybrid and design layers

A sampled body is the start, not the end. Keep the live controls meaningful and
add what the library lacks:

- `sample_release` synthesises a release from the body when none was recorded.
- `sample_morph` fills missing dynamics layers between two real ones.
- `sample_texture`: `freeze` (a moment held as a drone), `granular` (clouds),
  `tape` (worn resampling), `reverse_swell` (a swell rising into the note),
  `stretch_pad` — for cinematic layers in the `air` or `attack` slot.
- A real transient over a synthetic body (or the reverse): see guide('sound_design').
- `sample_split` cuts chromatic runs (Iowa) into single notes for `import_wav_set`.

## 6. Done means

`compile` without warnings you have not chosen, `lint` with no FAIL (WARNs
explained in notes.md), `preview` across the range and the dynamics
(`"36:0:1:30,36:1.2:1:110,…"` or a `cc` sweep for mod-wheel instruments),
credits in place (`sound_licenses`), a figure and notes. Then ask the user
whether to keep it.
