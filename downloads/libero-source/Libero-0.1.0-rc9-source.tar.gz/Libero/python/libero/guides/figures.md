# Figures

Every sound has a figure: `figure.svg` in the sound's folder. It is shown large
as the main image of the plugin's page and small (about 96 px) in the library. You draw it, by
writing SVG, after the sound exists, because the figure is a *reading* of the
sound, not a decoration for it.

The look is an engraved plate from an eighteenth-century treatise: Diderot's
*Encyclopédie*, Piranesi's *Vedute*, a Letarouilly plan. Line, hatching,
reserved paper, one accented element.

---------------------------------------------------------------------------

**Bank covers.** A bank has a cover too: `figure.svg` in the bank folder, named in `bank.json` as `"figure": "figure.svg"`. It follows every rule below but is drawn as a *cover*: one simpler, stronger composition that stands for the whole collection (the plan of a grand's strings and hammers, a bell flare in section), not a reading of one sound. When creating a new bank, draw its cover per this guide.

---------------------------------------------------------------------------

## 1. The contract

- Root: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430">`.
  No `width`/`height`.
- Self-contained. No `<script>`, `<style>`, `<foreignObject>`, `<image>`, `<a>`,
  no animation elements, no external `href`, no fonts. The UI strips all of
  these anyway, so anything built on them disappears.
- Presentation attributes only (`stroke="..."`, `fill="..."`), never `style="..."`.
- `<title>` with the sound's title, and `<desc>` with the reading (§4): one to
  three sentences saying which property of the sound became which part of the
  drawing. If you cannot write the desc, the figure is not derived yet.
- Under 60 KB. Most good figures are 10–40 KB.
- No text inside the drawing. The plugin sets the title under the figure.

## 2. Colour: three values, all recolourable

The plugin has themes (white paper, the same page printed on black, and user themes).
The UI inlines your SVG and recolours it, so you draw with exactly three values:

| role | write | becomes in the UI |
|---|---|---|
| ink | `currentColor` | the theme's ink (black on white, white on black) |
| gold | `#b8924f` (exactly this) | the theme's accent (Pompeian red in the built-in themes) |
| paper | `#f3eee6` (exactly this) | the page's paper colour |

Use **paper** to knock out: fill a shape with paper so that the hatching behind
it stops at its contour, or stroke with paper to cut a highlight through a dark
area. Everything else is transparent; never paint a full-bleed background.

Why not arbitrary hex or CSS variables: a figure with its own palette breaks on
every theme but one, and renderers outside the browser (the `figure_view`
preview) do not understand `var()`. `currentColor` with a `color` on the root
renders correctly everywhere; the two sentinel hex values are recoloured by
exact match.

Tone comes from **hatching density**, not from grey fills. `stroke-opacity` is
allowed for fading a family of lines (echoes dying away, a reflection sinking),
not as a substitute for drawing the shadow.

No gradients, no filters, no blur, no glow, no drop shadows. While the sound
plays the plugin draws its waveform in a hairline under the figure; the figure
itself stays still and graphic.

## 3. House style

**Line weights** (in viewBox units):

- 1.1–1.4 — outer contours, the silhouette of the subject
- 0.7–0.9 — secondary edges, inner contours, frames
- 0.35–0.6 — hatching, grain, fluting, ruled water

Round caps and joins on the root (`stroke-linecap="round" stroke-linejoin="round"`),
`fill="none"` on the root so nothing fills by accident.

**Hatching**, the engraver's grammar:

- *Parallel* lines, 3–6 units apart, for flat middle tones.
- *Cross-hatching* (a second family at 60–90°) for the darks. Never a third family.
- *Contour hatching*: lines that follow the form (the curve of a bowl, the
  cylinder of a column) — this is what makes it read as an engraving and not a
  diagram.
- *Stipple* (small dots, r 0.5–1.2) for air, breath, dust, noise.
- *Reserve*: highlights are paper left untouched, not white paint.
- Light comes from the upper left. Shade the right and lower sides.

**Projections** are welcome: elevation (front view), section, and plan (seen
from above). Architectural conventions carry meaning cheaply: walls cut in plan
are drawn as two lines filled with diagonal hatching (*poché*); axes are
dash-dot (`stroke-dasharray="14 3 2 3"`); columns in plan are dots.

**Gold** (drawn as `#b8924f`, shown in the theme's accent) appears once, as one idea: the element that *is* the sound's identity
(the plectrum at the pluck point, the one mode that rubbing excites, the vowel
that shapes the choir). If you find yourself gilding a second idea, choose.

## 4. Derive the figure from the sound

Start from the recipe and the analysis you already have — envelope times,
partial ratios, inharmonicity, pluck position, noise level, formants, room and
its decay — and let each become a *measurable* feature of the drawing. Compute
the geometry (a few lines of Python writing the path data is fine and usually
better than eyeballing); the numbers should survive into the picture.

A dictionary to start from — invent beyond it:

| in the sound | in the figure |
|---|---|
| **envelope** (attack, decay, sustain, release) | a *profile*: the swell and taper of a vase, the entasis of a column, the curve of a lyre's arm. Attack = how quickly the profile swells from its base; decay = the taper; sustain = the straight shaft; release = the lip, the foot, the volute that curls back. |
| **harmonic partials** | proportions. On a logarithmic axis the harmonic series crowds together exactly like a colonnade in recession — use it. Lengths of strings, spacing of columns, the module of an order. |
| **partial amplitudes** | line weight, height, or presence. A missing partial is a missing (or dotted) element. |
| **pluck / strike position** β | the partials it cancels (every n with nβ integer). A string plucked at 1/7 has no 7th harmonic: draw the 7th string dotted. The string at the moment of release is a triangle with its apex at the pluck point. |
| **inharmonic modes** | rings that are *not* concentric: rim deformations r = R(1 + ε cos nθ), each about its own slightly displaced centre, radii shrinking with the mode ratio. Write the ratios in the desc. |
| **material** | the hatching technique. Wood: grain following the form, a knot or two. Glass: very few lines, big reserved highlights, things seen *through* it. Metal: tight ruled lines, a hard specular reserve. Stone: veins and stipple. Skin or membrane: concentric lines. String: taut straight lines of graded weight. |
| **noise, breath, air** | stipple. Density = amount; dot size = colour (bright noise, fine dots; dark noise, coarse). |
| **room** | the setting. Dry: nothing, or a plinth. Small room: a tight niche. Long hall: a long nave, better in plan. Dark room: cross-hatched darkness. Reverb time = how far echo rings travel before fading (`stroke-opacity` decaying exponentially); damping = darker hatching; shimmer = dashed rings at half spacing. |
| **pitch drift, wow, vibrato** | a sinusoidal displacement, growing with distance (a reflection that wavers more the deeper it goes). |
| **detune, chorus, unison** | the same line drawn two or three times, slightly apart and not quite parallel. |
| **filter, formants, spectral envelope** | a curve used as architecture: a vault line, a horizon, a skyline, the line connecting capitals. |
| **register** | scale and height in the frame: low sounds sit low and wide, high sounds small and high. |

The test: someone who has heard the sound and reads the desc should be able to
point at the drawing and say "that is the attack", "that is the room".

## 5. Composition

- **One subject.** One instrument, one object, one place. Not a collage.
- **Generous margin.** Keep the drawing inside roughly 40–472; the page sets
  the figure on open paper, without a frame, so the margin is the frame.
- **Golden section.** The strong horizontals and verticals sit near 196 and 316
  (512/φ², 512/φ): a waterline, a pluck point, the centre of a bowl.
- A **frame** is optional and should be architecture, not a border: a niche, an
  arch, a plinth, the walls of a plan.
- **Value plan.** Squint: there should be one clear dark mass, a middle tone,
  and plenty of paper. All-grey is a failure; so is all-outline.
- It must still read at **96 px**: the silhouette carries the idea, hatching is
  the reward for looking closer.

## 6. Banned

- Waveforms, oscilloscopes, spectrum bars or sine curves used as decoration.
  (A spectral envelope *used as architecture* is fine; a wiggle floating in the
  middle is not.)
- Neon, lens flares, glow, bloom, gradients of any kind, glassmorphism.
- Robots, brains, circuits, sparkles, stars-as-magic, speech bubbles, music
  notes, headphones, speakers, keyboards, generic "sound wave" icons.
- Vaporwave props: palm trees, sunsets with stripes, checkerboards, Helios busts,
  dolphins, Windows chrome. The plugin brings its own restrained twilight.
- Random abstract gradients, blobs, "flowing shapes".
- Text, logos, signatures, watermarks. At most a small roman numeral, drawn as
  paths, if the composition needs it.
- Symmetry for its own sake when the sound is not symmetric.
- More than one accent colour; gold used for decoration rather than meaning.

## 7. Technique notes

- Hatching fills: a `<pattern patternUnits="userSpaceOnUse" patternTransform="rotate(-38)">`
  with one `<line>`, or explicit line families clipped with `<clipPath>`.
  Explicit families look better when they must follow a form; patterns are
  cheaper for large flat areas.
- Merge line families into one `<path d="M..L..M..L..">` instead of hundreds of
  `<line>` elements. Round coordinates to one decimal. This is how you stay
  under 60 KB.
- Group repeated attributes on a `<g>`.
- Ids may be short and simple (`hatch`, `bowl`); the plugin rewrites them so
  several figures can live in one page.
- If you scale a group with `transform`, add `vector-effect="non-scaling-stroke"`
  to its strokes so the weights of §3 hold.
- Occlusion order: draw what is behind first, then fill the front shapes with
  paper and stroke them.

## 8. Self-critique with `figure_view`

Render the figure with `figure_view` at full size and at thumbnail size, on both
the light and the dark theme, and go through this list honestly. Redraw rather
than patch when more than two items fail.

1. **Reading.** Does the desc name at least three concrete mappings from §4,
   with numbers? Can you point to each one in the render?
2. **Subject.** One subject, clear silhouette at 96 px?
3. **Values.** Squint: one dark mass, a middle tone, lots of paper?
4. **Engraving.** Is tone made by hatching, contour lines and stipple — not by
   opacity washes? Does at least one hatch family follow a form?
5. **Gold.** Exactly one idea in gold, and it is the sound's identity?
6. **Themes.** On the dark theme, do the paper knock-outs still hide what they
   should, and is nothing drawn in a colour other than the three?
7. **Clichés.** Anything from §6? Anything that would fit any sound equally well?
8. **Margins and weights.** Nothing touching the edge; contours 1.1–1.4,
   hatching under 0.6?
9. **Contract.** No text, no style, no scripts, no raster, under 60 KB.

## 9. Worked examples (in `sounds/`)

**Lira** — plucked lyre, cypress body, small bright chapel. The lyre's arms are
the pluck envelope in profile: w(h) = 52 + 56 (1 − e^(−h/0.07)) e^(−h/0.62),
a fast swell (attack) then an exponential taper (decay), ending in a volute
(release). Seven strings carry partials 1–7 of a string plucked at β = 1/7,
weight ∝ √(|sin nπβ| / n²); the 7th is silent and drawn dotted; string 1 is
caught as a triangle at the instant of release. The gilded plectrum marks the
pluck point on its cord. Cypress grain is contour-hatched along the bowl. The
room is a small arched niche, mostly paper: small and bright.

**Vetro** — rubbed glass bowl, long basilica. The bowl is seen from above, in
the apse of a basilica drawn in plan (walls in poché, columns as dots, dash-dot
axis). The rim's bending modes n = 2…6 (ratios 1 : 2.63 : 4.99 : 8.08 : 11.9)
are rosettes r = Rₙ(1 + ε cos nθ), Rₙ ∝ ratio^(−0.34), each about its own
displaced centre: inharmonic, so nothing shares a centre. The (2,0) mode that
rubbing excites is gilded, with its four nodes. The finger's path spirals in
from dots to a solid line: the slow rubbed onset. Echo rings fade down the long
nave; dashed half-spaced rings are the octave shimmer.

**Coro di marmo** — detuned saw choir through a/o formants, breath, tape wow,
dark cistern. Columns stand in black water under a cross-hatched vault. They are
harmonics 1–10 of a 110 Hz saw on a logarithmic axis (so they crowd like a
colonnade in recession), as tall as their amplitude after the vowel filter
(F1 730→570 Hz, F2 1090→840 Hz). The gilded line over the capitals is that
vowel envelope, drawn three times slightly apart: the detuned unison. Columns
lean by a hair, alternately: not quite parallel. Reflections break into ruled
bars displaced by a slow sine that grows with depth: tape wow. Paper stipple in
the dark, thickest just above the capitals, is the breath. The waterline sits
at the golden section.
