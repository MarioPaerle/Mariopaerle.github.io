# Genres: route the sound before you build it

Full research and sources: `docs/research/sound-design-method.md`. This is the working version.

## Step 0 — Route the sound (30 seconds, before any tool call)

Write one line: `genre · role · route · why`.

- **Role**: drums, bass, chords, lead, texture, FX.
- **Route**: REC (recordings), SYN (oscillators, `libero.forge`, `guide("forge")`), PM (`libero.physics`), HYB (mix).

Decision tree, in order:
1. Named acoustic instrument -> **REC**. No legal recording -> stop and report the gap. Add PM only for a gesture the samples lack (legato, bow, breath).
2. Native electronic sound (808, kick synth, lead, pad, reese, arp, riser, a hook nicknamed "meow") -> **SYN**. Measure first (pitch stability, harmonic count, centroid over time, onset sweep); never sample what it resembles.
3. Kit hit: acoustic genres (jazz, rock, boom-bap, folk) -> REC multi-mic; electronic genres (trap, house, techno, reggaeton) -> SYN body + recorded or synthesised transient.
4. Texture -> HYB: recording processed (freeze, granular, tape, reverse) under or over SYN pads.
5. Mixing layers: name the missing quality first (sub, breath, grit, transient). Layers must differ in register or role. Synthesised body under a recorded transient reads real; the opposite reads fake. Saturate once, after layering. Keep rooms live.
6. One genre per kit or bank. The genre decides whether grit is a process on recordings (boom-bap) or clean, loud, glued synthesis (trap).

## Genre cheat-sheets

| genre | palette | signature processing | right | cheap | routes |
|---|---|---|---|---|---|
| **trap / phonk** | 808, punchy kick, tight snare/clap, hats with rolls, dark bells/pads, vocal chops | 808 saturation (parallel, sub removed from the dirty copy), bus clip/glue, short plate | loud AND clean low end, 808 tuned to key, hat velocity variation | thin tanh sub, one 808 for all keys, no glue, crunch on snares | 808 SYN; kick/snare HYB; hats SYN; bells SYN; chops REC |
| **drill** | sliding 808, sparse minor melody, skittering hats, detuned piano, choir stabs | like trap, slides are the player's glide | dark, cold, half-time | static 808, major brightness | as trap; pads HYB |
| **boom-bap / lo-fi** | dusty kick+snare with tails, swing, chopped soul/jazz, Rhodes, upright | sampler chain (about 26 kHz, 12-bit, soft clip), crackle bed, swing; wow/flutter only for a clear tape-machine reference or brief | warm dull top, one sampler colour, timing variation | crush on everything, loud crackle, quantised hats | drums REC through the chain; bass REC/SYN; keys REC + tape |
| **pop** | layered claps/snaps, sub or electric bass, piano/guitar/pluck, vocal stacks | doubles panned, width from a separate bus, sidechain, fewer parts | each part finished, hook always audible | many mid-heavy layers | drums HYB; bass SYN/REC; chords REC; lead SYN |
| **R&B** | Rhodes/Wurli, warm pads, 808 or soft bass, sparse percussion | tape/cassette saturation, reverse swells, long vocal reverb, space | texture around a close vocal | dense drums, thin bright pads | keys REC; pads SYN/HYB; bass SYN; drums HYB |
| **house / techno** | 909-type kick, clap, hats, sub/rolling bass, stabs, acid line, rumble | kick+sub layering, sidechain as rhythm, parallel saturation, dub delay/reverb | tuned mono low end, groove from hats | kick and bass overlap, equal pumping everywhere | SYN almost entirely |
| **EDM** | supersaw, reese (2 saws +15-25 cents, sine below), big-room kick, risers | sidechain by role (bass 6-9 dB, lead 2-4 dB) | clear kick, wide mids, mono sub | static unison saw, heavy pump on lead | SYN (forge) |
| **ambient** | pads, drones, granular texture, tape loops | grains 50-100 ms, slow irregular drift, long reverb, uneven loop lengths | slow movement that never repeats exactly | LFO-perfect pad | HYB (`sample_texture` + SYN) |
| **jazz** | upright, piano, brushes/sticks, sax/trumpet/guitar | almost none: room, shelf EQ, natural decay | dynamics, brush noise, bass body | repeated notes, dead dry sound | REC only |
| **rock / metal** | kit, bass, crunch/high-gain guitars | DI + cab IR + amp stage, quad-tracking (outer bright/tight, inner darker), low gain per take, kick/bass own the low end, gated ambience (80s) | tight low end, cab present | fizzy high gain, no cab | kit REC; guitars REC DI + IR; synth SYN |
| **classical / cinematic** | strings, winds, brass, harp, timpani, choir; hybrid pulses, hits, risers | one consistent hall, no stacked reverbs; hybrid layers saturated and wide | legato, pp dark to ff bright, release tails | mixed dry/wet libraries, synthetic strings | REC; hybrid layer SYN / processed REC; PM under REC if legato missing |
| **folk / acoustic** | steel/nylon guitar, banjo, mandolin, fiddle, upright, voice | close mic + room mic, ribbon warmth | real finger/string noise, a little room | perfectly clean, uniform picking | REC with release + noise layers |
| **Latin / reggaeton** | dembow (kick 1 and "and" of 2; snare "and" of 1 and 3), 808s, bright hats, congas/timbales/guiro, brass, guitars | heavy sidechain, dry tight drums | the dembow pattern and dry punch | straight kick-snare backbeat | drums HYB/SYN; aux percussion REC; guitars/brass REC; lead SYN |
| **Italian trap/pop** | trap: double/triple-time hats, 808, dark synths, autotune; pop: piano, electropop, R&B/baile-funk touches | as trap / pop | follow the sub-genre; **measure the reference** (no sourced chain for Mace/Calcutta) | assuming a sound without measuring | piano REC; drums HYB; synths SYN |

**Italian trap (measured, see `docs/research/trap-italiana.md`).** Eight Lazza / Sfera / Charlie Charles-era tracks sit at -6.2..-8.4 LUFS with crest 7-10 dB (louder than the generic -10 above), 55-70 % of energy below 150 Hz, 808 fundamentals 31-65 Hz (median about 55, short 110-220 ms retriggered notes, small 40-75 cent early drop, slides rare, THD about -6..-9 dB), kick body at 125-160 Hz above the 808 or a short 808-type kick, dry 55-90 ms snares/claps (body 270-330 Hz), tight hats (15-30 ms, centroid 7-8.6 kHz, open hats about 5 %, no swing), no sidechain pump, no noise bed. Melodic intros are dark (centroid 500-1100 Hz, rolloff95 1.1-2.7 kHz) and wide, with fundamentals B3-E4. Targets and the per-producer table are in the doc.

For every genre, `tape_wow=0` and `tape_flutter=0` are the starting defaults. Add either only when the brief names tape/vintage drift or measurements support it; keep it subtle and check the rendered sound at its intended `tape_mix`.

## What to measure when matching a reference (in this order)

Attack time and centroid are the most robust timbre dimensions (McAdams, Caclin et al. 2005).
1. onset: time to peak (within about 30 %);
2. spectral centroid and its trajectory over the first 300 ms (about 15 %, same direction);
3. pitch stability: drift, vibrato, onset scoop (held tone under 10 cents spread);
4. harmonic count, odd/even balance, rolloff slope (within 3 dB/oct);
5. flatness / noise-to-harmonic ratio;
6. band energies: sub <60 Hz, 200-500 Hz, 2-5 kHz, >10 kHz (about 3 dB each);
7. T60 / tail shape (about 25 %);
8. LUFS, crest, peak (genre: hip-hop/pop near -9.5..-10, jazz about -13, classical/folk/ambient -16..-18; crest within 2 dB);
9. stereo correlation, low-end mono (below 150 Hz correlation above 0.9);
10. saturation: 2f/3f share, fraction of near-full-scale samples;
11. soft vs loud centroid (louder must be brighter);
12. defects: aliasing >16 kHz, DC, clicks, loop seams.
Also: loudness-match before comparing; use the spread between references as the target; a name is not a measurement.

## Failure modes seen in Libero and the step that avoids them

- Hip-hop kit judged terrible: two genres in one map, crunch on snares, no bus glue, thin 808 -> route by genre, one genre per kit, measure reference LUFS/crest/808 band first.
- Synthetic guitar: waveguide with nothing recorded under it -> acoustic = REC first; PM only as an added layer.
- Reed/breath instruments rebuilt without measuring (duduk, pan-flute class): separate voices, measure on isolated passages, hybrid = recorded breath over a reed model; `odisseo-aulos` is the worked example.
- "Meow" built as a cat: named by resemblance, was a pitch-stable synth lead -> measure, classify, then route.
