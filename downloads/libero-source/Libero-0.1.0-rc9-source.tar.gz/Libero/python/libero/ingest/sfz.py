"""A structural SFZ reader: enough of the format to map real libraries into zones.

Handles `#define` / `#include` (anywhere on a line, recursively, relative to the root file),
`//` and `/* */` comments, the header hierarchy `<control> <global> <master> <group> <region>`
with inheritance, `default_path`, backslash paths, note names, `note_offset`/`octave_offset`,
keyswitch banks (`sw_last`/`sw_default`), CC-gated regions evaluated at their default CC values,
CC-triggered regions (`on_locc`) left out, velocity (`lovel/hivel`, `xfin_*`/`xfout_*`),
round robins (`seq_length/seq_position`, `lorand/hirand`), release triggers with `rt_decay`,
loops, `tune`/`transpose`/`volume`/`amplitude`, `offset`/`end`.

It does not evaluate modulation (`*_oncc`, curves, LFOs, filters): those belong to the live
engine, not to the sample map.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path

from .. import dsp

HEADERS = ("control", "global", "master", "group", "region", "curve", "effect", "midi", "sample")
_TOKEN = re.compile(r'(#define\s+(\$\w+)\s+(\S+))|(#include\s+"([^"]*)")|(<(\w+)>)|(?<![\w$])([\w$]+)=')
_VAR = re.compile(r"\$\w+")
_NOTE = re.compile(r"^([a-gA-G])([#b]?)(-?\d+)$")


class SfzError(ValueError):
    pass


@dataclass
class SfzRegion:
    sample: Path
    lokey: int
    hikey: int
    root: int
    lovel: int
    hivel: int
    trigger: str = "attack"
    tune_cents: float = 0.0
    gain_db: float = 0.0
    loop_mode: str | None = None
    loop_start: int | None = None
    loop_end: int | None = None
    offset: int = 0
    end: int | None = None
    rt_decay: float | None = None
    seq_length: int = 1
    seq_position: int = 1
    lorand: float = 0.0
    hirand: float = 1.0
    ampeg_release: float | None = None
    root_from_file: bool = False
    group_id: str = ""
    opcodes: dict = field(default_factory=dict)


@dataclass
class SfzInstrument:
    path: Path
    regions: list[SfzRegion]
    control: dict
    warnings: list[str]
    unsupported: set


def parse_note_value(v: str, note_offset: int = 0) -> int | None:
    v = v.strip()
    if re.fullmatch(r"-?\d+", v):
        n = int(v)
    else:
        m = _NOTE.match(v)
        if not m:
            return None
        n = dsp.parse_note(m.group(1).upper() + m.group(2) + m.group(3))
    return n + note_offset


def _strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", "", text)


def _tokens(path: Path, root_dir: Path, defines: dict, depth: int = 0):
    """Yield ('header', name) and ('op', key, value) in file order, expanding includes."""
    if depth > 16:
        raise SfzError("#include nesting deeper than 16 (a loop?)")
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        raise SfzError(f"cannot read {path}: {e}") from None
    text = _strip_comments(text)
    for line in text.splitlines():
        matches = list(_TOKEN.finditer(line))
        for i, m in enumerate(matches):
            nxt = matches[i + 1].start() if i + 1 < len(matches) else len(line)
            if m.group(1):
                defines[m.group(2)] = m.group(3)
            elif m.group(4):
                inc = (root_dir / _subst(m.group(5), defines).replace("\\", "/")).resolve()
                yield from _tokens(inc, root_dir, defines, depth + 1)
            elif m.group(6):
                yield ("header", m.group(7).lower())
            else:
                key = _subst(m.group(8), defines)
                val = _subst(line[m.end():nxt].strip(), defines)
                yield ("op", key, val)


def _subst(s: str, defines: dict) -> str:
    return _VAR.sub(lambda m: defines.get(m.group(0), m.group(0)), s)


def _num(v, default=None, cast=float):
    try:
        return cast(float(v)) if cast is int else cast(v)
    except (TypeError, ValueError):
        return default


def parse_sfz(path: Path | str) -> SfzInstrument:
    path = Path(path).resolve()
    root_dir = path.parent
    defines: dict = {}
    control: dict = {}
    scopes = {"global": {}, "master": {}, "group": {}}
    section = None
    raw_regions: list[tuple[dict, str]] = []
    current: dict | None = None
    group_serial = 0
    master_serial = 0
    for tok in _tokens(path, root_dir, defines):
        if tok[0] == "header":
            name = tok[1]
            if current is not None:
                raw_regions.append((current, f"m{master_serial}.g{group_serial}"))
                current = None
            section = name
            if name == "global":
                scopes = {"global": {}, "master": {}, "group": {}}
                group_serial += 1
                master_serial += 1
            elif name == "master":
                scopes["master"], scopes["group"] = {}, {}
                group_serial += 1
                master_serial += 1
            elif name == "group":
                scopes["group"] = {}
                group_serial += 1
            elif name == "region":
                current = {}
            continue
        _, key, val = tok
        if section == "control":
            control[key] = val
        elif section in scopes:
            scopes[section][key] = val
        elif section == "region" and current is not None:
            current[key] = val
        if section == "region" and current is not None and "__base" not in current:
            current["__base"] = {**scopes["global"], **scopes["master"], **scopes["group"]}
    if current is not None:
        raw_regions.append((current, f"m{master_serial}.g{group_serial}"))
    return _resolve(path, control, raw_regions)


def _default_ccs(control: dict) -> dict[int, float]:
    ccs: dict[int, float] = {7: 100.0, 10: 64.0}
    for k, v in control.items():
        m = re.fullmatch(r"set_(hd)?cc(\d+)", k)
        if m:
            x = _num(v, 0.0)
            ccs[int(m.group(2))] = x * 127.0 if m.group(1) else x
    return ccs


def _resolve(path: Path, control: dict, raw_regions) -> SfzInstrument:
    warnings: list[str] = []
    unsupported: set = set()
    note_offset = _num(control.get("note_offset"), 0, int) + 12 * _num(control.get("octave_offset"), 0, int)
    default_path = control.get("default_path", "").replace("\\", "/")
    ccs = _default_ccs(control)
    known = {"sample", "key", "lokey", "hikey", "pitch_keycenter", "lovel", "hivel", "trigger", "tune", "transpose",
             "volume", "amplitude", "loop_mode", "loopmode", "loop_start", "loopstart", "loop_end", "loopend",
             "offset", "end", "rt_decay", "seq_length", "seq_position", "lorand", "hirand", "ampeg_release",
             "sw_last", "sw_lokey", "sw_hikey", "sw_default", "sw_label", "xfin_lovel", "xfin_hivel", "xfout_lovel",
             "xfout_hivel", "group", "off_by", "polyphony", "note_polyphony", "off_time", "off_mode",
             "region_label", "group_label", "master_label", "global_label", "amp_veltrack", "pan", "ampeg_attack",
             "ampeg_decay", "ampeg_sustain", "ampeg_hold", "ampeg_dynamic", "pitch_keytrack", "default_path"}
    sw_default = None
    regions: list[SfzRegion] = []
    for raw, gid in raw_regions:
        op = {**raw.get("__base", {}), **{k: v for k, v in raw.items() if not k.startswith("__")}}
        if "sw_default" in op and sw_default is None:
            sw_default = parse_note_value(op["sw_default"], note_offset)
    skipped = {"keyswitch": 0, "cc_trigger": 0, "cc_gate": 0, "generator": 0, "trigger": 0}
    for raw, gid in raw_regions:
        op = {**raw.get("__base", {}), **{k: v for k, v in raw.items() if not k.startswith("__")}}
        sample = op.get("sample")
        if not sample:
            continue
        if sample.startswith("*"):
            skipped["generator"] += 1
            continue
        for k in op:
            base = re.sub(r"(_?on)?cc\d+$|_oncc\d+$|_curvecc\d+$|_smoothcc\d+$", "", k)
            if base not in known and not k.startswith(("label_cc", "set_cc", "set_hdcc", "sw_", "on_lo", "on_hi",
                                                       "locc", "hicc", "amplitude_", "amp_veltrack_", "pan_",
                                                       "ampeg_", "hdcc", "offset_", "volume_", "tune_", "pitch_")):
                unsupported.add(k)
        if "sw_last" in op and sw_default is not None:
            if parse_note_value(op["sw_last"], note_offset) != sw_default:
                skipped["keyswitch"] += 1
                continue
        if any(k.startswith(("on_locc", "on_hicc")) for k in op):
            skipped["cc_trigger"] += 1
            continue
        gated_out = False
        for k, v in op.items():
            m = re.fullmatch(r"(lo|hi)cc(\d+)", k)
            if m:
                cur = ccs.get(int(m.group(2)), 0.0)
                lim = _num(v, 0.0)
                if (m.group(1) == "lo" and cur < lim) or (m.group(1) == "hi" and cur > lim):
                    gated_out = True
        if gated_out:
            skipped["cc_gate"] += 1
            continue
        lokey = hikey = None
        if "key" in op:
            lokey = hikey = parse_note_value(op["key"], note_offset)
        if "lokey" in op:
            lokey = parse_note_value(op["lokey"], note_offset)
        if "hikey" in op:
            hikey = parse_note_value(op["hikey"], note_offset)
        root_from_file = False
        if "pitch_keycenter" in op:
            if op["pitch_keycenter"].strip().lower() == "sample":
                root, root_from_file = (lokey if lokey is not None else 60), True
            else:
                root = parse_note_value(op["pitch_keycenter"], note_offset)
        elif "key" in op:
            root = lokey
        else:
            root = 60
        if lokey is None:
            lokey = 0
        if hikey is None:
            hikey = 127
        if lokey < 0 or hikey < 0 or root is None:
            continue
        lokey, hikey = max(0, lokey), min(127, hikey)
        lovel = _num(op.get("lovel"), 1, int)
        hivel = _num(op.get("hivel"), 127, int)
        if "xfin_lovel" in op:
            lovel = min(lovel, _num(op["xfin_lovel"], lovel, int))
        if "xfout_hivel" in op:
            hivel = max(hivel, _num(op["xfout_hivel"], hivel, int))
        lovel, hivel = max(1, lovel), min(127, hivel)
        trig = op.get("trigger", "attack").lower()
        if trig not in ("attack", "release", "first", "legato", "release_key"):
            skipped["trigger"] += 1
            continue
        transpose = _num(op.get("transpose"), 0.0)
        gain = _num(op.get("volume"), 0.0)
        if "amplitude" in op:
            amp = _num(op["amplitude"], 100.0)
            gain += 20 * math.log10(max(amp, 1e-3) / 100.0)
        spath = (path.parent / (default_path + sample.replace("\\", "/"))).resolve()
        loop_mode = op.get("loop_mode", op.get("loopmode"))
        ls = op.get("loop_start", op.get("loopstart"))
        le = op.get("loop_end", op.get("loopend"))
        regions.append(SfzRegion(
            sample=spath, lokey=lokey, hikey=hikey, root=int(root) - int(transpose), lovel=lovel, hivel=hivel,
            trigger="release" if trig in ("release", "release_key") else "attack",
            tune_cents=_num(op.get("tune"), 0.0), gain_db=gain, loop_mode=loop_mode,
            loop_start=_num(ls, None, int), loop_end=_num(le, None, int), offset=_num(op.get("offset"), 0, int),
            end=_num(op.get("end"), None, int), rt_decay=_num(op.get("rt_decay"), None),
            seq_length=_num(op.get("seq_length"), 1, int), seq_position=_num(op.get("seq_position"), 1, int),
            lorand=_num(op.get("lorand"), 0.0), hirand=_num(op.get("hirand"), 1.0),
            ampeg_release=_num(op.get("ampeg_release"), None), root_from_file=root_from_file, group_id=gid,
            opcodes=op))
    for k, n in skipped.items():
        if n:
            why = {"keyswitch": "belong to a non-default keyswitch bank",
                   "cc_trigger": "are triggered by a controller (pedal noises etc.)",
                   "cc_gate": "are switched off at the default controller values",
                   "generator": "use built-in generators (*sine, *noise)",
                   "trigger": "use legato/first/other triggers"}[k]
            warnings.append(f"{n} regions skipped: they {why}")
    if not regions:
        warnings.append("no playable regions found")
    return SfzInstrument(path, regions, control, warnings, unsupported)


def take_index(regions: list[SfzRegion]) -> list[int]:
    """Round-robin index per region: seq_position-1, or the rank of its lorand band among regions
    sharing the same key/velocity cell."""
    out = []
    bands: dict[tuple, list[float]] = {}
    for r in regions:
        bands.setdefault((r.trigger, r.lokey, r.hikey, r.lovel, r.hivel), []).append(r.lorand)
    for r in regions:
        if r.seq_length > 1:
            out.append(max(0, r.seq_position - 1))
        else:
            b = sorted(set(bands[(r.trigger, r.lokey, r.hikey, r.lovel, r.hivel)]))
            out.append(b.index(r.lorand) if len(b) > 1 else 0)
    return out
