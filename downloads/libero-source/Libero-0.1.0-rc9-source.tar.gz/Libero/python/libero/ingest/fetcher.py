"""Fetch a subset of a catalogued library into $LIBERO_HOME/cache/libraries/<id>/.

Only what is asked for is downloaded: GitHub repos are listed with the tree API and fetched
file by file, an SFZ subset (`sfz:Harp.sfz`) pulls exactly the samples that file references,
Zenodo archives are extracted while streaming so only the subset lands on disk. Sizes are
shown before anything large is downloaded, and a disk budget is enforced.
"""

from __future__ import annotations

import datetime as _dt
import fnmatch
import json
import os
import re
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote, urljoin

import httpx

from .. import library
from .catalog import BY_ID, Source

UA = "libero/0.2 (sample library fetcher)"
CONFIRM_MB = 500
DEFAULT_MAX_MB = 1500
MIN_FREE_GB = 5.0


class FetchError(Exception):
    pass


@dataclass
class Plan:
    source: Source
    files: list[tuple[str, int, str]] = field(default_factory=list)  # (relative path, bytes or -1, url)
    stream: dict | None = None  # zenodo: {"url", "patterns"}
    notes: list[str] = field(default_factory=list)

    @property
    def total_bytes(self) -> int:
        return sum(max(0, s) for _, s, _ in self.files)


def libraries_dir() -> Path:
    p = library.cache_dir() / "libraries"
    p.mkdir(parents=True, exist_ok=True)
    return p


def library_dir(sid: str) -> Path:
    return libraries_dir() / sid


def _source(sid: str) -> Source:
    if sid not in BY_ID:
        raise FetchError(f"unknown library '{sid}'; see library_search()")
    return BY_ID[sid]


def _gh_headers() -> dict:
    h = {"User-Agent": UA, "Accept": "application/vnd.github+json"}
    tok = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if not tok and shutil.which("gh"):
        try:
            r = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, timeout=10)
            tok = r.stdout.strip() if r.returncode == 0 else None
        except (OSError, subprocess.TimeoutExpired):
            tok = None
    if tok:
        h["Authorization"] = f"Bearer {tok}"
    return h


def github_tree(src: Source, refresh: bool = False) -> list[dict]:
    """[{path, size}] of every file in the repo branch (cached for a week)."""
    d = library_dir(src.id)
    d.mkdir(parents=True, exist_ok=True)
    cache = d / "_tree.json"
    if cache.exists() and not refresh and time.time() - cache.stat().st_mtime < 7 * 86400:
        return json.loads(cache.read_text())
    f = src.fetch
    url = f"https://api.github.com/repos/{f['repo']}/git/trees/{quote(f['branch'])}?recursive=1"
    r = httpx.get(url, headers=_gh_headers(), timeout=60, follow_redirects=True)
    if r.status_code != 200:
        raise FetchError(f"GitHub tree listing failed ({r.status_code}): {r.text[:200]}")
    data = r.json()
    if data.get("truncated"):
        raise FetchError("the repository tree is too large for one listing (truncated)")
    files = [{"path": t["path"], "size": t.get("size", 0)} for t in data["tree"] if t["type"] == "blob"]
    cache.write_text(json.dumps(files))
    return files


def _raw_url(src: Source, path: str) -> str:
    f = src.fetch
    return f"https://raw.githubusercontent.com/{f['repo']}/{quote(f['branch'])}/{quote(path)}"


def _match(path: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatchcase(path, p) or fnmatch.fnmatchcase(path, p.rstrip("*").rstrip("/") + "/*")
               and p.endswith("**") for p in patterns)


def _download(url: str, dst: Path, expect: int = -1, lfs_url: str | None = None, client: httpx.Client | None = None):
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".part")
    c = client or httpx.Client(headers={"User-Agent": UA}, follow_redirects=True, timeout=120)
    for attempt in range(3):
        try:
            with c.stream("GET", url) as r:
                if r.status_code != 200:
                    raise FetchError(f"HTTP {r.status_code} for {url}")
                with open(tmp, "wb") as fh:
                    for chunk in r.iter_bytes(1 << 16):
                        fh.write(chunk)
            head = tmp.read_bytes()[:64] if tmp.stat().st_size < 1024 else b""
            if head.startswith(b"version https://git-lfs") and lfs_url and url != lfs_url:
                url = lfs_url
                continue
            if expect > 0 and tmp.stat().st_size != expect and not head.startswith(b"version https://git-lfs"):
                raise FetchError(f"size mismatch for {dst.name}: {tmp.stat().st_size} != {expect}")
            os.replace(tmp, dst)
            return
        except (httpx.HTTPError, FetchError):
            if attempt == 2:
                raise
            time.sleep(1.5 * (attempt + 1))
    raise FetchError(f"could not download {url}")


def _sfz_closure(src: Source, sfz_path: str, tree: list[dict]) -> list[str]:
    """Fetch an SFZ file and its #includes, parse it, and return the repo paths it needs."""
    from .sfz import parse_sfz

    d = library_dir(src.id)
    sizes = {t["path"]: t["size"] for t in tree}
    if sfz_path not in sizes:
        cands = [p for p in sizes if p.lower().endswith(".sfz")]
        raise FetchError(f"{sfz_path} is not in {src.id}; SFZ files: {', '.join(cands[:40])}")
    needed = [sfz_path]
    seen = set()
    queue = [sfz_path]
    root_dir = Path(sfz_path).parent
    while queue:
        p = queue.pop()
        if p in seen:
            continue
        seen.add(p)
        local = d / p
        if not local.exists():
            _download(_raw_url(src, p), local, sizes.get(p, -1))
        for inc in re.findall(r'#include\s+"([^"]+)"', local.read_text(errors="replace")):
            ip = str((root_dir / inc.replace("\\", "/")).as_posix())
            ip = os.path.normpath(ip)
            if ip in sizes:
                needed.append(ip)
                queue.append(ip)
    ins = parse_sfz(d / sfz_path)
    base = d.resolve()
    lower = {p.lower(): p for p in sizes}
    for r in ins.regions:
        try:
            rel = str(r.sample.resolve().relative_to(base))
        except ValueError:
            continue
        if rel in sizes:
            needed.append(rel)
        elif rel.lower() in lower:  # case-insensitive filesystems in the original library
            needed.append(lower[rel.lower()])
    for extra in ("LICENSE", "LICENSE.md", "LICENSE.txt", "README.md"):
        if extra in sizes:
            needed.append(extra)
    return sorted(set(needed))


def resolve_subset(src: Source, subset: str) -> list[str]:
    if not subset:
        if not src.subsets:
            return ["**"]
        raise FetchError(f"choose a subset of {src.id}: {', '.join(src.subsets)} (or 'full', a glob, or "
                         f"'sfz:<file>.sfz')")
    if subset == "full":
        return ["**"]
    val = src.subsets.get(subset, subset)
    if isinstance(val, str):
        return [v.strip() for v in val.split(",") if v.strip()]
    return list(val)


def make_plan(sid: str, subset: str = "") -> Plan:
    src = _source(sid)
    kind = src.fetch["type"]
    plan = Plan(src)
    if kind == "manual":
        raise FetchError(f"{src.name} cannot be fetched automatically: download it from {src.fetch['url']} "
                         f"and bring it in with sample_import ({src.license}).")
    patterns = resolve_subset(src, subset)
    if kind == "github":
        tree = github_tree(src)
        paths: list[str] = []
        globs = []
        for p in patterns:
            if p.startswith("sfz:"):
                paths += _sfz_closure(src, p[4:], tree)
            else:
                globs.append(p)
        if globs:
            paths += [t["path"] for t in tree if any(fnmatch.fnmatchcase(t["path"], g) for g in globs)
                      or ("**" in globs)]
        sizes = {t["path"]: t["size"] for t in tree}
        for p in sorted(set(paths)):
            plan.files.append((p, sizes.get(p, -1), _raw_url(src, p)))
        if not plan.files:
            raise FetchError(f"subset {subset!r} matches no files in {src.id}")
    elif kind == "zenodo":
        url = f"https://zenodo.org/api/records/{src.fetch['record']}/files/{src.fetch['file']}/content"
        if patterns == ["**"]:
            raise FetchError(f"{src.id} is one {src.size_mb:.0f} MB archive: give a subset "
                             f"({', '.join(src.subsets)}) so only that part is kept")
        plan.stream = {"url": url, "patterns": patterns}
        plan.notes.append(f"streams the whole {src.size_mb:.0f} MB archive once and keeps only the subset")
    elif kind == "iowa":
        base = src.fetch["base"]
        for p in patterns:
            page, _, glob = p.partition("|")
            if not page.startswith("page:"):
                raise FetchError("iowa subsets look like 'page:MISviolin2012.html' or 'page:X.html|*arco*'")
            html = httpx.get(urljoin(base, page[5:]), headers={"User-Agent": UA}, timeout=60,
                             follow_redirects=True).text
            for href in re.findall(r'href="([^"]+\.(?:aif|aiff|wav|zip))"', html, flags=re.I):
                name = href.split("/")[-1]
                if glob and not fnmatch.fnmatch(name, glob):
                    continue
                plan.files.append((href.replace("sound files/", ""), -1, urljoin(base, quote(href))))
        if not plan.files:
            raise FetchError("no audio links found on that page")
    else:
        raise FetchError(f"unsupported fetch type {kind}")
    return plan


def _index(sid: str) -> dict:
    p = library_dir(sid) / "_index.json"
    if p.exists():
        try:
            return json.loads(p.read_text())
        except json.JSONDecodeError:
            pass
    return {"id": sid, "files": {}, "subsets": []}


def _save_index(sid: str, idx: dict):
    p = library_dir(sid) / "_index.json"
    p.write_text(json.dumps(idx, indent=1))


def usage_mb() -> dict:
    out = {}
    for d in sorted(libraries_dir().iterdir()):
        if d.is_dir():
            out[d.name] = round(sum(f.stat().st_size for f in d.rglob("*") if f.is_file()) / 1e6, 1)
    return out


def fetch(sid: str, subset: str = "", max_mb: float = DEFAULT_MAX_MB, confirm: bool = False,
          dry_run: bool = False) -> dict:
    """Download `subset` of library `sid`. Refuses above `max_mb`; above 500 MB it only reports
    sizes unless confirm=True. Returns a compact report (path, counts, sizes, sfz files)."""
    src = _source(sid)
    plan = make_plan(sid, subset)
    d = library_dir(sid)
    idx = _index(sid)
    missing = [(p, s, u) for p, s, u in plan.files if not (d / p).exists()]
    missing_mb = sum(max(0, s) for _, s, _ in missing) / 1e6
    total_mb = plan.total_bytes / 1e6
    free_gb = shutil.disk_usage(library.home() if library.home().exists() else Path.home()).free / 1e9
    report = {"library": sid, "name": src.name, "license": src.license, "license_class": src.license_class,
              "subset": subset or "full", "path": str(d), "files": len(plan.files) or None,
              "total_mb": round(total_mb, 1), "to_download_mb": round(missing_mb, 1),
              "free_disk_gb": round(free_gb, 1), "notes": plan.notes}
    if plan.stream:
        report["to_download_mb"] = src.size_mb
    if missing_mb > max_mb:
        raise FetchError(f"{src.id} subset '{subset}' needs {missing_mb:.0f} MB, above the {max_mb:.0f} MB budget. "
                         f"Pick a smaller subset (e.g. {', '.join(list(src.subsets)[:4])}) or raise max_mb.")
    if free_gb - missing_mb / 1e3 < MIN_FREE_GB:
        raise FetchError(f"only {free_gb:.1f} GB free on disk; refusing to go below {MIN_FREE_GB:.0f} GB")
    if dry_run or (missing_mb > CONFIRM_MB and not confirm) or (plan.stream and not confirm):
        report["status"] = ("dry run" if dry_run else f"not downloaded: {max(missing_mb, 0):.0f} MB — call again with "
                            f"confirm=True to proceed")
        return report
    d.mkdir(parents=True, exist_ok=True)
    if plan.stream:
        got = _stream_tar(plan.stream["url"], plan.stream["patterns"], d, max_mb)
        for p, s in got.items():
            idx["files"][p] = s
    elif missing:
        errors = []
        with httpx.Client(headers={"User-Agent": UA}, follow_redirects=True, timeout=180,
                          limits=httpx.Limits(max_connections=8)) as client:
            def job(item):
                p, s, u = item
                lfs = None
                if src.fetch["type"] == "github":
                    f = src.fetch
                    lfs = f"https://media.githubusercontent.com/media/{f['repo']}/{quote(f['branch'])}/{quote(p)}"
                try:
                    _download(u, d / p, s, lfs, client)
                except Exception as e:  # collect, report at the end
                    errors.append(f"{p}: {e}")
            with ThreadPoolExecutor(8) as ex:
                list(ex.map(job, missing))
        if errors:
            raise FetchError(f"{len(errors)} files failed, e.g. {errors[0]}")
    for p, s, _ in plan.files:
        if (d / p).exists():
            idx["files"][p] = (d / p).stat().st_size
    if subset and subset not in idx["subsets"]:
        idx["subsets"].append(subset)
    idx["retrieved"] = _dt.date.today().isoformat()
    _save_index(sid, idx)
    fetched = [p for p, _, _ in plan.files] if plan.files else list(idx["files"])
    report["status"] = "ok"
    report["downloaded_mb"] = round(missing_mb, 1)
    report["sfz"] = sorted(p for p in fetched if p.lower().endswith(".sfz"))[:20]
    report["audio_files"] = sum(1 for p in fetched if p.lower().endswith((".wav", ".flac", ".aif", ".aiff", ".ogg")))
    report["library_cache_mb"] = round(sum(usage_mb().values()), 1)
    return report


def _stream_tar(url: str, patterns: list[str], dest: Path, max_mb: float) -> dict:
    import tarfile

    kept: dict[str, int] = {}
    total = 0
    with httpx.stream("GET", url, headers={"User-Agent": UA}, follow_redirects=True, timeout=600) as r:
        if r.status_code != 200:
            raise FetchError(f"HTTP {r.status_code} for {url}")

        class _Raw:
            def __init__(self, it):
                self.it = it
                self.buf = b""

            def read(self, n=-1):
                while n < 0 or len(self.buf) < n:
                    try:
                        self.buf += next(self.it)
                    except StopIteration:
                        break
                if n < 0:
                    out, self.buf = self.buf, b""
                else:
                    out, self.buf = self.buf[:n], self.buf[n:]
                return out

        with tarfile.open(fileobj=_Raw(r.iter_bytes(1 << 16)), mode="r|gz") as tf:
            for m in tf:
                if not m.isfile() or not any(fnmatch.fnmatchcase(m.name, p) for p in patterns):
                    continue
                total += m.size
                if total / 1e6 > max_mb:
                    raise FetchError(f"subset exceeds {max_mb:.0f} MB")
                target = (dest / m.name).resolve()
                if dest.resolve() not in target.parents:
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                fh = tf.extractfile(m)
                with open(target, "wb") as out:
                    shutil.copyfileobj(fh, out)
                kept[m.name] = m.size
    if not kept:
        raise FetchError("no archive member matched the subset")
    return kept
