"""Legal sample sources: the catalogue, subset fetching, and SFZ / WAV-set importers."""

from .catalog import BY_ID, SOURCES, Source, search
from .fetcher import FetchError, fetch, library_dir, make_plan, usage_mb
from .importers import import_sfz, import_wav_set, parse_name
from .sfz import parse_sfz

__all__ = ["BY_ID", "SOURCES", "Source", "search", "FetchError", "fetch", "library_dir", "make_plan", "usage_mb",
           "import_sfz", "import_wav_set", "parse_name", "parse_sfz"]
