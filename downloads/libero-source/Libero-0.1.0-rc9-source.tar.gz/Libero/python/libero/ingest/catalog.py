"""The registry of legal multisample and impulse-response sources (from
docs/research/sample-sources.md). Every entry says what it is, its licence class, where
it lives and how to fetch a subset of it. Repo names, branches and licences were checked
against the GitHub API / source pages; sizes are approximate (repository size)."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

from ..licenses import SHIPPABLE


@dataclass
class Source:
    id: str
    name: str
    instruments: list[str]
    family: str
    license: str
    license_class: str
    author: str
    url: str
    fetch: dict                       # {"type": "github", "repo", "branch"} | zenodo | iowa | manual
    size_mb: float
    quality: int                      # 1..5, honest verdict for Kontakt-class use
    format: str                       # sfz | wav-set | ir | archive
    layers: str = ""
    subsets: dict = field(default_factory=dict)   # name -> [glob, ...] or "sfz:<file>"
    notes: str = ""

    @property
    def shippable(self) -> bool:
        return self.license_class in SHIPPABLE

    def card(self) -> dict:
        d = asdict(self)
        d["shippable"] = self.shippable
        return d


def _gh(repo: str, branch: str = "master") -> dict:
    return {"type": "github", "repo": repo, "branch": branch}


_SAL_LAYERS = [1, 3, 5, 7, 9, 11, 13, 16]

SOURCES: list[Source] = [
    Source("salamander-grand-v3", "Salamander Grand Piano V3", ["grand piano", "piano", "yamaha c5"], "piano",
           "CC BY 3.0", "by", "Alexander Holm", "https://github.com/sfzinstruments/SalamanderGrandPiano",
           _gh("sfzinstruments/SalamanderGrandPiano"), 750, 5, "sfz",
           "16 velocity layers, roots every minor third A0-C8, chromatic hammer-release samples, "
           "string-resonance releases, pedal noises; 48 kHz / 24 bit FLAC",
           {"full": ["**"],
            "layers8": ["*.sfz", "Data/*", "LICENSE", "README.md"]
                       + [f"Samples/[A-G]*v{v}.flac" for v in _SAL_LAYERS] + ["Samples/rel*.flac"],
            "layers4": ["*.sfz", "Data/*", "LICENSE", "README.md"]
                       + [f"Samples/[A-G]*v{v}.flac" for v in (2, 7, 12, 16)] + ["Samples/rel*.flac"]},
           "The best free piano. The SFZ is a control surface (#define/#include, keyswitch banks); "
           "import_sfz reads it structurally. layers8 ≈ 330 MB."),
    Source("vsco2-ce", "VSCO 2: Community Edition", ["violin", "viola", "cello", "contrabass", "string section",
           "harp", "flute", "oboe", "clarinet", "bassoon", "piccolo", "horn", "trumpet", "trombone", "tuba",
           "upright piano", "organ", "glockenspiel", "marimba", "xylophone", "timpani", "percussion"],
           "orchestral", "CC0 1.0", "cc0", "Versilian Studios (Sam Gossner)", "https://github.com/sgossner/VSCO-2-CE",
           _gh("sgossner/VSCO-2-CE", "SFZ"), 3240, 4, "sfz",
           "per articulation (sustain vib/non-vib, staccato, spiccato, pizzicato, tremolo); 1-2 velocity "
           "layers; RR on shorts; 44.1 kHz WAV, no loops",
           {"harp": "sfz:Harp.sfz", "marimba": "sfz:Marimba.sfz", "glockenspiel": "sfz:Glockenspiel.sfz",
            "flute": "sfz:FluteSusVib.sfz", "oboe": "sfz:OboeSusVib.sfz", "clarinet": "sfz:ClarinetSus.sfz",
            "bassoon": "sfz:BassoonSus.sfz", "horn": "sfz:FHornSus.sfz", "cello-section": "sfz:CelloEnsSusVib.sfz",
            "contrabass-pizz": "sfz:ContrabassPizz.sfz", "organ": "sfz:OrganLoud.sfz"},
           "Best free orchestral base. Sustains are unlooped: use process loop='auto'. Subsets can be any "
           "'sfz:<file>.sfz' in the repo root: only the samples it references are fetched."),
    Source("vcsl", "Versilian Community Sample Library", ["steinway", "kawai grand", "upright piano", "harpsichord",
           "harp", "pipe organ", "recorder", "ocarina", "harmonica", "marimba", "vibraphone", "xylophone",
           "glockenspiel", "tubular bells", "kalimba", "mbira", "balafon", "dan tranh", "timpani", "snare",
           "cymbal", "saxello", "tenor sax", "didgeridoo", "fm synth"], "various", "CC0 1.0", "cc0",
           "Versilian Studios (Sam Gossner)", "https://github.com/sgossner/VCSL", _gh("sgossner/VCSL"), 3970, 3,
           "wav-set", "mostly 1 RR and 2-3 velocity layers; names carry note, dynamic, rr, mic",
           {"marimba": ["Idiophones/Struck Idiophones/Marimba/*"],
            "vibraphone": ["Idiophones/Struck Idiophones/Vibraphone*/*"],
            "concert-harp": ["Chordophones/Composite Chordophones/Concert Harp/*"],
            "folk-harp": ["Chordophones/Composite Chordophones/Folk Harp/*"],
            "steinway-b": ["Chordophones/Zithers/Grand Piano, Steinway B/**"],
            "harpsichord-flemish": ["Chordophones/Zithers/Harpsichord, Flemish/**"],
            "pipe-organ-loud": ["Aerophones/Edge-blown Aerophones/Pipe Organ/Loud/*"],
            "alto-recorder": ["Aerophones/Edge-blown Aerophones/Baroque Alto Recorder/**"]},
           "Widest CC0 pool (ethnic, mallets, harpsichord, organ). WAV-only: use import_wav_set on a folder. "
           "Subsets are folder globs; look at library_info for the tree."),
    Source("tinysol", "TinySOL (IRCAM)", ["violin", "viola", "cello", "contrabass", "flute", "oboe", "clarinet",
           "bassoon", "alto sax", "horn", "trumpet", "trombone", "tuba", "accordion"], "orchestral",
           "CC BY 4.0", "by", "Cella, Ghisi, Lostanlen, Lévy, Fineberg, Maresz (IRCAM)",
           "https://zenodo.org/records/3685367",
           {"type": "zenodo", "record": "3685367", "file": "TinySOL.tar.gz"}, 1030, 3, "wav-set",
           "ordinario single notes at pp/mf/ff, 44.1 kHz; no releases, no loops",
           {"violin": ["*Strings/Violin/ordinario/*"], "viola": ["*Strings/Viola/ordinario/*"],
            "cello": ["*Strings/Violoncello/ordinario/*"], "contrabass": ["*Strings/Contrabass/ordinario/*"],
            "flute": ["*Winds/Flute/ordinario/*"], "oboe": ["*Winds/Oboe/ordinario/*"],
            "clarinet": ["*Winds/Clarinet_Bb/ordinario/*"], "bassoon": ["*Winds/Bassoon/ordinario/*"],
            "alto-sax": ["*Winds/Sax_Alto/ordinario/*"], "horn": ["*Brass/Horn/ordinario/*"],
            "trumpet": ["*Brass/Trumpet_C/ordinario/*"], "trombone": ["*Brass/Trombone/ordinario/*"],
            "tuba": ["*Brass/Bass_Tuba/ordinario/*"], "accordion": ["*Keyboards/Accordion/ordinario/*"]},
           "One 1 GB archive: a subset is extracted while streaming (the whole archive is downloaded once, "
           "only the subset is kept). Clean studio notes for hybrid layers."),
    Source("iowa-mis", "University of Iowa Musical Instrument Samples", ["flute", "oboe", "clarinet", "bassoon",
           "saxophone", "horn", "trumpet", "trombone", "tuba", "violin", "viola", "cello", "double bass",
           "marimba", "xylophone", "vibraphone", "bells", "crotales", "cymbals", "gongs", "piano"], "orchestral",
           "free to use without restriction (site notice)", "by", "University of Iowa Electronic Music Studios",
           "https://theremin.music.uiowa.edu/MIS.html",
           {"type": "iowa", "base": "https://theremin.music.uiowa.edu/"}, 5000, 3, "archive",
           "pp/mf/ff chromatic runs per file (post-2012: stereo 24/96); anechoic",
           {"violin": ["page:MISviolin2012.html"], "cello": ["page:MIScello2012.html"],
            "flute": ["page:MISflute.html"], "marimba": ["page:Mismarimba.html"]},
           "Informal permission, no licence text: keep the URL and date in the credits. Files hold chromatic "
           "runs: cut them into notes with sample_split before import_wav_set."),
    Source("karoryfer-bigcat-cello", "Karoryfer Bigcat Cello", ["cello"], "bowed", "CC0 1.0", "cc0", "Karoryfer",
           "https://github.com/sfzinstruments/karoryfer-bigcat.cello", _gh("sfzinstruments/karoryfer-bigcat.cello"),
           130, 4, "sfz", "527 samples, 24 bit, several articulations", {}, "Character solo cello."),
    Source("karoryfer-meatbass", "Karoryfer Meatbass", ["double bass", "upright bass"], "bowed", "CC0 1.0", "cc0",
           "Karoryfer", "https://github.com/sfzinstruments/karoryfer.meatbass", _gh("sfzinstruments/karoryfer.meatbass"),
           250, 4, "sfz", "plucked double bass with RR", {}, ""),
    Source("karoryfer-smolken", "Smolken Double Bass", ["double bass"], "bowed", "CC0 1.0", "cc0", "D. Smolken / Karoryfer",
           "https://github.com/sfzinstruments/dsmolken.double-bass", _gh("sfzinstruments/dsmolken.double-bass"),
           260, 4, "sfz", "arco and pizzicato", {}, ""),
    Source("karoryfer-bear-sax", "Karoryfer Bear Sax", ["baritone sax", "saxophone"], "wind", "CC0 1.0", "cc0",
           "Karoryfer", "https://github.com/sfzinstruments/karoryfer.bear-sax", _gh("sfzinstruments/karoryfer.bear-sax"),
           127, 4, "sfz", "1926 Conn baritone", {}, ""),
    Source("karoryfer-weresax", "Karoryfer Weresax", ["tenor sax", "saxophone"], "wind", "CC0 1.0", "cc0", "Karoryfer",
           "https://github.com/sfzinstruments/karoryfer.weresax", _gh("sfzinstruments/karoryfer.weresax"),
           193, 4, "sfz", "", {}, ""),
    Source("karoryfer-war-tuba", "Karoryfer War Tuba", ["tuba"], "brass", "CC0 1.0", "cc0", "Karoryfer",
           "https://github.com/sfzinstruments/karoryfer.war-tuba", _gh("sfzinstruments/karoryfer.war-tuba"),
           106, 4, "sfz", "", {}, ""),
    Source("karoryfer-squidpipes", "Karoryfer Squidpipes", ["bagpipes", "pipes"], "wind", "CC0 1.0", "cc0", "Karoryfer",
           "https://github.com/sfzinstruments/karoryfer.squidpipes", _gh("sfzinstruments/karoryfer.squidpipes"),
           43, 3, "sfz", "", {}, ""),
    Source("karoryfer-emilyguitar", "Karoryfer Emilyguitar", ["electric guitar", "guitar"], "plucked", "CC0 1.0",
           "cc0", "Karoryfer", "https://github.com/sfzinstruments/karoryfer.emilyguitar",
           _gh("sfzinstruments/karoryfer.emilyguitar"), 101, 4, "sfz", "", {}, ""),
    Source("karoryfer-shinyguitar", "Karoryfer Shinyguitar", ["electric guitar", "guitar"], "plucked", "CC0 1.0",
           "cc0", "Karoryfer", "https://github.com/sfzinstruments/karoryfer.shinyguitar",
           _gh("sfzinstruments/karoryfer.shinyguitar"), 360, 4, "sfz", "", {}, ""),
    Source("karoryfer-black-and-green-guitars", "Karoryfer Black and Green Guitars", ["guitar", "acoustic guitar"],
           "plucked", "CC0 1.0", "cc0", "Karoryfer", "https://github.com/sfzinstruments/karoryfer.black-and-green-guitars",
           _gh("sfzinstruments/karoryfer.black-and-green-guitars", "main"), 454, 4, "sfz", "", {}, ""),
    Source("karoryfer-string-cyborgs", "Karoryfer String Cyborgs", ["strings", "cinematic strings"], "bowed",
           "CC0 1.0", "cc0", "Karoryfer", "https://github.com/sfzinstruments/karoryfer.string-cyborgs",
           _gh("sfzinstruments/karoryfer.string-cyborgs"), 62, 3, "sfz", "", {}, "Character texture strings."),
    Source("karoryfer-big-rusty-drums", "Karoryfer Big Rusty Drums", ["drum kit", "drums"], "percussion", "CC0 1.0",
           "cc0", "Karoryfer", "https://github.com/sfzinstruments/karoryfer.big-rusty-drums",
           _gh("sfzinstruments/karoryfer.big-rusty-drums", "main"), 603, 5, "sfz", "multi-mic, many layers and RR", {}, ""),
    Source("karoryfer-frankensnare", "Karoryfer Frankensnare", ["snare"], "percussion", "CC0 1.0", "cc0", "Karoryfer",
           "https://github.com/sfzinstruments/karoryfer.frankensnare", _gh("sfzinstruments/karoryfer.frankensnare", "main"),
           336, 5, "sfz", "", {}, ""),
    Source("karoryfer-gogodze-phu", "Karoryfer Gogodze Phu vol. I", ["hand drums", "percussion"], "percussion",
           "CC0 1.0", "cc0", "Karoryfer", "https://github.com/sfzinstruments/karoryfer.gogodze-phu-vol-i",
           _gh("sfzinstruments/karoryfer.gogodze-phu-vol-i"), 30, 4, "sfz", "", {}, ""),
    Source("karoryfer-caveman-cosmonaut", "Karoryfer Caveman Cosmonaut", ["synth"], "synth", "CC0 1.0", "cc0",
           "Karoryfer", "https://github.com/sfzinstruments/karoryfer.caveman-cosmonaut",
           _gh("sfzinstruments/karoryfer.caveman-cosmonaut"), 95, 3, "sfz", "", {}, ""),
    Source("karoryfer-horse-pulse", "Karoryfer Horse Pulse", ["synth", "pulse"], "synth", "CC0 1.0", "cc0", "Karoryfer",
           "https://github.com/sfzinstruments/Karoryfer.HorsePulse", _gh("sfzinstruments/Karoryfer.HorsePulse", "main"),
           140, 3, "sfz", "", {}, ""),
    Source("headroom-piano", "Headroom Piano", ["upright piano", "piano"], "piano", "CC BY 4.0", "by",
           "Bengt Nilsson", "https://github.com/sfzinstruments/BengtNilsson.HeadroomPiano",
           _gh("sfzinstruments/BengtNilsson.HeadroomPiano"), 137, 3, "sfz", "", {}, "Character upright."),
    Source("osiris-piano", "Osiris Piano", ["piano"], "piano", "CC0 1.0", "cc0", "sfzinstruments",
           "https://github.com/sfzinstruments/Osiris_Piano", _gh("sfzinstruments/Osiris_Piano", "main"), 448, 3, "sfz",
           "", {}, ""),
    Source("mtg-solo-sax", "MTG Solo Sax", ["alto sax", "saxophone"], "wind", "CC BY 4.0", "by",
           "Music Technology Group, UPF", "https://github.com/sfzinstruments/MTG.SoloSax",
           _gh("sfzinstruments/MTG.SoloSax"), 102, 3, "sfz", "", {}, ""),
    Source("ixox-flute", "Ixox Flute", ["flute"], "wind", "CC BY 4.0", "by", "Ixox",
           "https://github.com/sfzinstruments/Ixox.Flute", _gh("sfzinstruments/Ixox.Flute"), 9, 2, "sfz", "", {}, ""),
    Source("hungarian-zither", "Hungarian Zither", ["zither", "citera"], "plucked", "CC0 1.0", "cc0", "sfzinstruments",
           "https://github.com/sfzinstruments/hungarian_zither", _gh("sfzinstruments/hungarian_zither", "main"),
           677, 4, "sfz", "", {}, ""),
    Source("cithara-barbarica", "Cithara Barbarica", ["lyre", "cithara", "psaltery"], "plucked", "CC0 1.0", "cc0",
           "sfzinstruments", "https://github.com/sfzinstruments/cithara-barbarica",
           _gh("sfzinstruments/cithara-barbarica", "main"), 172, 4, "sfz", "", {}, "An ancient-lyre-like instrument."),
    Source("erhu", "Erhu (aliexpress-erhu)", ["erhu", "bowed"], "bowed", "CC0 1.0", "cc0", "sfzinstruments",
           "https://github.com/sfzinstruments/aliexpress-erhu", _gh("sfzinstruments/aliexpress-erhu", "main"),
           80, 3, "sfz", "", {}, ""),
    Source("drs-kit", "DrumGizmo DRS Kit", ["drum kit", "drums"], "percussion", "CC BY 4.0", "by", "DrumGizmo",
           "https://github.com/sfzinstruments/DrumGizmo.DRSKit", _gh("sfzinstruments/DrumGizmo.DRSKit"), 736, 5, "sfz",
           "multi-mic, many layers", {}, ""),
    Source("naked-drums", "Wilkinson Audio Naked Drums", ["drum kit", "drums"], "percussion", "CC BY 4.0", "by",
           "Wilkinson Audio", "https://github.com/sfzinstruments/WilkinsonAudio.NakedDrums",
           _gh("sfzinstruments/WilkinsonAudio.NakedDrums"), 1250, 5, "sfz", "up to 10 RR", {}, ""),
    Source("philharmonia", "Philharmonia Orchestra samples (mirror)", ["violin", "viola", "cello", "double bass",
           "flute", "oboe", "cor anglais", "clarinet", "bass clarinet", "bassoon", "contrabassoon", "saxophone",
           "horn", "trumpet", "trombone", "tuba", "guitar", "banjo", "mandolin", "percussion"], "orchestral",
           "CC BY-SA 3.0 (not as-is)", "by-sa", "Philharmonia Orchestra",
           "https://github.com/skratchdot/philharmonia-samples", _gh("skratchdot/philharmonia-samples", "gh-pages"),
           196, 3, "archive", "several dynamics and lengths per note (MP3 origin)", {},
           "Share-alike and must not be redistributed as-is: use only as a transformed hybrid ingredient."),
    # impulse responses
    Source("openair", "OpenAIR impulse responses", ["church", "hall", "cistern", "room", "reverb"], "ir",
           "CC BY 4.0 (per item)", "by", "University of York / contributors", "https://www.openairlib.net",
           {"type": "manual", "url": "https://www.openairlib.net"}, 0, 4, "ir", "", {},
           "The site is script-driven: download an IR by hand, then sample_import it as the sound's impulse."),
    Source("echothief", "EchoThief impulse responses", ["cave", "stairwell", "glacier", "natural space"], "ir",
           "personal use and derivative work; commercial terms unclear", "unknown", "Chris Warren",
           "http://www.echothief.com", {"type": "manual", "url": "http://www.echothief.com/downloads/"}, 0, 4, "ir",
           "", {}, "Private lane until the author confirms commercial terms."),
    # private-lane examples, listed so the agent does not mistake them for free sources
    Source("pianobook", "Pianobook packs", ["various"], "various", "site EULA: no redistribution of derivatives",
           "eula", "various", "https://www.pianobook.co.uk", {"type": "manual", "url": "https://www.pianobook.co.uk"},
           0, 4, "sfz", "", {}, "Private lane only: a shared Libero bundle would be a forbidden derivative."),
    Source("jrhodes", "jRhodes3 (Jeff Learman)", ["rhodes", "electric piano"], "keys", "CC BY-NC", "nc",
           "Jeff Learman", "https://github.com/sfzinstruments/jlearman.jRhodes3d",
           _gh("sfzinstruments/jlearman.jRhodes3d"), 163, 4, "sfz", "", {}, "Non-commercial: private lane only."),
]

BY_ID = {s.id: s for s in SOURCES}


def search(query: str = "", family: str = "", license: str = "shippable", max_results: int = 8) -> list[Source]:
    """Rank sources by how well `query` matches their instruments and name."""
    q = [w for w in query.lower().replace("-", " ").split() if w]
    out = []
    for s in SOURCES:
        if license == "shippable" and not s.shippable:
            continue
        if family and s.family != family:
            continue
        hay_i = " ".join(s.instruments).lower()
        hay = f"{s.name} {hay_i} {s.family} {s.notes}".lower()
        if q:
            score = 0.0
            for w in q:
                if any(w == i or w in i.split() for i in s.instruments):
                    score += 3
                elif w in hay_i:
                    score += 2
                elif w in hay:
                    score += 1
            if score == 0:
                continue
        else:
            score = 0.0
        out.append((score + s.quality * 0.3, s))
    out.sort(key=lambda t: -t[0])
    return [s for _, s in out[:max_results]]
