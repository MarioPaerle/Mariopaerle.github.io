"""Synthesis primitives. Every function returns an `Audio` and is deterministic
for a given `seed`.

Oscillators are band-limited (additive up to 0.45·sr with a soft taper, or
polyBLEP); physical models are linear recursions run through `lfilter`, so
they are exact, in tune and fast.
"""

from __future__ import annotations

import math
from typing import Callable, Sequence

import numpy as np
from scipy import signal

from . import dsp
from .audio import DEFAULT_SR, Audio

FreqLike = float | np.ndarray | Callable[[np.ndarray], np.ndarray]


def _n(dur: float, sr: int) -> int:
    return max(1, int(round(dur * sr)))


def _freq_array(freq: FreqLike, n: int, sr: int) -> np.ndarray:
    if callable(freq):
        return np.asarray(freq(np.arange(n) / sr), dtype=np.float64)
    f = np.asarray(freq, dtype=np.float64)
    if f.ndim == 0:
        return np.full(n, float(f))
    if len(f) != n:
        f = np.interp(np.linspace(0, len(f) - 1, n), np.arange(len(f)), f)
    return f


def _phase_cycles(freq: np.ndarray, sr: int, phase0: float = 0.0) -> np.ndarray:
    """Running phase in cycles, wrapped to [0,1) (kept in float64)."""
    ph = phase0 + np.concatenate([[0.0], np.cumsum(freq[:-1] / sr)])
    return ph - np.floor(ph)


def vibrato(freq: float, rate: float = 5.0, cents: float = 15.0, delay: float = 0.3,
            drift_cents: float = 0.0, seed: int = 0, phase: float = 0.0) -> Callable[[np.ndarray], np.ndarray]:
    """A frequency function for oscillators: vibrato (starting at `phase` radians) fading in
    after `delay`, plus optional slow random drift. Use as `saw(vibrato(220), dur=3)`.
    For loopable material use delay=0, drift_cents=0 and a LoopGrid-snapped rate."""
    # 2^(c/1200) averages slightly above 1 over a cycle (by I0(cents·ln2/1200)); dividing it out
    # keeps the mean frequency exactly `freq`, so a LoopGrid-snapped vibrato stays periodic
    norm = float(np.i0(cents * math.log(2) / 1200))

    def f(t: np.ndarray) -> np.ndarray:
        fade = np.clip((t - delay) / max(delay, 1e-3), 0, 1) if delay > 0 else 1.0
        c = cents * fade * np.sin(2 * math.pi * rate * t + phase)
        if drift_cents:
            rng = np.random.default_rng(seed)
            k = max(4, int(t[-1] * 2) + 4)
            knots = rng.standard_normal(k) * drift_cents
            c = c + np.interp(t, np.linspace(0, t[-1] + 1e-9, k), knots)
        return freq * 2 ** (c / 1200) / norm
    return f


class LoopGrid:
    """Frequencies that repeat exactly over a loop, so sustained material can be
    looped with no seam at all (chorused pads, beating ensembles, LFOs).

        g = synth.LoopGrid(ctx.freq, seconds=4.0, sr=ctx.sr)
        voices = [synth.saw(g.cents(c), dur) for c in (-7, 0, 6)]
        lfo_rate = g.rate(0.3)

    `g.freq` is the fundamental snapped to a whole number of cycles in exactly
    `g.samples` samples (a multiple of `quantum`, 256 by default, which matches the
    block size of `formant`; error < 0.3 cent, 0.01 cent with quantum=1); `cents()`/`snap()` put other voices
    on the same grid (resolution 1/seconds Hz), `rate()` does the same for LFOs.
    Anything built only from these frequencies is periodic with period
    `g.samples`; the compiler's loop finder then lands on a seam far below -30 dB
(about -100 dB for plain oscillators; time-varying filters add a little)."""

    def __init__(self, freq: float, seconds: float = 4.0, sr: int = DEFAULT_SR, quantum: int = 256):
        # `samples` is a multiple of `quantum` so block-wise processors (formant(block=quantum))
        # update their coefficients at the same phase every period; costs < 0.3 cent of accuracy
        cycles = max(1, round(freq * seconds))
        q = max(1, int(quantum))
        self.samples = max(q, int(round(cycles * sr / freq / q)) * q)
        self.quantum = q
        self.sr = sr
        self.seconds = self.samples / sr
        self.freq = cycles * sr / self.samples

    def snap(self, f: float) -> float:
        return max(1, round(f * self.seconds)) / self.seconds

    def cents(self, c: float) -> float:
        return self.freq if c == 0 else self.snap(self.freq * 2 ** (c / 1200))

    def rate(self, hz: float) -> float:
        return self.snap(hz)


# ---------------------------------------------------------------- oscillators

def sine(freq: FreqLike, dur: float, sr: int = DEFAULT_SR, amp: float = 0.5, phase: float = 0.0) -> Audio:
    """Sine; `freq` may be a number, an array (per sample) or a function of time (see vibrato)."""
    n = _n(dur, sr)
    ph = _phase_cycles(_freq_array(freq, n, sr), sr, phase)
    return Audio(amp * np.sin(2 * math.pi * ph), sr)


def _additive_wave(freq: FreqLike, dur: float, sr: int, amp_of_k: Callable[[int], float],
                   phase_of_k: Callable[[int], float], amp: float, phase: float = 0.0) -> Audio:
    n = _n(dur, sr)
    f = _freq_array(freq, n, sr)
    ph = _phase_cycles(f, sr, phase)
    fmax = float(np.max(f))
    kmax = max(1, int(0.45 * sr / max(fmax, 1.0)))
    y = np.zeros(n)
    two_pi_ph = 2 * math.pi * ph
    for k in range(1, kmax + 1):
        a = amp_of_k(k)
        if a == 0.0:
            continue
        # soft taper over the top 25 % of the band, per sample (tracks glides)
        fk = k * f
        taper = np.clip((0.45 * sr - fk) / (0.12 * sr), 0.0, 1.0)
        y += a * taper * np.sin(k * two_pi_ph + phase_of_k(k))
    return Audio(amp * y, sr)


def saw(freq: FreqLike, dur: float, sr: int = DEFAULT_SR, amp: float = 0.4, method: str = "additive",
        phase: float = 0.0) -> Audio:
    """Band-limited sawtooth. method: 'additive' (alias-free) or 'blep' (polyBLEP, faster).
    `phase` (cycles, 0..1) is the starting phase: give stacked voices different phases, or
    their edges line up into a click every time they realign."""
    if method == "blep":
        return _blep(freq, dur, sr, amp, "saw", phase)
    return _additive_wave(freq, dur, sr, lambda k: (2 / math.pi) * ((-1) ** (k + 1)) / k, lambda k: 0.0, amp, phase)


def square(freq: FreqLike, dur: float, sr: int = DEFAULT_SR, amp: float = 0.4, method: str = "additive",
           phase: float = 0.0) -> Audio:
    """Band-limited square (odd harmonics). method: 'additive' or 'blep'; phase in cycles."""
    if method == "blep":
        return _blep(freq, dur, sr, amp, "square", phase)
    return _additive_wave(freq, dur, sr, lambda k: (4 / math.pi) / k if k % 2 else 0.0, lambda k: 0.0, amp, phase)


def tri(freq: FreqLike, dur: float, sr: int = DEFAULT_SR, amp: float = 0.5, phase: float = 0.0) -> Audio:
    """Band-limited triangle (odd harmonics falling at 12 dB/oct); phase in cycles."""
    return _additive_wave(freq, dur, sr,
                          lambda k: (8 / math.pi**2) * ((-1) ** ((k - 1) // 2)) / k**2 if k % 2 else 0.0,
                          lambda k: 0.0, amp, phase)


def _blep(freq: FreqLike, dur: float, sr: int, amp: float, shape: str, phase: float = 0.0) -> Audio:
    n = _n(dur, sr)
    f = _freq_array(freq, n, sr)
    dt = np.clip(f / sr, 1e-9, 0.5)
    ph = _phase_cycles(f, sr, phase)

    def blep(t):
        out = np.zeros_like(t)
        a = t < dt
        x = t[a] / dt[a]
        out[a] = x + x - x * x - 1.0
        b = t > 1.0 - dt
        x = (t[b] - 1.0) / dt[b]
        out[b] = x * x + x + x + 1.0
        return out

    if shape == "saw":
        y = 2.0 * ph - 1.0 - blep(ph)
    else:
        y = np.where(ph < 0.5, 1.0, -1.0) + blep(ph) - blep((ph + 0.5) % 1.0)
    return Audio(amp * y, sr)


def additive(freq: float, partials: Sequence[tuple[float, float, float]], dur: float, sr: int = DEFAULT_SR,
             amp: float = 0.5, seed: int = 0, attack: float = 0.002) -> Audio:
    """Sum of partials [(ratio, amp, t60_seconds), ...]; t60<=0 means no decay.
    Phases are random (seeded) to avoid a spiky sum. Partials above 0.45·sr are dropped."""
    n = _n(dur, sr)
    t = np.arange(n) / sr
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    for ratio, a, t60 in partials:
        fk = freq * ratio
        ph = rng.uniform(0, 2 * math.pi)
        if fk >= 0.45 * sr or a == 0:
            continue
        env = 10 ** (-3 * t / t60) if t60 and t60 > 0 else 1.0
        y += a * env * np.sin(2 * math.pi * fk * t + ph)
    if attack > 0:
        k = min(n, int(attack * sr))
        y[:k] *= np.sin(0.5 * math.pi * np.arange(k) / k)
    pk = np.abs(y).max(initial=0)
    return Audio(amp * y / pk if pk > 0 else y, sr)


def fm(carrier: float, ratio: float = 1.0, index: float = 2.0, dur: float = 2.0, sr: int = DEFAULT_SR,
       env: Sequence[tuple[float, float]] | None = None, index_t60: float = 0.0, feedback: float = 0.0,
       amp: float = 0.5) -> Audio:
    """Two-operator phase modulation. `index_t60` makes the brightness decay
    (seconds to fall 60 dB); `env` is an amplitude breakpoint list [(t, gain)]."""
    n = _n(dur, sr)
    t = np.arange(n) / sr
    fmod = carrier * ratio
    idx = index * (10 ** (-3 * t / index_t60) if index_t60 > 0 else 1.0)
    # keep the sidebands under Nyquist: Carson bandwidth ≈ 2(I+1)fm
    limit = (0.45 * sr - carrier) / max(fmod, 1e-9) - 1
    idx = np.minimum(idx, max(0.0, limit))
    mod = np.sin(2 * math.pi * fmod * t)
    if feedback:
        mod = np.sin(2 * math.pi * fmod * t + feedback * mod)
    y = np.sin(2 * math.pi * carrier * t + idx * mod)
    a = Audio(amp * y, sr)
    return a.envelope(env) if env else a


# ---------------------------------------------------------------- noise

def noise(color: str = "white", dur: float = 1.0, sr: int = DEFAULT_SR, seed: int = 0, stereo: bool = False,
          rms_db: float = -15.0) -> Audio:
    """Coloured noise with an exact spectral slope: white (0 dB/oct), pink (-3),
    brown (-6), blue (+3), violet (+6). Normalised to `rms_db` dBFS."""
    n = _n(dur, sr)
    slopes = {"white": 0.0, "pink": -0.5, "brown": -1.0, "red": -1.0, "blue": 0.5, "violet": 1.0}
    if color not in slopes:
        raise ValueError(f"noise color must be one of {list(slopes)}")
    rng = np.random.default_rng(seed)
    ch = 2 if stereo else 1
    w = rng.standard_normal((n, ch))
    if slopes[color] != 0.0:
        W = np.fft.rfft(w, axis=0)
        f = np.fft.rfftfreq(n, 1 / sr)
        f[0] = f[1] if n > 1 else 1.0
        shape = (np.maximum(f, 10.0) / 1000.0) ** slopes[color]
        w = np.fft.irfft(W * shape[:, None], n, axis=0)
    w -= w.mean(axis=0)
    w /= math.sqrt(float(np.mean(w**2))) + 1e-30
    w *= dsp.undb(rms_db)
    return Audio(w[:, 0] if ch == 1 else w, sr)


def breath(dur: float = 4.0, sr: int = DEFAULT_SR, seed: int = 0, brightness: float = 0.5,
           motion: float = 0.5, stereo: bool = True) -> Audio:
    """Breath / air: pink noise shaped by soft vocal-tract bands with slow, random
    swells (`motion` 0..1). Good for choir air, flute breath, room tone."""
    n = _n(dur, sr)
    nz = noise("pink", dur, sr, seed, stereo=stereo)
    centre = 900 + 2600 * brightness
    bands = [(centre * 0.55, 0.9, -4.0), (centre, 1.2, 0.0), (centre * 2.1, 1.6, -3.0), (centre * 3.7, 2.0, -9.0)]
    y = None
    for f, q, g in bands:
        b = nz.bandpass(min(f, 0.45 * sr), q).gain_db(g)
        y = b if y is None else y.mix(b)
    y = y.highpass(180).lowpass(min(16000, 7000 + 9000 * brightness))
    # slow swells: smoothed random walk, 0.2–1 Hz
    rng = np.random.default_rng(seed + 7)
    k = max(4, int(dur * (0.4 + motion)))
    knots = np.clip(1.0 + motion * 0.6 * rng.standard_normal(k + 2), 0.25, 2.0)
    from scipy.interpolate import PchipInterpolator
    env = PchipInterpolator(np.arange(k + 2), knots)(np.linspace(0, k + 1, n))
    env = np.clip(env, 0.15, 2.5)
    d = y.data.astype(np.float64)
    d = d * (env if d.ndim == 1 else env[:, None])
    return Audio(d, sr).normalize_rms(-24.0)


# ---------------------------------------------------------------- plucked string

def karplus(freq: float, dur: float = 4.0, bright: float = 0.6, damping: float = 0.4, pick_position: float = 0.18,
            sr: int = DEFAULT_SR, seed: int = 0, decay: float | None = None, velocity: float = 1.0,
            amp: float = 0.6) -> Audio:
    """Extended Karplus–Strong plucked string (Jaffe & Smith), exactly in tune.

    bright         0..1  excitation brightness and loop-filter openness
    damping        0..1  0 = rings ~10 s, 1 = palm-muted (~0.25 s); ignored if `decay` given
    decay          seconds for the fundamental to fall 60 dB
    pick_position  0..0.5 fraction of the string length (comb notch on the excitation)
    velocity       0..1  softer plucks are darker

    The loop is z^-M · one-zero lowpass · first-order allpass; the allpass
    coefficient is solved so the total loop phase delay at `freq` is exactly
    sr/freq samples."""
    n = _n(dur, sr)
    P = sr / freq
    # One-zero loop filter (1-s) + s z^-1. Its loss per *period* is ~ s(1-s)w^2, so a fixed s
    # makes high strings far duller per *second* than low ones. Scale s(1-s) ~ f^-0.7 around
    # 262 Hz so the upper partials of every string fade at a similar rate, as on a real instrument.
    s_ref = 0.5 - 0.32 * float(np.clip(bright, 0, 1))
    ss = min(0.25, s_ref * (1 - s_ref) * (262.0 / freq) ** 0.7)
    s = 0.5 * (1 - math.sqrt(max(0.0, 1 - 4 * ss)))
    w0 = 2 * math.pi * freq / sr

    def lp_resp(w):
        return (1 - s) + s * np.exp(-1j * w)

    pd_lp = -np.angle(lp_resp(w0)) / w0
    M = int(math.floor(P - pd_lp - 0.1))
    d_ap = P - M - pd_lp  # in [0.1, 1.1)
    c = _allpass_coeff_for_delay(d_ap, w0)
    if decay is None:
        decay = 10.0 * (0.025 ** float(np.clip(damping, 0, 1)))
    g_total = 10 ** (-3.0 / (decay * freq))
    g = min(0.99995, g_total / abs(lp_resp(w0)))

    # closed loop: Y = X / (1 - g z^-M H(z) A(z)),  H = (1-s) + s z^-1,  A = (c + z^-1)/(1 + c z^-1)
    # multiply through by (1 + c z^-1):
    #   Y (1 + c z^-1) - g z^-M [(1-s) + s z^-1][c + z^-1] Y = X (1 + c z^-1)
    num_ha = np.convolve([1 - s, s], [c, 1.0]) * g  # 3 taps
    a = np.zeros(M + 3)
    a[0] = 1.0
    a[1] += c
    a[M: M + 3] -= num_ha
    b = np.array([1.0, c])

    # excitation: the plucked string's initial shape (a triangle peaking at the pick point, whose
    # harmonics fall as sin(k·pi·beta)/k^2, so the fundamental is always there) plus filtered noise
    # for the grain of the finger/plectrum. Brighter and harder → more noise, higher cutoff.
    rng = np.random.default_rng(seed)
    L = int(round(P))
    v = float(np.clip(velocity, 0.05, 1))
    beta = float(np.clip(pick_position, 0.02, 0.5))
    k = max(1, int(round(beta * L)))
    tri = np.concatenate([np.linspace(0, 1, k, endpoint=False), np.linspace(1, 0, L - k)])
    tri -= tri.mean()
    nz = rng.uniform(-1, 1, L)
    pp = int(round(beta * P))
    if 0 < pp < L:
        nz = nz - np.concatenate([np.zeros(pp), nz[:-pp]])  # the pick-position comb on the noise part
    nz -= nz.mean()
    nz *= np.abs(tri).max() / (np.abs(nz).max() + 1e-12)
    exc = tri + (0.2 + 0.6 * bright * v) * nz
    cutoff = min(0.45 * sr, freq * (3 + 30 * bright * v) + 1500 * bright)
    exc = signal.sosfilt(signal.butter(2, cutoff, fs=sr, output="sos"), np.concatenate([exc, np.zeros(L)]))
    x = np.zeros(n)
    x[: min(n, len(exc))] = exc[:n]
    y = signal.lfilter(b, a, x)
    y = dsp.dc_block(y, sr, 12.0)
    pk = np.abs(y).max(initial=0)
    y = y / pk * amp * (0.35 + 0.65 * v) if pk > 0 else y
    return Audio(y, sr)


def _allpass_coeff_for_delay(d: float, w: float) -> float:
    """Coefficient c of (c + z^-1)/(1 + c z^-1) whose phase delay at w equals d."""
    def pdelay(c):
        z = np.exp(-1j * w)
        return -np.angle((c + z) / (1 + c * z)) / w

    lo, hi = -0.999, 0.999  # delay decreases as c increases
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if pdelay(mid) > d:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# ---------------------------------------------------------------- modal synthesis

MODES: dict[str, list[tuple[float, float, float]]] = {
    # (ratio to the named pitch, t60 seconds at freq=440 (scaled by pitch), amplitude)
    # church bell: hum, prime, tierce (minor third), quint, nominal, and upper partials
    "bell": [(0.5, 9.0, 0.55), (1.0, 6.5, 0.8), (1.183, 5.0, 0.6), (1.506, 3.8, 0.35), (2.0, 3.2, 1.0),
             (2.514, 2.4, 0.45), (2.662, 2.2, 0.4), (3.011, 1.7, 0.3), (4.166, 1.2, 0.25), (5.433, 0.8, 0.18),
             (6.796, 0.55, 0.12)],
    # wine glass / glass bowl: widely spaced, long, pure
    "glass": [(1.0, 9.0, 1.0), (2.32, 5.5, 0.42), (4.25, 3.2, 0.22), (6.63, 1.9, 0.12), (9.38, 1.1, 0.07),
              (12.6, 0.7, 0.04)],
    # tuned wooden bar (marimba-like 1 : 4 : 10) with short decays
    "wood": [(1.0, 1.1, 1.0), (3.93, 0.35, 0.35), (9.61, 0.12, 0.12), (1.52, 0.2, 0.08), (5.8, 0.09, 0.05)],
    # thin metal plate: dense inharmonic cluster
    "metal_plate": [(1.0, 4.0, 1.0), (1.59, 3.6, 0.8), (2.14, 3.1, 0.7), (2.30, 3.0, 0.55), (2.65, 2.6, 0.6),
                    (2.92, 2.4, 0.5), (3.16, 2.2, 0.45), (3.50, 2.0, 0.4), (4.15, 1.6, 0.35), (4.60, 1.4, 0.3),
                    (5.20, 1.2, 0.25), (6.13, 0.9, 0.2), (7.26, 0.7, 0.14), (8.61, 0.5, 0.1)],
    # tubular / chime: bar modes, the 'strike note' is the 4th-5th-6th mode hum
    "chime": [(1.0, 5.0, 1.0), (2.76, 3.4, 0.6), (5.40, 2.2, 0.4), (8.93, 1.4, 0.25), (13.34, 0.9, 0.15)],
}


def exciter(kind: str = "mallet", sr: int = DEFAULT_SR, hardness: float = 0.5, seed: int = 0,
            max_width: float | None = None) -> Audio:
    """Short excitation signals: 'impulse', 'mallet' (raised cosine, 0.4–6 ms wide
    by hardness, capped at `max_width` seconds), 'pluck' (noise burst), 'scrape'
    (60 ms rough noise)."""
    rng = np.random.default_rng(seed)
    if kind == "impulse":
        x = np.zeros(64)
        x[0] = 1.0
    elif kind == "mallet":
        w_s = 0.0004 + 0.006 * (1 - hardness)
        if max_width:
            w_s = min(w_s, max_width)
        width = int(sr * w_s)
        x = np.sin(np.linspace(0, math.pi, max(3, width))) ** 2
        x = np.concatenate([x, np.zeros(64)])
    elif kind == "pluck":
        k = int(0.004 * sr)
        x = rng.uniform(-1, 1, k) * np.exp(-np.linspace(0, 5, k))
    elif kind == "scrape":
        k = int(0.06 * sr)
        x = rng.standard_normal(k) * np.hanning(k) * (0.4 + 0.6 * rng.random(k))
    else:
        raise ValueError("exciter kind: impulse | mallet | pluck | scrape")
    return Audio(x, sr)


def modal(freq: float, modes: str | Sequence[tuple[float, float, float]] = "bell", dur: float = 5.0,
          sr: int = DEFAULT_SR, exciter_audio: Audio | None = None, hardness: float = 0.6,
          decay_scale: float = 1.0, detune_cents: float = 0.0, seed: int = 0, amp: float = 0.6,
          stereo: bool = False) -> Audio:
    """Modal resonator bank. `modes` is a preset name (bell, glass, wood,
    metal_plate, chime) or [(ratio, t60_s, amp), ...]. Each mode is an exact
    two-pole resonator driven by the exciter (default: a mallet of `hardness`).
    Preset decays are scaled by (440/freq)^0.5 so low notes ring longer.
    `detune_cents` spreads each mode randomly (beating, 'warble'); with
    stereo=True each side gets its own spread."""
    if isinstance(modes, str):
        if modes not in MODES:
            raise ValueError(f"modal preset must be one of {list(MODES)}")
        table = MODES[modes]
        pitch_scale = (440.0 / freq) ** 0.5
    else:
        table = list(modes)
        pitch_scale = 1.0
    n = _n(dur, sr)
    ex = exciter_audio.resample(sr).to_mono().data.astype(np.float64) if exciter_audio is not None \
        else exciter("mallet", sr, hardness, seed, max_width=0.9 / freq).data.astype(np.float64)
    x = np.zeros(n)
    x[: min(n, len(ex))] = ex[:n]
    rng = np.random.default_rng(seed)
    chans = []
    for ch in range(2 if stereo else 1):
        y = np.zeros(n)
        for ratio, t60, a in table:
            cents = rng.standard_normal() * detune_cents if detune_cents else 0.0
            f = freq * ratio * 2 ** (cents / 1200)
            if f >= 0.45 * sr or a == 0:
                continue
            T = max(0.005, t60 * decay_scale * pitch_scale)
            r = 10 ** (-3.0 / (T * sr))
            w = 2 * math.pi * f / sr
            # b0 = sin w: impulse response r^n sin((n+1)w), unit initial amplitude whatever the decay
            b = [math.sin(w)]
            aa = [1.0, -2 * r * math.cos(w), r * r]
            # hardness also tilts which modes the mallet excites (upper modes weaker when soft)
            tilt = min(1.0, (ratio ** -(1.2 * (1 - hardness)))) if ratio > 1 else 1.0
            y += a * tilt * signal.lfilter(b, aa, x)
        chans.append(y)
    y = np.stack(chans, axis=1) if stereo else chans[0]
    y = dsp.dc_block(y, sr, 10.0)
    pk = np.abs(y).max(initial=0)
    return Audio(y / pk * amp if pk > 0 else y, sr)


def bell(freq: float, dur: float = 6.0, **kw) -> Audio:
    return modal(freq, "bell", dur, **kw)


def glass(freq: float, dur: float = 6.0, **kw) -> Audio:
    return modal(freq, "glass", dur, **kw)


def wood(freq: float, dur: float = 2.0, **kw) -> Audio:
    return modal(freq, "wood", dur, **kw)


def metal_plate(freq: float, dur: float = 5.0, **kw) -> Audio:
    return modal(freq, "metal_plate", dur, **kw)


# ---------------------------------------------------------------- bowed / rubbed

def bow(freq: float, dur: float = 4.0, sr: int = DEFAULT_SR, body: str | Sequence = "string",
        pressure: float = 0.5, bright: float = 0.5, attack: float = 0.25, release: float = 0.3,
        vibrato_cents: float = 0.0, seed: int = 0, amp: float = 0.5) -> Audio:
    """Continuously excited resonator: friction noise (pulsed at the fundamental
    when body='string', like stick-slip) drives either a lossy string waveguide
    (body='string') or a modal bank (body='glass'/'bell'/.../custom modes, for
    rubbed glass and bowed metal). `pressure` 0..1 = more noise and grit."""
    n = _n(dur, sr)
    t = np.arange(n) / sr
    rng = np.random.default_rng(seed)
    bow_env = np.minimum(1.0, t / max(attack, 1e-3)) ** 1.5
    rel_n = int(release * sr)
    if rel_n > 0 and rel_n < n:
        bow_env[-rel_n:] *= np.linspace(1, 0, rel_n) ** 2
    # slow bow-speed wander
    k = max(4, int(dur * 3))
    wander = np.interp(t, np.linspace(0, t[-1] + 1e-9, k), 1 + 0.12 * rng.standard_normal(k))
    fr = noise("pink" if bright < 0.5 else "white", dur, sr, seed + 1).data.astype(np.float64)
    fr = signal.sosfilt(signal.butter(2, [min(200 + freq, 0.4 * sr), min(2000 + 12000 * bright, 0.45 * sr)],
                                      "bandpass", fs=sr, output="sos"), fr)
    if isinstance(body, str) and body == "string":
        f_arr = freq * 2 ** (vibrato_cents * np.sin(2 * math.pi * 5.2 * t) * np.clip(t - 0.4, 0, 1) / 1200)
        ph = _phase_cycles(f_arr, sr)
        pulse = np.exp(-((ph - 0.1) ** 2) / (2 * (0.03 + 0.05 * pressure) ** 2))  # slip bursts
        drive = (0.35 + pressure) * fr * (0.4 + pulse) + 0.25 * (pulse - pulse.mean())
        drive *= bow_env * wander
        # lossy waveguide at freq (lfilter comb with a one-zero damping filter)
        P = sr / freq
        M = int(math.floor(P - 0.5))
        frac = P - 0.5 - M
        g = 0.995 - 0.02 * (1 - bright)
        a = np.zeros(M + 3)
        a[0] = 1.0
        # fractional delay by linear interpolation between M and M+1 inside the (0.5,0.5) average
        taps = np.convolve([0.5, 0.5], [1 - frac, frac]) * g
        a[M: M + 3] -= taps
        y = signal.lfilter([1.0], a, drive)
        y = y + 0.15 * drive
        # wooden body: a few broad formants
        a_ = Audio(y, sr).peak(280, 5, 1.2).peak(520, 3, 1.5).peak(3000, 3, 1.0).highpass(max(40, freq * 0.6))
        y = a_.data.astype(np.float64)
    else:
        drive = fr * bow_env * wander * (0.6 + 0.8 * pressure)
        table = MODES[body] if isinstance(body, str) else list(body)
        y = np.zeros(n)
        for ratio, t60, am in table:
            f = freq * ratio
            if f >= 0.45 * sr:
                continue
            T = max(0.05, t60)
            r = 10 ** (-3.0 / (T * sr))
            w = 2 * math.pi * f / sr
            y += am * signal.lfilter([math.sin(w) * (1 - r)], [1.0, -2 * r * math.cos(w), r * r], drive)
        y = y + 0.02 * pressure * drive
    y = dsp.dc_block(y, sr, 15.0)
    pk = np.abs(y).max(initial=0)
    return Audio(y / pk * amp if pk > 0 else y, sr)


# ---------------------------------------------------------------- formants

VOWELS: dict[str, list[tuple[float, float, float]]] = {
    # (freq Hz, bandwidth Hz, gain dB) — a mixed alto/soprano choir set
    "a": [(800, 80, 0), (1150, 90, -4), (2900, 120, -20), (3900, 130, -30), (4950, 140, -35)],
    "e": [(400, 60, 0), (1600, 80, -24), (2700, 120, -30), (3300, 150, -35), (4950, 200, -60)],
    "i": [(270, 60, 0), (2140, 90, -12), (2950, 100, -26), (3900, 120, -26), (4950, 120, -44)],
    "o": [(450, 70, 0), (800, 80, -9), (2830, 100, -16), (3800, 130, -28), (4950, 135, -55)],
    "u": [(325, 50, 0), (700, 60, -12), (2530, 170, -30), (3500, 180, -40), (4950, 200, -64)],
}


def formant(src: Audio, vowel: str | Sequence[tuple[float, str]] = "a", amount: float = 1.0,
            shift: float = 1.0, block: int = 256) -> Audio:
    """Shape `src` with a parallel bank of 5 vowel formants.

    vowel: 'a' | 'e' | 'i' | 'o' | 'u', or keyframes [(time_s, vowel), ...]
           to morph (e.g. [(0, 'a'), (3, 'o')]).
    amount: 0 = dry, 1 = fully vocal. shift scales all formant frequencies
    (≈1.15 for a brighter, younger voice)."""
    sr = src.sr
    x = src.data.astype(np.float64)
    x2 = dsp.as_2d(x)
    n = len(x2)
    keys = [(0.0, vowel)] if isinstance(vowel, str) else sorted(vowel, key=lambda k: k[0])
    for _, v in keys:
        if v not in VOWELS:
            raise ValueError(f"vowel must be one of {list(VOWELS)}")
    kt = np.array([k[0] for k in keys])
    tab = np.array([VOWELS[k[1]] for k in keys])  # (K, 5, 3)
    out = np.zeros_like(x2)
    zi = [np.zeros((x2.shape[1], 2)) for _ in range(5)]
    for start in range(0, n, block):
        seg = x2[start: start + block]
        tc = (start + len(seg) / 2) / sr
        params = np.array([[np.interp(tc, kt, tab[:, j, c]) for c in range(3)] for j in range(5)])
        acc = np.zeros_like(seg)
        for j, (f, bw, g) in enumerate(params):
            f = min(f * shift, 0.45 * sr)
            q = f / max(bw, 1.0)
            sos = dsp.rbj_biquad("bandpass", f, sr, q)[0]
            b, a = sos[:3], sos[3:]
            for c in range(seg.shape[1]):
                y, zi[j][c] = signal.lfilter(b, a, seg[:, c], zi=zi[j][c])
                acc[:, c] += dsp.undb(g) * y
        out[start: start + len(seg)] = acc
    # match loudness of the dry signal
    r_in = math.sqrt(float(np.mean(x2**2)) + 1e-30)
    r_out = math.sqrt(float(np.mean(out**2)) + 1e-30)
    out *= r_in / r_out
    y = (1 - amount) * x2 + amount * out
    return Audio(y[:, 0] if x.ndim == 1 else y, sr)


# ---------------------------------------------------------------- impulse responses

_IR_KINDS = {
    # t60 low/high (s), predelay (s), early reflections count, density, brightness
    "room": dict(t60=0.7, t60_hi=0.35, pre=0.004, early=10, spread=0.03, bright=0.55),
    "hall": dict(t60=2.6, t60_hi=1.2, pre=0.018, early=14, spread=0.08, bright=0.5),
    "plate": dict(t60=2.0, t60_hi=1.6, pre=0.0, early=0, spread=0.0, bright=0.8),
    "cave": dict(t60=5.5, t60_hi=1.4, pre=0.03, early=6, spread=0.25, bright=0.3),
    "spring": dict(t60=2.2, t60_hi=0.9, pre=0.0, early=0, spread=0.0, bright=0.6),
    # instrument bodies (short, strongly coloured) for convolving dry sources
    "wood": dict(t60=0.09, t60_hi=0.03, pre=0.0, early=0, spread=0.0, bright=0.45),
    "metal": dict(t60=0.6, t60_hi=0.4, pre=0.0, early=0, spread=0.0, bright=0.8),
}


def impulse_response(kind: str = "hall", seconds: float | None = None, sr: int = DEFAULT_SR, seed: int = 0,
                     stereo: bool = True, t60: float | None = None) -> Audio:
    """Synthesised impulse response: kind = room | hall | plate | cave | spring
    (spaces, stereo) or wood | metal (instrument-body resonances for convolving
    dry sources). The late tail is decorrelated noise with a per-octave
    exponential decay (highs die first); spaces get sparse early reflections;
    spring adds dispersive chirps. Peak-normalised to -1 dBFS."""
    if kind not in _IR_KINDS:
        raise ValueError(f"IR kind must be one of {list(_IR_KINDS)}")
    p = dict(_IR_KINDS[kind])
    if t60:
        ratio = t60 / p["t60"]
        p["t60"], p["t60_hi"] = t60, p["t60_hi"] * ratio
    L = seconds or min(12.0, p["t60"] * 1.3 + p["pre"] + 0.05)
    n = _n(L, sr)
    rng = np.random.default_rng(seed)
    ch = 2 if stereo else 1
    t = np.arange(n) / sr

    if kind in ("wood", "metal"):
        # body resonances: modal cluster + short noise, same in both channels but a touch of spread
        base = 180.0 if kind == "wood" else 420.0
        y = np.zeros((n, ch))
        if kind == "wood":
            # cypress/spruce box: Helmholtz air mode, top plate modes, broad formants
            modes = [(98, 0.08, 1.0), (185, 0.09, 0.9), (240, 0.06, 0.7), (310, 0.05, 0.6), (420, 0.045, 0.5),
                     (560, 0.04, 0.45), (720, 0.035, 0.35), (1010, 0.03, 0.3), (1400, 0.02, 0.22),
                     (2100, 0.015, 0.15), (3100, 0.01, 0.1)]
        else:
            modes = [(base * r, 0.6 / (1 + 0.2 * i), 1 / (1 + 0.3 * i)) for i, r in
                     enumerate([1, 1.59, 2.14, 2.65, 3.16, 3.5, 4.15, 5.2, 6.1, 7.3, 8.6])]
        for c in range(ch):
            for f, T, a in modes:
                f *= 2 ** (rng.standard_normal() * 0.03)
                if f < 0.45 * sr:
                    y[:, c] += a * np.exp(-6.9 * t / T) * np.sin(2 * math.pi * f * t + rng.uniform(0, 2 * math.pi))
            y[0, c] += 1.5  # direct sound
        nz = rng.standard_normal((n, ch)) * np.exp(-6.9 * t / (p["t60"] * 0.3))[:, None] * 0.3
        y += signal.sosfilt(signal.butter(2, 4000 * p["bright"] + 800, fs=sr, output="sos"), nz, axis=0)
    else:
        # late tail: octave bands, each with its own decay
        tail = np.zeros((n, ch))
        white = rng.standard_normal((n, ch))
        edges = [20, 125, 250, 500, 1000, 2000, 4000, 8000, min(20000, 0.49 * sr)]
        for i in range(len(edges) - 1):
            lo, hi = edges[i], edges[i + 1]
            fc = math.sqrt(lo * hi)
            # t60 interpolates (log-freq) from t60 at 125 Hz to t60_hi at 8 kHz
            u = np.clip(math.log2(fc / 125) / 6, 0, 1)
            T = p["t60"] * (p["t60_hi"] / p["t60"]) ** u
            sos = signal.butter(3, [lo, hi], "bandpass", fs=sr, output="sos")
            band = signal.sosfilt(sos, white, axis=0)
            gain = (0.35 + 0.65 * p["bright"]) ** (u * 3)
            tail += band * gain * np.exp(-6.9 * t / T)[:, None]
        # fade the tail in over the build-up (density grows)
        build = np.clip(t / max(0.005, p["spread"] * 0.5 + 0.01), 0, 1) ** 1.5
        tail *= build[:, None]
        pre = int(p["pre"] * sr)
        y = np.zeros((n, ch))
        y[pre:] = tail[: n - pre] * 0.6
        # early reflections
        for k in range(p["early"]):
            d = p["pre"] + rng.uniform(0.002, p["spread"] + 0.004)
            idx = int(d * sr)
            if idx < n:
                amp = 0.7 * math.exp(-d / (p["spread"] + 0.02)) * rng.uniform(0.4, 1.0)
                for c in range(ch):
                    j = min(n - 1, idx + int(rng.integers(0, int(0.0015 * sr) + 1)))
                    y[j, c] += amp * (1 if rng.random() > 0.3 else -1)
        if kind == "spring":
            # dispersive chirps: a cascade of allpasses on a repeating impulse train
            rt = 0.034
            pulses = np.zeros(n)
            for k in range(int(L / rt)):
                idx = int(k * rt * sr)
                if idx < n:
                    pulses[idx] = 0.8 * (0.82 ** k)
            ap = pulses
            for _ in range(80):
                ap = signal.lfilter([0.6, 1.0], [1.0, 0.6], ap)
            ap = signal.sosfilt(signal.butter(2, [300, 5000], "bandpass", fs=sr, output="sos"), ap)
            for c in range(ch):
                y[:, c] = 0.45 * y[:, c] + np.roll(ap, c * int(0.0007 * sr)) * 2.0
        if kind == "cave":
            for d, a in ((0.11, 0.35), (0.23, 0.22), (0.37, 0.14)):
                idx = int((p["pre"] + d) * sr)
                if idx < n:
                    y[idx:] += 0.6 * a * tail[: n - idx] * 0.5
                    y[idx, :] += a
        if kind == "plate":
            y = signal.sosfilt(signal.butter(1, 200, "highpass", fs=sr, output="sos"), y, axis=0)
    y = dsp.dc_block(y, sr, 20.0)
    y = y[:, 0] if ch == 1 else y
    pk = np.abs(y).max(initial=0)
    y = y / pk * dsp.undb(-1.0) if pk > 0 else y
    # tiny end fade so truncation never clicks
    return Audio(y, sr).fade_out(min(0.05, L * 0.1))
