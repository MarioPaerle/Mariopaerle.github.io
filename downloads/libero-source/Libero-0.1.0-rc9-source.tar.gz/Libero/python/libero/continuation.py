"""Level control for declared extensions of struck or plucked recordings."""
import numpy as np
from .audio import Audio


def restrain_continuation(audio, region, ctx):
    """Keep the recorded entry and prevent a louder synthetic sustain from returning.

    Only mapped source loops are eligible. A shared stereo gain falls after the
    first 220 ms and stays constant throughout the loop, preserving its seam.
    """
    loop = region.loop
    if not isinstance(loop, dict):
        return audio
    data = audio.data
    sr = audio.sr
    stop = min(int(loop['start']), int(1.8 * sr))
    preserve = int(.220 * sr)
    if stop <= preserve + int(.120 * sr):
        return audio
    power = data.astype(np.float64) ** 2
    if power.ndim > 1:
        power = power.mean(axis=1)
    summed = np.concatenate(([0.0], np.cumsum(power)))
    half = int(.060 * sr)
    centres = np.arange(preserve + half, stop + 1, max(1, int(.020 * sr)))
    centres = np.unique(np.append(centres, stop))
    lows, highs = np.maximum(0, centres - half), np.minimum(len(data), centres + half)
    rms = np.sqrt((summed[highs] - summed[lows]) / np.maximum(1, highs - lows))
    reference = np.minimum.accumulate(rms)
    gain = np.minimum.accumulate(np.minimum(1.0, reference * 10 ** (1.0 / 20) / np.maximum(rms, 1e-12)))
    if gain[-1] > 10 ** (-1.0 / 20):
        return audio
    knots = np.concatenate(([preserve], centres))
    gains = np.concatenate(([1.0], gain))
    envelope = np.interp(np.arange(len(data)), knots, gains)
    if data.ndim > 1:
        envelope = envelope[:, None]
    return Audio((data * envelope).astype(np.float32), sr)
