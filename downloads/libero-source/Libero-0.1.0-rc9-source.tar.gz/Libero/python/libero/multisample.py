"""Recorded multisamples: turn real files into bundle zones the way a sample editor would.

A recipe declares regions (`sound.multisample(...)`); the compiler then, per region:
resamples to the sound's rate, trims to the true onset with a fixed pre-roll, cuts the
tail where it has decayed (or at a length that follows the register), fades, finds a long
loop if asked, and measures level, brightness and pitch. Then, per key: aligns the starts
of all dynamics layers and takes to the loudest one (so crossfades do not comb), writes
`tune_cents`, and calibrates the level ladder with one fixed gain for the whole
instrument plus small corrections for uneven notes. Files are never normalised one by one.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, Callable

import numpy as np
import soundfile as sf

from . import dsp
from .audio import Audio

LAYERS = ("body", "attack", "tail")
ENCODINGS = {"flac24": ("FLAC", "PCM_24", ".flac"), "wav24": ("WAV", "PCM_24", ".wav"),
             "float": ("WAV", "FLOAT", ".wav")}


class MultisampleError(ValueError):
    pass


@dataclass
class Region:
    """One recorded sample and where it plays.

    file        path relative to the sound's samples/ folder (or absolute)
    root        MIDI note of the recording (int or name like 'C#4'); unpitched regions ignore it
    lo, hi      key range; omitted → filled by nearest root, gapless
    vel         (lo, hi) velocity range 1..127, or
    dyn         (lo, hi) position on the dynamics axis 0..1 (bundle/2); velocity ranges are
                converted to dyn when the layer has several dynamics layers
    take        round-robin index 0..31
    tune_cents  the source's own tuning correction (e.g. SFZ `tune`)
    gain_db     extra gain for this region (e.g. SFZ `volume`)
    loop        {"start": s, "end": e} in source samples, kept when process.loop == "source";
                add "mode": "source" to opt into these markers within an otherwise auto-looped layer
    offset, end sample range inside the source file (SFZ `offset` / `end`)
    rt_decay, rt_min_db   tail regions: release attenuation per second of held note, and its floor
    pitched     False for noises that play at original speed regardless of the key; unpitched
                regions keep their own lo/hi (a drum kit: one articulation per key)
    one_shot    note-off is ignored: the sample plays to its end (drums, cymbals, gongs)
    choke_group int >= 1: starting a note of this group fades out the sounding voices of the group
    chokes      [groups]: further groups this region chokes without belonging to them
    articulation  id of the sound's articulation this region belongs to (none: every articulation)
    """

    file: str
    root: int = 60
    lo: int | None = None
    hi: int | None = None
    vel: tuple[int, int] | None = None
    dyn: tuple[float, float] | None = None
    take: int = 0
    tune_cents: float = 0.0
    gain_db: float = 0.0
    loop: dict | str | None = None   # {start,end} | "none" (never loop this region) | None
    offset: int = 0
    end: int | None = None
    rt_decay: float | None = None
    rt_min_db: float | None = None
    pitched: bool = True
    one_shot: bool | None = None
    choke_group: int | None = None
    chokes: list | None = None
    articulation: str | None = None

    @classmethod
    def from_any(cls, r: "Region | dict", layer: str) -> "Region":
        if isinstance(r, Region):
            return r
        if not isinstance(r, dict) or "file" not in r:
            raise MultisampleError(f"region must be a dict with a 'file', got {r!r}")
        known = {f.name for f in fields(cls)}
        extra = set(r) - known
        if extra:
            raise MultisampleError(f"region {r.get('file')}: unknown keys {sorted(extra)}; known: {sorted(known)}")
        d = dict(r)
        d.setdefault("pitched", layer != "attack")
        if "root" in d:
            d["root"] = dsp.parse_note(d["root"])
        for k in ("vel", "dyn"):
            if d.get(k) is not None:
                d[k] = tuple(d[k])
        reg = cls(**d)
        if reg.vel is not None and not (1 <= reg.vel[0] <= reg.vel[1] <= 127):
            raise MultisampleError(f"region {reg.file}: vel {reg.vel} must be within 1..127")
        if reg.dyn is not None and not (0 <= reg.dyn[0] < reg.dyn[1] <= 1):
            raise MultisampleError(f"region {reg.file}: dyn {reg.dyn} must be 0 <= lo < hi <= 1")
        if reg.articulation is not None and (not isinstance(reg.articulation, str) or not reg.articulation):
            raise MultisampleError(f"region {reg.file}: articulation must be an id string")
        if reg.one_shot is not None and not isinstance(reg.one_shot, bool):
            raise MultisampleError(f"region {reg.file}: one_shot must be true or false")
        if reg.choke_group is not None and (isinstance(reg.choke_group, bool) or not isinstance(reg.choke_group, int)
                                            or reg.choke_group < 1):
            raise MultisampleError(f"region {reg.file}: choke_group must be an integer >= 1")
        if reg.chokes is not None:
            if not isinstance(reg.chokes, (list, tuple)) or not all(
                    isinstance(g, int) and not isinstance(g, bool) and g >= 1 for g in reg.chokes):
                raise MultisampleError(f"region {reg.file}: chokes must be a list of integers >= 1")
            reg.chokes = sorted(set(reg.chokes))
        from .library import MAX_TAKES
        if not 0 <= reg.take < MAX_TAKES:
            raise MultisampleError(f"region {reg.file}: take must be 0..{MAX_TAKES - 1}")
        if (reg.rt_decay is not None or reg.rt_min_db is not None) and layer != "tail":
            raise MultisampleError(f"region {reg.file}: rt_decay/rt_min_db only make sense on tail regions")
        return reg


@dataclass
class Process:
    """How recorded regions are edited at compile time (all optional).

    pre_ms        pre-roll kept before the true onset (all zones start the same way)
    onset_db      onset = first point the 1 ms envelope rises above peak + onset_db
    align_ms      max shift when aligning layers/takes of a key to the loudest one (0 = off)
    tune          'source' (keep the region's tune_cents), 'smooth' (keep the instrument's own
                  stretch tuning but correct layers that disagree with their key and keys that jump
                  off the curve of their neighbours), 'detect' (measure f0 and tune every zone to
                  equal temperament), 'none'
    ladder        'smooth' (one gain for the instrument + corrections for notes that stand
                  out from their neighbours by more than 1.5 dB, at most ladder_max_db),
                  'keep' (one gain only), 'none' (leave levels untouched)
    max_step_db   with 'smooth', a key's step between adjacent dynamics layers is kept below this
    peak_db       the loudest zone's peak after the instrument gain
    max_seconds   cap on length: a number, or [[note, seconds], ...] interpolated by root
    end_db        cut the tail where it stays below peak + end_db
    fade_ms       fade at the end (longer, 150 ms, when a note is cut early)
    loop          'none', 'auto' (find a long loop, >= loop_min_s), 'source' (keep region loops)
    encoding      'flac24' (default), 'wav24', 'float'
    mono          fold to mono
    edge_fill     (default True) stretch the outermost roots to keys 0 and 127; False keeps their stated lo/hi
    preserve_key_ranges  (default False) keep every explicit region lo/hi; physical sample
                         roots may differ between takes of the same played key
    link_gain     attack/tail layers use the body's instrument gain, so recorded releases and
                  noises keep their natural level relative to the notes (default True)
    """

    pre_ms: float = 2.0
    onset_db: float = -20.0
    align_ms: float = 3.0
    tune: str = "source"
    ladder: str = "smooth"
    ladder_max_db: float = 3.0
    max_step_db: float = 9.5
    peak_db: float = -6.0
    max_seconds: Any = None
    end_db: float = -65.0
    fade_ms: float = 30.0
    loop: str = "none"
    loop_min_s: float = 2.0
    encoding: str = "flac24"
    mono: bool = False
    link_gain: bool = True
    edge_fill: bool = True  # False: the lowest/highest pitched roots keep their stated key range (keys beyond stay free, e.g. for noise keys)
    preserve_key_ranges: bool = False

    @classmethod
    def from_any(cls, p) -> "Process":
        if p is None:
            return cls()
        if isinstance(p, Process):
            return p
        if not isinstance(p, dict):
            raise MultisampleError("process must be a dict of options (see Process)")
        known = {f.name for f in fields(cls)}
        extra = set(p) - known
        if extra:
            raise MultisampleError(f"process: unknown options {sorted(extra)}; known: {sorted(known)}")
        out = cls(**p)
        if out.tune not in ("source", "smooth", "detect", "none"):
            raise MultisampleError("process.tune must be 'source', 'smooth', 'detect' or 'none'")
        if out.ladder not in ("smooth", "keep", "none"):
            raise MultisampleError("process.ladder must be 'smooth', 'keep' or 'none'")
        if out.loop not in ("none", "auto", "source"):
            raise MultisampleError("process.loop must be 'none', 'auto' or 'source'")
        if out.encoding not in ENCODINGS:
            raise MultisampleError(f"process.encoding must be one of {list(ENCODINGS)}")
        return out

    def seconds_for(self, note: int) -> float | None:
        m = self.max_seconds
        if m is None:
            return None
        if isinstance(m, (int, float)):
            return float(m)
        pts = sorted((dsp.parse_note(a), float(b)) for a, b in m)
        return float(np.interp(note, [p[0] for p in pts], [p[1] for p in pts]))


@dataclass
class MultiSpec:
    layer: str
    regions: list[Region]
    process: Process = field(default_factory=Process)
    custom: Callable | None = None  # fn(audio, region, ctx) -> Audio, applied after trimming
    as_dyn: bool | None = None       # None: dyn when the layer has more than one velocity layer
    fill_gaps: bool = False          # unpitched regions with their own key ranges: close the gaps between them


# ---------------------------------------------------------------- coverage

def _tile_ranges(ranges: list[tuple[float, float]], lo: float, hi: float, integer: bool):
    """Map each distinct range to a tile of [lo, hi]: sorted by centre, boundaries at the
    sources' own edges where they meet, at midpoints of centres where they overlap or gap."""
    uniq = sorted(set(ranges), key=lambda r: (r[0] + r[1]) / 2)
    out = {}
    for i, r in enumerate(uniq):
        if i == 0:
            a = lo
        else:
            p = uniq[i - 1]
            if integer and p[1] + 1 == r[0] or (not integer and abs(p[1] - r[0]) < 1e-9):
                a = r[0]
            else:
                c = ((p[0] + p[1]) / 2 + (r[0] + r[1]) / 2) / 2
                a = math.floor(c) + 1 if integer else c
        if i == len(uniq) - 1:
            b = hi
        else:
            nx = uniq[i + 1]
            if integer and r[1] + 1 == nx[0] or (not integer and abs(r[1] - nx[0]) < 1e-9):
                b = r[1]
            else:
                c = ((r[0] + r[1]) / 2 + (nx[0] + nx[1]) / 2) / 2
                b = math.floor(c) if integer else c
        out[r] = (a, b)
    return out


def _unpitched_keys(regs: list, fill_gaps: bool) -> dict:
    """Key range of each unpitched region: its own lo/hi (whole keyboard when omitted); overlaps of
    different ranges are an error, gaps stay open unless fill_gaps tiles them by nearest centre."""
    raw = {i: (0 if r.lo is None else int(r.lo), 127 if r.hi is None else int(r.hi))
           for i, r in enumerate(regs) if not r.pitched}
    for i, (lo, hi) in raw.items():
        if lo > hi:
            raise MultisampleError(f"region {regs[i].file}: lo {lo} > hi {hi}")
    uniq = sorted(set(raw.values()))
    for a, b in zip(uniq, uniq[1:]):
        if b[0] <= a[1]:
            raise MultisampleError(f"unpitched key ranges {a} and {b} overlap")
    if fill_gaps and len(uniq) > 1:
        tiles = _tile_ranges(uniq, 0, 127, True)
        raw = {i: tiles[v] for i, v in raw.items()}
    return raw


def plan_regions(spec: MultiSpec, reserved_keys=()) -> list[dict]:
    """Resolve key ranges, velocity/dyn ranges and takes into gapless zones (one dict per region).

    Keys first: every root gets one key range (the union of what its regions state, gaps closed
    at midpoints between roots, the ends stretched to 0 and 127); all regions of a root share it.
    Then, per root, its velocity (or dyn) ranges are tiled over 1..127 (0..1), so keys may have
    different numbers of dynamics layers. Takes share their layer's ranges."""
    regs = spec.regions
    if not regs:
        raise MultisampleError(f"multisample '{spec.layer}' has no regions")
    if any(r.articulation for r in regs):
        # Articulations are independent keyboards: plan each one on its own (regions without an
        # articulation form their own group and play in all of them).
        from dataclasses import replace
        out: list[dict] = []
        for art in dict.fromkeys(r.articulation for r in regs):
            idx = [i for i, r in enumerate(regs) if r.articulation == art]
            sub = plan_regions(replace(spec, regions=[replace(regs[i], articulation=None) for i in idx]), reserved_keys)
            for z, i in zip(sub, idx):
                z["index"] = i
                if art:
                    z["articulation"] = art
                out.append(z)
        return sorted(out, key=lambda z: z["index"])
    use_dyn = any(r.dyn for r in regs)
    if use_dyn and not all(r.dyn for r in regs):
        raise MultisampleError(f"multisample '{spec.layer}': give dyn on every region or on none")
    pitched_roots = sorted({r.root for r in regs if r.pitched})
    # Explicit SFZ key ranges belong to each region, not to its sample root.
    # Real round robins can use adjacent source pitches for one played key
    # (e.g. key 56 has takes rooted at 56, 57 and 58). Merging those ranges by
    # root collapses or steals keys from a valid recorded RR group.
    explicit_region_ranges = spec.process.preserve_key_ranges and bool(pitched_roots) and all(
        (not r.pitched) or (r.lo is not None and r.hi is not None) for r in regs
    )
    if spec.process.preserve_key_ranges and pitched_roots and not explicit_region_ranges:
        raise MultisampleError("preserve_key_ranges requires explicit lo/hi on every pitched region")
    region_ranges: dict[int, tuple[int, int]] = {}
    given: dict[int, list[int]] = {}
    for r in regs:
        if not r.pitched:
            continue
        lo = r.lo if r.lo is not None else r.root
        hi = r.hi if r.hi is not None else r.root
        g = given.setdefault(r.root, [lo, hi])
        g[0], g[1] = min(g[0], lo), max(g[1], hi)
    if explicit_region_ranges:
        region_ranges = {i: (int(r.lo), int(r.hi)) for i, r in enumerate(regs) if r.pitched}
        keyrange = {}
    else:
        cur = [given[r][:] for r in pitched_roots]
        for j in range(len(cur) - 1):
            a_, b_ = cur[j], cur[j + 1]
            if b_[0] <= a_[1]:
                a_[1] = b_[0] - 1
            elif b_[0] > a_[1] + 1:
                mid = (pitched_roots[j] + pitched_roots[j + 1]) // 2
                mid = min(max(mid, a_[1]), b_[0] - 1)
                a_[1], b_[0] = mid, mid + 1
        if cur and spec.process.edge_fill:
            cur[0][0] = 0
            cur[-1][1] = 127
        keyrange = {r: (int(lo), int(hi)) for r, (lo, hi) in zip(pitched_roots, cur)}
    if reserved_keys:
        # keyswitch keys play no zone: a range stops short of the ones between its edge and its root
        for r, (lo, hi) in list(keyrange.items()):
            below = [k for k in reserved_keys if lo <= k < r]
            above = [k for k in reserved_keys if r < k <= hi]
            lo = max(below) + 1 if below else lo
            hi = min(above) - 1 if above else hi
            keyrange[r] = (lo, hi)
            if r in reserved_keys:
                raise MultisampleError(f"root {r} is also an articulation's keyswitch key")
    ukey = _unpitched_keys(regs, spec.fill_gaps)
    for r, (lo, hi) in keyrange.items():
        if lo > hi:
            raise MultisampleError(f"root {r}: key range collapsed (overlapping regions?)")
    for i, (lo, hi) in region_ranges.items():
        if lo > hi:
            raise MultisampleError(f"region {regs[i].file}: key range collapsed (lo > hi)")
        if any(lo <= k <= hi for k in reserved_keys):
            raise MultisampleError(f"region {regs[i].file}: explicit range includes a keyswitch key")
    # dynamics / velocity per root (unpitched regions form one group)
    groups: dict = {}
    for i, r in enumerate(regs):
        group = region_ranges[i] if r.pitched and explicit_region_ranges else (r.root if r.pitched else ("u",) + ukey[i])
        groups.setdefault(group, []).append(i)
    n_layers = {k: len({(regs[i].dyn or regs[i].vel or (1, 127)) for i in idx}) for k, idx in groups.items()}
    as_dyn = use_dyn or (spec.as_dyn if spec.as_dyn is not None else max(n_layers.values()) > 1)
    axis: dict[int, tuple] = {}
    for k, idx in groups.items():
        if use_dyn:
            tiles = _tile_ranges([regs[i].dyn for i in idx], 0.0, 1.0, False)
            for i in idx:
                axis[i] = tiles[regs[i].dyn]
        else:
            vr = [regs[i].vel or (1, 127) for i in idx]
            tiles = _tile_ranges(vr, 1, 127, True)
            for i, v in zip(idx, vr):
                lo, hi = tiles[v]
                if as_dyn:
                    d0 = 0.0 if lo <= 1 else round((lo - 1) / 127.0, 6)
                    d1 = 1.0 if hi >= 127 else round(hi / 127.0, 6)
                    axis[i] = (d0, d1)
                else:
                    axis[i] = (lo, hi)
    out = []
    for i, r in enumerate(regs):
        lo, hi = (region_ranges[i] if explicit_region_ranges else keyrange[r.root]) if r.pitched else ukey[i]
        z = {"index": i, "root": int(r.root), "lo": lo, "hi": hi, "take": int(r.take), "pitched": r.pitched}
        if as_dyn:
            z["dyn"] = [float(axis[i][0]), float(axis[i][1])]
            z["vel_lo"], z["vel_hi"] = 1, 127
        else:
            z["vel_lo"], z["vel_hi"] = int(axis[i][0]), int(axis[i][1])
        out.append(z)
    return out


def zone_file(layer: str, z: dict, ext: str, taken: set) -> str:
    axis = f"d{int(round(z['dyn'][1] * 100)):03d}" if "dyn" in z else f"v{z['vel_hi']:03d}"
    layer = f"{layer}_{z['articulation']}" if z.get("articulation") else layer
    if z["pitched"]:
        base = f"{layer}_n{z['root']:03d}_{axis}"
    elif (z["lo"], z["hi"]) != (0, 127):
        span = f"{z['lo']:03d}" + (f"-{z['hi']:03d}" if z["hi"] != z["lo"] else "")
        base = f"{layer}_k{span}_{axis}"
    else:
        base = f"{layer}_{axis}"
    if z["take"]:
        base += f"_t{z['take']}"
    name, k = base, 1
    while name + ext in taken:
        k += 1
        name = f"{base}_{k}"
    taken.add(name + ext)
    return name + ext


# ---------------------------------------------------------------- per-region editing (stage A)

def source_signature(path: Path) -> str:
    st = path.stat()
    return f"{path.resolve()}|{st.st_size}|{int(st.st_mtime)}"


def true_onset(x: np.ndarray, sr: int, rel_db: float = -20.0) -> int:
    """First sample of the note. The 1 ms envelope's first rise to peak + rel_db is found well
    above any noise; from there we walk back down the rising edge while it keeps falling, until
    it reaches 6 dB over the noise floor that precedes it (at most 10 ms). Soft notes with slow,
    noisy attacks and loud ones with sharp attacks are then cut at the same physical moment."""
    m = dsp.mono(np.asarray(x, dtype=np.float64))
    if len(m) < 64:
        return 0
    win = max(8, int(0.001 * sr))
    c = np.concatenate([[0.0], np.cumsum(m ** 2)])
    e = np.sqrt(np.maximum((c[win:] - c[:-win]) / win, 0.0))
    if e.max() <= 0:
        return 0
    i = int(np.argmax(e >= e.max() * 10 ** (rel_db / 20)))
    pre = e[:i]
    floor = float(np.percentile(pre, 10)) if len(pre) > 16 else 0.0
    thr = floor * 2.0
    lim = max(0, i - int(0.010 * sr))
    j = i
    while j > lim and e[j - 1] > thr and e[j - 1] <= e[j] * 1.02:
        j -= 1
    return int(j)


def edit_region(audio: Audio, region: Region, proc: Process, sr: int) -> tuple[Audio, dict]:
    """Stage A: everything that depends on one file only. Returns the edited audio and its facts."""
    if audio.sr != sr:
        audio = audio.resample(sr)
    if proc.mono:
        audio = audio.to_mono()
    x = audio.data
    src_offset = int(round(region.offset * sr / max(1, audio.sr)))
    end = region.end
    if end is not None:
        x = x[: int(end)]
    x = x[src_offset:]
    audio = Audio(x, sr)
    if audio.n < 64 or not np.all(np.isfinite(audio.data)):
        raise MultisampleError(f"{region.file}: empty or non-finite audio")
    audio = audio.remove_dc(5.0)
    onset = true_onset(audio.data, sr, proc.onset_db)
    pre = int(round(proc.pre_ms * 1e-3 * sr))
    start = max(0, onset - pre)
    audio = Audio(audio.data[start:], sr)
    # the pre-roll is faded in so the zone never starts with a step
    audio = audio.fade_in(max(1, onset - start) / sr, "sine") if onset > start else audio.fade_in(8 / sr, "linear")
    facts: dict = {"trim_start": int(start + src_offset), "onset": int(onset - start)}

    # length: decay cut, then register cap
    m = dsp.mono(audio.data.astype(np.float64))
    t, e = dsp.rms_envelope(m, sr, 0.02)
    cut = audio.n
    truncated = False
    if len(e) and e.max() > 0:
        thr = e.max() * 10 ** (proc.end_db / 20)
        above = np.nonzero(e > thr)[0]
        if len(above):
            cut = min(cut, int((t[above[-1]] + 0.05) * sr))
    cap = proc.seconds_for(region.root)
    if cap and cut > int(cap * sr):
        cut = int(cap * sr)
        truncated = True
    loop = None
    source_loop = isinstance(region.loop, dict) and (
        proc.loop == "source" or (proc.loop == "auto" and region.loop.get("mode") == "source"))
    if source_loop:
        ls = int(region.loop["start"]) - facts["trim_start"]
        le = int(region.loop["end"]) - facts["trim_start"]
        if 0 < ls < le <= audio.n:
            loop = {"start": ls, "end": le, "crossfade": min(256, ls, (le - ls) // 4)}
            cut = max(cut, le)
            truncated = False
    audio = Audio(audio.data[:cut], sr)
    if proc.loop == "auto" and loop is None and region.loop != "none" and audio.duration > proc.loop_min_s + 0.5:
        lp = audio.loop_points(min_seconds=proc.loop_min_s)
        if lp is not None:
            audio = audio.bake_loop(lp)
            loop = {**lp.as_manifest(), "error_db": lp.error_db}
    if loop is None:
        fade = 0.15 if truncated else proc.fade_ms * 1e-3
        audio = audio.fade_out(min(fade, audio.duration / 3), "sine")
    facts["loop"] = loop
    facts["truncated"] = truncated

    # measurements used by alignment, the ladder, tuning and lint
    facts["seconds"] = round(audio.duration, 3)
    facts["peak_db"] = round(audio.peak_db, 2)
    facts["lufs_max"] = round(dsp.momentary_max(audio.data, sr), 2)
    head = dsp.mono(audio.data[: int(0.3 * sr)].astype(np.float64))
    facts["hf_ratio_db"] = round(_hf_ratio(head, sr), 2)
    facts["centroid_hz"] = round(_centroid(head, sr), 1)
    facts["noise_floor_db"] = round(_noise_floor(m, sr), 1)
    if region.pitched:
        body = audio.trim(min(0.15, audio.duration * 0.2), min(audio.duration, 2.5))
        f0, voiced = dsp.estimate_f0(body.data, sr, 25.0, 5000.0)
        if np.isfinite(f0) and voiced > 0.3:
            f0 = dsp.refine_f0(body.data, sr, f0)
            cents = 1200 * math.log2(f0 / dsp.midi_to_freq(region.root))
            if abs(cents) <= 60:
                facts["cents"] = round(cents, 2)
            facts["f0"] = round(f0, 3)
            facts["voiced"] = round(voiced, 2)
    return audio, facts


def _hf_ratio(x: np.ndarray, sr: int) -> float:
    if len(x) < 256:
        return -120.0
    S = np.abs(np.fft.rfft(x * np.hanning(len(x)))) ** 2
    f = np.fft.rfftfreq(len(x), 1 / sr)
    return 10 * math.log10((S[f > 4000].sum() + 1e-20) / (S.sum() + 1e-20))


def _centroid(x: np.ndarray, sr: int) -> float:
    if len(x) < 256:
        return 0.0
    S = np.abs(np.fft.rfft(x * np.hanning(len(x))))
    f = np.fft.rfftfreq(len(x), 1 / sr)
    return float((S * f).sum() / (S.sum() + 1e-20))


def _noise_floor(m: np.ndarray, sr: int) -> float:
    t, e = dsp.rms_envelope(m, sr, 0.05)
    if len(e) < 4:
        return -120.0
    return dsp.db(float(np.percentile(e, 5)))


# ---------------------------------------------------------------- per-key decisions (stage B)

def align_shift(ref: np.ndarray, x: np.ndarray, sr: int, max_ms: float, onset: int, window_ms: float = 40.0,
                min_gain: float = 0.1) -> tuple[int, float]:
    """Samples to drop from the start of `x` (negative: to pad) so its first `window_ms` after the
    onset best matches `ref` (both low-passed at 2 kHz: the attack's body, not its noise).
    Returns (shift, correlation). The shift is 0 when the match is poor (< 0.5) or when moving
    gains less than `min_gain` of correlation over leaving it where it is (a flat ridge of a low,
    periodic note is not evidence of misalignment)."""
    from scipy import signal as sps

    L = int(max_ms * 1e-3 * sr)
    W = int(window_ms * 1e-3 * sr)
    a = dsp.mono(np.asarray(ref, dtype=np.float64))[: onset + W + L + 64]
    b = dsp.mono(np.asarray(x, dtype=np.float64))[: onset + W + 2 * L + 64]
    if L < 1 or len(a) < onset + W or len(b) < onset + W + L:
        return 0, 0.0
    sos = sps.butter(2, 2000, fs=sr, output="sos")
    a = sps.sosfilt(sos, a)
    b = sps.sosfilt(sos, b)
    seg = a[onset: onset + W]
    seg = seg - seg.mean()
    na = math.sqrt(float(np.dot(seg, seg))) + 1e-20
    best, best_c, c0 = 0, -1.0, -1.0
    for lag in range(-L, L + 1):
        s0 = onset + lag
        if s0 < 0 or s0 + W > len(b):
            continue
        cand = b[s0: s0 + W]
        cand = cand - cand.mean()
        c = float(np.dot(seg, cand)) / (na * (math.sqrt(float(np.dot(cand, cand))) + 1e-20))
        if lag == 0:
            c0 = c
        if c > best_c:
            best, best_c = lag, c
    if best_c < 0.5 or best_c - c0 < min_gain or abs(best) > 0.8 * L:
        # poor match, flat ridge, or an optimum at the edge of the search (the real one may lie
        # beyond it): leave the zone where the onset detector put it
        return 0, max(best_c, c0)
    return best, best_c


def ladder_gains(items: list[dict], proc: Process, fixed_gain: float | None = None) -> tuple[dict, dict]:
    """items: [{id, root, axis, take, lufs_max, peak_db}]. Returns ({id: gain_db}, report).
    `fixed_gain` imposes the instrument gain (so releases keep their recorded level under the body)."""
    if proc.ladder == "none" or not items:
        return {it["id"]: 0.0 for it in items}, {"instrument_gain_db": 0.0, "corrections": {}}
    corr = {it["id"]: 0.0 for it in items}
    if proc.ladder == "smooth":
        # per dynamics layer (and take): smooth the loudness curve across roots, correct outliers
        by: dict[tuple, list[dict]] = {}
        for it in items:
            by.setdefault((it.get("art"), it["axis"], it["take"]), []).append(it)
        for grp in by.values():
            grp.sort(key=lambda it: it["root"])
            vals = np.array([it["lufs_max"] for it in grp])
            if len(vals) < 3:
                continue
            smooth = np.array([np.median(vals[max(0, i - 2): i + 3]) for i in range(len(vals))])
            for it, v, s in zip(grp, vals, smooth):
                d = float(s - v)
                if abs(d) > 1.5:
                    corr[it["id"]] = float(np.clip(d, -proc.ladder_max_db, proc.ladder_max_db))
        # per key: no dynamics step larger than max_step_db (lift the softer layer, within limits)
        keys: dict[tuple, list[dict]] = {}
        for it in items:
            if it["take"] == 0:
                keys.setdefault((it.get("art"), it["root"]), []).append(it)
        for grp in keys.values():
            grp.sort(key=lambda it: it["axis"])
            for lo_it, hi_it in zip(grp[::-1][1:], grp[::-1][:-1]):
                step = (hi_it["lufs_max"] + corr[hi_it["id"]]) - (lo_it["lufs_max"] + corr[lo_it["id"]])
                if step > proc.max_step_db:
                    lift = min(step - proc.max_step_db + 0.5, proc.ladder_max_db)
                    corr[lo_it["id"]] += lift
        # takes of the same key and layer: pull toward their mean (RR should differ in timbre, not level)
        tk: dict[tuple, list[dict]] = {}
        for it in items:
            tk.setdefault((it.get("art"), it["root"], it["axis"]), []).append(it)
        for grp in tk.values():
            if len(grp) > 1:
                mean = float(np.mean([it["lufs_max"] + corr[it["id"]] for it in grp]))
                for it in grp:
                    corr[it["id"]] += float(np.clip(mean - (it["lufs_max"] + corr[it["id"]]), -2, 2))
    peak = max(it["peak_db"] + corr[it["id"]] for it in items)
    g = proc.peak_db - peak if fixed_gain is None else fixed_gain
    gains = {it["id"]: round(g + corr[it["id"]], 3) for it in items}
    report = {"instrument_gain_db": round(g, 2),
              "corrections": {k: round(v, 2) for k, v in corr.items() if abs(v) > 1e-6}}
    return gains, report


# ---------------------------------------------------------------- final write (stage C)

def write_final(src: Path, dst: Path, shift: int, gain_db: float, encoding: str) -> dict:
    x, sr = sf.read(str(src), dtype="float32", always_2d=False)
    if shift > 0:
        x = x[shift:]
    elif shift < 0:
        pad = np.zeros((-shift,) + x.shape[1:], dtype=x.dtype)
        x = np.concatenate([pad, x])
    y = x.astype(np.float64) * dsp.undb(gain_db)
    # a shift may have cut into the faded pre-roll: fade the first 1.5 ms again
    k = min(len(y), int(0.0015 * sr))
    if k > 1:
        ramp = np.sin(0.5 * np.pi * (np.arange(k) + 0.5) / k)
        y[:k] *= ramp if y.ndim == 1 else ramp[:, None]
    pk = float(np.abs(y).max(initial=0.0))
    if pk > dsp.undb(-0.3):
        y, _ = dsp.limit(y, sr, -0.3)
    fmt, sub, _ = ENCODINGS[encoding]
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".part")
    sf.write(str(tmp), y.astype(np.float32), sr, format=fmt, subtype=sub)
    os.replace(tmp, dst)
    return {"frames": len(y), "peak_db": round(dsp.db(float(np.abs(y).max(initial=0.0))), 2)}


def cache_key(*parts) -> str:
    return hashlib.sha256("|".join(str(p) for p in parts).encode()).hexdigest()


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    try:
        os.link(src, dst)
    except OSError:
        import shutil

        shutil.copyfile(src, dst)


def spec_fingerprint(spec: MultiSpec) -> str:
    d = {"layer": spec.layer, "process": asdict(spec.process), "as_dyn": spec.as_dyn}
    if spec.fill_gaps:
        d["fill_gaps"] = True
    return json.dumps(d, sort_keys=True, default=str)
