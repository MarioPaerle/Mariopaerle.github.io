"""`libero` command line: the same library operations for humans."""

from __future__ import annotations

import argparse
import json
import sys

from . import library


def _cmd_new(a):
    folder = library.new_sound(a.slug, a.template, a.title, a.subtitle or "")
    print(f"created {folder}")


def _cmd_list(a):
    items = library.list_sounds()
    if a.json:
        print(json.dumps(items, indent=2, ensure_ascii=False))
        return
    if not items:
        print(f"(empty library at {library.home()})")
    for s in items:
        state = "saved " if s["saved"] else "sketch"
        comp = "compiled" if s["compiled"] else "        "
        print(f"{state}  {comp}  {s['slug']:<28} {s['title']} — {s['subtitle']}" + (f"  [{s['bank']}]" if s["bank"] not in ("mie", "prove") else ""))


def _cmd_bank(a):
    act = a.action
    if act == "new":
        if not a.args:
            raise library.LibraryError("usage: libero bank new <slug> [--title T --subtitle S ...]")
        print(f"created {library.bank_create(a.args[0], a.title or '', a.subtitle or '', a.description or '', a.author or '', a.license)}")
    elif act == "list":
        for b in library.bank_list():
            print(f"{b['slug']:<24} {b['count']:>4}  {b['title']}" + (f" — {b['subtitle']}" if b["subtitle"] else ""))
    elif act == "add":
        if len(a.args) != 2:
            raise library.LibraryError("usage: libero bank add <sound-slug> <bank>")
        print(f"moved → {library.bank_add(*a.args)}")
    elif act == "pack":
        if not a.args:
            raise library.LibraryError("usage: libero bank pack <bank> [-o out.liberobank]")
        print(f"packed → {library.bank_pack(a.args[0], a.out)}")
    elif act == "install":
        if not a.args:
            raise library.LibraryError("usage: libero bank install <file.liberobank>")
        print(f"installed → {library.bank_install(a.args[0])}")
    elif act == "edit":
        if not a.args:
            raise library.LibraryError("usage: libero bank edit <bank> [--title T --subtitle S --description D --author A]")
        m = library.bank_edit(a.args[0], a.title, a.subtitle, a.description, a.author)
        print(f"edited {m['slug']}: {m['title']} v{m['version']}")
    elif act == "migrate":
        done = library.bank_migrate()
        print("migrated: " + (", ".join(done) if done else "nothing to do"))
    elif act == "tag":
        if len(a.args) != 2:
            raise library.LibraryError("usage: libero bank tag <sound-slug> <0-4>")
        print(f"tag {library.set_color_tag(a.args[0], int(a.args[1]))}")


def _cmd_compile(a):
    from .compiler import compile_sound

    rc = 0
    for slug in a.slugs:
        res = compile_sound(library.find_sound(slug), timeout=a.timeout, use_cache=not a.force)
        print(res.text())
        rc |= 0 if res.ok else 1
    return rc


def _cmd_preview(a):
    from . import analysis, render

    try:
        pv = render.preview(a.slug, a.notes, json.loads(a.params) if a.params else None, a.tail)
    except render.RenderError as e:
        print(e, file=sys.stderr)
        return 2
    print(pv.wav)
    print(analysis.format_features(analysis.features(pv.audio), "preview"))
    if a.png:
        with open(a.png, "wb") as f:
            f.write(analysis.spectrogram(pv.audio, title=f"{a.slug} · preview"))
        print(f"spectrogram → {a.png}")


def _cmd_save(a):
    print(f"saved → {library.save_sound(a.slug)}")


def _cmd_discard(a):
    print(f"moved to {library.discard_sound(a.slug)}")


def _cmd_validate(a):
    probs = library.validate_bundle(library.find_sound(a.slug) / "build")
    print("valid" if not probs else "\n".join(probs))
    return 1 if probs else 0


def _cmd_lint(a):
    from .lint import lint_bundle, lint_text

    build = library.find_sound(a.slug) / "build"
    if not (build / "manifest.json").exists():
        print(f"libero: '{a.slug}' is not compiled", file=sys.stderr)
        return 1
    print(lint_text(build, a.slug))
    return 1 if any(f.level == "FAIL" for f in lint_bundle(build)) else 0


def _cmd_lib(a):
    from . import ingest

    if a.action == "search":
        for s in ingest.search(a.arg or "", license="any" if a.any else "shippable"):
            print(f"{s.id:<28} ★{s.quality} {s.license:<18} {s.size_mb:>6.0f} MB  {s.name}")
    elif a.action == "fetch":
        print(json.dumps(ingest.fetch(a.arg, a.subset, a.max_mb, a.yes), indent=1, ensure_ascii=False))
    elif a.action == "usage":
        print(json.dumps(ingest.usage_mb(), indent=1))
    elif a.action == "prune":
        from .compiler import prune_multisample_cache

        print(json.dumps(prune_multisample_cache(), indent=1))
    return 0


def _cmd_import(a):
    from . import ingest

    src = a.source
    if ":" in src and not src.startswith("/") and src.split(":", 1)[0] in ingest.BY_ID:
        sid, rel = src.split(":", 1)
        src = str(ingest.library_dir(sid) / rel)
    if src.lower().endswith(".sfz"):
        r = ingest.import_sfz(a.slug, src, a.family, a.title or "", layers=a.layers, budget_mb=a.budget,
                              replace=a.replace)
    else:
        r = ingest.import_wav_set(a.slug, src, a.family, include=a.include or "", title=a.title or "",
                                  layers=a.layers, budget_mb=a.budget, replace=a.replace)
    print(json.dumps(r, indent=1, ensure_ascii=False))
    return 0


def _cmd_preview_all(a):
    from . import preview

    res = preview.preview_all(skip=tuple(a.skip or ()), force=a.force, jobs=a.jobs)
    print(f"previews: {res['done']} written, {res['skipped']} skipped, {len(res['failed'])} failed")
    for f, e in res["failed"]:
        print(f"  FAILED {f}: {e}", file=sys.stderr)
    return 1 if res["failed"] else 0


def _cmd_mcp(a):
    from .mcp_server import main

    main()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="libero", description="Design, compile and preview Libero sounds.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("new", help="create a sketch from a template")
    p.add_argument("slug")
    p.add_argument("-t", "--template", default="plucked", choices=library.templates())
    p.add_argument("--title")
    p.add_argument("--subtitle")
    p.set_defaults(fn=_cmd_new)

    p = sub.add_parser("list", help="list sketches and saved sounds")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=_cmd_list)

    p = sub.add_parser("compile", help="compile sound(s) into build/")
    p.add_argument("slugs", nargs="+")
    p.add_argument("--force", action="store_true", help="ignore the zone cache")
    p.add_argument("--timeout", type=float, default=900)
    p.set_defaults(fn=_cmd_compile)

    p = sub.add_parser("preview", help="render notes through libero-render")
    p.add_argument("slug")
    p.add_argument("notes", nargs="?", default="48 60 72")
    p.add_argument("--params", help='JSON, e.g. \'{"rev_mix": 0.4}\'')
    p.add_argument("--tail", type=float, default=3.0)
    p.add_argument("--png", help="also write the spectrogram here")
    p.set_defaults(fn=_cmd_preview)

    p = sub.add_parser("save", help="move a sketch into the library")
    p.add_argument("slug")
    p.set_defaults(fn=_cmd_save)

    p = sub.add_parser("discard", help="move a sketch to the Trash")
    p.add_argument("slug")
    p.set_defaults(fn=_cmd_discard)

    p = sub.add_parser("validate", help="check a compiled bundle against the spec")
    p.add_argument("slug")
    p.set_defaults(fn=_cmd_validate)

    p = sub.add_parser("lint", help="objective checks of a compiled sound (exit 1 on FAIL)")
    p.add_argument("slug")
    p.set_defaults(fn=_cmd_lint)

    p = sub.add_parser("library", help="legal sample libraries: search, fetch, usage")
    p.add_argument("action", choices=["search", "fetch", "usage", "prune"],
                   help="prune: drop edited-region cache files no compiled sound uses")
    p.add_argument("arg", nargs="?", help="query (search) or library id (fetch)")
    p.add_argument("--subset", default="")
    p.add_argument("--max-mb", type=float, default=1500)
    p.add_argument("--yes", action="store_true", help="confirm downloads above 500 MB")
    p.add_argument("--any", action="store_true", help="also list private-lane sources")
    p.set_defaults(fn=_cmd_lib)

    p = sub.add_parser("import", help="import an SFZ or a folder of note-named files as a sketch")
    p.add_argument("slug")
    p.add_argument("source", help="file.sfz, a folder, or <library-id>:<path>")
    p.add_argument("-f", "--family", default="piano")
    p.add_argument("--title")
    p.add_argument("--layers", type=int, default=0)
    p.add_argument("--budget", type=float, default=600)
    p.add_argument("--include", help="substring filter for WAV sets (e.g. a mic)")
    p.add_argument("--replace", action="store_true")
    p.set_defaults(fn=_cmd_import)

    p = sub.add_parser("bank", help="sound banks: new, list, add (move a sound in), edit, pack, install, migrate, tag")
    p.add_argument("action", choices=["new", "list", "add", "pack", "install", "edit", "migrate", "tag"])
    p.add_argument("args", nargs="*", help="new: <slug>; add: <sound> <bank>; pack: <bank>; install: <file>")
    p.add_argument("--title")
    p.add_argument("--subtitle")
    p.add_argument("--description")
    p.add_argument("--author")
    p.add_argument("--license", default="")
    p.add_argument("-o", "--out", help="pack: output file")
    p.set_defaults(fn=_cmd_bank)

    p = sub.add_parser("preview-all", help="render build/preview.m4a for every compiled sound that lacks one")
    p.add_argument("--force", action="store_true", help="redo existing previews")
    p.add_argument("--skip", action="append", metavar="NAME", help="skip any folder with this path component (e.g. trap)")
    p.add_argument("--jobs", type=int, default=3)
    p.set_defaults(fn=_cmd_preview_all)

    p = sub.add_parser("mcp", help="run the MCP server on stdio")
    p.set_defaults(fn=_cmd_mcp)

    a = ap.parse_args(argv)
    try:
        return a.fn(a) or 0
    except library.LibraryError as e:
        print(f"libero: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
