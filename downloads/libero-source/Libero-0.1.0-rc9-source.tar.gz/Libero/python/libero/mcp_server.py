"""`libero` MCP server (stdio): design, analyse, compile, preview and push sounds.

Run with `libero-mcp`. The tool docstrings are the model's interface; keep them exact.
"""

from __future__ import annotations

import inspect
import json
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP, Image

from . import analysis, dsp, library, params, synth
from .audio import Audio

INSTRUCTIONS = """Libero turns sound recipes into a playable instrument. A sound is a folder
(sound.py recipe + samples/ + figure.svg + notes.md) that compiles into a bundle of WAV zones the
plugin plays instantly. Start with guide('sound_design').

Real acoustic instruments (piano, strings, winds, mallets, drums…) are built from legal recorded
libraries, fast: library_search → library_fetch (a subset) → import_sfz or import_wav_set (applies the
family preset) → compile → lint (fix what it says) → preview. That is 5-6 calls for a playable
instrument; see guide('sampled').

Designed/synthetic sounds: sound_new → build samples (synth_generate, workbench, sample_* ops,
freesound_*) → analyze/spectrogram → edit sound.py (sound_write) → compile → lint → preview.
Then plugin_load/plugin_play, draw figure.svg (guide('figures'), figure_view), notes.md, and ask the
user whether to sound_save. New sounds live in sketches/ until saved."""

mcp = FastMCP("libero", instructions=INSTRUCTIONS, log_level="WARNING")

GUIDES = Path(__file__).parent / "guides"
FIGURES_PLACEHOLDER = """# Figures (placeholder)

The full figure guide has not been installed yet. Until then: figure.svg is a self-contained SVG with
viewBox="0 0 512 512", no scripts, no raster images, no external references (only url(#id)). Draw
from the sound itself — its envelope, partial ratios, material — on a warm ivory ground with deep ink
and one gold accent. Avoid generic clip-art (notes, speakers, waveform icons). Check it with
figure_view(slug)."""


# ---------------------------------------------------------------- helpers

class Problem(Exception):
    pass


def _folder(slug: str) -> Path:
    return library.find_sound(slug)


def _load(slug: str, name: str) -> tuple[Path, Audio, Path]:
    folder = _folder(slug)
    p = library.sample_path(folder, name)
    return folder, Audio.load(p), p


def _png(data: bytes) -> Image:
    return Image(data=data, format="png")


def _save_report(folder: Path, audio: Audio, out_name: str, note: str = "") -> list:
    if audio.n == 0:
        raise Problem("the result is empty (0 samples)")
    p = library.out_sample_path(folder, out_name)
    if audio.peak_db > 0:
        note += f"\n(peak was {audio.peak_db:+.1f} dBFS: saved as float, but normalise or limit before use)"
    audio.save(p)
    ft = analysis.features(audio)
    text = f"saved samples/{p.name}\n" + analysis.format_features(ft, p.stem) + (f"\n{note.strip()}" if note else "")
    return [text, _png(analysis.spectrogram(audio, small=True, title=p.stem))]


def _default_out(name: str, suffix: str) -> str:
    return f"{Path(name).stem}_{suffix}"


# ---------------------------------------------------------------- guides & reference

def recipe_api_markdown() -> str:
    """API reference generated from the code's own signatures and docstrings."""
    from . import audio as audio_mod
    from . import recipe

    def sig(obj, name=None):
        try:
            sg = inspect.signature(obj)
        except (TypeError, ValueError):
            return f"{name or obj.__name__}(...)"
        parts, star = [], False
        for p in sg.parameters.values():
            if p.name == "self":
                continue
            if p.kind is p.KEYWORD_ONLY and not star:
                parts.append("*")
                star = True
            if p.kind is p.VAR_POSITIONAL:
                star = True
                parts.append(f"*{p.name}")
                continue
            if p.kind is p.VAR_KEYWORD:
                parts.append(f"**{p.name}")
                continue
            if p.annotation is p.empty:
                ann = ""
            else:
                ann = p.annotation if isinstance(p.annotation, str) else getattr(p.annotation, "__name__", "")
            txt = p.name + (f": {ann}" if ann else "")
            if p.default is not p.empty:
                txt += f" = {p.default!r}"
            parts.append(txt)
        return f"{name or obj.__name__}({', '.join(parts)})"

    def doc(obj):
        d = inspect.getdoc(obj) or ""
        return d.strip()

    out = ["# Recipe API (generated from the library)", "",
           "```python", "from libero import Sound, Audio, synth, load", "```", "",
           "## Sound", "", f"`{sig(recipe.Sound.__init__, 'Sound')}`", "",
           doc(recipe.Sound), ""]
    for name in ("body", "attack", "tail", "air", "impulse", "loop", "defaults", "render"):
        m = getattr(recipe.Sound, name)
        out += [f"- `sound.{sig(m, name)}` — {doc(m)}".replace("\n", " ")]
    out += ["", "## Ctx (argument of every layer function)", "", "```", doc(recipe.Ctx), "```",
            "- `ctx.load(name, sr=None)` — " + doc(recipe.Ctx.load),
            "- `ctx.has(name)` — " + doc(recipe.Ctx.has),
            "- `ctx.register` — " + doc(recipe.Ctx.register.fget), "",
            "## Audio", "", doc(audio_mod), ""]
    props = ["n", "channels", "is_stereo", "duration", "peak_db", "rms_db"]
    out.append("Properties: " + ", ".join(f"`{p}`" for p in props) + "; `data` (float32 array), `sr`.")
    out.append("")
    for name, m in inspect.getmembers(Audio, predicate=inspect.isfunction):
        if name.startswith("_") or name in props:
            continue
        s = sig(m, name)
        d = doc(m).split("\n\n")[0].replace("\n", " ")
        out.append(f"- `.{s}`" + (f" — {d}" if d else ""))
    out += ["", f"- `load(path, sr=None)` — {doc(audio_mod.load)}", "",
            "## synth", "", doc(synth), ""]
    for name, f in inspect.getmembers(synth, predicate=inspect.isfunction):
        if name.startswith("_") or f.__module__ != synth.__name__:
            continue
        d = doc(f)
        if not d and name in synth.MODES:
            d = f"modal(freq, '{name}', dur, **kw)"
        out += [f"### synth.{name}", "", f"`synth.{sig(f, name)}`", "", d, ""]
    out += ["### synth.LoopGrid", "", f"`synth.{sig(synth.LoopGrid.__init__, 'LoopGrid')}`", "", doc(synth.LoopGrid),
            "", "Presets: modal modes " + ", ".join(synth.MODES) + "; vowels " + ", ".join(synth.VOWELS)
            + "; noise colours white, pink, brown, blue, violet; IR kinds " + ", ".join(synth._IR_KINDS), "",
            "## dsp helpers", ""]
    for name in ("midi_to_freq", "freq_to_midi", "note_name", "parse_note", "describe_freq"):
        out.append(f"- `dsp.{sig(getattr(dsp, name), name)}`")
    return "\n".join(out)


@mcp.tool()
def guide(topic: str = "sound_design") -> str:
    """Read a Libero guide. Topics:
    - "sound_design": how Libero thinks (4 layers, what to bake vs leave live), techniques
      (real transients on synthetic bodies, noise beds, convolution, tuning samples, loops),
      the done-checklist and the workflow. READ THIS FIRST.
    - "figures": how to draw figure.svg (house style, rules against generic imagery).
    - "recipe_api": the exact API of Sound, Ctx, Audio and synth (generated from the code).
    - "params": the live parameter table (same as params_reference).
    - "sampled": real instruments from recorded libraries: sources, import, family presets,
      the editing the compiler does, lint, and when to hybridise. READ THIS for piano, strings, etc.
    - "physics": physical modelling (libero.physics): strings, winds, brass, bars, bells, membranes,
      bodies, rooms; copy-pasteable recipes per instrument, parameter ranges, troubleshooting.
    - "genres": route the sound first (genre, role, REC/SYN/PM/HYB), genre cheat-sheets, what to measure
      against a reference, failure modes. READ THIS before building any sound.
    - "forge": the wavetable synthesis library libero.forge: oscillators, warps, unison, filters, mod matrix,
      FX rack, tape/vinyl, 20 presets, recipe integration, cookbook (request -> patch).
    - "fast": workflow for sketching many sounds quickly (1-3 minutes each).
    - "slow": workflow for one carefully measured sound (recreating a real instrument)."""
    if topic == "recipe_api":
        return recipe_api_markdown()
    if topic == "params":
        return params.reference_markdown()
    if topic == "figures":
        p = GUIDES / "figures.md"
        return p.read_text() if p.exists() else FIGURES_PLACEHOLDER
    p = GUIDES / f"{topic}.md"
    if topic in ("sound_design", "fast", "slow", "sampled", "physics", "genres", "forge") and p.exists():
        return p.read_text()
    raise Problem("topic must be one of: sound_design, genres, sampled, physics, forge, fast, slow, figures, recipe_api, params")


@mcp.tool()
def params_reference() -> str:
    """The live parameters (SPEC §5): ids, ranges, defaults. Use these ids in sound.defaults(...),
    preview(params=...) and plugin_set_params. Choice params take their name, e.g. rev_mode="Cisterna"."""
    return params.reference_markdown()


# ---------------------------------------------------------------- sounds

@mcp.tool()
def sound_new(slug: str, template: str = "plucked", title: str = "", subtitle: str = "") -> str:
    """Create a new sketch sketches/<slug>/ from a template recipe and return its sound.py.
    slug: 1-48 chars of a-z, 0-9, '-'. template: plucked | bell | pad | bowed | percussion | hybrid
    (hybrid = sample-based: import a recording as samples/source.wav and it is tuned/looped per root).
    Templates are complete, good-sounding starting points: read the code, then reshape it."""
    folder = library.new_sound(slug, template, title or None, subtitle)
    return f"created {folder}\n\n--- sound.py ---\n" + (folder / "sound.py").read_text()


@mcp.tool()
def sound_list() -> str:
    """List sketches (unsaved) and saved sounds with title, compile state and whether a figure exists."""
    items = library.list_sounds()
    if not items:
        return f"library is empty ({library.home()})"
    lines = []
    for s in items:
        flags = ("saved" if s["saved"] else "sketch") + (", compiled" if s["compiled"] else "") + \
                (", figure" if s["figure"] else "")
        bank = f", bank {s['bank']}" if s.get("bank") not in (None, "mie", "prove") else ""
        lines.append(f"{s['slug']:<28} {s['title']} — {s['subtitle']}  [{flags}{bank}]")
    return "\n".join(lines)


@mcp.tool()
def sound_read(slug: str, file: str = "sound.py") -> str:
    """Read a text file of a sound: sound.py, notes.md, figure.svg, build/manifest.json,
    samples/ATTRIBUTION.md, or any text file in samples/."""
    return library.read_file(slug, file)


@mcp.tool()
def sound_write(slug: str, file: str, content: str) -> str:
    """Write (replace) a text file in a sound: sound.py, notes.md, figure.svg, or a text file in
    samples/ (e.g. samples/generate.py). For figure.svg the SPEC §8 checks run and are reported.
    Audio goes into samples/ through workbench, synth_generate, sample_* or sample_import instead."""
    p = library.write_file(slug, file, content)
    msg = f"wrote {p} ({len(content.encode())} bytes)"
    if file == "figure.svg":
        from .figure import validate_svg

        probs = validate_svg(content)
        msg += "\nfigure check: " + ("ok" if not probs else "PROBLEMS:\n- " + "\n- ".join(probs))
        msg += "\nlook at it with figure_view(slug)."
    if file == "sound.py":
        try:
            compile(content, "sound.py", "exec")
        except SyntaxError as e:
            msg += f"\nWARNING: syntax error line {e.lineno}: {e.msg}"
    return msg


@mcp.tool()
def sound_save(slug: str) -> str:
    """Save a sketch into the user's library (moves sketches/<slug> → sounds/<slug>).
    Only do this after the user has said they want to keep it. The reply states the sound's licence:
    sounds built from non-commercial or EULA sources may be kept but must not be shared."""
    from . import licenses

    folder = library.find_sound(slug)
    text, cls = licenses.bundle_license(licenses.read_credits(folder))
    dst = library.save_sound(slug)
    note = "" if cls in licenses.SHIPPABLE else f"\nWARNING: {text}. Keep it private."
    return f"saved to {dst}\nlicence: {text}{note}"


@mcp.tool()
def sound_discard(slug: str) -> str:
    """Discard a sketch: moves its folder to the Trash (recoverable). Saved sounds are never discarded
    by this tool. Ask the user before discarding anything you did not create in this session."""
    return f"moved to {library.discard_sound(slug)} (recoverable from the Trash)"


# ---------------------------------------------------------------- banks

@mcp.tool()
def bank_create(slug: str, title: str, subtitle: str = "", description: str = "", author: str = "",
                license: str = "") -> str:
    """Create an empty sound bank banks/<slug>/ (a named collection that can later be packed and shared
    as a .liberobank). Put saved sounds in it with bank_add. slug: 1-48 chars of a-z, 0-9, '-'.
    'mie' and 'prove' are the built-in banks (saved sounds and sketches) and cannot be created."""
    return f"created {library.bank_create(slug, title, subtitle, description, author, license)}"


@mcp.tool()
def bank_list() -> str:
    """List sound banks with sound counts: installed banks first, then Mie (sounds/) and Prove (sketches/)."""
    lines = []
    for b in library.bank_list():
        extra = f" — {b['subtitle']}" if b.get("subtitle") else ""
        ver = f" v{b['version']}" if b.get("version") else ""
        lines.append(f"{b['slug']:<24} {b['count']:>4} sounds  {b['title']}{ver}{extra}")
    return "\n".join(lines)


@mcp.tool()
def bank_add(sound_slug: str, bank: str) -> str:
    """Move a SAVED sound (not a sketch: sound_save it first) into a bank; bank='mie' moves it back to the
    user's own sounds/. Never overwrites. The sound keeps its slug, favourite and build."""
    return f"moved to {library.bank_add(sound_slug, bank)}"


@mcp.tool()
def bank_edit(bank: str, title: str = "", subtitle: str = "", description: str = "", author: str = "") -> str:
    """Change an installed bank's title, subtitle, description or author (empty arguments are left as they
    are; the slug never changes). The licence is always derived from the sounds' credits."""
    m = library.bank_edit(bank, title or None, subtitle or None, description or None, author or None)
    return f"edited {m['slug']}: {m['title']} v{m['version']}"


@mcp.tool()
def sound_tag(sound_slug: str, color: int) -> str:
    """Set a sound's colour tag: 1-4 (Pompeian red, ochre, verdigris, lapis), 0 removes it. Kept in
    config.json by slug, so it follows the sound between banks."""
    return f"tag {library.set_color_tag(sound_slug, color)} on {sound_slug}"


@mcp.tool()
def bank_pack(bank: str, out_path: str = "") -> str:
    """Pack a bank into a distributable <bank>.liberobank (zip: bank.json and per sound build/, figure.svg,
    notes.md, sound.py and the credits; no source audio). Refuses, naming the sounds, if any sound is built
    from non-commercial, private-use or unknown-licence sources. out_path: a file or folder (default: the
    current directory)."""
    return f"packed {library.bank_pack(bank, out_path or None)}"


@mcp.tool()
def bank_install(pack_path: str) -> str:
    """Install a .liberobank into ~/Libero/banks/. Refuses to overwrite an installed bank unless the pack's
    version is newer (the old copy then goes to the Trash)."""
    return f"installed {library.bank_install(pack_path)}"


# ---------------------------------------------------------------- samples

@mcp.tool()
def sample_list(slug: str) -> str:
    """List files in samples/ with duration, rate and channels."""
    items = library.list_samples(_folder(slug))
    if not items:
        return "samples/ is empty"
    lines = []
    for s in items:
        if "seconds" in s:
            lines.append(f"{s['name']:<36} {s['seconds']:>7.3f}s {s['sr']}Hz {s['channels']}ch")
        else:
            lines.append(f"{s['name']:<36} {s['bytes']} bytes" + (" (unreadable)" if s.get("unreadable") else ""))
    return "\n".join(lines)


@mcp.tool()
def sample_import(slug: str, source: str, name: str) -> list:
    """Import audio into samples/<name>.wav from a local file path or an http(s) URL. Any common format
    is converted to 32-bit float WAV (mp3/m4a via afconvert or ffmpeg). The source is recorded in
    samples/ATTRIBUTION.md — only use material the user may use."""
    from . import download

    folder = _folder(slug)
    if source.startswith(("http://", "https://")):
        p, a = download.fetch_url(folder, source, name)
    else:
        p, a = download.import_local(folder, source, name)
    return [f"imported → samples/{p.name}\n" + analysis.format_features(analysis.features(a), p.stem),
            _png(analysis.spectrogram(a, small=True, title=p.stem))]


@mcp.tool()
def freesound_search(query: str, filters: str = "", max_results: int = 15) -> str:
    """Search Freesound. filters uses Freesound syntax, e.g.
    'duration:[0.2 TO 4] license:"Creative Commons 0"' or 'tag:pluck samplerate:48000'.
    Prefer CC0 / CC BY. Needs FREESOUND_API_KEY or "freesound_api_key" in ~/Libero/config.json."""
    from . import download

    res = download.freesound_search(query, filters or None, max_results)
    if not res:
        return "no results"
    return "\n".join(f"#{r['id']}  {r['name'][:50]:<50} {r['seconds']:>6.2f}s  {r['license']:<9} by {r['by']}  "
                     f"★{r['rating']} ↓{r['downloads']}  [{', '.join(r['tags'][:5])}]" for r in res)


@mcp.tool()
def freesound_download(slug: str, id: int, name: str) -> list:
    """Download Freesound sound #id into samples/<name>.wav (the HQ preview, ~44.1 kHz) and record
    license and attribution in samples/ATTRIBUTION.md. Returns features + spectrogram."""
    from . import download

    folder = _folder(slug)
    p, a, meta = download.freesound_download(folder, id, name)
    return [f"downloaded → samples/{p.name} ({meta['license']}, by {meta['by']})\n"
            + analysis.format_features(analysis.features(a), p.stem),
            _png(analysis.spectrogram(a, small=True, title=p.stem))]


@mcp.tool()
def workbench(slug: str, code: str, out_name: str, timeout_s: float = 90) -> list:
    """Run a Python snippet to create or transform audio; it must assign `result` (an Audio, or a dict
    {suffix: Audio} to save several files as <out_name>_<suffix>.wav). Saved into samples/.

    In scope: Audio, synth, dsp, load/sample (names resolve in samples/), np, math, sr=48000,
    samples (Path), freq(note)→Hz, note('A3')→69, LoopGrid. Runs in a subprocess with cwd = the sound
    folder, killed after timeout_s. Trusted code only: it runs with your user permissions,
    can access other files and inherits environment variables. Python sockets are blocked;
    an OS network-denial profile is used on macOS when available. This is not a security
    sandbox, and network isolation is not guaranteed on every platform. Chain Audio ops, e.g.:
        body = load("cello.wav").trim(0.1, 2.5).tune_to("C3")
        pick = synth.noise("white", 0.01).bandpass(3000).fade_out(0.008)
        result = body.transient(pick, overlap_ms=8).noise_floor(-62, "pink").normalize(-3)
    See guide('recipe_api') for every operation."""
    from . import workbench as wb

    folder = _folder(slug)
    r = wb.run(folder, code, out_name, timeout_s)
    if not r.ok:
        raise Problem((r.error or "failed") + (f"\nstdout:\n{r.stdout}" if r.stdout.strip() else ""))
    out: list[Any] = []
    for rel in r.saved:
        a = Audio.load(folder / "samples" / rel)
        out.append(f"saved samples/{rel}\n" + analysis.format_features(analysis.features(a), Path(rel).stem))
        if len(r.saved) <= 3:
            out.append(_png(analysis.spectrogram(a, small=True, title=Path(rel).stem)))
    if r.stdout.strip():
        out.insert(0, "stdout:\n" + r.stdout.strip())
    return out


@mcp.tool()
def sample_trim(slug: str, sample: str, t0: float, t1: float, out_name: str = "", fade_ms: float = 3.0) -> list:
    """Cut samples/<sample> to [t0, t1) seconds (negative = from the end) with short fades."""
    folder, a, _ = _load(slug, sample)
    b = a.trim(t0, t1).fade_in(fade_ms / 1000).fade_out(fade_ms / 1000)
    return _save_report(folder, b, out_name or _default_out(sample, "trim"))


@mcp.tool()
def sample_pitch(slug: str, sample: str, semitones: float | None = None, to_note: str | None = None,
                 preserve_duration: bool = False, out_name: str = "") -> list:
    """Shift pitch by `semitones` (resampling: duration changes, like tape) or tune to `to_note`
    ('A3', 'C#4' or a MIDI number) by detecting f0 and correcting it. preserve_duration=True
    time-stretches back to the original length (phase vocoder)."""
    folder, a, _ = _load(slug, sample)
    note = ""
    if to_note is not None and str(to_note) != "":
        b = a.tune_to(to_note)
        note = f"detected {dsp.describe_freq(b.meta['detected_hz'])} → shifted {b.meta['shift_semitones']:+.2f} st"
        if preserve_duration:
            b = b.stretch(a.n / b.n)
    elif semitones is not None:
        b = a.pitch(semitones, preserve_duration)
    else:
        raise Problem("give semitones or to_note")
    return _save_report(folder, b, out_name or _default_out(sample, "pitch"), note)


@mcp.tool()
def sample_stretch(slug: str, sample: str, factor: float, out_name: str = "") -> list:
    """Time-stretch by `factor` (2 = twice as long) keeping pitch (phase vocoder, phase-locked)."""
    if not 0.1 <= factor <= 16:
        raise Problem("factor must be within 0.1..16")
    folder, a, _ = _load(slug, sample)
    return _save_report(folder, a.stretch(factor), out_name or _default_out(sample, "stretch"))


@mcp.tool()
def sample_layer(slug: str, layers: list[dict], out_name: str, normalize_db: float | None = -3.0) -> list:
    """Layer several samples in time: layers = [{"name": "body", "at": 0.0, "gain_db": 0, "pitch": 0,
    "pan": 0}, {"name": "click", "at": 0.002, "gain_db": -6}]. 'at' in seconds, 'pitch' in semitones
    (resampled), 'pan' -1..1. The mix is normalised to normalize_db (null = leave level)."""
    folder = _folder(slug)
    out: Audio | None = None
    for L in layers:
        if "name" not in L:
            raise Problem("every layer needs a 'name'")
        a = Audio.load(library.sample_path(folder, L["name"]))
        if L.get("pitch"):
            a = a.pitch(float(L["pitch"]))
        if L.get("pan") is not None and L.get("pan") != 0:
            a = a.pan(float(L["pan"]))
        if out is None:
            out = Audio.silence(0.0, a.sr)
        out = out.place(a, float(L.get("at", 0.0)), float(L.get("gain_db", 0.0)))
    if out is None:
        raise Problem("no layers")
    if normalize_db is not None:
        out = out.normalize(normalize_db)
    return _save_report(folder, out, out_name)


@mcp.tool()
def sample_convolve(slug: str, a: str, b: str, mix: float = 1.0, out_name: str = "") -> list:
    """Convolve sample a with sample b (FFT). Use b as an impulse response or a material: a wood IR
    gives a body, a hall IR a space, a second sound a cross-synthesis. mix 0..1 (wet level matched to
    dry). Output length = len(a) + len(b) - 1."""
    folder, x, _ = _load(slug, a)
    _, h, _ = _load(slug, b)
    return _save_report(folder, x.convolve(h, mix).normalize(-3), out_name or f"{Path(a).stem}_x_{Path(b).stem}")


@mcp.tool()
def sample_filter(slug: str, sample: str, kind: str, freq: float, q: float = 0.707, gain_db: float = 0.0,
                  order: int = 1, out_name: str = "") -> list:
    """Filter a sample. kind: lowpass | highpass | bandpass | notch | peak | lowshelf | highshelf.
    order stacks biquads (12 dB/oct each) for lowpass/highpass/bandpass; gain_db for peak/shelves."""
    folder, a, _ = _load(slug, sample)
    if kind in ("lowpass", "highpass", "bandpass"):
        b = getattr(a, kind)(freq, q, order)
    elif kind == "notch":
        b = a.notch(freq, q)
    elif kind in ("peak", "lowshelf", "highshelf"):
        b = getattr(a, kind)(freq, gain_db, q)
    else:
        raise Problem("kind must be lowpass, highpass, bandpass, notch, peak, lowshelf or highshelf")
    return _save_report(folder, b, out_name or _default_out(sample, kind))


@mcp.tool()
def sample_fade(slug: str, sample: str, fade_in: float = 0.0, fade_out: float = 0.0, curve: str = "sine",
                out_name: str = "") -> list:
    """Fade in/out (seconds). curve: linear | sine (equal power) | exp | log."""
    folder, a, _ = _load(slug, sample)
    return _save_report(folder, a.fade_in(fade_in, curve).fade_out(fade_out, curve),
                        out_name or _default_out(sample, "fade"))


@mcp.tool()
def sample_normalize(slug: str, sample: str, peak_db: float = -1.0, rms_db: float | None = None,
                     out_name: str = "") -> list:
    """Normalise to a sample peak (dBFS) or, if rms_db is given, to an RMS level."""
    folder, a, _ = _load(slug, sample)
    b = a.normalize_rms(rms_db) if rms_db is not None else a.normalize(peak_db)
    return _save_report(folder, b, out_name or _default_out(sample, "norm"))


@mcp.tool()
def sample_noise_floor(slug: str, sample: str, db: float = -60.0, color: str = "pink",
                       lowpass: float | None = None, seed: int = 0, out_name: str = "") -> list:
    """Add a steady background noise bed ('rumore di fondo') at `db` dBFS RMS under the whole sample.
    color: white | pink | brown | blue | violet; optional lowpass Hz to darken it."""
    folder, a, _ = _load(slug, sample)
    return _save_report(folder, a.noise_floor(db, color, seed, lowpass), out_name or _default_out(sample, "bed"))


@mcp.tool()
def sample_attach_transient(slug: str, body: str, transient: str, overlap_ms: float = 12.0,
                            transient_gain_db: float = 0.0, out_name: str = "") -> list:
    """Attach a real attack to a body: onsets are aligned, the body fades in over overlap_ms while the
    transient owns the first milliseconds and keeps ringing on top. The classic move for making a
    synthetic body feel physical (a real pick, hammer, breath or bow scrape on a modelled tone)."""
    folder, b, _ = _load(slug, body)
    _, t, _ = _load(slug, transient)
    return _save_report(folder, b.transient(t, overlap_ms, transient_gain_db),
                        out_name or f"{Path(body).stem}_with_{Path(transient).stem}")


SYNTH_KINDS = {
    "sine": synth.sine, "saw": synth.saw, "square": synth.square, "tri": synth.tri, "additive": synth.additive,
    "fm": synth.fm, "karplus": synth.karplus, "modal": synth.modal, "bell": synth.bell, "glass": synth.glass,
    "wood": synth.wood, "metal_plate": synth.metal_plate, "noise": synth.noise, "breath": synth.breath,
    "bow": synth.bow, "impulse_response": synth.impulse_response, "exciter": synth.exciter,
}


@mcp.tool()
def synth_generate(slug: str, kind: str, params: dict, out_name: str) -> list:
    """Synthesise into samples/<out_name>.wav. kind and its params (see guide('recipe_api')):
    sine/saw/square/tri {freq, dur} · additive {freq, partials:[[ratio, amp, t60]], dur} ·
    fm {carrier, ratio, index, dur, index_t60} · karplus {freq, dur, bright, damping|decay, pick_position} ·
    modal {freq, modes: bell|glass|wood|metal_plate|chime or [[ratio,t60,amp]], dur, hardness, detune_cents} ·
    bell/glass/wood/metal_plate {freq, dur} · noise {color, dur} · breath {dur, brightness, motion} ·
    bow {freq, dur, body: string|glass|..., pressure, bright, vibrato_cents} ·
    impulse_response {kind: room|hall|plate|cave|spring|wood|metal, seconds} ·
    exciter {kind: impulse|mallet|pluck|scrape, hardness}.
    Any freq may be given as a note name via "note": "A3" instead of "freq"."""
    if kind not in SYNTH_KINDS:
        raise Problem(f"kind must be one of {sorted(SYNTH_KINDS)}")
    fn = SYNTH_KINDS[kind]
    p = dict(params or {})
    if "note" in p:
        hz = dsp.midi_to_freq(dsp.parse_note(p.pop("note")))
        key = "carrier" if kind == "fm" else "freq"
        p[key] = hz
    if kind == "impulse_response" and "ir_kind" in p:
        p["kind"] = p.pop("ir_kind")
    if "partials" in p:
        p["partials"] = [tuple(x) for x in p["partials"]]
    if isinstance(p.get("modes"), list):
        p["modes"] = [tuple(x) for x in p["modes"]]
    allowed = set(inspect.signature(fn).parameters)
    unknown = set(p) - allowed
    if unknown:
        raise Problem(f"{kind} does not take {sorted(unknown)}; parameters: {sorted(allowed)}")
    dur = p.get("dur") or p.get("seconds")
    if dur and float(dur) > 60:
        raise Problem("keep generated audio under 60 s")
    a = fn(**p)
    return _save_report(_folder(slug), a, out_name)


# ---------------------------------------------------------------- analysis

@mcp.tool()
def analyze(slug: str, sample: str, t0: float | None = None, t1: float | None = None) -> str:
    """Numbers for samples/<sample> (or 'build/<zone>.wav'), optionally for [t0, t1] seconds: level,
    loudness, attack, T60, onsets, f0 as note + cents with spread/drift, spectral centroid/rolloff/
    flatness, energy above 16 kHz (aliasing) and below 40 Hz (rumble), top partials as ratios, inharmonicity,
    noisiness, stereo correlation, DC, clipping."""
    _, a, p = _load(slug, sample)
    if t0 is not None or t1 is not None:
        a = a.trim(t0 or 0.0, t1)
    return analysis.format_features(analysis.features(a), p.stem)


@mcp.tool()
def spectrogram(slug: str, sample: str, t0: float | None = None, t1: float | None = None, fmin: float = 30.0,
                fmax: float | None = None, db_range: float = 90.0) -> list:
    """Spectrogram image (log frequency, C gridlines, RMS envelope on top) of a sample or build zone
    ('build/body_n060_v100.wav'). Zoom with t0/t1 (look at the attack: 0..0.1; the sustain; the loop
    seam) and fmin/fmax. Aliasing shows as partials folding down from the top; clicks as vertical lines."""
    _, a, p = _load(slug, sample)
    return [_png(analysis.spectrogram(a, t0, t1, fmin, fmax, True, db_range, title=p.stem))]


@mcp.tool()
def waveform(slug: str, sample: str, t0: float | None = None, t1: float | None = None) -> list:
    """Waveform image with the RMS envelope. Zoom below ~2500 samples to see individual samples
    (check clicks, zero crossings at loop points, DC, clipping)."""
    _, a, p = _load(slug, sample)
    return [_png(analysis.waveform(a, t0, t1, title=p.stem))]


@mcp.tool()
def compare(slug: str, a: str, b: str, t0: float | None = None, t1: float | None = None) -> list:
    """Two spectrograms stacked on the same time axis and dB scale (before/after, reference vs yours)."""
    _, x, pa = _load(slug, a)
    _, y, pb = _load(slug, b)
    return [_png(analysis.compare(x, y, pa.stem, pb.stem, t0, t1))]


# ---------------------------------------------------------------- compile & preview

@mcp.tool(name="compile")
def compile_tool(slug: str, force: bool = False) -> str:
    """Compile sound.py into build/ (SPEC §4): renders every zone (cached per zone, so unchanged zones
    are instant; force=True re-renders all), finds loops, removes DC, limits peaks to -1 dBFS, checks
    tuning, aliasing, loop seams and loudness spread across roots, validates the bundle. Returns a
    per-zone summary and warnings — fix warnings before calling a sound done."""
    from .compiler import compile_sound

    res = compile_sound(_folder(slug), use_cache=not force)
    if not res.ok:
        raise Problem(res.text())
    return res.text()


@mcp.tool()
def preview(slug: str, notes: str = "48 60 72", params: dict | None = None, tail: float = 3.0,
            cc: str = "") -> list:
    """Render notes through libero-render — the plugin's own engine — and return features + spectrogram
    of the result (recompiles first if sources changed). notes: "48 60 72" (one after another),
    "60+64+67" (chord), or exact "60:0:1.2:100,64:0.5:1.0:90" (pitch:start_s:dur_s:velocity);
    note names work too ("C3 E3 G3"). params: live parameter overrides, e.g. {"rev_mix": 0.4}.
    cc: MIDI controller events "time_s:controller:value,..." e.g. "0:1:10,3:1:127" sweeps the
    mod wheel (the dynamics axis of sounds whose source is cc1)."""
    from . import render

    pv = render.preview(slug, notes, params, tail, cc=cc or None)
    ft = analysis.features(pv.audio)
    text = f"rendered {pv.wav}\n" + analysis.format_features(ft, "preview")
    if pv.compiled:
        text = pv.compiled.split("\n")[0] + " (recompiled)\n" + text
    return [text, _png(analysis.spectrogram(pv.audio, title=f"{slug} · preview"))]


# ---------------------------------------------------------------- recorded libraries

def _lib_path(path: str) -> Path:
    """'<library-id>:<relative path>' inside the library cache, or an absolute/home path."""
    from .ingest import BY_ID, library_dir

    if ":" in path and not path.startswith("/") and path.split(":", 1)[0] in BY_ID:
        sid, rel = path.split(":", 1)
        p = (library_dir(sid) / rel).resolve()
        if library_dir(sid).resolve() not in p.parents and p != library_dir(sid).resolve():
            raise Problem("path escapes the library folder")
        return p
    return Path(path).expanduser()


@mcp.tool()
def library_search(query: str, family: str = "", license: str = "shippable", max_results: int = 8) -> str:
    """Find legal recorded libraries for an instrument ("grand piano", "solo violin", "marimba", "tuba",
    "drum kit"...). license="shippable" (default) shows only CC0 / CC BY / CC BY-SA sources whose
    derived sounds may be shared; "any" also lists private-lane sources (NC, EULA, unknown terms).
    family filters: piano, orchestral, bowed, wind, brass, plucked, percussion, synth, ir, various.
    Each line: id, quality 1-5, licence, size, what it holds. Next: library_info(id) or library_fetch."""
    from .ingest import search

    res = search(query, family, license, max_results)
    if not res:
        return "no source matches; try a broader word, license='any', or synthesis (guide('sampled') § gaps)"
    return "\n".join(f"{s.id:<28} ★{s.quality} {s.license:<18} {s.size_mb:>6.0f} MB  {s.name}: "
                     f"{', '.join(s.instruments[:6])}{' …' if len(s.instruments) > 6 else ''}"
                     f"{'' if s.shippable else '  [PRIVATE LANE]'}" for s in res)


@mcp.tool()
def library_info(id: str) -> str:
    """Everything about one catalogued library: licence and author (for credits), layers/RR, format,
    named subsets you can fetch, what is already in the local cache, and (GitHub sources) the top
    folders with sizes so you can choose a subset glob."""
    from .ingest import BY_ID, library_dir
    from .ingest.fetcher import github_tree

    if id not in BY_ID:
        raise Problem(f"unknown library '{id}'; use library_search")
    s = BY_ID[id]
    lines = [f"{s.name} ({s.id}) — {s.license} [{s.license_class}{', shippable' if s.shippable else ', PRIVATE'}]",
             f"by {s.author} — {s.url}", f"format {s.format}; {s.layers}", f"notes: {s.notes}"]
    if s.subsets:
        lines.append("subsets: " + "; ".join(f"{k} = {v if isinstance(v, str) else ', '.join(v)[:120]}"
                                           for k, v in s.subsets.items()))
    d = library_dir(id)
    idx = d / "_index.json"
    if idx.exists():
        data = json.loads(idx.read_text())
        mb = sum(data.get("files", {}).values()) / 1e6
        lines.append(f"cached: {len(data.get('files', {}))} files, {mb:.0f} MB in {d} (subsets {data.get('subsets')})")
        sfz = sorted(p for p in data.get("files", {}) if p.lower().endswith(".sfz"))
        if sfz:
            lines.append("cached SFZ: " + ", ".join(sfz[:12]))
    if s.fetch["type"] == "github":
        try:
            tree = github_tree(s)
            tops: dict[str, list[int]] = {}
            for t in tree:
                parts = t["path"].split("/")
                key = "/".join(parts[:2]) if len(parts) > 2 else (parts[0] if len(parts) > 1 else "(root)")
                tops.setdefault(key, [0, 0])
                tops[key][0] += 1
                tops[key][1] += t["size"]
            lines.append("folders (files, MB):")
            for k, (n, b) in sorted(tops.items(), key=lambda kv: -kv[1][1])[:40]:
                lines.append(f"  {k:<60} {n:>5} {b / 1e6:>8.1f}")
            sfz_all = [t["path"] for t in tree if t["path"].lower().endswith(".sfz")]
            if sfz_all:
                lines.append(f"SFZ files ({len(sfz_all)}): " + ", ".join(sfz_all[:40]))
        except Exception as e:
            lines.append(f"(tree listing unavailable: {e})")
    return "\n".join(lines)


@mcp.tool()
def library_fetch(id: str, subset: str = "", max_mb: float = 1500, confirm: bool = False) -> str:
    """Download part of a library into ~/Libero/cache/libraries/<id>/. subset: a named subset from
    library_info, 'sfz:<file>.sfz' (fetches exactly the samples that SFZ uses), a glob such as
    'Idiophones/Struck Idiophones/Marimba/*', or 'full'. The disk is nearly full: anything above
    500 MB only reports its size until you call again with confirm=True, and nothing above max_mb
    (default 1500) is fetched. Already-cached files are not downloaded again."""
    from .ingest import fetch

    r = fetch(id, subset, max_mb, confirm)
    return json.dumps(r, indent=1, ensure_ascii=False)


@mcp.tool()
def import_sfz(slug: str, sfz: str, family: str = "piano", title: str = "", subtitle: str = "", layers: int = 0,
               root_step: int = 0, takes: int = 0, budget_mb: float = 600, releases: bool = True,
               replace: bool = False) -> str:
    """Turn an SFZ instrument into a sketch that plays its real samples. sfz: '<library-id>:<path in
    the library>' (e.g. 'salamander-grand-v3:Salamander Grand Piano V3.sfz') or an absolute path.
    Reads #define/#include, headers and inheritance, keyswitch banks (default bank), CC gates,
    velocity layers → continuous dynamics layers, round robins, release triggers → tail with rt_decay,
    loops, tune/volume. family (piano, plucked, mallet, bowed, wind, brass, voice, percussion, pad,
    cinematic, synth) sets how the compiler edits the samples (see family_preset). layers/root_step/
    takes = 0 means chosen by the family and the memory budget (budget_mb of float audio in the
    plugin). Files are linked, not copied. Credits and licence are recorded. Next: compile, lint, preview."""
    from .ingest import import_sfz as _imp

    r = _imp(slug, _lib_path(sfz), family, title, subtitle, layers, root_step, takes, budget_mb, "slow", releases,
             None, replace)
    return json.dumps(r, indent=1, ensure_ascii=False)


@mcp.tool()
def import_wav_set(slug: str, folder: str, family: str = "plucked", pattern: str = "", include: str = "",
                   exclude: str = "", title: str = "", subtitle: str = "", layers: int = 0, root_step: int = 0,
                   takes: int = 0, budget_mb: float = 600, replace: bool = False) -> str:
    """Turn a folder of note-named audio files into a sketch (VCSL, TinySOL, your own recordings).
    folder: '<library-id>:<folder>' or an absolute path. Names are parsed for a note (C#4, Db3),
    a dynamic (pp..ff, soft/med/loud, v1..vN) and a round robin (rr1, trailing _01); files in a
    'Releases' folder or named 'rel' become the tail. Or give pattern, a regex with named groups
    note/dyn/rr. include/exclude: comma-separated substrings to filter paths (e.g. include='Main' to
    pick one microphone). family and budget as in import_sfz. Next: compile, lint, preview."""
    from .ingest import import_wav_set as _imp

    r = _imp(slug, _lib_path(folder), family, pattern, include, exclude, title, subtitle, layers, root_step, takes,
             budget_mb, "slow", None, replace)
    return json.dumps(r, indent=1, ensure_ascii=False)


@mcp.tool()
def family_preset(family: str, quality: str = "slow") -> str:
    """The recipe skeleton and defaults for an instrument family: root spacing, dynamics layers, round
    robins, loop and length policy, release, humanize, compiler editing options and starting live
    parameters (from how professional libraries are built). family: piano, plucked, mallet, bowed,
    wind, brass, voice, percussion, pad, cinematic, synth. quality: fast (sketch) or slow (keeper)."""
    from . import families

    try:
        return families.preset_text(family, quality)
    except ValueError as e:
        raise Problem(str(e)) from None


@mcp.tool()
def lint(slug: str) -> str:
    """Objective quality check of the compiled bundle — run it instead of guessing by ear. Checks
    coverage and format, tuning spread between the layers of a key and off the keyboard curve, level
    and brightness ladders across dynamics layers, onset alignment, clicks at starts/ends/loop seams,
    DC, aliasing, silent zones, round robins that are nearly identical, missing release layers, loudness
    jumps between neighbouring keys, noise-floor spread. FAIL = fix before calling it done, WARN =
    look at it. Compile first."""
    from .lint import lint_text

    folder = _folder(slug)
    if not (folder / "build" / "manifest.json").exists():
        raise Problem(f"'{slug}' is not compiled yet: call compile('{slug}') first")
    return lint_text(folder / "build", slug)


@mcp.tool()
def sound_licenses(slug: str) -> str:
    """The sources a sound is built from (samples/credits.json), their licences, and whether the sound
    may be shared: the bundle is as restricted as its most restricted source."""
    from . import licenses

    folder = _folder(slug)
    cr = licenses.read_credits(folder)
    text, cls = licenses.bundle_license(cr)
    lines = [f"{slug}: {text} [{cls}] — {'shippable' if cls in licenses.SHIPPABLE else 'PRIVATE: do not share'}"]
    for c in cr:
        lines.append(f"- {c.get('source')} by {c.get('author', '?')}, {c.get('license')} <{c.get('url', '')}>")
    return "\n".join(lines)


@mcp.tool()
def sample_trim_onset(slug: str, sample: str, pre_ms: float = 2.0, out_name: str = "") -> list:
    """Cut a recording to its true onset (found well above the noise, then walked back down the attack),
    keeping pre_ms of faded pre-roll, so every note of an instrument starts the same way."""
    from .sampletools import onset_trim

    folder, a, _ = _load(slug, sample)
    return _save_report(folder, onset_trim(a, pre_ms), out_name or _default_out(sample, "on"))


@mcp.tool()
def sample_align(slug: str, samples: list[str], suffix: str = "_al", max_ms: float = 3.0, pre_ms: float = 2.0) -> str:
    """Phase-align several recordings of the same note (dynamics layers or takes): each is onset-trimmed
    and shifted (≤ max_ms) so its attack lines up with the loudest, which keeps crossfades between
    layers from combing. Saves <name><suffix>.wav for each; returns the shifts and correlations.
    (The compiler does this automatically for multisample regions; use this for workbench material.)"""
    from .sampletools import align_set

    folder = _folder(slug)
    auds = [Audio.load(library.sample_path(folder, n)) for n in samples]
    out, rep = align_set(auds, pre_ms, max_ms)
    lines = []
    for n, a, r in zip(samples, out, rep):
        p = library.out_sample_path(folder, Path(n).stem + suffix)
        a.save(p)
        lines.append(f"{p.name}: shift {r['shift']} samples, corr {r['corr']}" + (" (reference)" if r.get("reference") else ""))
    return "\n".join(lines)


@mcp.tool()
def sample_ladder(slug: str, samples: list[str]) -> str:
    """Measure a dynamics ladder of one note (samples softest → loudest): loudness and brightness per
    layer, the steps between them, whether both rise, and the one gain that keeps their natural
    spread with the loudest peak at -3 dBFS. Flat brightness = one sound at two volumes."""
    from .sampletools import ladder

    folder = _folder(slug)
    auds = [Audio.load(library.sample_path(folder, n)) for n in samples]
    return json.dumps(ladder(auds, [Path(n).stem for n in samples]), indent=1)


@mcp.tool()
def sample_release(slug: str, sample: str, kind: str = "damper", seconds: float = 0.6, at: float | None = None,
                   out_name: str = "") -> list:
    """Synthesise a release sample from a sustained note when the library has none: 'damper' (the note
    cut short with a felt thump), 'room' (a slower darker ring-out), 'bloom' (undamped strings swelling
    then dying). Use it as the tail layer with rt_decay."""
    from .sampletools import release_from

    folder, a, _ = _load(slug, sample)
    return _save_report(folder, release_from(a, kind, seconds, at), out_name or _default_out(sample, "rel"))


@mcp.tool()
def sample_morph(slug: str, a: str, b: str, n: int = 1, prefix: str = "") -> str:
    """Create n in-between dynamics layers from a soft (a) and a loud (b) recording of the same note by
    interpolating their spectral envelopes and levels (align them first). Lets 2-3 real layers become
    5-8 smooth ones. Saves <prefix>_m1.wav … <prefix>_m<n>.wav."""
    from .sampletools import morph

    folder, x, _ = _load(slug, a)
    _, y, _ = _load(slug, b)
    outs = morph(x, y, n)
    pre = prefix or f"{Path(a).stem}_to_{Path(b).stem}"
    lines = []
    for k, o in enumerate(outs, 1):
        p = library.out_sample_path(folder, f"{pre}_m{k}")
        o.save(p)
        lines.append(f"{p.name}: {analysis.format_features(analysis.features(o)).splitlines()[0]}")
    return "\n".join(lines)


@mcp.tool()
def sample_texture(slug: str, sample: str, kind: str, params: dict | None = None, out_name: str = "") -> list:
    """Design processors for hybrid/cinematic layers, baked offline:
    freeze {at, seconds, width_s}: a spectral freeze of one moment into a drone ·
    granular {seconds, grain_ms, density, position, spread, jitter_cents, reverse_p}: a grain cloud ·
    tape {wow, flutter, sat, age}: resampled through a worn tape ·
    reverse_swell {seconds}: the sound's reverberated tail reversed, rising into the note ·
    stretch_pad {factor, at, seconds}: a slice stretched into a slow pad."""
    from . import sampletools as T

    fns = {"freeze": T.freeze, "granular": T.granular, "tape": T.tape, "reverse_swell": T.reverse_swell,
           "stretch_pad": T.stretch_pad}
    if kind not in fns:
        raise Problem(f"kind must be one of {sorted(fns)}")
    folder, a, _ = _load(slug, sample)
    p = dict(params or {})
    allowed = set(inspect.signature(fns[kind]).parameters) - {"a"}
    bad = set(p) - allowed
    if bad:
        raise Problem(f"{kind} takes {sorted(allowed)}, not {sorted(bad)}")
    if kind == "freeze" and "at" not in p:
        p["at"] = a.duration * 0.4
    return _save_report(folder, fns[kind](a, **p), out_name or _default_out(sample, kind))


@mcp.tool()
def sample_split(slug: str, sample: str, first_note: str = "", step: int = 1, prefix: str = "") -> str:
    """Cut a recording of several separate notes (e.g. an Iowa chromatic run) into one file per note,
    named <prefix>_<note>.wav (Cs4 = C#4, ready for import_wav_set). Notes are detected by silence gaps;
    their pitch is detected unless first_note (and step in semitones) is given."""
    from .sampletools import split_runs

    folder, a, p = _load(slug, sample)
    parts = split_runs(a, first_note or None, step)
    pre = prefix or p.stem
    lines = []
    for note, seg in parts:
        name = f"{pre}_{dsp.note_name(note).replace('#', 's') if note is not None else 'x'}"
        q = library.out_sample_path(folder, name)
        seg.save(q)
        lines.append(f"{q.name}: {seg.duration:.2f} s" + (f", {dsp.note_name(note)}" if note is not None else ""))
    return f"{len(parts)} notes\n" + "\n".join(lines)


# ---------------------------------------------------------------- figure

@mcp.tool()
def figure_view(slug: str) -> list:
    """Rasterise the sound's figure.svg (512 px) so you can see and critique your drawing, and check
    it against SPEC §8: viewBox 0 0 512 512, no scripts, no raster images, no external references."""
    from .figure import rasterize, validate_svg

    folder = _folder(slug)
    p = folder / "figure.svg"
    if not p.exists():
        raise Problem("no figure.svg yet — write one with sound_write(slug, 'figure.svg', ...); see guide('figures')")
    text = p.read_text()
    probs = validate_svg(text)
    head = "figure.svg: " + ("passes the SPEC §8 checks" if not probs else "PROBLEMS:\n- " + "\n- ".join(probs))
    try:
        return [head, _png(rasterize(text))]
    except Exception as e:  # rasteriser failures are reported, not fatal
        return [head + f"\n(could not rasterise: {e})"]


# ---------------------------------------------------------------- plugin live control

@mcp.tool()
def plugin_instances() -> str:
    """Running Libero plugin instances (id, host DAW, port, loaded sound)."""
    from . import plugin

    live = plugin.instances()
    if not live:
        return "no running Libero instance (open the plugin in a DAW)"
    return "\n".join(f"{i.get('id')}  port {i.get('port')}  host {i.get('host')}  sound {i.get('sound')}" for i in live)


@mcp.tool()
def plugin_load(slug: str, instance: str | None = None) -> str:
    """Load a compiled sound into a running plugin (most recent instance unless `instance` is given).
    Compile first; the plugin applies the manifest's default params."""
    from . import plugin

    folder = _folder(slug)
    if not (folder / "build" / "manifest.json").exists():
        raise Problem(f"'{slug}' is not compiled yet: call compile('{slug}') first")
    return json.dumps(plugin.call("load", instance, path=str(folder.resolve())))


@mcp.tool()
def plugin_get_params(ids: list[str] | None = None, instance: str | None = None) -> str:
    """Current live parameter values of a running plugin (all, or just `ids`)."""
    from . import plugin

    kw = {"ids": ids} if ids else {}
    return json.dumps(plugin.call("get_params", instance, **kw), indent=1)


@mcp.tool()
def plugin_set_params(values: dict, instance: str | None = None) -> str:
    """Set live parameters on a running plugin, e.g. {"rev_mode": "Cisterna", "rev_mix": 0.35}. Values are
    validated against the parameter table first. Changes are host-notified and undoable."""
    from . import plugin

    return json.dumps(plugin.call("set_params", instance, values=params.validate(values)))


@mcp.tool()
def plugin_play(pitch: int = 60, velocity: int = 100, duration_ms: int = 800, instance: str | None = None) -> str:
    """Play a note through the running plugin's output so the user hears it in their DAW."""
    from . import plugin

    return json.dumps(plugin.call("note", instance, pitch=int(pitch), velocity=int(velocity),
                                  duration_ms=int(duration_ms)))


@mcp.tool()
def plugin_status(text: str, instance: str | None = None) -> str:
    """Show a short status line in the plugin UI (e.g. "accordo i risonatori…")."""
    from . import plugin

    return json.dumps(plugin.call("status", instance, text=text[:160]))


@mcp.tool()
def plugin_reload(instance: str | None = None) -> str:
    """Reload the plugin's current sound from disk, keeping the player's parameter values (after a
    recompile). The plugin also does this by itself about a second after build/manifest.json changes."""
    from . import plugin

    return json.dumps(plugin.call("reload", instance))


@mcp.tool()
def plugin_reset(instance: str | None = None) -> str:
    """Put the running plugin's parameters back to the loaded sound's own defaults."""
    from . import plugin

    return json.dumps(plugin.call("reset", instance))


@mcp.tool()
def plugin_save_as(title: str, instance: str | None = None) -> str:
    """Save what the plugin is playing as a new sound in the library: a copy of the current sound (audio
    shared by hard links) titled `title`, with the current parameter values as its defaults. Loads it."""
    from . import plugin

    return json.dumps(plugin.call("save_as", instance, title=str(title)))


def main():
    mcp.run()


if __name__ == "__main__":
    main()
