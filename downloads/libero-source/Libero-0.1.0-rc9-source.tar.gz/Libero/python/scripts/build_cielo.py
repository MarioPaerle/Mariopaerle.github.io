"""Build installed Cielo from licensed professional vocal recordings.
Run acquisition, extraction, this builder, then build_cielo_verify.py.
"""
from pathlib import Path
import json, math, shutil, datetime, hashlib, itertools
import numpy as np
from scipy import signal
from libero import Audio,load,dsp
from libero.compiler import compile_sound
from libero import licenses
ROOT=Path.home()/'Libero/cache/research/cielo'
BANK=Path.home()/'Libero/banks/cielo'
RECS=json.loads((ROOT/'vocalset-notes.json').read_text())
CREDIT={'source':'VocalSet: A Singing Voice Dataset','license':'CC BY 4.0','license_class':'by','author':'Julia Wilkins, Prem Seetharaman, Alison Wahl, Bryan Pardo / Northwestern University','url':'https://zenodo.org/records/1442513','retrieved':'2026-10-02'}
SOURCE_DIR=ROOT/'ensemble-samples';SOURCE_DIR.mkdir(parents=True,exist_ok=True)


def figure(title,lo,hi,attack,room,voices,centroid=1500):
    # One choir loft: register maps its elevation, voice count its distinct columns,
    # attack maps rise of the arch, and room decay maps the nave length.
    n=max(3,min(9,voices));base=385-(lo-40)*1.4;top=100+(84-hi)*1.3
    cols=[]
    for i in range(n):
        x=96+i*320/(n-1);h=base-top-15*(i%2)
        cols.append(f'<path d="M{x-8:.1f},{base:.1f}V{base-h:.1f}Q{x:.1f},{base-h-9:.1f} {x+8:.1f},{base-h:.1f}V{base:.1f}" stroke="currentColor" stroke-width="1.2"/>')
        cols.extend(f'<path d="M{x+2:.1f},{y:.1f}l5,-3" stroke="currentColor" stroke-width="0.45"/>' for y in np.arange(base-h+12,base-5,5))
    arch=f'<path d="M65,{base:.1f}V{top+70:.1f}Q256,{top-50-attack*.1:.1f} 447,{top+70:.1f}V{base:.1f}" stroke="currentColor" stroke-width="1.3"/>'
    contour=''.join(f'<path d="M{65+j},{base:.1f}V{top+70+j*.4:.1f}Q256,{top-50+j*2:.1f} {447-j},{top+70+j*.4:.1f}" stroke="currentColor" stroke-width="0.45"/>' for j in range(4,28,4))
    floor=''.join(f'<path d="M{70+j*6},{base+j*6:.1f}H{442-j*6}" stroke="currentColor" stroke-width="0.45"/>' for j in range(1,int(5+room*3)))
    width=float(np.clip(110+centroid*.05,140,215))
    gold=f'<path d="M{256-width:.1f},{top+75:.1f}Q256,{top-30:.1f} {256+width:.1f},{top+75:.1f}" stroke="#b8924f" stroke-width="1.3"/>'
    desc=f'{n} separate columns represent independent recorded singers; MIDI register {lo}–{hi} sets the loft elevation. The arch rises over a {attack} ms entrance; {room:.1f} s live room decay extends its perspective. The width of the single gold vault follows the measured source spectral centroid ({centroid:.0f} Hz), the recorded vowel’s spectral colour.'
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>{desc}</desc>{arch}{contour}{floor}{"".join(cols)}{gold}</svg>'


def ensemble(gender,vowel,dynamic,root,take):
    recs=[r for r in RECS if r['vowel']==vowel and r['dynamic']==dynamic and (gender=='mixed' or r['gender']==gender)]
    singers=sorted({r['singer'] for r in recs})
    eligible=[]
    for singer in singers:
        available=[r for r in recs if r['singer']==singer]
        best=min(available,key=lambda r:abs(r['root']-root))
        if abs(best['root']-root)<=3:eligible.append(best)
    # Balance only genuinely eligible performers into two disjoint cohorts.
    selected=eligible[take::2]
    if len(selected)<2:return None
    buffers=[]
    for j,r in enumerate(selected):
        a=load(r['file'],sr=48000).pitch(root-r['root'])
        # Tiny natural entrance offsets, no repeated source and no artificial vibrato.
        x=a.data
        if x.ndim==2:x=x.mean(axis=1)
        offset=int((j%3)*.007*48000);x=np.pad(x,(offset,0))
        pan=-.55+1.1*j/max(1,len(selected)-1);angle=(pan+1)*math.pi/4
        buffers.append(np.stack([x*math.cos(angle),x*math.sin(angle)],axis=1))
    n=max(len(x) for x in buffers);out=np.zeros((n,2),np.float64)
    for x in buffers:out[:len(x)]+=x
    # One constant ensemble averaging gain preserves all source dynamics.
    out/=math.sqrt(len(buffers));a=Audio(out,48000).remove_dc().fade_in(.004).fade_out(.06)
    path=SOURCE_DIR/f'{gender}-{vowel}-{dynamic}-{root}-{take}.wav';a.save(path,subtype='PCM_24')
    return {'file':str(path),'root':root,'take':take,'singers':[r['singer'] for r in selected],'sources':[{k:r[k] for k in ['source','source_seconds','root','source_cents']} for r in selected],'peak_db':a.peak_db,'lufs':dsp.momentary_max(a.data,48000)}


def make_sound(slug,title,subtitle,regions,lo,hi,short=False,credit=CREDIT,limitations=''):
    folder=BANK/slug;folder.mkdir(parents=True,exist_ok=True);samples=folder/'samples';samples.mkdir(exist_ok=True)
    clean=[];provenance=[]
    for i,r in enumerate(regions):
        path=Path(r['file']);dst=samples/f'{i:03d}-{path.name}'
        dst.unlink(missing_ok=True)
        try:dst.hardlink_to(path)
        except OSError:shutil.copy2(path,dst)
        mapped={k:r[k] for k in ['root','take','dyn','articulation','gain_db'] if k in r};mapped['file']=dst.name
        mapped['lo']=lo;mapped['hi']=hi
        clean.append(mapped);provenance.append({**r,'installed_file':dst.name})
    # Each key retains a nearest source zone; limits are explicit, never all 88 keys.
    # lo/hi are populated by per-articulation nearest-root planning below.
    for articulation, group in itertools.groupby(sorted(clean,key=lambda r:(r.get('articulation',''),r['root'])),key=lambda r:r.get('articulation','')):
        group=list(group);roots=sorted({r['root'] for r in group})
        for r in group:
            idx=roots.index(r['root']);r['lo']=lo if idx==0 else (roots[idx-1]+r['root'])//2+1;r['hi']=hi if idx==len(roots)-1 else (r['root']+roots[idx+1])//2
    (samples/'map.json').write_text(json.dumps(clean,indent=2));(samples/'provenance.json').write_text(json.dumps(provenance,indent=2))
    licenses.add_credit(folder,credit);(samples/'ATTRIBUTION.md').write_text(licenses.attribution_text([credit]))
    arts=sorted({r.get('articulation') for r in clean if r.get('articulation')})
    roots=sorted({r['root'] for r in clean});attack=0 if short else 12;release=90 if short else 240;room=1.4 if short else 2.4
    recipe=f'''from libero import Sound\nimport json\nfrom pathlib import Path\nsound=Sound({title!r},subtitle={subtitle!r},tags=['voice','choir','voce','coro','campionato','cielo'],roots={roots!r},seed=2718)\nregions=json.loads((Path(__file__).parent/'samples/map.json').read_text())\nsound.multisample('body',regions,process={{'pre_ms':2,'align_ms':5,'tune':'source','ladder':'keep','peak_db':-15,'max_seconds':None,'end_db':-65,'fade_ms':45,'loop':'none','encoding':'flac24','edge_fill':False}},as_dyn=True)\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=2000)\n'''
    if len(arts)==1 or not arts:recipe+="sound.articulations([{'id':'natural','name':'Vocale','key':24}])\n"
    if len(arts)>1:recipe+="sound.articulations([{'id':'sustain','name':'Vocale','key':24},{'id':'swell','name':'Crescendo','key':25}])\n"
    recipe+=f"sound.defaults(mode='Poli',glide=0,voices=24,dyn_mode='Velocità',amp_attack={attack},amp_decay=6000,amp_sustain=1,amp_release={release},vel_sens=0.16,lvl_body=0,lvl_tail=-60,lvl_air=-60,drive=0,tape_wow=0,tape_flutter=0,tape_sat=0,tape_age=0,tape_mix=0,osc1_level=-60,osc2_level=-60,sub_level=-60,lfo_pitch=0,lfo_amp=0,res_mix=0,echo_mix=0,flt_cutoff=20000,rev_mode='Cappella',rev_mix={.10 if short else .17},rev_size=.55,rev_decay={room},rev_predelay=16,rev_damp=.48,master=0,humanize=0)\n"
    (folder/'sound.py').write_text(recipe)
    (folder/'figure.svg').write_text(figure(title,lo,hi,attack,room,max(len(r.get('singers',[])) for r in regions) or 3))
    notes=f'''# {title}\n\nVoci reali per accordi e melodie, con vocali naturali e una stanza di cappella. Le note seguono il registro dei cantanti disponibili.\n\nSource: {credit['source']}, {credit['license']}, {credit['url']}.\n{limitations}\n\nRange MIDI {lo}–{hi}; {len(clean)} recorded ensemble zones; one independent sample per zone and dynamics. No loops, no synthetic body, no pitch wobble. Pitch-segmented source long tones retain natural vocal bodies, vibrato and available room release; independently recorded performers were assembled into two disjoint cohorts, rather than cloning one voice. Recorded pp, straight, forte and messa long-tone sessions are retained in the adult sustain/crescendo patches. Membership changes with native register; low mixed notes use the available men, upper notes the available women. Each source dynamic uses its own real recordings, with level calibration where their independently recorded session gains inverted the playable ladder. Dynamics switch at note-on to avoid combing between independent recordings. Natural recorded notes are retuned by constant resampling and mapped at most three semitones; a live chapel supplies the room.\n\nProvenance with individual singers, original source filenames and extraction intervals: samples/provenance.json. Individual source recordings remain in cache; the installed source ensemble samples make this recipe self-contained.\n\nMeasurement, lint, RAM and renderer checks are appended by build_cielo_verify.py. I cannot hear the output; these are numerical and visual checks, not a listening or hyperrealism certification.\n'''
    if slug=='voci-bianche-sillabe':notes=notes.replace('Voci reali per accordi e melodie, con vocali naturali e una stanza di cappella. Le note seguono il registro dei cantanti disponibili.','Un coro di bambini veri ripreso in chiesa: brevi sillabe cantate, ambiente vivo e un triangolo distante. Una texture per piccole frasi nel suo registro naturale.')
    (folder/'notes.md').write_text(notes)
    res=compile_sound(folder,jobs=2);print(slug,res.text() if res.ok else res.error,flush=True)
    if not res.ok:raise RuntimeError(slug)
    from build_cielo_verify import calibrate
    calibrate(folder)
    return folder


def adult_sounds():
    for gender,label in [('female','Donne'),('male','Uomini'),('mixed','Coro epico')]:
        for vowel,name in [('a','Ah'),('e','Eh'),('o','Oh')]:
            rootsrange=range(48 if gender in ('male','mixed') else 60,76 if gender=='male' else 85,3)
            data={}
            for root in rootsrange:
                recordings={}
                for dynamic in ['pp','straight','forte','messa']:
                    recordings[dynamic]=[ensemble(gender,vowel,dynamic,root,take) for take in [0,1]]
                # Two authentic singers per take and all three natural dynamics required.
                if all(all(recordings[d]) for d in ['pp','straight','forte','messa']):data[root]=recordings
            if not data:raise RuntimeError(f'no common range {gender}/{vowel}')
            regs=[]
            # Preserve natural relative levels, with one global correction per recorded
            # dynamic to account for independent session gains (never per sample normalization).
            lv={d:np.median([r['lufs'] for x in data.values() for r in x[d]]) for d in ['pp','straight','forte','messa']}
            wanted={'pp':-29,'straight':-23,'forte':-18,'messa':-23}
            gains={d:float(wanted[d]-lv[d]) for d in lv}
            for root,rec in data.items():
                for d in ['pp','straight','forte','messa']:
                    for r in rec[d]:
                        r={**r,'articulation':'swell' if d=='messa' else 'sustain','gain_db':gains[d]}
                        r['dyn']={'pp':[0,.4],'straight':[.4,.73],'forte':[.73,1],'messa':[0,1]}[d];regs.append(r)
            folder=make_sound(f'{gender}-{vowel}',f'{label} · {name}','vocale reale · tre dinamiche e crescendo',regs,min(data),max(data),limitations='Vowels follow VocalSet filename labels a/e/o. “Eh” means the recorded e vowel, whose exact Italian open/closed pronunciation has not been independently confirmed. This is an ensemble of separate real performers, not a simultaneously recorded room choir. No claim of commercial-library realism is made.')
    # Short articulation uses actual voice samples with a shorter playable envelope.
    for gender,label in [('female','Donne'),('male','Uomini')]:
        regs=[]
        source=BANK/f'{gender}-a';prov=json.loads((source/'samples/provenance.json').read_text())
        for r in prov:
            if r['articulation']!='sustain':continue
            a=load(r['file']);a=a.trim(0,min(a.duration,.55)).fade_out(.11)
            f=SOURCE_DIR/f'breve-{Path(r["file"]).name}';a.save(f,subtype='PCM_24');r={**r,'file':str(f)};r.pop('articulation',None);regs.append(r)
        make_sound(f'{gender}-ah-breve',f'{label} · Ah breve','vocale registrata · inviluppo corto',regs,min(r['root'] for r in regs),max(r['root'] for r in regs),short=True,limitations='Short articulation is cut from separately recorded natural vowel notes; it is not claimed as an original staccato session. 550 ms maximum sample with 110 ms tail taper; no synthetic vowel.')


def children():
    a=load(ROOT/'children.mp3',sr=48000);sr=a.sr;recs=[]
    # Natural phrase fragments: voiced 600ms windows. They retain the room and
    # Finnish syllables; triangle accompaniment is not falsely called studio dry.
    for t in np.arange(.8,a.duration-.85,.8):
        seg=a.trim(float(t),float(t+.65));f=seg.f0(fmin=220,fmax=560)
        if not np.isfinite(f):continue
        n=dsp.freq_to_midi(f);root=round(n)
        if not 60<=root<=72:continue
        # Keep notes stable over two halves; avoid musical transitions and octave errors.
        fl=seg.trim(.05,.29).f0(fmin=f*.90,fmax=f*1.1);fr=seg.trim(.32,.59).f0(fmin=f*.90,fmax=f*1.1)
        if not np.isfinite(fl+fr) or abs(1200*math.log2(fl/fr))>60:continue
        seg=seg.pitch(root-n).remove_dc().fade_in(.016).fade_out(.08)
        path=SOURCE_DIR/f'children-{t:.1f}-{root}.wav';seg.save(path,subtype='PCM_24');recs.append({'file':str(path),'root':root,'source_seconds':[round(float(t),2),round(float(t+.65),2)],'source_cents':round((n-root)*100,2),'singers':[]})
    # Natural independent fragments remain takes; their distinct sung words are not
    # mislabelled dynamics or pure vowels. At most 16 engine takes per root.
    regs=[]
    for root in sorted({r['root'] for r in recs}):
        rr=[r for r in recs if r['root']==root]
        for i,r in enumerate(rr[:16]):regs.append({**r,'take':i})
    credit={'source':'children_singing.wav (public HQ MP3 edition)','license':'CC0 1.0','license_class':'cc0','author':'isohoo','url':'https://freesound.org/people/isohoo/sounds/512975/','retrieved':'2026-10-02'}
    make_sound('voci-bianche-sillabe','Voci bianche · sillabe','bambini veri in chiesa · frammenti',regs,min(r['root'] for r in regs),max(r['root'] for r in regs),short=True,credit=credit,limitations='Real children’s choir, recorded in Finland in 2017 on Zoom H2 singing Twinkle Twinkle Little Star in Finnish with triangle accompaniment. Source is the public high-quality MP3 preview (88 seconds), not the 134-second lossless original. Limited field-recording syllable texture: room noise, actual sung syllables and distant triangle remain. This is not a clean unison vowel multisample, and it cannot honestly satisfy a hyperrealistic studio children choir requirement. There is one recorded dynamic; different real syllables are independent takes, not artificial velocity layers.')

if __name__=='__main__':
    if BANK.exists() and any(BANK.iterdir()):
        backup=Path.home()/'Libero-backups/2026-10-02'/('cielo-'+datetime.datetime.now().strftime('%H%M%S'));backup.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(BANK,backup);print('backup',backup,flush=True)
    BANK.mkdir(parents=True,exist_ok=True)
    adult_sounds();children()
    now=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    credits=sum([licenses.read_credits(d) for d in BANK.iterdir() if d.is_dir()],[])
    meta={'format':'libero.bank/1','slug':'cielo','title':'Cielo','subtitle':'vocali campionate · cori di voci reali','description':'Voci professionali reali VocalSet: donne, uomini e cori misti assemblati, Ah/Eh/Oh, tre dinamiche, crescendo e note brevi. Voci bianche autentiche da frammenti di coro in chiesa, con i limiti della registrazione sul campo dichiarati.','version':'1.0.0','author':'Mario Prignano','license':licenses.bundle_license(credits)[0],'created':now,'updated':now,'figure':'figure.svg'}
    (BANK/'bank.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False)+'\n');(BANK/'figure.svg').write_text(figure('Cielo',48,84,12,2.4,9))
    (BANK/'SOURCE-SEARCH.md').write_text('''# Source audit\n\nSelected core: VocalSet CC BY 4.0, https://zenodo.org/records/1442513. Pinned mirror permits selective acquisition; checksum of primary original archive is md5:0c09396242f946e7111ad7d8fc649b81. Exact singers follow folders (female1–9; male1–11), which disagree with the numerical counts in the record prose. All selected long-tone dynamics pp/straight/forte/messa and every selected singer are retained. Sources a/e/o are actual recorded vowel labels; no synthesis, adult-to-child transformation or wow/flutter.\n\nChildren: isohoo 512975 CC0 real choir; public HQ MP3 source, field snippets. Supported honest texture only, not a studio choir replacement.\n\nAlternatives investigated, not included: Signature Sounds actual children CC0 requires a free checkout email, so no email was submitted. Pianobook Women 4 syllables Choir is exact female ah/éh/oh/mmh but account-gated. Mihai Sorohan real mixed vowel choir acquired for inspection but private nontransferable sample terms; superseded by shippable VocalSet. FreePats choir pad is explicitly ZynAddSubFX synthesis, excluded. Freesound Katarina Rose actual female ah/staccato preview declares possible stream artifacts, excluded from core in favour of lossless VocalSet. KBH Real Choir has conflicting unattributed/public-domain/CC-BY/CC-NC metadata across mirrors; excluded.\n''')
