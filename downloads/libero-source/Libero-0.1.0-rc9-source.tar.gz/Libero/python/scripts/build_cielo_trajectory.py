"""Audit complete extracted single-singer note trajectories, independently of head lint."""
from pathlib import Path
import json,concurrent.futures
import numpy as np
from libero import load,dsp
ROOT=Path.home()/'Libero/cache/research/cielo'

def audit(r):
    a=load(r['file']);x=dsp.resample_to(dsp.mono(a.data),a.sr,12000)
    t,f,aper,rms=dsp.yin(x,12000,fmin=60,fmax=1500,frame=1024,hop=120,threshold=.05)
    ok=np.isfinite(f)&(aper<.22)&(rms>rms.max()*.08)&(t>.15)&(t<a.duration-.15)
    centers=[]
    for start in np.arange(.15,max(.16,a.duration-.15),.5):
        sel=ok&(t>=start)&(t<start+.5)
        if sel.sum()>=10:centers.append((float(start),float(np.median(69+12*np.log2(f[sel]/440)))))
    span=100*(max(n for _,n in centers)-min(n for _,n in centers)) if len(centers)>1 else 0
    shifted=[100*(n-r['root']-12*round((n-r['root'])/12)) for _,n in centers]
    pitch_span=max(shifted)-min(shifted) if shifted else 0
    return {'source':r['source'],'file':r['file'],'root':r['root'],'seconds':r['seconds'],'voiced_window_midi':centers,'median_span_cents':round(span,1),'register_jump':pitch_span>200,'pitch_class_span_cents':round(pitch_span,1),'raw_octave_ambiguity':span>200 and pitch_span<=200}
if __name__=='__main__':
    recs=json.loads((ROOT/'vocalset-notes.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:audits=list(ex.map(audit,recs))
    bad=[r for r in audits if r['register_jump']]
    report={'method':'Full-note voiced YIN, broad60–1500Hz threshold0.05; medians in0.5s windows, excluding150ms at each edge. Raw octave changes are separately retained and were reviewed in spectrograms; pitch-class trajectory spread >200c flags non-octave register transitions. Pitch-aware source segmentation independently separates register octaves. Three visually confirmed extraneous attack/end intervals were trimmed in extraction.','notes':len(audits),'register_jumps':bad,'raw_octave_ambiguities':[r for r in audits if r['raw_octave_ambiguity']],'audits':audits}
    (ROOT/'note-trajectories.json').write_text(json.dumps(report,indent=2));print('notes',len(audits),'register jumps',len(bad),flush=True)
    for r in bad:print(r['source'],r['seconds'],r['median_span_cents'],r['voiced_window_midi'],flush=True)
