"""Full-length native lower/middle/upper ensemble holds, beyond head-window lint."""
from pathlib import Path
import json,concurrent.futures
import numpy as np
from libero import load,dsp
BANK=Path.home()/'Libero/banks/cielo'

def audit(item):
    folder,z=item;a=load(folder/'build'/z['file']);x=dsp.resample_to(dsp.mono(a.data),a.sr,12000)
    t,f,aper,rms=dsp.yin(x,12000,fmin=60,fmax=1500,frame=1024,hop=120,threshold=.05)
    ok=np.isfinite(f)&(aper<.26)&(rms>rms.max()*.12)&(t>.25)&(t<a.duration-.2)
    med=[]
    for start in np.arange(.25,max(.26,a.duration-.2),.5):
        sel=ok&(t>=start)&(t<start+.5)
        if sel.sum()>=12:med.append([round(float(start),2),round(float(np.median(69+12*np.log2(f[sel]/440)))+z.get('tune_cents',0)/100,3)])
    centered=[100*(n-z['root']-12*round((n-z['root'])/12)) for _,n in med];span=max(centered)-min(centered) if centered else 0
    rawspan=100*(max(n for _,n in med)-min(n for _,n in med)) if med else 0
    return {'preset':folder.name,'file':z['file'],'root':z['root'],'seconds':round(a.duration,2),'median_window_midi':med,'pitch_class_span_cents':round(span,1),'raw_median_span_cents':round(rawspan,1),'confirmed_non_octave_jump':span>200,'tracker_octave_ambiguity':rawspan>200 and span<=200}

if __name__=='__main__':
    items=[]
    for f in sorted(x for x in BANK.iterdir() if (x/'sound.py').exists() and x.name.startswith(('female-','male-','mixed-')) and 'breve' not in x.name):
        m=json.loads((f/'build/manifest.json').read_text());roots=sorted({z['root'] for z in m['zones']});wanted={roots[0],roots[len(roots)//2],roots[-1]}
        for z in m['zones']:
            if z['root'] in wanted and z.get('take',0)==0 and z.get('dyn',[0,1])[1]==1:items.append((f,z))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:results=list(ex.map(audit,items))
    report={'method':'Complete native lower/mid/upper, top dynamics plus crescendo take0; broad60–1500Hz YIN threshold.05,0.5s medians, excluded250ms onset/200ms release. Raw octave errors are retained separately; source segmentation and spectra distinguish real register changes.','holds':len(results),'confirmed_non_octave_jumps':[r for r in results if r['confirmed_non_octave_jump']],'audits':results}
    source_root=Path.home()/'Libero/cache/research/cielo'
    source=json.loads((source_root/'note-trajectories.json').read_text())
    primary=json.loads((source_root/'mirror-primary-validation.json').read_text()) if (source_root/'mirror-primary-validation.json').exists() else {'verified_files':None}
    summary={'source_notes':source['notes'],'source_files':240,'source_file_primary_sha256_matches':primary['verified_files'],'source_note_confirmed_register_jumps':len(source['register_jumps']),'source_detector_octave_ambiguities':len(source['raw_octave_ambiguities']),'ambiguities_visually_reviewed':True,'three_transition_interval_repairs':'male3 messa-a/pp-a attacks; male7 straight-e contiguous higher-note ending','compiled_native_holds':len(results),'compiled_hold_register_jumps':len(report['confirmed_non_octave_jumps']),'compiled_hold_detector_octave_ambiguities':sum(r['tracker_octave_ambiguity'] for r in results)}
    (BANK/'source-validation.json').write_text(json.dumps(summary,indent=2))
    (BANK/'hold-trajectories.json').write_text(json.dumps(report,indent=2));print('holds',len(results),'confirmedjumps',len(report['confirmed_non_octave_jumps']),'octaveambiguous',sum(r['tracker_octave_ambiguity'] for r in results),flush=True)
    for r in report['confirmed_non_octave_jumps']:print(r,flush=True)
