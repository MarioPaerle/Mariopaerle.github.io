"""Four new tape-keyboard interpretations from cleared acoustic performances.

These are not recordings of a historical Mellotron or copies of its tape masters.
Only this script's four Giove folders are written; original libraries are read-only.
"""
from pathlib import Path
import argparse, hashlib, json, math, shutil, sys
import numpy as np
import soundfile as sf
from scipy import signal
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, library, render
from libero.compiler import compile_sound
from libero.dsp import estimate_f0, momentary_max
from libero.ingest.sfz import parse_sfz
from libero.lint import lint_bundle
from libero.figure import validate_svg
H=Path.home()/'Libero';CACHE=H/'cache/libraries';BANK=H/'banks/giove';OUT=H/'demo/giove-v1/tapes';SR=48000
SQUID_ROOTS=H/'cache/research/giove/squid-source-roots.json'
DESIGNS={
 'nastri-flauto':dict(title='Nastri di Flauto',subtitle='fiato vero · tastiera a nastro reinterpretata',keys=(60,84),families=[('vsco2-ce/FluteSusVib.sfz',1)],cutoff=5600,attack=18,release=360),
 'nastri-archi':dict(title='Nastri di Corde',subtitle='violini e viole indipendenti · corpo a nastro',keys=(55,84),families=[('vsco2-ce/ViolinEnsSusVib.sfz',.78),('vsco2-ce/ViolaEnsSusVib.sfz',.65)],cutoff=4900,attack=55,release=510),
 'nastri-ottoni':dict(title='Nastri di Ottone',subtitle='tromba, corno e trombone · registro orchestrale a nastro',keys=(48,77),families=[('vsco2-ce/TrumpetSus.sfz',.5),('vsco2-ce/FHornSus.sfz',.8),('vsco2-ce/TromboneSus.sfz',.65)],cutoff=4700,attack=28,release=330),
 'nastri-ance':dict(title='Nastri di Ance',subtitle='Squidpipes registrate · ance polifoniche a nastro',keys=(43,77),families=[('karoryfer-squidpipes/Programs/mappings/long_clean.sfz',1)],cutoff=4300,attack=12,release=300),
}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def source_register(p,d):
 rows=[]
 for family,_,_ in sources(d):
  base=CACHE/family.split('/')[0];mapping=CACHE/family
  evidence=[]
  for src in [mapping,base/'LICENSE',base/'readme.md']:
   if src.exists():
    dest=p/'samples/source-documents'/family.split('/')[0]/src.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
    evidence.append({'source_path':str(src),'source_sha256':sha(src),'included':dest.relative_to(p/'samples').as_posix(),'included_sha256':sha(dest)})
  rows.append({'family':family,'documents':evidence,'primary_grant_url':'https://shop.karoryfer.com/pages/free-samples' if family.startswith('karoryfer') else 'https://github.com/sgossner/VSCO-2-CE/blob/SFZ/LICENSE','historical_mellotron_recording':False})
  if family.startswith('karoryfer-squidpipes/'):
   dest=p/'samples/source-documents/karoryfer-squidpipes/physical-source-roots.json'
   shutil.copyfile(SQUID_ROOTS,dest)
   rows[-1]['physical_root_calibration']={'included':dest.relative_to(p/'samples').as_posix(),'sha256':sha(dest),'ambiguous_sources_excluded':['g4_long_clean.wav']}
 dump(p/'samples/source-register.json',rows)
def balance_recorded_layers(p,proof):
 """Correct recording capture inversions with a constant attenuation only."""
 keys=sorted({q['key'] for q in proof})
 for key in keys:
  cell=sorted([q for q in proof if q['key']==key],key=lambda q:q['velocity'][0])
  if len(cell)!=2:continue
  levels=[]
  for q in cell:
   x,sr=sf.read(p/'samples'/q['file'],always_2d=True);levels.append(momentary_max(x[:round(1.5*sr)],sr))
  gap=levels[1]-levels[0]
  if gap<2:
   delta=gap-4;dest=p/'samples'/cell[0]['file'];x,sr=sf.read(dest,always_2d=True);sf.write(dest,x*10**(delta/20),sr,subtype='PCM_24')
   cell[0]['recorded_layer_capture_balance_db']=cell[0].get('recorded_layer_capture_balance_db',0)+delta
   cell[0]['capture_balance_measurement']={'soft_lufs_before':levels[0],'loud_lufs':levels[1],'window_seconds':1.5,'additional_attenuation_db':delta,'target_gap_db':4,'method':'constant gain, preserving original performed envelope and spectrum'}
   cell[0]['sha256']=sha(dest)
def center(x,key):
 f=440*2**((key-69)/12)
 hz,v=estimate_f0(x,SR,f*.8,f*1.2)
 if not np.isfinite(hz) or v<.5:raise ValueError(f'Unvoiced source at key {key}: {hz}/{v}')
 return 1200*math.log2(hz/f),v
def loop(x):
 """Same-performance continuation, preserving entry and several human cycles."""
 a=Audio(x,SR);end=min(a.duration-.12,4.8)
 p=a.loop_points(min_seconds=.85,region=(.4,end),window=.03,max_crossfade=.2)
 if p is None:p=a.loop_points(min_seconds=.45,region=(.25,end),window=.025,max_crossfade=.16)
 if p is None:raise ValueError(f'No performed sustain loop in {a.duration:.3f}s source')
 y=x.copy();xf=min(round(.18*SR),p.start,(p.end-p.start)//3);exact=min(round(.02*SR),xf//3)
 n=xf-exact
 if n>1:
  w=np.linspace(0,1,n);w=w*w*(3-2*w)
  y[p.end-xf:p.end-exact]=(1-w[:,None])*x[p.end-xf:p.end-exact]+w[:,None]*x[p.start-xf:p.start-exact]
 y[p.end-exact:p.end]=x[p.start-exact:p.start]
 return y[:p.end],{'start':p.start,'end':p.end},dict(seconds=(p.end-p.start)/SR,source_seconds=len(x)/SR,crossfade_ms=xf/SR*1000,exact_overlap_ms=exact/SR*1000,selection_error_db=p.error_db)
def sources(d):
 out=[]
 for name,gain in d['families']:
  inst=parse_sfz(CACHE/name)
  physical={r['source_file']:r for r in json.loads(SQUID_ROOTS.read_text())['records']} if name.startswith('karoryfer-squidpipes/') else {}
  verified=[]
  for r in inst.regions:
   if not r.sample.exists() and name.startswith('karoryfer-squidpipes/'):
    r.sample=CACHE/'karoryfer-squidpipes/Samples'/r.sample.parent.name/r.sample.name
   assert r.sample.exists(),r.sample
   if physical:
    evidence=physical.get(r.sample.name)
    # Only individually audited performances are eligible. The full source SFZ
    # also contains upper samples outside the audit/playable range.
    if evidence is None:continue
    assert evidence['source_sha256']==sha(r.sample),r.sample
    if evidence['status']!='supported' or evidence['recommended_physical_root'] is None:continue
    r.sfz_original_root=r.root
    r.physical_root_evidence=evidence
    r.root=evidence['recommended_physical_root']
   verified.append(r)
  assert verified,name
  out.append((name,gain,verified))
 return out
def figure(title,lanes):
 parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>Due bobine e {lanes} percorsi indipendenti: il corpo registrato entra nella tastiera a nastro. La linea continua indica il sostegno fino al rilascio.</desc>']
 for cx in (147,365):
  parts.append(f'<circle cx="{cx}" cy="164" r="72" stroke-width="1.4"/><circle cx="{cx}" cy="164" r="16" stroke-width=".8"/>')
  for a in range(0,360,45):
   r=math.radians(a);parts.append(f'<circle cx="{cx+44*math.cos(r):.2f}" cy="{164+44*math.sin(r):.2f}" r="11" stroke-width=".6"/>')
 for i in range(lanes):
  y=262+i*20;parts.append(f'<path d="M75 164 C28 270 98 {y} 147 {y} H365 C414 {y} 477 270 437 164" stroke="'+('#b8924f' if i==0 else 'currentColor')+'" stroke-width="1.1"/>')
 parts.append('<path d="M76 340 H438 V400 H76 Z" stroke-width="1.3"/>')
 for x in range(86,435,12):parts.append(f'<path d="M{x} 340 V400" stroke-width=".6"/>')
 for x in range(88,430,24):parts.append(f'<path d="M{x} 355 l6 -10 m-6 22 l6 -10 m-6 22 l6 -10" stroke-width=".4"/>')
 parts.append('</svg>');s=''.join(parts);assert not validate_svg(s);return s
def build(slug):
 d=DESIGNS[slug];p=BANK/slug;s=p/'samples';s.mkdir(parents=True,exist_ok=True);rows=[];proof=[];srcs=sources(d)
 # Real soft/loud recordings exist for the string ensemble. Other families have
 # one recorded dynamic; velocity controls the live envelope, not fake takes.
 dynamics=[(1,63,45),(64,127,100)] if slug=='nastri-archi' else [(1,127,100)]
 cache={}
 for key in range(d['keys'][0],d['keys'][1]+1):
  for vlo,vhi,vel in dynamics:
   lanes=[];laneproof=[]
   for family,gain,rr in srcs:
    possible=[r for r in rr if r.lovel<=vel<=r.hivel] or rr
    r=min(possible,key=lambda r:(abs(r.root-key),r.seq_position,r.sample.name))
    uid=(str(r.sample),r.root)
    if uid not in cache:
     a=Audio.load(r.sample,sr=SR);x=a.data
     if x.ndim==1:x=x[:,None]
     if x.shape[1]==1:x=np.repeat(x,2,axis=1)
     stable=x[round(.3*SR):min(len(x),round(2*SR))]
     c,v=center(stable,r.root)
     if abs(c)>90:raise ValueError(f'Source root discrepancy {r.sample}: {c:.1f}c')
     cache[uid]=(x,c,v)
    x,c,v=cache[uid]
    # Fixed varispeed correction keeps the recorded vibrato and pressure motion.
    a=Audio(x,SR).pitch(key-r.root-c/100);x=a.data
    y,lp,lq=loop(x)
    pc,pv=center(y[lp['start']:lp['end']],key)
    # Centre the actual retained loop, not a different portion of the original.
    if abs(pc)>1:
     y=Audio(y,SR).pitch(-pc/100).data
     scale=2**(pc/1200);lp={k:round(vv*scale) for k,vv in lp.items()};lp['end']=min(lp['end'],len(y))
    post,pvoiced=center(y[lp['start']:lp['end']],key)
    raw=s/'originals'/family.split('/')[0]/r.sample.parent.name/r.sample.name;raw.parent.mkdir(parents=True,exist_ok=True)
    if not raw.exists():shutil.copyfile(r.sample,raw)
    assert sha(raw)==sha(r.sample)
    lanes.append((y,lp,gain*10**(r.gain_db/20)));laneproof.append(dict(source=str(r.sample),source_sha256=sha(r.sample),included=raw.relative_to(s).as_posix(),included_sha256=sha(raw),source_root=r.root,played_root=key,source_velocity=[r.lovel,r.hivel],source_take=r.seq_position-1,source_mapping_gain_db=r.gain_db,source_center_cents=c,source_voiced=v,transposition_semitones=key-r.root-c/100,retained_loop_before_cents=pc,retained_loop_after_cents=post,loop_correction_cents=-pc if abs(pc)>1 else 0,retained_loop_voiced=pvoiced,continuation=lq))
    if hasattr(r,'sfz_original_root'):
     laneproof[-1].update(original_sfz_root=r.sfz_original_root,physical_root=r.root,physical_root_evidence=r.physical_root_evidence,root_calibration_sha256=sha(SQUID_ROOTS))
   # Independent performances share one newly arranged unison. Each lane is
   # extended from its own loop, avoiding periodic collapse to one tiny cycle.
   n=round(10*SR);out=np.zeros((n,2))
   for x,lp,gain in lanes:
    ids=np.arange(n);ids=np.where(ids<len(x),ids,lp['start']+(ids-len(x))%(lp['end']-lp['start']))
    out+=x[ids]*gain
   # Honour the source SFZ's recording-level compensation; normalise only by
   # fixed arrangement weights, not those per-recording gains. A shared -30 dB
   # encoding margin is restored by the compiler's whole-instrument gain.
   out*=10**(-30/20)/math.sqrt(sum(g*g for _,g,_ in srcs))
   balance_db=-6 if slug=='nastri-archi' and vel==45 else 0
   out*=10**(balance_db/20)
   # A modest tape playback bandwidth, without delayed dry/wet modulation.
   out=signal.sosfilt(signal.butter(2,d['cutoff'],fs=SR,output='sos'),out,axis=0)
   out,lp,lq=loop(out)
   if not np.isfinite(out).all() or np.max(np.abs(out))>=.99:raise ValueError(f'Pre-encoding headroom exceeded: {slug}/{key}/{vel}')
   filename=f'key-{key}-v{vel}.flac';dest=s/'tapes'/filename;dest.parent.mkdir(parents=True,exist_ok=True);sf.write(dest,out,SR,subtype='PCM_24')
   row=dict(file=dest.relative_to(s).as_posix(),root=key,lo=key,hi=key,vel=[vlo,vhi],take=0,tune_cents=0,articulation='continuo',loop=lp)
   rows.append(row)
   proof.append(dict(file=row['file'],sha256=sha(dest),key=key,velocity=[vlo,vhi],sources=laneproof,recorded_layer_capture_balance_db=balance_db,arranged_body_loop=lq,processing=f'Independent performed unison; SFZ capture compensation preserved, soft string layer balanced uniformly -6 dB; second-order {d["cutoff"]} Hz playback bandwidth. No historical Mellotron tape or delayed effect signal.'))
 balance_recorded_layers(p,proof)
 dump(s/'map.json',rows);dump(s/'source-proof.json',proof);source_register(p,d)
 credits=[]
 for family,_,_ in srcs:
  kar=family.startswith('karoryfer')
  author='Karoryfer Lecolds / D. Smolken' if kar else 'Sam Gossner and Simon Dalzell / Versilian Studios; sample editing Elan Hickler'
  url='https://shop.karoryfer.com/pages/free-squidpipes' if kar else 'https://github.com/sgossner/VSCO-2-CE'
  credits.append(dict(source='Squidpipes' if kar else 'VSCO 2 Community Edition',author=author,license='CC0 1.0',license_class='cc0',url=url,files=sorted({z['included'] for q in proof for z in q['sources'] if family.split('/')[0] in z['included']}),notes='Independent acoustic performances transposed, statically centred, arranged and looped for a new tape-keyboard interpretation. Not sampled from a Mellotron.'))
  licence=CACHE/family.split('/')[0]/'LICENSE';target=s/'licenses'/family.split('/')[0]/'LICENSE';target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(licence,target)
 dump(s/'credits.json',credits)
 defaults=dict(mode='Poli',glide=0,voices=16,amp_attack=d['attack'],amp_decay=10000,amp_sustain=1,amp_release=d['release'],master=-9,lvl_body=0,lvl_tail=-60,lvl_air=-60,lvl_attack=-60,vel_sens=.5,flt_cutoff=16000,flt_env=0,rev_mix=.025,rev_mode='Cappella',rev_size=.23,rev_decay=.8,width=1,tape_mix=0,tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,caldi_mode='Spento')
 p.joinpath('sound.py').write_text('import json\nfrom pathlib import Path\nfrom libero import Sound\nsound=Sound(title='+repr(d['title'])+',subtitle='+repr(d['subtitle'])+',tags=["giove","sampled","tape-keyboard","cc0"],roots='+repr(list(range(d['keys'][0],d['keys'][1]+1)))+',sample_rate=48000,accent="#a1743b")\nsound.articulations([{"id":"continuo","name":"Continuo"}])\nsound.multisample("body",json.loads((Path(__file__).parent/"samples/map.json").read_text()),process={"tune":"source","ladder":"keep","peak_db":-10,"align_ms":0,"pre_ms":0,"fade_ms":0,"loop":"source","end_db":-100,"max_seconds":None,"preserve_key_ranges":True,"edge_fill":False,"encoding":"flac24"})\nsound.performance(dynamics_source="velocity",dyn_crossfade=0,rr_reset_ms=1500,humanize={"cents":0,"ms":0,"db":0},onset_ms=0)\nsound.defaults(**'+repr(defaults)+')\n')
 p.joinpath('figure.svg').write_text(figure(d['title'],len(srcs)))
 p.joinpath('notes.md').write_text(f'# {d["title"]}\n\nGiove · melody/chords · REC/HYB · {d["subtitle"]}.\n\nNew tape-keyboard interpretation from independent cleared acoustic performances. This is not a recording of a historical Mellotron and contains no Mellotron tape masters. Each lane retains its physical entry, pressure and vibrato; only fixed pitch offsets are corrected. Independent sources are summed in unison when specified, without cloned delayed singers/players. The loop is a designed continuation of the recorded body, not a naturally endless performance. Default holds until release; every playable key has an explicit loop.\n\nSource provenance, exact hashes, recorded velocity/take labels and before/after retained-loop tuning are in samples/source-proof.json. '+('Two actual recorded soft/loud layers. Source SFZ capture compensation is preserved; the soft ensemble receives a uniform -6 dB capture balance to retain a rising performance ladder.' if len(dynamics)==2 else 'One recorded dynamic per source; velocity changes live amplitude. No artificial recorded layer or RR is claimed.')+' No wow/flutter, chorus or baked stereo widening. CC0 source notices are retained in samples/licenses and credits. Technical validation and equal-level preview do not certify realism or listener preference.\n')
 c=compile_sound(p,jobs=2);print(slug,c.text(),flush=True)
 if c.error:raise RuntimeError(c.error)
 return p
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--slugs',nargs='*',choices=DESIGNS,default=list(DESIGNS));ap.add_argument('--source-documents-only',action='store_true');ap.add_argument('--balance-existing',action='store_true');args=ap.parse_args()
 for slug in args.slugs:
  if args.source_documents_only or args.balance_existing:
   p=BANK/slug
   if args.balance_existing:
    proof=json.loads((p/'samples/source-proof.json').read_text());balance_recorded_layers(p,proof);dump(p/'samples/source-proof.json',proof)
   else:source_register(p,DESIGNS[slug])
   result=compile_sound(p,jobs=2)
   if result.error:raise RuntimeError(result.error)
   print(slug,'source documents updated and compiled',flush=True)
  else:build(slug)
if __name__=='__main__':main()
