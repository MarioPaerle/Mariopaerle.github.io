"""Fetch checked CC0 acoustic/electric sources and author-published CC BY3 slap ZIP.
No checkout, account registration, purchases or email; original files retained in cache.
Uses GitHub blob SHAs to check each download. Run with bundled Python virtualenv.
"""
from pathlib import Path
import urllib.request,urllib.parse,json,hashlib,concurrent.futures,time,zipfile
CACHE=Path.home()/'Libero/cache/libraries'
SOURCES={'sneakybass':('main',lambda p:p.startswith('Samples/')),'meatbass':('master',lambda p:p.startswith('Samples/pizz/') or p.startswith('Samples/noise/')),'swagbass':('master',lambda p:p.startswith(('notes/','noises/','release/'))),'black-and-blue-basses':('main',lambda p:p.startswith('Samples/darkblack/'))}
def get(name,branch,e):
 dst=CACHE/('karoryfer-'+name)/e['path'];dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists() and dst.stat().st_size==e.get('size',-1):return
 url='https://raw.githubusercontent.com/sfzinstruments/karoryfer.'+name+'/'+branch+'/'+urllib.parse.quote(e['path'])
 for retry in range(5):
  try:
   data=urllib.request.urlopen(url,timeout=80).read()
   assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==e['sha'],dst
   dst.write_bytes(data);return
  except Exception:
   if retry==4:raise
   time.sleep(retry+1)
def main():
 for name,(branch,pick) in SOURCES.items():
  d=CACHE/('karoryfer-'+name)
  d.mkdir(parents=True,exist_ok=True)
  if not (d/'tree-api.json').exists():
   url='https://api.github.com/repos/sfzinstruments/karoryfer.'+name+'/git/trees/'+branch+'?recursive=1'
   (d/'tree-api.json').write_bytes(urllib.request.urlopen(url,timeout=60).read())
  tree=json.loads((d/'tree-api.json').read_text())
  licensepath=d/('license' if name=='black-and-blue-basses' else 'LICENSE')
  if not licensepath.exists():
   licensepath.write_bytes(urllib.request.urlopen('https://raw.githubusercontent.com/sfzinstruments/karoryfer.'+name+'/'+branch+'/'+licensepath.name,timeout=60).read())
  assert 'CC0 1.0 Universal' in licensepath.read_text(),name
  es=[e for e in tree['tree'] if e['type']=='blob' and e['path'].lower().endswith('.wav') and pick(e['path'])]
  print(name,len(es),'files',round(sum(e['size'] for e in es)/2**20,1),'MiB',flush=True)
  with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(lambda e:get(name,branch,e),es))
  print(name,'complete',flush=True)
 d=CACHE/'bmc-slap';d.mkdir(parents=True,exist_ok=True)
 if not (d/'api.json').exists():
  (d/'api.json').write_bytes(urllib.request.urlopen('https://ccmixter.org/api/query/api?ids=13742&f=json&dataview=links_dl',timeout=60).read())
 meta=json.loads((d/'api.json').read_text())[0]
 # A normal public download query avoids the site's stale 403 cache entry.
 data=urllib.request.urlopen(meta['download_url']+'?download=1',timeout=60).read();assert len(data)==meta['files'][0]['file_rawsize']
 assert hashlib.sha256(data).hexdigest()=='6b2af3543dd111b9f62b53544c4a02ae633fb775e20b42591e006a3c0d610d53','BMC source version changed'
 (d/'bmc-slap.zip').write_bytes(data)
 with zipfile.ZipFile(d/'bmc-slap.zip') as z:
  for item in z.infolist():
   rel=item.filename.lstrip('/');assert '..' not in Path(rel).parts
   if rel and not item.is_dir():
    (d/rel).parent.mkdir(parents=True,exist_ok=True);(d/rel).write_bytes(z.read(item))
 print('BMC slap complete',flush=True)
if __name__=='__main__':main()
