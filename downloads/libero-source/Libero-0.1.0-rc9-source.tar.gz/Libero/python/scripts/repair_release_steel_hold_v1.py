#!/usr/bin/env python3
"""Repair the nine finite steel-string fingerstyle cells with same-take holds.

Only the sketch `chitarra-acustica-libero` is owned here. Original TavyMusic
PCM extraction and SF2 container are kept untouched; the derived files preserve
the performed pluck and form a long overlap loop from that performance.
"""
from __future__ import annotations
import hashlib,json,math,sys,shutil
from pathlib import Path
import numpy as np
import soundfile as sf
ROOT=Path('/Users/mario/Documents/Libero');sys.path.insert(0,str(ROOT/'python'))
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero.audio import Audio
from libero.multisample import true_onset

FOLDER=Path.home()/'Libero/sketches/chitarra-acustica-libero'; SAMPLES=FOLDER/'samples'
OUT=Path.home()/'Libero/demo/release-replacements-v1/rhythm/chitarra-acustica-libero'
TARGETS={72,75,78,79,80,81,82,83,84}; SR_EXPECT=44100

def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def pressure_loop(source:Path,dest:Path)->tuple[dict,dict]:
 x,sr=sf.read(source,dtype='float64',always_2d=True)
 if sr!=SR_EXPECT:raise RuntimeError(f'unexpected source rate {sr}: {source}')
 win=max(1,round(.010*sr)); env=np.sqrt(np.convolve(np.mean(x*x,axis=1),np.ones(win)/win,mode='same'))
 threshold=max(float(env.max())*10**(-36/20),1e-6); active=np.flatnonzero(env>=threshold)
 onset=float(active[0]/sr) if len(active) else 0.0
 start_s=max(.30,onset+.05); start=round(start_s*sr); xf=round(.30*sr); keep=round(.135*sr); end=len(x)-keep
 if end-start<round(.58*sr) or 2*xf>=end-start or start<xf:
  raise RuntimeError(f'no viable source overlap for {source.name}: length {len(x)/sr:.3f}s')
 y=x[:end].copy(); j=end-xf; tgt=start-xf
 ramp_end=end-keep; n=ramp_end-j
 u=np.linspace(0,1,n,endpoint=True);u=u*u*(3-2*u)
 y[j:ramp_end]=x[j:ramp_end]*(1-u[:,None])+x[tgt:tgt+n]*u[:,None]
 # Exact source-period closure: the final 135 ms before loop end is the
 # performed segment immediately before loop start, avoiding a synthetic bed.
 y[end-keep:end]=x[start-keep:start]
 tail=x[end:].copy()
 if len(tail):
  f=min(len(tail),round(.008*sr));tail[-f:]*=np.linspace(1,0,f)[:,None];y=np.concatenate([y,tail])
 dest.parent.mkdir(parents=True,exist_ok=True);sf.write(dest,y.astype(np.float32),sr,format='FLAC',subtype='PCM_24')
 w=round(.020*sr); seam_num=np.sum((y[start-w:start]-y[end-w:end])**2);seam_den=np.sum(y[start-w:start]**2)+np.sum(y[end-w:end]**2)
 return {'start':start,'end':end},{'method':'same-take performed-overlap pressure loop; preserve attack and body, no oscillator/noise/effect layer','source_seconds':round(len(x)/sr,4),'source_onset_seconds':round(onset,5),'loop_seconds':round((end-start)/sr,4),'loop_seam_db_20ms':round(10*math.log10((seam_num+1e-30)/(seam_den+1e-30)),2),'crossfade_ms':round(xf*1000/sr,2),'exact_source_overlap_ms':round(keep*1000/sr,2),'source_sha256':digest(source),'derived_sha256':digest(dest)}

def main():
 OUT.mkdir(parents=True,exist_ok=True);before=OUT/'before-repair'
 if not before.exists():
  before.mkdir()
  for name in ('sound.py','notes.md'):
   shutil.copy2(FOLDER/name,before/name)
  for name in ('map.json','source-proof.json'):
   shutil.copy2(SAMPLES/name,before/name)
  man=FOLDER/'build/manifest.json';shutil.copy2(man,before/'manifest.json')
  for key in TARGETS:
   f=FOLDER/f'build/body_fingerstyle_n{key:03d}_d100.flac'
   if f.exists():shutil.copy2(f,before/f.name)
 # Rebuild metadata from the captured pre-repair baseline every time; only
 # the nine intended target rows are changed by this script.
 old=json.loads((before/'map.json').read_text());proof=json.loads((before/'source-proof.json').read_text())
 proof_by={(p.get('source_instrument'),p.get('generator_root_key_override')):p for p in proof}
 loops={}; changed=[]
 for row in old:
  if row.get('articulation')!='fingerstyle':continue
  root=int(row.get('root',-1));entry=proof_by.get(('guitar-fingerstyle',root))
  if root in TARGETS:
   if entry is None:raise RuntimeError(f'missing original source-proof for root {root}')
   src=SAMPLES/entry.get('raw_extracted_file',row['file'])
   destrel=Path('derived/fingerstyle-hold')/(Path(entry['raw_extracted_file']).stem+'-pressure.flac');dest=SAMPLES/destrel
   lp,quality=pressure_loop(src,dest);row['file']=destrel.as_posix()
   # The compiler resamples 44.1 kHz sources before applying source loop
   # indices, so serialize the map at the compiled 48 kHz rate.
   lp_bundle={'start':round(lp['start']*48000/SR_EXPECT),'end':round(lp['end']*48000/SR_EXPECT)}
   row['loop']={**lp_bundle,'mode':'source'};quality['loop_source_frames']=lp;quality['loop_compiled_48k_frames']=lp_bundle
   entry['mapped_file']=destrel.as_posix();entry['mapped_sha256']=quality['derived_sha256']
   entry['extraction']='Original PCM extraction retained unchanged at raw_extracted_file; mapped FLAC is a source-derived same-take sustain continuation with a 135 ms exact-source overlap; no added oscillator, noise, or effect.'
   entry['derived_continuation']=quality
   loops[str(root)]=quality;changed.append(root)
 if sorted(changed)!=sorted(TARGETS):raise RuntimeError(f'target coverage mismatch: {sorted(changed)}')
 (SAMPLES/'map.json').write_text(json.dumps(old,indent=2,ensure_ascii=False)+'\n')
 (SAMPLES/'source-proof.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
 shutil.copy2(before/'sound.py',FOLDER/'sound.py')
 shutil.copy2(before/'notes.md',FOLDER/'notes.md')
 notes_path=FOLDER/'notes.md';notes=notes_path.read_text()
 section='## Hold per le nove note acute fingerstyle'
 if section not in notes:
  with notes_path.open('a') as f:
   f.write('\n## Hold per le nove note acute fingerstyle\n\nLe nove sorgenti fingerstyle che prima terminavano senza loop usano ora una continuazione source-derived della stessa esecuzione: attacco originale conservato, corpo reale e sovrapposizione esatta di 135 ms prima del punto di ritorno. Nessun oscillatore, noise bed, riverbero o seconda esecuzione è aggiunto. I 36 loop automatici fingerstyle preesistenti restano sotto la ricetta `auto`; i plectrum restano one-shot finiti. Indici, durata, seam a 20 ms e SHA originali/derivati sono in `samples/derived-loop-report.json` e `samples/source-proof.json`.\n')
 (SAMPLES/'derived-loop-report.json').write_text(json.dumps({'method':'same-take performed-overlap loop, source PCM preserved byte-for-byte; explicit source mode opt-in on only nine high fingerstyle zones; process loop auto remains unchanged for all other cells; plectrum remains finite','targets':loops},indent=2,ensure_ascii=False)+'\n')
 comp=compile_sound(FOLDER,jobs=2)
 if not comp.ok:raise RuntimeError(comp.text())
 final_manifest=json.loads((FOLDER/'build/manifest.json').read_text())
 findings=lint_bundle(FOLDER/'build');counts={}
 for f in findings:counts[f.level]=counts.get(f.level,0)+1
 fails=[f.line() for f in findings if f.level=='FAIL']
 if fails:raise RuntimeError('lint FAIL: '+repr(fails))
 zones=final_manifest['zones'];loops_built=[z for z in zones if z.get('articulation')=='fingerstyle' and z.get('loop')]
 if len(loops_built)!=45:raise RuntimeError(f'compiled main loops incomplete: {len(loops_built)}/45')
 report={'slug':'chitarra-acustica-libero','title':final_manifest['title'],'zones':len(zones),'source_hash':final_manifest.get('source_hash'),'compile':comp.summary,'lint':counts,'lint_warnings':[f.line() for f in findings if f.level=='WARN'],'main_fingerstyle_loop_zones':{str(z['root']):z['loop'] for z in loops_built},'new_derived_loops':loops,'original_sf2_sha256':digest(SAMPLES/'originals/PluckedStrings.sf2'),'source_pcm_preserved':True,'before_zone_snapshot':str(before)}
 (OUT/'repair-build-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'compiled':comp.ok,'hash':report['source_hash'],'lint':counts,'maintargetloops':len(loops_built),'newloops':len(loops),'seams':{k:v['loop_seam_db_20ms'] for k,v in loops.items()}},indent=2))
if __name__=='__main__':main()
