"""Cielo v2: distinct actual performances, staged atomically outside active bank.
Run build_cielo_v2_extract.py first, then this builder and verify script.
"""
from pathlib import Path
import json,math,shutil,itertools,sys
import numpy as np
from libero import Audio,load,dsp,licenses
from libero.compiler import compile_sound
from libero.lint import _load
BASE=Path.home()/'Libero/cache/research/cielo-v2';OLD=Path.home()/'Libero/cache/research/cielo'
STAGE=BASE/'staged';STAGE.mkdir(exist_ok=True)
RECS=json.loads((OLD/'vocalset-notes.json').read_text())+json.loads((BASE/'notes.json').read_text())
CREDIT={'source':'VocalSet: A Singing Voice Dataset','license':'CC BY 4.0','license_class':'by','author':'Julia Wilkins, Prem Seetharaman, Alison Wahl, Bryan Pardo / Northwestern University','url':'https://zenodo.org/records/1442513','retrieved':'2026-10-02'}

def draw(role,title):
    strokes=[]
    for i in range(14):
        y=120+i*19
        if role=='radura':d=f'M70,{y}Q{170+i*4},{y-55} 256,{y}T442,{y}'
        elif role=='mezzo':d=f'M90,{y}Q170,{y-95} 248,{y}Q330,{y+65} 422,{y}'
        elif role=='pietra':d=f'M{90+i*3},390V{150+i*9}Q256,{80+i*9} {422-i*3},{150+i*9}V390'
        elif role=='cenere':d='M'+ 'L'.join(f'{100+j*8},{y+np.sin(j*.55+i*.9)*(10+i*1.1):.1f}' for j in range(40))
        elif role=='volta':d=f'M{60+i*7},410Q{95+i*3},{40+i*8} 256,{82+i*13}Q{417-i*3},{40+i*8} {452-i*7},410'
        elif role=='rito':d='M'+'L'.join(f'{256+(80+i*7+8*np.sin(j*8))*np.cos(j):.1f},{256+(80+i*7+8*np.sin(j*8))*np.sin(j):.1f}' for j in np.linspace(0,2*np.pi,121))
        else:d=f'M{95+i*4},340C{70+i*8},100 {440-i*5},100 {415-i*4},340C300,440 200,390 {95+i*4},340'
        strokes.append(f'<path d="{d}" stroke="currentColor" stroke-width="{1.2 if i==0 else .45}"/>')
    gold={'radura':'M70,265Q170,210 256,265T442,265','mezzo':'M90,250Q170,155 248,250Q330,315 422,250','pietra':'M90,390H422','cenere':'M100,260Q190,190 256,260T410,260','volta':'M60,410Q95,40 256,82Q417,40 452,410','rito':'M256,64V92','ellen':'M150,310C120,165 380,130 390,290'}[role]
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>Recorded voice gesture: {role}. Multiple fine paths represent independent moving harmonic bands; the gold stroke follows the musical entrance.</desc>{"".join(strokes)}<path d="{gold}" stroke="#b8924f" stroke-width="1.3"/></svg>'

def choose(singer,vowel,tech,target,maxshift=2):
    rr=[r for r in RECS if r['singer']==singer and r['vowel']==vowel and r['dynamic']==tech and abs(r['root']-target)<=maxshift and r['seconds']>=.65 and Path(r['file']).name not in {'m10_long_forte_o-0-59.wav','m10_arpeggios_c_slow_piano_o-0-52.wav','m10_scales_c_slow_forte_o-0-53.wav','m10_scales_f_slow_piano_o-0-55.wav'}]
    return min(rr,key=lambda r:(abs(r['root']-target),-r['seconds'])) if rr else None

def ensemble(role,vowel,tech,root,singers,sections=False,minvoices=2):
    selected=[]
    for s in singers:
        shift=0
        if sections:shift=-12 if s in {'male4','male8','male10'} else (12 if s.startswith('female') and s not in {'female5','female8'} else 0)
        r=choose(s,vowel,tech,root+shift,3 if tech in {'pp','straight','forte','messa'} else 2)
        if r:selected.append((r,shift))
    if len(selected)<minvoices:return None
    buffers=[]
    for i,(r,shift) in enumerate(selected):
        a=load(r['file'],sr=48000).pitch(root+shift-r['root'])
        # Original gestures, constant transposition only. No clones, loops or jitter.
        x=dsp.mono(a.data)
        if sections:x=x*(4.0 if shift==-12 else (.85 if shift==12 else 1.0))
        pan=-.65+1.3*i/max(1,len(selected)-1);ang=(pan+1)*math.pi/4
        x=np.pad(x,(int((i%4)*.008*48000),0));buffers.append(np.stack([x*np.cos(ang),x*np.sin(ang)],axis=1))
    # Longer source gestures remain, even after a short component naturally ends.
    out=np.zeros((max(len(x) for x in buffers),2))
    for x in buffers:out[:len(x)]+=x
    out/=math.sqrt(len(buffers));a=Audio(out,48000).remove_dc().fade_in(.003).fade_out(.04)
    dest=BASE/'assembled'/role/f'{vowel}-{tech}-{root}.wav';dest.parent.mkdir(parents=True,exist_ok=True);a.save(dest,subtype='PCM_24')
    return {'file':str(dest),'root':root,'take':0,'singers':[r['singer'] for r,sh in selected],'sources':[{**r,'section_octave':sh//12,'assembly_semitones':root+sh-r['root'],'section_gain_db':12.0412 if sections and sh==-12 else (-1.4116 if sections and sh==12 else 0)} for r,sh in selected],'lufs':dsp.momentary_max(a.data,48000),'peak_db':a.peak_db}

PALETTE=[
('donne-radura','Donne · Radura','radura','Un coro femminile ampio e mobile, per accordi aperti: nove cantanti disponibili, vibrato registrato e respiri distinti.',[f'female{i}' for i in range(1,10)],['pp','straight','forte'],range(60,82,3),False,3,10,.14,2.2),
('donne-mezzo','Donne · Mezzo','mezzo','Due mezzosoprani vicine e incisive. Il belt registrato conserva il petto e gli attacchi delle vocali; le note hanno la durata reale della frase.', ['female5','female8'],['belt'],range(55,77,2),False,2,2,.07,1.3),
('uomini-pietra','Uomini · Pietra','pietra','Bassi e baritoni con peso nel registro grave. Vocali lunghe per fondamentali, intervalli larghi e accordi sobri.', ['male4','male8','male10','male1','male5','male6'],['pp','straight','forte'],range(43,67,3),False,3,8,.12,2.0),
('uomini-cenere','Uomini · Cenere','cenere','Tre baritoni soffiano realmente le vocali: aria, grana e presenza ravvicinata. Un colore intimo, da piccole melodie e contrappunti.', ['male1','male5','male6'],['breathy'],range(45,68,2),False,2,3,.06,1.2),
('coro-volta','Coro · Volta','volta','Un coro misto costruito per sezioni: bassi un’ottava sotto, tenori e mezzosoprani al centro, soprani un’ottava sopra. Le ottave vengono da registri realmente cantati.', ['male4','male8','male10','male2','male3','male7','male11']+[f'female{i}' for i in range(1,10)],['pp','straight','forte'],range(57,69,3),True,6,12,.19,3.0),
('trillo-rito','Trillo · Rito','rito','Pulsazioni vocali realmente eseguite, con piccoli attacchi interni e movimento ritmico irregolare. Per ostinati, risposte e accordi scanditi.', ['female5','female8','male1','male5','male6','male2','male3'],['trillo'],range(55,77,3),False,3,0,.08,1.4)
]

def write_sound(slug,title,role,desc,regions,arts,attack,rev,decay,credit=CREDIT):
    folder=STAGE/slug
    if folder.exists():shutil.rmtree(folder)
    (folder/'samples').mkdir(parents=True);mapped=[]
    for i,r in enumerate(regions):
        dest=folder/'samples'/f'{i:03d}.wav';shutil.copy2(r['file'],dest)
        mapped.append({k:r[k] for k in ['root','take','dyn','articulation','gain_db'] if k in r}|{'file':dest.name})
    for art in {r['articulation'] for r in mapped}:
        roots=sorted({r['root'] for r in mapped if r['articulation']==art})
        for r in mapped:
            if r['articulation']!=art:continue
            ix=roots.index(r['root']);r['lo']=max(0,roots[0]-1) if ix==0 else (roots[ix-1]+r['root'])//2+1;r['hi']=roots[-1]+1 if ix==len(roots)-1 else (r['root']+roots[ix+1])//2
    (folder/'samples/map.json').write_text(json.dumps(mapped,indent=2));(folder/'samples/provenance.json').write_text(json.dumps(regions,indent=2));licenses.add_credit(folder,credit)
    roots=sorted({r['root'] for r in mapped});recipe=f'''from libero import Sound\nfrom pathlib import Path\nimport json\nsound=Sound({title!r},subtitle='voci registrate · {role}',tags=['voice','choir','voce','coro','cielo'],roots={roots!r},seed=2718)\nsound.multisample('body',json.loads((Path(__file__).parent/'samples/map.json').read_text()),process={{'pre_ms':4,'align_ms':5,'tune':'source','ladder':'keep','peak_db':-10,'max_seconds':None,'end_db':-70,'fade_ms':35,'loop':'none','encoding':'flac24','edge_fill':False}},as_dyn=True)\nsound.articulations({arts!r})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=2000)\nsound.defaults(mode='Poli',glide=0,voices=32,dyn_mode='Velocità',amp_attack={attack},amp_decay=10000,amp_sustain=1,amp_release=260,vel_sens=.25,lvl_body=0,lvl_tail=-60,lvl_air=-60,drive=0,tape_wow=0,tape_flutter=0,tape_sat=0,tape_age=0,tape_mix=0,osc1_level=-60,osc2_level=-60,sub_level=-60,lfo_pitch=0,lfo_amp=0,res_mix=0,echo_mix=0,flt_cutoff=20000,rev_mode='Cappella',rev_mix={rev},rev_size=.6,rev_decay={decay},rev_predelay=22,rev_damp=.35,master=-3,humanize=0)\n'''
    (folder/'sound.py').write_text(recipe);(folder/'figure.svg').write_text(draw(role,title));(folder/'notes.md').write_text(f'# {title}\n\n{desc}\n\nAh/Eh/Oh seguono le vocali a/e/o realmente registrate; l’apertura italiana della e non è certificata. Il coro è un montaggio di interpreti separati, non una ripresa simultanea. Nessuna voce sintetica, wow/flutter o ripetizione artificiale. Inviluppi e stanza aiutano a suonare il materiale senza cancellarne gli attacchi. Nessun loop: tenendo il tasto, ogni componente termina alla fine della registrazione.\n\nSource: {credit["source"]} · {credit["license"]} · {credit["url"]}. Le informazioni su interpreti, tecnica, intervalli estratti e trasposizione sono in samples/provenance.json. Le parti corrispondono alle tecniche originali, non a filtri della stessa vocale.\n\nLe registrazioni pp, normale/vibrato e forte, quando presenti, sono dinamiche distinte; belt, breathy e trillo hanno un solo livello originale e la velocity regola il volume. Non inventiamo un secondo livello registrato. La composizione dei cantanti cambia col registro. Nei vuoti dei longtone, Radura e Pietra usano note originali di scale lente piano/forte: durate più brevi, due dinamiche vere, meno trasporto. La mappa copre solo il registro selezionato e trasporta moderatamente le note vicine.\n\nNon posso ascoltare: le verifiche numeriche e gli spettrogrammi verificano il comportamento tecnico, non certificano gusto o realismo percepito.\n')
    res=compile_sound(folder,jobs=2)
    if not res.ok:raise RuntimeError(res.error)
    # Keep absolute constant tuning in the reproducible map, never tune=detect twice.
    ds=[_load(folder/'build',z,True) for z in json.loads((folder/'build/manifest.json').read_text())['zones']]
    processing=[]
    lookup={(r['root'],r['articulation'],tuple(r.get('dyn',[0,1]))):r for r in mapped}
    for d in ds:
        if d.above18k_db>-40:
            region=lookup[(d.z['root'],d.z['articulation'],tuple(d.z.get('dyn',[0,1])))];path=folder/'samples'/region['file']
            load(path).lowpass(16000,order=2,zero_phase=True).save(path,subtype='PCM_24')
            processing.append({'file':region['file'],'lowpass_hz':16000,'original_above18k_db':d.above18k_db,'reason':'Recorded ultrasonic hiss/alias headroom, selective; source formant body retained.'})
        if d.f0_cents is not None:lookup[(d.z['root'],d.z['articulation'],tuple(d.z.get('dyn',[0,1])))]['tune_cents']=round(-d.f0_cents,2)
    # Recording-session microphone gains differ strongly by register. Calibrate
    # fixed zone gain per original dynamic, preserving +/-2 dB native variation.
    # This changes level only: no spectral replacement or fake dynamics.
    for art in {r['articulation'] for r in mapped}:
        for dyn in {tuple(r.get('dyn',[0,1])) for r in mapped if r['articulation']==art}:
            group=[d for d in ds if d.z['articulation']==art and tuple(d.z.get('dyn',[0,1]))==dyn]
            median=float(np.median([d.lufs_max for d in group]))
            for d in group:
                r=lookup[(d.z['root'],art,dyn)]
                r['gain_db']=r.get('gain_db',0)+float(np.clip(d.lufs_max,median-2,median+2)-d.lufs_max)
    # Lower only inverted dynamics, retaining independent recordings.
    for art in {r['articulation'] for r in mapped}:
        for root in roots:
            rr=sorted([d for d in ds if d.z['root']==root and d.z['articulation']==art],key=lambda d:tuple(d.z.get('dyn',[0,1])))
            target=[d.lufs_max+lookup[(root,art,tuple(d.z.get('dyn',[0,1])))].get('gain_db',0) for d in rr]
            for i in range(1,len(target)):target[i]=min(target[i],target[i-1]+8)
            for i in range(len(target)-2,-1,-1):target[i]=min(target[i],target[i+1]-3)
            for d,t in zip(rr,target):
                r=lookup[(root,art,tuple(d.z.get('dyn',[0,1])))];r['gain_db']=r.get('gain_db',0)+float(t-(d.lufs_max+r.get('gain_db',0)))
    (folder/'samples/processing.json').write_text(json.dumps(processing,indent=2))
    (folder/'samples/map.json').write_text(json.dumps(mapped,indent=2));res=compile_sound(folder,jobs=2)
    if not res.ok:raise RuntimeError(res.error)
    print(slug,'zones',len(mapped),'roots',roots,flush=True)
    return folder

def main():
    for slug,title,role,desc,singers,techs,roots,sections,minvoices,attack,rev,decay in PALETTE:
        if len(sys.argv)>1 and slug!=sys.argv[1]:continue
        regs=[]
        for vowel,art in [('a','ah'),('e','eh'),('o','oh')]:
            # Retain only roots supported by ALL declared actual dynamics.
            sets={root:[ensemble(role,vowel,t,root,singers,sections,minvoices) for t in techs] for root in roots}
            if role in {'radura','pietra'}:
                for root,rows in list(sets.items()):
                    if not all(rows):
                        alt=[ensemble(role,vowel,t,root,singers,False,minvoices) for t in ['slow_piano','slow_forte']]
                        if all(alt):sets[root]=alt
            sets={root:rows for root,rows in sets.items() if all(rows)}
            for root,rows in sets.items():
                for i,r in enumerate(rows):
                    r['articulation']=art;r['dyn']=[i/len(rows),(i+1)/len(rows)];r['gain_db']=0;regs.append(r)
        if role=='mezzo':
            # Default long original forte notes; real belt remains a separate gesture.
            belt=regs;regs=[]
            for vowel,art in [('a','ah'),('e','eh'),('o','oh')]:
                for root in range(57,76,3):
                    r=ensemble(role,vowel,'forte',root,singers,False,2)
                    if not r:r=ensemble(role,vowel,'slow_forte',root,singers,False,2)
                    if r:r.update(articulation=art,dyn=[0,1],gain_db=0);regs.append(r)
            for r in belt:r['articulation']+='_belt'
            regs+=belt
        if not regs:raise RuntimeError('No supported actual range '+slug)
        arts=[{'id':a,'name':n,'key':24+i} for i,(a,n) in enumerate([('ah','Ah'),('eh','Eh'),('oh','Oh')])]
        if role=='mezzo':
            arts += [{'id':a+'_belt','name':n+' · belt','key':27+i} for i,(a,n) in enumerate([('ah','Ah'),('eh','Eh'),('oh','Oh')])]
            desc='Due mezzosoprani vicine e piene, con vocali lunghe reali. Le articolazioni belt conservano attacchi di petto e la durata breve delle note originali: due gesti differenti, dalle stesse due interpreti.'
        if role in {'radura','pietra','volta'}:
            for root in roots:
                r=ensemble(role,'a','messa',root,singers,sections,minvoices)
                if r:r.update(articulation='ah_open',dyn=[0,1],gain_db=0);regs.append(r)
            arts.append({'id':'ah_open','name':'Ah · apertura','key':27})
            desc += ' Ah · apertura conserva il lungo crescendo originale (messa di voce), con il suo movimento registrato.'
        write_sound(slug,title,role,desc,regs,arts,attack,rev,decay)
    if len(sys.argv)>1 and sys.argv[1]!='ellen-ooh-aha':return
    # This is a recorded chord/phrase, not a unison vowel. Its tonal root is G.
    a=load(OLD/'female-ensemble.mp3',sr=48000).remove_dc().fade_in(.003).fade_out(.045);p=BASE/'ellen-ooh-aha.wav';a.save(p,subtype='PCM_24')
    credit={'source':'ooh-aha.wav · public HQ MP3 edition','license':'CC0 1.0','license_class':'cc0','author':'ellenmentor','url':'https://freesound.org/people/ellenmentor/sounds/419161/','retrieved':'2026-10-02'}
    desc='Una cantante, dodici sovraincisioni originali: Ooh e Aha aprono due accordi vocali, con una coda e un secondo ingresso. Conserva gli effetti della registrazione. È una frase armonica completa, non una vocale monofonica; il tasto trasporta l’accordo. Fonte pubblica MP3, non WAV originale.'
    write_sound('ellen-ooh-aha','Ellen · Ooh → Aha','ellen',desc,[{'file':str(p),'root':55,'take':0,'dyn':[0,1],'articulation':'phrase','gain_db':0,'singers':['ellenmentor'],'overdubs':12,'source_seconds':[0,a.duration]}],[{'id':'phrase','name':'Ooh → Aha','key':24}],0,0,1.0,credit)
    # Replace generic vowel text for this honest polyphonic phrase.
    p=STAGE/'ellen-ooh-aha/notes.md';p.write_text('# Ellen · Ooh → Aha\n\n'+desc+'\n\nSource: '+credit['url']+' · CC0 1.0. Registrazione di ellenmentor, Samson condenser / PreSonus AudioBox22VSL / Studio One, Paesi Bassi 2018. L’autrice dichiara effetti e dodici sovraincisioni della propria voce: non dodici persone. Centro armonico nominale Sol3; mappa Fa♯3–Sol♯3, un semitono per lato, nessuna pretesa di intonazione unisono o dinamiche multiple. Nessun loop, nessuna voce sintetica o wow/flutter.\n')
if __name__=='__main__':main()
