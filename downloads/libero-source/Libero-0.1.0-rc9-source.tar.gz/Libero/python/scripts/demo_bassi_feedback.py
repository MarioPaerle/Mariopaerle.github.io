"""Short musical audition of the new basses through the native Libero engine."""
from pathlib import Path
import json
import subprocess
import sys

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from libero.render import find_renderer

LIBRARY_ROOT = Path.home() / "Libero"
OUT = LIBRARY_ROOT / "demo" / "bassi-feedback"


def render(folder, name, events, tail=2):
    path = OUT / (name + ".wav")
    notes = ",".join(f"{n}:{t:.5f}:{d:.5f}:{v}" for n, t, d, v in events)
    subprocess.run([str(find_renderer()), "--sound", str(folder / "build"),
                    "--out", str(path), "--notes", notes, "--tail", str(tail),
                    "--sr", "48000"], check=True, capture_output=True)
    audio, sr = sf.read(path, always_2d=True)
    return audio, sr


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    beat = 60 / 96
    walking = [33, 36, 40, 43, 38, 41, 45, 48,
               31, 35, 38, 42, 28, 32, 35, 40]
    bass_events = [(n, i * beat, beat * .90, [88, 76, 94, 82][i % 4])
                   for i, n in enumerate(walking)]
    chords = [[57, 60, 64, 67], [57, 60, 62, 65],
              [55, 59, 62, 66], [56, 59, 62, 64]]
    piano_events = [(n, (bar * 4 + .45) * beat, beat * 1.8, 52)
                    for bar, chord in enumerate(chords) for n in chord]
    piano, sr = render(LIBRARY_ROOT / "banks/piano/pianoforte-concerto",
                       "piano-accompaniment", piano_events)
    report = {}
    for slug in ("contrabbasso-jazz", "basso-flatwound", "basso-hollowbody"):
        bass, _ = render(LIBRARY_ROOT / "banks/bassi" / slug, slug + "-walking", bass_events)
        n = max(len(piano), len(bass))
        mix = np.zeros((n, 2))
        mix[:len(bass)] += bass
        mix[:len(piano)] += piano * 10 ** (-14 / 20)
        peak = float(np.max(np.abs(mix)))
        # Attenuation only: preserve the instrument's own envelope and balance.
        gain = min(1, 10 ** (-3 / 20) / max(peak, 1e-12))
        mix *= gain
        path = OUT / (slug + "-con-piano.wav")
        sf.write(path, mix, sr, subtype="PCM_24")
        report[slug] = {"file": str(path), "seconds": len(mix) / sr,
                        "peak_dbfs": 20 * np.log10(max(np.max(np.abs(mix)), 1e-12)),
                        "clipped_samples": int(np.count_nonzero(np.abs(mix) >= 1)),
                        "mix_attenuation_db": 20 * np.log10(gain),
                        "bass_midi": bass_events, "piano_gain_db": -14}
    (OUT / "musical-demos.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
