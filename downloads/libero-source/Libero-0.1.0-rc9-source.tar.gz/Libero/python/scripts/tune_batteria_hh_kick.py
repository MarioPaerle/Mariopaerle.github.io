#!/usr/bin/env python3
"""Rebuild the approved Jazz-derived boom-bap hats and Big Rusty kick2.

Run with the immutable v5 backup and current Libero home:
  python python/scripts/tune_batteria_hh_kick.py --apply
Then compile with `libero compile batteria-boombap batteria-hiphop-vera`.
The script writes only the seven boom-bap HH source groups/manifest rows and the
24 hip-hop kick2 recordings. It does not alter sound.py, defaults or other zones.
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfiltfilt
from libero import dsp

HAT_KEYS = {54: 42, 65: 42, 56: 46, 66: 46, 58: 44, 67: 44, 69: 26}
HAT_NAMES = {42: "closed", 46: "open", 44: "pedal", 26: "half_open"}
DEST_NAMES = {54:"hat-closed-dusty",65:"hat-closed-crisp",56:"hat-open-dusty",66:"hat-open-crisp",58:"hat-pedal-dusty",67:"hat-pedal-crisp",69:"hat-half-open"}

def run(home: Path, backup: Path, apply: bool) -> None:
    banks=home/"banks/percussioni"
    boom=banks/"batteria-boombap"; jazz=banks/"batteria-jazz"; hip=banks/"batteria-hiphop-vera"
    base_boom=backup/"batteria-boombap"; base_hip=backup/"batteria-hiphop-vera"
    for p in (base_boom/"samples/kit_manifest.json",base_hip/"samples/mix_manifest.json",jazz/"samples/mix_manifest.json"):
        if not p.exists(): raise FileNotFoundError(p)
    old=json.loads((base_boom/"samples/kit_manifest.json").read_text())
    jm=json.loads((jazz/"samples/mix_manifest.json").read_text())
    target={k:max(z["peak_db"] for z in old if z["key"]==k) for k in HAT_KEYS}
    if not apply:
        print("Dry run. Would replace HH keys",sorted(HAT_KEYS),"and hip-hop kick2 from pristine backup:",backup)
        return
    manifest=json.loads((boom/"samples/kit_manifest.json").read_text())
    manifest=[z for z in manifest if z["key"] not in HAT_KEYS]
    for dst,src in HAT_KEYS.items():
        levels=sorted(map(int,jm[str(src)])); n=len(levels); cap=10**(target[dst]/20)
        source_max=max(10**(e[2]/20) for vv in jm[str(src)].values() for e in vv)
        gain=cap/source_max
        for di,v in enumerate(levels):
            for rr,filename,_source_pk in sorted(jm[str(src)][str(v)]):
                raw,sr=sf.read(jazz/"samples/mix"/filename,always_2d=True,dtype="float32")
                x=raw*gain; drive=1.15
                y=np.tanh(drive*x)*(cap/np.tanh(drive*cap))
                name=f"jazz_k{dst:03d}_{HAT_NAMES[src]}_d{v:02d}_t{rr-1}.wav"
                sf.write(boom/"samples/kit"/name,y,sr,subtype="PCM_24")
                manifest.append({"key":dst,"name":DEST_NAMES[dst],"file":f"kit/{name}",
                    "dyn":[round(di/n,4),round((di+1)/n,4)],"take":rr-1,"kind":"hat","choke":1,
                    "one_shot":True,"peak_db":round(float(20*np.log10(np.max(np.abs(y))+1e-15)),2),
                    "lufs400":round(float(dsp.momentary_max(y.mean(1),sr)),1)})
    (boom/"samples/kit_manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+"\n")
    # Recreate only kick2 samples from pristine real takes; preserve all other files and
    # the original peak metadata used to calculate the sound's per-dynamic gains.
    kick_manifest=base_hip/"samples/mix_manifest.json"
    shutil_path=hip/"samples/mix_manifest.json"
    import shutil
    shutil.copy2(kick_manifest,shutil_path)
    for source in sorted((base_hip/"samples/mix").glob("kick2*.flac")):
        x,sr=sf.read(source,always_2d=True,dtype="float32")
        lp=sosfiltfilt(butter(3,150,btype="lowpass",fs=sr,output="sos"),x,axis=0)
        hf=sosfiltfilt(butter(2,1200,btype="highpass",fs=sr,output="sos"),x,axis=0)
        env=np.exp(-np.arange(len(x),dtype=np.float32)/(0.025*sr))[:,None]
        u=x+1.3*lp+2.0*hf*env
        drive=2.2; y=np.tanh(drive*u)/np.tanh(drive)
        y*=np.max(np.abs(x))/max(float(np.max(np.abs(y))),1e-12)
        sf.write(hip/"samples/mix"/source.name,y,sr,subtype="PCM_24")
    print("Wrote 152 Jazz-derived HH zones and 24 kick2 takes; compile the two kits next.")

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--home",type=Path,default=Path.home()/"Libero")
    ap.add_argument("--backup",type=Path,default=Path.home()/"Libero-backups/2026-10-03/drums-hats-kick-v5")
    ap.add_argument("--apply",action="store_true",help="write the targeted source samples and manifests")
    args=ap.parse_args();run(args.home.expanduser(),args.backup.expanduser(),args.apply)
