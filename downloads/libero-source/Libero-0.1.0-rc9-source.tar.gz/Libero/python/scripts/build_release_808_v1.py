"""Create three original, proposed-CC0 808 instruments without source samples.

Only the three *-libero directories are written. The previously installed
Abletunes instruments are measurement references only and are never read here.
"""
from __future__ import annotations

import hashlib
import json
import math
import shutil
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
from libero.compiler import compile_sound
from libero.figure import rasterize, validate_svg
from libero.library import source_hash
from libero.lint import lint_bundle
from libero import render

HOME = Path.home() / "Libero"
BANK = HOME / "banks" / "bassi"
OUT = HOME / "demo" / "release-replacements-v1" / "bassi"
SR = 48_000
LOW, HIGH = 21, 60
VELOCITIES = ((1, 79, 56), (80, 127, 116))
SPECS = {
    "808-cavo-libero": {
        "title": "808 Cavo II", "accent": "#9a7448",
        "subtitle": "808 originale · corpo cavo, fondamentale ferma",
        "design": "Un impulso discendente apre la nota; il corpo resta su una fondamentale stabile con seconda armonica attenuata e una struttura di parziali dispari, larga ma controllata.",
    },
    "808-colpo-libero": {
        "title": "808 Colpo II", "accent": "#bb6849",
        "subtitle": "808 originale · colpo incisivo e coda sub",
        "design": "L'attacco combina discesa di pitch e armonici alti che si ritirano rapidamente; il corpo sostiene la fondamentale sub con seconda e terza armonica più presenti.",
    },
    "808-notte-libero": {
        "title": "808 Notte II", "accent": "#5e6286",
        "subtitle": "808 originale · corpo scuro con movimento lento",
        "design": "Il corpo mantiene una fondamentale ferma e scura; armoniche centrali cambiano lentamente peso in un ciclo lungo, senza wow, flutter o modulazione di pitch.",
    },
}
REFERENCE_MEASUREMENTS = {
    "808-cavo-libero": {"preset":"808-cavo","path":"~/Libero/banks/bassi/808-cavo/samples/body.wav",
        "root_midi":28,"duration_s":4.6181,"measured_f0_hz":41.1953,"rms_0_5_1s_dbfs":-4.4678,
        "band_share_0_5_1_5s":{"20_60Hz":.89466,"60_150Hz":.09693,"150_500Hz":.00841}},
    "808-colpo-libero": {"preset":"808-colpo","path":"~/Libero/banks/bassi/808-colpo/samples/body.wav",
        "root_midi":36,"duration_s":4.5356,"measured_f0_hz":65.7364,"rms_0_5_1s_dbfs":-6.0720,
        "band_share_0_5_1_5s":{"20_60Hz":.00612,"60_150Hz":.96028,"150_500Hz":.03117}},
    "808-notte-libero": {"preset":"808-notte","path":"~/Libero/banks/bassi/808-notte/samples/body.wav",
        "root_midi":33,"duration_s":18.5642,"measured_f0_hz":54.9070,"rms_0_5_1s_dbfs":-5.4628,
        "band_share_0_5_1_5s":{"20_60Hz":.89294,"60_150Hz":.02674,"150_500Hz":.08032}},
}

def cents_for(freq: float, period: float) -> tuple[int, float]:
    cycles = max(1, round(freq * period))
    actual = cycles / period
    return cycles, 1200 * math.log2(actual / freq)

def recipe_seed(slug: str, midi: int, vel: int) -> int:
    raw = hashlib.sha256(f"Libero authored 808 v1|{slug}|{midi}|{vel}|seed-20261003".encode()).digest()
    return int.from_bytes(raw[:8], "big")

def wave_for(slug: str, midi: int, vel: int):
    """Make a one-off pitched attack plus an explicitly periodic held body."""
    f0 = 440 * 2 ** ((midi - 69) / 12)
    period = 2.0 if slug == "808-notte-libero" else 1.0
    cycles, detune = cents_for(f0, period)
    f = cycles / period
    rng = np.random.default_rng(recipe_seed(slug, midi, vel))
    v = (vel - 1) / 126
    # A common low fundamental anchors all three identities and protects note pitch.
    amps = {
        "808-cavo-libero": [1.0, .08 + .025*v, .25 + .04*v, .045, .12, .025, .07, .018, .04],
        "808-colpo-libero": [1.0, .38 + .1*v, .32 + .08*v, .17, .10, .055, .03, .018, .012],
        "808-notte-libero": [1.0, .18 + .03*v, .21 + .02*v, .085, .12, .05, .065, .03, .03],
    }[slug]
    phases = rng.uniform(-math.pi, math.pi, len(amps))
    # Keep fundamental phase fixed; deterministic phases enrich each source-root texture.
    phases[0] = 0
    nloop = max(256, round(period * SR))
    tloop = np.arange(nloop, dtype=np.float64) / SR
    body = np.zeros(nloop, dtype=np.float64)
    for k, (amp, phase) in enumerate(zip(amps, phases), start=1):
        motion = 1.0
        if slug == "808-notte-libero" and k in (2, 3, 5, 7):
            depth = (.055 if k in (2, 3) else .085) * (0.5 + 0.5*v)
            motion = 1 + depth * np.sin(2 * np.pi * tloop / period + .71*k)
        body += amp * motion * np.sin(2*np.pi*(k*f)*tloop + phase)
    # Slightly rounded authored body: no noise, external sample, or copied waveform.
    body = np.tanh(body * (1.05 if slug == "808-colpo-libero" else .92))

    attack_s = .235
    na = round(attack_s * SR)
    ta = np.arange(na, dtype=np.float64) / SR
    # One-way pitch fall: +12 semitones at onset, converging to body f0 by 180 ms.
    sweep = 12.0 * np.exp(-ta / .040)
    inst = f * np.power(2.0, sweep / 12.0)
    phase_acc = 2*np.pi*np.cumsum(inst) / SR
    attack = np.zeros(na, dtype=np.float64)
    for k, (amp, phase) in enumerate(zip(amps, phases), start=1):
        decay = np.exp(-ta / (.065 if slug == "808-colpo-libero" and k > 1 else .10)) if k > 1 else 1
        attack += amp * decay * np.sin(k*phase_acc + phase)
    # 808 Colpo's upper edge is a single onset event, not a looped transient.
    if slug == "808-colpo-libero":
        for k in range(3, len(amps)+1):
            decay = np.exp(-ta / .035)
            attack += .18 * decay * np.sin(k*phase_acc + phases[k-1])
    attack = np.tanh(attack * 1.05)
    # Continue on exact f0 into periodic material; crossfade over 20 ms to avoid a hard splice.
    phase_end = float(phase_acc[-1])
    aligned_body = np.zeros(nloop, dtype=np.float64)
    for k, (amp, phase) in enumerate(zip(amps, phases), start=1):
        motion = 1.0
        if slug == "808-notte-libero" and k in (2, 3, 5, 7):
            depth = (.055 if k in (2, 3) else .085) * (0.5 + 0.5*v)
            motion = 1 + depth * np.sin(2 * np.pi * tloop / period + .71*k)
        aligned_body += amp * motion * np.sin(2*np.pi*(k*f)*tloop + k*phase_end + phase)
    aligned_body = np.tanh(aligned_body * (1.05 if slug == "808-colpo-libero" else .92))
    xf = round(.020*SR)
    startbody = aligned_body[:nloop].copy()
    # Align the periodic body phase to attack's final fundamental cycle.
    w = np.linspace(0, 1, xf, endpoint=True)
    prefix = np.concatenate([attack[:-xf], attack[-xf:]*(1-w)+startbody[:xf]*w,
                             startbody[xf:], startbody[:xf]])
    # Let the one-off attack/body splice finish, then play one complete body cycle
    # before declaring the loop. This gives the loop's preceding 20 ms true steady
    # state, which is also what the native seam auditor compares at wrap.
    cycle = np.concatenate([startbody[xf:], startbody[:xf]])
    loop_start = len(prefix)
    loop_end = loop_start + len(cycle)
    joined = np.concatenate([prefix, cycle])
    # Gain staging before compiler's shared peak trim. Authored velocity remains a meaningful
    # timbral/level change; keep all roots/cells and both authored layers intact.
    velocity_gain = .72 + .16*v
    joined *= velocity_gain
    return joined.astype(np.float32), {
        "root_midi": midi, "target_f0_hz": f0, "period_seconds": period,
        "integer_cycles": cycles, "generated_body_f0_hz": f,
        "quantization_cents": detune, "attack_pitch_drop_semitones": 12,
        "attack_converges_by_seconds": .18, "loop_start_frame": loop_start,
        "loop_end_frame": loop_end, "fine_tune_cents": -detune, "seed": recipe_seed(slug,midi,vel),
        "authored_velocity_gain_linear":velocity_gain,
        "velocity_gain_formula":"0.72 + 0.16 * ((authored_velocity - 1) / 126)",
        "velocity_partial_formula":"Cavo: H2=0.08+0.025v, H3=0.25+0.04v; Colpo: H2=0.38+0.1v, H3=0.32+0.08v; Notte: H2=0.18+0.03v, H3=0.21+0.02v; v=(authored_velocity-1)/126",
        "harmonic_amplitudes_before_body_rounding": amps,
    }

def svg_for(slug: str, spec: dict) -> str:
    desc = spec["design"]
    if slug == "808-cavo-libero":
        art = '<path d="M70 340Q70 170 256 118Q442 170 442 340Z" fill="#f2eee6" stroke-width="2"/><path d="M150 340V238Q150 196 256 196Q362 196 362 238V340Z" stroke="#9a7448" stroke-width="2"/><path d="M185 332V250Q185 220 256 220Q327 220 327 250V332" stroke-width=".8"/>'
    elif slug == "808-colpo-libero":
        art = '<path d="M70 350H442M115 350L256 112L397 350Z" stroke-width="2"/><path d="M164 350L256 176L348 350Z" stroke="#bb6849" stroke-width="2"/><path d="M220 350L256 238L292 350Z" stroke-width=".8"/><path d="M256 86V42M240 59L256 42L272 59" stroke="#bb6849" stroke-width="2"/>'
    else:
        art = '<path d="M80 350H432V170Q256 74 80 170Z" stroke-width="2"/><path d="M110 330V190Q256 104 402 190V330" stroke="#5e6286" stroke-width="2"/><path d="M145 318V208Q256 140 367 208V318M180 307V225Q256 174 332 225V307" stroke-width=".8"/><path d="M115 165Q170 126 225 162T335 160T405 162" stroke="#5e6286" stroke-width="1.4"/>'
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="none" stroke="#302a2b" stroke-linecap="round" stroke-linejoin="round"><title>{spec['title']}</title><desc>{desc}</desc><path d="M52 380H460" stroke-width=".8"/>{art}<text x="52" y="438" fill="#6e645e" stroke="none" font-family="sans-serif" font-size="15">SYN · corpo a fondamentale stabile</text></svg>\n'''

def write_patch(slug: str):
    spec = SPECS[slug]
    folder = BANK / slug
    samples = folder / "samples"
    samples.mkdir(parents=True, exist_ok=True)
    regions, proof = [], []
    seed_records = []
    for root in range(LOW, HIGH+1):
        for vlo, vhi, vel in VELOCITIES:
            audio, facts = wave_for(slug, root, vel)
            name = f"r{root}-v{vel}.wav"
            sf.write(samples/name, audio, SR, subtype="PCM_24")
            loop = {"start": facts["loop_start_frame"], "end": facts["loop_end_frame"]}
            regions.append({"file":name,"root":root,"lo":root,"hi":root,"vel":[vlo,vhi],
                            "tune_cents":facts['fine_tune_cents'],"loop":loop})
            facts.update({"file":name,"velocity_range":[vlo,vhi],"authored_velocity":vel,
                          "wav_sha256":hashlib.sha256((samples/name).read_bytes()).hexdigest()})
            proof.append(facts)
            seed_records.append((root,vel))
    (samples/"map.json").write_text(json.dumps(regions,indent=2)+"\n")
    recipe = f'''"""{spec['title']} · originale oscillators, nessun campione di terzi."""
import json
from pathlib import Path
from libero import Sound
P=Path(__file__).parent
MAP=json.loads((P/'samples'/'map.json').read_text())
sound=Sound(title={spec['title']!r},subtitle={spec['subtitle']!r},
 tags=['bass','808','trap','synth','original','proposed-cc0'],roots=list(range({LOW},{HIGH+1})),
 velocities=[56,116],sample_rate={SR},accent={spec['accent']!r})
sound.multisample('body',MAP,as_dyn=True,process={{'tune':'source','ladder':'keep','peak_db':-6,
 'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','max_seconds':None,'end_db':-120,
 'encoding':'flac24','mono':True,'edge_fill':False,'preserve_key_ranges':True}})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,rr_reset_ms=1500,
 humanize={{'cents':0,'ms':0,'db':0}},one_shot=False)
sound.defaults(mode='Poli',glide=0,voices=32,amp_attack=0,amp_decay=10000,amp_sustain=1,
 amp_release=180,vel_sens=.45,dyn_mode='Velocità',master=-13.5,osc_drift=0,
 osc1_level=-60,osc2_level=-60,sub_level=-60,lvl_body=0,lvl_attack=-60,lvl_tail=-60,lvl_air=-60,
 tape_wow=0,tape_flutter=0,tape_sat=0,tape_age=0,tape_mix=0,drive=0,lfo_pitch=0,lfo_amp=0,
 echo_mix=0,rev_mode='Cappella',rev_mix=0,width=0,caldi_mode='Spento')
'''
    (folder/"sound.py").write_text(recipe)
    proof_doc={"method":"Original deterministic Libero synthesis; old Abletunes files used for measurement only and never opened/copied by this builder.",
               "seed_recipe":"sha256('Libero authored 808 v1|slug|midi|velocity|seed-20261003'); first 8 bytes big-endian",
               "seed_recipe_sha256":hashlib.sha256(b"Libero authored 808 v1|slug|midi|velocity|seed-20261003").hexdigest(),
               "all_wav_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(samples.glob("*.wav"))},
               "zones":proof}
    (samples/"design-proof.json").write_text(json.dumps(proof_doc,indent=2)+"\n")
    credits=[{"source":"Original Libero-authored procedural synthesis","author":"Libero sound design session","license":"CC0 1.0 proposed for these original generated assets; not yet published or uploaded","license_class":"cc0","url":"https://creativecommons.org/publicdomain/zero/1.0/","files":[r['file'] for r in regions],"notes":"No third-party audio, Abletunes waveform, transient, noise, IR, or loop is included."}]
    (samples/"credits.json").write_text(json.dumps(credits,indent=2)+"\n")
    (samples/"ATTRIBUTION.md").write_text("# Source and rights\n\nOriginal Libero-authored procedural synthesis. Proposed CC0 1.0 dedication for these generated files; this is a local preparation and is not publication. No external audio bytes are included. Deterministic recipe, per-zone seed, synthesis parameters, and SHA-256 values are in `design-proof.json`. The approved Abletunes sounds were used only for separate reference measurements, never as synthesis input.\n")
    (folder/"figure.svg").write_text(svg_for(slug,spec))
    if validate_svg((folder/"figure.svg").read_text()):
        raise ValueError(f"SVG validation failed: {slug}")
    ref=REFERENCE_MEASUREMENTS[slug]
    (folder/"notes.md").write_text(f'''# {spec['title']}\n\n{spec['subtitle']} · SYN. {spec['design']}\n\nThis patch is authored oscillator synthesis rendered into exact chromatic roots. The attack falls by 12 semitones and reaches a stable body pitch within 180 ms; the held portion loops a generated periodic waveform with fixed fundamental. Soft/hard zones use authored output gains `0.72 + 0.16 × ((velocity−1)/126)` and the per-identity partial formulas in `samples/design-proof.json`; they are not recorded dynamics or round robins. Infinite sustain is synthetic by design; release is the native 180 ms amp release. Defaults are Poli, glide 0, wow/flutter 0, Caldi Spento.\n\n## Technical facts\n\nSee `samples/design-proof.json` for per-zone target/generated f0, bounded source fine tuning, loop coordinates, deterministic seed, amplitude formulas, and generated WAV SHA-256. `samples/credits.json` documents the proposed local CC0 1.0 dedication; there are no third-party samples. The old 808 audio is not included.\n\n## Measurement-only reference\n\nI read `{ref['path']}` in place for numeric measurements only; the old WAV was not copied, transformed, or used by the builder. It is the approved `{ref['preset']}` reference, labelled MIDI {ref['root_midi']}, {ref['duration_s']:.4f}s. On a 0.5–1.5s window the measured dominant fundamental was {ref['measured_f0_hz']:.3f}Hz; 0.5–1.0s RMS was {ref['rms_0_5_1s_dbfs']:.2f}dBFS. Energy shares in the 0.5–1.5s window (20–60 / 60–150 / 150–500Hz) were {ref['band_share_0_5_1_5s']['20_60Hz']:.3f} / {ref['band_share_0_5_1_5s']['60_150Hz']:.3f} / {ref['band_share_0_5_1_5s']['150_500Hz']:.3f}. These readings guided distinct harmonic roles only; no reference waveform, transient, noise, impulse response, or loop entered the replacement. A compact machine-readable record is in `~/Libero/demo/release-replacements-v1/bassi/reference-measurements.json`.\n\n## QA\n\nNative verification: see `~/Libero/demo/release-replacements-v1/bassi/{slug}/verification.json`. Technical measurements do not establish listening preference.\n''')
    result=compile_sound(folder,jobs=1)
    print(slug,result.text(),flush=True)
    if not result.ok: raise RuntimeError(result.text())
    verify_patch(slug, folder)
    return folder

def _rms_db(x):
    return float(20*np.log10(np.sqrt(np.mean(np.asarray(x,dtype=np.float64)**2))+1e-15))

def _pitch_cents(x, sr, target_hz):
    y=np.asarray(x,dtype=np.float64)
    if y.ndim==2:y=y.mean(axis=1)
    y=y-np.mean(y)
    nfft=1<<20
    mag=np.abs(np.fft.rfft(y*np.hanning(len(y)),n=nfft))
    freq=np.fft.rfftfreq(nfft,1/sr)
    lo,hi=np.searchsorted(freq,(target_hz*.94,target_hz*1.06))
    k=lo+int(np.argmax(mag[lo:hi]))
    a,b,c=np.log(np.maximum(mag[k-1:k+2],1e-30))
    d=a-2*b+c
    delta=.5*(a-c)/d if abs(d)>1e-20 else 0
    measured=(k+float(np.clip(delta,-.5,.5)))*sr/nfft
    return 1200*math.log2(measured/target_hz),measured

def _partial_profile(x, sr, target_hz, start=10.0, duration=1.0, count=12):
    y=np.asarray(x[int(start*sr):int((start+duration)*sr)],dtype=np.float64).mean(axis=1)
    y-=np.mean(y);nfft=1<<20
    mag=np.abs(np.fft.rfft(y*np.hanning(len(y)),n=nfft));freq=np.fft.rfftfreq(nfft,1/sr)
    amps=[]
    for k in range(1,count+1):
        center=k*target_hz;lo,hi=np.searchsorted(freq,(center*.988,center*1.012))
        amps.append(float(np.max(mag[lo:hi])) if hi>lo else 0.0)
    ref=max(amps[0],1e-30)
    return {str(k):round(20*math.log10(max(a,1e-30)/ref),2) for k,a in enumerate(amps,1)}

def _render(slug, folder, path, notes, tail=.25, params=None):
    path.parent.mkdir(parents=True,exist_ok=True)
    render.render(folder,path,notes,params or {'rev_mix':0,'lvl_tail':-60,'lvl_air':-60,'lvl_attack':-60},tail=tail,sr=SR)
    x,sr=sf.read(path,always_2d=True,dtype='float64')
    return x,sr

def _save_flac(wav_path, x, sr):
    flac_path=wav_path.with_suffix('.flac')
    sf.write(flac_path,x,sr,subtype='PCM_24')
    wav_path.unlink()
    return flac_path

def verify_patch(slug, folder):
    from libero import Audio, analysis
    spec=SPECS[slug]; out=OUT/slug; out.mkdir(parents=True,exist_ok=True)
    findings=lint_bundle(folder/'build')
    fails=[f.line() for f in findings if f.level=='FAIL']
    warns=[f.line() for f in findings if f.level=='WARN']
    warn_explanations=[]
    for warning in warns:
        if 'brightness' in warning:
            warn_explanations.append({'warning':warning,
              'explanation':'Intentional authored dynamics: both zones keep one recognizable 808 spectrum while the higher layer adds level and small partial-specific changes; no separate instrument/articulation is claimed.'})
        else:
            warn_explanations.append({'warning':warning,'explanation':'See the source-specific note below.'})
    (folder/'lint.txt').write_text('\n'.join(f.line() for f in findings)+'\n')
    if fails: raise AssertionError(f'{slug}: lint FAIL: {fails}')
    source_now=source_hash(folder)
    manifest=json.loads((folder/'build'/'manifest.json').read_text())
    if source_now!=manifest['source_hash']: raise AssertionError(f'{slug}: stale compiled source')
    # Full chromatic native sweep, including both declared keyboard edges.
    chromatic=[(n,i*.52,.41,116) for i,n in enumerate(range(LOW,HIGH+1))]
    xp,sr=_render(slug,folder,out/'chromatic-native.wav',chromatic,tail=.2)
    pitch_rows=[]
    for i,n in enumerate(range(LOW,HIGH+1)):
        start=i*.52+.225
        a,b=round(start*sr),round((start+.16)*sr)
        target=440*2**((n-69)/12)
        cents,hz=_pitch_cents(xp[a:b],sr,target)
        pitch_rows.append({'midi':n,'expected_hz':target,'measured_hz':hz,'cents':cents})
    max_cents=max(abs(r['cents']) for r in pitch_rows)
    _save_flac(out/'chromatic-native.wav',xp,sr)
    if max_cents>5: raise AssertionError(f'{slug}: native chromatic pitch residual {max_cents:.3f}c')
    # Sixty-second held tests in low, middle and high bass registers. Each independently
    # confirms late energy and held-body pitch after many actual loop wraps.
    holds=[]
    for n in (24,36,48):
        wav=out/f'hold-{n}-60s.wav'
        x,sr=_render(slug,folder,wav,[(n,0,60,116)],tail=1.0)
        windows=[]
        for start in (10,20,30,40,50,58):
            seg=x[int(start*sr):int((start+1)*sr)]
            windows.append({'start_s':start,'rms_dbfs':_rms_db(seg)})
        target=440*2**((n-69)/12)
        pitch_checks=[]
        for start in (10.0,30.0,58.0):
            cents,hz=_pitch_cents(x[int(start*sr):int((start+.8)*sr)],sr,target)
            pitch_checks.append({'start_s':start,'hz':hz,'cents':cents})
        late_min=min(r['rms_dbfs'] for r in windows)
        if late_min<=-50: raise AssertionError(f'{slug} midi {n}: held body below -50dBFS ({late_min:.1f})')
        if max(abs(r['cents']) for r in pitch_checks)>5: raise AssertionError(f'{slug} midi {n}: hold pitch drift')
        flac=_save_flac(wav,x,sr)
        holds.append({'midi':n,'file':flac.name,'held_duration_s':60,'late_rms_windows':windows,
                      'held_pitch':pitch_checks,'peak_dbfs':20*math.log10(np.max(np.abs(x))+1e-15),
                      'clipped_samples':int(np.count_nonzero(np.abs(x)>=1)),
                      **({'native_steady_body_partials_db_relative_to_f0':_partial_profile(x,sr,target)} if n==36 else {})})
    # Phrase demonstrates soft/loud, repeated notes, low/mid/high, octave movement and note-off.
    phrase=[(24,0,.55,40),(24,.72,.55,116),(24,1.42,.22,127),(24,1.72,.22,96),
            (36,2.12,.8,78),(43,3.05,.65,105),(48,3.85,.8,127),(60,4.78,.65,100)]
    x,sr=_render(slug,folder,out/'phrase-native.wav',phrase,tail=1)
    peak=20*math.log10(np.max(np.abs(x))+1e-15)
    if not np.isfinite(x).all() or peak>=0: raise AssertionError(f'{slug}: phrase clipped or nonfinite')
    phrase_flac=_save_flac(out/'phrase-native.wav',x,sr)
    (out/'phrase-spectrogram.png').write_bytes(analysis.spectrogram(Audio(x.astype(np.float32),sr),fmin=20,fmax=5000,title=spec['title']+' · native phrase'))
    chord_rows=[]
    chord_keys=(24,28,31,36,40,43,48,52)
    chord_cases=[('v100-default',100,{}),('v127-default',127,{}),
                 ('max-dynamics-knob',100,{'dyn_mode':'Manopola','dynamics':1.0})]
    for label,velocity,overrides in chord_cases:
        events=[(n,0,3,velocity) for n in chord_keys]
        wav=out/f'chord-8notes-{label}.wav'
        params={'rev_mix':0,'lvl_tail':-60,'lvl_air':-60,'lvl_attack':-60,**overrides}
        cx,csr=_render(slug,folder,wav,events,tail=.2,params=params)
        cpeak=20*math.log10(np.max(np.abs(cx))+1e-15)
        if cpeak>-3.0: raise AssertionError(f'{slug}: 8-note v{velocity} headroom {cpeak:.2f} dBFS')
        flac=_save_flac(wav,cx,csr)
        chord_rows.append({'test':label,'velocity':velocity,'overrides':overrides,'midi_notes':list(chord_keys),'file':flac.name,
                           'peak_dbfs':cpeak,'rms_dbfs':_rms_db(cx),
                           'clipped_samples':int(np.count_nonzero(np.abs(cx)>=1))})
    report={'slug':slug,'title':spec['title'],'route':'808 bass · SYN, deterministic original oscillator synthesis',
      'source_integrity':{'third_party_audio_files':0,'Abletunes_audio_bytes_included':False,
        'authored_zones':len(manifest['zones']),'roots':list(range(LOW,HIGH+1)),
        'velocity_regions':2,'build_source_hash':manifest['source_hash'],'current_source_hash':source_now,
        'source_fresh':source_now==manifest['source_hash'],
        'velocity_model':{'overall_gain':'0.72 + 0.16*((authored_velocity-1)/126)','partial_modulation':'See per-zone design-proof.json; partial weights H2/H3 vary by family.'},
        'sample_sha256':json.loads((folder/'samples'/'design-proof.json').read_text())['all_wav_sha256']},
      'native_chromatic':{'note_count':len(pitch_rows),'range':[LOW,HIGH],'max_abs_cents':max_cents,
                          'per_note':pitch_rows},
      'native_holds':holds,'eight_note_chords':chord_rows,
      'phrase':{'file':phrase_flac.name,'notes':phrase,'peak_dbfs':peak,'rms_dbfs':_rms_db(x),
                'duration_s':len(x)/sr,'clipped_samples':int(np.count_nonzero(np.abs(x)>=1))},
      'lint':{'fail_count':len(fails),'warnings':warns,'warning_explanations':warn_explanations},
      'taste_claim':'No listening or perceptual quality claim; report is technical QA only.'}
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'figure.png').write_bytes(rasterize((folder/'figure.svg').read_text(),512))
    with (folder/'notes.md').open('a') as f:
        f.write('\n## Native QA\n\n')
        f.write(f"Build is source-fresh: `{source_now}`. Native chromatic range {LOW}–{HIGH}: maximum measured pitch residual {max_cents:.3f} cents. Three 60 s holds remained above −50 dBFS in every late window and stayed within 5 cents. Eight-note chord peaks (velocity default 100 / velocity maximum 127 / dynamics knob maximum): "+', '.join(f"{r['test']} = {r['peak_dbfs']:.2f} dBFS" for r in chord_rows)+". Lint: 0 FAIL.\n\n")
        f.write('Warnings: '+('; '.join(warns) if warns else 'none')+'. Brightness warning explanation: the two zones intentionally preserve one 808 spectrum, with the upper zone adding level and small partial-specific changes rather than a different instrument or articulation. Each sample loop is an authored periodic oscillator cycle, not a recorded performance. See demo/release-replacements-v1/bassi for the chromatic render, long holds, phrase, chord previews, and structured QA report. Measurements do not certify listening preference.\n')
    print(slug,'native QA PASS; pitch max',max_cents,'c; chords',[(r['velocity'],round(r['peak_dbfs'],2)) for r in chord_rows],flush=True)

if __name__ == '__main__':
    selected=sys.argv[1:] or list(SPECS)
    unknown=set(selected)-set(SPECS)
    if unknown: raise SystemExit(f"unknown slugs: {sorted(unknown)}")
    OUT.mkdir(parents=True,exist_ok=True)
    for slug in selected: write_patch(slug)
    verified=[]
    for slug,spec in SPECS.items():
        report=OUT/slug/'verification.json'
        if not report.is_file(): break
        data=json.loads(report.read_text())
        verified.append({'slug':slug,'title':spec['title'],'verification_file':f'{slug}/verification.json',
          'source_fresh':data['source_integrity']['source_fresh'],
          'zones':data['source_integrity']['authored_zones'],
          'max_native_pitch_error_cents':data['native_chromatic']['max_abs_cents'],
          'minimum_60s_hold_window_dbfs':min(w['rms_dbfs'] for h in data['native_holds'] for w in h['late_rms_windows']),
          'maximum_8note_chord_peak_dbfs':max(c['peak_dbfs'] for c in data['eight_note_chords']),
          'lint_fail_count':data['lint']['fail_count'],'warnings':data['lint']['warnings']})
    if len(verified)==len(SPECS):
        aggregate={'collection':'Original Libero 808 replacements · v1','presets':verified,
          'references':'Numerical measurement only; see reference-measurements.json. No source audio copied.',
          'rights':'Original generated audio; local proposed CC0 1.0 dedication; no external audio sources.',
          'installation':'Three new folders only; existing 808 folders and banks/bassi/bank.json are not changed.'}
        (OUT/'report.json').write_text(json.dumps(aggregate,indent=2)+'\n')
        (OUT/'README.md').write_text('''# Original 808 replacements · technical preview\n\nThree new original oscillator-designed presets are in `~/Libero/banks/bassi/*-libero`. Each contains a 40-key exact chromatic map (A0–C4), two authored velocity regions, source/seed/hash proof, proposed local CC0 credits, notes, and an original SVG. The old approved 808 samples were read in place for numeric reference measurements only; no bytes from them entered the generated sounds or this demo.\n\nEvery preset has an individual `verification.json`, a native phrase and spectrogram, a native chromatic sweep, 60-second holds at three registers, and eight-note chord renders at default/high velocity and maximum dynamics-knob settings. `report.json` is the compact aggregate. Technical checks do not establish listening preference.\n''')
