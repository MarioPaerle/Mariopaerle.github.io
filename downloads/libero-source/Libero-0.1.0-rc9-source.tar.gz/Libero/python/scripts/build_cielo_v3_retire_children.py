"""Archive the rejected field-choir preset without deleting its samples."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil

BANK = Path.home() / 'Libero/banks/cielo'
ARCHIVE = Path.home() / 'Libero-backups/2026-10-02/cielo-v3-rejected-children'


def hashes(folder):
    return {str(p.relative_to(folder)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in folder.rglob('*') if p.is_file()}


def retire():
    child = BANK / 'voci-bianche-sillabe'
    if not child.exists() or ARCHIVE.exists():
        raise RuntimeError('Refusing missing source or existing archive')
    before = hashes(child)
    ARCHIVE.mkdir(parents=True)
    for name in ['bank.json', 'README.md', 'SOURCE-SEARCH.md']:
        shutil.copy2(BANK / name, ARCHIVE / name)
    destination = ARCHIVE / child.name
    shutil.move(str(child), destination)
    assert before == hashes(destination)
    meta = json.loads((BANK / 'bank.json').read_text())
    meta.update(version='2.1.0', subtitle='sette candidati vocali · campioni reali',
                description='Voci femminili e maschili, coro misto per sezioni, trillo cantato e una frase originale di sovraincisioni. Ah/Eh/Oh sono articolazioni. I bambini sono in attesa di una nuova fonte musicale; il precedente preset è stato ritirato dopo il feedback.',
                updated=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'))
    (BANK / 'bank.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n')
    readme = (BANK / 'README.md').read_text()
    readme = readme.replace('Otto identità,', 'Sette candidati,')
    readme = readme.replace('- **Voci bianche · sillabe**: il coro di bambini in chiesa resta identico alla versione precedente, rumori e triangolo compresi.\n', '')
    readme = readme.replace('sono bocciate e in attesa', 'sono bocciate e archiviate fuori dalla banca attiva, in attesa')
    readme = readme.replace('Ellen e isohoo CC0', 'Ellen CC0')
    readme = readme.replace('Gli otto strumenti', 'I sette strumenti')
    readme += '\nIl preset infantile bocciato è conservato integralmente in ~/Libero-backups/2026-10-02/cielo-v3-rejected-children/voci-bianche-sillabe. Nessun preset vuoto lo sostituisce.\n'
    (BANK / 'README.md').write_text(readme)
    search = (BANK / 'SOURCE-SEARCH.md').read_text()
    search = search.replace('La texture originale rimane identica,', 'Preset ritirato fuori dalla banca attiva dopo il feedback. La texture archiviata rimane identica,')
    search += '\nNuova ricerca bambini: [_reports/v3-children/RICERCA.md](_reports/v3-children/RICERCA.md). Fonte non ancora acquisita; nessun adulto processato è etichettato bambino.\n'
    (BANK / 'SOURCE-SEARCH.md').write_text(search)
    report = BANK / '_reports/v3-children'
    audit = (report / 'RICERCA.md').read_text()
    audit = audit.replace('già installate', 'ora archiviate fuori dalla banca attiva')
    audit = audit.replace('Questa tensione non è risolta: non assumere automaticamente che una nuova compilazione Libero sia autorizzata.', 'Escluso dal percorso attuale: la tensione non è risolta e il divieto esplicito di processing/recompilazione, anche in processi AI, non permette di assumere autorizzata la compilazione Libero.')
    (report / 'RICERCA.md').write_text(audit)
    (report / 'retirement.json').write_text(json.dumps({'archive': str(destination), 'files': len(before), 'byte_identical': True, 'hashes': before}, indent=2) + '\n')
    print(json.dumps({'active': sorted(p.name for p in BANK.iterdir() if (p / 'sound.py').exists()), 'archive': str(destination), 'files_preserved': len(before)}))


if __name__ == '__main__':
    retire()
