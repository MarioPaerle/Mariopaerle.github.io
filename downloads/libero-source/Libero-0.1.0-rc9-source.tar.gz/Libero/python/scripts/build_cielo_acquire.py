"""Acquire exactly the licensed VocalSet natural long-tone subset used by Cielo.
Primary licence/provenance: https://zenodo.org/records/1442513 (CC BY 4.0).
Pinned mirror allows a selective download instead of fetching the 2.1GB corpus.
"""
import concurrent.futures, json, urllib.request, time, zipfile, hashlib
from pathlib import Path
ROOT=Path.home()/'Libero/cache/research/cielo'
REV='9763b3439b6034b797a6f2cd8118b8842a430c2f'
DEST=ROOT/'vocalset'

def acquire(singer):
    url=f'https://huggingface.co/api/datasets/stemsai/vocalset/tree/{REV}/VocalSet/FULL/{singer}/long_tones?recursive=true&limit=1000'
    entries=json.loads(urllib.request.urlopen(url,timeout=60).read())
    entries=[e for e in entries if e['type']=='file' and e['path'].endswith(('_a.wav','_e.wav','_o.wav')) and any('/'+k+'/' in e['path'] for k in ['forte','pp','straight','messa'])]
    (ROOT/f'vocalset-{singer}-listing.json').write_text(json.dumps(entries,indent=2))
    for e in entries:
        dst=DEST/e['path'].removeprefix('VocalSet/FULL/');dst.parent.mkdir(parents=True,exist_ok=True)
        expected=e.get('lfs',{}).get('oid')
        if dst.exists() and dst.stat().st_size==e['size'] and (not expected or hashlib.sha256(dst.read_bytes()).hexdigest()==expected):continue
        for attempt in range(4):
            try:
                u=f'https://huggingface.co/datasets/stemsai/vocalset/resolve/{REV}/'+e['path']
                tmp=dst.with_suffix('.part');urllib.request.urlretrieve(u,tmp)
                if tmp.stat().st_size!=e['size']: raise ValueError('size differs')
                if expected and hashlib.sha256(tmp.read_bytes()).hexdigest()!=expected:raise ValueError('pinned source hash differs')
                tmp.replace(dst);break
            except Exception:
                if attempt==3: raise
                time.sleep(2)
    print(singer,len(entries),sum(e['size'] for e in entries),flush=True)
    return entries

if __name__=='__main__':
    ROOT.mkdir(parents=True,exist_ok=True)
    metadata=json.loads(urllib.request.urlopen('https://zenodo.org/api/records/1442513',timeout=60).read())
    if metadata['metadata']['license']['id']!='cc-by-4.0':raise RuntimeError('Unexpected source license')
    (ROOT/'vocalset-primary.json').write_text(json.dumps(metadata,indent=2))
    if not (ROOT/'children.mp3').exists():
        urllib.request.urlretrieve('https://cdn.freesound.org/previews/512/512975_10829062-hq.mp3',ROOT/'children.mp3')
    urllib.request.urlretrieve('https://freesound.org/people/isohoo/sounds/512975/',ROOT/'children-freesound.html')
    singers=[f'female{i}' for i in range(1,10)]+[f'male{i}' for i in range(1,12)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
        entries=sum(list(ex.map(acquire,singers)),[])
    (ROOT/'vocalset-acquisition.json').write_text(json.dumps({'primary':'https://zenodo.org/records/1442513','license':'CC BY 4.0','mirror_revision':REV,'files':entries},indent=2))

    archive=ROOT/'VocalSet11.zip'
    if archive.exists():
        with zipfile.ZipFile(archive) as z:
            names=z.namelist();bad=[]
            for e in entries:
                suffix=e['path'].removeprefix('VocalSet/FULL/')
                match=[n for n in names if n.endswith('/'+suffix)]
                if len(match)!=1 or hashlib.sha256(z.read(match[0])).digest()!=hashlib.sha256((DEST/suffix).read_bytes()).digest():bad.append(suffix)
            (ROOT/'mirror-primary-validation.json').write_text(json.dumps({'verified_files':len(entries)-len(bad),'errors':bad},indent=2))
            if bad:raise RuntimeError('Primary/mirror sample hashes differ')
