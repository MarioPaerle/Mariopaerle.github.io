"""Twelve distinct original Green synths, including four continuous live designs.

Only new Green folders are touched. Authored electronic velocity layers are not
claimed as recorded performances. The stereo body is generated at source, with
a shared low register; effects are optional. No engine changes are needed.
"""
from pathlib import Path
import argparse, hashlib, json, math, sys
import numpy as np
import soundfile as sf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, library, render, analysis
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero.figure import validate_svg, rasterize

SR=48000; PERIOD=24; ROOTS=[36,43,50,57,64,71,78,85]
BANK=Path.home()/'Libero/banks/green';OUT=Path.home()/'Libero/demo/green-v6'
DESIGNS={
 'cedro-lead':('Cedro','lead analogico · centro solido, bordo seghettato',3,250,'live'),
 'miele-pulse':('Miele','impulsi larghi · triangolo centrale e PWM',18,650,'live'),
 'ottone-verde':('Ottone Verde','brass sintetico · attacco gonfio e registro pieno',38,500,'live'),
 'bosco-largo':('Bosco Largo','pad di corde elettroniche · sette seghe e centro morbido',520,1300,'live'),
 'giada-fase':('Giada','lead di fase · cosine deformate, gesto elastico',6,320,'phase'),
 'ambra-fm':('Ambra','lead FM · due portanti, corpo vellutato',12,550,'fm'),
 'canneto-elettrico':('Canneto Elettrico','synth di ance · registri pari e dispari, aria spettrale',70,720,'reed'),
 'prisma-morbido':('Prisma Morbido','morph synth · tre profili periodici in movimento',180,850,'morph'),
 'seta-spettrale':('Seta Spettrale','pad armonico · registri mobili e bordi aperti',650,1400,'spectral'),
 'resina-sync':('Resina','lead sync · morso armonico e fondamentale stabile',4,300,'sync'),
 'aurora-vetro':('Aurora di Vetro','pad FM · campane elettroniche su corpo morbido',380,1200,'glass'),
 'muscolo-basso':('Muscolo','bass synth e lead basso · corpo compatto e cresta mobile',5,260,'bass'),
}

def table(kind,f,v,variant=0):
    """A band-limited single-cycle shape, not a shared pad spectrum."""
    n=4096;p=np.arange(n)/n;ph=2*np.pi*p
    if kind=='phase':
        duty=.22+.11*v+.045*variant
        warp=np.where(p<duty,.5*p/duty,.5+.5*(p-duty)/(1-duty))
        wave=-np.cos(2*np.pi*warp)+.24*np.sin(4*np.pi*warp)+.14*np.sin(6*np.pi*warp)+.18*np.sin(ph)
    elif kind=='reed':
        wave=np.zeros(n)
        for k in range(1,min(90,int(14000/f))+1):
            hz=k*f
            form=1+2.2*np.exp(-.5*((hz-(700+variant*240))/280)**2)
            form+=1.6*np.exp(-.5*((hz-1700)/600)**2)
            form+=.75*np.exp(-.5*((hz-3100)/950)**2)
            a=(1 if k%2 else .48+.28*v)*form/k**1.05
            wave+=a*np.sin(k*ph+.12*k)
    elif kind=='spectral':
        wave=np.zeros(n)
        for k in range(1,min(90,int(14000/f))+1):
            hz=k*f
            # Two independent spectral registers, rather than another saw-like
            # 1/k string spectrum. Velocity opens the upper band at its source.
            form=.55+1.4*np.exp(-.5*((hz-(880+variant*200))/330)**2)
            form+=.90*np.exp(-.5*((hz-(2600+variant*300))/600)**2)
            parity=1.0 if k%2==0 else .38+.24*v
            a=form*parity*(1+.55*np.cos(.87*k+.6*variant))*np.exp(-(hz/(4200+2500*v))**2)/k**.90
            wave+=a*np.sin(k*ph+.23*k*k)
    elif kind=='sync':
        ratio=2.25+1.35*v+.55*variant
        wave=np.sin(ratio*ph+.16*np.sin(ph))*(.8+.2*np.cos(ph))
        wave+=.65*np.sin(ph)  # master clock is the musical pitch
    elif kind=='bass':
        wave=np.tanh((1.1+1.4*v)*(np.sin(ph)+.28*np.sin(2*ph)))
        wave+=.22*np.sin(3*ph+.8)+.10*np.sin(4*ph+.3)
    elif kind=='pulse':
        wave=np.where(p<.31+.04*variant,1.,-1.)
    elif kind=='triangle':
        wave=1-4*np.abs(p-.5)
    else:
        wave=2*p-1
    spec=np.fft.rfft(wave);spec[0]=0
    k=np.arange(len(spec));hz=k*f
    # Smooth upper cutoff and a hard Nyquist margin; remove phase-function
    # discontinuities before sampling the waveform at instrument frequencies.
    cutoff=9000 if kind in {'sync','reed'} else 7500
    spec*=np.exp(-(hz/cutoff)**4);spec[hz>12000]=0
    wave=np.fft.irfft(spec,n=n)
    wave/=max(np.sqrt(np.mean(wave*wave)),1e-12)
    return np.r_[wave,wave[0]]

def sample(tab,phase):
    n=len(tab)-1;u=np.remainder(phase,1)*n;i=u.astype(np.int32);a=u-i
    return tab[i]*(1-a)+tab[i+1]*a

def authored(slug,key,velocity):
    kind=DESIGNS[slug][4];v=(velocity-1)/126
    count=int((PERIOD+3)*SR);t=np.arange(count)/SR
    actual=440*2**((key-69)/12);f=round(actual*PERIOD)/PERIOD
    phase=f*t;ph=2*np.pi*phase;m=2*np.pi*t/PERIOD
    if kind=='fm':
        index=1.65+1.25*v+.32*np.sin(m)
        core=.35*np.sin(ph)+.58*np.sin(ph+index*np.sin(2*ph))
        core+=.24*np.sin(2*ph+.55*np.sin(3*ph))+.12*np.sin(3*ph+.28*np.sin(ph))
        left=.27*np.sin(2*np.pi*(f+3/PERIOD)*t+.48*np.sin(2*ph+m))
        right=.27*np.sin(2*np.pi*(f-3/PERIOD)*t+.48*np.sin(2*ph-m))
    elif kind=='glass':
        # A harmonic musical centre; inharmonic bell components stay subordinate
        # and change together with periodic FM, never a frozen major/minor chord.
        core=.38*np.sin(ph)+.54*np.sin(ph+(.75+1.05*v)*np.sin(2*ph))
        core+=.24*np.sin(2*ph+(.45+.35*v)*np.sin(ph+m))+.14*np.sin(3*ph+.30*np.sin(ph))
        fbell=round(2.76*f*PERIOD)/PERIOD
        bell=.23+.27*v
        left=bell*np.sin(2*np.pi*fbell*t+(.35+.40*v)*np.sin(4*ph+m))
        right=bell*np.sin(2*np.pi*(fbell+2/PERIOD)*t+(.35+.40*v)*np.sin(4*ph-m))
        left*=.8+.2*np.sin(2*m);right*=.8+.2*np.cos(2*m)
    elif kind=='morph':
        a=sample(table('triangle',f,v),phase)
        b=sample(table('saw',f,v),phase)
        c=sample(table('pulse',f,v),phase)
        mix=.5+.22*np.sin(m)
        core=.28*a+.48*mix*b+.45*(1-mix)*c-.24*np.cos(ph)
        core+=.20*np.sin(2*ph)+.14*np.cos(3*ph)
        left=.28*sample(table('pulse',f,v,1),phase+2*t/PERIOD+.03*np.sin(2*m))
        right=.28*sample(table('saw',f,v),phase-2*t/PERIOD-.03*np.sin(2*m))
    else:
        a=sample(table(kind,f,v,0),phase)
        b=sample(table(kind,f,v,1),phase)
        morph=.5+.18*np.sin((2 if kind=='spectral' else 1)*m)
        core=.82*((1-morph)*a+morph*b)+.16*np.sin(ph)
        if kind=='bass':
            left=.25*np.sin(2*ph+2*m)+.10*np.sin(5*ph+.2*np.sin(m))
            right=.25*np.sin(2*ph-2*m)+.10*np.sin(5*ph-.2*np.sin(m))
        else:
            # Use two different edge carriers, rather than a delayed copy of a
            # mono source. The centre remains common and dominant in the bass.
            left=.32*sample(table(kind,f,v,1),phase+2*t/PERIOD+.035*np.sin(2*m))
            right=.32*sample(table(kind,f,v,-1),phase-2*t/PERIOD-.035*np.sin(2*m))
    x=np.column_stack([core+left,core+right])
    # Periodic FFT suppresses the edge component below 180 Hz. Render exactly one
    # steady cycle and tile it with its note-on timeline, then add the unique entry.
    a0=2*SR;n=PERIOD*SR;cycle=x[a0:a0+n].copy()
    mid=cycle.mean(1);side=(cycle[:,0]-cycle[:,1])/2
    bins=np.fft.rfftfreq(n,1/SR);sp=np.fft.rfft(side)
    sp*=1-np.exp(-(bins/180)**4)
    side=np.fft.irfft(sp,n=n)
    # Source-generated stereo, with a solid shared low register. Widen the
    # harmonic edges while retaining the exact mono body; a bass role uses less.
    side*=1.4 if kind=='bass' else (2.3 if kind=='glass' else 1.8)
    cycle=np.column_stack([mid+side,mid-side])
    x=cycle[(np.arange(count)-a0)%n].copy()
    # Separate authored velocity level and spectral excitation, not fake takes.
    x*=.18+.11*v
    if kind in {'phase','sync','fm','bass'}:
        env=np.exp(-t/.14);env[t>1.3]=0
        x+=.055*v*np.sin(2*ph+1.4*np.exp(-t/.13)*np.sin(3*ph))[:,None]*env[:,None]
    x[:384]*=np.linspace(0,1,384)[:,None]
    tune=1200*math.log2(actual/f)
    return x,{'start':2*SR,'end':(PERIOD+2)*SR},tune

AUTHORED_MASTERS={'ambra-fm':-2.95,'canneto-elettrico':.34,'aurora-vetro':-3.69}

LIVE={
 'cedro-lead':dict(osc1_wave='Sega',osc1_level=-17,osc1_voices=1,osc1_detune=0,osc1_spread=0,
    osc2_wave='Triangolo',osc2_level=-24,osc2_voices=3,osc2_detune=.23,osc2_spread=.85,
    flt_cutoff=3700,flt_env=.14,fenv_attack=3,fenv_decay=650,fenv_sustain=.28,lfo_rate=.12,lfo_cutoff=.025),
 'miele-pulse':dict(osc1_wave='Quadra',osc1_level=-22,osc1_pw=.32,osc1_voices=5,osc1_detune=.24,osc1_spread=.95,
    osc2_wave='Triangolo',osc2_level=-14,osc2_voices=1,osc2_detune=0,osc2_spread=0,
    flt_cutoff=4300,flt_env=.09,fenv_attack=25,fenv_decay=850,fenv_sustain=.42,lfo_rate=.16,lfo_pw=.14,lfo_cutoff=.035),
 'ottone-verde':dict(osc1_wave='Sega',osc1_level=-21,osc1_voices=3,osc1_detune=.13,osc1_spread=.8,
    osc2_wave='Quadra',osc2_level=-22,osc2_pw=.43,osc2_voices=1,osc2_detune=0,osc2_spread=0,
    flt_cutoff=3100,flt_env=.26,fenv_attack=40,fenv_decay=550,fenv_sustain=.30,lfo_rate=.105,lfo_pw=.025),
 'bosco-largo':dict(osc1_wave='Sega',osc1_level=-23,osc1_voices=7,osc1_detune=.32,osc1_spread=.95,
    osc2_wave='Triangolo',osc2_level=-19,osc2_voices=1,osc2_detune=0,osc2_spread=0,
    flt_cutoff=4800,flt_env=.07,fenv_attack=650,fenv_decay=1800,fenv_sustain=.5,lfo_rate=.071,lfo_cutoff=.06),
}

# Final live designs after listener feedback; separate module owns the four recipes.
from green_live_v2_design import LIVE_V2
LIVE.update(LIVE_V2)

def figure(slug):
    index=list(DESIGNS).index(slug);title,subtitle,*_=DESIGNS[slug]
    shapes=['<path d="M86 351H426V396H86Z" fill="#f3eee6" stroke-width="1.2"/>']
    for i in range(14):shapes.append(f'<path d="M{100+23*i} 360V389" stroke-width=".6"/>')
    for band in range(3):
        points=[]
        for i in range(81):
            x=90+i*4.1;y=190+band*45+22*math.sin(i*(.18+.013*index)+band*.75)*math.cos(i*.027*index)
            points.append(f'{x:.1f},{y:.1f}')
        shapes.append('<polyline points="'+' '.join(points)+'" stroke="'+('#658765'if band==1 else 'currentColor')+'" stroke-width="'+('1.8'if band==1 else '.8')+'"/>')
    shapes+=['<path d="M256 113V337" stroke="#b8924f" stroke-width="1.1"/>',f'<circle cx="256" cy="{140+index*10}" r="{13+index}" stroke-width=".9"/>']
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="none" stroke="currentColor" stroke-linecap="round"><title>'+title+'</title><desc>'+subtitle+'; asse centrale stabile e registri stereo laterali.</desc>'+''.join(shapes)+'</svg>'

def build(slug):
    title,subtitle,attack,release,kind=DESIGNS[slug];p=BANK/slug;s=p/'samples';s.mkdir(parents=True,exist_ok=True)
    proof=[];rows=[]
    if kind!='live':
        for key in ROOTS:
            for lo,hi,vel in [(1,79,50),(80,127,110)]:
                x,lp,tune=authored(slug,key,vel);name=f'{key}-{vel}.flac';sf.write(s/name,x,SR,subtype='PCM_24')
                rows.append({'file':name,'root':key,'vel':[lo,hi],'take':0,'tune_cents':round(tune,5),'loop':lp})
                proof.append({'file':name,'root':key,'authored_velocity':vel,'tune_cents':tune,'period_s':PERIOD,
                    'sha256':hashlib.sha256((s/name).read_bytes()).hexdigest(),'mechanism':kind,'recorded_takes':0})
        (s/'map.json').write_text(json.dumps(rows,indent=2)+'\n')
    defaults=dict(mode='Poli',glide=0,voices=16,amp_attack=attack,amp_decay=10000,amp_sustain=1,
        amp_release=release,master=AUTHORED_MASTERS.get(slug,-5),vel_sens=.36,humanize=0,
        osc1_level=-60,osc2_level=-60,sub_level=-60,osc_drift=.035,osc_retrig='Libera',
        osc1_phase=0,osc2_phase=0,osc1_fine=0,osc2_fine=0,lvl_body=0 if rows else -60,
        lvl_air=-60,lvl_attack=-60,lvl_tail=-60,drive=.025 if kind=='live' else 0,
        flt_mode='Basso',flt_cutoff=14000,flt_reso=.065,flt_key=.50,flt_vel=.13,flt_env=0,
        fenv_source='Propria',fenv_release=release,lfo_shape='Seno',lfo_pitch=0,lfo_amp=0,
        tape_wow=0,tape_flutter=0,tape_mix=0,tape_sat=0,res_mix=0,echo_mix=0,rev_mix=.035,
        rev_decay=1.05,rev_damp=.65,width=1,caldi_mode='Spento')
    defaults.update(LIVE.get(slug,{}))
    recipe=f'from pathlib import Path\nimport json\nfrom libero import Sound\nsound=Sound(title={title!r},subtitle={subtitle!r},tags=["green","synth","warm","wide","infinite",{kind!r}],roots={ROOTS!r})\n'
    if rows:
        recipe+='sound.multisample("body",json.loads((Path(__file__).parent/"samples/map.json").read_text()),as_dyn=False,process={"tune":"source","ladder":"keep","peak_db":-12,"align_ms":0,"pre_ms":0,"loop":"source","max_seconds":None,"end_db":-100,"encoding":"flac24","edge_fill":True})\n'
    recipe+='sound.performance(dynamics_source="velocity",dyn_crossfade=0,humanize={"cents":0,"ms":0,"db":0})\n'
    recipe+='sound.defaults(**'+repr(defaults)+')\n';(p/'sound.py').write_text(recipe)
    (s/'design-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    (s/'credits.json').write_text(json.dumps([{'source':'Original Libero Green synthesis','license':'CC0 1.0','license_class':'cc0','author':'Libero sound design session','url':'https://creativecommons.org/publicdomain/zero/1.0/','files':[r['file']for r in rows]}],indent=2)+'\n')
    svg=figure(slug);assert not validate_svg(svg);(p/'figure.svg').write_text(svg)
    (p/'notes.md').write_text(f'# {title}\n\nEpic rap / soul · lead, synth or pad · SYN. {subtitle}.\n\nOriginal electronic design, CC0; no acoustic performance is claimed. Mechanism: {kind}. '+
        ('Continuous live band-limited oscillators; source unison supplies width. 'if kind=='live'else 'Band-limited authored waveforms; common musical centre and independent upper edge carriers. Explicit 24 s periodic body after a single note-on entry. '+
        'Harmonic/body-rich revision after listener feedback: stronger mechanism-specific inner partials and less dominant sine anchor; source side register below 180 Hz is suppressed before encoding; soft/hard are authored excitation layers, not recorded velocity takes. ')+
        'No wow, flutter, delay or generated noise carpet. Small optional room. Defaults remain polyphonic and glide zero; sustain holds until MIDI note-off. Technical measurements do not certify listening preference.\n')
    c=compile_sound(p,jobs=2);print(slug,c.text(),flush=True)
    if not c.ok:raise RuntimeError(c.text())

def db(x):return float(20*np.log10(np.sqrt(np.mean(np.asarray(x,dtype=float)**2))+1e-20))

def qa(slug):
    p=BANK/slug;out=OUT/slug;out.mkdir(parents=True,exist_ok=True);stats=[]
    findings=lint_bundle(p/'build');fails=[f.line()for f in findings if f.level=='FAIL']
    (p/'lint.txt').write_text('\n'.join(f.line()for f in findings)+'\n')
    if fails:raise RuntimeError(slug+' lint: '+str(fails))
    for name,notes,tail in [
        ('phrase','48:0:.3:45,55:.45:.45:80,60:1.1:.6:115,63:1.85:.4:95,67:2.55:.8:110,60:3.8:3:95',1.8),
        ('chord','48:0:4:120,55:0:4:115,60:0:4:110,63:0:4:110',2),
        ('held65','60:0:65:100',3),
        ('registers','36:0:2:50,48:2.5:2:110,60:5:2:50,72:7.5:2:110,84:10:2:100',2),
        ('legato','48:0:1.1:100,55:.8:1.1:100,60:1.6:1.2:110',1.5)]:
        a=out/(name+'.wav');params={'mode':'Legato','glide':150}if name=='legato'else None
        render.render(p,a,notes,params,tail=tail);audio=Audio.load(a);x=audio.data.astype(float)
        if x.ndim==1:x=x[:,None]
        row={'name':name,'peak_dbfs':audio.peak_db,'rms_dbfs':audio.rms_db,'mono_loss_db':db(x.mean(1))-db(x),'seconds':len(x)/audio.sr,'clipped_samples':int(np.sum(abs(x)>=1))}
        assert np.isfinite(x).all() and audio.peak_db<-.5,(slug,name,row)
        if name=='held65':
            rms=[db(x[i*SR:(i+1)*SR])for i in range(10,64)];row.update(held_min_dbfs=min(rms),held_span_db=max(rms)-min(rms),release_last_dbfs=db(x[-SR:]))
            assert min(rms)>-55 and max(rms)-min(rms)<8,(slug,'held body',row)
            spec=np.abs(np.fft.rfft(x[20*SR:22*SR].mean(1)));freq=np.fft.rfftfreq(2*SR,1/SR)
            bands=[[lo,hi,db(spec[(freq>=lo)&(freq<hi)])]for lo,hi in [(30,150),(150,600),(600,2500),(2500,8000)]]
            row['spectral_band_magnitudes']=bands
        stats.append(row);print(slug,name,row,flush=True)
        if name=='phrase':(out/'spectrogram.png').write_bytes(analysis.spectrogram(audio,title=DESIGNS[slug][0]))
    m=json.loads((p/'build/manifest.json').read_text());report={'slug':slug,'route':'SYN','mechanism':DESIGNS[slug][4],
        'recorded_takes':0,'zones':len(m['zones']),'body_loops':sum(bool(z.get('loop'))for z in m['zones']if z['layer']=='body'),
        'native':stats,'lint':[f.line()for f in findings],'source_hash_fresh':library.source_hash(p)==m['source_hash']}
    assert report['source_hash_fresh'];(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    with(p/'notes.md').open('a')as f:f.write('\n## Native QA\n\n'+ '\n'.join(q.line()for q in findings)+'\n\nOne authored take is intentional; no recorded release is invented. MIDI release uses the envelope. Brightness/tuning warnings must be checked against intentional waveform spectra and the stable central fundamental. Native 65 s holds, register/velocity phrase, chord and legato are stored in demo/green-v6.\n')
    (out/'figure.png').write_bytes(rasterize((p/'figure.svg').read_text(),512))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--slugs',nargs='*');ap.add_argument('--qa-only',action='store_true');a=ap.parse_args()
    for slug in a.slugs or DESIGNS:
        if not a.qa_only:build(slug)
        qa(slug)
