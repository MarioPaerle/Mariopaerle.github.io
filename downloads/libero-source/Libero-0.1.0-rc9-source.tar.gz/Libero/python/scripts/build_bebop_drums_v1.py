#!/usr/bin/env python3
"""Build one source-led Bebop drum kit from DRSKit's actual SFZ regions.

This does not edit the Bebop bank index or any existing preset. Each SFZ
sequence_position remains a RR take; velocity bands come from the source
velocity macros. Close mics are selected per drum, never summed as fake takes.
For cymbals, matching OHL/OHR recordings are paired as the source's stereo
overhead image, with both original mono files retained alongside the derived
stereo WAV.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

REPO = Path('/Users/mario/Documents/Libero')
HOME = Path('/Users/mario/Libero')
CLI = REPO / 'python/.venv/bin/libero'
SRC = HOME / 'cache/libraries/drs-kit/DrumGizmo/DRSKit'
LIBRARY = HOME / 'cache/libraries/drs-kit'
TARGET = HOME / 'banks/bebop/bebop-batteria'
DEMO = HOME / 'demo/bebop-v1/drums'
SAMPLES = TARGET / 'samples'
MACRO = SRC / 'Data/macro.txt'

# (region definition, MIDI key, label, selected mic, stereo-overhead, choke)
# The filenames and velocities are resolved from Data/region plus macro.txt.
MAP = [
    ('Kdrum_without_contact.txt', 35, 'Kick · no contact', 'Kdrum_front', False, 0),
    ('Kdrum_with_contact.txt', 36, 'Kick · contact', 'Kdrum_front', False, 0),
    ('Snare_rim.txt', 37, 'Snare · rim', 'Snare_top', False, 0),
    ('Snare.txt', 38, 'Snare · center', 'Snare_top', False, 0),
    ('Snare_rest.txt', 40, 'Snare · rest', 'Snare_top', False, 0),
    ('Tom3.txt', 41, 'Tom 3 · low', 'Tom3', False, 0),
    ('Hihat_closed_shank.txt', 42, 'Hi-hat · closed shank', 'Hihat', False, 1),
    ('Tom2.txt', 43, 'Tom 2 · mid', 'Tom2', False, 0),
    ('Hihat_foot.txt', 44, 'Hi-hat · pedal', 'Hihat', False, 1),
    ('Tom1.txt', 47, 'Tom 1 · high', 'Tom1', False, 0),
    ('Crash_left_shank.txt', 49, 'Crash left · shank', 'OHL', True, 0),
    ('Crash_right_tip.txt', 55, 'Crash right · tip', 'OHL', True, 0),
    ('Crash_left_tip.txt', 54, 'Crash left · tip', 'OHL', True, 0),
    ('Crash_right_shank.txt', 57, 'Crash right · shank', 'OHL', True, 0),
    ('Ride_tip.txt', 51, 'Ride · tip', 'OHL', True, 0),
    ('Ride_shank_bell.txt', 53, 'Ride · shank/bell', 'OHL', True, 0),
    ('Ride_rest.txt', 63, 'Ride · recorded rest/mute', 'OHL', True, 0),
    ('Ride_shank.txt', 66, 'Ride · shank', 'OHL', True, 0),
    ('Ride_tip_bell.txt', 68, 'Ride · tip/bell', 'OHL', True, 0),
    ('Ride_tip_bell_chain.txt', 70, 'Ride · tip/bell chain', 'OHL', True, 0),
    ('Ride_tip_chain.txt', 73, 'Ride · tip/chain', 'OHL', True, 0),
    ('Hihat_closed.txt', 56, 'Hi-hat · closed', 'Hihat', False, 1),
    ('Hihat_semi_open.txt', 46, 'Hi-hat · semi-open', 'Hihat', False, 1),
    ('Hihat_open.txt', 58, 'Hi-hat · open', 'Hihat', False, 1),
    ('Hihat_open_tip.txt', 61, 'Hi-hat · open tip', 'Hihat', False, 1),
    ('Snare_circle_whisker.txt', 69, 'Snare · circle whisker', 'Snare_top', False, 0),
    ('Snare_whisker.txt', 71, 'Snare · whisker', 'Snare_top', False, 0),
    ('Tom1_whisker.txt', 72, 'Tom 1 · whisker', 'Tom1', False, 0),
    ('Tom2_whisker.txt', 74, 'Tom 2 · whisker', 'Tom2', False, 0),
    ('Tom3_whisker.txt', 76, 'Tom 3 · whisker', 'Tom3', False, 0),
    ('Hihat_closed_whisker.txt', 64, 'Hi-hat · closed whisker', 'Hihat', False, 1),
    ('Hihat_open_whisker.txt', 65, 'Hi-hat · open whisker', 'Hihat', False, 1),
    ('Ride_whisker.txt', 67, 'Ride · whisker', 'Ride', False, 0),
    ('Crash_left_whisker.txt', 60, 'Crash left · whisker', 'OHL', True, 0),
    ('Crash_right_whisker.txt', 62, 'Crash right · whisker', 'OHL', True, 0),
]

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def macros() -> dict[str, str]:
    result: dict[str, str] = {}
    for line in MACRO.read_text().splitlines():
        for name, value in re.findall(r'#define\s+\$(\w+)\s+([^\s#]+)', line):
            result[name] = value
    return result

def regions_for(filename: str, mic: str, key: int, label: str, stereo: bool,
                choke: int, macros_: dict[str, str], source_files: dict[str, dict]) -> list[dict]:
    path = SRC / 'Data/region' / filename
    text = path.read_text()
    inst = re.search(r'^#define\s+\$instr\s+(\S+)', text, re.M).group(1)
    out: list[dict] = []
    positions: dict[tuple[int, int], list[tuple[int, dict]]] = {}
    # Each SFZ region is one actual sample take with its original velocity band.
    for line in text.splitlines():
        if '<region>' not in line or 'sample=' not in line:
            continue
        vel = re.search(r'lovel=\$(v\d+l)\s+hivel=\$(v\d+h)', line)
        seq = re.search(r'seq_position=(\d+)', line)
        sample = re.search(r'sample=([^\s]+)', line)
        if not (vel and seq and sample):
            continue
        low = int(macros_[vel.group(1)])
        high = int(macros_[vel.group(2)])
        sample_expr = sample.group(1).replace('$instr', inst).replace('$mic', mic).replace('$ext', 'flac')
        rel_sample = Path(sample_expr)
        raw = SRC / 'Samples' / rel_sample
        if not raw.exists():
            raise FileNotFoundError(f'{filename}: missing mapped source {raw}')
        raw_rel = raw.relative_to(SRC)
        output_rel = Path('raw') / raw_rel
        dest = SAMPLES / output_rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.exists():
            shutil.copy2(raw, dest)
        source_files[str(output_rel)] = {
            'source_path': str(raw), 'source_sha256': sha(raw),
            'bundled_sha256': sha(dest), 'mic': mic,
            'source_region_definition': str(path),
        }
        file_for_zone = str(output_rel)
        if stereo:
            # Pair the exact same take/velocity from the source overhead L/R mics.
            ohr = raw.with_name(raw.stem.rsplit('-', 1)[0] + '-OHR.flac')
            if not ohr.exists():
                raise FileNotFoundError(f'missing matching overhead right sample: {ohr}')
            ohr_rel = ohr.relative_to(SRC)
            ohr_out = Path('raw') / ohr_rel
            ohr_dest = SAMPLES / ohr_out
            ohr_dest.parent.mkdir(parents=True, exist_ok=True)
            if not ohr_dest.exists():
                shutil.copy2(ohr, ohr_dest)
            source_files[str(ohr_out)] = {
                'source_path': str(ohr), 'source_sha256': sha(ohr),
                'bundled_sha256': sha(ohr_dest), 'mic': 'OHR',
                'source_region_definition': str(path),
            }
            left, sr = sf.read(dest, dtype='float32', always_2d=True)
            right, sr2 = sf.read(ohr_dest, dtype='float32', always_2d=True)
            if sr != sr2 or len(left) != len(right):
                raise ValueError(f'overhead channels mismatch: {dest} / {ohr_dest}')
            stereo_rel = Path('stereo') / (raw.stem.rsplit('-', 1)[0] + '-OHL_OHR.wav')
            stereo_dest = SAMPLES / stereo_rel
            stereo_dest.parent.mkdir(parents=True, exist_ok=True)
            if not stereo_dest.exists():
                sf.write(stereo_dest, np.column_stack((left[:, 0], right[:, 0])), sr, subtype='PCM_24')
            file_for_zone = str(stereo_rel)
            source_files[str(stereo_rel)] = {
                'derived_from': [str(output_rel), str(ohr_out)],
                'source_sha256': [sha(dest), sha(ohr_dest)],
                'bundled_sha256': sha(stereo_dest),
                'transformation': 'paired same-take OHL/OHR mono close overhead recordings as L/R PCM_24 stereo; no summing',
            }
        zone = {'file': file_for_zone, 'root': key, 'lo': key, 'hi': key,
                'vel': [low, high], 'pitched': False, 'one_shot': True}
        # Tiny source-preserving level corrections on two measured irregular
        # layers; the audio and genuine dynamics/takes remain distinct.
        if key == 44 and (low, high) == (51, 76):
            zone['gain_db'] = 8.0
        if key == 44 and (low, high) == (77, 101):
            zone['gain_db'] = 3.0
        if key == 44 and (low, high) == (102, 127):
            zone['gain_db'] = 5.0
        if key == 65 and (low, high) == (102, 127):
            zone['gain_db'] = 2.5
        if choke:
            zone['choke_group'] = choke
        positions.setdefault((low, high), []).append((int(seq.group(1)), zone))
    for band in sorted(positions):
        # Some DRSKit SFZ groups number RR positions globally across velocity
        # layers. Libero takes are local to each dynamic band, so preserve order
        # while reindexing each genuine set to 0..N-1.
        for take, (_source_position, zone) in enumerate(sorted(positions[band], key=lambda p: p[0])):
            zone['take'] = take
            out.append(zone)
    return out

def cmd(*args: object) -> str:
    p = subprocess.run([str(CLI), *map(str, args)], cwd=REPO, text=True, capture_output=True)
    if p.returncode:
        raise RuntimeError(f'libero {args}:\n{p.stdout}\n{p.stderr}')
    return p.stdout.strip()

def main() -> None:
    if not (LIBRARY / 'LICENSE').exists():
        raise FileNotFoundError(LIBRARY / 'LICENSE')
    # This builder exclusively owns the one preset folder.
    if TARGET.exists():
        shutil.rmtree(TARGET)
    TARGET.mkdir(parents=True, exist_ok=True)
    SAMPLES.mkdir(parents=True, exist_ok=True)
    macros_ = macros()
    raw_sources: dict[str, dict] = {}
    body = []
    for region, key, label, mic, stereo, choke in MAP:
        body.extend(regions_for(region, mic, key, label, stereo, choke, macros_, raw_sources))
    if not body:
        raise RuntimeError('no regions generated')
    (SAMPLES / 'map.json').write_text(json.dumps({'body': body, 'tail': []}, indent=2) + '\n')
    (SAMPLES / 'source-map.json').write_text(json.dumps({
        'upstream': 'DRSKit v1.0 SFZ', 'upstream_local': str(SRC),
        'mapping_method': 'Source Data/region/*.txt with Data/macro.txt velocity boundaries and seq_position RR; key assignments from Data/keymap.txt, individual close mics or paired same-strike OHL/OHR stereo.',
        'midi_map': [{'region_definition': r, 'midi_key': k, 'label': label, 'selected_mic': mic,
                      'paired_stereo_overhead': stereo, 'choke_group': choke or None}
                     for r,k,label,mic,stereo,choke in MAP],
        'files': raw_sources,
    }, indent=2) + '\n')
    shutil.copy2(LIBRARY / 'LICENSE', SAMPLES / 'LICENSE-CC-BY-4.0.txt')
    shutil.copy2(LIBRARY / 'README.md', SAMPLES / 'UPSTREAM-README.md')
    (SAMPLES / 'credits.json').write_text(json.dumps([{
        'source': 'DrumGizmo DRSKit v1.0 (ARIA SFZ port)',
        'author': 'Original DRSKit: Lars Muldjord / Bent Bisballe Nyeng (DrumGizmo); ARIA SFZ port and mapping: kinwie',
        'license': 'CC BY 4.0', 'license_class': 'by',
        'url': 'https://github.com/sfzinstruments/DrumGizmo.DRSKit',
        'license_url': 'https://creativecommons.org/licenses/by/4.0/',
        'changes': 'Selected the source-mapped dynamics/RR and specific close mics; paired same-take OHL/OHR mono recordings into true stereo for cymbal zones; converted those pairs to PCM_24 WAV. Audio content is otherwise retained.',
        'retrieved': '2026-10-03',
    }], indent=2) + '\n')
    (TARGET / 'ATTRIBUTION.md').write_text(
        '# Attribution\n\n'
        'Contains samples from **DRSKit v1.0** by Lars Muldjord / Bent Bisballe Nyeng (DrumGizmo), '
        'with the ARIA SFZ port and mapping by kinwie. Licensed under **CC BY 4.0**. '
        'Source: https://github.com/sfzinstruments/DrumGizmo.DRSKit . '
        'License: https://creativecommons.org/licenses/by/4.0/ .\n\n'
        'Changes: selected individual close-mic recordings and the source velocity/RR zones; '
        'paired matching OHL/OHR overhead recordings as left/right stereo for cymbals and wrote those '
        'derived pairs as PCM_24 WAV. Individual source files and their SHA-256 values are listed in '
        '`samples/source-map.json`; the upstream README and full CC BY 4.0 license are included.\n'
    )
    title = 'Bebop batteria · DRSKit'
    recipe = f'''import json
from pathlib import Path
from libero import Sound

HERE = Path(__file__).parent
MAP = json.loads((HERE / 'samples/map.json').read_text())
sound = Sound(title={title!r}, subtitle='Kit jazz · MIDI GM · stick e whisker registrati',
              tags=['percussion','drums','bebop','jazz','sampled','unpitched','sticks','whiskers'],
              sample_rate=48000, accent='#8a5a2b')
sound.multisample('body', MAP['body'], process={{'max_step_db': 12.0, 'tune': 'none', 'ladder': 'smooth', 'align_ms': 0.0, 'loop': 'none', 'max_seconds': 30.0, 'end_db': -90.0, 'peak_db': -3.0}})
sound.performance(humanize={{'cents': 0.0, 'ms': 0.0, 'db': 0.0}}, rr_reset_ms=1200, one_shot=True, dyn_crossfade=0)
sound.defaults(mode='Poli', glide=0, voices=32, amp_attack=0, amp_sustain=1.0, amp_release=80,
               vel_sens=0.0, humanize=0.0, master=-1.5, rev_mode='Cappella', rev_mix=0.0,
               tape_sat=0.0, tape_wow=0.0, tape_flutter=0.0)
'''
    (TARGET / 'sound.py').write_text(recipe)
    (TARGET / 'notes.md').write_text('''# Bebop batteria · DRSKit

One-shot jazz kit built from DRSKit v1.0 source SFZ region definitions. GM keys retain the source kit's playing layout, including the documented whisker gestures on their separate upper keys. Each source velocity band remains a hard-switch dynamic layer; `seq_position` stays a genuine same-articulation round robin. No separate microphone captures are combined as alternate takes. Kick, snare, toms and hats use a single selected close mic; cymbal zones pair matching OHL/OHR captures as stereo left/right, with no mono summing. Original selected microphone files and derived channel pairs are retained and SHA-mapped in `samples/source-map.json`.

Natural one-shot samples play to their source tail. There are no loops. Default is Poli, glide 0, wow/flutter 0, no reverb, and no added humanization; human motion comes from source takes. Hi-hats share choke group 1 so a new hat/closure hit can stop the prior hat voice. Ride and crash zones have no choke group and therefore ring over later cymbal attacks. The source-defined `Ride_rest` region remains its own real muted/rest sample; it plays its full recorded gesture. Engine semantics were checked in `plugin/engine/Engine.cpp`: a note in a `choke_group` cuts prior voices in that same group, so putting ordinary ride or crash hits in a group would incorrectly choke each successive strike. Source attribution and exact CC BY 4.0 terms are in `ATTRIBUTION.md` and `samples/`.

Measured level corrections retain all source layers: pedal-hat dynamics get +8.0 dB (velocity 51–76), +3.0 dB (77–101), and +5.0 dB (102–127) to repair a non-rising measured ladder; the open-whisker top layer gets +2.5 dB because its compiled mean fell below the preceding one. The whisker ride uses its own close Ride mic after its matched overhead capture measured below −78 dBFS RMS; the other ride/cymbal zones use true paired overhead stereo. These are level/mic selection repairs, not added performances.

Technical warnings are summarized in `build/qa-summary.json`; source-mapped variation in take counts by velocity is expected and retained. Lint results and native renders are copied under the demo directory. The stress groove is an engineering headroom check, not a claim of listener approval.

Final lint WARNs are recorded in `build/qa-summary.json`: source attack aliasing, actual layer-level variations, one 2 ms onset shift, near-identical but genuine RR takes, and source-defined sparse velocity groups are retained rather than altered. Exact counts are regenerated by the builder. There are 0 lint FAILs. These checks do not substitute for listening.

The four-bar native stress groove includes a swung ride pattern with overlapping ride/crash resonances; a separate native render records ride/crash tail RMS at several windows after the last hit. The report stores those values so a tail cut regression is visible.
''')
    (TARGET / 'figure.svg').write_text('''<svg xmlns="http://www.w3.org/2000/svg" width="900" height="500" viewBox="0 0 900 500">
<rect width="900" height="500" fill="#f5eee2"/><text x="42" y="52" font-family="sans-serif" font-size="28" font-weight="700" fill="#302a26">Bebop batteria · DRSKit</text><text x="42" y="82" font-family="sans-serif" font-size="14" fill="#65584f">Separate close captures · paired true-stereo overhead cymbals · recorded sticks and whiskers</text>
<ellipse cx="452" cy="298" rx="300" ry="142" fill="#e4d2b8" stroke="#8a5a2b" stroke-width="3"/><ellipse cx="452" cy="298" rx="78" ry="67" fill="#d48a4d" stroke="#633d27" stroke-width="3"/><text x="452" y="303" text-anchor="middle" font-family="sans-serif" font-size="16" fill="#241b16">Snare · top</text>
<circle cx="452" cy="411" r="47" fill="#bd7047" stroke="#633d27" stroke-width="3"/><text x="452" y="416" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#241b16">Kick · front</text>
<ellipse cx="274" cy="251" rx="45" ry="38" fill="#c9a85f" stroke="#705328" stroke-width="3"/><text x="274" y="256" text-anchor="middle" font-family="sans-serif" font-size="13">Tom 1</text><ellipse cx="628" cy="250" rx="49" ry="40" fill="#c9a85f" stroke="#705328" stroke-width="3"/><text x="628" y="255" text-anchor="middle" font-family="sans-serif" font-size="13">Tom 2</text><ellipse cx="650" cy="344" rx="53" ry="44" fill="#c9a85f" stroke="#705328" stroke-width="3"/><text x="650" y="349" text-anchor="middle" font-family="sans-serif" font-size="13">Tom 3</text>
<ellipse cx="228" cy="160" rx="95" ry="28" fill="#d9b957" stroke="#705328" stroke-width="3"/><ellipse cx="675" cy="152" rx="105" ry="30" fill="#d9b957" stroke="#705328" stroke-width="3"/><text x="228" y="165" text-anchor="middle" font-family="sans-serif" font-size="13">Crash L</text><text x="675" y="157" text-anchor="middle" font-family="sans-serif" font-size="13">Ride / Crash R</text>
<path d="M160 101 L228 130 M740 100 L675 122" stroke="#304c67" stroke-width="3"/><circle cx="160" cy="101" r="8" fill="#304c67"/><circle cx="740" cy="100" r="8" fill="#304c67"/><text x="450" y="467" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#304c67">Overhead pair: left → L, right → R; no summed bleed mics</text></svg>\n''')
    if TARGET.exists():
        print(cmd('compile', 'bebop-batteria'))
    # Intentionally do not `save`, `bank add`, or edit bank.json: bank index is owned by another task.
    lint = subprocess.run([str(CLI), 'lint', 'bebop-batteria'], cwd=REPO, text=True, capture_output=True)
    (DEMO / 'lint.txt').parent.mkdir(parents=True, exist_ok=True)
    (DEMO / 'lint.txt').write_text(lint.stdout + lint.stderr)
    # Native renderer groove: swung eighth-note hats, syncopated kick, backbeat,
    # tom/cymbal accents, with a denser two-bar stress pass.
    sys.path.insert(0, str(REPO / 'python'))
    from libero import render, library
    from libero.audio import Audio
    import numpy as np
    events = []
    beat = 60.0 / 116.0
    sixteenth = beat / 4
    for bar in range(4):
        t0 = bar * 16 * sixteenth
        # swung 8ths, with light dynamic alternation and open-hat punctuation
        for step in range(16):
            if step % 2 == 0 or (step % 4 == 3):
                events.append((42 if step % 16 != 14 else 58, t0 + step * sixteenth,
                               0.13, 74 if step % 4 == 0 else 55))
        # A swung ride pattern rings over the rest of the kit; cymbal zones do
        # not join a choke group. Hat group 1 still lets closed hits cut hats.
        for step, vel in ((0, 76), (4, 62), (6, 82), (8, 72), (12, 62), (14, 84)):
            events.append((51, t0 + step * sixteenth, .3, vel))
        for step in ((0, 7, 10, 14) if bar % 2 == 0 else (0, 6, 11, 14)):
            events.append((36, t0 + step * sixteenth, 0.24, 116))
        for step in (4, 12):
            events.append((38, t0 + step * sixteenth, 0.22, 112))
        if bar in (1, 3):
            events.extend([(47, t0 + 13 * sixteenth, .2, 90),
                           (49, t0 + 15 * sixteenth, .45, 108)])
    events.sort(key=lambda e: e[1])
    notes_arg = ','.join(f'{k}:{s:.6f}:{d:.4f}:{v}' for k,s,d,v in events)
    demo_wav = DEMO / 'bebop-batteria-swing-stress.wav'
    result = render.render(TARGET, demo_wav, notes=notes_arg, tail=2.5, sr=48000)
    audio = Audio.load(demo_wav)
    arr = np.asarray(audio.data, dtype=np.float64)
    peak = float(np.max(np.abs(arr)))
    peak_db = 20 * math.log10(max(peak, 1e-15))
    mono = arr.mean(axis=1) if arr.ndim > 1 else arr
    mono_peak_db = 20 * math.log10(max(float(np.max(np.abs(mono))), 1e-15))
    (DEMO / 'swing-stress-notes.txt').write_text(notes_arg + '\n')
    # Overlapping ride + crash hit test leaves both natural one-shot tails free
    # to ring. A source-defined Ride_rest hit plays its own captured mute sample.
    tail_notes = '51:0:0.05:104,49:0.28:0.05:112,51:0.62:0.05:92'
    tail_wav = DEMO / 'cymbal-overlap-natural-tail.wav'
    render.render(TARGET, tail_wav, notes=tail_notes, tail=4.0, sr=48000)
    tail_audio = Audio.load(tail_wav)
    tail_arr = np.asarray(tail_audio.data, dtype=np.float64)
    def window_db(start: float, end: float) -> float:
        x = tail_arr[int(start * 48000):int(end * 48000)]
        return 20 * math.log10(max(float(np.sqrt(np.mean(x * x))), 1e-15)) if x.size else -300.0
    tail_windows = {'post_last_hit_0.4_to_0.9s_dbfs': round(window_db(1.02, 1.52), 2),
                    'post_last_hit_1.4_to_1.9s_dbfs': round(window_db(2.02, 2.52), 2),
                    'post_last_hit_2.4_to_2.9s_dbfs': round(window_db(3.02, 3.52), 2)}
    (DEMO / 'cymbal-overlap-notes.txt').write_text(tail_notes + '\n')
    lint_lines = (lint.stdout + lint.stderr).splitlines()
    counts: dict[str, int] = {}
    for line in lint_lines:
        match = re.match(r'WARN\s+(\w+)', line)
        if match:
            counts[match.group(1)] = counts.get(match.group(1), 0) + 1
    final_manifest = json.loads((TARGET / 'build/manifest.json').read_text())
    final_credits = json.loads((SAMPLES / 'credits.json').read_text())
    fresh_source_hash = library.source_hash(TARGET)
    compiled_zones = {z['file']: sha(TARGET / 'build' / z['file'])
                      for z in final_manifest.get('zones', [])}
    zone_tree = hashlib.sha256()
    for name, digest in sorted(compiled_zones.items()):
        zone_tree.update(name.encode() + b'\0' + bytes.fromhex(digest))
    report = {
        'slug': 'bebop-batteria', 'zones': len(body), 'source_files': len(raw_sources),
        'compiler_exit': 0, 'compiler_warning_count': 0, 'lint_exit': lint.returncode,
        'license': final_manifest.get('license'),
        'license_class': final_credits[0].get('license_class'),
        'source_hash_manifest': final_manifest.get('source_hash'),
        'source_hash_recomputed': fresh_source_hash,
        'source_hash_fresh': final_manifest.get('source_hash') == fresh_source_hash,
        'compiled_audio_zone_count': len(compiled_zones),
        'compiled_audio_zone_tree_sha256': zone_tree.hexdigest(),
        'lint_fail_lines': [line for line in lint_lines if line.startswith('FAIL')],
        'lint_warn_counts': counts,
        'lint_warn_reasons': {
            'aliasing': 'Audible source transients in recorded cymbal/hat attacks have energy above 18 kHz; no synthetic resampling/attenuation added.',
            'brightness': 'Recorded velocity steps for this captured kit often alter level more than spectrum; original dynamics retained.',
            'layers': 'Some source instruments/articulations provide only one recorded velocity group; omitted layers are not fabricated.',
            'loudness': 'Natural instrument/take level spread retained, except two small source-preserving corrections documented in notes.md.',
            'onset': 'One mapped take contains 2 ms of source timing variation; attack is preserved.',
            'takes': 'Some genuine DRSKit takes have correlation >0.98 because they are near-repeat same-source RR performances; retained as source RR.',
        },
        'native_renderer': {'sample_rate': 48000, 'bars': 4, 'bpm': 116,
                            'events': len(events), 'peak_dbfs': round(peak_db, 2),
                            'mono_peak_dbfs': round(mono_peak_db, 2),
                            'peak_ceiling_dbfs': -3.0, 'passes_peak_ceiling': peak_db <= -3.0},
        'cymbal_overlap_tail_test': {'notes': tail_notes,
                                     'tail_window_rms_dbfs': tail_windows,
                                     'policy': 'Ride and crash have no choke_group; Ride_rest is an actual source-recorded muted/rest take and plays as its own one-shot. No artificial sample-end fade or voice choking is applied.'},
        'notes': str(DEMO / 'swing-stress-notes.txt'), 'wav': str(demo_wav),
    }
    (DEMO / 'qa-summary.json').write_text(json.dumps(report, indent=2) + '\n')
    (TARGET / 'build' / 'qa-summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'Built {len(body)} regions from {len(raw_sources)} selected or derived source files at {TARGET}')
    print(f'Lint exit {lint.returncode}; WARN categories {counts}; stress peak {peak_db:.2f} dBFS (mono {mono_peak_db:.2f} dBFS); tail windows {tail_windows}')

if __name__ == '__main__':
    main()
