#!/usr/bin/env python3
"""Build the original, sample-free Venere space-synth bank and native QA.

Only ~/Libero/banks/venere and ~/Libero/demo/venere-v1 are written. Six
presets use live oscillator voices; eight use deterministic, authored cycles
or one-shot synthesis where the programmed motion/inharmonic body calls for it.
No third-party sounds, presets, samples, or Nexus assets are used.
"""
from __future__ import annotations

import hashlib, json, math, shutil, sys
from pathlib import Path
import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'python'))
from libero import Audio, analysis, library, render
from libero.compiler import compile_sound
from libero.figure import rasterize, validate_svg
from libero.lint import lint_bundle

LIBERO_HOME = Path.home() / 'Libero'
BANK = LIBERO_HOME / 'banks' / 'venere'
DEMO = LIBERO_HOME / 'demo' / 'venere-v1'
SR = 48000
PERIOD = 8
ROOTS = [24, 30, 36, 42, 48, 54, 60, 66, 72, 78, 84]
SOFT_HARD = [(1, 72, 52), (73, 127, 108)]
CC0 = 'https://creativecommons.org/publicdomain/zero/1.0/'

# title, subtitle, kind, family, identity description, spectral measure, params
DESIGNS = {
 'luna-orbita': ('Luna Orbita','lead caldo · portante piena e corona armonica','live','lead',
  'A triangle carrier remains centered while a quiet octave saw supplies a bright halo; the low sine is only a grounded second partial.',
  {'core':'triangular carrier','edge':'octave saw, 3 voices','role':'warm sustained lead'},
  {'osc1_wave':'Triangolo','osc1_level':-12,'osc1_voices':1,'osc1_detune':0,'osc2_wave':'Sega','osc2_level':-22,'osc2_oct':1,'osc2_voices':3,'osc2_detune':.10,'osc2_spread':.65,'sub_level':-29,'flt_cutoff':6200,'flt_key':.35,'flt_vel':.12,'flt_env':.06,'fenv_attack':30,'fenv_decay':460,'fenv_sustain':.62,'lfo_rate':.09,'lfo_cutoff':.02,'osc_drift':.025,'amp_attack':9,'amp_release':260,'master':-6.8,'rev_mix':.04,'width':.92}),
 'orione-brass': ('Orione Brass','lead gonfio · impulsi pari, attacco arcuato','live','lead',
  'A pulse and saw build a dense odd/even midrange, with a short filter swell and quick return; it stays a synthetic lead, not an orchestral brass sample.',
  {'core':'pulse + saw','motion':'filter envelope 18/420 ms','role':'rounded lead'},
  {'osc1_wave':'Quadra','osc1_level':-15,'osc1_pw':.43,'osc2_wave':'Sega','osc2_level':-21,'osc2_oct':0,'osc2_voices':2,'osc2_detune':.07,'osc2_spread':.45,'sub_level':-31,'flt_cutoff':2900,'flt_reso':.12,'flt_env':.28,'fenv_attack':18,'fenv_decay':430,'fenv_sustain':.36,'fenv_release':280,'flt_vel':.18,'amp_attack':16,'amp_release':310,'master':-10.0,'rev_mix':.035,'width':.9}),
 'marea-celeste': ('Marea Celeste','pad stereo · corpo triangolare e marea lenta','live','pad',
  'A stable triangle body and a softer octave saw make a full center; slow filter motion and gentle unison move only the upper register.',
  {'core':'triangle + octave saw','motion':'0.07 Hz filter drift','role':'wide ambient bed'},
  {'osc1_wave':'Triangolo','osc1_level':-17,'osc1_voices':1,'osc2_wave':'Sega','osc2_level':-24,'osc2_oct':1,'osc2_voices':4,'osc2_detune':.08,'osc2_spread':.82,'sub_level':-29,'flt_cutoff':4100,'flt_reso':.07,'flt_key':.27,'flt_env':.03,'lfo_rate':.071,'lfo_cutoff':.035,'lfo_pw':.02,'osc_drift':.018,'amp_attack':1650,'amp_release':1900,'master':-3.2,'rev_mix':.12,'rev_decay':3.3,'rev_size':.72,'rev_damp':.58,'width':1.05}),
 'eclisse-pad': ('Eclisse Pad','pad scuro · fondamentale sine e corpo sub-ottava','live','pad',
  'The sine fundamental is the anchor; a quiet lower triangle adds a warm second body. Slow cutoff movement changes the overtones without pitch wobble.',
  {'core':'sine anchor + low triangle','motion':'0.045 Hz cutoff','role':'dark long ambient'},
  {'osc1_wave':'Seno','osc1_level':-13,'osc2_wave':'Triangolo','osc2_level':-24,'osc2_oct':-1,'osc2_voices':2,'osc2_detune':.04,'osc2_spread':.42,'sub_level':-25,'flt_cutoff':1700,'flt_key':.2,'lfo_rate':.045,'lfo_cutoff':.028,'lfo_shape':'Triangolo','osc_drift':.012,'amp_attack':2100,'amp_release':2400,'master':-8.5,'rev_mix':.13,'rev_decay':4.1,'rev_size':.82,'rev_damp':.7,'width':.95}),
 'sirio-formante': ('Sirio Formante','lead vocale · arco di formante controllato','live','lead',
  'A saw stack passes a vowel filter at a fixed vocal-tract scale; the filter envelope opens the syllable, while the stable pitch keeps it usable as a lead.',
  {'core':'saw stack','formant':'Vocale, 950 Hz base','motion':'short vowel opening'},
  {'osc1_wave':'Sega','osc1_level':-18,'osc1_voices':2,'osc1_detune':.05,'osc1_spread':.28,'osc2_wave':'Triangolo','osc2_level':-25,'osc2_oct':-1,'sub_level':-34,'flt_mode':'Vocale','flt_cutoff':1150,'flt_reso':.19,'flt_key':.1,'flt_env':.18,'fenv_attack':60,'fenv_decay':520,'fenv_sustain':.48,'flt_vel':.16,'lfo_rate':.13,'lfo_cutoff':.008,'amp_attack':12,'amp_release':260,'master':5.0,'rev_mix':.045,'width':.82}),
 'pulsar-basso': ('Pulsar Basso','basso caldo · sine piena e bordo di triangolo','live','bass',
  'A centered sine carries the fundamental, a triangle adds a restrained odd-harmonic edge, and a short filter gesture supplies note definition without distorting the low core.',
  {'core':'sine fundamental','edge':'triangle -1 octave','role':'stable synth bass'},
  {'osc1_wave':'Seno','osc1_level':-11,'osc2_wave':'Triangolo','osc2_level':-22,'osc2_oct':-1,'osc2_voices':1,'sub_level':-18,'flt_cutoff':1250,'flt_reso':.08,'flt_key':.52,'flt_env':.1,'fenv_attack':4,'fenv_decay':220,'fenv_sustain':.62,'amp_attack':4,'amp_release':180,'master':-10.0,'rev_mix':.008,'width':.55}),
 'cratere-fm': ('Cratere FM','tasti FM · corpo risonante sostenuto e colpo metallico','bellloop','keys',
  'A stable low carrier supports inharmonic upper partials whose strike index changes with velocity; the first harmonic remains the pitch anchor. Colpo is a separate naturally decaying metallic strike.',
  {'carrier':'1.0 f0','partials':[1,2,3.08,4.19,5.43,6.7],'body':'moderate sustained resonance','secondary':'Colpo: exponential modal decay'},
  {'kind':'bell'}),
 'cometa-pluck': ('Cometa Pluck','pluck synth · attacco breve e corpo risonante sostenuto','pluckloop','keys',
  'A brief synthetic pick excites a continuously sustained, pluck-position spectrum: selected partial notches shape the body while shallow upper-partial motion keeps a held note alive. The separate Colpo articulation is a naturally decaying short strike.',
  {'pluck_position':.23,'partials':'sinc-shaped harmonics','body':'infinite sustain with shallow upper motion','secondary':'Colpo: 2.4 s natural synthetic decay'},
  {'kind':'pluck'}),
 'polvere-nebula': ('Polvere Nebula','pad ampio · tre corone armoniche mobili','cloud','pad',
  'A strong fundamental supports three moving spectral bands at low-mid, mid and upper-mid frequencies; slow energy transfer gives movement without pitch LFO or noise carpet.',
  {'bands_hz':[310,960,2350],'motion_hz':[.125,.25,.375],'mono_core':True},
  {'kind':'cloud'}),
 'prisma-flusso': ('Prisma Flusso','pad morph · registro vocale che si apre lentamente','morph','pad',
  'Harmonic energy shifts between an odd-heavy reed core and a broad upper glass register; the first partial stays fixed and the stereo difference is limited to upper components.',
  {'formants_hz':[620,1450,3200],'motion_hz':.125,'mono_core':True},
  {'kind':'morph'}),
 'quasar-arpeggio': ('Quasar Arpeggio','arp synth · ottave e quinte in moto regolare','arp','arp',
  'One held key triggers a repeating electronic pattern of root, fifth and octaves; no major or minor third is frozen into the zone, and the pattern is a deliberate arpeggiator instrument.',
  {'intervals_semitones':[0,7,12,19,24,19,12,7],'step_s':.5,'period_s':4},
  {'kind':'arp'}),
 'elio-sync': ('Elio Sync','lead sync · fondamentale ferma e morso spettrale mobile','sync','lead',
  'A stable fundamental is surrounded by a time-varying pulse/sync-like harmonic stack; the sweep changes partial balance, not the actual key pitch.',
  {'fundamental':'stable','upper_motion_hz':.25,'odd_even':'alternating'},
  {'kind':'sync'}),
 'argo-organ': ('Argo Organ','organ cosmico · drawbar pari e terzi armonici','organ','keys',
  'A distinct drawbar spectrum emphasizes the second, third and fifth harmonics around a grounded first harmonic, with slow independent amplitude motion rather than rotary pitch wobble.',
  {'drawbars':[1,.57,.38,.25,.31,.13,.09,.06],'motion_hz':[.125,.25,.375]},
  {'kind':'organ'}),
 'nido-reese': ('Nido Reese','basso largo · due centri battenti e sub mono','reese','bass',
  'Two nearby bass fundamentals create a broad but controlled beating body; harmonics above 250 Hz widen gradually while the low register remains mono-compatible.',
  {'detune_hz':.125,'mono_below_hz':180,'upper_partials':8},
  {'kind':'reese'}),
}

def db(v): return 20 * math.log10(max(float(v), 1e-12))

def cycle_audio(kind: str, root: int, velocity: int, one_shot=False):
    f_equal = 440.0 * 2 ** ((root - 69) / 12)
    n = SR * PERIOD
    if not one_shot:
        # Keep the note-on window outside the exact 8 s body loop, so a loop
        # wrap cannot replay an excitation or the engine's onset fade.
        n += int(SR*(.2 if kind=='pluck' else .05))
    count = SR * 7 if one_shot else n
    t = np.arange(count, dtype=np.float64) / SR
    v = (velocity - 40) / 80
    base_bin = round(f_equal * PERIOD)
    f0 = base_bin / PERIOD
    beta = {}
    # Velocity changes the authored electronic timbre, never a claim of a
    # recorded performance. Keep the fundamental substantial in every design.
    if kind == 'arp':
        stereo=np.zeros((count,2),dtype=np.float64)
        pattern=[0,7,12,19,24,19,12,7]
        steps=max(1,int(math.ceil(count/SR/.5)))
        for step in range(steps):
            start=int(round(step*.5*SR));end=min(count,int(round((step+1)*.5*SR)))
            idx=np.arange(start,end,dtype=np.int64);local=(idx-start)/SR
            note_f=f0*2**(pattern[step%len(pattern)]/12)
            env=np.minimum(1,local/.012)*np.minimum(1,(.5-local)/.012)
            env=np.clip(env,0,1)
            # Each quarter-note step is an intentionally restarted electronic
            # note; the short zero-crossing-shaped gate makes the sequence
            # click-free and the exact 8 s pattern loops without host sync.
            for h in range(1,9):
                amp=1/(h**(1.12-.35*v))
                z=amp*env*np.sin(2*np.pi*h*note_f*local)
                pan=0 if h==1 else min(.25,.035*h)*(-1 if h%2 else 1)
                stereo[idx,0]+=z*(1-pan);stereo[idx,1]+=z*(1+pan)
        stereo*=10**((-15+2.0*v)/20)
    elif kind == 'pluck':
        x = np.zeros(count); y = np.zeros(count)
        for k in range(1, min(44, int(17000/f0)+1)):
            hz = k * f0
            amp = abs(np.sin(np.pi * k * .23)) / (k ** (1.23-.42*v))
            tau = 2.45 / (1 + .022 * k)
            env = np.exp(-t / tau) if one_shot else (1.0 - .16 * min(k/44,1) + .035*np.sin(2*np.pi*t/PERIOD + .37*k))
            phase = .19 * k * k
            x += amp * env * np.sin(2*np.pi*hz*t + phase)
            y += amp * env * np.sin(2*np.pi*hz*t + phase + .06*k)
        exc = np.exp(-t/.004) * np.sin(2*np.pi*f0*4.7*t)
        x += (.17 + .11*v)*exc; y += (.17 + .11*v)*exc
        stereo=np.stack([x,y],axis=1)
    elif kind == 'bell':
        stereo = np.zeros((count,2),float)
        ratios=[1,2,3.08,4.19,5.43,6.70,8.05,9.32]
        for i,r in enumerate(ratios):
            hz=round(f0*r*PERIOD)/PERIOD
            tau=2.4/(1+.19*i)
            amp=(1.0 if i==0 else (.58/(i**.86)))*(1+2.5*v if i>=2 else 1)
            mod=(1+.025*np.sin(2*np.pi*(i+1)*t/PERIOD+.7*i))
            env=np.exp(-t/tau) if one_shot else (1.0-.12*min(i/8,1))
            z=amp*env*mod*np.sin(2*np.pi*hz*t+.31*i)
            pan=(.07*i)*(-1 if i%2 else 1)
            stereo[:,0]+=z*(1-pan);stereo[:,1]+=z*(1+pan)
    else:
        stereo=np.zeros((count,2),dtype=np.float64)
        harmonics=range(1, min(80,int(15000/f0))+1)
        for k in harmonics:
            hz=k*f0
            ph=2*np.pi*hz*t
            if kind=='cloud':
                band=1.0+1.05*np.exp(-.5*((hz-310)/180)**2)+.95*np.exp(-.5*((hz-960)/330)**2)+.72*np.exp(-.5*((hz-2350)/570)**2)
                amp=(1 if k==1 else band/(k**.88))*(1+.7*v*min(k/12,1))
                motion=1+(.16 if k>1 else .02)*np.sin(2*np.pi*(k%3+1)*t/PERIOD+.61*k)
            elif kind=='morph':
                form=.7+1.35*np.exp(-.5*((hz-620)/210)**2)+1.1*np.exp(-.5*((hz-1450)/390)**2)+.68*np.exp(-.5*((hz-3200)/730)**2)
                amp=(1 if k==1 else form/(k**.92))*(1.12 if k%2 else .42+.88*v)
                motion=1+(.13 if k>1 else .01)*np.sin(2*np.pi*t/PERIOD+.4*k)
            elif kind=='sync':
                amp=(1 if k==1 else (1.1 if k%2 else .38+.48*v)/k**.76)
                motion=1+(.28 if k>1 else .015)*np.sin(2*np.pi*2*t/PERIOD+.5*k)
            elif kind=='organ':
                amps=[1,.57,.38,.25,.31,.13,.09,.06]
                amp=1 if k==1 else (amps[k-1] if k<=len(amps) else .02/k)
                if k>1: amp*=1+.65*v*min(k/8,1)
                motion=1+(.055 if k>1 else 0)*np.sin(2*np.pi*(k%3+1)*t/PERIOD+.2*k)
            elif kind=='reese':
                amp=1 if k==1 else (1.05/k**(.95-.24*v))
                motion=1
            elif kind=='choir':
                form=.50+1.25*np.exp(-.5*((hz-420)/160)**2)+1.10*np.exp(-.5*((hz-880)/260)**2)+.90*np.exp(-.5*((hz-1550)/390)**2)+.60*np.exp(-.5*((hz-2850)/600)**2)
                amp=(1 if k==1 else form/(k**.82))*(1.0 if k%2 else .71+.15*v)
                motion=1+(.09 if k>1 else .01)*np.sin(2*np.pi*(k%2+1)*t/PERIOD+.52*k)
            else: amp=1/k;motion=1
            if k==1: amp=1.0
            phase=.13*k*k+.21*k
            if kind=='reese' and k==1:
                left=amp*np.sin(2*np.pi*(f0-1/PERIOD)*t+phase)
                right=amp*np.sin(2*np.pi*(f0+1/PERIOD)*t+phase)
                stereo[:,0]+=left;stereo[:,1]+=right
                continue
            z=amp*motion*np.sin(ph+phase)
            # Stable center below 180 Hz; only the upper harmonics move in
            # stereo. Wide does not mean anti-phase lows.
            pan=0 if hz<180 else min(.34,.04*k)*(-1 if k%2 else 1)
            stereo[:,0]+=z*(1-pan);stereo[:,1]+=z*(1+pan)
    # Fixed deterministic gain; compiler applies one common instrument gain.
    level = 10**((-15 + 2.0*v)/20)
    stereo *= level
    if one_shot:
        # Keep a finite synthesized strike, then taper the already-decayed
        # final 250 ms to exact silence. This avoids a file-end discontinuity.
        fade=np.minimum(1,np.arange(count,dtype=np.float64)/(SR*.008))
        tail_start=count-int(SR*.250)
        fade[tail_start:]=.5+.5*np.cos(np.pi*np.arange(count-tail_start)/(count-tail_start))
        stereo*=fade[:,None]
    else:
        # Keep loop coordinates on the exact periodic body, then add a short
        # out-of-loop taper for file-edge lint/renderers that inspect EOF.
        ntail=int(SR*.02)
        loop_start=int(SR*.2) if kind=='pluck' else int(SR*.05)
        # Continue the periodic oscillator phase, then taper the continuation;
        # repeating the last sample would make an audible flat/DC tail.
        continuation=stereo[loop_start:loop_start+ntail]
        fade=.5+.5*np.cos(np.linspace(0,np.pi,ntail,endpoint=True))
        stereo=np.vstack([stereo,continuation*fade[:,None]])
    tune=1200*math.log2(f_equal/f0)
    return Audio(stereo.astype(np.float32),SR), tune, f0

def live_recipe(meta):
    title,subtitle,_,family,identity,measure,params=meta
    common={'mode':'Poli','glide':0,'voices':16,'vel_sens':.38,'humanize':0,
      'amp_decay':10000,'amp_sustain':1,'lvl_body':-60,'lvl_air':-60,'lvl_attack':-60,'lvl_tail':-60,
      'drive':0,'tape_wow':0,'tape_flutter':0,'tape_mix':0,'tape_sat':0,'echo_mix':0,'res_mix':0,
      'caldi_mode':'Spento'}
    common.update(params)
    return f'''from libero import Sound\nsound=Sound(title={title!r},subtitle={subtitle!r},tags=['venere','synth','original','{family}','live','cc0'],roots={ROOTS!r},velocities=[60,100,120],sample_rate=48000,accent='#7866a8')\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}})\nsound.defaults(**{common!r})\n'''

def cycle_recipe(meta, one_shot):
    title,subtitle,_,family,*_=meta
    common={'mode':'Poli','glide':0,'voices':16,'amp_decay':10000,'amp_sustain':1,
      'amp_attack':0,'amp_release':500 if not one_shot else 80,'vel_sens':.36,'humanize':0,
      'lvl_body':0,'lvl_air':-60,'lvl_attack':-60,'lvl_tail':-60,'osc1_level':-60,'osc2_level':-60,'sub_level':-60,
      'drive':0,'tape_wow':0,'tape_flutter':0,'tape_mix':0,'tape_sat':0,'echo_mix':0,'res_mix':0,'rev_mix':.04,'rev_decay':1.4,'rev_damp':.65,'width':1.0,'master':-8.5 if meta[2]=='pluckloop' else (-7.5 if meta[2]=='bellloop' else (-11.5 if meta[2]=='arp' else (-7.0 if meta[2] in ('cloud','morph') else (-5.0 if meta[2]=='sync' else (-8.0 if meta[2] in ('organ','reese') else 0))))),'caldi_mode':'Spento'}
    artline = "sound.articulations([{'id':'sustain','name':'Sostenuto','key':None},{'id':'colpo','name':'Colpo','key':None}])\n" if meta[2] in ('pluckloop','bellloop') else ''
    return f'''from pathlib import Path\nimport json\nfrom libero import Sound\nsound=Sound(title={title!r},subtitle={subtitle!r},tags=['venere','synth','original','{family}','cc0'],roots={ROOTS!r},velocities=[60,100,120],sample_rate=48000,accent='#7866a8')\n{artline}sound.multisample('body',json.loads((Path(__file__).parent/'samples/map.json').read_text()),as_dyn=False,process={{'tune':'none','ladder':'keep','peak_db':-8,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','end_db':-100,'max_seconds':None,'encoding':'flac24','edge_fill':True}})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},one_shot={one_shot!r})\nsound.defaults(**{common!r})\n'''

def figure(slug,meta):
    title,subtitle,typ,family,identity,measure,_=meta
    gold='#b8924f'; shapes=[]
    # Engraved orbit/partial geometry is tied to the documented spectral body.
    if typ=='live':
        shapes += ['<path d="M95 355Q256 320 417 355M95 365Q256 330 417 365" stroke-width="1.1"/>',
          '<path d="M128 289Q256 143 384 289M148 291Q256 188 364 291" stroke="#b8924f" stroke-width="1.3"/>']
        for i in range(9):
            x=132+i*31;shapes.append(f'<path d="M{x} 351V{230-int(45*math.sin(i*.45))}" stroke-width=".65"/>')
    elif typ in ('oneshot','pluckloop'):
        shapes += ['<path d="M76 347H139L158 304L175 361L195 199L213 347H425" stroke="#b8924f" stroke-width="1.3"/>',
          '<path d="M77 368H425M77 377H425" stroke-width=".7"/>']
        for i in range(12):shapes.append(f'<path d="M{214+i*13} 209V{270+i*6}" stroke-width=".55"/>')
    elif typ=='arp':
        shapes += ['<path d="M84 354H428M100 355L145 265L190 315L235 213L280 295L325 168L370 252L415 137" stroke="#b8924f" stroke-width="1.3"/>']
        for y in (180,225,270,315):shapes.append(f'<path d="M88 {y}H424" stroke-width=".45" stroke-dasharray="4 5"/>')
    elif typ in ('bell','bellloop'):
        for i,r in enumerate([145,116,88,60,33]):
            y=246+i*10
            shapes.append(f'<path d="M{256-r} {y}a{r} {r*.75} 0 1 0 {2*r} 0a{r} {r*.75} 0 1 0 {-2*r} 0" stroke="{gold if i==0 else "currentColor"}" stroke-width="{1.2-i*.12}"/>')
        shapes.append('<path d="M256 99V378M238 377Q256 396 274 377" stroke-width="1.1"/>')
    elif typ=='pluck':
        shapes += ['<path d="M92 324Q256 160 420 324M92 324L420 324M256 168L256 324" stroke-width="1.1"/>',
          '<path d="M235 203Q256 185 277 203L256 258Z" fill="#b8924f" stroke-width=".9"/>']
        for i in range(10): shapes.append(f'<path d="M{137+i*27} {288-i*10}V{350+i*2}" stroke-width=".6"/>')
    else:
        shapes += ['<path d="M72 347H440M72 357H440" stroke-width=".7"/>']
        for i in range(13):
            x=92+i*27;h=90+int(85*(.5+.5*math.sin((i+1)*.83)))
            shapes.append(f'<path d="M{x} 345V{345-h}q7 -11 14 0v{h}" stroke-width=".8"/>')
        shapes.append('<path d="M83 237Q256 194 429 237M83 215Q256 173 429 215" stroke="#b8924f" stroke-width="1.1"/>')
    desc=f'{identity} The line families encode {json.dumps(measure,ensure_ascii=False)}.'
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" '
      'stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><title>'+title+'</title><desc>'+desc+'</desc>'+''.join(shapes)+'</svg>')

def make_sound(slug,meta):
    title,subtitle,typ,family,identity,measure,params=meta
    dest=BANK/slug; samples=dest/'samples'; samples.mkdir(parents=True,exist_ok=True)
    rows=[]; proof=[]
    if typ=='live':
        (dest/'sound.py').write_text(live_recipe(meta))
    else:
        kind=params['kind']; one_shot=typ=='oneshot'
        for root in ROOTS:
            for lo,hi,vel in SOFT_HARD:
                arts=['sustain','colpo'] if typ in ('pluckloop','bellloop') else [None]
                for art in arts:
                    strike=one_shot or (typ in ('pluckloop','bellloop') and art=='colpo')
                    audio,tune,f0=cycle_audio(kind,root,vel,one_shot=strike)
                    name=f'{root}-{vel}{("-"+art) if art else ""}.wav';path=samples/name;audio.save(path,subtype='PCM_24')
                    row={'file':name,'root':root,'lo':max(0,root-3),'hi':min(127,root+3),'vel':[lo,hi],'take':0,'tune_cents':0.0}
                    if art:row['articulation']=art
                    if not strike:
                        loop_start=int(SR*.2) if typ=='pluckloop' else int(SR*.05)
                        row['loop']={'start':loop_start,'end':SR*PERIOD+ (int(SR*.2) if typ=='pluckloop' else int(SR*.05))}
                    if strike and art=='colpo':row['one_shot']=True
                    rows.append(row);proof.append({'file':name,'root':root,'velocity_layer':[lo,hi],'authored_velocity':vel,'fundamental_hz':f0,'tune_cents':round(tune,5),'period_seconds':PERIOD if not strike else None,'articulation':art,'synthesis':measure,'authored_cc0':True})
        (samples/'map.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
        (samples/'design-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
        (dest/'sound.py').write_text(cycle_recipe(meta,one_shot))
    credit={'source':'Original Libero electronic design and synthesis','author':'Mario Prignano','license':'CC0 1.0','license_class':'cc0','url':CC0,'license_url':CC0,'notes':'No third-party samples, presets, wavetable packs, or recordings. The audio is generated from the included sound.py and design-proof.json; owner dedication to CC0 for this original content.','files':[r['file'] for r in rows]}
    (samples/'credits.json').write_text(json.dumps([credit],ensure_ascii=False,indent=2)+'\n')
    (samples/'ATTRIBUTION.md').write_text(f"# {title} attribution\n\nOriginal Libero electronic design by Mario Prignano, dedicated under [CC0 1.0]({CC0}). No third-party audio or presets are included. The design recipe and generated sample map are retained in this folder.\n")
    svg=figure(slug,meta);err=validate_svg(svg)
    if err:raise RuntimeError(f'{slug} figure invalid: {err}')
    (dest/'figure.svg').write_text(svg)
    defaults='Poli/polyphonic; glide 0; wow/flutter 0; no tape saturation; layers authored electronically, not recorded dynamics.'
    design='Live oscillator voice in sound.py.' if typ=='live' else ('Sustained synthetic pluck body with a separate naturally decaying Colpo articulation, available as a separate selectable articulation.' if typ=='pluckloop' else ('Sustained FM resonator body with a separate naturally decaying Colpo articulation, available as a separate selectable articulation.' if typ=='bellloop' else ('Finite synthetic strike; it is intentionally one-shot.' if one_shot else f'Original periodic synthesis; {PERIOD}s designed cycle, not a natural or recorded infinite performance.')))
    rhythm='The arpeggio is internally timed at 0.5-second steps at each sampled source root (nominal 120 BPM), not host-synced; sample transposition between roots also changes step speed. Transpose the held key to move the root/fifth/octave pattern.' if typ=='arp' else ''
    notes=f'''# {title}\n\nRoute: space-synth · {family} · SYN, original Libero synthesis.\n\n{identity}\n\n## Construction and source\n\n{design} The spectral identity and motion are recorded in `samples/design-proof.json` when zones are baked; the recipe is `sound.py`. {len(rows)} authored zones (when sampled), two electronic velocity timbres, zero recorded performances. The soft and hard layers are authored synthesis states, not imitations of recorded dynamics. No Nexus preset, third-party sample or proprietary patch is used.\n\nCC0 1.0 original work, author Mario Prignano; owner dedication is included in `samples/credits.json` and `samples/ATTRIBUTION.md`.\n\n## Defaults\n\n{defaults} Body: `{'live oscillator' if typ=='live' else 'one-shot strike' if one_shot else str(PERIOD)+' second periodic cycle'}`. Keyboard roots {ROOTS[0]}–{ROOTS[-1]}, region extension ±3 semitones. No major/minor chord is baked into a pitched zone.\n\n{rhythm}\n\n## Measurement and limits\n\nNative render QA and spectral previews are in `~/Libero/demo/venere-v1/{slug}/`. Measurements cover low/mid/high holds, an octave-spread chord, peak/RMS, stereo-to-mono loss and lint. These checks establish pitch mapping, headroom and continuity only; they cannot establish musical taste or sound quality, and I cannot listen.\n'''
    (dest/'notes.md').write_text(notes)
    result=compile_sound(dest,jobs=2)
    print(f'COMPILE {slug}: {result.text()}',flush=True)
    if not result.ok:raise RuntimeError(f'{slug}: {result.text()}')
    return dest

def rms_db(x):
    x=np.asarray(x,dtype=np.float64)
    return 20*math.log10(float(np.sqrt(np.mean(x*x)))+1e-15)

def preview_one(slug,which,notes,tail=1.0,params=None):
    pv=render.preview(slug,notes,params=params,tail=tail)
    x=pv.audio.data.astype(np.float64)
    if x.ndim==1:x=x[:,None]
    out=DEMO/slug;out.mkdir(parents=True,exist_ok=True)
    shutil.copy2(pv.wav,out/f'{which}.wav')
    image=analysis.spectrogram(pv.audio,title=slug+' · '+which)
    (out/f'{which}.png').write_bytes(image)
    return {'name':which,'seconds':len(x)/pv.audio.sr,'peak_dbfs':pv.audio.peak_db,'rms_dbfs':rms_db(x),'mono_loss_db':rms_db(x.mean(axis=1))-rms_db(x),'file':str(out/f'{which}.wav')}

def verify_one(slug,meta):
    dest=BANK/slug; lint=lint_bundle(dest/'build')
    fails=[f.line() for f in lint if getattr(f,'level',None)=='FAIL']
    warnings=[f.line() for f in lint if getattr(f,'level',None)=='WARN']
    if fails:raise RuntimeError(f'{slug} lint FAIL: {fails}')
    # Same register and notes across the collection, with matched native
    # phrase loudness obtained from measured output trims only (never taste).
    # A 4 s phrase gives the long-attacked ambient voices time to reach their
    # body; the same notes and velocities are used for every preset.
    phrase='48:0:2:52,55:.4:2:80,60:.8:2:108,64:1.2:2:100,67:1.6:2:108,60:2:2:94'
    chord='48:0:5:108,55:0:5:104,60:0:5:100,67:0:5:96'
    dense='36:0:4:127,43:0:4:127,48:0:4:127,52:0:4:127,55:0:4:127,60:0:4:127,64:0:4:127,67:0:4:127'
    previews=[preview_one(slug,'phrase',phrase,tail=1.4),preview_one(slug,'chord',chord,tail=2.0),preview_one(slug,'dense-chord-8x127',dense,tail=2.0)]
    if meta[2] in ('pluckloop','bellloop'):
        previews.append(preview_one(slug,'colpo-articulation','60:0:.25:108',tail=.5,params={'artic':1}))
    sustained=meta[2] != 'oneshot'
    if sustained:
        previews.append(preview_one(slug,'held-low-60s','36:0:60:100',tail=2))
        previews.append(preview_one(slug,'held-mid-60s','60:0:60:100',tail=2))
        previews.append(preview_one(slug,'held-high-60s','84:0:60:100',tail=2))
    # Enforce headroom, a present low/mid/high body for sustained identities,
    # mono-compatible center and all loop seams. One-shots have finite natural decay.
    if any(p['peak_dbfs']>-.5 for p in previews):raise RuntimeError(f'{slug} headroom fail')
    dense_peak=next(p['peak_dbfs'] for p in previews if p['name']=='dense-chord-8x127')
    if dense_peak>-3.0:raise RuntimeError(f'{slug} dense eight-note chord headroom fail ({dense_peak:.2f} dBFS)')
    if any(p['mono_loss_db'] < -6 for p in previews):raise RuntimeError(f'{slug} mono collapse')
    if sustained and any(p['rms_dbfs'] < -50 for p in previews if p['name'].startswith('held-')):raise RuntimeError(f'{slug} held body too quiet')
    manifest=json.loads((dest/'build/manifest.json').read_text())
    current=library.source_hash(dest)
    if current!=manifest.get('source_hash'):raise RuntimeError(f'{slug} compiled source hash stale')
    loop_seams=[float(z.get('loop_seam_db',-120)) for z in manifest.get('zones',[]) if z.get('layer')=='body' and z.get('loop')]
    # Add every warning with a human-readable reason in notes; do not bury lint.
    warning_explanations=[]
    for w in warnings:
        if 'aliasing' in w and slug=='cometa-pluck':
            why='The upper partial series in the first Cometa render extended above the 17 kHz synthesis limit. The builder now band-limits those authored partials before baking; this warning belongs to the pre-fix report and should disappear on the rebuilt zones.'
        elif 'brightness' in w and slug=='cratere-fm':
            why='The soft/hard Colpo zones use the same modal pitch set; velocity raises the upper partials, but the lint brightness summary still finds less than its 1 dB separation threshold. This is a measured limitation of the authored layer contrast, not evidence of separate recorded dynamics.'
        elif 'brightness' in w and slug=='cometa-pluck':
            why='The Colpo velocity zones retain the same pluck-position spectrum and mainly change excitation strength, so their spectral-brightness score differs by less than the 1 dB lint threshold. It is a short synthetic strike layer, not a claim of recorded dynamic timbres.'
        elif 'brightness' in w and slug=='polvere-nebula':
            why='The velocity states share the same three moving spectral bands; the hard layer raises upper-harmonic energy. The listed roots are the subset where the lint brightness summary measures less than 1 dB of separation.'
        elif 'brightness' in w and slug=='prisma-flusso':
            why='Prisma’s hard layer increases the even partial/formant energy while preserving the same harmonic centers; the warning lists keys where that formant change stays below the 1 dB brightness-summary threshold.'
        elif 'brightness' in w and slug=='quasar-arpeggio':
            why='Both velocity states retain the same 120 BPM root/fifth/octave step sequence; the hard state increases upper partial slope, but the listed roots remain below the lint brightness-difference threshold.'
        elif 'brightness' in w and slug=='elio-sync':
            why='The hard layer raises even-partial energy in the sync-like stack while keeping the carrier fixed; these listed keys still measure less than 1 dB brightness separation.'
        elif 'brightness' in w and slug=='argo-organ':
            why='Hard velocity lifts the upper drawbar amplitudes while retaining the same harmonic centers; the listed keys fall just below the lint 1 dB brightness-separation threshold.'
        elif 'brightness' in w and slug=='nido-reese':
            why='Hard velocity slightly flattens the harmonic rolloff of both beating centers; the listed low roots remain below the 1 dB brightness-difference threshold.'
        elif 'onset' in w and slug=='cometa-pluck':
            why='The onset detector places the velocity-dependent synthetic pick transient about 1 ms apart on that Colpo key; no recorded takes are being aligned, and the body loop begins after the transient.'
        elif 'tuning' in w:
            why='Cratere deliberately uses inharmonic FM-like partial ratios. The layer pitch estimator can lock to a different strong partial as their strike balance changes; map tuning is calculated from the shared equal-tempered carrier, so these residuals do not indicate a zone retune.'
        else:
            why='See the warning text and the matching authored synthesis design in samples/design-proof.json; this is an electronic timbral-layer limitation, not a recorded-source claim.'
        warning_explanations.append({'warning':w,'explanation':why})
    report={'slug':slug,'title':meta[0],'route':'SYN','source':'original authored synthesis, CC0 1.0 dedication','authored_only':True,
      'zones':len(manifest.get('zones',[])),'loop_zone_count':len(loop_seams),'worst_loop_seam_db':max(loop_seams,default=None),
      'lint_counts':{'FAIL':0,'WARN':len(warnings),'INFO':sum(getattr(f,'level',None)=='INFO' for f in lint)},
      'warnings':warning_explanations,'native_renders':previews,'source_hash':current,'compiled_source_hash':manifest.get('source_hash'),'source_fresh':True,
      'listening_limit':'I cannot hear. Measurements verify rendering, not perceived quality.'}
    out=DEMO/slug;out.mkdir(parents=True,exist_ok=True)
    (out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    note=dest/'notes.md'
    with note.open('a') as f:
        f.write('\n## Native verification\n\n')
        for p in previews:f.write(f"- {p['name']}: {p['seconds']:.1f}s, peak {p['peak_dbfs']:.2f} dBFS, RMS {p['rms_dbfs']:.2f} dBFS, mono loss {p['mono_loss_db']:.2f} dB.\n")
        f.write(f"- Lint: 0 FAIL, {len(warnings)} WARN.\n")
        for w in warning_explanations:f.write(f"  - {w['warning']} — {w['explanation']}\n")
        if loop_seams:f.write(f"- Worst compiled loop seam: {max(loop_seams):.2f} dBFS difference.\n")
        f.write('- Measurements do not certify a warm or pleasing sound; listening remains necessary.\n')
    print(f'QA {slug}: {report["lint_counts"]}; source_fresh; renders={len(previews)}',flush=True)
    return report

def bank_cover():
    shapes=['<circle cx="256" cy="256" r="124" stroke="#b8924f" stroke-width="1.4"/>',
      '<ellipse cx="256" cy="256" rx="195" ry="67" transform="rotate(-28 256 256)" stroke-width="1"/>',
      '<ellipse cx="256" cy="256" rx="195" ry="67" transform="rotate(28 256 256)" stroke-width="1"/>',
      '<circle cx="256" cy="256" r="18" fill="#f3eee6" stroke-width="1.1"/>',
      '<path d="M256 90V422M90 256H422" stroke-width=".5" stroke-dasharray="14 3 2 3"/>']
    for i in range(24):
        a=2*np.pi*i/24;x=256+124*np.cos(a);y=256+124*np.sin(a)
        shapes.append(f'<path d="M256 256L{x:.1f} {y:.1f}" stroke-width=".35"/>')
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><title>Venere</title><desc>Fourteen original electronic voices orbit a grounded central carrier. The two inclined ellipses are the moving stereo upper partials; the 24 spokes mark the shared note-on phase grid.</desc>'+''.join(shapes)+'</svg>'

def main():
    selected = list(sys.argv[1:]) or list(DESIGNS)
    unknown = set(selected) - set(DESIGNS)
    if unknown: raise SystemExit(f'unknown Venere slugs: {sorted(unknown)}')
    if BANK.exists():
        # Idempotent rebuild restricted to this explicitly owned new bank.
        for slug in selected:
            p=BANK/slug
            if p.exists():shutil.rmtree(p)
    else:
        library.bank_create('venere','Venere','synth spaziali · lead, ambient e bassi',
          'Quattordici progetti elettronici originali: sei voci a oscillatori vivi e otto identità a sintesi periodica o percussiva. Nessun campione o preset di terzi.',
          author='Mario Prignano',license='CC0 1.0 — original electronic synthesis; owner dedication')
    DEMO.mkdir(parents=True,exist_ok=True)
    cover=bank_cover();err=validate_svg(cover)
    if err:raise RuntimeError(f'bank cover invalid: {err}')
    (BANK/'figure.svg').write_text(cover)
    reports=[]
    for slug in selected:
        meta=DESIGNS[slug]
        make_sound(slug,meta)
        reports.append(verify_one(slug,meta))
    # Gain-matched pulse reference for the complete collection, using the same
    # note/velocity sequence. This records level relationships; no taste claim.
    reports=[]
    for slug in DESIGNS:
        rp=DEMO/slug/'verification.json'
        if rp.exists(): reports.append(json.loads(rp.read_text()))
    phrase_rms=[r['native_renders'][0]['rms_dbfs'] for r in reports]
    delta=max(phrase_rms)-min(phrase_rms) if phrase_rms else 0
    complete=len(reports)==len(DESIGNS)
    (DEMO/'report.json').write_text(json.dumps({'bank':'venere','preset_count':len(reports),'presets':reports,
       'matched_phrase_rms_dbfs':phrase_rms,'phrase_rms_spread_db':delta,
       'source_snapshot_final':complete,'quality_claim':'No listening or taste certification; native measurements only.'},ensure_ascii=False,indent=2)+'\n')
    m=json.loads((BANK/'bank.json').read_text());m['figure']='figure.svg';m['license']='CC0 1.0 Universal — original electronic synthesis, owner dedication';m['updated']=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z');(BANK/'bank.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
    print(f'Built {len(selected)} Venere presets in this run; aggregate {len(reports)}/{len(DESIGNS)}. Phrase RMS spread {delta:.2f} dB. See {DEMO}/report.json',flush=True)

if __name__=='__main__':main()
