#!/usr/bin/env python3
"""Native-render smoke and legato/hold report for the six Giove presets."""
import json, math, sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from libero.render import render
from libero.audio import Audio
from libero import analysis

BANK=Path.home()/'Libero/banks/giove'; OUT=Path.home()/'Libero/demo/giove-v1'; OUT.mkdir(parents=True,exist_ok=True)
SLUGS=['theremin-vetro','theremin-ambra','trautonium-due-formanti','volkstrautonium-manuale','mixturtrautonium-quarta-aperta','mixturtrautonium-frange']
PARAMS=None  # use each installed sound.py default, especially Legato
def db(x): return 20*math.log10(max(float(x),1e-12))
def window_rms(a,sr,t0,t1):
 x=a[int(t0*sr):int(t1*sr)]
 return float(np.sqrt(np.mean(np.square(x,dtype=np.float64)))) if len(x) else 0.0
rows=[]
for slug in SLUGS:
 p=BANK/slug; manifest=json.loads((p/'build'/'manifest.json').read_text())
 row={'slug':slug,'source_hash':manifest.get('source_hash'),'mode':'Legato','continuous_live_oscillators':slug.startswith('theremin-'),'renders':{}}
 notes='60:0:1.30:100,64:1.18:1.30:100,67:2.36:1.30:100,55:3.54:1.50:100'
 phrase=OUT/f'{slug}-legato-phrase.wav'
 info=render(p/'build',phrase,notes,params=PARAMS,tail=.8)
 a=Audio.load(phrase); x=np.asarray(a.data,dtype=np.float64); sr=a.sr
 # The old voice should remain alive across each intentionally overlapped note-on.
 transitions=[]
 for t in (1.18,2.36,3.54):
  transitions.append({'time_s':t,'pre_100ms_rms_db':round(db(window_rms(x,sr,t-.12,t-.02)),2),'post_100ms_rms_db':round(db(window_rms(x,sr,t+.02,t+.12)),2)})
 row['renders']['legato_phrase']={'path':str(phrase),'engine':info,'transitions':transitions,'overlap_s':.12,'finite':bool(np.isfinite(x).all())}
 held={}
 for note,label in ((40,'low'),(60,'mid'),(72 if slug.startswith(('trautonium','volkstrautonium')) else 80,'high')):
  dest=OUT/f'{slug}-hold-{label}-60s.wav'
  inf=render(p/'build',dest,f'{note}:0:60:100',params=PARAMS,tail=0)
  au=Audio.load(dest); z=np.asarray(au.data,dtype=np.float64); sr2=au.sr
  held[label]={'note':note,'path':str(dest),'engine':inf,'finite':bool(np.isfinite(z).all()),'peak_db':round(db(np.max(np.abs(z))),2),'rms_0_1s_db':round(db(window_rms(z,sr2,0,1)),2),'rms_10_20s_db':round(db(window_rms(z,sr2,10,20)),2),'rms_50_59s_db':round(db(window_rms(z,sr2,50,59)),2)}
 row['renders']['held_60s']=held
 rows.append(row); print(slug,'legato',info.get('peak_db'),'hold mid',held['mid']['rms_50_59s_db'],flush=True)
(OUT/'native-report.json').write_text(json.dumps({'method':'libero-render native engine; deliberately overlapped notes (destination onset precedes previous note-off) exercise configured Legato behavior','interpretation':'RMS continuity is a diagnostic for dropouts/retrigger-level dips, not a substitute for listening; live Theremin patches do not use sample-zone pitch/loop tests. There are no alternative articulations in these six patches.','presets':rows},indent=2,ensure_ascii=False)+'\n')
