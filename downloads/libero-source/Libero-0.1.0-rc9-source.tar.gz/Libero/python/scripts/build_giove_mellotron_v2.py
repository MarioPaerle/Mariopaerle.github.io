"""Import verified Leisureland tape recordings for a separate freeware-only candidate."""

from __future__ import annotations

import base64
import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path

import soundfile as sf

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
from libero import Audio, dsp, library
from libero.compiler import compile_sound
from libero.figure import validate_svg

LIBRARY = Path.home() / "Libero"
CACHE = LIBRARY / "cache/research/giove/mellotron-original"
BANK = LIBRARY / "banks/giove"
DESIGNS = {
    "mellotron-mkii-flute": ("MkII Flute.zip", "Mellotron MkII Flute", "The original tape flute · M400S/M4000 recordings"),
    "mellotron-mkii-strings": ("MkII Violins.zip", "Mellotron MkII Strings", "Three violins on tape · the original MkII frame"),
    "mellotron-eight-voice-choir": ("8 Choir.zip", "Mellotron 8 Voice Choir", "Eight voices on tape · original keyboard performances"),
    "mellotron-cello": ("Cello.zip", "Mellotron Cello", "The original cello tape · 35 individually recorded keys"),
}
GRANT_URL = "https://www.kvraudio.com/forum/viewtopic.php?start=15&t=236629"
LATER_TERMS = "https://www.kvraudio.com/forum/viewtopic.php?t=561309"
TERMS = "Taijiguy freeware instrument permission; attribution required; no payware or commercial for-profit software"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, data) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def figure() -> str:
    keys = "".join(f'<path d="M{x} 355V421"/>' for x in range(99, 417, 14))
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="none" '
            'stroke="currentColor" stroke-width="1.2">'
            '<path d="M79 112H433V421H79Z M79 340H433 M79 355H433"/>'
            '<circle cx="157" cy="201" r="57"/><circle cx="355" cy="201" r="57"/>'
            '<circle cx="157" cy="201" r="18"/><circle cx="355" cy="201" r="18"/>'
            '<path d="M157 258H355 M157 144H355 M139 299H373" stroke="#bb985c" stroke-width="2"/>'
            '<path d="M157 183V145 M139 201H101 M175 201H213 M355 183V145 M337 201H299 M373 201H411"/>'
            + keys + '</svg>')


def build(slug: str, archive_name: str, title: str, subtitle: str) -> dict:
    acquisition = json.loads((CACHE / "acquisition.json").read_text())
    record = next(row for row in acquisition if row["file"] == archive_name)
    archive = CACHE / archive_name
    body = archive.read_bytes()
    assert sha(archive) == record["sha256"]
    assert base64.b32encode(hashlib.sha1(body).digest()).decode().rstrip("=") == record["cdx_sha1_base32"]
    folder = BANK / slug
    if folder.exists():
        previous = folder / "samples/source-acquisition.json"
        if not previous.exists() or json.loads(previous.read_text())["sha256"] != record["sha256"]:
            raise RuntimeError(f"{slug} exists with a different source; inspect it before rebuilding")
    samples = folder / "samples"
    originals = samples / "originals"
    originals.mkdir(parents=True, exist_ok=True)
    sustained = samples / "sustained"
    sustained.mkdir(exist_ok=True)
    rows, proof = [], []
    with zipfile.ZipFile(archive) as source:
        assert source.testzip() is None
        for name in source.namelist():
            if not name.lower().endswith(".wav"):
                continue
            basename = Path(name).name
            note = dsp.parse_note(Path(basename).stem)
            dest = originals / basename
            dest.write_bytes(source.read(name))
            info = sf.info(dest)
            mapped_root = note + 12 if slug in {"mellotron-mkii-flute", "mellotron-mkii-strings"} else note
            verified_physical_root = mapped_root if slug in {"mellotron-mkii-flute", "mellotron-mkii-strings"} else None
            proof.append({"file": "originals/" + basename, "sha256": sha(dest),
                          "filename_root": note, "mapped_root": mapped_root,
                          "physical_root": verified_physical_root, "root": mapped_root,
                          "frames": info.frames, "sample_rate": info.samplerate, "channels": info.channels,
                          "duration": info.duration, "encoding": info.subtype, "source_archive": record})
            common = {"file": "originals/" + basename, "root": mapped_root, "lo": mapped_root, "hi": mapped_root,
                      "vel": [1, 127], "take": 0, "tune_cents": 0}
            audio = Audio.load(dest).remove_dc(5)
            loop = audio.loop_points(min_seconds=3, region=(.8, audio.duration - .1), max_crossfade=.4)
            if loop is None:
                raise RuntimeError(f"No long source continuation found: {archive_name}/{basename}")
            looped = sustained / (Path(basename).stem + ".flac")
            sf.write(looped, audio.bake_loop(loop).data, info.samplerate, subtype="PCM_24")
            proof[-1]["sustained_derivation"] = {"file": "sustained/" + looped.name,
                                                "sha256": sha(looped), "loop": loop.as_manifest(),
                                                "loop_error_db": loop.error_db,
                                                "method": "Long loop from the same recording, rising zero crossings and up to 400ms baked crossfade; no synthetic sustain."}
            proof[-1]["finite_articulation_render"] = {"terminal_fade_ms": 12,
                "note": "Only compiled finite tape_original zones receive a short terminal ramp; archived ZIP and preserved original WAV remain byte-identical."}
            rows.append({**common, "file": "sustained/" + looped.name,
                         "articulation": "sustained", "loop": loop.as_manifest()})
            rows.append({**common, "articulation": "tape_original", "loop": "none"})
    roots = sorted(row["mapped_root"] for row in proof)
    assert sorted(row["filename_root"] for row in proof) == list(range(43, 78))
    assert all(6.5 < row["duration"] < 9 for row in proof)
    dump(samples / "map.json", rows)
    dump(samples / "source-proof.json", proof)
    dump(samples / "source-acquisition.json", record)
    shutil.copy2(CACHE / "wayback-cdx.json", samples / "wayback-cdx.json")
    credits = [{"source": archive_name.removesuffix(".zip") + " — Leisureland Mellotron recordings",
                "author": "Taijiguy", "license": TERMS, "license_class": "nc",
                "url": "https://www.leisureland.us/mellotron.htm", "permission_url": GRANT_URL,
                "later_terms_url": LATER_TERMS, "archive_url": record["archived_url"],
                "files": sorted(row["file"] for row in proof),
                "notes": "Original 35-key recordings preserved. A separate sustained articulation derives a loop; no synthetic replacement, extra recorded dynamics or round robins. Freeware-only bank; do not include in an unrestricted/commercial sample-data release."}]
    dump(samples / "credits.json", credits)
    (samples / "TERMS.md").write_text(
        f"# Leisureland Mellotron terms\n\n{TERMS}.\n\n"
        f"[Author's 2008 permission]({GRANT_URL}); [later restriction]({LATER_TERMS}).\n\n"
        "This is an author permission statement, not CC0, CC BY or an open sample license. "
        "The restriction concerns instrument/software redistribution. Do not infer additional "
        "permissions, an endorsement from Mellotron/Streetly, or a license to new tape masters.\n"
    )
    defaults = dict(mode="Poli", glide=0, voices=16, master=-6, vel_sens=0,
                    amp_attack=3, amp_decay=10000, amp_sustain=1, amp_release=110,
                    lvl_body=0, lvl_attack=-60, lvl_tail=-60, lvl_air=-60,
                    flt_cutoff=10500, flt_env=0, rev_mix=.018, rev_mode="Cappella",
                    rev_size=.2, rev_decay=.7, tape_mix=0, tape_wow=0, tape_flutter=0,
                    tape_sat=0, drive=0, echo_mix=0, lfo_pitch=0, lfo_amp=0,
                    caldi_mode="Spento", width=1)
    process = dict(tune="source", ladder="keep", peak_db=-12, align_ms=0,
                   pre_ms=0, onset_db=-160, end_db=-160, fade_ms=12, loop="source",
                   loop_min_s=3, max_seconds=None, preserve_key_ranges=True,
                   edge_fill=False, encoding="flac24")
    (folder / "sound.py").write_text(
        "import json\nfrom pathlib import Path\nfrom libero import Sound\n\n"
        f"sound = Sound(title={title!r}, subtitle={subtitle!r}, tags=['giove', 'mellotron', 'recorded', 'freeware-only'], roots={roots!r}, sample_rate=44100, accent='#ae9056')\n"
        "sound.articulations([{'id': 'sustained', 'name': 'Sustained Loop', 'key': 24}, {'id': 'tape_original', 'name': 'Tape Original', 'key': 25}])\n"
        f"sound.multisample('body', json.loads((Path(__file__).parent / 'samples/map.json').read_text()), process={process!r})\n"
        "sound.performance(dynamics_source='velocity', dyn_crossfade=0, humanize={'cents': 0, 'ms': 0, 'db': 0})\n"
        f"sound.defaults(**{defaults!r})\n"
    )
    svg = figure()
    assert not validate_svg(svg)
    (folder / "figure.svg").write_text(svg)
    (folder / "notes.md").write_text(
        f"# {title}\n\n{subtitle}.\n\n"
        "Authentic Taijiguy recordings from M400S/M4000 Mellotrons, recovered from "
        "an Internet Archive capture of the original Leisureland download. The ZIP's "
        "SHA-1 matches the archived CDX payload digest; each original WAV is retained "
        "unchanged with a SHA-256 record. WAV filename labels span G2–F5 (MIDI 43–77).\n\n"
        "**Sustained Loop** is the default: a long crossfaded continuation of each actual "
        "tape recording. **Tape Original** (C#1 / MIDI 25) plays the finite original "
        "performance, about eight seconds, with no loop and a 12 ms compiled end ramp to prevent an abrupt cutoff. C1 / MIDI 24 returns to Sustained "
        "Loop. Release responds to note-off in both modes. Source pitch drift, attacks, "
        "noise and differences between keys remain; no destructive retuning or fake recorded "
        "velocity layers. One common compilation gain preserves recording balance.\n\n"
        f"Source: Taijiguy, Leisureland. {TERMS}. "
        + ("Independent period and partial-family checks found these flute/strings recordings one octave above their filename labels: filenames G2–F5 (MIDI 43–77), measured physical roots G3–F6 (MIDI 55–89), retained separately in source-proof and playable at those physical roots. " if slug in {"mellotron-mkii-flute", "mellotron-mkii-strings"} else "EXPERIMENTAL pitch mapping: the current playable roots follow filename labels G2–F5 (MIDI 43–77); physical roots have not been established independently for these polyphonic/ambiguous sources. Do not treat this mapping as a verified pitch recreation. ")
        + "This bank is separate from any unrestricted/open sound-data release. Rebuild with "
        "`python/scripts/build_giove_mellotron_v2.py` after acquiring the verified ZIPs.\n"
    )
    result = compile_sound(folder, jobs=2)
    if result.error:
        raise RuntimeError(result.error)
    manifest = json.loads((folder / "build/manifest.json").read_text())
    errors = library.validate_bundle(folder / "build")
    assert not errors, errors
    assert len(manifest["zones"]) == 70
    for zone in manifest["zones"]:
        assert bool(zone.get("loop")) == (zone["articulation"] == "sustained"), zone
    print(slug, result.text(), flush=True)
    return {"slug": slug, "title": title, "source_hash": manifest["source_hash"],
            "source_archive": record, "recorded_keys": 35, "zones": 70,
            "duration_range": [min(r["duration"] for r in proof), max(r["duration"] for r in proof)]}


if __name__ == "__main__":
    results = [build(slug, *design) for slug, design in DESIGNS.items()]
    dump(CACHE / "built-presets.json", results)
