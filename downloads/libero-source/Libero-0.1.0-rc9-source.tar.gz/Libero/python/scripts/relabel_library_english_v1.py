#!/usr/bin/env python3
"""Reproducibly relabel the active Libero library in English without rendering audio.

The script edits only Sound title/subtitle literals, bank display metadata and the
matching text fields in existing build manifests. It recalculates source hashes,
records before/after compiled-audio hashes, and refuses to continue on drift.
The six live Giove Theremin/Trautonium entries now use the owner's frozen schema;
their literal display fields are included while all synthesis values remain intact.
"""
from __future__ import annotations
import ast, hashlib, json, re, shutil, sys, os, tempfile
import stat
from datetime import datetime, timezone
from pathlib import Path

HOME = Path.home() / 'Libero'
REPO = Path(__file__).resolve().parents[2]
REPORT = REPO / 'docs/research/library-display-name-migration.json'
DEFERRED = set()  # Sol has frozen all six; their literal SPEC labels are now in scope.
MALLET = {'marble-xylophone-vcsl','marble-marimba-vcsl'}
SCOPE_EXCLUSIONS = {'mellotron-mkii-flute','mellotron-mkii-strings','mellotron-eight-voice-choir','mellotron-cello'}

# Poetic names remain identities; generic instrument/role words are translated.
TITLE = {
 'Archi armonici':'String Harmonics','Armonici del violoncello II':'Cello Harmonics II',
 'Archi congelati':'Frozen Strings','Archi ensemble':'String Ensemble',
 'Archi particolari':'Extended String Techniques','Archi particolari II':'Extended Strings II',
 'Contrabbassi':'Double Basses','Viole':'Violas','Violini':'Violins','Violino solo':'Solo Violin',
 'Violoncelli':'Cellos','Violoncello solo':'Solo Cello','Violoncello solo II':'Solo Cello II',
 'Armonica vissuta':'Worn Harmonica','Arpa Folk':'Folk Harp','Carillon particolare':'Unusual Music Box',
 'Dan Tranh lunare':'Moonlit Dan Tranh','Fagotto ombra':'Shadow Bassoon','Flauto barocco':'Baroque Recorder',
 'Gong profondo':'Deep Gong','Kalimba di Legno':'Wooden Kalimba','Mandolino dorato':'Gilded Mandolin',
 'Mandolino dorato · Celtic Oval':'Gilded Mandolin · Celtic Oval','Marimba radice':'Root Marimba',
 'Oboe respiro':'Breath Oboe','Ocarina di terra':'Earth Ocarina','Piano giocattolo':'Toy Piano',
 'Piano Preparato':'Prepared Piano','Salterio vivo':'Living Psaltery','Saw · Rame':'Saw · Copper',
 'Tubolari risonanti':'Resonant Tubular Bells','Vibrafono caldo':'Warm Vibraphone','Xilofono vivo':'Living Xylophone',
 '808 Cavo':'Hollow 808','808 Cavo II':'Hollow 808 II','808 Colpo':'Strike 808','808 Colpo II':'Strike 808 II',
 '808 Notte':'Night 808','808 Notte II':'Night 808 II','Basso Flatwound':'Flatwound Bass',
 'Basso Hollowbody':'Hollowbody Bass','Contrabbasso Jazz':'Jazz Double Bass','Sub Ancora':'Anchor Sub',
 'Sub Legno':'Wooden Sub','Sub Rimbalzo':'Bouncing Sub',
 'Bebop batteria · DRSKit':'Bebop Drums · DRSKit','Archtop di mezzanotte':'Midnight Archtop',
 'Clarinet in B♭':'B♭ Clarinet','Contrabbasso Rubner Bebop':'Rubner Bebop Double Bass',
 'French horn':'French Horn','Trombone':'Trombone','trombone':'Trombone','Alto saxophone':'Alto Saxophone','Sassofono contralto':'Alto Saxophone','high saxophone':'Alto Saxophone',
 'kick Baile':'Baile Kick','kick Phonk':'Phonk Kick','Trap kit':'Trap Kit','Trap kit ita':'Italian Trap Kit','drums hip-hop':'Hip-Hop Drums','drums trap':'Trap Drums',
 'Trautonium · Due Formanti':'Trautonium · Two Formants','Volkstrautonium · Manuale':'Volkstrautonium · Manual','Mixturtrautonium · Quarta Aperta':'Mixturtrautonium · Open Fourth','Mixturtrautonium · Frange':'Mixturtrautonium · Fringes',
 'Piano a coda Steinway Bebop':'Steinway Bebop Grand Piano',
 'Cinque Fili':'Five Strings','Respiro d’Ambra':'Amber Breath','Mantice Sassone':'Saxon Bellows',
 'Filo Magnetico':'Magnetic Thread','Corde Cobalto':'Cobalt Strings','Fosforo · Tasti':'Phosphor · Keys',
 'Indaco · Ance':'Indigo · Reeds','Mantice Blu':'Blue Bellows','Corde di Cedro':'Cedar Strings',
 'Ruote Blues':'Blues Wheels','Positivo Rinascimentale':'Renaissance Positive Organ',
 'Rame Notturno':'Night Copper','Vetro Lungo':'Long Glass','Ancia Elettrica':'Electric Reed',
 "Chitarra d'acciaio":"Steel-String Guitar", "Chitarra d'acciaio · accordi":"Steel-String Guitar · Chords",
 'Chitarra classica':'Classical Guitar','Chitarra classica, accordi':'Classical Guitar · Chords',
 'Chitarra classica · accordi II':'Classical Guitar · Chords II','Chitarra classica · nylon':'Classical Guitar · Nylon',
 'Chitarra dietro il ponte':'Behind-the-Bridge Guitar','Chitarra elettrica crunch':'Crunch Electric Guitar',
 'Chitarra elettrica pulita':'Clean Electric Guitar','Coro · Orizzonte':'Choir · Horizon',
 'Coro · Volta':'Choir · Vault','Donne · Mezzo':"Women's Choir · Mezzo",'Donne · Radura':"Women's Choir · Glade",
 'Ellen · Ooh → Aha':'Ellen · Ooh → Aha','Trillo · Rito':'Trill · Rite',
 'Uomini · Cenere':"Men's Choir · Ashes",'Uomini · Pietra':"Men's Choir · Stone",
 'Clarinetto':'Clarinet','Flauto dolce contralto':'Alto Recorder','Flauto traverso':'Concert Flute',
 'Odisseo aulos':'Odysseus Aulos','Pan · Canne':'Pan · Pipes',
 'Marble · Marimba':'Marble · Marimba','Marble · Xylophone':'Marble · Xylophone',
 'Nastri di Ance':'Reed Tapes','Nastri di Corde':'String Tapes','Nastri di Flauto':'Flute Tapes',
 'Nastri di Ottone':'Brass Tapes','Ambra':'Ambra','Aurora di Vetro':'Glass Aurora',
 'Bosco Largo':'Bosco Largo','Canneto Elettrico':'Electric Reedbed','Cedro':'Cedro','Giada':'Jade',
 'Miele':'Miele','Muscolo':'Muscolo','Ottone Verde':'Green Brass','Prisma Morbido':'Soft Prism',
 'Resina':'Resin','Seta Spettrale':'Spectral Silk',
 'Apito de Neon':'Apito de Neon','Baile de Rua':'Baile de Rua','Baixo Corrente':'Baixo Corrente',
 'Clap Baile':'Baile Clap','Coro Fantasma':'Ghost Choir','Faísca Cromada':'Faísca Cromada',
 'Gota de Cobre':'Gota de Cobre','Lua de Viaduto':'Lua de Viaduto','Memphis Fita':'Memphis Fita',
 'Oitão 808':'Oitão 808','Perc Baile':'Baile Percussion','Poeira de Concreto':'Poeira de Concreto',
 'Reese de Favela':'Reese de Favela','Rim Baile':'Baile Rimshot','Sino de Lata':'Sino de Lata',
 'Sino de Lata · Quarta giusta':'Sino de Lata · Perfect Fourth','Sino de Lata · Terza maggiore':'Sino de Lata · Major Third',
 'Sino de Noite':'Sino de Noite','Sirene de Vidro':'Sirene de Vidro','Snare Phonk':'Phonk Snare',
 'Sub Asfalto':'Asphalt Sub','Voz de Asfalto':'Voz de Asfalto',
 'Corno francese':'French Horn','Corno francese · aria e ottone':'French Horn · Air and Brass',
 'Tromba con sordina':'Muted Trumpet','Tromba v3':'Trumpet v3',
 'Batteria boom-bap':'Boom-Bap Drums','Batteria hip-hop vera':'Live Hip-Hop Drums',
 'Batteria jazz':'Jazz Drums','Batteria rock':'Rock Drums','Percussioni a mano':'Hand Percussion',
 'Percussioni a Mano · Libero':'Hand Percussion · Libero','Percussioni texture':'Percussion Textures',
 'Percussioni · Texture':'Percussion · Textures','Percussioni Trailer':'Trailer Percussion',
 'Tamburi Epici':'Epic Drums','Xilofono':'Xylophone','Piano Feltro':'Felt Piano',
 'Pianoforte':'Grand Piano','Pianoforte Concerto':'Concert Grand Piano',
 'Chitarra':'Acoustic Guitar','Chitarra acustica':'Acoustic Guitar','Chitarra acustica steel-string · Libero':'Steel-String Acoustic Guitar · Libero',
 'Sintesi pad calda':'Warm Synth Pad','Sintesi pluck arpa':'Harp-Glass Pluck Synth',
 'Trap Archi':'Trap Strings','Trap Carillon':'Trap Music Box','Trap Ottone Secco':'Dry Trap Brass',
 'Trap campana':'Trap Bell','Trap Coro':'Trap Choir','Trap Coro · Libero':'Trap Choir · Libero',
 'Trap drill slide':'Trap Drill Slide','Trap Flauto':'Trap Flute','Trap Kit Italiano · Libero':'Italian Trap Kit · Libero',
 'Trap Kit · Libero':'Trap Kit · Libero','Trap kit pro':'Trap Kit Pro','Trap Kit Pro · Libero':'Trap Kit Pro · Libero',
 'Trap Lead Scuro':'Dark Trap Lead','Trap marimba scura':'Dark Trap Marimba','Trap Pad Marea':'Tidal Trap Pad',
 'Trap pad inverso':'Reverse Trap Pad','Trap pad scuro':'Dark Trap Pad','Trap Piano':'Trap Piano',
 'Trap Pluck Goccia':'Drop Trap Pluck','Trap Sub Sporco':'Dirty Trap Sub','Trap Voce Formante':'Formant Trap Voice',
 'Argo Organ':'Argo Organ','Cometa Pluck':'Comet Pluck','Cratere FM':'Crater FM','Eclisse Pad':'Eclipse Pad',
 'Elio Sync':'Helium Sync','Luna Orbita':'Lunar Orbit','Marea Celeste':'Celestial Tide','Nido Reese':'Reese Nest',
 'Orione Brass':'Orion Brass','Polvere Nebula':'Nebula Dust','Prisma Flusso':'Prism Flow','Pulsar Basso':'Pulsar Bass',
 'Quasar Arpeggio':'Quasar Arpeggio','Sirio Formante':'Sirius Formant',
 'Coro di marmo':'Marble Choir','Flauto di Pan (ricostruzione)':'Pan Flute (Reconstruction)',
 'Sassofono contralto':'Alto Saxophone','Tromba':'Trumpet','Trap Stab Orchestrale':'Orchestral Trap Stab',
 'Lead Fase':'Phase Lead','Lead Fase Live':'Phase Lead Live','Meow phonk':'Meow Phonk',
}

# Exact phrase substitutions keep technical labels, key names, and source names intact.
SUB = {
 'armonici di violoncello e contrabbasso da registrazioni vere':'cello and double-bass harmonics from genuine recordings',
 'Quattro scivolate armoniche reali, tenute sui parziali registrati stabili':'Four recorded harmonic slides, sustained on stable recorded partials',
 'archi congelati · tessitura infinita e ariosa da sostenuti veri':'frozen string tones · open, sustained texture from real long notes',
 "sezione d'archi completa, bassi in basso, violini in alto":"full string section, low basses and high violins",
 'tecniche estese':'extended techniques','sezione naturale':'natural section','dinamica dalla velocità':'velocity-controlled dynamics',
 'violino solo, sostenuto ordinario pp mf ff da registrazioni vere':'solo violin, ordinary sustain at pp/mf/ff from genuine recordings',
 'violoncello solo da registrazioni vere':'solo cello from genuine recordings','contrabbasso solo':'solo double bass',
 'quattro dinamiche':'four dynamics','due dinamiche':'two dynamics','tre dinamiche':'three dynamics',
 'registrazioni vere':'genuine recordings','registrazioni reali':'genuine recordings','registrazioni originali':'original recordings',
 'registrazioni VCSL':'VCSL recordings','registrazioni vere':'genuine recordings','registrazioni hardware':'hardware recording',
 'da registrazioni vere':'from genuine recordings','da registrazioni reali':'from genuine recordings',
 'colpo naturale':'natural strike','colpo incisivo':'punchy strike','coda lunga':'long decay','coda sub':'sub tail',
 'corpo cavo':'hollow body','fondamentale sinusoidale ferma':'stable sine fundamental','sine centrale':'central sine',
 'triangolo risonante':'resonant triangle','caldo ma leggibile':'warm yet clear','corpo scuro':'dark body',
 'movimento lento':'slow movement','quattro dinamiche · sessione quieta separata':'four dynamics · separate quiet session',
 'piano / mezzoforte / fortissimo':'piano / mezzo-forte / fortissimo','registrate':'recorded','registrati':'recorded','registrato':'recorded',
 'articolazioni':'articulations','dinamiche':'dynamics','dinamica':'dynamics','sostenuto':'sustained','staccato':'staccato',
 'pizzicato':'pizzicato','tremolo':'tremolo','sordina':'mute','senza vibrato':'without vibrato','molto vibrato':'strong vibrato',
 'sezione di violoncelli':'cello section','contrabbasso':'double bass','violoncello':'cello','violini':'violins','violino':'violin',
 'bassi in basso':'low basses','in alto':'high','in Fa':'in F','al manico':'neck pickup','corde':'strings','corda':'string',
 'coda modellata dalla stessa ripresa':'tail modelled from the same take','note cromatiche':'chromatic notes','note registrate':'recorded notes',
 'attacchi reali':'real attacks','attacco registrato':'recorded attack','corpo sostenuto derivato':'derived sustained body',
 'corpo a nastro':'tape-like body','a nastro':'tape-like','fiato vero':'real breath','fiato':'breath',
 'campane manuali':'handbells','singole note registrate':'recorded single notes','barre lignee profonde':'deep wooden bars',
 'mazze morbide e dure':'soft and hard mallets','più arco registrato':'plus recorded bowed articulation',
 'tre articolazioni di mazza':'three mallet articulations','scatola musicale':'music box','denti metallici':'metal tines',
 'coda continua':'continuous decay','ceramica soffiata':'blown ceramic','tenuta e vibrato registrati':'recorded sustain and vibrato',
 'plettro':'pick','arco lungo':'long bow','arco corto':'short bow','sega analogica viva':'live analog saw',
 'centro solido':'solid center','bordi mobili':'moving edges','campane tubolari':'tubular bells','mazze':'mallets',
 'steel string':'steel-string','chitarra jazz registrata':'recorded jazz guitar','pickup e microfono':'pickup and microphone',
 'quattro dinamiche e quattro riprese':'four dynamics and four takes','Piano a coda':'grand piano','close mic':'close microphone',
 'dinamiche e release originali preservate':'original dynamics and releases preserved','piano elettrico':'electric piano',
 'sega e quadra live':'live saw and square waves','nastro e sala buia':'tape and dark room','archi scuri':'dark strings',
 'pad scuro':'dark pad','plucked':'plucked','note':'notes','cassa':'kick drum','rullante':'snare','chiuso':'closed','aperto':'open',
 'Charleston aperto registrato':'recorded open hi-hat','Charleston chiuso registrato':'recorded closed hi-hat',
 'batteria asciutta':'dry drums','kit completo':'full kit','batteria jazz':'jazz drums','kit jazz':'jazz kit',
 'cowbell phonk':'phonk cowbell','lead vocale':'vocal lead','pad ampio':'wide pad','pad stereo':'stereo pad',
 'fondamentale ferma':'stable fundamental','coda reale':'natural tail','Tom grave corto registrato':'recorded short low tom',
 'attacco sul bordo':'rim attack','corpo armonico':'harmonic body','registro orchestrale':'orchestral register',
 'quattro divisori':'four dividers','colore scuro':'dark color','registro aperto':'open register','non triadico minore':'not a minor triad',
 'sintesi originale ispirata all’architettura, non campionamento hardware':'original synthesis inspired by the instrument architecture, not hardware sampling',
 'sintesi originale':'original synthesis','campionamento hardware':'hardware sampling','registrate':'recorded',
 'sostegno, staccato e sordina registrati':'recorded sustain, staccato, and muted articulations',
 'canna sola':'single reed','intonazione giusta sul bordone':'just intonation against the drone','dieci canne vere':'ten real pipes',
 'soffio mosso e legno':'moving breath and wood','cori e vocali':'choirs and vowels','voci registrate':'recorded voices',
 'cori scuri':'dark choirs','vocali a e o':'A/E/O vowels','nastro':'tape','vinile':'vinyl','coro':'choir',
 'aria di statue':'the breath of statues','ancia doppia scura':'dark double reed','scivoli larghi':'wide glides',
 'ricostruzione':'reconstruction','canne chiuse':'closed pipes','molto fiato':'strong breath','ricostruito da flauto e flauto dolce':'reconstructed from flute and recorder',
 'corda pizzicata':'plucked string','cassa di cipresso':'cypress soundbox','sax alto':'alto saxophone',
 'tromba, registrazioni reali':'trumpet, genuine recordings','acoustic steel string, finger and pick':'steel-string acoustic guitar, fingerstyle and pick',
 'steel string, dita e plettro':'steel-string, fingerstyle and pick','sega analogica, stereo per sfasamento':'analog saw, stereo from phase offset',
 'gatto pitchato':'pitched cat','Registrazioni e sintesi':'Recordings and synthesis',
 'sul ponticello':'near the bridge','sul tasto':'over the fingerboard','col legno tratto':'drawn col legno',
 'col legno battuto':'struck col legno','con sordino':'muted','reale della section':'real section',
 'gesti acustici':'acoustic gestures','riprese d’arco':'bow takes',"riprese d'arco":'bow takes',
 'in Do':'in C','due registrazioni originali per nota':'two original recordings per note',
 'cetra vietnamita':'Vietnamese zither','a ponticelli mobili':'with movable bridges','pizzicato, tremolo and glissando':'plucked, tremolo, and glissando',
 'TavyMusic Plucked Strings':'TavyMusic Plucked Strings','campioni reali mono':'real mono samples','registro misurato':'measured range',
 'mappa SF2 conservata':'SF2 mapping retained','corde preparate':'prepared strings','risonanza tenuta':'sustained resonance',
 'per sostenere la linea':'to support the line','quattro riprese':'four takes','riprese e dinamiche originali':'takes and original dynamics',
 'tasti FM originali':'original FM keys','colpo vellutato':'velvety strike','corpo elettrico':'electric body',
 'Chitarra classica nylon':'classical nylon guitar','note cromatiche registrate':'recorded chromatic notes',
 'Prime zither ungherese':'Hungarian prime zither','melody di default':'default melody','selezionabili':'selectable',
 'Calici sfregati':'rubbed glasses','due gesti reali':'two real gestures','batteria':'drums','registro misurato':'measured range',
 'Unisono sostenuto composto':'sustained unison assembled','esecuzioni reali':'real performances','staccati registrati secondari':'secondary recorded staccatos',
 'clarinetto in Sib':'B-flat clarinet','registrazioni IRCAM':'IRCAM recordings','respiro e legato':'breath and legato',
 'tromba aperta':'open trumpet','3 dinamiche reali':'three real dynamics','ampli crunch':'crunch amp',
 'chitarra elettrica':'electric guitar','gran coda':'concert grand','pianoforte col feltro':'felt piano',
 'bacchette di lana e gomma':'wool and rubber mallets','bacchette di palissandro':'rosewood mallets',
 'sega analogica':'analog saw','stereo per sfasamento':'stereo by phase offset','sfasamento':'phase offset',
 'quattro dinamiche/2 riprese d’arco':'four dynamics/two bow takes','acustici':'acoustic','originale':'original',
 'originali':'original','scura':'dark','scuro':'dark','completo':'full','phonk completo':'full phonk',
 'tasti GM':'GM keys','sincronizzati su':'mapped across','doppia risonanza tesa':'dual tight resonances',
 'colpo corto':'short hit','coda controllata':'controlled tail','cowbell scura':'dark cowbell',
 'ottava bassa':'low octave','attacco cavo':'hollow attack','quarta giusta superiore':'upper perfect fourth',
 'terza maggiore superiore':'upper major third','kit melodico italiano':'Italian melodic kit','kick più corto e alto':'shorter, higher kick',
 'clap a colpi ravvicinati':'closely spaced clap hits','percussione/hat articolate':'articulated percussion and hats',
 'kit essenziale':'essential kit','sweep sub scuro':'dark sub sweep','snare secco':'dry snare','hi-hat chiuso':'closed hi-hat',
 'clap breve':'short clap','kit articolato':'articulated kit','kick doppio-membrana':'dual-membrane kick',
 'clap multi-impulso':'multi-pulse clap','snare center/rimshot':'center snare/rimshot',
 'lead agudo':'high lead','impulso stretto':'narrow pulse','centro triangolare':'triangle-wave center',
 'formante vocale':'vocal formant','bassline a impulsi':'pulse bassline','quadro morbido':'soft square wave',
 'lead bright':'bright lead','bordo di ottava':'octave edge','pluck brillante':'bright pluck','triangolo caldo':'warm triangle wave',
 'pad senza accordo baked':'un-chorded pad, no baked chord','sega soffice':'soft saw','bordi lenti':'slow edges',
 'kit Memphis':'Memphis kit','snare centrale':'center snare','tom e close cymbals':'tom and close-miked cymbals',
 'lead sincopato':'syncopated lead','sega tagliata':'gated saw','impulso duro':'hard pulse','ring mod a registro':'register-based ring modulation',
 'con discesa di nota breve':'with a short pitch drop','fondamentale stabile':'stable fundamental','fino al note-off':'through note-off',
 'texture ritmica pitched':'pitched rhythmic texture','sega bassa':'low saw','grana d’oscillatore controllata':'controlled oscillator grain',
 'centro sega denso':'dense saw center','bordi detunati':'detuned edges','sub mono':'mono sub','attacco sul bordo':'rim attack',
 'livelli e round robin':'layers and round robins','due quadre strette':'two narrow square waves','intervallo di quinta aumentata':'augmented-fifth interval',
 'triangolo metallico':'metallic triangle wave','ottava bassa':'low octave','lead inarmonico senza accordo':'unpitched lead with no baked chord',
 'fondamentale sinusoidale centrale':'central sine fundamental','partiale sega a tritono':'saw partial at a tritone','centro del fusto close-top':'close top-mic drumhead center',
 'corno in Fa':'F horn','sordina dritta':'straight mute','batteria jazz':'jazz drums','rullante grasso':'fat snare','rullante secco':'dry snare',
 'snare fat':'fat snare','kick':'kick','rimshot':'rimshot','hi-hat':'hi-hat','chiuso':'closed','aperto':'open','ride':'ride','crash':'crash',
 'bongos':'bongos','congas':'congas','nacchere':'castanets','tamburi':'drums','shaker':'shaker','tamburello':'tambourine','triangolo':'triangle',
 'campanacci':'cowbells','grancassa':'bass drum','piatti':'cymbals','molle e raganelle':'springs and rattles','campane e campanelli':'bells and chimes',
 'frusta e guiro':'slapstick and güiro','hits':'hits','booms':'booms','risers':'risers','swells':'swells','gran coda':'concert grand',
 'decay naturale':'natural decay','tine vere':'real tines','pad analogico':'analog pad','coro':'chorus','caldo e largo':'warm and wide',
 'pluck di vetro':'glass pluck','per arpeggi':'for arpeggios','eco puntato dal vivo':'tempo-synced live echo',
 'cori indipendenti':'independent choir performers','A/E/O registrate':'recorded A/E/O vowels','corpo sostenuto derivato':'derived sustained body',
 'corpo risonante sostenuto':'sustained resonant body','colpo metallico':'metallic hit','pad scuro':'dark pad',
 'fundamentale':'fundamental','lead sync':'sync lead','morso spettrale mobile':'moving spectral bite','lead caldo':'warm lead',
 'portante piena':'full carrier','corona armonica':'harmonic halo','pad stereo':'stereo pad','corpo triangolare':'triangle-wave body',
 'marea lenta':'slow tide','basso largo':'wide bass','due centri battenti':'two beating centers','lead gonfio':'swollen lead',
 'impulsi pari':'even harmonics','attacco arcuato':'arched attack','pad ampio':'wide pad','tre corone armoniche mobili':'three moving harmonic halos',
 'registro vocale':'vocal register','si apre lentamente':'opens slowly','basso caldo':'warm bass','sine piena':'full sine','basso caldo':'warm bass',
 'bordo di triangolo':'triangle edge','ottave e quinte in moto regolare':'regularly moving octaves and fifths','lead vocale':'vocal lead',
 'arco di formante controllato':'controlled formant arc','organo cosmico':'cosmic organ','drawbar pari e terzi armonici':'even drawbars and third harmonics',
 'pluck synth':'synth pluck','attacco breve':'short attack','corpo risonante sostenuto':'sustained resonant body','tasti FM':'FM keys',
 'fondamentale sine':'sine fundamental','corpo sub-ottava':'sub-octave body','lead sync':'sync lead','fondamentale ferma':'stable fundamental',
 'pad morph':'morph pad','synth spaziali':'space synths','coda continua':'continuous decay',
 'tasti':'keys','sost':'sustain','destra':'right','cinque':'five','ripetizioni':'repetitions','rilascio':'release',
 'unghie':'fingernails','polifoniche':'polyphonic','tastiera':'keyboard','reinterpretata':'reimagined','livelli':'layers',
 'pelle':'drumhead','che':'that','sega':'saw','miagolio':'meow','della':'of the','delle':'of the','nel':'in the',
 'sax alto':'alto saxophone','tromba':'trumpet','sordina':'mute','aperto':'open','dinamiche originali':'original dynamics',
 'tesa':'taut','asimmetrico':'asymmetric','ampli':'amp','volta':'Vault','radura':'Glade','cenere':'Ash','pietra':'Stone','mezzo':'Mezzo','rito':'Rite','default melody':'default melody','cello section':'cello section',
 'restano':'remain','inglese':'English','spazzole':'brushes','strumenti':'instruments','fusto':'shell','metallica':'metal',
 'sul':'on the','accordatura':'tuning','piano':'piano','mezzo-forte':'mezzo-forte','fortissimo':'fortissimo',
 'elastico':'springy','morso':'bite','ritorno':'return','rotondo':'rounded','centrale':'central','registro':'register',
 'armoniche':'harmonics','maggiore':'major','minore':'minor','maggiore':'major','cromatica':'chromatic',
 'nylon spagnolo':'Spanish nylon','sintesi':'synthesis','diretta':'direct','pulito':'clean','saturato':'saturated',
 'voce':'voice','vocalico':'vocal','scivola':'slides','nota':'note','dark':'dark','che si apre':'that opens',
}

SUB_EXACT={
 'Tremolo reale della sezione cello, staccato/pizzicato e gesti acustici':'Real cello-section tremolo, staccato/pizzicato, and acoustic gestures',
 "contrabbasso solo (fondo a destra) · tasti C0 sost · C#0 marc · D0 stacc · D#0 pizz · E0 trem · dinamica CC1":"solo double bass (back right) · keys C0 sustain · C#0 marcato · D0 staccato · D#0 pizzicato · E0 tremolo · CC1 dynamics",
 'violino solo, sostenuto ordinario pp mf ff da registrazioni vere':'solo violin, ordinary sustain at pp/mf/ff from genuine recordings',
 'violoncello solo da registrazioni vere · C0 sost · C#0 breve · D0 stacc · D#0 senza vibrato · E0 molto vibrato · F0 col legno · F#0/G0 trilli':'solo cello from genuine recordings · C0 sustain · C#0 short · D0 staccato · D#0 without vibrato · E0 strong vibrato · F0 col legno · F#0/G0 trills',
 "Bigcat Cello · 4 dinamiche/2 riprese d'arco, staccato e pizzicato reali":'Bigcat Cello · four dynamics/two bow takes, recorded staccato and pizzicato',
 'Hohner Special 20 in Do · ancia e fiato reali':'Hohner Special 20 in C · reed and breath recorded',
 'corde pizzicate · due registrazioni originali per nota':'plucked strings · two original recordings per note',
 'ancia doppia grave · pp, mf e ff registrati':'low double reed · recorded pp, mf, and ff dynamics',
 'ancia doppia · pp, mf e ff registrati':'double reed · recorded pp, mf, and ff dynamics',
 'Schoenhut My First Piano · attacchi reali, risonanza infinita':'Schoenhut My First Piano · real attacks, designed infinite resonance',
 'CCRMA2011 · corde preparate per Cage · risonanza tenuta':'CCRMA2011 · prepared strings for Cage · sustained resonance',
 'Contrabbasso pizzicato Rubner · D. Smolken · quattro riprese e dinamiche originali':'Rubner pizzicato double bass · D. Smolken · four takes and original dynamics',
 'Sintesi originale a formanti mobili, fondamentale stabile e registro di legno':'Original synthesis with moving formants, stable fundamental, and woody register',
 'pad additivo originale · registro pieno e formanti mobili':'Original additive pad · full register and moving formants',
 'Prime zither ungherese · melody di default · strum down/up selezionabili · due o tre riprese reali':'Hungarian prime zither · default melody · selectable down/up strums · two or three recorded takes',
 'C3-B3 maggiori · C4-B4 minori · C5-B5 settime; giù/su':'C3–B3 major · C4–B4 minor · C5–B5 seventh chords; down/up strums',
 'Z=C3 maggiori, C4 minori, C5 settime. Pollice giu, dita su (take alternati)':'Z=C3 major, C4 minor, C5 seventh chords. Thumb down, fingers up (alternating takes)',
 'Accordi maggiori/minori da note nylon indipendenti; strum composto, non registrato':'Major/minor chords assembled from independent nylon-note recordings; composed strum, not a recorded chord performance',
 'lead FM · due portanti, corpo vellutato':'FM lead · two carriers, velvety body',
 'pad FM · campane elettroniche su corpo morbido':'FM pad · electronic bells over a soft body',
 'pad di corde elettroniche · sette seghe e centro morbido':'Electronic string pad · seven saw oscillators and a soft center',
 'pad armonico · registri mobili e bordi aperti':'Harmonic pad · moving registers and open edges',
 'Clap sintetico originale · quattro transienti ravvicinati, schiocco largo e pelle breve':'Original synthesized clap · four close transients, wide snap, and short membrane body',
 'pluck sintetico · triangolo morbido, impulso corto e corpo sostenuto':'Synth pluck · soft triangle, short pulse, and sustained body',
 'marimba da concerto, bacchette di lana e gomma':'Concert marimba, wool and rubber mallets',
 'xilofono da concerto, bacchette di palissandro':'Concert xylophone, rosewood mallets',
 'Rhodes elettrico, 5 dinamiche, tine vere':'Electric Rhodes, five dynamics, real tines',
 'Trap Kit · Libero':'Essential kit: dark sub sweep, dry snare, closed hi-hat, and short clap',
 'Trap Kit Italiano · Libero':'Italian melodic kit: shorter, higher kick; close-spaced clap hits; articulated percussion and hats',
 'Coro scuro di performer VocalSet indipendenti · A/E/O registrate, due dinamiche e micro-scaglionamento di entrata reale':'Dark choir from independent VocalSet performers · recorded A/E/O vowels, two dynamics, and subtle real entrance offsets',
 'marimba scura, nastro e eco al buio':'Dark marimba, tape, and shadowed echo',
 'armonica di vetro, campana sfiorata':'Glass harmonica, lightly touched bell',
 'tecniche estese · C0 sul ponticello · C#0 sul tasto · D0 col legno tratto · D#0 col legno battuto · E0 con sordino · F0 au talon · F#0 pizzicato Bartok':'Extended techniques · C0 near the bridge · C#0 over the fingerboard · D0 drawn col legno · D#0 struck col legno · E0 muted · F0 au talon · F#0 Bartók pizzicato',
 'VCSL · legno alto e mazze distinte · attacco registrato, corpo sostenuto derivato':'VCSL · upper-register wood bars with distinct mallets · recorded attack, derived sustained body',
 'pad di corde elettroniche · sette seghe e centro morbido':'Electronic string pad · seven saws and a soft center',
 'impulsi larghi · triangolo centrale e PWM':'Wide pulses · central triangle and PWM',
 'morph synth · tre profili periodici in movimento':'Morph synth · three moving periodic profiles',
 'pad senza accordo baked · centro triangolare, sega soffice e bordi lenti':'Un-chorded pad · triangle-wave center, soft saw, and slow edges',
 'pluck brillante · triangolo caldo e partiale alto quasi campana':'Bright pluck · warm triangle and high partial near a bell tone',
 'lead inarmonico senza accordo · fondamentale sinusoidale centrale e partiale sega a tritono':'Inharmonic lead without a baked chord · central sine fundamental and saw partial at a tritone',
 'pad e pluck scuro, largo e pulito':'Dark pad and pluck, wide and clean',
 'organ cosmico · drawbar pari e terzi armonici':'Cosmic organ · even drawbars and third harmonics',
 'lead gonfio · impulsi pari, attacco arcuato':'Swollen lead · even harmonics, arched attack',
 'Kay closed-back banjo · dita, corde smorzate e armonici':'Kay closed-back banjo · fingers, muted strings, and harmonics',
 "sezione d'archi completa, bassi in basso, violini in alto · tasti C0 sost · C#0 marc · D0 stacc · D#0 pizz · E0 trem · dinamica CC1":"full string section, low basses, high violins · keys C0 sustain · C#0 marcato · D0 staccato · D#0 pizzicato · E0 tremolo · CC1 dynamics",
 'sezione naturale · C0 sostenuto · D0 spiccato · D#0 pizzicato · E0 tremolo · dinamica dalla velocità':'natural section · C0 sustained · D0 spiccato · D#0 pizzicato · E0 tremolo · velocity-controlled dynamics',
 'sezione di violoncelli (a destra) · tasti C0 sost · C#0 marc · D0 stacc · D#0 pizz · E0 trem · dinamica CC1':'cello section (right side) · keys C0 sustain · C#0 marcato · D0 staccato · D#0 pizzicato · E0 tremolo · CC1 dynamics',
 'Darkblack cinque corde · quattro dinamiche · corpo cavo':'Darkblack five-string bass · four dynamics · hollow body',
 'Otto Rubner 1958 · quattro dinamiche · sessione quieta separata':'Otto Rubner 1958 · four dynamics · separate quiet session',
 'VCSL · campane tubolari con dinamiche originali':'VCSL · tubular bells with original dynamics',
 'Chitarra jazz registrata · pickup e microfono · quattro dinamiche e quattro riprese':'Recorded jazz guitar · pickup and microphone · four dynamics and four takes',
 'Piano a coda Steinway B · close mic VCSL · dinamiche e release originali preservate':'Steinway B grand piano · VCSL close microphone · original dynamics and releases preserved',
 'Epiphone flatwound · 4 dinamiche · 3 ripetizioni':'Epiphone flatwound · four dynamics · three repetitions',
 'Chitarra classica nylon · FreePats · note cromatiche registrate':'Classical nylon guitar · FreePats · recorded chromatic notes',
 'steel string, 3 dinamiche, 3 take, rilascio':'steel-string, three dynamics, three takes, natural release',
 'nylon, due dinamiche, dita e unghie':'nylon, two dynamics, fingers and fingernails',
 'Squidpipes registrate · ance polifoniche a nastro':'Recorded Squidpipes · polyphonic reed tape',
 'fiato vero · tastiera a nastro reinterpretata':'real breath · reimagined tape keyboard',
 'tromba, corno e trombone · registro orchestrale a nastro':'trumpet, horn, and trombone · orchestral tape register',
 'Clap sintetico originale · quattro transienti ravvicinati, schiocco largo e pelle breve':'Original synthesized clap · four close transients, wide snap, and short drumhead body',
 'Kit phonk completo · kick phonk/baile, snare, clap, hats, rim e tom sincronizzati su otto tasti GM':'Full phonk kit · phonk/baile kicks, snare, clap, hats, rim, and tom across eight GM keys',
 'Rullante registrato · centro del fusto close-top, dinamiche e round robin Big Rusty':'Recorded snare · Big Rusty close-top head center, dynamics, and round robins',
 'lead vocale · ancia sega e triangolo, centro di formanti medio-basso':'vocal lead · saw reed and triangle, low-mid formant center',
 'C2 bongos · F#2 congas · D#3 nacchere · F#3 darbuka · B3 tamburi · F4 shaker · C5 tamburello · F#5 triangolo · A#5+ claves/legni/campanacci':'C2 bongos · F#2 congas · D#3 castanets · F#3 darbuka · B3 drums · F4 shaker · C5 tambourine · F#5 triangle · A#5+ claves/woodblocks/cowbells',
 'Yamaha C5 · 16 livelli · decay naturale':'Yamaha C5 · 16 velocity layers · natural decay',
 'lead scuro che scivola nella nota':'dark lead that slides into the note',
 'pad che si muove, scuro':'dark moving pad',
 'pad scuro che sboccia al contrario':'dark pad that blooms in reverse',
 'sax alto, registrazioni IRCAM TinySOL':'alto saxophone · IRCAM TinySOL recordings',
 "sega live, il miagolio e' il filtro che si apre":"live saw; the meow is the filter opening",
 'gatto pitchato; Z=C3 tastiera; one-shot C7 mew, C#7 meow, D7 basso, D#7 reverse':'pitched cat; Z=C3 keyboard; one-shot C7 mew, C#7 meow, D7 bass, D#7 reverse',
 'flauto dolce contralto · dritta, vibrata and staccata':'alto recorder · straight, vibrato, and staccato',
 'flute dolce contralto, VCSL recordings':'alto recorder · VCSL recordings',
 'VCSL · canne real · registri 8′, 4′ and full':'VCSL · real pipes · 8′, 4′, and full stops',
 'strings plucked dietro il ponte, suono of kalimba':'strings plucked behind the bridge, with a kalimba-like tone',
 'TavyMusic plucked Strings · real mono samples, measured range, SF2 mapping retained':'TavyMusic Plucked Strings · real mono samples, measured range, SF2 mapping retained',
 'registrazioni dal vivo, calde e piene':'warm, full live recordings',
 'Theremin sintetico · corpo caldo e colore più ricco':'Synth Theremin · warm body and richer color',
 'Theremin sintetico · quasi sinusoidale, sottile e luminoso':'Synth Theremin · near-sine tone, thin and bright',
 'Sintesi a sega · due risonanze parallele ispirate al VT':'Saw synthesis · two parallel resonances inspired by the VT',
 'Sintesi a sega · prefiltri e registro essenziale':'Saw synthesis · prefilters and a focused register',
 'Quattro divisori 1:2:3:4 · registro aperto, non triadico minore':'Four dividers 1:2:3:4 · open register, not a minor triad',
 'Quattro divisori 1:2:4:7 · colore scuro con settima subarmonica':'Four dividers 1:2:4:7 · dark color with a subharmonic seventh',
}

def translate(text: str, table: dict[str,str]) -> str:
    if text in SUB_EXACT:return SUB_EXACT[text]
    if text in table: return table[text]
    out=text
    # Whole phrase replacements first; keep spelling/case in technical names and MIDI notes.
    for old,new in sorted(SUB.items(),key=lambda kv:-len(kv[0])):
        # Match complete words/phrases only. Without these guards, e.g. `corde`
        # corrupts the English word `recorded` into `restringsd`.
        out=re.sub(r'(?<![A-Za-zÀ-ÿ0-9])'+re.escape(old)+r'(?![A-Za-zÀ-ÿ0-9])',new,out,flags=re.IGNORECASE)
    # Last-mile generic instrument terms, preserving existing user/aura names.
    words=[('grancassa','bass drum'),('batteria','drums'),('percussioni','percussion'),('pianoforte','piano'),
           ('pianoforti','pianos'),('arpa','harp'),('violini','violins'),('violino','violin'),('violoncelli','cellos'),
           ('violoncello','cello'),('viole','violas'),('archi','strings'),('ottoni','brass'),('tromba','trumpet'),
           ('trombone','trombone'),('corno','horn'),('flauto','flute'),('clarinetto','clarinet'),('fagotto','bassoon'),
           ('oboe','oboe'),('ance','reeds'),('ancia','reed'),('coro','choir'),('cori','choirs'),('voce','voice'),
           ('voci','voices'),('risonanza','resonance'),('risonanze','resonances'),('sostenuto','sustained'),
           ('sostegno','sustain'),('attacco','attack'),('decadimento','decay'),('coda','tail'),('corpo','body'),
           ('legno','wood'),('lignee','wooden'),('metallo','metal'),('campana','bell'),('campane','bells'),
           ('pizzicate','plucked'),('pizzicata','plucked'),('pizzicato','pizzicato'),('basso','bass'),('bassi','basses'),
           ('caldo','warm'),('calda','warm'),('caldi','warm'),('fredda','cold'),('oscura','dark'),('scuro','dark'),
           ('ampio','wide'),('ampia','wide'),('stabile','stable'),('stabili','stable'),('originale','original'),
           ('originali','original'),('vera','real'),('vere','real'),('vero','real'),('veri','real'),('registrata','recorded'),
           ('registrate','recorded'),('registrato','recorded'),('registrati','recorded'),('dinamica','dynamics'),
           ('dinamiche','dynamics'),('sezione','section'),('sezioni','sections'),('solista','solo'),('speciali','special'),
           ('particolari','unusual'),('congelati','frozen'),('congelate','frozen'),('armonici','harmonics'),
           ('armoniche','harmonic'),('armonico','harmonic'),('morbide','soft'),('dure','hard'),('lungo','long'),
           ('corto','short'),('notturno','night'),('notturna','night'),('profondo','deep'),('profonda','deep'),
           ('vivo','live'),('viva','live'),('vibrato','vibrato'),('sordina','mute'),('mani','hand'),('a mano','hand'),
           ('ritmica','rhythmic'),('ritmico','rhythmic'),('pieno','full'),('piena','full'),('buia','dark'),('buio','dark')]
    words.extend([('di','of'),('da','from'),('con','with'),('e','and'),('per','for'),('su','on'),('a','to'),('in','in'),
                  ('dita','fingers'),('smorzate','muted'),('impulsi','pulses'),('larghi','wide'),('larga','wide'),
                  ('centro','center'),('profilo','profile'),('profili','profiles'),('periodici','periodic'),('movimento','motion'),
                  ('parziale','partial'),('alto','high'),('quasi','nearly'),('cosmico','cosmic'),('gonfio','swollen'),
                  ('sette','seven'),('italiano','Italian'),('superiore','upper'),('doppia','double'),('grave','low'),
                  ('singole','single'),('elettrico','electric'),('elettroniche','electronic'),('morbido','soft'),('morbida','soft'),
                  ('controllata','controlled'),('bassa','low'),('quattro','four'),('tre','three'),('due','two'),
                  ('reali','real'),('registrate','recorded'),('registrati','recorded'),('registrato','recorded'),
                  ('reale','real'),('ferma','stable'),('mobili','moving'),('cavo','hollow'),('aperto','open'),('aperta','open')])
    for old,new in sorted(words,key=lambda kv:-len(kv[0])):
        out=re.sub(r'(?<![A-Za-zÀ-ÿ0-9])'+re.escape(old)+r'(?![A-Za-zÀ-ÿ0-9])',new,out,flags=re.IGNORECASE)
    return out

BANKS={
 'archi':('Strings','Ensembles, soloists, and extended techniques: violins, violas, cellos, double basses, harmonics, and special gestures.'),
 'aria':('Aria','Played wood, metal, strings, and winds.'),'bassi':('Bass','Wood, strings, sub, and 808.'),
 'bebop':('Bebop','Jazz · solo, section, and rhythm.'),'blue':('Blue','Keys, reeds, and resonances.'),
 'chitarre':('Guitars','Steel, nylon, electric, and chord instruments.'),'cielo':('Cielo','Eight choirs and voices · sustained tones.'),
 'flauti':('Flutes','Pipes, reeds, and woodwinds.'),'giove':('Giove','Warm analog tones · tapes and continuous instruments.'),
 'green':('Green','Leads, synths, and harmonic fields.'),'mog':('Mog','Memphis and Brazilian phonk · drum kits, leads, cowbells, and bass.'),
 'ottoni':('Brass','Open and muted trumpets.'),'percussioni':('Percussion','Drums, hand percussion, and cinematic hits.'),
 'piano':('Piano','Concert grand, felt, and tape.'),'sintesi':('Synthesis','Analog pads and plucks, pure waves.'),
 'trap':('Trap','Choirs, orchestras, tape, and vinyl.'),'venere':('Venere','Space synths · leads, ambient, and bass.')}
BANK_DESCRIPTIONS={
 'archi':'Recorded string instruments with keyswitch articulations. Mixed licenses: sections CC0 (VSCO 2 CE); violino-solo CC BY 4.0 (TinySOL); violoncello-solo, archi-armonici, and archi-particolari from Philharmonia samples, CC BY-SA 3.0, private lane (not to be distributed as-is).',
 'aria':'Twenty instruments: acoustic recordings, resonances, and prepared instruments. Six additions include mandolin, oboe, bassoon, baroque alto recorder, gong, and dan tranh.',
 'bassi':'Jazz double bass, two sampled electric basses, three subs, and three 808s from hardware recordings. Slap replacement pending: the previous version is archived outside the library. Abletunes 808s are for this personal installation; bank export is blocked by the license.',
 'bebop':'Thirteen jazz instruments: trumpet, trombone, horn, tuba, four saxophones, clarinet, Steinway grand piano, archtop guitar, double bass, and drums. Articulations, dynamics, and round robins preserve the recordings available for each source.',
 'blue':'Eighteen instruments: keyboards and organs, plucked strings, free reeds, and original synthesis. New voices include zither, nylon guitar, concertina, banjo, pickup strings, and formants.',
 'chitarre':'Guitars from genuine recordings, with major and minor chord sections.',
 'cielo':'Seven approved vocal identities with original attacks and sustained tails, plus Choir · Horizon: broad sections of independent performers. All vowels and dynamics remain available. Children await a new source.',
 'flauti':'Flute and reed instruments: aulos, clarinet, concert flute, recorder, and Pan Pipes. Pan Pipes retain more motion from the recorded breath without added effects.',
 'green':'Twelve original electronic instruments: phase, FM, and sync leads; pulses, brass, synth bass, and harmonic pads. Solid central bodies and moving stereo registers. Live oscillators and explicit synthesized cycles sustain notes until release.',
 'mog':'Twenty-eight phonk and Brazilian phonk programmes: leads, basses, cowbells, textures, two hybrid kits, eight individual drums, and a dedicated kit. Sino de Lata also comes in major-third and perfect-fourth versions.',
 'ottoni':'Brass instruments from genuine recordings.',
 'percussioni':'A jazz drum kit, hand percussion, and cinematic drums.',
 'piano':'Pianos from genuine recordings: a Yamaha concert grand (Salamander), a Steinway B, and felt-and-tape piano.',
 'venere':'Fourteen original programmes inspired by space: leads, pads, plucks, organs, basses, and textures. Quasar uses a sequence internal to the sample, without DAW tempo synchronization.'}

def hfile(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def atomic_text(path: Path, content: str):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    # Atomic replace also breaks any legacy staging hardlink. Preserve the
    # destination's ordinary readability instead of inheriting mkstemp's 0600.
    mode=stat.S_IMODE(path.stat().st_mode) if path.exists() else 0o644
    fd,tmp=tempfile.mkstemp(prefix=f'.{path.name}.',suffix='.tmp',dir=path.parent)
    try:
        os.fchmod(fd,mode)
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as f:f.write(content)
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
def source_hash(folder):
    h=hashlib.sha256(); sp=folder/'sound.py';h.update(b'sound.py\0');h.update(sp.read_bytes() if sp.exists() else b'')
    sd=folder/'samples'
    if sd.exists():
        for p in sorted(x for x in sd.rglob('*') if x.is_file() and not x.name.startswith('.') and '__pycache__' not in x.parts):
            h.update(p.relative_to(folder).as_posix().encode()+b'\0');h.update(bytes.fromhex(hfile(p)))
    return h.hexdigest()
def audio_hashes(folder):
    build=folder/'build'
    return {p.relative_to(build).as_posix():hfile(p) for p in sorted(build.rglob('*')) if p.is_file() and p.suffix.lower() in {'.wav','.flac'}}

def literal_changes(src: str, new_title: str, new_subtitle: str):
    tree=ast.parse(src); candidates=[]
    raw=src.encode('utf-8'); lines=raw.splitlines(keepends=True)
    for node in ast.walk(tree):
        if not isinstance(node,ast.Call):continue
        fn=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else ''
        if fn not in {'Sound','retitle'}:continue
        kws={kw.arg:kw.value for kw in node.keywords}
        title_node=kws.get('title') or (node.args[0] if node.args else None)
        if title_node is None:continue
        for key,value in [('title',new_title),('subtitle',new_subtitle)]:
            oldnode=kws.get(key)
            if oldnode is None: continue
            if not isinstance(oldnode,ast.Constant) or not isinstance(oldnode.value,str):continue
            s=oldnode.lineno-1;e=oldnode.end_lineno-1
            start=sum(len(x) for x in lines[:s])+oldnode.col_offset; end=sum(len(x) for x in lines[:e])+oldnode.end_col_offset
            candidates.append((start,end,repr(value).encode('utf-8')))
    # Some generated live instruments use SPEC['title']/SPEC['sub']; translate
    # those source literals without disturbing any synthesis or articulation data.
    for node in tree.body:
        if not isinstance(node,ast.Assign) or not any(isinstance(t,ast.Name) and t.id=='SPEC' for t in node.targets):continue
        if not isinstance(node.value,ast.Dict):continue
        for k,v in zip(node.value.keys,node.value.values):
            if isinstance(k,ast.Constant) and isinstance(v,ast.Constant) and k.value in {'title','sub'}:
                value=new_title if k.value=='title' else new_subtitle
                start=sum(len(x) for x in lines[:v.lineno-1])+v.col_offset
                end=sum(len(x) for x in lines[:v.end_lineno-1])+v.end_col_offset
                candidates.append((start,end,repr(value).encode('utf-8')))
    if not candidates:raise ValueError('no literal Sound/SPEC display labels found')
    for a,b,v in sorted(candidates,reverse=True):raw=raw[:a]+v+raw[b:]
    return raw.decode('utf-8')

def main():
    program_entries=[]; moved=[]; audio_ledger={}
    prior_rows={}
    if '--apply' in sys.argv and REPORT.exists():
        try:
            prior=json.loads(REPORT.read_text())
            if prior.get('phase') in {'applied','applying'}:prior_rows={x['slug']:x for x in prior.get('presets',[])}
        except (OSError,ValueError,KeyError):
            prior_rows={}
    roots=[HOME/'banks',HOME/'sounds',HOME/'sketches']
    manifests=[]
    for root in roots:
        manifests += [p for p in sorted(root.rglob('build/manifest.json'))
                      if '/old/' not in p.as_posix() and p.parent.parent.name not in SCOPE_EXCLUSIONS]
    if len(manifests)!=242:raise RuntimeError(f'expected active library inventory 242, found {len(manifests)}')
    for mf in manifests:
        folder=mf.parent.parent; manifest=json.loads(mf.read_text());slug=manifest.get('slug',folder.name)
        src=folder/'sound.py';tree=ast.parse(src.read_text());vals=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Call):
                fn=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else ''
                if fn not in {'Sound','retitle'}:continue
                kw={x.arg:x.value for x in node.keywords}
                title_node=kw.get('title') or (node.args[0] if node.args else None)
                if title_node is not None:
                    get=lambda x: ast.literal_eval(kw[x]) if x in kw else ''
                    if isinstance(title_node,ast.Constant):vals.append((ast.literal_eval(title_node),get('subtitle')))
                    else:vals.append((manifest.get('title',''),manifest.get('subtitle','')))
        if len(vals)!=1:raise RuntimeError(f'{src}: expected one literal title, got {vals}')
        old_t,old_s=vals[0]
        prior_row=prior_rows.get(slug)
        if prior_row:
            old_t=prior_row.get('recipe_title_before',old_t)
            old_s=prior_row.get('subtitle_before',old_s)
        new_t=TITLE.get(old_t,translate(old_t,{}));new_s=translate(old_s,{})
        deferred=slug in DEFERRED
        target_path=folder
        if slug in MALLET:
            target_path=HOME/'banks/percussioni'/slug
            moved.append({'slug':slug,'from':prior_row.get('old_path',str(folder)) if prior_row else str(folder),'to':str(target_path),'action':'move without duplication' if folder!=target_path else 'already moved; route remains unique'})
        # Hash full compiled-zone audio only during the actual apply pass;
        # `--plan` remains a quick inventory operation.
        audio_before=audio_hashes(folder) if '--apply' in sys.argv else {}
        entry={'slug':slug,'old_path':prior_row.get('old_path',str(folder)) if prior_row else str(folder),'new_path':str(target_path),'title_before':prior_row.get('title_before',manifest.get('title',old_t)) if prior_row else manifest.get('title',old_t),'title_after':new_t,
               'subtitle_before':prior_row.get('subtitle_before',manifest.get('subtitle',old_s)) if prior_row else manifest.get('subtitle',old_s),'subtitle_after':new_s,'recipe_title_before':old_t,'recipe_title_after':new_t,
               'deferred':deferred,'source_hash_before':prior_row.get('source_hash_before',source_hash(folder)) if prior_row else source_hash(folder),'source_hash_after':None,
               'compiled_audio_sha256_before':prior_row.get('compiled_audio_sha256_before',audio_before) if prior_row else audio_before,'compiled_audio_sha256_after':None}
        program_entries.append(entry);audio_ledger[slug]=audio_before
    if not program_entries:raise RuntimeError('empty migration')
    if '--plan' in sys.argv:
        REPORT.write_text(json.dumps({'format':'libero.display-name-migration/1','phase':'planned','preset_count':len(program_entries),'excluded_historical':1,'excluded_by_scope':sorted(SCOPE_EXCLUSIONS),
            'deferred_slugs':sorted(DEFERRED),'preserved_names_policy':'Keep proper/aura names (Aria, Giove, Nettuno, Cielo, Venere, Mog, Bebop, Blue, Green, Ambra, Cedro, Ellen, and poetic instrument identities); translate common instrument and role terms.',
            'banks':BANKS,'bank_descriptions_after':BANK_DESCRIPTIONS,'ui_files':['ui/index.html','ui/js/main.js','ui/js/library.js','ui/js/mock.js','ui/js/params.js','ui/js/controls.js'],'moves':moved,'presets':program_entries},indent=2,ensure_ascii=False)+'\n')
        print(f'wrote plan {REPORT} ({len(program_entries)} active presets)');return
    if '--apply' not in sys.argv:raise SystemExit('use --plan or --apply')
    # Capture the full plan before mutation as a reversible journal.
    plan={'format':'libero.display-name-migration/1','phase':'applying','preset_count':len(program_entries),'excluded_historical':1,'excluded_by_scope':sorted(SCOPE_EXCLUSIONS),
          'deferred_slugs':sorted(DEFERRED),'preserved_names_policy':'Keep proper/aura names (Aria, Giove, Nettuno, Cielo, Venere, Mog, Bebop, Blue, Green, Ambra, Cedro, Ellen, and poetic instrument identities); translate common instrument and role terms.',
          'banks':BANKS,'bank_descriptions_after':BANK_DESCRIPTIONS,'ui_files':['ui/index.html','ui/js/main.js','ui/js/library.js','ui/js/mock.js','ui/js/params.js','ui/js/controls.js'],'moves':moved,'presets':program_entries}
    REPORT.parent.mkdir(parents=True,exist_ok=True);REPORT.write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n')
    for item in program_entries:
        if item['deferred']:continue
        folder=Path(item['new_path']) if Path(item['new_path']).exists() else Path(item['old_path'])
        sp=folder/'sound.py';atomic_text(sp,literal_changes(sp.read_text(),item['recipe_title_after'],item['subtitle_after']))
        if item['slug'] in MALLET and folder!=Path(item['new_path']):
            target=Path(item['new_path'])
            if target.exists():raise RuntimeError(f'mallet target already exists, refusing overwrite: {target}')
            shutil.move(str(folder),str(target));folder=target
        manifest_path=folder/'build/manifest.json';m=json.loads(manifest_path.read_text())
        m['title']=item['title_after'];m['subtitle']=item['subtitle_after']
        m['source_hash']=source_hash(folder)
        atomic_text(manifest_path,json.dumps(m,indent=2,ensure_ascii=False)+'\n')
        item['source_hash_after']=m['source_hash'];item['compiled_audio_sha256_after']=audio_hashes(folder)
        actual_before=audio_ledger[item['slug']]
        if item['compiled_audio_sha256_after']!=actual_before and actual_before:
            raise RuntimeError(f'compiled audio changed during this migration for {item["slug"]}')
        if item['compiled_audio_sha256_after']!=item['compiled_audio_sha256_before']:raise RuntimeError(f'compiled audio baseline changed for {item["slug"]}')
    # Bank membership is folder-based: the two moves above are the registry
    # change; bank.json intentionally carries only bank-level display metadata.
    for slug,(title,subtitle) in BANKS.items():
        bp=HOME/f'banks/{slug}/bank.json';d=json.loads(bp.read_text());d['title']=title;d['subtitle']=subtitle
        if slug in BANK_DESCRIPTIONS:d['description']=BANK_DESCRIPTIONS[slug]
        for prog in d.get('programs',[]):
            match=next((x for x in program_entries if x['slug']==prog['slug']),None)
            if match:
                prog['title']=match['title_after'];prog['role']=match['subtitle_after']
        atomic_text(bp,json.dumps(d,indent=2,ensure_ascii=False)+'\n')
    # Recompute moved mallet route roots only; no build or audio render is performed.
    now=datetime.now(timezone.utc).isoformat()
    plan['phase']='applied';plan['applied_utc']=now;plan['zone_audio_hashes_identical']=all(x['compiled_audio_sha256_before']==x['compiled_audio_sha256_after'] for x in program_entries if not x['deferred'])
    REPORT.write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n')
    print(f'applied {sum(not x["deferred"] for x in program_entries)} text-only labels; {len(DEFERRED)} deferred; audio hashes identical={plan["zone_audio_hashes_identical"]}; report={REPORT}')
if __name__=='__main__':main()
