#!/usr/bin/env python3
"""Build six original SYN programs for Giove, inspired by documented circuitry.

The rendered sample zones are first-party digital synthesis, not samples of
commercial instruments. The installed patch selects Libero's native Legato mode
by default so overlapping MIDI notes slide without a fresh attack.
"""
from __future__ import annotations

import collections
import hashlib
import json
import math
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero import render

BANK=Path.home()/'Libero/banks/giove'
DEMO=Path.home()/'Libero/demo/giove-v1'
SR=48000
ROOTS=list(range(36,85,3))
VELOCITIES=[36,80,116]

SPECS=[
 {'slug':'theremin-vetro','title':'Theremin · Vetro','sub':'Theremin synth · clear sine body with a bright upper edge','accent':'#80aeb7','kind':'theremin-vetro','rootmax':84,'vibrato':28.0,'rate':5.1,'glide':95,'master':-10,'output_scale':.32},
 {'slug':'theremin-ambra','title':'Theremin · Ambra','sub':'Theremin synth · warm body with a richer color','accent':'#c88450','kind':'theremin-ambra','rootmax':84,'vibrato':34.0,'rate':5.25,'glide':105,'master':-6,'output_scale':.32},
 {'slug':'trautonium-due-formanti','title':'Trautonium · Two Formants','sub':'Saw synthesis · two parallel fixed-Hz resonances inspired by the Trautonium','accent':'#aa765c','kind':'trautonium','rootmax':72,'vibrato':26.0,'rate':5.2,'glide':85,'master':-5,'output_scale':.30},
 {'slug':'volkstrautonium-manuale','title':'Volkstrautonium · Manual','sub':'Saw synthesis · prefilters and a focused manual register','accent':'#936c50','kind':'volkstrautonium','rootmax':72,'vibrato':24.0,'rate':5.0,'glide':90,'master':-12,'output_scale':.30},
 {'slug':'mixturtrautonium-quarta-aperta','title':'Mixturtrautonium · Open Fourth','sub':'Four dividers 1:2:3:4 · open register, not a minor triad','accent':'#a078aa','kind':'mixtur-quarta','rootmax':84,'vibrato':22.0,'rate':5.15,'glide':95,'master':-7,'output_scale':.58},
 {'slug':'mixturtrautonium-frange','title':'Mixturtrautonium · Fringes','sub':'Four dividers 1:2:4:7 · dark color with a subharmonic seventh','accent':'#647c94','kind':'mixtur-frange','rootmax':84,'vibrato':26.0,'rate':5.35,'glide':105,'master':-8,'output_scale':.58},
]

RECIPE='''from pathlib import Path
import json, math
import numpy as np
from libero import Sound, synth
from libero.audio import Audio
from libero.forge.filters import apply_filter

SPEC=__SPEC__
SR=48000
sound=Sound(title=SPEC['title'], subtitle=SPEC['sub'], tags=['giove','synth','analog-inspired','legato',SPEC['kind']], roots=__ROOTS__, velocities=[36,80,116], sample_rate=SR, seed=76031, accent=SPEC['accent'])

def _tone(f, dur, amp, phase=0.0):
    return synth.saw(f, dur, SR, amp=amp, method='additive', phase=phase).data.astype(np.float64)

def body(ctx):
    sr=ctx.sr; f=float(ctx.freq); kind=SPEC['kind']; vel=ctx.velocity/127.0
    # Use an integer number of master cycles; for divided voices choose a
    # multiple of every divisor, then sample-round the period. It remains in
    # tune (<0.1 cent) and every branch closes on the same buffer boundary.
    divs=SPEC.get('divisors',[1]); lcm=math.lcm(*divs)
    cycles=max(lcm,round(f*3.15/lcm)*lcm); n=max(4096,round(cycles*sr/f)); actual=cycles*sr/n; dur=n/sr
    bright=0.82+0.25*vel
    if kind=='theremin-vetro':
        y=(synth.sine(actual,dur,sr,amp=.62).data + synth.tri(actual,dur,sr,amp=.10+.10*vel).data +
           synth.sine(actual*2,dur,sr,amp=.10+.12*vel).data + synth.sine(actual*3,dur,sr,amp=.02+.045*vel).data)
    elif kind=='theremin-ambra':
        y=(synth.sine(actual,dur,sr,amp=.35).data + synth.tri(actual,dur,sr,amp=.18+.09*vel).data +
           _tone(actual,dur,.10+.11*vel) + synth.sine(actual*2,dur,sr,amp=.08+.12*vel).data)
        y=.70*y+.30*apply_filter('bp12',y,650+680*vel,.15,0,0,sr)
    elif kind=='trautonium':
        raw=_tone(actual,dur,.46)
        f1=apply_filter('bp12',raw,430+360*vel,.19,0,0,sr)
        f2=apply_filter('bp12',raw,1450+920*vel,.24,0,0,sr)
        y=(.52-.13*vel)*raw+(.34+.07*vel)*f1+(.25+.09*vel)*f2
    elif kind=='volkstrautonium':
        raw=_tone(actual,dur,.50)
        pre=apply_filter('lp12',raw,3000-450*vel,.05,0,0,sr)
        f1=apply_filter('bp12',pre,310+250*vel,.20,0,0,sr)
        f2=apply_filter('bp12',pre,920+710*vel,.18,0,0,sr)
        y=(.57-.14*vel)*pre+(.27+.07*vel)*f1+(.23+.10*vel)*f2
    elif kind.startswith('mixtur-'):
        ratios=SPEC['divisors']; weights=SPEC['weights']; centres=SPEC['formants']
        y=np.zeros(n,dtype=np.float64)
        for i,(d,w,fc) in enumerate(zip(ratios,weights,centres)):
            branch=_tone(actual/d,dur,.48*w,phase=(i*.137)%1)
            band=apply_filter('bp12',branch,fc*(.78+.48*vel),.10+.07*(i%2),0,0,sr)
            y+=.68*branch+.32*band
        # A very quiet detuned second master adds a slow harmonic edge without
        # becoming a second fixed chord or defeating one-note pitch identity.
        if SPEC.get('second_vco_cents',0):
            y+=_tone(actual*2**(SPEC['second_vco_cents']/1200),dur,.035)
    else: raise ValueError(kind)
    y=np.asarray(y,dtype=np.float64)
    if y.ndim>1:y=y.mean(axis=1)
    # Preserve note/register and velocity differences; only true overshoots
    # receive a final safety correction. No distortion, chorus or baked vibrato.
    y *= SPEC['output_scale']*(.76+.24*vel)
    peak=float(np.max(np.abs(y))) or 1.0
    if peak>.78:y *= .78/peak
    return Audio(y.astype(np.float32),sr)

sound.body(body)
sound.loop(body=True,min_seconds=.55,region=(.35,2.8))
sound.performance(dynamics_source='velocity',velocity_curve=.8,dyn_crossfade=0,humanize={'cents':0,'ms':0,'db':0},rr_reset_ms=1500)
sound.defaults(mode='Legato',glide=SPEC['glide'],voices=1,
    amp_attack=12,amp_decay=10000,amp_sustain=1,amp_release=260,vel_sens=.28,
    master=SPEC['master'],lvl_body=0,lvl_attack=-60,lvl_tail=-60,lvl_air=-60,
    osc1_level=-60,osc2_level=-60,sub_level=-60,flt_cutoff=18000,flt_reso=0,flt_env=0,
    lfo_rate=SPEC['rate'],lfo_pitch=SPEC['vibrato'],lfo_delay=350,lfo_amp=0,
    drive=0,tape_wow=0,tape_flutter=0,tape_sat=0,tape_mix=0,echo_mix=0,
    rev_mode='Cappella',rev_mix=.025,rev_size=.22,rev_decay=.72,caldi_mode='Spento')
'''

# A Theremin is a continuously generated tone source: keep these two as live
# oscillators rather than forcing the distinctive tone through sampled loops.
LIVE_RECIPE='''from libero import Sound
SPEC=__SPEC__
sound=Sound(title=SPEC['title'],subtitle=SPEC['sub'],tags=['giove','theremin','live-synthesis','legato',SPEC['kind']],roots=__ROOTS__,seed=76031,accent=SPEC['accent'])
sound.performance(dynamics_source='velocity',velocity_curve=.45,dyn_crossfade=0,humanize={'cents':0,'ms':0,'db':0},rr_reset_ms=1500)
sound.defaults(mode='Legato',glide=SPEC['glide'],voices=1,master=SPEC['master'],vel_sens=1,vel_amp_curve=1,
 amp_attack=18,amp_decay=10000,amp_sustain=1,amp_release=340,
 osc1_wave=SPEC['osc1_wave'],osc1_level=SPEC['osc1_level'],osc1_oct=0,osc1_fine=0,osc1_voices=1,osc1_detune=0,osc1_spread=0,osc1_phase=0,
 osc2_wave=SPEC['osc2_wave'],osc2_level=SPEC['osc2_level'],osc2_oct=SPEC['osc2_oct'],osc2_semi=0,osc2_fine=0,osc2_voices=1,osc2_detune=0,osc2_spread=0,osc2_phase=0,
 osc_drift=0,osc_retrig='Libera',sub_level=-60,
 flt_mode='Basso',flt_cutoff=SPEC['cutoff'],flt_reso=SPEC['reso'],flt_key=.32,flt_vel=.12,flt_env=0,
 lfo_shape='Seno',lfo_rate=SPEC['rate'],lfo_pitch=0,lfo_pitch_cc1=SPEC['vibrato'],lfo_delay=350,lfo_amp=0,lfo_cutoff=0,
 drive=0,width=1,rev_mode='Cappella',rev_mix=.025,rev_size=.2,rev_decay=.7,
 tape_wow=0,tape_flutter=0,tape_sat=0,tape_mix=0,echo_mix=0,
 lvl_body=-60,lvl_attack=-60,lvl_tail=-60,lvl_air=-60,caldi_mode='Spento')
'''

LIVE_INSTRUMENT_RECIPE='''from libero import Sound
SPEC=__SPEC__
sound=Sound(title=SPEC['title'],subtitle=SPEC['sub'],tags=['giove','synth','live-circuit','legato',SPEC['kind']],roots=__ROOTS__,seed=76031,accent=SPEC['accent'])
sound.articulations(SPEC['articulations'])
sound.performance(dynamics_source='cc1',velocity_curve=.8,dyn_crossfade=0,humanize={'cents':0,'ms':0,'db':0},rr_reset_ms=1500)
defaults=dict(mode='Legato',glide=SPEC['glide'],voices=1,master=SPEC['master'],vel_sens=1,vel_amp_curve=1,
 amp_attack=SPEC['attack_ms'],amp_decay=10000,amp_sustain=1,amp_release=SPEC['release_ms'],
 osc1_wave=SPEC['osc1_wave'],osc1_level=SPEC['osc1_level'],osc1_oct=0,osc1_semi=0,osc1_fine=0,osc1_voices=1,osc1_detune=0,osc1_spread=0,osc1_phase=0,
 osc2_wave=SPEC['osc2_wave'],osc2_level=SPEC['osc2_level'],osc2_oct=SPEC['osc2_oct'],osc2_semi=0,osc2_fine=0,osc2_voices=1,osc2_detune=0,osc2_spread=0,osc2_phase=0,
 sub_wave=SPEC['sub_wave'],sub_level=SPEC['sub_level'],sub_divisor=SPEC['sub_divisor'],sub2_level=SPEC['sub2_level'],sub2_divisor=SPEC['sub2_divisor'],sub3_level=SPEC['sub3_level'],sub3_divisor=SPEC['sub3_divisor'],
 osc_drift=0,osc_retrig='Libera',flt_mode=SPEC['flt_mode'],flt_cutoff=SPEC['flt_cutoff'],flt_reso=SPEC['flt_reso'],flt_key=0,flt_vel=0,flt_env=0,flt_dyn=SPEC['flt_dyn'],amp_dyn=SPEC['amp_dyn'],
 lfo_shape='Seno',lfo_rate=SPEC['rate'],lfo_pitch=0,lfo_pitch_cc1=SPEC['vibrato'],lfo_delay=350,lfo_amp=0,lfo_cutoff=0,
 drive=SPEC['drive'],width=1,rev_mode='Cappella',rev_mix=.025,rev_size=.2,rev_decay=.7,
 tape_wow=0,tape_flutter=0,tape_sat=0,tape_mix=0,echo_mix=0,
 lvl_body=-60,lvl_attack=-60,lvl_tail=-60,lvl_air=-60,caldi_mode='Spento',dyn_mode='Modulazione',dynamics=0)
sound.defaults(**defaults)
'''

def write_preset(spec):
    dest=BANK/spec['slug']; dest.mkdir(parents=True,exist_ok=True); (dest/'samples').mkdir(exist_ok=True)
    if (dest/'sound.py').exists():
        proof_path=dest/'samples'/'source-proof.json'
        prior=json.loads(proof_path.read_text()) if proof_path.exists() else {}
        if prior.get('preset')!=spec['slug'] or prior.get('route') not in ('SYN, first-party Libero band-limited digital synthesis; not samples of a commercial instrument','SYN, first-party live Libero oscillators; not samples of a commercial instrument','SYN, original first-party live oscillator/filter/divider engine; no sampled hardware or commercial ROM'):
            raise RuntimeError(f"refusing to replace non-owned preset folder {dest}")
    roots=[r for r in ROOTS if r<=spec['rootmax']]
    cfg=dict(spec)
    cfg.update(osc1_wave='Sega',osc1_level=-9,osc2_wave='Triangolo',osc2_level=-60,osc2_oct=0,
               sub_wave='Sega',sub_level=-60,sub_divisor=2,sub2_level=-60,sub2_divisor=3,sub3_level=-60,sub3_divisor=4,
               flt_mode='Basso',flt_cutoff=6500,flt_reso=.12,flt_dyn=.12,amp_dyn=.10,drive=.015,attack_ms=14,release_ms=280)
    if spec['kind']=='theremin-vetro':
        cfg.update(osc1_wave='Seno',osc1_level=-11,osc2_wave='Triangolo',osc2_level=-23,osc2_oct=1,
                   flt_cutoff=9000,flt_reso=0,flt_dyn=.12,vibrato=28.0,glide=110,attack_ms=26,release_ms=320)
        arts=[
            {'id':'vibrato','name':'Continuous Vibrato','key':12,'params':{'lfo_pitch':0.0,'lfo_pitch_cc1':cfg['vibrato'],'glide':110}},
            {'id':'dritto','name':'Straight Tone','key':13,'params':{'lfo_pitch':0.0,'lfo_pitch_cc1':0.0,'glide':90}},
        ]
    elif spec['kind']=='theremin-ambra':
        cfg.update(osc1_wave='Triangolo',osc1_level=-10,osc2_wave='Sega',osc2_level=-18,osc2_oct=0,
                   flt_mode='Vocale',flt_cutoff=1450,flt_reso=.12,flt_dyn=.12,vibrato=34.0,glide=120,attack_ms=24,release_ms=340)
        arts=[
            {'id':'vibrato','name':'Continuous Vibrato','key':12,'params':{'lfo_pitch':0.0,'lfo_pitch_cc1':cfg['vibrato'],'glide':120}},
            {'id':'dritto','name':'Straight Tone','key':13,'params':{'lfo_pitch':0.0,'lfo_pitch_cc1':0.0,'glide':95}},
        ]
    elif spec['kind']=='trautonium':
        cfg.update(osc1_level=-9,flt_mode='Vocale',flt_cutoff=1050,flt_reso=.32,flt_dyn=.12,amp_dyn=.10,drive=.025)
        arts=[
            {'id':'formanti','name':'VT Formants','key':12,'params':{'flt_mode':'Vocale','flt_cutoff':1050,'flt_reso':.32,'osc1_level':-9,'lfo_pitch':0}},
            {'id':'nasale','name':'Nasal / Narrow','key':13,'params':{'flt_mode':'Vocale','flt_cutoff':420,'flt_reso':.58,'osc1_level':0,'lfo_pitch':0}},
            {'id':'aperto','name':'Open / Direct Saw','key':14,'params':{'flt_mode':'Basso','flt_cutoff':14500,'flt_reso':.08,'osc1_level':-11,'lfo_pitch':0}},
        ]
    elif spec['kind']=='volkstrautonium':
        cfg.update(osc1_level=-8,flt_mode='Basso',flt_cutoff=3100,flt_reso=.18,flt_dyn=.12,amp_dyn=.10,drive=.02)
        arts=[
            {'id':'registro','name':'Manual Register','key':12,'params':{'flt_mode':'Basso','flt_cutoff':3100,'flt_reso':.18,'osc1_wave':'Sega','lfo_pitch':0}},
            {'id':'morbido','name':'Soft Register','key':13,'params':{'flt_mode':'Vocale','flt_cutoff':690,'flt_reso':.2,'osc1_wave':'Triangolo','lfo_pitch':0}},
            {'id':'aperto','name':'Open Register','key':14,'params':{'flt_mode':'Basso','flt_cutoff':9000,'flt_reso':.05,'osc1_wave':'Sega','lfo_pitch':0}},
        ]
    elif spec['kind']=='mixtur-quarta':
        weights=[.42,.25,.20,.13]; ratios=[1,2,3,4]
        cfg.update(osc1_level=-8,sub_level=-12.5,sub_divisor=ratios[1],sub2_level=-14.4,sub2_divisor=ratios[2],
                   sub3_level=-18.2,sub3_divisor=ratios[3],flt_mode='Vocale',flt_cutoff=1350,flt_reso=.24,flt_dyn=.12,amp_dyn=.10)
        arts=[
            {'id':'miscela','name':'Mixture I · 1:2:3:4','key':12,'params':{'sub_level':-12.5,'sub2_level':-14.4,'sub3_level':-18.2,'lfo_pitch':0}},
            {'id':'fondamentale','name':'Fundamental Only','key':13,'params':{'sub_level':-60,'sub2_level':-60,'sub3_level':-60,'lfo_pitch':0}},
            {'id':'ottave','name':'Fundamental + Octaves','key':14,'params':{'sub_level':-12,'sub2_level':-60,'sub3_level':-18,'lfo_pitch':0}},
        ]
        cfg['divisors']=ratios; cfg['weights']=weights
    elif spec['kind']=='mixtur-frange':
        weights=[.43,.25,.19,.13]; ratios=[1,2,4,7]
        cfg.update(osc1_level=-8,sub_level=-12.7,sub_divisor=ratios[1],sub2_level=-15.1,sub2_divisor=ratios[2],
                   sub3_level=-18.4,sub3_divisor=ratios[3],flt_mode='Vocale',flt_cutoff=820,flt_reso=.32,flt_dyn=.12,amp_dyn=.10)
        arts=[
            {'id':'miscela','name':'Mixture II · 1:2:4:7','key':12,'params':{'sub_level':-12.7,'sub2_level':-15.1,'sub3_level':-18.4,'lfo_pitch':0}},
            {'id':'fondamentale','name':'Fundamental Only','key':13,'params':{'sub_level':-60,'sub2_level':-60,'sub3_level':-60,'lfo_pitch':0}},
            {'id':'senza_settimo','name':'Without Divider 7','key':14,'params':{'sub_level':-12.7,'sub2_level':-15.1,'sub3_level':-60,'lfo_pitch':0}},
        ]
        cfg['divisors']=ratios; cfg['weights']=weights
    cfg['articulations']=arts
    recipe=LIVE_INSTRUMENT_RECIPE.replace('__SPEC__',repr(cfg)).replace('__ROOTS__',repr(roots))
    route='SYN, original first-party live oscillator/filter/divider engine; no sampled hardware or commercial ROM'
    (dest/'sound.py').write_text(recipe)
    (dest/'figure.svg').write_text(figure_svg(spec))
    references=(['https://api.moogmusic.com/sites/default/files/2022-04/Etherwave-Theremin_Manual_2022.pdf'] if spec['kind'].startswith('theremin-') else
                ['https://www.trautoniks.de/downloads/VT2012/vt2012_manual_en.pdf','https://www.trautoniks.de/com/product.html'] if spec['kind'] in ('trautonium','volkstrautonium') else
                ['https://www.trautoniks.de/modules.html','https://www.trautoniks.de/com/order.html'])
    proof={'route':route,'source':'Original live oscillators, fixed-Hz filter profiles and subharmonic divider code in this repository, inspired by primary circuit documentation. No external audio used.','proposed_audio_license':'CC0 1.0 (proposal for generated audio; project owner to confirm distribution terms)','preset':spec['slug'],'roots':roots,'zones':'none; fully live oscillator synthesis','algorithm':cfg,'primary_design_references':references,'formants':'filter frequency centres remain in absolute Hz while note, legato glide and pitch wheel change oscillator frequency; CC1 only makes the preset-approved mild filter move and its primary purpose is vibrato depth','live_controls':{'mode':'Legato','glide_ms':cfg['glide'],'lfo_rate_hz':cfg['rate'],'base_vibrato_cents':0,'cc1_vibrato_depth_cents':cfg['vibrato'],'lfo_delay_ms':350,'pitch_bend':'host MIDI wheel/RPN 0; default ±2 semitones per plugin README','expression':'velocity is the primary volume control (concave optional curve); CC1 controls vibrato depth and only a small secondary level/tone change','articulations':arts}}
    (dest/'samples'/'source-proof.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
    (dest/'samples'/'credits.json').write_text(json.dumps([{'source':'Original digital oscillator/filter synthesis rendered by Libero','author':'Mario / Libero authoring session','license':'CC0 1.0 (proposed)','license_class':'cc0','url':'https://creativecommons.org/publicdomain/zero/1.0/','notes':'No commercial hardware ROM, demo audio or third-party sample is included; hardware documentation informed only the disclosed design.'}],indent=2,ensure_ascii=False)+'\n')
    notes=f"""# {spec['title']}\n\nOriginal SYN patch built with Libero live oscillators, fixed-Hz filter profiles and (for Mixtur) live subharmonic dividers. No hardware samples, commercial ROM or reference audio are included. The primary design references describe Theremin tone color, Trautonium sawtooth excitation and fixed resonances, and configurable Mixtur subharmonics. Keyboard notes, legato and pitch wheel move oscillator pitch while filter/formant centres stay fixed in absolute Hz. Full construction and references: `samples/source-proof.json`.\n\nDefault performance is Legato with {cfg['glide']} ms glide. MIDI velocity is the main loudness control: the optional concave `vel_amp_curve` keeps the upper velocity range gentle and lets quiet strikes fall away more quickly. CC1 is primarily vibrato depth, from straight at zero to ±{cfg['vibrato']} cents at full wheel; a 350 ms onset fade shapes vibrato on a fresh note. CC1 also has only a small level and filter-profile contribution. Overlapping notes preserve the envelope and global LFO phase; note velocity changes glide over 25 ms without retriggering the note. MIDI pitch wheel is global/RPN 0 (default ±2 semitones) and never transposes the fixed-Hz filter centres.\n\nArticulation profiles are selectable in the UI or via MIDI keyswitches 12–14. Their labels identify designed circuit registers, not recordings or hardware replicas. The Instagram reel was not used as audio material.\n"""
    (dest/'notes.md').write_text(notes)
    return dest,roots,cfg

def figure_svg(spec):
    slug=spec['slug']; title=spec['title']; accent=spec['accent']
    header=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="currentColor" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>Diagramma originale del percorso sonoro: {spec["sub"]}.</desc>'
    if slug=='theremin-vetro':
        art='<path d="M105 332Q256 226 407 332M139 343Q256 268 373 343" stroke-width="1.2"/><path d="M256 180V325M184 248H328" stroke-width="1.1"/><circle cx="256" cy="177" r="8" fill="#f3eee6" stroke-width="1.2"/><path d="M102 118H410M102 126H410" stroke-width=".7"/><path d="M119 102V142M393 102V142" stroke-width="1"/><path d="M215 384H297L284 403H228Z" stroke-width="1"/>'
    elif slug=='theremin-ambra':
        art='<path d="M128 206Q256 72 384 206Q256 340 128 206Z" stroke-width="1.2"/><path d="M151 206Q256 112 361 206Q256 300 151 206Z" stroke-width=".8"/><circle cx="256" cy="206" r="8" fill="#f3eee6" stroke-width="1.2"/><path d="M256 214V346M207 346H305" stroke-width="1"/><path d="M150 382Q256 360 362 382M150 389Q256 367 362 389" stroke="#b8924f" stroke-width="1.1"/>'
    elif slug=='trautonium-due-formanti':
        art='<path d="M115 197H397V324H115Z" stroke-width="1.2"/><path d="M133 218H379M133 239H379M133 260H379M133 281H379M133 302H379" stroke-width=".45"/><path d="M165 324V374M347 324V374M147 374H365" stroke-width="1"/><path d="M126 174H386" stroke-width=".7"/><path d="M189 167L223 129H292L326 167Z" stroke="#b8924f" stroke-width="1.1"/><circle cx="225" cy="148" r="7"/><circle cx="290" cy="148" r="7"/>'
    elif slug=='volkstrautonium-manuale':
        art='<path d="M100 225H412V340H100Z" stroke-width="1.2"/><path d="M121 242H391M121 264H391M121 286H391M121 308H391" stroke-width=".5"/><path d="M136 340V378M376 340V378M118 378H394" stroke-width="1"/><path d="M157 178H355L384 211H128Z" stroke="#b8924f" stroke-width="1.1"/><path d="M180 190V211M222 190V211M264 190V211M306 190V211" stroke-width=".7"/><path d="M210 150H302V177H210Z" stroke-width="1"/>'
    elif slug=='mixturtrautonium-quarta-aperta':
        art='<circle cx="256" cy="256" r="115" stroke-width="1.1"/><circle cx="256" cy="256" r="84" stroke-width=".8"/><circle cx="256" cy="256" r="52" stroke="#b8924f" stroke-width="1.2"/><path d="M256 141V371M141 256H371M175 175L337 337M337 175L175 337" stroke-width=".65"/><path d="M256 141V204M371 256H308M256 371V308M141 256H204" stroke-width="2"/>'
    else:
        art='<circle cx="256" cy="256" r="119" stroke-width="1.1"/><circle cx="256" cy="256" r="84" stroke-width=".8"/><circle cx="256" cy="256" r="50" stroke="#b8924f" stroke-width="1.2"/><path d="M256 137V206M375 256H306M256 375V306M137 256H206M172 172L221 221M340 172L291 221M340 340L291 291M172 340L221 291" stroke-width=".8"/><path d="M256 137V184M375 256H328M256 375V328M137 256H184" stroke-width="1.8"/>'
    return header+f'<g stroke-width="1.1">{art}</g><path d="M96 420H416" stroke="{accent}" stroke-width="1.2"/><path d="M122 430H390" stroke-width=".55"/></svg>'

def main():
    DEMO.mkdir(parents=True,exist_ok=True); results=[]
    for spec in SPECS:
        dest,roots,cfg=write_preset(spec)
        comp=compile_sound(dest,jobs=2)
        if not comp.ok:raise RuntimeError(f"{spec['slug']} compile failed: {comp.text()}")
        findings=lint_bundle(dest/'build');counts=collections.Counter(x.level for x in findings)
        errors=[x.line() for x in findings if x.level=='FAIL']
        if errors:raise RuntimeError(f"{spec['slug']} lint FAIL: {errors}")
        results.append({'slug':spec['slug'],'title':spec['title'],'roots':roots,'compile':comp.summary,'manifest_source_hash':comp.manifest.get('source_hash'),'lint':dict(counts),'warnings':[x.line() for x in findings if x.level=='WARN'],'errors':errors,'proof':str(dest/'samples/source-proof.json')})
        print(spec['slug'],len(roots),'roots',dict(counts),'FAIL',len(errors),flush=True)
    (DEMO/'build-report.json').write_text(json.dumps({'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'presets':results},indent=2,ensure_ascii=False)+'\n')
    print('Built six Giove synthesis presets; native QA remains to run.')

if __name__=='__main__':main()
