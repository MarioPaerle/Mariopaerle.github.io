"""Append true VSCO 2 CE solo-violin arts to the approved TinySOL violin and
prepare source-loop audits for the existing cello programmes.

Requires the VSCO source files cached at ~/Libero/cache/libraries/vsco2-ce/Strings/Solo Violin.
The source fetch helper is included for reproducibility (`--fetch`); it downloads only that
solo-violin directory from the public SFZ branch. Existing source bodies/releases remain intact.
"""
from __future__ import annotations
import argparse, hashlib, json, re, shutil, urllib.request
from pathlib import Path
from collections import Counter
import numpy as np, soundfile as sf
from libero import load, Audio
from libero.compiler import compile_sound
from libero.lint import lint_text

HOME=Path.home(); REPO=Path(__file__).resolve().parents[2]
BANK=HOME/'Libero/banks/archi'; SOURCE=HOME/'Libero/cache/libraries/vsco2-ce/Strings/Solo Violin'
GITHUB_API='https://api.github.com/repos/sgossner/VSCO-2-CE/git/trees/SFZ?recursive=1'
RAW='https://raw.githubusercontent.com/sgossner/VSCO-2-CE/SFZ/'


def fetch():
    tree=json.load(urllib.request.urlopen(GITHUB_API,timeout=30))
    files=[x for x in tree['tree'] if x.get('size') and x['path'].lower().startswith('strings/solo violin/')]
    if not files: raise RuntimeError('No VSCO 2 CE Solo Violin sources found')
    for row in files:
        rel=Path(row['path'].split('/',2)[2]); dst=SOURCE/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists() and dst.stat().st_size==row['size']: continue
        url=RAW+urllib.parse.quote(row['path'])
        data=urllib.request.urlopen(url,timeout=60).read()
        if len(data)!=row['size']: raise ValueError(f'Bad source size: {rel}')
        dst.write_bytes(data)
    print(f'Cached {len(files)} files ({sum(x["size"] for x in files)/2**20:.1f} MiB) at {SOURCE}')


def parse_note(s):
    names={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
    m=re.fullmatch(r'([A-G])([#b]?)(\d+)',s)
    if not m: raise ValueError(s)
    pc=names[m[1]]+(1 if m[2]=='#' else -1 if m[2]=='b' else 0)
    return 12*(int(m[3])+1)+pc


def _root_from_file(p):
    m=re.search(r'_([A-G][#b]?\d)_',p.name)
    if not m: raise ValueError(f'Unparsed root: {p}')
    return parse_note(m[1])


def build_violin():
    folder=BANK/'violino-solo'; src=SOURCE
    arts=[('Arco Vib','vib','Arco vibrato',13),('Pizz','pizz','Pizzicato',14),('spic','spic','Spiccato',15),('Trem','trem','Tremolo',16)]
    if not src.exists() or not any(src.rglob('*.wav')): raise RuntimeError('Missing cached VSCO solo violin sources; run --fetch')
    samples=folder/'samples'; raw=samples/'vsco-solo'
    old=json.loads((samples/'map.json').read_text())
    new_body=[]
    for r in old['body']:
        q=dict(r); q['articulation']='ord'; new_body.append(q)
    new_tail=[]
    for r in old['tail']:
        q=dict(r); q['articulation']='ord'; new_tail.append(q)
    added=[]; provenance=[]
    for dirname,aid,_label,_key in arts:
        paths=sorted((src/dirname).glob('*.wav'))
        if not paths: raise RuntimeError(f'Missing source art {dirname}')
        parsed=[]
        for p in paths:
            n=_root_from_file(p) + (12 if dirname in ('spic','Trem') else 0)
            if dirname=='Arco Vib':
                suffix=p.stem.rsplit('_',1)[-1]
                dyn=0 if suffix=='p' else 1
                take=0
            elif dirname=='Pizz':
                m=re.search(r'_([pf])_RR(\d+)$',p.stem)
                if m: dyn=0 if m[1]=='p' else 1; take=int(m[2])-1
                else: dyn=1; take=0
            elif dirname=='spic':
                m=re.search(r'_v(\d+)_rr(\d+)$',p.stem,re.I)
                if not m: raise ValueError(p.name)
                dyn=int(m[1])-1; take=int(m[2])-1
            else:
                m=re.search(r'_v(\d+)_rr(\d+)$',p.stem,re.I)
                if not m: raise ValueError(p.name)
                dyn=int(m[1])-1; take=int(m[2])-1
            parsed.append((p,n,dyn,take))
        roots=sorted({n for _,n,_,_ in parsed})
        dyns=sorted({d for _,_,d,_ in parsed})
        for p,n,dyn,take in parsed:
            rel=Path('vsco-solo')/dirname/p.name; out=samples/rel
            out.parent.mkdir(parents=True,exist_ok=True)
            if not out.exists() or hashlib.sha256(out.read_bytes()).digest()!=hashlib.sha256(p.read_bytes()).digest(): shutil.copy2(p,out)
            # preserve each source dynamic as a hard velocity region; do not blend phases
            if dirname=='Arco Vib': vlo,vhi=(1,63) if dyn==0 else (64,127)
            elif dirname=='Pizz': vlo,vhi=(1,63) if dyn==0 else (64,127)
            else: vlo,vhi=(1,63) if dyn==0 else (64,127)
            zone={'file':str(rel),'root':n,'vel':[vlo,vhi],'take':take,'articulation':aid,'gain_db':-9.18}
            if aid in ('pizz','spic'): zone['one_shot']=True
            added.append(zone)
            provenance.append({'file':str(rel),'source_path':str(p.relative_to(src)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'root_midi':n,'dynamic_index':dyn,'take':take})
    mapfile=samples/'map-expanded.json'
    mp={'body':new_body+added,'tail':new_tail}
    mapfile.write_text(json.dumps(mp,indent=2)+'\n')
    (samples/'vsco-solo-provenance.json').write_text(json.dumps({'repo':'https://github.com/sgossner/VSCO-2-CE/tree/SFZ/Strings/Solo%20Violin','revision':'6dd651d55dde97fd4028699be9d4481f26917891','license':'CC0-1.0','files':provenance},indent=2)+'\n')
    # Edit only the map read, key-switch table, and attribution. All existing TinySOL process settings remain unchanged.
    p=folder/'sound.py'; recipe=p.read_text().replace('"/ "samples" / "map.json"','"/ "samples" / "map-expanded.json"')
    recipe=recipe.replace('"samples" / "map.json"','"samples" / "map-expanded.json"')
    oldarts='sound = Sound(title="Violino solo"'
    if 'sound.articulations(' not in recipe:
        i=recipe.find(oldarts)
        if i<0: raise RuntimeError('Unexpected TinySOL sound recipe')
        line_end=recipe.find('\n',i)
        recipe=recipe[:line_end+1]+'''sound.articulations([{"id":"ord","name":"Ordinario (TinySOL)","key":12}, {"id":"vib","name":"Arco vibrato (VSCO solo)","key":13}, {"id":"pizz","name":"Pizzicato (VSCO solo)","key":14}, {"id":"spic","name":"Spiccato (VSCO solo)","key":15}, {"id":"trem","name":"Tremolo (VSCO solo)","key":16}])\n'''+recipe[line_end+1:]
    p.write_text(recipe)
    credits=samples/'credits.json'; rows=json.loads(credits.read_text()) if credits.exists() else []
    if not any(x.get('source')=='VSCO 2 CE solo violin recordings' for x in rows):
        rows.append({'source':'VSCO 2 CE solo violin recordings','author':'Versilian Studios / sample performer credits in source records','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://github.com/sgossner/VSCO-2-CE/tree/SFZ/Strings/Solo%20Violin'})
    credits.write_text(json.dumps(rows,indent=2)+'\n')
    attr=samples/'ATTRIBUTION.md'; existing=attr.read_text() if attr.exists() else '# Recordings\n'
    if '## Added solo articulations' not in existing:
        existing += '\n## Added solo articulations\n\nVSCO 2 Community Edition Solo Violin recordings, CC0 1.0 Universal. Source repository and per-file hashes: `vsco-solo-provenance.json`. The original VSCO source includes actual arco-vibrato, pizzicato, spiccato and tremolo recordings; no section samples, synthesized transitions, or fake round robins are used.\n'
    attr.write_text(existing)
    print('Violin source zones',len(added),Counter(z['articulation'] for z in added))



def prepare_cello(slug):
    """Source-derived sustain loop in active performed material and align release starts.
    The existing body/tail recordings remain in place; loop bodies are explicit derived files.
    """
    folder=BANK/slug; samples=folder/'samples'; mp_path=samples/'map.json'
    # Keep a pristine recipe beside the derived loop map so rerunning this builder
    # never loops a loop or trims a release twice.
    source_map=samples/'map-source-v5.json'
    if not source_map.exists(): shutil.copy2(mp_path,source_map)
    mp=json.loads(source_map.read_text()); loop_arts={'violoncello-solo':{'sus','nonvib','molto','trillo_tono','trillo_semitono'},'violoncelli':{'sus','trem'}}[slug]
    audit=[]; new=[]
    for r0 in mp['body']:
        r=dict(r0); art=r.get('articulation','sus')
        if art not in loop_arts:
            new.append(r); continue
        src=samples/r['file']; audio=load(src)
        # Choose and bake loops at the bundle's native rate. Selecting at the
        # source rate and resampling afterwards can move endpoints by a fraction
        # of a sample, which is enough to spoil phase-sensitive loop joins.
        if audio.sr != 48000: audio=audio.resample(48000)
        dur=audio.duration; sr=audio.sr
        # Keep the loop between the bow attack and the beginning of the recorded lift.
        # Some solo phrases are <1 s, so the trailing file edge is not a safe loop end.
        min_loop=.25 if slug=='violoncello-solo' else 1.2
        start_region=max(.10,min(.35,dur*.10))
        mono=audio.data.mean(axis=1) if audio.data.ndim==2 else audio.data
        hop=max(1,int(.01*sr)); frame=max(64,int(.03*sr))
        env=np.array([np.sqrt(np.mean(mono[i:i+frame]**2)+1e-30) for i in range(0,len(mono)-frame,hop)])
        active_end=dur-.07
        if len(env):
            threshold=float(env.max())*10**(-8/20); hold=max(1,int(.10*sr/hop))
            peak_i=int(np.argmax(env)); search_i=max(int(start_region*sr/hop),peak_i+int(.05*sr/hop))
            for j in range(search_i,max(search_i,len(env)-hold)):
                if np.all(env[j:j+hold]<threshold):
                    active_end=max(start_region+.14,j*hop/sr); break
        end_region=min(dur-.005,active_end)
        if end_region < start_region + min_loop + .02:
            end_region=dur-.07
        # Explore several same-performance windows. Require local level agreement at
        # both 20 and 50 ms and prefer a correlated, longer candidate within that bound.
        candidates=[]; fallback=[]
        windows=(.01,.02,.03,.05,.07) if slug=='violoncello-solo' else (.02,.03,.05,.07)
        mins=(.25,.14,.08,.06) if slug=='violoncello-solo' and dur<.8 else ((.25,.14,.08) if slug=='violoncello-solo' else (1.2,))
        for win in windows:
            for lo in (start_region,min(start_region+.04,max(start_region,end_region-.30))):
                for hi in (end_region,min(end_region,max(lo+.15,end_region-.025))):
                    if hi<=lo+min(mins)+win: continue
                    lp0=None
                    for min_len in mins:
                        lp0=audio.loop_points(min_seconds=min_len,region=(lo,hi),window=win,max_crossfade=.18)
                        if lp0 is not None: break
                    if lp0 is None: continue
                    measures=[]
                    for ms in (20,50):
                        n=max(64,int(ms*.001*sr)); s,e=lp0.start,lp0.end
                        a0=mono[s-n:s];a1=mono[e-n:e]
                        measures.append(float(20*np.log10((np.sqrt(np.mean(a1*a1)+1e-30))/(np.sqrt(np.mean(a0*a0)+1e-30)))) if len(a0)==n and len(a1)==n else 99.)
                    item=(lp0,measures)
                    fallback.append(item)
                    if max(abs(measures[0]),abs(measures[1]))<=1.5:
                        candidates.append(item)
        if not candidates:
            # If the first stable region has no level-matched seam, search farther
            # into the same performed sustain rather than accepting a loudness jump.
            for win in (.02,.05):
                for lo in (start_region,min(start_region+.05,max(start_region,end_region-.35)),min(start_region+.10,max(start_region,end_region-.25))):
                    for back in (0,.05,.10,.15):
                        hi=max(lo+min(mins)+win,end_region-back)
                        if hi>end_region: continue
                        for min_len in mins:
                            lp0=audio.loop_points(min_seconds=min_len,region=(lo,hi),window=win,max_crossfade=.18)
                            if lp0 is None: continue
                            measures=[]
                            for ms in (20,50):
                                n=max(64,int(ms*.001*sr)); s,e=lp0.start,lp0.end
                                a0=mono[s-n:s];a1=mono[e-n:e]
                                measures.append(float(20*np.log10((np.sqrt(np.mean(a1*a1)+1e-30))/(np.sqrt(np.mean(a0*a0)+1e-30)))) if len(a0)==n and len(a1)==n else 99.)
                            item=(lp0,measures);fallback.append(item)
                            if max(abs(measures[0]),abs(measures[1]))<=1.5: candidates.append(item)
        def lint_loop_score(q):
            lp0=q[0]; x=mono; s,e=lp0.start,lp0.end; wlen=int(.02*sr)
            nxf=min(int(.18*sr),max(32,(e-s)//2),s)
            t=(np.arange(nxf)+.5)/nxf; fade=t*t*(3-2*t)
            end=x[e-nxf:e]*(1-fade)+x[s-nxf:s]*fade
            a=x[max(0,s-wlen):s+1]; b=np.r_[x[max(0,e-wlen):e-nxf],end[-min(wlen,nxf):]]
            n=min(len(a)-1,len(b)); aa=a[:n]; bb=b[:n]
            err=10*np.log10(np.sum((aa-bb)**2)/(np.sum(aa**2)+np.sum(bb**2))+1e-12)
            jump=abs(a[n]-b[-1])/(np.percentile(np.abs(np.diff(bb)),99)+1e-9)
            return err,jump
        if candidates:
            # Rank using the same 20 ms boundary metric used by `libero lint`
            # after the baked overlap, then prefer a longer same-performance loop.
            lp,level_deltas=min(candidates,key=lambda q:(max(0,lint_loop_score(q)[0]+20)*4+max(0,lint_loop_score(q)[1]-3)*2,
                                                          lint_loop_score(q)[0],- (q[0].end-q[0].start)))
        elif fallback:
            lp,level_deltas=min(fallback,key=lambda q:max(abs(q[1][0]),abs(q[1][1])))
        else:
            lp=None
            for min_len in mins:
                lp=audio.loop_points(min_seconds=min_len,region=(start_region,end_region),window=.01 if min_len<.14 else .02,max_crossfade=.18)
                if lp is not None: break
            level_deltas=[99.,99.] if lp is None else []
        if lp is None:
            raise RuntimeError(f'No performed loop can be fitted: {slug}/{r["file"]} ({dur:.2f}s)')
        x=audio.data.astype(np.float64).copy(); sr=audio.sr
        s0,e0=lp.start,lp.end; nxf=min(int(.18*sr),max(32,(e0-s0)//2),s0)
        t=(np.arange(nxf)+.5)/nxf; w=t*t*(3-2*t)  # raised-smoothstep overlap, one source performance
        if x.ndim==2: w=w[:,None]
        x[e0-nxf:e0]=x[e0-nxf:e0]*(1-w)+x[s0-nxf:s0]*w
        rel=Path('loops')/(src.stem+'_loop.flac'); out=samples/rel; out.parent.mkdir(parents=True,exist_ok=True)
        sf.write(out,x,sr,subtype='PCM_24',format='FLAC')
        r['file']=str(rel);r['loop']={'start':int(round(s0*48000/sr)),'end':int(round(e0*48000/sr))}
        new.append(r)
        # Actual window mismatch and level checks use the loop endpoint after the baked join.
        wcheck=min(int(.02*sr),(e0-s0)//8)
        err=float(np.sum((x[e0-wcheck:e0]-x[s0:s0+wcheck])**2)/(np.sum(x[e0-wcheck:e0]**2)+np.sum(x[s0:s0+wcheck]**2)+1e-30))
        if not level_deltas:
            level_deltas=[]
            for ms in (20,50):
                n=max(64,int(ms*.001*sr));a0=mono[s0-n:s0];a1=mono[e0-n:e0]
                level_deltas.append(float(20*np.log10((np.sqrt(np.mean(a1*a1)+1e-30))/(np.sqrt(np.mean(a0*a0)+1e-30)))) if len(a0)==n and len(a1)==n else 99.)
        audit.append({'articulation':art,'root':r['root'],'dyn':r.get('dyn',r.get('vel')),'take':r.get('take',0),'source_file':r0['file'],'derived_file':str(rel),'duration_s':round(dur,3),'loop_start_s':round(s0/sr,4),'loop_end_s':round(e0/sr,4),'period_s':round((e0-s0)/sr,3),'window_mismatch_db':round(10*np.log10(max(err,1e-30)),2),'source_level_delta_20ms_db':round(level_deltas[0],2),'source_level_delta_50ms_db':round(level_deltas[1],2),'candidate_error_db':lp.error_db,'crossfade_ms':round(1000*nxf/sr,2),'sample_rate':sr,'old_source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'derived_sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
    # Preserve the chosen same-performance loop point, but complete a short
    # overlap in the three compiled-seam outliers before compilation. This is
    # an edit to derived loop audio only; source recordings and every other
    # derived sample remain byte-identical.
    targeted={
        'violoncello-solo':{'loops/trillo_semitono_n44_me_loop.flac'},
        'violoncelli':{'loops/trem_n040_lo_t0_loop.flac','loops/trem_n057_lo_t0_loop.flac'},
    }[slug]
    for r in new:
        if r['file'] not in targeted: continue
        p=samples/r['file']; x,sr=sf.read(p,always_2d=True,dtype='float64'); s,e=r['loop']['start'],r['loop']['end']
        exact_n=int((.08 if slug=='violoncelli' else .02)*sr); fade_n=2*exact_n; soft_n=fade_n-exact_n
        if sr!=48000 or s<fade_n or e>len(x) or soft_n<1: raise RuntimeError(f'Bad targeted source join: {slug}/{r["file"]}')
        if not np.array_equal(x[e-exact_n:e],x[s-exact_n:s]):
            t=(np.arange(soft_n)+.5)/soft_n; w=(t*t*(3-2*t))[:,None]
            x[e-fade_n:e-exact_n]=x[e-fade_n:e-exact_n]*(1-w)+x[s-fade_n:s-exact_n]*w
            x[e-exact_n:e]=x[s-exact_n:s]
            sf.write(p,x,sr,subtype='PCM_24',format='FLAC')
        digest=hashlib.sha256(p.read_bytes()).hexdigest()
        for row in audit:
            if row['derived_file']==r['file']:
                row['derived_sha256']=digest;row['targeted_join_ms']=round(1000*fade_n/sr);row['exact_preloop_match_ms']=round(1000*exact_n/sr)
    mp['body']=new;mp_path.write_text(json.dumps(mp,indent=2)+'\n')
    tail_audit=[]
    # The existing split keeps 40 ms before the detected lift in both body and tail.
    # Drop that overlap from release playback so note-off begins exactly after the held-body end.
    tail_sources=samples/'tails-source-v5'
    for r in mp['tail']:
        tp=samples/r['file']
        if not tp.exists(): continue
        pristine=tail_sources/tp.name
        if pristine.exists(): shutil.copy2(pristine,tp)
        x,sr=sf.read(tp,always_2d=True,dtype='float64'); cut=int(round(.04*sr))
        if len(x)<=cut+int(.1*sr): continue
        before=hashlib.sha256(tp.read_bytes()).hexdigest()
        sf.write(tp,x[cut:],sr,subtype='PCM_24',format='FLAC')
        tail_audit.append({'file':r['file'],'removed_overlap_ms':round(1000*cut/sr,2),'before_sha256':before,'after_sha256':hashlib.sha256(tp.read_bytes()).hexdigest(),'duration_s':round((len(x)-cut)/sr,4)})
    (samples/'natural-loop-audit.json').write_text(json.dumps({'slug':slug,'loop_method':'same-performance source loop with up to 180ms smoothstep overlap; key/attack region untouched','loops':audit,'tail_alignment':tail_audit},indent=2)+'\n')
    # The source-layer maps now carry actual loop points; other recorded arts keep their original durations.
    sound=folder/'sound.py';txt=sound.read_text().replace('"loop": "none"','"loop": "source"',1)
    txt=txt.replace('long unlooped','source-looped').replace('long UNLOOPED','source-looped')
    sound.write_text(txt)
    print(slug,'loop zones',len(audit),'tail overlaps trimmed',len(tail_audit),'loop windows',Counter(x['articulation'] for x in audit),flush=True)
    print(slug,'loop score dB min/max',min((x['candidate_error_db'] for x in audit),default=None),max((x['candidate_error_db'] for x in audit),default=None),flush=True)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--fetch',action='store_true'); ap.add_argument('--violin',action='store_true'); ap.add_argument('--cellos',action='store_true'); args=ap.parse_args()
    if args.fetch: fetch()
    if args.violin: build_violin()
    if args.cellos:
        for slug in ('violoncello-solo','violoncelli'):
            prepare_cello(slug)
            r=compile_sound(BANK/slug)
            print(r.text())
            if not r.ok: raise SystemExit(1)
            (BANK/slug/'lint.txt').write_text(lint_text(BANK/slug/'build')+'\n')
    if args.violin:
        r=compile_sound(BANK/'violino-solo')
        print(r.text())
        if not r.ok: raise SystemExit(1)
        out=BANK/'violino-solo'/'lint.txt'; out.write_text(lint_text(BANK/'violino-solo'/'build')+'\n')

if __name__=='__main__': main()
