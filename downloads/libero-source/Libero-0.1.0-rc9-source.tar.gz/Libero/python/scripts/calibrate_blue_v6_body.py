"""Fine calibration from the actual performed/continued body, preserving source audio."""
from pathlib import Path
import argparse,hashlib,json,sys,numpy as np,soundfile as sf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero.compiler import compile_sound
from libero import library

def estimate(x,sr,expected):
 x=x.mean(1);x=x-x.mean();n=524288;sp=abs(np.fft.rfft(x*np.hanning(len(x)),n));hz=np.fft.rfftfreq(n,1/sr);found=[]
 for harmonic in [1,2,3,4]:
  centre=expected*harmonic;ix=np.flatnonzero((hz>centre*2**(-150/1200))&(hz<centre*2**(150/1200)));k=int(ix[np.argmax(sp[ix])]);q=np.log(np.maximum(sp[k-1:k+2],1e-30));d=float(np.clip(.5*(q[0]-q[2])/(q[0]-2*q[1]+q[2]+1e-30),-.5,.5));found.append(((k+d)*sr/n/harmonic,float(sp[k]),harmonic))
 # Some soft concertina notes lack their first harmonic entirely. Do not tune
 # to room noise in its place. Strong actual partials establish their note class.
 strongest=max(q[1]for q in found)
 chosen=found[0]if found[0][1]>strongest*.05 else max(found,key=lambda q:q[1])
 freq=chosen[0];return freq,float(1200*np.log2(freq/expected))

def calibrate(slug):
 p=Path.home()/f'Libero/banks/blue/{slug}';s=p/'samples';mp=s/'map.json';m=json.loads(mp.read_text());proof=[];seen={}
 resid=json.loads((s/'native-residual-tuning-v6.json').read_text()) if (s/'native-residual-tuning-v6.json').exists() else []
 original=s/'map-before-body-calibration-v6.json'
 if not original.exists():original.write_text(mp.read_text())
 for r in m['body']:
  lp=r.get('loop')
  if not lp:continue
  source=s/r['file'];x,sr=sf.read(source,always_2d=True);lo=round(1.0*sr);hi=round(1.5*sr);indices=np.arange(lo,hi);indices=np.where(indices>=lp['end'],lp['start']+(indices-lp['start'])%(lp['end']-lp['start']),indices);seg=x[indices];expected=440*2**((r['root']-69)/12);freq,cents=estimate(seg,sr,expected);tune=-cents
  for correction in resid:
   if correction['file']==r['file'] and hashlib.sha256(source.read_bytes()).hexdigest()==correction['derived_sha256']:tune+=correction['native_residual_compensation_cents']
  if abs(tune)>100:raise RuntimeError(f'{slug} {r["file"]} needs root correction: {tune:.2f}')
  proof.append({'file':r['file'],'root':r['root'],'velocity':r.get('vel'),'articulation':r.get('articulation'),'previous_tune_cents':r.get('tune_cents',0),'measured_stable_body_hz':freq,'measured_stable_body_offset_cents':cents,'tune_cents':tune,'measurement':'virtual same-take source loop at note clock 1.0–1.5s; no source audio edited'})
  r['tune_cents']=tune
 mp.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n');(s/'stable-body-tuning-v6.json').write_text(json.dumps(proof,indent=2)+'\n')
 recipe=p/'sound.py';recipe.write_text(recipe.read_text().replace("'tune':'smooth'","'tune':'source'"))
 result=compile_sound(p,jobs=2);print(result.text(),flush=True)
 if not result.ok:raise RuntimeError(result.text())
 assert library.source_hash(p)==json.loads((p/'build/manifest.json').read_text())['source_hash']
 with(p/'notes.md').open('a')as f:f.write('\n## Calibrazione della fondamentale sostenuta v6\n\nOffset per sorgente misurati dal corpo effettivamente riprodotto (1,0–1,5 s); `samples/stable-body-tuning-v6.json` conserva misure e valori precedenti. Nessun WAV originale o derivato è alterato. Ricetta: eseguire `calibrate_blue_v6_body.py` dopo il builder, poi il controllo nativo delle celle. La calibrazione centra la tastiera mantenendo il movimento relativo della performance.\n')
 print(slug,len(proof),'zones calibrated',flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--slugs',nargs='+',choices=['banjo-blue','chemnitzer-blue'],required=True);args=a.parse_args()
 for slug in args.slugs:calibrate(slug)
