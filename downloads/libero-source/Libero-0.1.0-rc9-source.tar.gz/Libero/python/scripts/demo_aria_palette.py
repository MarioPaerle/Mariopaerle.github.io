"""Native, isolated ten-voice audition. Level matching only; no extra effect or mastering."""
from pathlib import Path
import sys,json
import numpy as np
import soundfile as sf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import render
OUT=Path.home()/'Libero/demo/aria-palette';OUT.mkdir(parents=True,exist_ok=True)
slugs=['jupiter-unisono','velluto-arco','fiato-fuso','plettro-ambra','legno-risonante','chiave-di-petali','soffio-di-sax','plettro-vivo','pizzicato-seta','colpo-di-legno']
pads=set(slugs[:5]);pieces=[];rows=[];offset=0
for slug in slugs:
 phrase='48:0:3.5:98,55:0:3.5:93,60:0:3.5:90' if slug in pads else '60:0:.45:100,67:.65:.2:90,70:1:.35:97,72:1.5:.6:108,67:2.4:.5:97,60:3.2:.6:95'
 pv=render.preview(slug,phrase,tail=1.5);x=np.asarray(pv.audio.data,dtype=np.float64)
 if x.ndim==1:x=np.column_stack([x,x])
 amp=np.max(abs(x),axis=1);active=x[amp>10**(-45/20)]
 rms=float(np.sqrt(np.mean(active**2))) if active.size else 0
 peak=float(np.max(abs(x)));gain=min(10**(-22/20)/max(rms,1e-12),10**(-6/20)/max(peak,1e-12));x*=gain
 sf.write(OUT/(slug+'-matched.wav'),x,pv.audio.sr,subtype='PCM_24')
 pieces.extend([x,np.zeros((int(.5*pv.audio.sr),2))]);rows.append({'slug':slug,'starts_seconds':round(offset,3),'seconds':len(x)/pv.audio.sr,'gain_db':20*np.log10(gain),'peak_dbfs':20*np.log10(max(np.max(abs(x)),1e-12))});offset+=len(x)/pv.audio.sr+.5
 print(slug,rows[-1]['starts_seconds'],flush=True)
sf.write(OUT/'aria-10-voci-matched.wav',np.concatenate(pieces),pv.audio.sr,subtype='PCM_24')
(OUT/'index.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'ASCOLTO.md').write_text('# Aria — dieci voci isolate\n\nRender del motore nativo, stesso accordo/frase per ruolo, compensazione di livello senza compressione o effetti aggiunti.\n\n'+ '\n'.join(f"- {r['starts_seconds']:05.1f} s — {r['slug']}" for r in rows)+'\n')
