"""Cielo reproducible calibration, engine previews and numerical verification.
Calibration is stored in the recipe map, so normal subsequent compiles preserve it.
"""
from pathlib import Path
import json, math, subprocess, concurrent.futures
import numpy as np
import soundfile as sf
from libero import Audio, dsp, analysis
from libero.compiler import compile_sound
from libero.lint import _load, lint_text, lint_bundle
from libero.render import render
from scipy import signal
BANK=Path.home()/'Libero/banks/cielo'

def key(z):return (z['root'],z.get('take',0),tuple(z.get('dyn') or [0,1]),z.get('articulation') or 'natural')
def calibrate(folder):
    build=folder/'build';mp=folder/'samples/map.json';regions=json.loads(mp.read_text())
    lookup={key(r):r for r in regions};changes=[]
    manifest=json.loads((build/'manifest.json').read_text())
    data=[_load(build,z,True) for z in manifest['zones']]
    for d in data:
        r=lookup[key(d.z)]
        if d.above18k_db>-40:
            original=folder/'samples'/r['file'];temp=original.with_name(original.stem+'-filtered.wav')
            Audio.load(original).lowpass(16000,order=2,zero_phase=True).save(temp,subtype='PCM_24');temp.replace(original)
            changes.append({'key':key(d.z),'source_lowpass_hz':16000,'why':'Suppress recorded ultrasonic hiss before pitched keyboard resampling; no added bright layer.'})
        if d.f0_cents is not None:
            old=r.get('tune_cents',0);r['tune_cents']=round(d.z.get('tune_cents',0)-d.f0_cents,2)
            changes.append({'key':key(d.z),'pitch_cents':r['tune_cents'],'measured_before':d.f0_cents})
    groups={}
    for d in data:
        if d.z.get('take',0)==0 and d.z.get('dyn'):groups.setdefault((d.z.get('articulation'),d.z['root']),[]).append(d)
    for group,ds in groups.items():
        ds.sort(key=lambda d:tuple(d.z['dyn']));lv=np.array([d.lufs_max for d in ds]);target=lv.copy()
        if len(ds)<2:continue
        for i in range(1,len(ds)):target[i]=min(target[i],target[i-1]+8)
        for i in range(len(ds)-2,-1,-1):target[i]=min(target[i],target[i+1]-3)
        for d,t,v in zip(ds,target,lv):
            correction=float(t-v)
            if abs(correction)<.05:continue
            for r in regions:
                if r['root']==d.z['root'] and (r.get('articulation') or 'natural')==(d.z.get('articulation') or 'natural') and tuple(r.get('dyn') or [])==tuple(d.z['dyn']):r['gain_db']=r.get('gain_db',0)+correction
            changes.append({'key':key(d.z),'level_db':correction})
    mp.write_text(json.dumps(regions,indent=2))
    (folder/'samples/calibration.json').write_text(json.dumps({'method':'Constant root tuning from the same 0.15–1.5 s sustain window used by lint; level only reduced on inverted or oversized dynamics ladders, same correction for independent takes. No timbre/dynamic synthesis.','changes':changes},indent=2))
    res=compile_sound(folder,jobs=2)
    if not res.ok:raise RuntimeError(res.error)
    print('calibrated',folder.name,flush=True)


def verify(folder):
    recipe=folder/'sound.py';old=recipe.read_text();new=old.replace("tags=['voce','coro','campionato','cielo']","tags=['voice','choir','voce','coro','campionato','cielo']")
    before=json.loads((folder/'build/manifest.json').read_text());expected=[z.get('tune_cents',0) for z in before['zones']]
    if new!=old:recipe.write_text(new)
    res=compile_sound(folder,jobs=2)
    if not res.ok:raise RuntimeError(res.error)
    after=json.loads((folder/'build/manifest.json').read_text());assert expected==[z.get('tune_cents',0) for z in after['zones']]
    build=folder/'build';m=json.loads((build/'manifest.json').read_text());zs=m['zones'];lo=min(z['lo'] for z in zs);hi=max(z['hi'] for z in zs);mid=sorted({z['root'] for z in zs})[len({z['root'] for z in zs})//2]
    from build_cielo import figure
    exemplar=next(z for z in zs if z['root']==mid and z.get('take',0)==0)
    sample=Audio.load(build/exemplar['file']);x=dsp.mono(sample.data[:72000]);fr,power=signal.welch(x,sample.sr,nperseg=min(8192,len(x)))
    centroid=float((fr*power).sum()/(power.sum()+1e-30));prov=json.loads((folder/'samples/provenance.json').read_text());voices=max(len(r.get('singers',[])) for r in prov) or 3
    art=figure(m['title'],lo,hi,m['params'].get('amp_attack',0),1.4 if 'breve' in folder.name or 'bianche' in folder.name else 2.4,voices,centroid)
    if folder.name=='voci-bianche-sillabe':art=art.replace('3 separate columns represent independent recorded singers;','Three columns suggest the recorded children’s group; its exact singer count is unknown;')
    (folder/'figure.svg').write_text(art);(build/'figure.svg').write_text(art)
    notes=f'{lo}:0:1.2:30,{hi}:1.5:1.3:118,{mid}:3.1:.4:55,{mid}:3.7:.4:112,{mid}:4.3:1.8:75,{min(hi,mid+3)}:5:1.8:115,{mid}:7.4:8:105'
    out=build/'preview.wav';info=render(folder,out,notes,tail=3)
    a=Audio.load(out);subprocess.run(['/opt/homebrew/bin/ffmpeg','-y','-loglevel','error','-i',str(out),'-c:a','aac','-b:a','192k',str(build/'preview.m4a')],check=True)
    (build/'spectrogram.png').write_bytes(analysis.spectrogram(a,title=m['title']))
    if len(m.get('articulations',[]))>1:render(folder,build/'crescendo.wav',f'{mid}:0:8:110',params={'artic':1},tail=3)
    findings=lint_bundle(build);report=lint_text(build,folder.name);(build/'lint.txt').write_text(report)
    ram=sum(sf.info(str(build/z['file'])).frames*sf.info(str(build/z['file'])).channels*4 for z in zs)
    lengths=[sf.info(str(build/z['file'])).duration for z in zs]
    metrics={'normal_recompile_preserves_tuning':True,'zones':len(zs),'sample_seconds_min':round(min(lengths),2),'sample_seconds_max':round(max(lengths),2),'roots':sorted({z['root'] for z in zs}),'ram_mib':round(ram/1048576,2),'preview_peak_db':a.peak_db,'preview_dc_db':dsp.db(abs(float(a.data.mean()))),'preview_max_step':float(np.abs(np.diff(a.data,axis=0)).max()),'notes':notes,'renderer':info,'fail':sum(f.level=='FAIL' for f in findings),'warn':sum(f.level=='WARN' for f in findings)}
    (build/'verification.json').write_text(json.dumps(metrics,indent=2))
    notesfile=folder/'notes.md';text=notesfile.read_text().split('## Verification')[0]
    if folder.name=='voci-bianche-sillabe':
        start=text.index('Range MIDI');end=text.index('Provenance with')
        text=text[:start]+f'Range MIDI {lo}–{hi}; {len(zs)} natural children’s syllable fragments across {len(metrics["roots"])} native roots, one recorded dynamic, up to 16 independent fragments/takes per root. No loops or synthetic/adult transformed voices. Constant pitch calibration and a 650 ms excerpt taper are disclosed; original syllables, church sound and triangle remain.\n\n'+text[end:]
    text+='## Verification\n\n'+f'{len(zs)} zones, {len(metrics["roots"])} roots; source duration {min(lengths):.2f}–{max(lengths):.2f} s, decoded stereo RAM {metrics["ram_mib"]} MiB. Preview peak {a.peak_db:.2f} dBFS; DC {metrics["preview_dc_db"]:.1f} dB. Engine preview exercises both extremes, soft/loud, repeats, overlap and an 8 s held key; unlooped samples naturally end during longer holds. No hard clipping.\n\n'+report+'\n'
    explanations={'layers':'The original field choir provides one recorded performance level; a second artificial dynamic would misrepresent the source.', 'brightness':'Natural independently sung vowels do not all increase high-frequency energy monotonically; their authentic timbre is retained instead of adding an artificial bright layer.','loudness':'Native register and changing real singer membership produce level differences; velocity sessions are calibrated without flattening every note.','noise':'Recorded room/breath noise varies between independent singers/syllables and remains natural.','tuning':'Independent singers preserve natural vibrato; constant sustain-window tuning removes static key offsets, not their time-varying performance.'}
    if folder.name!='voci-bianche-sillabe':explanations['layers']='Crescendo uses one original messa recording per take; the Vocale articulation provides the three independently recorded pp/normal/forte performances. No fabricated velocity layers are added to the crescendo.'
    for f in findings:
        if f.level=='WARN':text+=f'- {f.check}: {explanations.get(f.check,"See measured finding above; authentic independent source variation remains.")}\n'
    if folder.name!='voci-bianche-sillabe':text+='\nWhole-note audit: every extracted component note was checked with broad-range voiced YIN in 0.5 s windows, beyond the static head-window lint. Three original attack/end transitions were trimmed after source spectrogram inspection; eight remaining tracker octave/subharmonic ambiguities were visually reviewed against stable harmonic bands. No confirmed register-change fragment is deliberately mapped as one sustained note. Natural vibrato, breath and recorded room remain.\n'
    notesfile.write_text(text);print(folder.name,metrics['fail'],'FAIL',metrics['warn'],'WARN',a.peak_db,flush=True)
    return metrics

if __name__=='__main__':
    folders=sorted(p for p in BANK.iterdir() if (p/'sound.py').exists())
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:results=dict(zip([p.name for p in folders],ex.map(verify,folders)))
    (BANK/'verification.json').write_text(json.dumps(results,indent=2))
    if any(r['fail'] for r in results.values()):raise SystemExit('Unresolved lint FAIL; inspect individual reports.')
