#!/usr/bin/env python3
"""Build Aria v2 from four CC0 recording families and new hybrid synthesis.
Run: python/.venv/bin/python python/scripts/build_aria_v2.py [--compile]
"""
from __future__ import annotations
import json, math, re, shutil, subprocess, sys, urllib.request, urllib.parse
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; PY=ROOT/'python'; sys.path.insert(0,str(PY))
from libero.library import home
LIB=home(); BANK=LIB/'banks'/'aria'; CACHE=LIB/'cache'/'libraries'; SR=48000
ROOTS_PAD=[48,55,62,69,76,83]; ROOTS_LEAD=[48,55,62,69,76,83]
NOTES={'c':0,'cs':1,'db':1,'d':2,'ds':3,'eb':3,'e':4,'f':5,'fs':6,'gb':6,'g':7,'gs':8,'ab':8,'a':9,'as':10,'bb':10,'b':11}
def midi(tok):
    t=tok.lower().replace('#','s'); m=re.fullmatch(r'(c#|d#|f#|g#|a#|db|eb|gb|ab|bb|[a-g])(-?\d+)',t)
    if not m:return None
    key=m.group(1).replace('#','s'); octv=int(m.group(2)); return (octv+1)*12+NOTES[key]
def note_token(path):
    name=path.stem.lower()
    for t in re.findall(r'(?<![a-z])(?:[a-g](?:#|b)?-?\d+)(?![a-z])',name):
        x=midi(t)
        if x is not None:return x
    return None

def candidates(family):
    if family=='arco': return list((CACHE/'karoryfer-smolken'/'arco').glob('arco_*.wav'))
    if family=='pizz': return list((CACHE/'karoryfer-smolken'/'pizz').glob('pizz_*.wav'))
    if family=='sax': return list((CACHE/'karoryfer-weresax'/'Samples'/'alto').glob('*.wav'))
    if family=='guitar': return list((CACHE/'karoryfer-emilyguitar'/'notes').glob('*.wav'))
    if family=='marimba':
        paths=[]
        idx=json.loads((CACHE/'vcsl'/'_index.json').read_text())['files']
        for rel in idx:
            if '/Marimba/' in rel and rel.lower().endswith('.wav'):
                local=CACHE/'vcsl'/rel
                if not local.exists():
                    local.parent.mkdir(parents=True,exist_ok=True)
                    url='https://raw.githubusercontent.com/sgossner/VCSL/master/'+urllib.parse.quote(rel,safe='/')
                    req=urllib.request.Request(url,headers={'User-Agent':'Libero-Aria-v2/1.0'})
                    with urllib.request.urlopen(req,timeout=40) as src,local.open('wb') as dst: shutil.copyfileobj(src,dst)
                paths.append(local)
        return paths
    raise ValueError(family)

FAMILIES={f:candidates(f) for f in ('arco','pizz','sax','guitar','marimba')}
def dyn_score(path,fam,target):
    s=path.stem.lower()
    if fam=='arco':
        d=re.search(r'_(pp|p|mf|f|ff)_',s); val={'pp':0,'p':.2,'mf':.52,'f':.78,'ff':1}.get(d.group(1),.5) if d else .5
    elif fam=='pizz':
        d=re.search(r'_([pmf])([a-z])$',s); val={'p':.2,'m':.55,'f':.85}.get(d.group(1),.5) if d else .5
    elif fam=='sax': val=.8 if re.search(r'_f_rr',s) else .25
    elif fam=='guitar':
        d=re.search(r'_([a-z]+)_rr',s); val={'pp':.05,'p':.2,'mp':.4,'mf':.58,'f':.82,'ff':1}.get(d.group(1),.5) if d else .5
    else: val={'soft':.15,'med':.55,'loud':.9}.get((re.search(r'_(soft|med|loud)_',s) or [None,'med'])[1],.55)
    return abs(val-target)

def choose(fam, root, d, take=0):
    pool=[p for p in FAMILIES[fam] if note_token(p) is not None]
    if fam=='sax': pool=[p for p in pool if ('_cnd' in p.stem or '_dnm' in p.stem)]
    if fam=='guitar': pool=[p for p in pool if re.search(r'_rr[1-5]$',p.stem)]
    if not pool: raise RuntimeError(f'no source clips for {fam}')
    # Weresax note labels are one octave below their recorded pitch. Select by
    # the measured sounding register, not by the filename's written convention.
    octave=12 if fam=='sax' else 0
    pitch=lambda p: note_token(p)+octave
    # Nearest pitch/force first; alternate genuine RR, bow direction and mic takes.
    nearest=min(abs(pitch(p)-root) for p in pool)
    pool=[p for p in pool if abs(pitch(p)-root)==nearest]
    best=min(dyn_score(p,fam,d) for p in pool)
    pool=sorted((p for p in pool if dyn_score(p,fam,d)<=best+.13),key=lambda p:p.name)
    return pool[take%len(pool)]

SOUNDS=[
 dict(slug='velluto-arco',title='Velluto d’Arco',sub='arco vivo, corpo caldo e armoniche mobili',family='arco',role='pad',arch='bow',desc='Un pad ibrido denso e caldo: arco reale di contrabbasso, risonanza di corda modellata e armoniche che respirano lentamente.',ratios=[(1,.42),(2,.25),(3,.16),(4.02,.09),(5.96,.08)],bodydb=-22,attack=.18,release=1.2,accent='#a95d45'),
 dict(slug='fiato-fuso',title='Fiato Fuso',sub='tenuto di sax, formanti ampi e soffio inciso',family='sax',role='pad',arch='reed',desc='Tenuto di sax alto con attacco di fiato, un corpo di risonanze originali e una lieve crescita delle formanti: pieno al centro senza gonfiare il basso.',ratios=[(1,.5),(2,.22),(3,.14),(4,.1),(6,.04)],bodydb=-23,attack=.12,release=1.0,accent='#b17a42'),
 dict(slug='plettro-ambra',title='Plettro d’Ambra',sub='nota elettrica pizzicata, legno risonante',family='guitar',role='pad',arch='plucked',desc='Nota singola di chitarra elettrica flatwound, con il plettro in primo piano e corde sintetiche di sostegno che evolvono senza fissare accordi.',ratios=[(1,.5),(2,.25),(2.99,.12),(4.03,.08),(5.01,.05)],bodydb=-24,attack=.3,release=.9,accent='#bd694b'),
 dict(slug='legno-risonante',title='Legno Risonante',sub='colpo di marimba, risonatore caldo in espansione',family='marimba',role='pad',arch='modal',desc='Un colpo di marimba VCSL alimenta modi di legno e un tono basso sostenuto; la nota rimane leggibile mentre le risonanze si aprono con gradualità.',ratios=[(1,.42),(2.76,.22),(4.12,.18),(5.43,.1),(6.9,.08)],bodydb=-24,attack=.28,release=1.15,accent='#9d7b4e'),
 dict(slug='soffio-di-sax',title='Soffio di Sax',sub='tongue bite, legato pieno per linee melodiche',family='sax',role='lead',arch='reedlead',desc='Voce melodica dal sax registrato, con una lingua netta, corpo pieno e un bordo di sintesi che mantiene le note leggibili anche in frase rap.',ratios=[(1,.52),(2,.22),(3,.14),(5,.08),(7,.04)],bodydb=-22,attack=.008,release=.35,accent='#c08348'),
 dict(slug='plettro-vivo',title='Plettro Vivo',sub='attacco di corda, centro cantabile e deciso',family='guitar',role='lead',arch='picklead',desc='Una nota di chitarra singola con transiente di plettro, sustain asciutto e armoniche originali calibrate per una melodia principale.',ratios=[(1,.52),(2,.26),(3,.13),(4,.06),(6,.03)],bodydb=-22,attack=.006,release=.3,accent='#b65742'),
 dict(slug='pizzicato-seta',title='Pizzicato di Seta',sub='contrabbasso pizzicato in registro melodico',family='pizz',role='lead',arch='pizzlead',desc='Pizzicato di contrabbasso portato nel registro melodico, con legno e grana della corda reali, sostenuti da una coda armonica discreta.',ratios=[(1,.58),(2,.24),(3,.1),(4,.05),(5,.03)],bodydb=-22,attack=.004,release=.28,accent='#9e644d'),
 dict(slug='colpo-di-legno',title='Colpo di Legno',sub='mallet articolato, sustain intonato per hook',family='marimba',role='lead',arch='malletlead',desc='Colpo reale di marimba con una coda intonata e più armonica: un accento di legno asciutto, facile da accordare in piccoli hook e stabs.',ratios=[(1,.62),(2,.19),(3,.10),(4,.055),(5,.035)],bodydb=-22,attack=.002,release=.22,accent='#8e784e'),
]

def figure_svg(item):
    """An engraved reading of this recipe, in the shared paper/ink/gold palette."""
    slug=item['slug']
    descs={
      'velluto-arco':'Il profilo largo del contrabbasso traduce il sustain di 14,2 s; quattro corde tese portano i parziali 1:2:3:4,02:5,96. La bacchetta dorata è il contatto dell’arco, sopra la tavola rigata lungo la curvatura del corpo.',
      'fiato-fuso':'La campana svasata e la colonna d’aria piegata traducono il tenuto di sax e le formanti in movimento. Le tre chiavi maggiori segnano i centri del tubo; il soffio puntinato si addensa all’imboccatura e la prima risonanza è dorata.',
      'plettro-ambra':'La tavola e il manico traducono la nota singola di chitarra, mentre le sei corde indicano la serie armonica 1:2:2,99:4,03:5,01. Il plettro dorato è fermato nel punto d’attacco; la venatura segue la pancia del corpo.',
      'legno-risonante':'Le cinque barre e i tubi accordati rappresentano i modi 1:2,76:4,12:5,43:6,90 della marimba; la fundamental line resta al centro mentre il colpo si spegne in 1,3 s. Il mazzuolo dorato marca l’eccitazione reale, con venature curve nella tavola.',
      'soffio-di-sax':'La sezione del bocchino mostra ancia, camera e foro: l’attacco di lingua dura 8 ms e il tubo sostiene una fondamentale con parziali 1:2:3:5:7. La punta dorata è la lingua; i punti nel condotto sono il fiato registrato, fitto all’inizio e poi rado.',
      'plettro-vivo':'Il close-up del ponte fissa il plettro a β=0,19 sulla corda; i sei modi disegnati seguono i parziali 1:2:3:4:6. La punta dorata è il transiente, la corda tesa e il pickup inciso mostrano la coda asciutta del lead.',
      'pizzicato-seta':'La tastiera del contrabbasso è vista al punto di pizzico: l’attacco di 4 ms è il rilascio della corda sotto il dito dorato. Quattro corde corrono verso il ponte; la linea di sustain segue i parziali 1:2:3:4:5.',
      'colpo-di-legno':'La sezione della barra mostra il colpo di marimba e il risonatore tubolare; il corpo mantiene una fondamentale armonica 1:2:3:4:5 dopo l’attacco di 2 ms. Il mazzuolo dorato è l’unico accento, le venature e la cavità seguono il legno.'}
    art={
      'velluto-arco':'''<g stroke="currentColor" fill="none" stroke-width="1.2"><path d="M246 65 C227 71 220 84 224 102 L231 143 L212 172 C177 183 149 202 137 232 C118 282 135 348 167 386 C190 414 224 430 256 432 C288 430 322 414 345 386 C377 348 394 282 375 232 C363 202 335 183 300 172 L281 143 L288 102 C292 84 285 71 266 65Z" fill="#f3eee6"/><path d="M223 98 Q256 114 289 98 M231 148 L281 148 M213 174 Q256 191 299 174 M196 187 L196 344 M216 180 L216 356 M236 176 L236 363 M256 176 L256 366 M276 176 L276 363 M296 180 L296 356 M316 187 L316 344 M156 263 Q174 251 181 275 Q174 299 156 310 M356 263 Q338 251 331 275 Q338 299 356 310 M181 364 Q256 395 331 364 M226 368 L286 368 M240 393 L272 393" stroke-width=".8"/><path d="M241 73 Q256 57 271 73 L268 88 Q256 96 244 88Z" fill="currentColor" stroke-width=".8"/><path d="M186 208 Q205 223 207 255 M326 208 Q307 223 305 255 M164 333 Q189 374 218 390 M348 333 Q323 374 294 390 M174 245 Q189 230 204 234 M338 245 Q323 230 308 234 M199 399 Q222 416 244 419 M313 399 Q290 416 268 419" stroke-width=".45"/><path d="M82 161 L421 114" stroke="#b8924f" stroke-width="2.2"/><path d="M95 159 L414 115 M104 166 L417 119" stroke="currentColor" stroke-width=".45"/></g><path d="M251 351 L261 351 L260 368 L252 368Z" fill="#b8924f"/>''',
      'fiato-fuso':'''<g stroke="currentColor" fill="none" stroke-width="1.2"><path d="M175 78 L209 70 L220 110 C226 131 214 151 203 169 C187 195 178 225 184 250 C190 277 214 291 229 311 C246 333 235 357 218 378 L195 402 L214 419 L244 393 C270 370 280 339 264 312 C250 288 221 273 216 248 C211 224 224 201 240 181 C258 158 271 136 264 110 L252 69 L284 61 L301 111 C311 144 292 175 274 200 C252 232 249 252 270 273 C296 299 321 326 313 355 C307 383 282 407 260 428 L232 451 L185 421 L208 394 C230 369 234 349 219 330 C202 309 178 295 168 267 C155 231 166 190 187 157 C203 131 213 115 207 99Z" fill="#f3eee6"/><path d="M218 91 L261 82 M195 183 Q222 194 244 180 M184 250 Q203 260 220 248 M218 311 Q239 302 259 312 M215 393 Q237 407 255 392 M196 422 Q224 439 244 418" stroke-width=".8"/><path d="M203 143 l17 9 M192 166 l18 9 M183 199 l18 6 M181 228 l19 3 M191 271 l17 -3 M207 296 l18 -9 M235 328 l18 -8 M239 358 l17 5 M224 385 l17 10 M202 411 l17 10" stroke-width=".45"/><ellipse cx="249" cy="82" rx="18" ry="9" fill="#b8924f" stroke-width=".8"/><circle cx="222" cy="213" r="4"/><circle cx="238" cy="231" r="3"/><circle cx="228" cy="250" r="2.5"/><circle cx="248" cy="263" r="2"/><circle cx="257" cy="281" r="1.5"/></g><path d="M316 355 Q349 371 365 398 M325 347 Q361 358 380 381 M334 338 Q370 347 393 368" stroke="currentColor" stroke-width=".45"/>''',
      'plettro-ambra':'''<g stroke="currentColor" fill="none" stroke-width="1.2"><path d="M291 71 L316 70 L323 233 C353 250 380 269 390 300 C404 344 371 386 322 402 C274 418 210 408 177 378 C143 348 141 303 162 273 C176 253 199 241 224 231 L219 73 L244 72 L250 228 Q268 225 287 228Z" fill="#f3eee6"/><path d="M222 98 L296 97 M225 120 L299 119 M226 143 L300 142 M227 166 L301 165 M228 189 L302 188 M229 212 L303 211 M234 232 Q274 221 316 234 M242 250 L239 347 M253 247 L252 358 M267 247 L267 362 M281 247 L282 358 M294 249 L296 349 M188 292 Q250 270 337 293 M175 328 Q244 354 348 328 M196 367 Q253 388 320 368" stroke-width=".75"/><path d="M183 284 Q209 268 235 266 M316 267 Q350 276 366 300 M174 338 Q200 367 230 378 M328 375 Q355 360 375 338 M218 381 Q256 395 298 382" stroke-width=".45"/><path d="M243 349 L298 349 L294 361 L246 361Z" fill="currentColor" stroke-width=".8"/><circle cx="260" cy="354" r="2.3" fill="#f3eee6"/><circle cx="281" cy="354" r="2.3" fill="#f3eee6"/></g><path d="M224 261 Q251 242 281 254 Q273 273 251 288 Q234 280 224 261Z" fill="#b8924f" stroke="currentColor" stroke-width=".8"/>''',
      'legno-risonante':'''<g stroke="currentColor" fill="none" stroke-width="1.2"><path d="M87 205 L420 170 L432 218 L98 254Z" fill="#f3eee6"/><path d="M101 266 L432 229 L439 269 L107 308Z" fill="#f3eee6"/><path d="M116 321 L437 282 L442 318 L122 357Z" fill="#f3eee6"/><path d="M139 367 L435 333 L439 365 L143 399Z" fill="#f3eee6"/><path d="M164 411 L425 382 L428 408 L167 437Z" fill="#f3eee6"/><path d="M96 214 L416 181 M110 276 L428 242 M124 331 L434 294 M147 376 L431 345 M172 419 L421 391" stroke-width=".75"/><path d="M128 249 L136 269 M206 241 L214 261 M288 232 L296 252 M368 223 L376 243 M149 302 L157 323 M233 293 L241 314 M317 284 L325 305 M179 352 L187 372 M265 342 L273 362 M352 332 L360 352 M208 393 L216 410 M294 383 L302 400 M365 375 L373 392" stroke-width=".45"/><path d="M130 258 L142 359 L155 403 M395 241 L388 323 L381 378" stroke-width=".8"/><path d="M146 300 Q194 292 238 297 M271 281 Q322 273 367 280 M173 350 Q214 343 249 347 M294 335 Q332 329 365 334" stroke-width=".45"/><path d="M95 260 L81 355 M431 223 L452 337 M81 355 Q256 385 452 337" stroke-width=".8"/></g><path d="M256 151 L267 172 L256 190 L245 172Z" fill="#b8924f" stroke="currentColor" stroke-width=".8"/><path d="M224 184 L256 172 L288 184" stroke="currentColor" stroke-width=".45"/>''',
      'soffio-di-sax':'''<g stroke="currentColor" fill="none" stroke-width="1.2"><path d="M75 230 L104 214 L167 243 L247 243 L337 243 L419 243 L440 256 L419 269 L337 269 L247 269 L167 269 L104 298 L75 282Z" fill="#f3eee6"/><path d="M108 216 L171 247 L419 247 M108 296 L171 265 L419 265 M166 244 L166 268 M179 246 L179 266 M192 246 L192 266 M205 246 L205 266 M218 246 L218 266 M231 246 L231 266" stroke-width=".8"/><path d="M91 221 L133 246 L133 264 L91 290 M146 241 L151 272 M272 248 L272 264 M300 248 L300 264 M328 248 L328 264 M356 248 L356 264 M384 248 L384 264" stroke-width=".45"/><path d="M62 206 Q100 198 139 228 L171 244 L163 266 L128 281 Q99 310 62 298 Q88 275 94 253 Q88 231 62 206Z" fill="#f3eee6"/><path d="M63 206 Q96 215 123 244 M62 298 Q96 286 123 261 M79 219 Q98 235 109 252 Q98 271 79 285" stroke-width=".8"/><path d="M154 238 L171 251 L162 270 L145 257Z" fill="#b8924f" stroke-width=".8"/><path d="M85 215 L111 232 M80 224 L107 240 M74 234 L102 249 M74 269 L104 259 M80 281 L108 267 M88 290 L116 271" stroke-width=".45"/><circle cx="218" cy="255" r="1.1"/><circle cx="251" cy="256" r=".9"/><circle cx="284" cy="255" r=".8"/><circle cx="317" cy="256" r=".7"/><circle cx="350" cy="256" r=".6"/></g><path d="M414 234 Q442 236 455 256 Q442 276 414 278" stroke="currentColor" stroke-width=".8"/>''',
      'plettro-vivo':'''<g stroke="currentColor" fill="none" stroke-width="1.2"><path d="M67 330 L445 330 M67 342 L445 342 M67 354 L445 354" stroke-width=".7"/><path d="M94 316 L431 316 L431 367 L94 367Z" fill="#f3eee6"/><path d="M118 326 L408 326 M118 338 L408 338 M118 350 L408 350" stroke-width=".45"/><path d="M131 368 L131 389 L397 389 L397 368 M144 389 L155 411 L372 411 L385 389" stroke-width=".8"/><path d="M204 315 L204 367 M222 315 L222 367 M240 315 L240 367 M258 315 L258 367 M276 315 L276 367 M294 315 L294 367 M312 315 L312 367" stroke-width=".45"/><path d="M93 282 L173 282 L184 311 L82 311Z M322 282 L415 282 L431 311 L312 311Z" fill="#f3eee6"/><path d="M102 288 L166 288 M329 288 L408 288 M99 296 L169 296 M326 296 L418 296" stroke-width=".45"/><path d="M67 330 L226 329 L257 334 L445 342" stroke-width=".7"/><path d="M97 278 L111 265 L125 278 L141 265 L156 278" stroke-width=".45"/><path d="M186 305 Q232 311 257 332 Q280 309 316 304" stroke-width=".8"/></g><path d="M235 281 Q253 258 274 278 L262 315 Q245 309 235 281Z" fill="#b8924f" stroke="currentColor" stroke-width=".8"/>''',
      'pizzicato-seta':'''<g stroke="currentColor" fill="none" stroke-width="1.2"><path d="M228 63 L284 63 L286 293 L226 293Z" fill="#f3eee6"/><path d="M235 67 L235 300 M249 67 L249 300 M263 67 L263 300 M277 67 L277 300" stroke-width=".7"/><path d="M212 294 Q256 280 300 294 L315 319 Q256 339 197 319Z" fill="#f3eee6"/><path d="M202 315 L309 315 M188 345 L324 345 M207 328 Q256 340 305 328" stroke-width=".8"/><path d="M241 77 L241 288 M255 77 L255 288 M269 77 L269 288" stroke-width=".45"/><path d="M226 121 L284 121 M226 182 L284 182 M226 243 L284 243" stroke-width=".8"/><path d="M238 125 l7 0 M252 125 l7 0 M266 125 l7 0 M238 186 l7 0 M252 186 l7 0 M266 186 l7 0 M238 247 l7 0 M252 247 l7 0 M266 247 l7 0" stroke-width=".45"/><path d="M111 166 C151 154 181 170 209 201 Q224 219 238 213 L247 197 Q254 184 268 193 L281 206 Q294 217 311 208" stroke-width="1.1"/><path d="M110 166 Q142 144 174 161 M111 166 Q138 185 165 187 L205 201" stroke-width=".8"/><path d="M113 162 Q149 143 181 161 M121 169 Q147 185 175 190 M134 159 L142 170 M147 157 L155 170 M160 159 L168 173" stroke-width=".45"/><path d="M191 340 L201 332 L214 340 L225 332 L237 340" stroke-width=".45"/></g><path d="M236 204 Q251 178 270 190 L259 214 Q246 224 236 204Z" fill="#b8924f" stroke="currentColor" stroke-width=".8"/>''',
      'colpo-di-legno':'''<g stroke="currentColor" fill="none" stroke-width="1.2"><path d="M73 307 Q256 284 439 307 L426 360 Q256 383 86 360Z" fill="#f3eee6"/><path d="M87 320 Q256 300 426 320 M90 345 Q256 365 423 345" stroke-width=".8"/><path d="M102 316 Q125 330 145 352 M139 312 Q162 329 181 357 M179 308 Q198 329 214 360 M320 310 Q299 331 286 360 M359 314 Q339 333 327 356 M401 318 Q382 336 367 352" stroke-width=".45"/><path d="M122 359 L116 416 Q256 447 396 416 L390 359 M147 368 L145 407 M179 374 L177 413 M211 377 L210 418 M243 379 L243 420 M275 379 L275 420 M307 377 L309 418 M339 374 L341 413 M371 368 L373 407" stroke-width=".8"/><path d="M113 416 Q256 442 399 416 M130 425 Q256 449 382 425 M160 432 Q256 451 352 432" stroke-width=".45"/><path d="M78 90 L223 273 M68 100 L213 283 M56 110 L201 294" stroke-width=".65"/><path d="M201 264 Q218 237 243 247 Q266 256 254 281 Q239 302 216 285Z" fill="#f3eee6" stroke-width=".9"/><path d="M216 267 Q229 254 244 263 M216 276 Q230 264 247 272" stroke-width=".45"/><path d="M153 144 L180 177 M169 135 L197 168 M186 126 L213 159" stroke-width=".45"/></g><circle cx="230" cy="271" r="14" fill="#b8924f" stroke="currentColor" stroke-width=".8"/><path d="M230 248 L230 294 M207 271 L253 271" stroke="currentColor" stroke-width=".45"/>'''
    }
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" stroke-linecap="round" stroke-linejoin="round" fill="none"><title>{item['title']}</title><desc>{descs[slug]}</desc>{art[slug]}</svg>'''

def get_source_map(item, roots, folder):
    family=item['family']; maps={}; takes=2 if family in ('arco','pizz','sax','guitar') else 1
    for ni,root in enumerate(roots):
        maps[str(root)]={}
        for di,dyn in enumerate((.15,.55,.95)):
            choices=[]
            for take in range(takes):
                src=choose(family,root,dyn,take); ext=src.suffix
                name=f'src_{root}_{di}_{take}{ext}'; dst=folder/'samples'/name
                if not dst.exists() or dst.stat().st_size!=src.stat().st_size: shutil.copy2(src,dst)
                # VCSL note tokens use C4=60 here, but the Outrigger recordings
                # sound one octave above their label (checked from the partials).
                src_note=note_token(src)+(12 if family in ('marimba','sax') else 0)
                choices.append({'file':name,'src_midi':src_note,'name':src.name})
            maps[str(root)][str(di)]=choices
    return maps

def recipe(item, roots, maps):
    # body logic is materially distinct, with source gesture plus one of four bespoke architectures.
    dur=14.2 if item['role']=='pad' else 2.6
    data=repr(maps); takes=2 if item['family'] in ('arco','pizz','sax','guitar') else 1
    arch=item['arch']; ratios=item['ratios']
    syn=f'''    # Original designed synthesis layer: coherent partials with slow, independent amplitude travel.
    n=int({dur}*ctx.sr); t=np.arange(n,dtype=np.float64)/ctx.sr
    dyn=float(ctx.dyn); brightness=0.72 if dyn>.75 else (0.38 if dyn<.35 else .56)
    shape={ratios!r}
    y=np.zeros(n,dtype=np.float64); rng=np.random.default_rng(ctx.seed)
    period={12.0 if item['role']=='pad' else 6.0}
    for i,(ratio,weight) in enumerate(shape):
        f=round(ctx.freq*ratio*period)/period if {item['role']!r}=='pad' else ctx.freq*ratio
        if f>=ctx.sr*.42: continue
        ph=rng.uniform(0,2*np.pi)
        rate=round((.14+.02*(i%3))*period)/period if {item['role']!r}=='pad' else .035+.017*(i%4)
        wobble=1.+(.045+.035*brightness)*np.sin(2*np.pi*rate*t+ph*.31)
        env=np.ones(n)
        if {item['role']!r}=='lead': env=np.exp(-t*(.15+.24*(i%3)))
        y+=weight*(ratio**((dyn-.55)*.24))*wobble*env*np.sin(2*np.pi*f*t+ph)
    # Mild spectral/dynamic contour preserves harmonic identity at soft velocity.
    scale=(.80+.20*dyn)
    synthetic=Audio(y*scale,ctx.sr).fade_in(.012 if {item['role']!r}=='pad' else .002).remove_dc()
'''
    layer = f'''from libero import Sound, Audio, synth
import numpy as np
from scipy.signal import find_peaks
sound=Sound(title={item['title']!r},subtitle={item['sub']!r},tags=['hybrid','aria-v2',{item['role']!r},'warm','melodic'],roots={roots!r},dynamics=[.15,.55,.95],sample_rate=48000,accent={item['accent']!r},takes={takes})
SOURCE={data}
ARCH={arch!r}
FAMILY={item['family']!r}

def _source_sustain(ctx, source, duration):
    # A source-shaped, phase-coherent body: spectral envelopes come from five windows
    # of the actual recording and repeat over a six-second exact cycle, not a frozen table.
    period=12.0; sr=ctx.sr; n=int(duration*sr); t=np.arange(n)/sr
    x=source.to_mono().data.astype(np.float64); win_n=min(len(x),max(4096,int(.22*sr)))
    if win_n<1024: return synth.additive(ctx.freq,[(1,.7,0),(2,.2,5),(3,.1,2)],duration,sr,amp=.3,seed=ctx.seed)
    win=np.hanning(win_n); centers=np.linspace(win_n*.55,max(win_n*.55,len(x)-win_n*.55),5).astype(int)
    frames=[]
    for center in centers:
        a=max(0,min(len(x)-win_n,int(center-win_n/2))); seg=x[a:a+win_n]
        spec=np.abs(np.fft.rfft(seg*win,n=32768)); frames.append(spec)
    freqs=np.fft.rfftfreq(32768,1/sr); average=np.mean(frames,axis=0)
    # Marimba's modes are intentionally inharmonic, but the sustain must remain
    # keyed. Derive its spectral envelope around the calibrated harmonic grid;
    # the real modal strike remains audible in the first few seconds.
    max_partials=18 if FAMILY=='marimba' else 36
    ratios=[float(k) for k in range(1,max_partials+1) if ctx.freq*k<sr*.38]
    if not ratios: ratios=[1.0]
    profiles=[]
    bin_hz=sr/32768
    for spec in frames:
        vals=[]
        for ratio in ratios:
            target=ctx.freq*ratio
            # The VCSL marimba's real bars have slightly inharmonic modes.
            # Capture each mode in the nearest keyed harmonic band so the
            # sustain retains the recording's rich spectral envelope while
            # keeping the played pitch stable. Other source families use a
            # tight band to avoid folding neighboring partials together.
            radius=max(2*bin_hz,target*(.105 if FAMILY=='marimba' and ratio>1 else .012))
            lo=max(0,int((target-radius)/bin_hz)); hi=min(len(spec),int((target+radius)/bin_hz)+1)
            vals.append(float(np.max(spec[lo:hi],initial=0)))
        vals=np.asarray(vals); ref=max(float(vals.max()),1e-12)
        vals=vals/ref
        profiles.append(vals)
    profiles=np.asarray(profiles); profiles[-1]=profiles[0]
    ft=np.linspace(0,period,len(profiles)); y=np.zeros(n,dtype=np.float64)
    rng=np.random.default_rng(ctx.seed+191)
    for i,ratio in enumerate(ratios):
        f=round(ctx.freq*ratio*period)/period
        if f<=0 or f>=sr*.38: continue
        amp=np.interp(np.mod(t,period),ft,profiles[:,i])
        if FAMILY!='marimba':
            # Keep the source's low/mid fundamentals filled while preserving its measured upper spectrum.
            floor=(.46/(i+1)**(.82 if FAMILY=='sax' else 1.05))
            amp=np.maximum(amp*.78,floor)
        cycles=1+(i*3+({{'arco':0,'sax':1,'guitar':2,'pizz':3,'marimba':4}}[FAMILY]))%9
        phase=rng.uniform(0,2*np.pi)
        motion=1+.035*np.sin(2*np.pi*(cycles/period)*t+phase)
        y+=amp*motion*np.sin(2*np.pi*f*t+phase*.37)
    body=Audio(y, sr).fade_in(.25).remove_dc().normalize_loudness(-24,ceiling_db=-10)
    return body

@sound.body
def body(ctx):
    key=min(SOURCE,key=lambda k:abs(int(k)-ctx.note))
    di=0 if ctx.dyn<.34 else (1 if ctx.dyn<.76 else 2)
    choices=SOURCE[key][str(di)]; info=choices[ctx.take%len(choices)]
    # Preserve the full recorded gestures; the marimba strike is also exposed
    # as a separate attack layer while the keyed sustain takes over quickly.
    source_limit=min({dur},7.2 if {item['role']!r}=='pad' else {dur})
    recorded=ctx.load(info['file']).trim(0,min(ctx.load(info['file']).duration,source_limit))
    semitones=ctx.note-int(info['src_midi'])
    recorded=recorded.pitch(semitones,preserve_duration=True).to_mono().remove_dc()
    recorded=recorded.normalize_loudness(-26 if {item['role']!r}=='pad' else -24,ceiling_db=-10)
    source_body=_source_sustain(ctx,recorded,{dur}) if {item['role']!r}=='pad' else Audio(np.zeros(int({dur}*ctx.sr)),ctx.sr)
    if {item['role']!r}=='pad':
        nsrc=len(recorded.data); ts=np.arange(nsrc)/ctx.sr
        if FAMILY=='marimba':
            gate=np.clip((.48-ts)/.28,0,1)
        else:
            fade=max(0.10,min(.45,recorded.duration*.13)); gate=np.clip((recorded.duration-ts)/fade,0,1)
        recorded=Audio(recorded.data*gate,ctx.sr)
{syn}
    if ARCH=='bow':
        model=synth.bow(ctx.freq,{dur},ctx.sr,body='string',pressure=.36+.12*dyn,bright=.3+.27*dyn,attack=.3,release=.7,seed=ctx.seed,amp=.30)
        if {item['role']!r}=='pad':
            mdata=model.data; tm=np.arange(len(mdata))/ctx.sr; model=Audio(mdata*np.clip((3.0-tm)/1.25,0,1),ctx.sr)
        out=recorded.gain_db(-2).mix(model,synthetic,source_body,gains_db=[-9,-24,-3])
    elif ARCH=='reed':
        shaped=synth.formant(recorded, vowel=[(0,'o'),(2.2,'a'),(5.0,'o')] if {item['role']!r}=='pad' else 'a',amount=.35)
        model=synth.additive(ctx.freq,[(1,.5,0),(2,.20,0),(3.01,.13,4.0),(4.0,.08,2.4),(5.98,.04,1.7)],{dur},ctx.sr,amp=.25,seed=ctx.seed)
        if {item['role']!r}=='pad':
            mdata=model.data; tm=np.arange(len(mdata))/ctx.sr; model=Audio(mdata*np.clip((3.0-tm)/1.25,0,1),ctx.sr)
        out=shaped.gain_db(-2).mix(model,synthetic,source_body,gains_db=[-8,-24,-3])
    elif ARCH in ('plucked','picklead','pizzlead'):
        # Recorded pick/bow grain sets the onset; a separate pluck model gives a tuned, evolving body.
        model=synth.karplus(ctx.freq,{dur},bright=.32+.35*dyn,damping=.34,pick_position=.19 if ARCH!='pizzlead' else .24,sr=ctx.sr,seed=ctx.seed,decay=6.2 if {item['role']!r}=='pad' else 2.1,velocity=.3+.65*dyn,amp=.34)
        if {item['role']!r}=='pad':
            mdata=model.data; tm=np.arange(len(mdata))/ctx.sr; model=Audio(mdata*np.clip((3.0-tm)/1.25,0,1),ctx.sr)
        out=recorded.gain_db(-1).mix(model,synthetic,source_body,gains_db=[-8,-24,-3])
    elif ARCH in ('modal','malletlead'):
        # Full marimba strike is the exciter for a new, keyed modal body (no chordal sample).
        modes=[(1,3.6,.52),(2.76,2.8,.23),(4.12,2.3,.15),(5.43,1.7,.09),(6.9,1.4,.06)]
        model=synth.modal(ctx.freq,modes=modes,dur={dur},sr=ctx.sr,exciter_audio=recorded,hardness=.34+.48*dyn,amp=.50,seed=ctx.seed)
        if {item['role']!r}=='pad':
            mdata=model.data; tm=np.arange(len(mdata))/ctx.sr; model=Audio(mdata*np.clip((.72-tm)/.45,0,1),ctx.sr)
        if ARCH=='malletlead':
            # Keep the recorded mallet gesture audible; synthesis only fills
            # the keyed tail instead of replacing the source with five tones.
            out=recorded.gain_db(-1).mix(synthetic,gains_db=[-24])
        else:
            # Audio.mix gains apply only to the added layers, not `model`.
            # Keep the source-derived body foremost in the long pad.
            out=model.gain_db(-8).mix(synthetic,source_body,gains_db=[-24,-3])
    elif ARCH=='reedlead':
        shaped=synth.formant(recorded,vowel='a',amount=.28)
        out=shaped.gain_db(-1).mix(synthetic.gain_db(-12),gains_db=[-3])
    else:
        out=recorded.gain_db(-1).mix(synthetic.gain_db(-11),gains_db=[-3])
    out=out.fit({dur}).fade_in({item['attack']}).fade_out({0.0 if item['role']=='pad' else .08}).remove_dc()
    tilt=(dyn-.55)*({32.0 if item['family']=='marimba' and item['role']=='pad' else 16.0})
    out=out.mix(out.highpass(1600,order=2,zero_phase=False),gains_db=[tilt]).lowpass(16500,order=2).highpass(55,order=2)
    # Take down root loudness before compiler safety limiting; forte 4-note pad chord has headroom.
    target_lufs={item['bodydb']}-3.0+8.0*(dyn-.15)
    return out.normalize_loudness(target_lufs,ceiling_db=-9).remove_dc()

{('@sound.attack(pitched=True)\ndef attack(ctx):\n    key=min(SOURCE,key=lambda k:abs(int(k)-ctx.note)); di=0 if ctx.dyn<.34 else (1 if ctx.dyn<.76 else 2)\n    choices=SOURCE[key][str(di)]; info=choices[ctx.take%len(choices)]\n    a=ctx.load(info[\'file\']).pitch(ctx.note-int(info[\'src_midi\']),preserve_duration=True).to_mono()\n    return a.trim(0,.22).highpass(150,order=2).fade_out(.18).normalize_loudness(-22,ceiling_db=-8)\n' if item['arch'] in ('malletlead','modal') else '')}
sound.performance(dyn_crossfade=0)
sound.defaults(mode='Poli',glide=0,amp_attack={int(item['attack']*1000)},amp_decay=900,amp_sustain={.94 if item['role']=='pad' else .82},amp_release={int(item['release']*1000)},rev_mode='Cappella',rev_size=.3,rev_decay=1.25,rev_predelay=7,rev_damp=.68,rev_mix={.07 if item['role']=='pad' else .045},lvl_attack=-12,lvl_air=-36,tape_wow=0,tape_flutter=0,tape_sat=.025,drive=.015,width=1.0,master=-3)
'''
    return layer

def main():
    do_compile='--compile' in sys.argv
    reports=BANK/'_reports'; reports.mkdir(parents=True,exist_ok=True)
    retired=LIB.parent/'Libero-backups'/'2026-10-03'/'aria-retired-v1'; retired.mkdir(parents=True,exist_ok=True)
    # Move the previous eight voices into an ignored report subfolder; parent backup remains untouched.
    old={'ferro-angelico','fiato-rosso','corno-di-vetro','ferrite-luce','ferro-corto','squid-jab','ottone-pugno','vetro-taglio'}
    for slug in old:
        src=BANK/slug
        if src.exists():
            dst=retired/slug
            if dst.exists(): shutil.rmtree(dst)
            shutil.move(str(src),str(dst))
    old_meta=json.loads((BANK/'bank.json').read_text())
    for item in SOUNDS:
        folder=BANK/item['slug']
        if folder.exists(): shutil.rmtree(folder)
        (folder/'samples').mkdir(parents=True)
        roots=ROOTS_PAD if item['role']=='pad' else ROOTS_LEAD
        maps=get_source_map(item,roots,folder)
        (folder/'sound.py').write_text(recipe(item,roots,maps))
        source_names=sorted({v['name'] for d in maps.values() for choices in d.values() for v in choices})
        pitch_note={'sax':'Weresax: la nota che suona è un’ottava sopra l’etichetta del file; la mappa applica la correzione dopo la verifica spettrale della sorgente.','marimba':'VCSL Outrigger: la nota che suona è un’ottava sopra l’etichetta del file; la mappa applica la correzione dopo la verifica spettrale della sorgente.'}.get(item['family'],'')
        pitch_note={'sax':'Weresax: la fondamentale registrata suona un’ottava sopra l’etichetta del file; la mappa applica +12 semitoni, verificati sullo spettro.','marimba':'VCSL Outrigger: la fondamentale registrata suona un’ottava sopra l’etichetta del file; la mappa applica +12 semitoni, verificati sullo spettro.'}.get(item['family'],'')
        if item['family']=='sax':
            variation_note='La libreria offre due dinamiche registrate: p sul livello morbido e f sui livelli medio e forte; il terzo livello usa bilanciamento/colore ibrido. cnd e dnm sono due microfoni della stessa esecuzione, alternati come prospettive, non round robin indipendenti.'
        elif item['family']=='marimba':
            variation_note='È disponibile una sola presa per nota e dinamica; non sono dichiarati round robin. Il colpo registrato alimenta l’attacco, mentre il corpo del pad deriva dallo spettro misurato della stessa sorgente.'
        else:
            variation_note='Le prese alternate restano legate alle varianti realmente presenti nei file sorgente; pitch e forza sono selezionati dalla mappa originale, senza round robin sintetici.'
        role_note=('Nel pad, l’attacco conserva il gesto registrato e il sostegno source-derived percorre un arco di 12 s senza riavviare il ciclo.' if item['role']=='pad' else 'Nel lead, il campione conserva il transiente e una coda sintetica intonata rende la nota sostenibile per frasi melodiche brevi.')
        (folder/'notes.md').write_text(f"# {item['title']}\n\n{item['desc']}\n\nRegistrazione di partenza: {item['family']} ({', '.join(source_names)}). Il testo distingue sempre lo strumento registrato dal design ibrido. {pitch_note} {variation_note} {role_note}\n\n## Design\n\n{item['arch']}: materiale CC0 trasformato per intonazione e bilanciato con sintesi originale sensibile alla dinamica. Polifonico, glide 0, wow/flutter 0; riverbero leggero lasciato al preset. I pad hanno un corpo offline continuo di 14,2 s, senza cucitura di loop imposta.\n")
        (folder/'figure.svg').write_text(figure_svg(item))
    old_meta.update({'title':'Aria','subtitle':'voci ibride dense per pad e melodie','description':'Otto voci ibride con gesti registrati e sintesi originale: quattro pad caldi e quattro melodie/stab, da quattro famiglie di sorgenti CC0, senza wow o flutter.','version':'2.0.0','updated':datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')})
    (BANK/'bank.json').write_text(json.dumps(old_meta,indent=2,ensure_ascii=False)+'\n')
    # Provenance is per sound; include license copies and exact sample filename map in source note.
    from libero.licenses import add_credit, attribution_text, read_credits
    CREDIT={
      'arco':('Karoryfer Smolken Rubner Bass','D. Smolken','https://github.com/sfzinstruments/karoryfer.smolken'),
      'pizz':('Karoryfer Smolken Rubner Bass','D. Smolken','https://github.com/sfzinstruments/karoryfer.smolken'),
      'sax':('Karoryfer Weresax','Karoryfer Lecolds','https://github.com/sfzinstruments/karoryfer.weresax'),
      'guitar':('Karoryfer Emily the Strange Guitar','Karoryfer Lecolds','https://github.com/sfzinstruments/karoryfer.emilyguitar'),
      'marimba':('Versilian Community Sample Library: Outrigger Marimba','Versilian Studios / Sam Gossner','https://github.com/sgossner/VCSL'),
    }
    for item in SOUNDS:
        folder=BANK/item['slug']; name,author,url=CREDIT[item['family']]
        add_credit(folder,{'source':name,'license':'CC0 1.0','license_class':'cc0','author':author,'url':url,'retrieved':datetime.now(timezone.utc).strftime('%Y-%m-%d')})
        (folder/'samples'/'ATTRIBUTION.md').write_text(attribution_text(read_credits(folder)))
    if do_compile:
        subprocess.run([str(PY/'.venv'/'bin'/'python'),str(ROOT/'python/scripts/build_aria_v2_qa.py')],check=True)
    print(f"Built {len(SOUNDS)} Aria v2 voices under {BANK}; license refresh is left to the bank integrator.")
if __name__=='__main__': main()
