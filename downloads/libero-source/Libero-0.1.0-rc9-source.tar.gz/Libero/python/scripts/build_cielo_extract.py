"""Extract the three natural notes of each VocalSet long-tone vocalise.
Keep all source dynamics and all 20 singers; no looping or voice cloning.
"""
from pathlib import Path
import json, math, concurrent.futures
import numpy as np
from scipy import signal
from libero import load, dsp
ROOT=Path.home()/'Libero/cache/research/cielo'
DEST=ROOT/'vocalset-notes'

def extract(path):
    audio=load(path); sr=audio.sr;x=audio.data
    if x.ndim==2:x=x.mean(axis=1)
    # Pitch-aware segmentation is essential: room noise bridges nominal silences
    # in some files, whose three register notes must never become one sample.
    track_sr=12000;track=dsp.resample_to(x,sr,track_sr)
    times,f0,aper,rms=dsp.yin(track,track_sr,fmin=60,fmax=1500,frame=1024,hop=120,threshold=.05)
    labels=np.zeros(len(times),dtype=int)
    voiced=np.isfinite(f0)&(aper<.26)&(rms>max(rms.max()*.025,1e-5))
    midi=69+12*np.log2(f0[voiced]/440)
    # The documented long-tone task has low, middle and high register notes.
    # Clustering their voiced pitch avoids splitting wide vibrato at semitone bins.
    centers=np.percentile(midi,[10,50,90])
    for _ in range(30):
        classes=np.abs(midi[:,None]-centers[None,:]).argmin(axis=1)
        new=np.array([np.median(midi[classes==i]) if np.any(classes==i) else centers[i] for i in range(3)])
        if np.max(abs(new-centers))<.001:break
        centers=new
    # Merge centers inside one sung note (if an unusable low note left only two
    # voiced registers). This also prevents soft vibrato from becoming fake takes.
    unique=[]
    for c in sorted(centers):
        if not unique or c-unique[-1]>3:unique.append(c)
        else:unique[-1]=(unique[-1]+c)/2
    centers=np.array(unique);classes=np.abs(midi[:,None]-centers[None,:]).argmin(axis=1)
    labels[voiced]=classes+1
    # Fill brief tracker gaps only when both edges agree; preserve real breaths.
    for start in np.flatnonzero(np.diff(np.r_[1,labels==0,0])==1):
        end=start
        while end<len(labels) and labels[end]==0:end+=1
        if start>0 and end<len(labels) and end-start<25 and labels[start-1]==labels[end]:labels[start:end]=labels[end]
    labels=signal.medfilt(labels,11)
    edges=np.flatnonzero(np.diff(np.r_[-1,labels,-1])!=0)
    segments=[]
    for start,end in zip(edges[:-1],edges[1:]):
        if labels[start]==0 or end-start<45:continue
        s=max(0,int((times[start]-.075)*sr));e=min(len(x),int((times[end-1]+.075)*sr))
        if segments and labels[start]==segments[-1][2] and (s-segments[-1][1])/sr<.45:
            old=segments.pop();segments.append((old[0],e,labels[start]))
        else:segments.append((s,e,labels[start]))
    segments=[(s,e,float(centers[label-1])) for s,e,label in segments]
    # Retain the whole stable natural note, its attack and a room release.
    records=[]
    for i,(s,e,center) in enumerate(segments):
        s=max(0,s-int(.02*sr));e=min(len(x),e+int(.18*sr))
        if i+1<len(segments):e=min(e,max(s+int(.5*sr),segments[i+1][0]-int(.035*sr)))
        if i>0:s=max(s,segments[i-1][1]+int(.01*sr))
        if e-s<int(.45*sr):continue
        rel=path.relative_to(ROOT/'vocalset')
        # Source spectrogram QA: these original takes contain an extra off-note
        # attack or a contiguous next-register entrance. Preserve the intended
        # stable note, never let a held sample silently become another key.
        repairs={
            'male3/long_tones/messa/m3_long_messa_a.wav':(59,.95,0),
            'male3/long_tones/pp/m3_long_pp_a.wav':(59,.78,0),
            'male7/long_tones/straight/m7_long_straight_e.wav':(60,0,.65),
        }
        repair=repairs.get(str(rel))
        if repair and abs(center-repair[0])<2:
            s+=int(repair[1]*sr);e-=int(repair[2]*sr)
        if e-s<int(.45*sr):continue
        a=audio.trim(s/sr,e/sr)
        body=a.trim(min(.35,a.duration/5),max(.4,a.duration-.35))
        anchor=dsp.midi_to_freq(center)
        f,voiced_fraction=dsp.estimate_f0(body.data,sr,anchor*.85,anchor*1.18)
        if np.isfinite(f):f=dsp.refine_f0(body.data,sr,f)
        if not np.isfinite(f):continue
        midi=round(dsp.freq_to_midi(f));cents=100*(dsp.freq_to_midi(f)-midi)
        # Use one constant cents correction. Natural vibrato stays intact.
        a=a.pitch(-cents/100).highpass(15).fade_in(.003).fade_out(.035)
        rel=path.relative_to(ROOT/'vocalset');singer=rel.parts[0];dynamic=rel.parts[-2];vowel=path.stem.split('_')[-1]
        file=DEST/singer/dynamic/f'{path.stem}-{i}-{midi}.wav';file.parent.mkdir(parents=True,exist_ok=True);a.save(file,subtype='PCM_24')
        records.append({'file':str(file),'source':str(rel),'singer':singer,'gender':'female' if singer.startswith('female') else 'male','dynamic':dynamic,'vowel':vowel,'root':midi,'seconds':a.duration,'source_seconds':[round(s/sr,3),round(e/sr,3)],'source_cents':round(cents,3),'lufs':round(dsp.momentary_max(a.data,sr),3),'peak_db':round(a.peak_db,3)})
    return records

if __name__=='__main__':
    files=sorted(p for p in (ROOT/'vocalset').rglob('*.wav') if '/long_tones/' in str(p))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        records=sum(list(ex.map(extract,files)),[])
    (ROOT/'vocalset-notes.json').write_text(json.dumps(records,indent=2))
    print('files',len(files),'natural segments',len(records),'singers',sorted({r['singer'] for r in records}),flush=True)
    for gender in ['female','male']:
        rr=[r for r in records if r['gender']==gender];print(gender,min(r['root'] for r in rr),max(r['root'] for r in rr),len(rr),flush=True)
