"""Source-led archtop: genuine pickup/mic takes, natural releases and held variant."""
from pathlib import Path
import sys, json, shutil, re, math, urllib.request
from hashlib import sha256
from collections import Counter
import numpy as np
import soundfile as sf
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, render, library, dsp
from libero.compiler import compile_sound
from libero.ingest.sfz import parse_sfz
from libero.lint import lint_bundle
from build_aria_mechanical import derive_source_body
from build_blue_expansion_v6 import identity_pitch, figure
from calibrate_blue_v6_body import estimate
SRC=Path.home()/'Libero/cache/libraries/karoryfer-shinyguitar/Shinyguitar'
DEST=Path.home()/'Libero/banks/bebop/bebop-chitarra'
OUT=Path.home()/'Libero/demo/bebop-v1/guitar'
def digest(p):return sha256(p.read_bytes()).hexdigest()
def build():
 OUT.mkdir(parents=True,exist_ok=True); samples=DEST/'samples';samples.mkdir(parents=True,exist_ok=True)
 # Preserve complete source sample data and SFZs; mapping includes single performers,
 # never the upstream three/five delayed-voice presets.
 shutil.copytree(SRC,samples/'originals',dirs_exist_ok=True,ignore=shutil.ignore_patterns('GUI','*.bank.xml'))
 docs=samples/'source-reference';docs.mkdir(exist_ok=True)
 for page,url in [('grant','https://shop.karoryfer.com/pages/free-samples'),('instrument','https://shop.karoryfer.com/pages/free-shinyguitar')]:
  urllib.request.urlretrieve(url,docs/f'{page}.html')
 body=[];tail=[];proof=[]; counts={}
 for capture,cc in [('electric',0),('acoustic',127)]:
  wrapper=OUT/f'{capture}-source.sfz'
  wrapper.write_text(f'<control> default_path={SRC}/Samples/ set_cc100={cc} set_cc106=127 set_cc107=0\n#include "{SRC}/Programs/{capture}_one.sfz"\n#include "{SRC}/Programs/{capture}_release.sfz"\n#include "{SRC}/Programs/{capture}_noises.sfz"\n')
  inst=parse_sfz(wrapper); counts[capture]={'regions':len(inst.regions),'warnings':inst.warnings,'unsupported':sorted(inst.unsupported)}
  if inst.warnings:raise RuntimeError(inst.warnings)
  for i,r in enumerate(inst.regions):
   src=r.sample;rel=src.relative_to(SRC); raw='originals/'+rel.as_posix()
   match=re.search(r'_rr(\d+)',src.name);take=int(match.group(1))-1 if match else r.seq_position-1
   row={'file':raw,'root':r.root,'lo':r.lokey,'hi':r.hikey,'vel':[r.lovel,r.hivel],'take':take,'tune_cents':r.tune_cents,'gain_db':r.gain_db}
   pr={'source_file':str(src),'file':raw,'source_sha256':digest(src),'capture':capture,'root':r.root,'key_range':[r.lokey,r.hikey],'velocity':row['vel'],'take':take,'trigger':r.trigger,'sfz_opcodes':r.opcodes}
   if r.trigger=='release':
    row.update(articulation=capture,rt_decay=r.rt_decay or 7,rt_min_db=-55);tail.append(row)
    natural=dict(row,articulation=capture+'-colpo');tail.append(natural)
   elif '_vl' in src.name:
    # Preserve a longer initial gesture than mallets. Continue only this
    # take's fitted partials, without an independent oscillator/noise layer.
    derived=samples/'derived'/capture/(src.stem+'-hold.flac')
    if not derived.exists():lp,metrics=derive_source_body(src,derived,r.root,period=8,transition_end=.65)
    else:
     # Deterministic source onset and stored loop proof are reused below.
     old=next((p for p in json.loads((samples/'source-proof.json').read_text()) if p.get('source_file')==str(src) and p.get('loop')),None) if (samples/'source-proof.json').exists() else None
     if old:lp=old['loop'];metrics=old['continuation']
     else:lp,metrics=derive_source_body(src,derived,r.root,period=8,transition_end=.65)
    stable,sr=sf.read(derived,start=48000,frames=48000,always_2d=True)
    _,deviation=estimate(stable,sr,440*2**((r.root-69)/12));corr=-deviation
    if abs(corr)>100:raise RuntimeError(f'Wrong source register {src} {corr}')
    row.update(file=derived.relative_to(samples).as_posix(),loop=lp,articulation=capture,tune_cents=corr)
    body.append(row)
    natural,sr=sf.read(src,always_2d=True);segment=natural[round(.15*sr):round(.65*sr)]
    _,deviation=estimate(segment,sr,440*2**((r.root-69)/12));natural_corr=-deviation
    if abs(natural_corr)>100:raise RuntimeError(f'Natural source register invalid {src} {natural_corr}')
    body.append(dict(row,file=raw,loop=None,one_shot=True,articulation=capture+'-colpo',tune_cents=natural_corr))
    pr.update(derived_file=row['file'],derived_sha256=digest(derived),loop=lp,continuation=metrics,applied_tune_cents=corr,natural_tune_cents=natural_corr,tuning_method='Stable source-derived body 1–2s; natural performed body .15–.65s; strong partial fallback; bounded +/-100 cents')
   else:
    row.update(articulation=capture+'-gesti',pitched=False,one_shot=True);body.append(row)
   proof.append(pr)
 # Recorded level ladders may cross slightly. Use first actual RR for the
 # lint ladder and equal additive corrections for every take of that layer.
 groups={}
 for r in body:
  if r.get('pitched') is False:continue
  groups.setdefault((r['articulation'],r['root'],r['lo'],r['hi']),{}).setdefault(tuple(r['vel']),[]).append(r)
 for axes in groups.values():
  previous=None
  for vel,rows in sorted(axes.items()):
   first=min(rows,key=lambda r:r['take']);x,sr=sf.read(samples/first['file'],always_2d=True,frames=72000)
   db=dsp.momentary_max(x,sr)+first['gain_db']
   target=db if previous is None else max(db,previous+.8)
   for r in rows:r['gain_db']+=target-db
   previous=target
 for row in body+tail:
  row['articulation']=row['articulation'].replace('-','_')
 (samples/'map.json').write_text(json.dumps({'body':body,'tail':tail},indent=2)+'\n')
 (samples/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 credit={'source':'Shinyguitar v1.002 · real archtop guitar','author':'D. Smolken / Karoryfer Lecolds','license':'CC0 1.0','license_class':'cc0','url':'https://shop.karoryfer.com/pages/free-shinyguitar','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','grant_url':'https://shop.karoryfer.com/pages/free-samples','download':'https://github.com/sfzinstruments/karoryfer.shinyguitar/releases/download/v1.002/Karoryfer.Shinyguitar.v1.002.zip','notes':'Current owner grant converts older free libraries to CC0. Complete original data retained. Pickup and microphone are selectable individual performances, not layered pseudo ensembles.'}
 (samples/'credits.json').write_text(json.dumps([credit],indent=2)+'\n')
 arts=[{'id':'electric','name':'Pickup · sostenuto'},{'id':'electric-colpo','name':'Pickup · naturale'},{'id':'acoustic','name':'Microfono · sostenuto'},{'id':'acoustic-colpo','name':'Microfono · naturale'},{'id':'electric-gesti','name':'Pickup · gesti'},{'id':'acoustic-gesti','name':'Microfono · gesti'}]
 for index,art in enumerate(arts):art['id']=art['id'].replace('-','_');art['key']=6+index
 roots=sorted({r['root'] for r in body if r.get('pitched') is not False})
 code=f'''import json
from pathlib import Path
from libero import Sound
m=json.loads((Path(__file__).parent/'samples/map.json').read_text())
sound=Sound(title='Archtop di mezzanotte',subtitle='Chitarra jazz registrata · pickup e microfono · quattro dinamiche e quattro riprese',tags=['bebop','jazz','sampled','guitar','plucked'],roots={roots!r},sample_rate=48000,accent='#ae8547')
sound.articulations({arts!r})
sound.multisample('body',m['body'],process={{'tune':'source','ladder':'keep','peak_db':-8,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'}})
sound.multisample('tail',m['tail'],as_dyn=False,process={{'tune':'source','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':0,'fade_ms':8,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'}})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,rr_reset_ms=1500,humanize={{'cents':0,'ms':0,'db':0}},onset_ms=0)
sound.defaults(mode='Poli',glide=0,voices=32,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=180,lvl_body=0,lvl_tail=-8,lvl_attack=-60,lvl_air=-60,vel_sens=.35,master=-1,flt_cutoff=5500,flt_env=0,rev_mix=.025,rev_mode='Cappella',rev_size=.2,rev_decay=.55,width=1,tape_wow=0,tape_flutter=0,tape_mix=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,caldi_mode='Spento')
'''
 (DEST/'sound.py').write_text(code)
 # Independent hand-drawn figure; no proprietary source GUI reused.
 svg=figure('nylon-blue').replace('Nylon guitar','Archtop guitar').replace('Corde di Cedro','Archtop di mezzanotte')
 (DEST/'figure.svg').write_text(svg)
 (DEST/'notes.md').write_text('Archtop reale di D. Smolken, Karoryfer Shinyguitar v1.002. Quattro dinamiche e quattro riprese per nota; pickup e microfono separati. Sostenuto: gesto registrato e continuazione periodica dei modi misurati della stessa ripresa; non si afferma che una corda acustica risuoni naturalmente per sempre. Naturale: decadimento originale, con rilasci registrati. Gesti: rumori realmente registrati, non intonati. Nessun ensemble artificiale, chorus o wow. Mappa e tutte le sorgenti originali incluse.\n')
 (DEST/'ATTRIBUTION.md').write_text('Shinyguitar, D. Smolken / Karoryfer Lecolds (2015, 2018), v1.002. CC0 1.0 per la concessione attuale del titolare: https://shop.karoryfer.com/pages/free-samples . Fonte: https://shop.karoryfer.com/pages/free-shinyguitar . Modifiche: mappatura Libero, calibrazione statica limitata, continuazione dei modi per la sola variante sostenuta. Originali e concessione conservati in samples/.\n')
 result=compile_sound(DEST,jobs=1);print(result.text(),flush=True)
 if not result.ok:raise RuntimeError(result.text())
 qa(counts)
def qa(counts):
 findings=lint_bundle(DEST/'build');c=Counter(f.level for f in findings)
 (DEST/'lint.txt').write_text('\n'.join(f.line() for f in findings)+'\n')
 report={'slug':'bebop-chitarra','source_mapping':counts,'lint_counts':dict(c),'lint':[f.line() for f in findings],'native':[],'source_fresh':library.source_hash(DEST)==json.loads((DEST/'build/manifest.json').read_text())['source_hash'],'errors':[]}
 if c['FAIL']:report['errors'].append('lint FAIL')
 for name,notes,params in [('phrase',[(40,0,.7,36),(40,1,.7,70),(40,2,.7,112),(52,3,.6,92),(55,3.66,.5,80),(59,4.33,.6,104),(64,5,.65,85)],{}),('dense',[(k,0,4,127) for k in [48,52,55,59,62,65,69,72]],{}),('natural',[(k,i*.65,.45,90) for i,k in enumerate([52,55,59,62,65,64,60,57])],{'articulation':1}),('microphone',[(52,0,2,92),(55,2.2,2,105)],{'articulation':2})]+[(f'hold-{k}',[(k,0,60,90)],{})for k in [40,60,81]]:
  if 'articulation' in params:params={'artic':params['articulation']}
  file=OUT/f'{name}.wav';render.render(DEST,file,notes,params,tail=1)
  x,sr=sf.read(file,always_2d=True);peak=20*np.log10(max(np.max(abs(x)),1e-15));rms=10*np.log10(np.mean(x*x)+1e-30)
  q={'name':name,'file':str(file),'peak_dbfs':float(peak),'rms_dbfs':float(rms),'clipped_samples':int(np.count_nonzero(abs(x)>=1))}
  if name.startswith('hold'):q['held_rms_dbfs']=float(10*np.log10(np.mean(x[10*sr:59*sr]**2)+1e-30))
  if name=='dense' and peak>-3:report['errors'].append('dense headroom')
  if q['clipped_samples']:report['errors'].append(name+' clipped')
  if q.get('held_rms_dbfs',0)<-50:report['errors'].append(name+' dropped')
  report['native'].append(q)
 pitch=[];manifest=json.loads((DEST/'build/manifest.json').read_text())
 for art in [0,2]:
  aid=manifest['articulations'][art]['id'];zones=[z for z in manifest['zones']if z['layer']=='body'and z.get('articulation')==aid]
  keys=sorted({k for z in zones for k in [z['root'],z['lo'],z['hi']] if 33<=k<=91})
  notes=[(k,i*2.2,2,v) for i,(k,v) in enumerate((k,v) for k in keys for v in [36,72,110])]
  file=OUT/f'pitch-art-{art}.wav';render.render(DEST,file,notes,{'artic':art,'rev_mix':0,'lvl_tail':-60},tail=.1);x,sr=sf.read(file,always_2d=True)
  for key,t,_,vel in notes:
   _,cents=estimate(x[round((t+1)*sr):round((t+1.9)*sr)],sr,440*2**((key-69)/12));pitch.append({'artic':art,'key':key,'velocity':vel,'cents':cents})
 pitch_report={'notes':pitch,'max_abs_cents':max(abs(r['cents'])for r in pitch),'failures':[r for r in pitch if abs(r['cents'])>10]}
 (OUT/'native-pitch-audit.json').write_text(json.dumps(pitch_report,indent=2)+'\n');report['native_pitch']=pitch_report
 if pitch_report['failures']:report['errors'].append('native mapping pitch')
 report['warn_interpretation']={
  'aliasing':'Original percussive guitar gestures contain captured high-frequency energy; unchanged originals retained, no synthetic high-frequency layer.',
  'ladder':'Recorded A2 microphone dynamics retain a genuine large contrast. All decreases calibrated with equal additive offsets for every RR of the affected layer.',
  'brightness':'Recorded high C6 soft/hard strokes have similar centroid; they are distinct genuine performances, not duplicate volume edits.',
  'tuning':'Short attack estimator sees pick transient/string stretching; stable source-derived body is separately calibrated and checked in native root/edge/interior renders.',
  'takes':'Periodic continuation fits independent real source takes; correlation of held harmonic bodies does not make their preserved physical attacks identical.',
  'loudness':'Source-relative levels and nonpitched hand gestures differ; native chord headroom is separately checked.'}
 (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');(DEST/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'lint':dict(c),'errors':report['errors'],'source_fresh':report['source_fresh']}),flush=True)
 if report['errors']:raise RuntimeError(report['errors'])
if __name__=='__main__':
 if '--qa' in sys.argv:qa({})
 else:build()
