"""Native carrier/harmonic-family pitch probe for Giove's twelve live synths."""
from pathlib import Path
import json,sys
import numpy as np
import soundfile as sf
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero import library,render
from build_giove_luna14 import SYNTHS
BANK=Path.home()/'Libero/banks/giove'
OUT=Path.home()/'Libero/demo/giove-v1/synth-carrier'
PARAMS={'amp_attack':0,'amp_release':8,'rev_mix':0,'echo_mix':0,'lfo_pitch':0,'lfo_cutoff':0}

def main():
    OUT.mkdir(parents=True,exist_ok=True);results=[]
    for spec in SYNTHS:
        slug=spec['slug'];p=BANK/slug;m=json.loads((p/'build/manifest.json').read_text())
        events=[(n,v) for n in range(36,85) for v in (60,116)]
        wav=OUT/f'{slug}-chromatic.wav'
        render.render(p,wav,[(n,i*3,2.6,v) for i,(n,v) in enumerate(events)],PARAMS,tail=.1,timeout=240)
        x,sr=sf.read(wav,always_2d=True);rows=[];errors=[]
        for i,(n,v) in enumerate(events):
            seg=x[round((i*3+.6)*sr):round((i*3+2.3)*sr)]
            # Power summed across channels avoids cancellation of wide unison.
            spectrum=np.sum(np.abs(np.fft.rfft(seg*np.hanning(len(seg))[:,None],n=262144,axis=0))**2,axis=1)
            frequencies=np.fft.rfftfreq(262144,1/sr);target=440*2**((n-69)/12);partials=[]
            for h in range(1,9):
                f=target*h
                if f>15000:continue
                band=(frequencies>=f*2**(-60/1200))&(frequencies<=f*2**(60/1200))
                power=float(spectrum[band].sum())
                level=10*np.log10(max(float(spectrum[band].max()),1e-30)/max(float(spectrum.max()),1e-30))
                if level < -45:continue
                centre=float(np.sum(frequencies[band]*spectrum[band])/max(power,1e-30))/h
                partials.append(dict(harmonic=h,centre_hz=centre,cents=float(1200*np.log2(centre/target)),relative_peak_db=float(level),power=power))
            centre=np.average([q['centre_hz'] for q in partials],weights=[q['power'] for q in partials]) if partials else None
            cents=float(1200*np.log2(centre/target)) if centre else None
            good=cents is not None and abs(cents)<=5
            if not good:errors.append(dict(key=n,velocity=v,cents=cents))
            rows.append(dict(key=n,velocity=v,cents=cents,partials=partials))
        fresh=library.source_hash(p)==m['source_hash']
        if not fresh:errors.append({'error':'source changed during probe'})
        result=dict(slug=slug,source_hash=m['source_hash'],fresh=fresh,status='PASS' if not errors else 'FAIL',events=len(events),
                    max_abs_cents=max((abs(r['cents']) for r in rows if r['cents'] is not None),default=None),errors=errors,measurements=rows)
        results.append(result);print(slug,result['status'],result['max_abs_cents'],errors[:3],flush=True)
    report=dict(status='PASS' if all(r['status']=='PASS' for r in results) else 'FAIL',
                method='Installed native renderer; every chromatic key 36–84 at two velocities, 98 events per synth. Independently indexed 0.6–2.3s steady windows. FFT power centres of carrier-family partials h1–h8, across both channels, with +/-60c search and -45dB relative peak floor. Authored sub-octave oscillators are intentional and not mistaken for wrong carrier pitch. Maximum 5c carrier-family centre. Source oscillator architectures establish which carrier family is intended; this does not assert the lowest frequency of the mixed patch is the played carrier.',
                probe_overrides=PARAMS,default_safety_report=str(OUT.parent/'default-safety/report.json'),presets=results)
    (OUT.parent/'synth-carrier-pitch.json').write_text(json.dumps(report,indent=2)+'\n')
    return report['status']!='PASS'

if __name__=='__main__':raise SystemExit(main())
