#!/usr/bin/env python3
"""Build three Blue acoustic instruments from their complete legal recordings."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
from libero import Audio, analysis, dsp
from libero.compiler import compile_sound
from libero.ingest.sfz import parse_sfz
from libero.lint import lint_bundle, _load
from libero.figure import validate_svg

HOME = Path.home()
BANK = HOME / "Libero" / "banks" / "blue"
DEMO = HOME / "Libero" / "demo" / "blue-organic"
DEMO.mkdir(parents=True, exist_ok=True)
ACCORDION = HOME / "Libero" / "cache" / "libraries" / "freepats-button-accordion"
GLASS = HOME / "Libero" / "cache" / "libraries" / "vcsl" / "Idiophones" / "Friction Idiophones" / "Wine Glasses"
GUITAR = HOME / "Libero" / "cache" / "libraries" / "karoryfer-emilyguitar"
SR = 48000

SPECS = {
    "mantice-blue": {
        "title": "Mantice Blu", "subtitle": "Fisarmonica a bottoni · Hohner · FreePats",
        "tags": ["blue", "accordion", "sampled", "acoustic"], "source": ACCORDION,
    },
    "vetro-blue": {
        "title": "Vetro Lungo", "subtitle": "Calici sfregati · due gesti reali · VCSL",
        "tags": ["blue", "glass", "friction", "sampled", "acoustic"], "source": GLASS,
    },
    "corde-blue": {
        "title": "Corde Cobalto", "subtitle": "Epiphone flatwound · 4 dinamiche · 3 ripetizioni",
        "tags": ["blue", "guitar", "flatwound", "sampled", "acoustic"], "source": GUITAR,
    },
}


def digest(path: Path) -> str:
    h = sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_source(src: Path, samples: Path) -> str:
    """Copy a complete original into this sound; the map points only to the copy."""
    rel = src.relative_to(SPECS[_active_slug]["source"])
    dest = samples / "originals" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists() or digest(dest) != digest(src):
        shutil.copy2(src, dest)
    return dest.relative_to(samples).as_posix()


def copy_source_documents(slug: str, samples: Path) -> None:
    if slug == "mantice-blue":
        docs = [ACCORDION / "LICENSE.txt", ACCORDION / "README.txt",
                ACCORDION / "PRESET Button Accordion HN tuned.sfz"]
        credit = {"source": "FreePats Button Accordion HN", "author": "Jeff Stauffer; FreePats",
                  "license": "CC0 1.0", "license_class": "cc0",
                  "url": "https://freepats.zenvoid.org/Organ/accordion.html",
                  "license_url": "https://creativecommons.org/publicdomain/zero/1.0/",
                  "notes": "Hohner button accordion recording. Source SFZ preserved in source-reference/ and its note, tune, release and loop maps are used.",
                  "retrieved": datetime.now(timezone.utc).date().isoformat()}
    elif slug == "vetro-blue":
        vcsl = HOME / "Libero" / "cache" / "libraries" / "vcsl"
        docs = [vcsl / "LICENSE", vcsl / "README.md"]
        credit = {"source": "Versilian Community Sample Library · Wine Glasses",
                  "author": "Versilian Studios LLC / VCSL contributors",
                  "license": "CC0 1.0", "license_class": "cc0",
                  "url": "https://github.com/sgossner/VCSL",
                  "license_url": "https://creativecommons.org/publicdomain/zero/1.0/",
                  "notes": "Raw VCSL rubbed wine-glass sustain and release recordings. Full library CC0 notice is included in source-reference/.",
                  "retrieved": datetime.now(timezone.utc).date().isoformat()}
    else:
        docs = [GUITAR / "LICENSE", GUITAR / "readme.txt", GUITAR / "emily_basic.sfz"]
        credit = {"source": "Karoryfer Emily the Strange Guitar", "author": "D. Smolken / Karoryfer Lecolds",
                  "license": "CC0 1.0", "license_class": "cc0",
                  "url": "https://github.com/sfzinstruments/karoryfer.emilyguitar",
                  "license_url": "https://creativecommons.org/publicdomain/zero/1.0/",
                  "notes": "Epiphone Emily the Strange flatwound DI. The basic SFZ, license and attribution are included in source-reference/.",
                  "retrieved": datetime.now(timezone.utc).date().isoformat()}
    root = samples / "source-reference"
    root.mkdir(parents=True, exist_ok=True)
    proof = []
    for src in docs:
        dest = root / src.name
        shutil.copy2(src, dest)
        proof.append({"file": dest.relative_to(samples).as_posix(), "source": str(src),
                      "bytes": dest.stat().st_size, "sha256": digest(dest)})
    (samples / "source-documents.json").write_text(json.dumps(proof, indent=2) + "\n")
    (samples / "credits.json").write_text(json.dumps([credit], indent=2, ensure_ascii=False) + "\n")


_active_slug = ""


def accordion_map(samples: Path) -> tuple[dict, dict]:
    sfz = ACCORDION / "PRESET Button Accordion HN tuned.sfz"
    inst = parse_sfz(sfz)
    if inst.warnings:
        raise RuntimeError(f"Accordion SFZ parse warnings: {inst.warnings}")
    body, tails, proof = [], [], []
    for r in inst.regions:
        f = copy_source(r.sample, samples)
        proof.append({"file": f, "source_file": str(r.sample), "sha256": digest(r.sample),
                      "trigger": r.trigger, "sfz_root": r.root, "sfz_key_range": [r.lokey, r.hikey],
                      "source_tune_cents": r.tune_cents, "sfz_offset": r.offset,
                      "loop_samples": [r.loop_start, r.loop_end] if r.loop_start and r.loop_end else None})
        item = {"file": f, "root": r.root, "lo": r.lokey, "hi": r.hikey,
                "tune_cents": r.tune_cents, "gain_db": r.gain_db,
                "offset": r.offset, "take": 0}
        if r.loop_mode in ("loop_continuous", "loop_sustain") and r.loop_start and r.loop_end:
            # Keep the sample-maker's loop location, but bake a short transition
            # from its end into the exact beginning so the native player can wrap
            # without an audible discontinuity. All source frames before the
            # loop end, including the original attack, remain present.
            audio = Audio.load(r.sample, sr=SR)
            scale = SR / sf.info(r.sample).samplerate
            # Re-evaluate the loop inside the source's established sustain
            # window. Some distributed SFZ loops are only ~110 ms and fail a
            # native seam check; the alternate loop stays in this very take,
            # starts after 300 ms, and retains at least 800 ms of reed motion.
            chosen = audio.loop_points(.8, region=(.30, audio.duration-.08),
                                      window=.03, max_crossfade=.35)
            if chosen is None:
                raise RuntimeError(f"Could not find a long source loop for {r.sample.name}")
            start, end = chosen.start, chosen.end
            looped = audio.bake_loop(chosen)
            loop_name = Path(f).stem + "-sfz-loop.wav"
            loop_file = samples / "derived" / loop_name
            loop_file.parent.mkdir(parents=True, exist_ok=True)
            sf.write(loop_file, looped.data, SR, subtype="PCM_24")
            item.update({"file": loop_file.relative_to(samples).as_posix(),
                         "offset": round(r.offset * scale),
                         "loop": {"start": start, "end": end}})
            proof[-1].update({"derived_file": item["file"], "derived_sha256": digest(loop_file),
                              "original_sfz_loop_samples": [r.loop_start, r.loop_end],
                              "loop_selection_error_db": chosen.error_db,
                              "baked_crossfade_ms": round(chosen.crossfade / SR * 1000, 2),
                              "loop_coordinates_48k": [start, end],
                              "loop_seconds": round((end-start)/SR, 4)})
        if r.trigger == "release":
            if r.rt_decay is not None:
                item["rt_decay"] = r.rt_decay
                item["rt_min_db"] = -54
            tails.append(item)
        else:
            body.append(item)
    if len(body) != 17 or len(tails) != 17:
        raise RuntimeError(f"Expected 17 accordion bodies/releases, got {len(body)}/{len(tails)}")
    (samples / "source-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
    return {"body": body, "tail": tails}, {"body": 17, "tail": 17, "dynamic_layers": 1, "takes": 1}


GLASS_NOTES = [
    ("glass1_D#4", 75, 28),
    ("glass2_F#4", 78, -11),
    ("glass3_A#4", 82, 55),
    ("glass4_D5", 86, 6),
]
GLASS_CORR = {"D#4": -28, "F#4": 11, "A#4": -55, "D5": -6}


def glass_map(samples: Path) -> tuple[dict, dict]:
    body, tails, proof = [], [], []
    roots = [n[1] for n in GLASS_NOTES]
    ranges = [(63, 76), (77, 80), (81, 84), (85, 94)]
    for art, folder in (("lento", "Slow"), ("rapido", "Fast")):
        for (stem, root, cents), (lo, hi) in zip(GLASS_NOTES, ranges):
            body_src = next(p for p in (GLASS / "Sustains" / folder).glob(f"{stem}_{folder}_*")
                            if p.name.lower().endswith("_main.wav"))
            rel_src = next(p for p in (GLASS / "Releases" / folder).glob(f"{stem}_{folder}_*")
                           if p.name.lower().endswith("_decay.wav"))
            original_body = copy_source(body_src, samples)
            t = copy_source(rel_src, samples)
            audio = Audio.load(body_src, sr=SR)
            chosen = audio.loop_points(8.0, region=(.30, audio.duration-.08),
                                      window=.05, max_crossfade=.25)
            if chosen is None:
                chosen = audio.loop_points(6.0, region=(.30, audio.duration-.08),
                                           window=.05, max_crossfade=.25)
            if chosen is None:
                raise RuntimeError(f"Could not derive long source loop for {body_src.name}")
            looped = audio.bake_loop(chosen)
            body_path = samples / "derived" / f"{art}-{body_src.stem}-loop.wav"
            body_path.parent.mkdir(parents=True, exist_ok=True)
            sf.write(body_path, looped.data, SR, subtype="PCM_24")
            b = body_path.relative_to(samples).as_posix()
            token = stem.rsplit("_", 1)[-1]
            tune = GLASS_CORR[token]
            body.append({"file": b, "root": root, "lo": lo, "hi": hi, "take": 0,
                         "tune_cents": tune, "articulation": art,
                         "loop": {"start": chosen.start, "end": chosen.end}})
            tails.append({"file": t, "root": root, "lo": lo, "hi": hi, "take": 0,
                          "tune_cents": tune, "rt_decay": 2.0, "rt_min_db": -48,
                          "articulation": art})
            proof.extend([
                {"file": original_body, "source_file": str(body_src), "sha256": digest(body_src),
                 "kind": "sustain", "articulation": art, "recorded_label": token,
                 "measured_root_midi": root, "source_pitch_deviation_cents": cents,
                 "applied_tune_cents": tune, "mapped_keys": [lo, hi], "sample_seconds": sf.info(body_src).duration,
                 "derived_file": b, "derived_sha256": digest(body_path),
                 "loop_selection_error_db": chosen.error_db,
                 "loop_crossfade_ms": round(chosen.crossfade / SR * 1000, 2),
                 "loop_samples_48k": [chosen.start, chosen.end],
                 "loop_seconds": round((chosen.end-chosen.start)/SR, 4)},
                {"file": t, "source_file": str(rel_src), "sha256": digest(rel_src),
                 "kind": "release", "articulation": art, "recorded_label": token,
                 "measured_root_midi": root, "source_pitch_deviation_cents": cents,
                 "applied_tune_cents": tune, "mapped_keys": [lo, hi], "sample_seconds": sf.info(rel_src).duration},
            ])
    if len(body) != 8 or len(tails) != 8:
        raise RuntimeError("Wine-glass articulation coverage incomplete")
    (samples / "source-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
    return {"body": body, "tail": tails}, {"body": 8, "tail": 8, "articulations": {"lento": 4, "rapido": 4}, "mapped_keys": [63, 94]}


def guitar_map(samples: Path) -> tuple[dict, dict]:
    inst = parse_sfz(GUITAR / "emily_basic.sfz")
    if inst.warnings:
        raise RuntimeError(f"Emily SFZ parse warnings: {inst.warnings}")
    body, tails, gestures, proof = [], [], [], []
    for r in inst.regions:
        rel = r.sample.relative_to(GUITAR)
        f = copy_source(r.sample, samples)
        m = re.search(r"_rr(\d+)\.wav$", r.sample.name, re.I)
        if not m:
            raise RuntimeError(f"Round robin index missing from SFZ sample {r.sample}")
        take = int(m.group(1)) - 1
        row = {"file": f, "root": r.root, "lo": r.lokey, "hi": r.hikey,
               "take": take, "tune_cents": r.tune_cents,
               "gain_db": r.gain_db, "offset": r.offset}
        if r.trigger == "release":
            row.update({"rt_decay": r.rt_decay if r.rt_decay is not None else 7.0,
                        "rt_min_db": -60, "articulation": "corde"})
            tails.append(row)
            kind = "release"
        elif rel.parts[0].lower() == "noises":
            # The original fingering gesture is intentionally much quieter
            # than the muted-string keys; +30 dB makes its one-shot playable
            # while it remains well below the other gesture keys.
            if r.root == 90:
                row["gain_db"] = 30.0
            row.update({"pitched": False, "one_shot": True,
                        "articulation": "gesti"})
            gestures.append(row)
            kind = "finger-noise-key"
        else:
            audio = Audio.load(r.sample, sr=SR)
            chosen = audio.loop_points(1.0, region=(.25, min(audio.duration-.06, 2.2)),
                                      window=.02, max_crossfade=.30)
            if chosen is None:
                raise RuntimeError(f"Could not find a source loop for {r.sample.name}")
            looped = audio.bake_loop(chosen)
            derived = samples / "derived" / f"{r.sample.stem}-loop.flac"
            derived.parent.mkdir(parents=True, exist_ok=True)
            sf.write(derived, looped.data, SR, format="FLAC", subtype="PCM_24")
            row["file"] = derived.relative_to(samples).as_posix()
            row["loop"] = {"start": chosen.start, "end": chosen.end}
            row["vel"] = [r.lovel, r.hivel]
            row["articulation"] = "corde"
            body.append(row)
            kind = "pitched-body"
        proof.append({"file": f, "source_file": str(r.sample), "sha256": digest(r.sample),
                      "kind": kind, "root": r.root, "keys": [r.lokey, r.hikey],
                      "velocity": [r.lovel, r.hivel], "take": take,
                      "tune_cents": r.tune_cents, "gain_db": r.gain_db,
                      "mapped_gain_db": row.get("gain_db", 0.0),
                      "release_attenuation_db_per_second": r.rt_decay,
                      **({"derived_file": row["file"], "derived_sha256": digest(samples / row["file"]),
                          "loop_selection_error_db": chosen.error_db,
                          "loop_crossfade_ms": round(chosen.crossfade / SR * 1000, 2),
                          "loop_samples_48k": [chosen.start, chosen.end],
                          "loop_seconds": round((chosen.end-chosen.start)/SR, 4)}
                         if kind == "pitched-body" else {})})
    expected = (216, 72, 35)
    actual = (len(body), len(tails), len(gestures))
    if actual != expected:
        raise RuntimeError(f"Emily coverage mismatch: expected {expected}, got {actual}")
    dyn_roots = Counter(x["root"] for x in body)
    if set(dyn_roots.values()) != {12} or len(dyn_roots) != 18:
        raise RuntimeError(f"Unexpected per-root guitar body coverage: {dyn_roots}")
    # Real recordings occasionally place a nominal f sample a little below mf
    # for one key. Apply level-only corrections from the first genuine RR so
    # velocity remains a sensible control; source spectra and all three takes
    # remain separate and untouched. A small margin prevents a down-step after
    # level calibration without forcing equal spacing between dynamics.
    by_layer = {}
    for row in body:
        by_layer.setdefault((row["root"], tuple(row["vel"])), []).append(row)
    corrections = {}
    previous_by_root = {}
    axis_rows = sorted(by_layer.items(), key=lambda item: (item[0][0], item[0][1][0]))
    for (root, vel), rows in axis_rows:
        rr1 = next(row for row in rows if row["take"] == 0)
        audio = Audio.load(samples / rr1["file"], sr=SR)
        measured = dsp.momentary_max(audio.data, SR) + rr1.get("gain_db", 0.0)
        previous = previous_by_root.get(root)
        corr = max(0.0, previous + .7 - measured) if previous is not None else 0.0
        if corr:
            for row in rows:
                row["gain_db"] = row.get("gain_db", 0.0) + corr
        previous_by_root[root] = measured + corr
        if corr > .05:
            corrections.setdefault(str(root), {})[f"vel_{vel[0]}_{vel[1]}"] = round(corr, 2)
            for proof_row in proof:
                if proof_row.get("derived_file") == rr1["file"]:
                    proof_row["velocity_level_correction_db"] = round(corr, 2)
    if corrections:
        for row in body:
            root_corrections = corrections.get(str(row["root"]), {})
            correction = root_corrections.get(f"vel_{row['vel'][0]}_{row['vel'][1]}")
            if correction is not None:
                for proof_row in proof:
                    if proof_row.get("derived_file") == row["file"]:
                        proof_row["velocity_level_correction_db"] = correction
                        proof_row["mapped_gain_db"] = row.get("gain_db", 0.0)
    (samples / "source-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
    return {"body": body, "tail": tails, "attack": gestures}, {
        "body": 216, "tail": 72, "noise_keys": 35,
        "velocity_layers": {"p": [1, 40], "mp": [41, 80], "mf": [81, 120], "f": [121, 127]},
        "measured_level_corrections_db": corrections,
        "round_robins": {"pitched": 3, "release": 4, "noise": 5},
        "keyswitch_noise_keys": [90, 96], "pitched_root_span": [37, 86]}


def sound_source(slug: str, dest: Path, spec: dict, info: dict) -> None:
    title, subtitle = spec["title"], spec["subtitle"]
    if slug == "mantice-blue":
        arts = ""
        maps = "mapping=json.loads((Path(__file__).parent/'samples/map.json').read_text())\nsound.multisample('body',mapping['body'],as_dyn=False,process={'tune':'source','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'})\nsound.multisample('tail',mapping['tail'],as_dyn=False,process={'tune':'source','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':0,'fade_ms':8,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={'cents':0,'ms':0,'db':0},rr_reset_ms=0,onset_ms=0)"
        defaults = "mode='Poli',glide=0,voices=24,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=140,lvl_body=0,lvl_tail=0,lvl_attack=-60,lvl_air=-60,vel_sens=.25,master=-1,tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix=.035,rev_decay=1.2,rev_size=.30,rev_damp=.50"
        artblock = ""
    elif slug == "vetro-blue":
        maps = "mapping=json.loads((Path(__file__).parent/'samples/map.json').read_text())\nsound.articulations([{'id':'lento','name':'Sfregamento lento','key':12},{'id':'rapido','name':'Sfregamento rapido','key':13}])\nsound.multisample('body',mapping['body'],as_dyn=False,process={'tune':'source','ladder':'keep','peak_db':-6,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'})\nsound.multisample('tail',mapping['tail'],as_dyn=False,process={'tune':'source','ladder':'keep','peak_db':-6,'align_ms':0,'pre_ms':0,'fade_ms':12,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={'cents':0,'ms':0,'db':0},rr_reset_ms=0,onset_ms=0)"
        defaults = "mode='Poli',glide=0,voices=20,artic=0,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=260,lvl_body=0,lvl_tail=0,lvl_attack=-60,lvl_air=-60,vel_sens=.30,master=-1,tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix=.04,rev_decay=1.25,rev_size=.32,rev_damp=.5"
    else:
        maps = "mapping=json.loads((Path(__file__).parent/'samples/map.json').read_text())\nsound.articulations([{'id':'corde','name':'Corde','key':12},{'id':'gesti','name':'Gesti di dita','key':13}])\nsound.multisample('body',mapping['body'],as_dyn=True,process={'tune':'source','ladder':'keep','peak_db':-8,'align_ms':0,'pre_ms':2,'fade_ms':0,'loop':'source','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'})\nsound.multisample('tail',mapping['tail'],as_dyn=False,process={'tune':'source','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':2,'fade_ms':15,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'link_gain':True,'encoding':'flac24'})\nsound.multisample('attack',mapping['attack'],as_dyn=False,process={'tune':'none','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':1,'fade_ms':10,'loop':'none','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={'cents':0,'ms':0,'db':0},rr_reset_ms=0,onset_ms=2,one_shot=False)"
        defaults = "mode='Poli',glide=0,voices=24,artic=0,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=110,lvl_body=0,lvl_tail=0,lvl_attack=-3,lvl_air=-60,vel_sens=.45,master=-1,tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix=.025,rev_decay=1.1,rev_size=.28,rev_damp=.55"
    code = f'''"""Recorded {title}; all source layers, release gestures and RR are preserved."""
import json
from pathlib import Path
from libero import Sound
sound=Sound(title={title!r},subtitle={subtitle!r},tags={spec['tags']!r},roots={sorted(set(r['root'] for r in info['body']))!r},sample_rate=48000)
{maps}
sound.defaults({defaults})
'''
    (dest / "sound.py").write_text(code)
    (dest / "samples" / "map.json").write_text(json.dumps(info, indent=2) + "\n")


def figure(slug: str) -> str:
    root = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{}</title><desc>{}</desc>'.format
    if slug == "mantice-blue":
        title = "Mantice Blu"
        desc = "Diciassette lamelle accordate corrispondono ai diciassette tasti campionati; le coppie di pieghe serrate descrivono il battimento del mantice nel loop originale. La lamella dorata indica la lingua che rende udibile il respiro d’aria."
        p = ['<path d="M92 148 L203 104 L310 130 L420 170 L420 341 L310 374 L203 352 L92 314 Z" stroke="currentColor" stroke-width="1.3"/>',
             '<path d="M113 158 L196 126 L196 343 M135 151 L135 330 M157 143 L157 337 M179 134 L179 345 M218 125 L218 355 M240 130 L240 362 M262 136 L262 367 M284 142 L284 370 M328 138 L328 367 M350 145 L350 360 M372 152 L372 353 M394 161 L394 347" stroke="currentColor" stroke-width=".8"/>',
             '<path d="M203 112 L310 138 L310 366 L203 346 Z" fill="#f3eee6" stroke="currentColor" stroke-width=".9"/>',
             '<path d="M218 151 L293 168 M218 164 L293 181 M218 177 L293 194 M218 190 L293 207 M218 203 L293 220 M218 216 L293 233 M218 229 L293 246 M218 242 L293 259 M218 255 L293 272 M218 268 L293 285 M218 281 L293 298 M218 294 L293 311 M218 307 L293 324" stroke="currentColor" stroke-width=".55"/>',
             '<path d="M241 178 L268 184 L268 198 L241 192 Z" fill="#b8924f" stroke="#b8924f" stroke-width="1.2"/>',
             '<path d="M84 121 L91 139 M94 117 L101 135 M104 113 L111 131 M114 109 L121 127 M124 105 L131 123 M408 367 L415 385 M390 374 L397 392 M372 380 L379 398 M354 386 L361 404" stroke="currentColor" stroke-width=".5"/>',
             '<path d="M87 98 Q252 42 427 118 M83 405 Q250 456 428 391" stroke="currentColor" stroke-width=".7"/>']
    elif slug == "vetro-blue":
        title = "Vetro Lungo"
        desc = "Quattro calici occupano i rapporti di altezza dei quattro tasti reali, con altezza ridotta di un’ottava nel registro Blue. I cerchi eccentrici descrivono i modi inarmonici del bordo; il tratto dorato segue la traiettoria del dito sfregante."
        p = ['<path d="M116 154 Q256 108 396 154 L372 292 Q360 361 256 390 Q152 361 140 292 Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.3"/>',
             '<ellipse cx="256" cy="155" rx="140" ry="34" stroke="currentColor" stroke-width=".9"/>',
             '<ellipse cx="256" cy="155" rx="119" ry="24" stroke="currentColor" stroke-width=".55"/>',
             '<path d="M148 186 Q187 218 220 235 M364 185 Q328 215 292 233 M163 258 Q201 280 221 307 M349 257 Q311 282 291 307 M188 330 Q223 348 244 369 M324 330 Q289 351 268 369" stroke="currentColor" stroke-width=".55"/>',
             '<path d="M183 147 Q205 136 226 147 Q241 155 249 174 M180 152 Q205 141 224 152 Q241 161 246 178" stroke="#b8924f" stroke-width="1.2"/>',
             '<path d="M167 175 Q256 201 345 175 M154 194 Q256 228 358 194 M147 215 Q256 252 365 215 M143 238 Q256 277 369 238" stroke="currentColor" stroke-width=".45"/>',
             '<path d="M245 389 L267 389 L277 422 L235 422 Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.0"/>',
             '<path d="M212 425 Q256 414 300 425 L309 439 Q256 429 203 439 Z" stroke="currentColor" stroke-width="1.2"/>']
    else:
        title = "Corde Cobalto"
        desc = "Sei corde tese riprendono l’accordatura della chitarra e le diverse lunghezze delle radici registrate; tre linee parallele per ogni corda indicano le tre vere ripetizioni. Il pletto dorato tocca la corda bassa, sopra la cassa a grana fitta delle flatwound."
        p = ['<path d="M98 304 Q105 257 147 239 Q180 224 209 246 Q235 266 256 256 Q280 246 306 233 Q350 212 387 245 Q422 279 408 332 Q393 386 334 393 Q293 398 256 371 Q225 348 193 378 Q151 415 112 378 Q88 354 98 304 Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.3"/>',
             '<path d="M128 298 Q142 268 170 263 Q190 262 207 281 Q228 305 256 293 Q285 281 310 265 Q345 248 371 274 Q392 296 383 326 Q373 356 340 361 Q302 365 274 340 Q257 325 239 336 Q211 355 189 372 Q160 393 135 367 Q116 347 128 298 Z" stroke="currentColor" stroke-width=".8"/>',
             '<path d="M87 201 L418 174 L424 222 L91 249 Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.0"/>',
             '<path d="M100 209 L413 184 M101 217 L414 192 M102 225 L415 200 M103 233 L416 208 M104 241 L417 216" stroke="currentColor" stroke-width=".65"/>',
             '<path d="M224 202 L264 199 L267 231 L227 235 Z" fill="#b8924f" stroke="#b8924f" stroke-width="1.2"/>',
             '<path d="M102 252 L111 285 M119 251 L128 276 M137 249 L145 268 M155 247 L163 265 M173 246 L181 269 M191 244 L199 280 M209 242 L217 296 M227 240 L235 300 M245 238 L253 302 M263 236 L271 299 M281 234 L289 290 M299 232 L307 278 M317 230 L325 267 M335 228 L343 257 M353 226 L361 250 M371 224 L379 248 M389 222 L397 250" stroke="currentColor" stroke-width=".45"/>',
             '<path d="M145 301 Q178 288 204 300 M149 311 Q178 300 202 311 M153 321 Q178 312 199 322" stroke="currentColor" stroke-width=".55"/>']
    svg = root(title, desc) + ''.join(p) + '</svg>'
    issues = validate_svg(svg)
    if issues:
        raise ValueError(f"Invalid figure for {slug}: {issues}")
    return svg


def notes(slug: str, info: dict) -> str:
    if slug == "mantice-blue":
        return f"""# Mantice Blu

Fisarmonica a bottoni Hohner, registrata da Jeff Stauffer nel novembre 2023 e distribuita da FreePats. REC, timbro di mantice dal morso dolce e dal battimento naturale delle lamelle; per accordi pieni e linee melodiche dal colore folk/cinematico.

## Mappa reale

17 note radice (MIDI 47–79), 17 corpi tenuti e 17 rilasci distinti. Il file sorgente `PRESET Button Accordion HN tuned.sfz` è la mappa di verità per radice, key range, tuning e offset: il campione che porta `B3` nel nome ha radice SFZ MIDI 47, conservata senza correzione d’ottava basata sul nome. Le dinamiche non sono state registrate come layer separati: la velocity controlla solo la risposta d’ampiezza, senza duplicati più brillanti inventati.

## Fonte e limiti

Jeff Stauffer / FreePats, CC0 1.0: https://freepats.zenvoid.org/Organ/accordion.html. Tutti i 34 sample originali offerti sono inclusi in `samples/originals/`; `source-proof.json` riporta SHA-256 e opcodes di ogni zona. I brevi punti loop forniti dallo SFZ non superavano la verifica di giunzione; il loop viene riselezionato nella stessa registrazione dopo 300 ms d’attacco, con durata minima 800 ms e raccordo di 300–350 ms. Ogni presa continua a usare il proprio suono di mantice originale. Gli effetti tape, wow e flutter restano a zero; la stanza live è appena accennata.

## QA

Copertura: {info}. Verifica renders nativi, loop per zona, rilasci, accordo a quattro note, mono e mappa estremi in `verification.json`. La lettura dei file, dei render e dello spettrogramma non sostituisce l’ascolto umano.
"""
    if slug == "vetro-blue":
        return f"""# Vetro Lungo

Calici di vino sfregati con il dito, registrati in VCSL. REC, due gesti reali selezionabili: `lento` e `rapido`. Le prese lente e rapide conservano la loro diversa velocità di innesco e movimento spettrale; una coda lunga in loop mantiene l’aria viva sul tasto tenuto. Il registro di progetto scende un’ottava sotto i calici reali per offrire un corpo più caldo negli accordi e nelle melodie Blue.

## Mappa reale

8 sustain e 8 release originali, 4 radici per ciascuna articolazione. I nomi di nota del VCSL sono un’ottava sotto la frequenza misurata: le radici di playback sorgente sono MIDI 75, 78, 82 e 86. Deviazioni di pitch misurate: +28, −11, +55 e +6 cent; applicata la compensazione inversa (−28, +11, −55, −6 cent) per centrare ciascun tasto, senza rimuovere il gesto di pitch nel campione. La zona di tasti MIDI 63–94 è assegnata a radici vicine, così C4 viene riprodotto un’ottava sotto la registrazione.

## Fonte e limiti

Versilian Community Sample Library, CC0: https://github.com/sgossner/VCSL (cartella Idiophones/Friction Idiophones/Wine Glasses). Tutti i 16 file originali sono inclusi in `samples/originals/`; hash, durate, radici e tuning sono in `source-proof.json`. Un loop esplicito di almeno 8 secondi viene scelto dentro ogni sustain originale e rifinito con un breve crossfade source-led; il campione non viene congelato o sostituito da oscillatori. Le riprese durano 11.7–25.4 s. Lo sfregamento e il rumore del contatto restano nella registrazione. Il livello di playback compensa le prese molto quiete della raccolta, mantenendo diversi i due gesti.

## QA

Copertura: {info}. Renders nativi tenuti, articolazioni, rilascio, accordo/mono e seam sono in `verification.json`. I calici restano naturalmente inarmonici; le misure descrivono le sorgenti e non certificano il gusto.
"""
    return f"""# Corde Cobalto

Chitarra elettrica Epiphone Emily the Strange a corde D’Addario Chromes flatwound da 11 gauge, registrata direttamente e suonata da D. Smolken. REC, linea calda con nota pizzicata e dita udibili, adatta a melodie sostenute e a figure ribattute.

## Mappa reale

216 body zone = 18 radici reali × 4 velocity registrate (p, mp, mf, f) × 3 round robin. 72 rilasci reali = 18 radici × 4 round robin. 35 gesti/rumori di dito originali sono preservati come one-shot non intonati su un’articolazione separata `gesti`, tasti MIDI 90–96; non vengono miscelati come hiss sotto le note. L’articolazione `corde` usa le 216 note e i relativi rilasci; ogni loop tiene almeno un secondo di contenuto della stessa presa entro i primi 2,2 s, e conserva intatto l’attacco che precede il loop. Nessun layer fra dinamiche viene fuso, nessun RR viene duplicato. Le differenze di livello delle quattro velocity sono quelle registrate; dove un tasto f è sotto mf ho applicato una piccola compensazione di gain senza alterare lo spettro: {info.get('measured_level_corrections_db', {})}. Il gesto `fingering1` è registrato circa 30 dB sotto gli altri tasti noise: il suo solo gain di regione è rialzato di 30 dB perché resti udibile come one-shot, senza entrare nel sustain. `source-proof.json` e `map.json` riportano la mappa SFZ completa e gli SHA-256.

## Fonte e limiti

Karoryfer Lecolds, Epiphone Emily the Strange, CC0: https://github.com/sfzinstruments/karoryfer.emilyguitar. Tutte le 323 registrazioni indicate da `emily_basic.sfz` sono incluse come originali. Le regioni originali includono curve di velocity non replicate (le quattro fasce reali e il volume relativo vengono preservati; le curve proprietarie `amp_velcurve_*` non sono supportate dal parser). Non è una chitarra acustica né una ripresa amplificatore microfonata: il DI conserva il carattere del pickup e delle flatwound. Nessun wow, chorus o saturazione baked.

## QA

Copertura: {info}. Render nativi 60 s, chord, mono, release, dinamiche, estremi e repeat notes sono descritti in `verification.json`. Il looping sostiene l’accordo dopo il decadimento registrato; non viene presentato come nota dal decadimento acustico naturale infinito. I limiti di pitch/range derivano dalle 18 radici registrate (MIDI 37–86).
"""


def build_one(slug: str) -> dict:
    global _active_slug
    _active_slug = slug
    dest = BANK / slug
    if dest.exists() and not (dest / "builder-owner.json").exists():
        raise RuntimeError(f"Refusing to overwrite non-owned sound folder: {dest}")
    if not dest.exists():
        dest.mkdir(parents=True)
    (dest / "samples").mkdir(exist_ok=True)
    (dest / "builder-owner.json").write_text(json.dumps({"builder": Path(__file__).name, "source": str(SPECS[slug]["source"])}, indent=2) + "\n")
    copy_source_documents(slug, dest / "samples")
    if slug == "mantice-blue":
        mapping, counts = accordion_map(dest / "samples")
    elif slug == "vetro-blue":
        mapping, counts = glass_map(dest / "samples")
    else:
        mapping, counts = guitar_map(dest / "samples")
    sound_source(slug, dest, SPECS[slug], mapping)
    (dest / "figure.svg").write_text(figure(slug))
    (dest / "notes.md").write_text(notes(slug, counts))
    result = compile_sound(dest, jobs=1)
    print(f"COMPILE {slug}: {result.text()}", flush=True)
    if not result.ok:
        raise RuntimeError(f"Compile failed for {slug}: {result.text()}")
    qa = verify_one(slug, dest, counts)
    return qa


def verify_one(slug: str, dest: Path, counts: dict) -> dict:
    bundle = dest / "build"
    manifest = json.loads((bundle / "manifest.json").read_text())
    findings = lint_bundle(bundle)
    lines = [f.line() for f in findings]
    (dest / "lint.txt").write_text("\n".join(lines) + "\n")
    levels = Counter(f.level for f in findings)
    renderer = str(HOME / ".local/bin/libero-render")
    if slug == "mantice-blue":
        mid = 60
        phrase = f"47:0:.8:45,60:.9:.8:76,72:1.8:1:110,60:3:1:100,60:3.12:1:100,60:3.24:1:100,79:4.2:1:112"
        chord = [55, 60, 64, 67]
    elif slug == "vetro-blue":
        mid = 63
        phrase = "12:0:.01:100,63:.05:1.8:70,66:2:2:85,70:4.1:2:102,74:6.2:1.2:112,63:7.6:1:96,63:7.75:1:96,63:7.9:1:96,94:9:1.4:108"
        chord = [60, 63, 67, 70]
    else:
        mid = 60
        phrase = "12:0:.01:100,40:.05:1:30,40:1.2:1:70,40:2.4:1:110,52:3.6:1:120,60:4.8:.9:82,60:4.92:.9:82,60:5.04:.9:82,86:6.2:.9:115,90:7.5:.4:100"
        chord = [52, 57, 60, 64]
    demos = {}
    if slug == "vetro-blue":
        demos["phrase-lento"] = (phrase, {"artic": 0})
        demos["phrase-rapido"] = (phrase.replace("12:0:.01:100", "13:0:.01:100"), {"artic": 1})
        helds = [("held-lento", "63", "artic=0"), ("held-rapido", "63", "artic=1"), ("held-high", "86", "artic=0")]
    elif slug == "corde-blue":
        demos["phrase"] = (phrase, {})
        demos["phrase-gesti"] = ("90:0:.25:100,91:.3:.25:100,92:.6:.25:100,93:.9:.25:100,94:1.2:.25:100,95:1.5:.25:100,96:1.8:.25:100", {"artic": 1})
        helds = [("held-low", "40", "artic=0"), ("held-mid", "60", "artic=0"), ("held-high", "86", "artic=0")]
    else:
        demos["phrase"] = (phrase, {})
        helds = [("held-low", "47", ""), ("held-mid", "60", ""), ("held-high", "79", "")]
    native = []
    for name, (notespec, params) in demos.items():
        out = bundle / f"{name}.wav"
        cmd = [renderer, "--sound", str(dest), "--out", str(out), "--notes", notespec, "--tail", "2"]
        if params:
            cmd.extend(["--params", json.dumps(params)])
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        arr, sr = sf.read(out, always_2d=True)
        native.append(render_stats(out, arr, sr, name))
        shutil.copy2(out, DEMO / f"{slug}-{name}.wav")
        shutil.copy2(out.with_suffix(".png"), DEMO / f"{slug}-{name}.png") if out.with_suffix(".png").exists() else None
        if name.startswith("phrase"):
            (DEMO / f"{slug}-{name}.png").write_bytes(analysis.spectrogram(Audio(arr, sr), title=f"{slug} · {name}"))
    for name, note, param in helds:
        out = bundle / f"{name}.wav"
        spec = f"{note}:0:60:100"
        cmd = [renderer, "--sound", str(dest), "--out", str(out), "--notes", spec, "--tail", "2"]
        if slug == "vetro-blue":
            cmd.extend(["--params", json.dumps({"artic": int(param.split("=")[1])})])
        elif slug == "corde-blue":
            cmd.extend(["--params", json.dumps({"artic": int(param.split("=")[1])})])
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        arr, sr = sf.read(out, always_2d=True)
        st = render_stats(out, arr, sr, name)
        mono = arr.mean(axis=1)
        blocks = arr[int(5*sr):int(55*sr)]
        rms = 20*np.log10(np.sqrt(np.mean(blocks**2))+1e-20)
        st["held_body_rms_dbfs_5_55s"] = round(float(rms), 2)
        st["held_mono_loss_db"] = round(float(10*np.log10(np.mean(mono**2)/(np.mean(arr**2)+1e-20)+1e-20)), 2)
        native.append(st)
        shutil.copy2(out, DEMO / f"{slug}-{name}-60s.wav")
    chord_out = bundle / "chord.wav"
    chord_spec = ",".join(f"{n}:0:4:100" for n in chord)
    cmd = [renderer, "--sound", str(dest), "--out", str(chord_out), "--notes", chord_spec, "--tail", "1"]
    if slug == "vetro-blue":
        cmd.extend(["--params", json.dumps({"artic": 0})])
    elif slug == "corde-blue":
        cmd.extend(["--params", json.dumps({"artic": 0})])
    subprocess.run(cmd, check=True, capture_output=True, text=True)
    arr, sr = sf.read(chord_out, always_2d=True)
    native.append(render_stats(chord_out, arr, sr, "four-note-chord"))
    shutil.copy2(chord_out, DEMO / f"{slug}-chord.wav")
    loops, seams = [], []
    for z in manifest.get("zones", []):
        if z.get("layer") != "body":
            continue
        data = _load(bundle, z, False)
        if z.get("loop") is not None:
            loops.append(z["loop"])
            seams.append(data.loop_seam_db)
    report = {"generated_utc": datetime.now(timezone.utc).isoformat(), "slug": slug,
              "source_file_counts": counts, "manifest_zone_counts": dict(Counter(z.get("layer") for z in manifest.get("zones", []))),
              "body_zone_count": sum(z.get("layer") == "body" for z in manifest.get("zones", [])),
              "body_loop_count": len(loops), "body_loop_seam_worst_db": max(seams) if seams else None,
              "body_loop_min_seconds": min((lp.get("end", 0)-lp.get("start", 0))/SR for lp in loops) if loops else None,
              "body_loop_max_seconds": max((lp.get("end", 0)-lp.get("start", 0))/SR for lp in loops) if loops else None,
              "lint_counts": {k: levels[k] for k in ("FAIL", "WARN", "INFO")},
              "lint": lines, "native_renders": native,
              "maximum_source_samples_per_sound": len(json.loads((dest / "samples/source-proof.json").read_text())),
              "listening_limit": "Native files, numeric analysis, and spectrograms were inspected; this environment cannot audition audio."}
    (dest / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    notes_file = dest / "notes.md"
    base = notes_file.read_text()
    guitar_warns = """WARN conservati: alcune sorgenti hanno le velocity f e mf con livelli vicini; la compensazione per-key in map.json corregge solo l’ordine di volume e lascia intatto il timbro registrato. Le due note con brightness piatta (E2, D6) conservano i layer reali, non vengono sostituite da copie EQ. Le differenze di onset e di tuning fra dinamiche/RR sono parte delle prese indipendenti, quindi align=0 e tune=source. Alcune coppie RR superano .98 di correlazione ma sono file originali distinti e restano tutte selezionabili. I salti tra note sono presi reali, senza normalizzazione per tasto. `fingering1` rimane molto più quieto dei gesti di corda anche dopo +30 dB ed è utilizzabile solo come gesto leggero.
"""
    notes_file.write_text(base + "\n## Verifica numerica\n\n```json\n" + json.dumps(report, indent=2) + "\n```\n\n" +
                          ("WARN: gli opcode `amp_velcurve_*` dello SFZ Karoryfer non hanno corrispondenti live; le quattro zone velocity originali sono conservate, ma non si replica la loro curva proprietaria.\n" + guitar_warns if slug == "corde-blue" else "") +
                          ("WARN: il lungo loop source-led rende periodico il movimento del calice soltanto dopo 8–18 s di gesto registrato; il corpo e le code originali rimangono conservati. Il salto di loudness fra calici è dovuto al diverso gesto/contatto registrato; non ho normalizzato le quattro note una per una.\n" if slug == "vetro-blue" else "") +
                          "\nIl report verifica integrità e comportamento tecnico, non la qualità percepita.\n")
    print(f"QA {slug}: {json.dumps(report, ensure_ascii=False)}", flush=True)
    if levels["FAIL"]:
        raise RuntimeError(f"Lint has {levels['FAIL']} FAIL findings for {slug}; inspect {dest/'lint.txt'}")
    if len(loops) != sum(z.get("layer") == "body" for z in manifest.get("zones", [])):
        raise RuntimeError(f"Some body zones lack an infinite hold loop for {slug}")
    if seams and max(seams) > -30:
        raise RuntimeError(f"Loop seam exceeds -30 dB for {slug}: {max(seams):.2f} dB")
    if any(x["peak_dbfs"] > -0.2 or x["clipped_samples"] > 0 for x in native):
        raise RuntimeError(f"Native render clips or exceeds safe headroom for {slug}")
    return report


def render_stats(path: Path, arr: np.ndarray, sr: int, name: str) -> dict:
    peak = float(np.max(np.abs(arr)))
    mono = arr.mean(axis=1)
    return {"name": name, "file": str(path), "seconds": round(len(arr)/sr, 2),
            "peak_dbfs": round(20*np.log10(peak+1e-20), 2),
            "clipped_samples": int(np.count_nonzero(np.abs(arr) >= 1)),
            "mono_loss_db": round(float(10*np.log10(np.mean(mono**2)/(np.mean(arr**2)+1e-20)+1e-20)), 2)}


def main() -> None:
    reports = []
    for slug in ("mantice-blue", "vetro-blue", "corde-blue"):
        reports.append(build_one(slug))
        (DEMO / "report.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(f"Report: {DEMO / 'report.json'}", flush=True)


if __name__ == "__main__":
    main()
