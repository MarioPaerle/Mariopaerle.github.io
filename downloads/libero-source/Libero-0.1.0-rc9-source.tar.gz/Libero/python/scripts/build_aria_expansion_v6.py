#!/usr/bin/env python3
"""Build six source-led Aria additions without touching approved programmes.

Sources are read from ~/Libero/cache/libraries. VCSL material is pinned to its
cached upstream tree; the builder records both upstream blob IDs and local SHA256.
Run with python/.venv/bin/python python/scripts/build_aria_expansion_v6.py.
"""
from __future__ import annotations
import hashlib, json, math, re, shutil, sys
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

import numpy as np
import soundfile as sf

ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, analysis, render, dsp
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero.library import home, sketches_dir

HOME=Path.home(); LIB=home(); BANK=LIB/'banks'/'aria'; CACHE=LIB/'cache'/'libraries'
VCSL=CACHE/'vcsl'; TINY=CACHE/'tinysol'; PHIL=CACHE/'philharmonia'
TREE=json.loads((HOME/'Libero/cache/research/cielo/vcsl-tree.json').read_text())
COMMIT=TREE['sha']; VCSL_ROWS={r['path']:r for r in TREE['tree'] if r['type']=='blob'}
SR=48000; DEMO=LIB/'demo'/'aria-v6'; DEMO.mkdir(parents=True,exist_ok=True)
PITCH={'C':0,'C#':1,'D':2,'D#':3,'E':4,'F':5,'F#':6,'G':7,'G#':8,'A':9,'A#':10,'B':11}

SOUNDS=[
 {'slug':'mandolino-dorato','title':'Mandolino dorato','subtitle':'corda metallica pizzicata · attacco e tremolo originali','kind':'philharmonia-pluck','source':PHIL/'audio'/'mandolin','accent':'#a87543'},
 {'slug':'oboe-respiro','title':'Oboe respiro','subtitle':'ancia doppia · pp, mf e ff registrati','kind':'tinysol-wind','source':TINY/'Winds'/'Oboe'/'ordinario','accent':'#a45d4b'},
 {'slug':'fagotto-ombra','title':'Fagotto ombra','subtitle':'ancia doppia grave · pp, mf e ff registrati','kind':'tinysol-wind','source':TINY/'Winds'/'Bassoon'/'ordinario','accent':'#8d624c'},
 {'slug':'flauto-barocco','title':'Flauto barocco','subtitle':'flauto dolce contralto · dritta, vibrata e staccata','kind':'vcsl-recorder','source':VCSL,'accent':'#8f7449'},
 {'slug':'gong-profondo','title':'Gong profondo','subtitle':'gong sospeso · colpi e raschiatura originali','kind':'vcsl-gong','source':VCSL,'accent':'#637d73'},
 {'slug':'dan-tranh-lunare','title':'Dan Tranh lunare','subtitle':'cetra vietnamita a ponticelli mobili · pizzicato, tremolo e glissando','kind':'vcsl-dan-tranh','source':VCSL,'accent':'#71836d'},
]

def sha256(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bake_performed_loop(audio, lp, overlap=.15, exact_tail=.02):
 """Keep the performance while joining with an exact source-phase tail.

 The smoothstep overlap ends exactly at the last complete loop window; the
 final 20 ms are copied from just before loop start, so pre-end and pre-start
 windows are identical and the loop-end→start value/slope stay contiguous.
"""
 y=audio.data.astype(np.float64).copy(); n=int(exact_tail*audio.sr)
 xf=min(int(overlap*audio.sr),lp.start,lp.end-lp.start)
 blend=max(0,xf-n)
 if blend>1:
  t=np.linspace(0,1,blend,endpoint=True); w=t*t*(3-2*t)
  src=y[lp.start-xf:lp.start-n]
  dst=y[lp.end-xf:lp.end-n]
  if y.ndim==2:w=w[:,None]
  y[lp.end-xf:lp.end-n]=dst*(1-w)+src*w
 if n>0:y[lp.end-n:lp.end]=y[lp.start-n:lp.start]
 return Audio(y[:lp.end],sr=audio.sr), xf

def window_seam_db(y,start,end,n):
 left=y[end-n:end].astype(float);right=y[start-n:start].astype(float)
 return 10*math.log10((float(np.sum((left-right)**2))+1e-30)/(float(np.sum(left**2)+np.sum(right**2))+1e-30))

def measured_audio_mode(audio,root,t0=.20,t1=.60):
 """Estimate the fundamental in a stable, note-constrained source window."""
 a=audio.to_mono().data.astype(float);x=a[int(t0*SR):int(t1*SR)]
 if len(x)<SR//8:return None
 expected=440*2**((root-69)/12);t,track,aper,rms=dsp.yin(x,SR,fmin=expected*.65,fmax=expected*1.35)
 voiced=np.isfinite(track)&(aper<.3)&(rms>max(float(rms.max())*10**(-30/20),1e-6))
 if not voiced.any():return None
 hz=float(np.median(track[voiced]));nfft=262144;s=np.abs(np.fft.rfft(x*np.hanning(len(x)),n=nfft));f=np.fft.rfftfreq(nfft,1/SR);parts=[]
 for h in (1,2,3):
  q=np.flatnonzero((f>=hz*h*.94)&(f<=hz*h*1.06))
  parts.append(float(f[q[np.argmax(s[q])]]) if len(q) else None)
 return {'window_seconds':[t0,t1],'expected_hz':expected,'measured_root_mode_hz':hz,
         'body_mode_error_cents':1200*math.log2(hz/expected),'harmonic_peaks_hz':parts,
         'harmonic_ratios':[round(parts[i]/hz/(i+1),4) if parts[i] else None for i in range(3)],'median_yin_aperiodicity':float(np.median(aper[voiced]))}

def measured_source_mode(path,root,t0=.20,t1=.60):
 return measured_audio_mode(Audio.load(path,sr=SR),root,t0,t1)

def git_blob_sha(b): return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
def midi(note):
 m=re.fullmatch(r'([A-G]#?)(-?\d+)',note)
 if not m: raise ValueError(note)
 return (int(m.group(2))+1)*12+PITCH[m.group(1)]
def midi_note_from_name(p):
 m=re.search(r'(?<![A-Za-z])([A-G]#?-?\d)(?!\d)',Path(p).stem)
 return midi(m.group(1)) if m else None
def fetch_vcsl(rel,dest):
 row=VCSL_ROWS[rel]; dest.parent.mkdir(parents=True,exist_ok=True)
 if not dest.exists():
  url='https://raw.githubusercontent.com/sgossner/VCSL/'+COMMIT+'/'+quote(rel,safe='/')
  with urlopen(Request(url,headers={'User-Agent':'Libero-Aria-v6/1.0'}),timeout=90) as r: data=r.read()
  if git_blob_sha(data)!=row['sha']: raise ValueError('VCSL Git blob mismatch: '+rel)
  dest.write_bytes(data)
 data=dest.read_bytes()
 if git_blob_sha(data)!=row['sha']: raise ValueError('cached VCSL Git blob mismatch: '+rel)
 return row
def source_proof(p,provider,rel=None,art=None,dyn=None):
 d={'provider':provider,'relative_path':rel or str(p),'local_path':str(p),'sha256':sha256(p)}
 if art is not None:d['articulation']=art
 if dyn is not None:d['source_dynamic']=dyn
 return d
def clean_owned(slug):
 dest=BANK/slug
 if dest.exists():
  proof=dest/'samples'/'aria-v6-owned.json'
  if not proof.exists(): raise RuntimeError(f'refusing to touch unowned bank folder {dest}')
  shutil.rmtree(dest)
 return dest

def add_default_policy(folder,master=-6):
 p=folder/'sound.py'; code=p.read_text()
 code += f"\nsound.defaults(mode='Poli',glide=0,amp_sustain=1,master={master},tape_wow=0,tape_flutter=0)\n"
 p.write_text(code)

def imported_source(spec):
 """Use importer to preserve every source root/dynamic, then move its recipe to Aria."""
 from libero.ingest.importers import import_wav_set
 from libero.library import discard_sound
 slug=spec['slug']; source=spec['source']; kind=spec['kind']
 # The lib importer uses a temporary staging copy only for the Philharmonia
 # dynamic spelling (piano/forte); each name still points to a separately
 # preserved original performance in the provenance manifest.
 staging=LIB/'cache'/'aria-v6-stage'/slug; shutil.rmtree(staging,ignore_errors=True); staging.mkdir(parents=True)
 proof=[]
 files=sorted(p for p in source.rglob('*') if p.is_file() and p.suffix.lower() in ('.wav','.flac','.mp3'))
 if kind=='philharmonia-pluck':
  for p in files:
   m=re.search(r'_([A-G]s?\d)_very-long_(piano|forte)_(normal|tremolo)\.mp3$',p.name,re.I)
   if not m: continue
   nt=m.group(1).replace('s','#'); dyn={'piano':'pp','forte':'ff'}[m.group(2).lower()]
   art=m.group(3).lower(); dst=staging/f'mandolin_{nt}_{dyn}_{art}.wav'
   if not dst.exists(): Audio.load(p,sr=SR).save(dst,subtype='PCM_24')
   item=source_proof(p,'Philharmonia Orchestra',p.relative_to(PHIL).as_posix(),art,dyn); item['staging_file']=dst.name; proof.append(item)
  family='plucked'; pattern=None
 elif kind=='tinysol-wind':
  shutil.rmtree(staging); staging=source
  files=sorted(p for p in staging.rglob('*.wav'))
  proof=[source_proof(p,'TinySOL',p.relative_to(TINY).as_posix(),None,re.search(r'-(pp|mf|ff)-',p.stem).group(1) if re.search(r'-(pp|mf|ff)-',p.stem) else None) for p in files]
  family='wind'; pattern=r'-(?P<note>[A-G]#?\d)-(?P<dyn>pp|mf|ff)-'
 credit={'id':'tinysol','source':'TinySOL (IRCAM)','author':'Cella, Ghisi, Lostanlen, Lévy, Fineberg, Maresz','license':'CC BY 4.0','license_class':'by','url':'https://zenodo.org/records/3685367','retrieved':'cached archive'}
 if kind=='philharmonia-pluck':
  credit={'id':'philharmonia','source':'Philharmonia Orchestra samples','author':'Philharmonia Orchestra performers','license':'CC BY-SA 3.0','license_class':'by-sa','url':'https://philharmonia.co.uk/explore/make_music','retrieved':'cached mirror'}
 if kind=='philharmonia-pluck':
  # Import each articulation independently, then merge the maps with explicit
  # articulation labels. Original dynamic layers stay switched at note-on.
  allmaps=[]; temp_slugs=[]
  for art in ('normal','tremolo'):
   partslug=slug+'-'+art; temp_slugs.append(partslug)
   art_pattern=rf'_(?P<note>[A-G]#?\d)_(?P<dyn>pp|ff)_{art}$'
   result=import_wav_set(partslug,staging,family=family,pattern=art_pattern,title=spec['title'],subtitle=spec['subtitle'],root_step=0,budget_mb=2000,quality='slow',credit=credit,replace=True)
   tmp=Path(result['folder']); mp=json.loads((tmp/'samples/map.json').read_text())
   for row in mp['body']: row['articulation']=art
   allmaps.extend(mp['body'])
  folder=Path(result['folder']).parent/(slug+'-merged'); folder.mkdir(parents=True,exist_ok=True); (folder/'samples').mkdir(exist_ok=True)
  # Source files are hardlinked by the importer; copy all of them into merged samples.
  for partslug in temp_slugs:
   tmp=Path(result['folder']).parent/partslug
   for q in (tmp/'samples').rglob('*'):
    if q.is_file():
     rel=q.relative_to(tmp/'samples'); target=folder/'samples'/rel; target.parent.mkdir(parents=True,exist_ok=True)
     if not target.exists():
      try: target.hardlink_to(q)
      except OSError: shutil.copy2(q,target)
  (folder/'samples/map.json').write_text(json.dumps({'body':allmaps,'tail':[]},indent=2)+'\n')
  # Substantially transform the Philharmonia recordings before they enter the
  # distributable bank bundle. Both attacks receive a same-source modal hold;
  # the performed tremolo gesture is preserved through the first 650 ms.
  from build_aria_mechanical import derive_source_body
  proof_by_stage={x['staging_file']:x for x in proof}; derived_dir=folder/'samples'/'body';derived_dir.mkdir(exist_ok=True)
  for i,row in enumerate(allmaps):
   raw=folder/'samples'/row['file']; proof_row=proof_by_stage[raw.name]
   original=PHIL/proof_row['relative_path']; derived=derived_dir/f'mandolin-zone-{i:03d}.wav'
   loop,measurement=derive_source_body(original,derived,row['root'],period=6.0 if row['root']<72 else 4.0,transition_end=.65)
   row['loop']=loop; proof_row['continuation']=measurement
   row['file']='body/'+derived.name
  (folder/'samples/map.json').write_text(json.dumps({'body':allmaps,'tail':[]},indent=2)+'\n')
  shutil.copy2(Path(result['folder'])/'sound.py',folder/'sound.py'); shutil.copy2(Path(result['folder'])/'notes.md',folder/'notes.md')
  if kind=='philharmonia-pluck':
   # The importer recipe's root-dependent cap can cut below our explicit 4/6s
   # modal loop, and its detector can move a source-derived continuation away
   # from the recording. Keep the whole continuation and measured source pitch.
   p=folder/'sound.py';code=p.read_text().replace("'tune': 'detect'", "'tune': 'source'").replace("'ladder': 'smooth'", "'ladder': 'keep'").replace("'max_seconds': [[28, 8.0], [96, 3.0]]", "'max_seconds': None");p.write_text(code)
  from libero import library
  for partslug in temp_slugs:
   library.discard_sound(partslug)
  folder=folder
 else:
  temp_slug=slug+'-import'
  result=import_wav_set(temp_slug,staging,family=family,pattern=pattern,title=spec['title'],subtitle=spec['subtitle'],root_step=0,budget_mb=2000,quality='slow',credit=credit,replace=True)
  folder=Path(result['folder'])
  if kind=='tinysol-wind':
   # Keep the full original performance in its imported source path. Bake a
   # longer same-recording crossfade into a derivative, then provide explicit
   # loop coordinates so the compiler does not fall back to its 5 ms default.
   mp=folder/'samples/map.json'; maps=json.loads(mp.read_text()); body_dir=folder/'samples'/'body';body_dir.mkdir(exist_ok=True)
   from dataclasses import replace as dc_replace
   for i,row in enumerate(maps['body']):
    raw=folder/'samples'/row['file']; audio=Audio.load(raw,sr=SR).remove_dc(3)
    mono=audio.to_mono().data.astype(float); t,en=dsp.rms_envelope(mono,SR,.04)
    good=np.flatnonzero(en>max(en.max()*10**(-6/20),1e-7))
    lp=None
    if len(good)>4:
     left=max(.12,float(t[good[0]])+.08);right=float(t[good[-1]])-.08
     if right-left>.9:
      min_s=min(2.2,(right-left)*.62)
      lp=audio.loop_points(min_seconds=min_s,region=(left,right),max_crossfade=.25)
    if lp is None: lp=audio.loop_points(min_seconds=1.0,max_crossfade=.25)
    if lp is None: raise RuntimeError(f'No long performed loop for {raw}')
    cooked,xf=bake_performed_loop(audio,lp); out=body_dir/f'{slug}-zone-{i:03d}.wav';cooked.save(out,subtype='PCM_24')
    row['file']='body/'+out.name;row['loop']={'start':lp.start,'end':lp.end}
    source_rel=raw.relative_to(folder/'samples'/'tinysol').as_posix()
    proof_row=next((x for x in proof if x.get('relative_path')==source_rel),None)
    if proof_row is not None:
     proof_row['derived_body_file']=row['file'];proof_row['loop_search_error_db']=lp.error_db;proof_row['loop_crossfade_seconds']=xf/SR;proof_row['exact_tail_seconds']=.02
   mp.write_text(json.dumps(maps,indent=2)+'\n')
   soundpy=folder/'sound.py'; code=soundpy.read_text().replace("'loop': 'auto'", "'loop': 'source'").replace('"loop": "auto"','"loop": "source"');soundpy.write_text(code)
  # Copy full originals into a stable subfolder, in addition to the exact mapped
  # files in samples/<catalog>/; no source is reconstructed from processed output.
  (folder/'samples/source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
  (folder/'samples/credits.json').write_text(json.dumps([credit],indent=2)+'\n')
 if kind=='philharmonia-pluck':
  (folder/'samples/source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
  (folder/'samples/credits.json').write_text(json.dumps([credit],indent=2)+'\n')
  (folder/'samples/map.json').write_text(json.dumps({'body':allmaps,'tail':[]},indent=2)+'\n')
  # Provide explicit normal/tremolo selectors.
  soundpy=folder/'sound.py'; txt=soundpy.read_text(); txt += "\nsound.articulations([{'id':'normal','name':'Normal','key':None},{'id':'tremolo','name':'Tremolo','key':None}])\n"
  txt=txt.replace("'loop': 'none'", "'loop': 'source'").replace('"loop": "none"', '"loop": "source"')
  soundpy.write_text(txt)
  # Drop mirror copies after derivation. The unchanged originals remain in the
  # user's licensed source cache and are identified by URL and SHA-256 above.
  for q in list((folder/'samples'/'philharmonia').rglob('*')) if (folder/'samples'/'philharmonia').exists() else []:
   if q.is_file(): q.unlink()
 # Apply the new unique slug and destination.
 dest=clean_owned(slug); shutil.copytree(folder,dest,dirs_exist_ok=True)
 (dest/'samples/aria-v6-owned.json').write_text(json.dumps({'builder':'build_aria_expansion_v6.py','slug':slug})+'\n')
 if folder.name==slug+'-merged': shutil.rmtree(folder)
 else:
  from libero import library
  library.discard_sound(temp_slug)
 add_default_policy(dest,4 if slug=='mandolino-dorato' else (-8 if kind=='philharmonia-pluck' else -6))
 return dest,proof

def fetch_vcsl_group(prefix,slug):
 dest=LIB/'cache'/'sources'/'aria-v6'/slug; dest.mkdir(parents=True,exist_ok=True)
 items=[]
 for rel,row in VCSL_ROWS.items():
  if rel.startswith(prefix+'/') and rel.lower().endswith(('.wav','.mp3')):
   p=dest/Path(rel).name; fetch_vcsl(rel,p); items.append((rel,p,row))
 return items

def figure(spec,kind):
 title=spec['title']; c=spec['accent']
 shapes={
  'mandolino-dorato':f'<path d="M112 345 Q92 292 149 255 Q199 222 232 265 Q267 221 320 249 Q393 286 365 352 Q342 411 274 395 Q254 389 241 368 Q226 396 195 401 Q137 405 112 345Z" fill="#f3eee6"/><path d="M241 308 L405 104 L420 115 L256 323"/><path d="M236 292 L402 91 M240 303 L409 102 M245 314 L416 113" stroke="{c}"/><circle cx="238" cy="326" r="18"/><path d="M218 323 Q237 305 257 323 M170 286 Q194 266 210 291 M284 281 Q306 266 326 287"/>',
  'oboe-respiro':f'<path d="M244 70 L268 70 L282 366 Q256 412 230 366Z" fill="#f3eee6"/><path d="M252 69 L261 34 L269 69 M236 152H275 M238 205H278 M240 260H280 M231 332H281"/><circle cx="258" cy="173" r="4" fill="{c}"/><circle cx="258" cy="226" r="4" fill="{c}"/><circle cx="258" cy="281" r="4" fill="{c}"/><path d="M232 370 Q256 397 280 370"/>',
  'fagotto-ombra':f'<path d="M219 74 L244 74 L251 343 Q246 368 232 377 L195 377 Q178 370 188 352 L211 337Z" fill="#f3eee6"/><path d="M243 76 L268 76 L277 332 Q280 364 261 380 L232 380 M267 83 L284 83 L296 329 Q301 365 282 389"/><path d="M217 135H266 M220 202H271 M222 268H274 M194 353L179 408 M284 388L301 411"/><circle cx="232" cy="157" r="4" fill="{c}"/><circle cx="235" cy="227" r="4" fill="{c}"/><circle cx="238" cy="293" r="4" fill="{c}"/>',
  'recorder':'<path d="M215 82 L297 82 L279 422 L232 422Z"/><ellipse cx="256" cy="85" rx="42" ry="10"/><path d="M231 140H281 M228 210H284 M224 280H288 M220 350H292"/>'+''.join(f'<circle cx="256" cy="{150+i*38}" r="5" fill="{c}" stroke="none"/>' for i in range(6)),
  'gong':f'<circle cx="256" cy="255" r="151"/><circle cx="256" cy="255" r="121"/><circle cx="256" cy="255" r="23" fill="{c}"/><path d="M152 404 L177 365 M360 365 L384 404 M177 365 Q256 404 360 365"/>',
  'zither':'<path d="M103 317 Q255 251 407 317 L379 375 Q255 331 131 375Z"/><path d="M126 319 Q255 270 384 319"/>'+''.join(f'<path d="M{145+i*22} 302 L{136+i*24} 363"/>' for i in range(11)),
 }
 kind=spec['slug'] if kind=='instrument' else kind
 art=shapes.get(kind,'<rect x="130" y="178" width="252" height="160" rx="24"/><path d="M155 222H357 M155 280H357"/>')
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>Disegno identificativo della sorgente registrata; il colore indica l’inviluppo misurato, non un effetto aggiunto.</desc>{art}</svg>\n'

def build_vcsl(spec):
 slug=spec['slug']; kind=spec['kind']; dest=clean_owned(slug); samples=dest/'samples'; originals=samples/'originals'; bodies=samples/'body'; originals.mkdir(parents=True);bodies.mkdir()
 if kind=='vcsl-recorder':
  prefix='Aerophones/Edge-blown Aerophones/Baroque Alto Recorder'
  items=fetch_vcsl_group(prefix,slug); selected=[x for x in items if '/Sustain/' in x[0] or '/SusVib/' in x[0] or '/Staccato/' in x[0]]
 elif kind=='vcsl-gong':
  prefix='Idiophones/Struck Idiophones/Gong 1';items=fetch_vcsl_group(prefix,slug);selected=items
 else:
  prefix='Chordophones/Zithers/Dan Tranh';items=fetch_vcsl_group(prefix,slug);selected=[x for x in items if '/Normal/' in x[0] or '/Tremolo/' in x[0] or '/Vibrato/' in x[0] or '/Gliss/' in x[0]]
 proof=[]; regions=[]; continuation=[]; articulation_ids=[]
 for rel,src,row in items:
  target=originals/Path(rel).relative_to(Path(prefix)); target.parent.mkdir(parents=True,exist_ok=True)
  if not target.exists(): shutil.copy2(src,target)
  proof.append({'provider':'VCSL','upstream_path':rel,'source_url':f'https://github.com/sgossner/VCSL/blob/{COMMIT}/{quote(rel,safe="/")}', 'git_blob_sha':row['sha'],'sha256':sha256(target),'retained_original':'samples/originals/'+str(target.relative_to(originals))})
 arts={'Sustain':'dritta','SusVib':'vibrata','Staccato':'staccata','Normal':'pizzicato','Tremolo':'tremolo','Vibrato':'vibrato','Gliss':'glissando'}
 for rel,src,row in selected:
  target=originals/Path(rel).relative_to(Path(prefix))
  artdir=Path(rel).parent.name; art=arts.get(artdir,'colpo')
  proof_row=next(x for x in proof if x['upstream_path']==rel); proof_row['articulation']=art
  if kind=='vcsl-recorder':
   root=midi_note_from_name(Path(rel));
   if root is None: continue
   # The four VCSL recorder families label notes one octave below sounding pitch.
   root+=12
   audio=Audio.load(target,sr=SR).remove_dc(3)
   if art=='staccata':
    # A short articulation remains short; it is not stretched into a fake sustain.
    out=bodies/(target.stem+'-entry.wav'); audio.save(out,subtype='PCM_24'); loop=None
   else:
    a=audio.to_mono().data.astype(float); t,e=dsp.rms_envelope(a,SR,.04); active=np.flatnonzero(e>max(e.max()*10**(-12/20),1e-7))
    if len(active)<4: raise ValueError(f'no performed recorder body in {rel}')
    lo=max(float(t[active[0]])+.08,.12); hi=float(t[active[-1]])-.03
    if hi-lo<.8: raise ValueError(f'recorder tone too short to loop: {rel}')
    lp=audio.loop_points(min_seconds=min(2.8,(hi-lo)*.65),region=(lo,hi),max_crossfade=.25)
    if lp is None: raise ValueError(f'no recorder loop {rel}')
    cooked,xf=bake_performed_loop(audio,lp)
    out=bodies/(target.stem+'-sustain.wav'); cooked.save(out,subtype='PCM_24'); loop={'start':lp.start,'end':lp.end}
    continuation.append({'source':rel,'loop':loop,'loop_candidate_db':float(lp.error_db),'loop_seam_db_20ms':window_seam_db(cooked.data,lp.start,lp.end,int(.02*SR)),'crossfade_seconds':xf/SR,'loop_seconds':(lp.end-lp.start)/SR})
   regions.append({'file':'body/'+out.name,'root':root,'vel':[1,127],'take':0,'pitched':True,'articulation':art,'loop':loop})
   articulation_ids.append(art)
  elif kind=='vcsl-dan-tranh':
   m=re.search(r'([A-Ga-g]#?\d+)',target.stem)
   audio=Audio.load(target,sr=SR).remove_dc(3)
   if not m:
    low=target.stem.lower(); pace=('swl' if 'swl' in low else ('med' if 'med' in low else 'slow'))
    art=('gliss_down_' if 'dwn' in low else 'gliss_up_')+pace
    key=45 if 'down' in art else 46
    out=bodies/(target.stem+'.wav');audio.save(out,subtype='PCM_24')
    dyn='ff' if '_ff_' in low else ('mf' if '_mf_' in low else None)
    vel={'mf':[1,75],'ff':[76,127]}.get(dyn,[1,127])
    tm=re.search(r'_(\d+)$',target.stem); take=max(0,(int(tm.group(1))-1)) if tm else 0
    proof_row['articulation']=art; proof_row['source_dynamic']=dyn; proof_row['source_take']=take
    regions.append({'file':'body/'+out.name,'root':key,'lo':key,'hi':key,'vel':vel,'take':take,'pitched':False,'one_shot':True,'articulation':art})
    articulation_ids.append(art)
    continue
   filename_root=midi(m.group(1).upper());root=filename_root+12
   proof_row['filename_midi']=filename_root;proof_row['sounding_midi']=root;proof_row['octave_audit']='source 40-500 ms fundamental is one octave above VCSL filename label'
   dyn_match=re.search(r'_(mf|f|ff)_',target.stem)
   proof_row['source_dynamic']=dyn_match.group(1) if dyn_match else None
   if art in ('glissando',):
    out=bodies/(target.stem+'.wav');audio.save(out,subtype='PCM_24');loop=None
   else:
    # Source-derived modal continuation: preserve its attack, fit measured modes,
    # and preserve source tuning rather than quantising the altered string spectrum.
    from build_aria_mechanical import derive_source_body
    out=bodies/(target.stem+'-hold.wav')
    try: loop,measure=derive_source_body(target,out,root,period=6.0,transition_end=.65)
    except Exception as exc: raise RuntimeError(f'Dan Tranh sustain fit failed for {rel}: {exc}')
    continuation.append({'source':rel,'loop':loop,**measure})
   vel={'mf':[1,48],'f':[49,96],'ff':[97,127]}.get(re.search(r'_(mf|f|ff)_',target.stem).group(1) if re.search(r'_(mf|f|ff)_',target.stem) else None,[1,127])
   zone={'file':'body/'+out.name,'root':root,'vel':vel,'take':0,'pitched':True,'articulation':art,'loop':loop}
   if art in ('pizzicato','tremolo','vibrato'):
    # The continuation is the held keyboard tone, so calibrate from the actual
    # source-derived body after fitting. The short raw strike can bend sharply
    # during its attack; using only that window leaves the looped body detuned.
    measured=measured_source_mode(out,root)
    if measured is None: raise RuntimeError(f'Cannot measure Dan Tranh derived body pitch: {rel}')
    tune_cents=float(np.clip(-measured['body_mode_error_cents'],-100,100))
    zone['tune_cents']=round(tune_cents,2)
    proof_row['measured_body_pitch']=measured;proof_row['source_tune_cents']=round(tune_cents,2)
    continuation[-1]['source_tune_cents']=round(tune_cents,2)
   regions.append(zone)
   articulation_ids.append(art)
  else:
   # One actual strike yields two modes, never a second take/RR: original
   # natural decay as Colpo, and a same-source fitted inharmonic modal body as
   # default Risonanza. A noisy scrape remains an original one-shot only.
   name=target.stem.lower(); art='scrape' if 'scrape' in name else ('second' if '2_' in name else 'hit')
   dyn=next((x for x in ('p','mp','mf','f','fff') if name.endswith('_'+x)), 'mf')
   vel={'p':[1,32],'mp':[33,58],'mf':[59,88],'f':[89,112],'fff':[113,127]}[dyn]
   key=36 if art=='hit' else (37 if art=='second' else 38)
   if art=='scrape':
    regions.append({'file':'originals/'+target.name,'root':key,'lo':0,'hi':127,'vel':vel,'take':0,'pitched':False,'one_shot':True,'articulation':'raschio'})
    articulation_ids.append('raschio');proof_row['articulation']='raschio';proof_row['source_mode']='unchanged one-shot scrape'
   else:
    source_label='secondo' if art=='second' else ''
    colpo_art='colpo'+('_'+source_label if source_label else '')
    resonance_art='risonanza'+('_'+source_label if source_label else '')
    regions.append({'file':'originals/'+target.name,'root':key,'lo':0,'hi':127,'vel':vel,'take':0,'pitched':False,'one_shot':True,'articulation':colpo_art})
    articulation_ids.append(colpo_art)
    from build_aria_mechanical import derive_source_body
    out=bodies/(target.stem+'-risonanza.wav')
    try: loop,measure=derive_source_body(target,out,key,period=6.0,transition_end=.65)
    except Exception as exc: raise RuntimeError(f'Gong modal continuation failed for {rel}: {exc}')
    regions.append({'file':'body/'+out.name,'root':key,'lo':0,'hi':127,'vel':vel,'take':0,'pitched':False,'one_shot':False,'articulation':resonance_art,'loop':loop})
    articulation_ids.append(resonance_art);proof_row['articulation']=colpo_art;proof_row['source_mode']=f'same take as {colpo_art}; modal continuation is not another performance';proof_row['modal_derivative_file']='body/'+out.name
    continuation.append({'source':rel,'source_performance':f'same take as {colpo_art}; not a new take or RR','loop':loop,**measure})
 if not regions: raise RuntimeError('No VCSL zones for '+slug)
 # Reindex only actual performances, contiguously within their key, dynamic
 # and articulation. This preserves RR variation without inventing missing takes.
 groups={}
 for region in regions:
  key=(region.get('articulation'),region['root'],tuple(region.get('vel',[1,127])))
  groups.setdefault(key,[]).append(region)
 for group in groups.values():
  group.sort(key=lambda r:r['file'])
  for i,region in enumerate(group): region['take']=i
 mapjson={'body':regions,'tail':[]};(samples/'map.json').write_text(json.dumps(mapjson,indent=2)+'\n')
 (samples/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 (samples/'infinite-provenance.json').write_text(json.dumps(continuation,indent=2)+'\n')
 lic={'source':'Versilian Community Sample Library (VCSL)','author':'Versilian Studios LLC / contributors','license':'CC0 1.0','license_class':'cc0','url':'https://github.com/sgossner/VCSL','commit':COMMIT,'license_url':f'https://github.com/sgossner/VCSL/blob/{COMMIT}/LICENSE','retrieved':datetime.now(timezone.utc).date().isoformat()}
 (samples/'credits.json').write_text(json.dumps([lic],indent=2)+'\n')
 def soundpy():
  roots=sorted({r['root'] for r in regions});takes=max((r['take'] for r in regions),default=0)+1
  if kind=='vcsl-gong': arts=['risonanza','colpo','risonanza_secondo','colpo_secondo','raschio']
  elif kind=='vcsl-dan-tranh': arts=['pizzicato','tremolo','vibrato']+sorted(a for a in set(articulation_ids) if a.startswith('gliss_'))
  else: arts=sorted(set(articulation_ids))
  art_names={'risonanza':'Risonanza','colpo':'Colpo','risonanza_secondo':'Seconda Risonanza','colpo_secondo':'Secondo Colpo','raschio':'Raschio','pizzicato':'Pizzicato'}
  soundarts=','.join(repr({'id':a,'name':art_names.get(a,a.title()),'key':None}) for a in arts)
  proc={'pre_ms':0,'align_ms':0,'tune':'source','ladder':'keep','peak_db':-12 if kind!='vcsl-gong' else -13,'end_db':-100,'fade_ms':0,'loop':'source','max_seconds':None,'encoding':'flac24','mono':False}
  return f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nMAP=json.loads((Path(__file__).parent/'samples/map.json').read_text())\nsound=Sound(title={spec['title']!r},subtitle={spec['subtitle']!r},tags=['aria','recorded','v6','source-led'],roots={roots!r},velocities=[24,56,84,108,124],sample_rate=48000,accent={spec['accent']!r},takes={takes})\nsound.articulations([{soundarts}])\nsound.multisample('body',MAP['body'],process={proc!r},as_dyn=False)\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}},rr_reset_ms=0,one_shot=False)\nsound.defaults(mode='Poli',glide=0,voices=24,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=360,lvl_body=0,lvl_attack=-60,lvl_tail=-60,lvl_air=-60,vel_sens=.42,master={0 if kind=='vcsl-recorder' else (-1.5 if kind=='vcsl-gong' else -6)},osc1_level=-60,osc2_level=-60,sub_level=-60,drive=0,tape_wow=0,tape_flutter=0,tape_sat=0,tape_mix=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix=.04,rev_decay=1.15,rev_damp=.45)\n'''
 (dest/'sound.py').write_text(soundpy());(dest/'figure.svg').write_text(figure(spec,'recorder' if kind=='vcsl-recorder' else 'gong' if kind=='vcsl-gong' else 'zither'))
 (samples/'aria-v6-owned.json').write_text(json.dumps({'builder':'build_aria_expansion_v6.py','slug':slug})+'\n')
 (dest/'notes.md').write_text(f"# {spec['title']}\n\n{spec['subtitle']}. Source WAVs are preserved unchanged under `samples/originals/`; VCSL blob IDs and SHA-256 digests appear in `samples/source-proof.json`. `{COMMIT}` is the pinned VCSL source commit (CC0 1.0).\n\nAll included source articulations and actual recorded dynamics are mapped; no missing takes or dynamics are synthesized. Recorded breath loops, where applicable, retain the original performed motion. Struck-string extensions are source-derived modal continuations with the attack and motion preserved. Gong defaults to Risonanza, an explicitly designed infinite hold from measured inharmonic modes of a finite source take (the original recording does not ring forever); unmodified natural decay remains secondary Colpo and scrape remains Raschio one-shot. These are modes of one performance, never separate takes or round robins. Defaults: Poli, glide 0, sustain 1, wow/flutter 0, master headroom.\n")
 if kind=='vcsl-dan-tranh':
  with (dest/'notes.md').open('a') as f:f.write('\nFor named pizzicato, tremolo, and vibrato notes, each original receives a per-source/per-dynamic tuning offset measured from its stable 0.20–0.60 s root mode; offsets are in `samples/map.json` and the source-measurement proof is in `samples/source-proof.json`. Originals are unchanged. Intentional glissando one-shots are excluded from the chromatic tuning audit.\n')
 return dest,proof,continuation

def compile_and_audit(spec,dest,proof,continuation):
 result=compile_sound(dest,jobs=2)
 if not result.ok: raise RuntimeError(f'{spec["slug"]} compile failed: {result.text()}')
 native_tune_calibration=[]
 if spec['kind']=='vcsl-dan-tranh':
  # Calibrate the player's actual pitched output (including its looped body
  # and engine tuning convention) at the two default velocity extremes. This
  # is a small per-root/per-source-dynamic correction, not a pitch resynthesis.
  mp=dest/'samples'/'map.json'; data=json.loads(mp.read_text()); changed=False
  roots=sorted({int(z['root']) for z in data['body'] if z.get('articulation')=='pizzicato'})
  for key in roots:
   for dynamic,velocity in (('soft',28),('hard',120)):
    pv=render.preview(spec['slug'],f'{key}:0:1.2:{velocity}',params={'artic':0},tail=.5)
    measured=measured_audio_mode(pv.audio,key,.20,.60)
    candidates=[z for z in data['body'] if z.get('articulation')=='pizzicato' and int(z['root'])==key and int(z['vel'][0])<=velocity<=int(z['vel'][1])]
    if measured is None or len(candidates)!=1:
     native_tune_calibration.append({'root':key,'dynamic':dynamic,'error':'missing native pitch or unique source zone'});continue
    zone=candidates[0];before=float(measured['body_mode_error_cents']);delta=-before
    prior=float(zone.get('tune_cents',0));updated=prior+delta
    row={'root':key,'note':dsp.note_name(key),'dynamic':dynamic,'velocity':velocity,'source_zone':zone['file'],'native_error_before_cents':round(before,2),'tune_before_cents':round(prior,2),'tune_adjustment_cents':round(delta,2),'tune_after_cents':round(updated,2)}
    if abs(updated)>100:
     row['error']='native correction exceeds ±100 cents'
    else:
     if abs(delta)>.25: zone['tune_cents']=round(updated,2);changed=True
    native_tune_calibration.append(row)
  if changed:
   mp.write_text(json.dumps(data,indent=2)+'\n')
   result=compile_sound(dest,jobs=2)
   if not result.ok: raise RuntimeError(f'{spec["slug"]} pitch-calibrated recompile failed: {result.text()}')
 findings=lint_bundle(dest/'build'); fails=[f for f in findings if f.level=='FAIL'];
 if fails: raise RuntimeError(spec['slug']+' lint FAIL: '+'; '.join(f.line() for f in fails))
 # Generate native phrase, holds, soft/loud, pitch-scale, chord and extreme tests.
 bodyzones=json.loads((dest/'samples/map.json').read_text())['body']
 pitch_map=[];pitch_fails=[];pitch_warnings=[]
 if spec['kind']=='vcsl-dan-tranh':
  sources=list((dest/'samples'/'originals').rglob('*.wav')); done=set()
  for z in bodyzones:
   if z.get('articulation') not in ('pizzicato','tremolo','vibrato') or '-hold.wav' not in z['file']: continue
   stem=Path(z['file']).name.removesuffix('-hold.wav');src=next((p for p in sources if p.stem==stem),None)
   if src is None:
    pitch_fails.append({'root':z['root'],'source':stem,'error':'original source missing'});continue
   identity=(z.get('articulation'),z['root'],stem)
   if identity in done: continue
   done.add(identity);body_path=dest/'samples'/z['file'];measured=measured_source_mode(body_path,z['root']);tune=float(z.get('tune_cents',0))
   if measured is None:pitch_fails.append({'source':str(src.relative_to(dest)),'root':z['root'],'error':'no measurable stable fundamental'});continue
   err=float(measured['body_mode_error_cents']);source_mode=measured_source_mode(src,z['root']);row={'source':str(src.relative_to(dest)),'derived_body':z['file'],'articulation':z.get('articulation'),'source_dynamic':next((x.get('source_dynamic') for x in proof if x.get('upstream_path','').endswith(stem+'.wav')),None),'filename_root':z['root']-12,'sounding_root':z['root'],'raw_source_error_cents':round(source_mode['body_mode_error_cents'],2) if source_mode else None,'measured_body_mode_hz':round(measured['measured_root_mode_hz'],3),'raw_error_cents':round(err,2),'tune_cents':round(tune,2),'effective_source_error_cents':round(err+tune,2),'harmonic_peaks_hz':[round(x,2) if x else None for x in measured['harmonic_peaks_hz']],'harmonic_ratios':measured['harmonic_ratios']}
   pitch_map.append(row)
   # Native rendered output below is the final interval authority. This source
   # row separately records the true body-mode and applied correction.
 pitched_roots=[r.get('root',60) for r in bodyzones if r.get('pitched',True)]
 root=36 if spec['kind']=='vcsl-gong' else min(pitched_roots)
 hi_root=38 if spec['kind']=='vcsl-gong' else max(pitched_roots)
 notes=[root,root+3,root+7,root+12]
 tests={'soft':f'{root}:0:1:28','hard':f'{root}:0:1:120',
        'phrase':f'{root}:0:.5:45,{root+3}:.65:.5:70,{root+7}:1.3:.7:100,{root+12}:2.2:1:118',
        'chord':','.join(f'{n}:0:2:95' for n in notes),
        'low-high':f'{root}:0:.5:95,{hi_root}:1:.5:95',
        'hold60':f'{root}:0:60:100'}
 qa={};
 for name,phrase in tests.items():
  try:
   pv=render.preview(spec['slug'],phrase,tail=1)
   shutil.copy2(pv.wav,DEMO/(spec['slug']+'-'+name+'.wav'))
   qa[name]=analysis.features(pv.audio)
   mono=pv.audio.to_mono()
   qa[name]['mono_check']={'channels':mono.channels,'peak_db':analysis.features(mono)['peak_db'],'clipped_samples':analysis.features(mono)['clipped_samples']}
   if name=='hold60' and qa[name]['duration_s'] < 60:
    qa[name]['validation_error']=f"60-second sustain rendered only {qa[name]['duration_s']:.3f}s"
   if qa[name]['clipped_samples'] or qa[name]['mono_check']['clipped_samples']:
    qa[name]['validation_error']='clipping in stereo or mono render'
   if name=='phrase': (DEMO/(spec['slug']+'-phrase.png')).write_bytes(analysis.spectrogram(pv.audio,title=spec['title']+' · phrase'))
  except Exception as exc: qa[name]={'error':str(exc)}
 if spec['kind']=='vcsl-gong':
  # Verify every real source dynamic at its true unpitched key. Each 1-second
  # window from 10 through 59 seconds must retain measurable modal energy; the
  # natural decay is separately preserved as Colpo and is not counted as a hold.
  holds=[]; hold_fails=[]
  for zone in bodyzones:
   art=zone.get('articulation')
   if art not in ('risonanza','risonanza_secondo'): continue
   vel=(int(zone['vel'][0])+int(zone['vel'][1]))//2; key=int(zone['root'])
   try:
    hp=render.preview(spec['slug'],f'{key}:0:60:{vel}',params={'artic':{'risonanza':0,'colpo':1,'risonanza_secondo':2,'colpo_secondo':3,'raschio':4}[art]},tail=1)
    x=hp.audio.to_mono().data.astype(np.float64); windows=[]
    for sec in range(10,60):
     part=x[sec*SR:(sec+1)*SR]
     windows.append(20*math.log10(float(np.sqrt(np.mean(part*part)))+1e-15) if len(part)==SR else -300.0)
    peak=analysis.features(hp.audio)['peak_db']; clipped=analysis.features(hp.audio)['clipped_samples']
    row={'articulation':art,'source_body':zone['file'],'root':key,'velocity':vel,'late_windows_10_59_min_dbfs':round(min(windows),2),'late_windows_10_59_median_dbfs':round(float(np.median(windows)),2),'late_windows_10_59_max_dbfs':round(max(windows),2),'peak_db':peak,'clipped_samples':clipped,'duration_s':hp.audio.duration,'pitched':False}
    holds.append(row)
    if min(windows)<-55 or clipped or peak>=0 or hp.audio.duration<60: hold_fails.append(row)
   except Exception as exc: hold_fails.append({'source_body':zone.get('file'),'error':str(exc)})
  qa['modal_dynamic_holds']={'default_articulation':'risonanza','source_performance_modes':holds,'failure_rows':hold_fails}
 mid_keys={'mandolino-dorato':[60,72],'flauto-barocco':[72,84],'dan-tranh-lunare':[60,72]}.get(spec['slug'],[])
 if mid_keys:
  mid=[]
  for key in mid_keys:
   try:
    hp=render.preview(spec['slug'],f'{key}:0:12:100',tail=1);feat=analysis.features(hp.audio);mono=hp.audio.to_mono().data.astype(np.float64)
    levels=[]
    for sec in (10,11):
     part=mono[sec*SR:(sec+1)*SR];levels.append(20*math.log10(float(np.sqrt(np.mean(part*part)))+1e-15))
    shutil.copy2(hp.wav,DEMO/(spec['slug']+f'-mid{key}-hold12.wav'))
    mid.append({'midi':key,'measured_f0_hz':feat.get('f0_hz'),'measured_f0_note':feat.get('f0_note'),'rms_10_11_dbfs':round(levels[0],2),'rms_11_12_dbfs':round(levels[1],2),'peak_db':feat['peak_db'],'clipped_samples':feat['clipped_samples'],'duration_s':feat['duration_s'],'one_second_change_db':round(levels[1]-levels[0],2)})
   except Exception as exc: mid.append({'midi':key,'error':str(exc)})
  qa['mid_register_holds']=mid
 chromatic_fails=[]
 if spec['kind']=='vcsl-dan-tranh':
  checks=[];chromatic_roots=sorted({int(z['root']) for z in bodyzones if z.get('articulation')=='pizzicato'})
  for key in chromatic_roots:
   expected=440*2**((key-69)/12)
   for label,vel in (('soft',28),('hard',120)):
    try:
     pv=render.preview(spec['slug'],f'{key}:0:1.2:{vel}',params={'artic':0},tail=.5)
     measurement=measured_audio_mode(pv.audio,key,.20,.60);features=analysis.features(pv.audio)
     cents=measurement['body_mode_error_cents'] if measurement else None
     row={'key_midi':key,'note':dsp.note_name(key),'dynamic':label,'velocity':vel,'expected_hz':round(expected,3),'measured_body_mode_hz':round(measurement['measured_root_mode_hz'],3) if measurement else None,'error_cents':round(cents,2) if cents is not None else None,'yin_f0_hz_diagnostic':features.get('f0_hz'),'yin_f0_note_diagnostic':features.get('f0_note'),'peak_db':features['peak_db'],'clipped_samples':features['clipped_samples'],'duration_s':features['duration_s']}
     checks.append(row)
     if cents is None or abs(cents)>10 or features['clipped_samples'] or features['peak_db']>=0:chromatic_fails.append(row)
    except Exception as exc:chromatic_fails.append({'key_midi':key,'dynamic':label,'error':str(exc)})
  qa['native_chromatic_pitch']={'articulation':'pizzicato default only; intentional glissandi excluded','roots':chromatic_roots,'soft_and_hard_checks':checks,'failures':chromatic_fails}
 lint={'FAIL':len(fails),'WARN':sum(f.level=='WARN' for f in findings),'findings':[f.line() for f in findings]}
 # Verify compiled source-loop boundaries directly, rather than trusting the
 # recipe's loop intent. Compare equal 20 ms windows at both sides of each wrap.
 seams=[]; manifest=json.loads((dest/'build'/'manifest.json').read_text())
 for z in manifest.get('zones',[]):
  lp=z.get('loop')
  if not lp: continue
  audio_path=dest/'build'/z['file']; y,sr=sf.read(audio_path,dtype='float64',always_2d=True)
  a=int(lp['start']);b=int(lp['end']);n=min(int(.02*sr),a,b-a)
  if n<16: continue
  left=y[b-n:b];right=y[a-n:a]
  # Compare the matching 20 ms regions before loopEnd and loopStart, matching
  # Audio.loop_points' normalised seam-error definition after baked crossfade.
  err=10*math.log10((float(np.sum((left-right)**2))+1e-30)/(float(np.sum(left**2)+np.sum(right**2))+1e-30))
  seams.append({'file':z['file'],'root':z.get('root'),'dynamic':z.get('dyn'),'articulation':z.get('articulation'),'seam_error_20ms_db':round(err,2),'loop_seconds':round((b-a)/sr,3)})
 (dest/'lint.txt').write_text('\n'.join(f.line() for f in findings)+'\n')
 source_seams=[x.get('loop_seam_db_20ms',x.get('loop_seam_db')) for x in continuation]
 source_seams=[v for v in source_seams if isinstance(v,(int,float))]
 compiled_seams=[x['seam_error_20ms_db'] for x in seams]
 failures=[f"{name}: {item['validation_error']}" for name,item in qa.items() if 'validation_error' in item]
 report={'slug':spec['slug'],'source_files':len(proof),'continuation_zones':len(continuation),'compiled_loop_zones':len(seams),'loop_seam_checks':seams,'lint':lint,'native_previews':qa,'native_tune_calibration':native_tune_calibration,'compile_warnings':result.warnings,
         'loop_seam_max_db':max(compiled_seams,default=None),'source_loop_candidate_max_db':max(source_seams,default=None),'loops_above_minus30_db':[x for x in seams if x['seam_error_20ms_db']>-30],
         'source_pitch_mapping':pitch_map,'source_pitch_warnings':pitch_warnings,'validation_failures':failures + ([f"gong modal dynamic hold floor/clip/duration failed: {len(qa['modal_dynamic_holds']['failure_rows'])} zones" ] if spec['kind']=='vcsl-gong' and qa['modal_dynamic_holds']['failure_rows'] else []) + ([f"Dan Tranh source pitch mapping exceeded ±10 cents, missing mode, or clipped: {len(pitch_fails)} source zones; native soft/hard chromatic failures: {len(chromatic_fails)}"] if spec['kind']=='vcsl-dan-tranh' and (pitch_fails or chromatic_fails) else []) + ([f"mid-register hold preview failed for {spec['slug']}"] if mid_keys and any('error' in x or x.get('clipped_samples',0)>0 for x in qa['mid_register_holds']) else []),
         'human_listening':'not performed by builder; no taste/quality claim from metrics'}
 (dest/'verification.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
 def reason(f):
  line=f.line()
  if f.check=='aliasing': return line+' Retained because the upper attack detail belongs to the original high-register performance.'
  if f.check=='onset': return line+' Variation is in the recorded onset; trimming/alignment would alter that performance.'
  if f.check=='ladder': return line+' The source levels remain genuine pp/mf/ff performances; no note-wise gain normalization was applied.'
  if f.check=='brightness': return line+' The recorded dynamics at this key differ mainly in level; no artificial timbre was generated.'
  if f.check=='takes': return line+' Only the stated number of distinct source takes exists at this key; no duplicates were made.'
  if f.check=='layers': return line+' The source does not supply every dynamic at this key; absent performances were not synthesized.'
  if f.check=='loudness': return line+' This note is louder in the actual source recording; note-wise normalization was avoided.'
  return line+' The recorded gesture is retained; see source-proof.json for the source and measurements.'
 warn='\n'.join('- '+reason(f) for f in findings if f.level=='WARN')
 with (dest/'notes.md').open('a') as f:
  f.write('\n## Lint warnings\n\n'+(warn if warn else 'No WARN findings.')+'\n\n')
  if pitch_warnings:
   f.write('## Measured source-pitch notes\n\n')
   for x in pitch_warnings: f.write(f"- {x['source']}: measured local mode {x['measured_mode_hz_near_root']} Hz is {x['measured_mode_error_cents']:+.2f} cents from the filename-derived sounding key; retained without retuning. Full source/YIN diagnostics are in `verification.json`.\n")
  if spec['kind']=='vcsl-dan-tranh':
   checks=qa.get('native_chromatic_pitch',{}).get('soft_and_hard_checks',[])
   ce=[x['error_cents'] for x in checks if isinstance(x.get('error_cents'),(int,float))]
   f.write('\n## Dan Tranh pitch calibration\n\n')
   f.write(f"Each source/dynamic loop body is tuned from its measured 0.20–0.60 s fundamental, then calibrated in the native renderer. The 16 pizzicato roots are checked at soft and hard velocity ({len(checks)} native renders); measured final spread is {min(ce):+.2f} to {max(ce):+.2f} cents. Full before/after tuning offsets and diagnostics are in `verification.json` and `samples/map.json`; glissandi are intentionally excluded.\n\n")
   csharp=next((x for x in pitch_map if x['source'].endswith('C#3_ff_1.wav') and x['articulation']=='pizzicato'),None)
   if csharp:
    native=next((x for x in checks if x['key_midi']==csharp['sounding_root'] and x['dynamic']=='hard'),None)
    f.write(f"The C#3-labelled VCSL take maps to sounding MIDI {csharp['sounding_root']} (C#4). Its 0.20–0.60 s source fundamental measures {csharp['raw_source_error_cents']:+.2f} cents against that sounding root; the derived held-body fundamental measures {csharp['raw_error_cents']:+.2f} cents. Harmonics 2 and 3 support this as the fundamental rather than an upper inharmonic partial. Native hard playback after per-source calibration measures {native['error_cents']:+.2f} cents. The original file remains unchanged.\n")
  f.write('Native renders are in `~/Libero/demo/aria-v6/`. The report checks pitch, clipping, output levels, and numerical loop-boundary continuity; repeating loop texture and musical preference still require listener review.\n')
 return report

def main():
 from libero.ingest.importers import import_wav_set
 force='--force' in sys.argv[1:]; only=None
 if '--only' in sys.argv[1:]:
  i=sys.argv.index('--only')
  if i+1>=len(sys.argv): raise SystemExit('--only needs an exact sound slug')
  only=sys.argv[i+1]
 if only is not None and only not in {x['slug'] for x in SOUNDS}: raise SystemExit('unknown --only slug: '+only)
 reports=[]
 for spec in SOUNDS:
  if only is not None and spec['slug']!=only: continue
  ready=BANK/spec['slug']
  if not force and (ready/'samples'/'aria-v6-owned.json').exists() and (ready/'verification.json').exists():
   prior=json.loads((ready/'verification.json').read_text())
   if prior.get('lint',{}).get('FAIL')==0:
    reports.append(prior); print(spec['slug'],'already built and lint clean',flush=True); continue
  if spec['kind'].startswith('vcsl-'):
   dest,proof,continuation=build_vcsl(spec)
  else:
   dest,proof=imported_source(spec); continuation=[]
   # Add instrument-specific cover and source-unique provenance metadata.
   (dest/'figure.svg').write_text(figure(spec,'instrument'))
   report0={'source_files':len(proof),'source_sha256':{x['relative_path']:x['sha256'] for x in proof},'licence':spec['kind']}
   (dest/'samples/aria-v6-source-map.json').write_text(json.dumps(report0,indent=2)+'\n')
  reports.append(compile_and_audit(spec,dest,proof,continuation))
 print(json.dumps({'bank':str(BANK),'demo':str(DEMO),'sounds':[{'slug':r['slug'],'source_files':r['source_files'],'lint':r['lint'],'compiled_loop_zones':r.get('compiled_loop_zones',0),'loop_seam_max_db':r.get('loop_seam_max_db'),'native_previews':list(r.get('native_previews',{}))} for r in reports]},indent=2,default=str))
if __name__=='__main__': main()
