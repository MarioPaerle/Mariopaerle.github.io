"""Recorded Cage-prepared grand piano with a declared source-led modal continuation.

Run from repo root: python/.venv/bin/python python/scripts/build_aria_prepared.py
No shared bank metadata, other sounds, accounts or purchases are modified.
"""
from pathlib import Path
import argparse, hashlib, json, math, shutil, subprocess, urllib.request, zipfile
from collections import Counter
import numpy as np
import soundfile as sf
from scipy import signal, ndimage
from libero import Audio, analysis, dsp
from libero.compiler import compile_sound
from libero.lint import lint_bundle, _load
from libero.figure import validate_svg

HOME=Path.home(); CACHE=HOME/'Libero/cache/libraries/kurt-werner-prepared'
DEST=HOME/'Libero/banks/aria/piano-preparato'
PAGE='https://ccrma.stanford.edu/~kwerner/samples_such.html'
ZIP='https://ccrma.stanford.edu/~kwerner/kurt_james_werner_prepared_piano_samples.zip'
SHA='7dfbe100bad8854ee265c00d06d83861d7271e127c31c57ee831feae51b84b1a'
SR=48000

def fetch():
    CACHE.mkdir(parents=True,exist_ok=True)
    page=CACHE/'source-page.html'
    if not page.exists():page.write_bytes(urllib.request.urlopen(PAGE).read())
    assert 'Creative\nCommons Attribution 3.0' in page.read_text(), 'source license changed'
    z=CACHE/'kurt_james_werner_prepared_piano_samples.zip'
    if not z.exists():urllib.request.urlretrieve(ZIP,z)
    assert hashlib.sha256(z.read_bytes()).hexdigest()==SHA,'archive SHA mismatch'
    with zipfile.ZipFile(z) as f:
        for n in f.namelist():
            if n.startswith('__MACOSX/')or not n.lower().endswith(('.wav','.aif')):continue
            p=(CACHE/n).resolve();assert CACHE.resolve()in p.parents
            if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(f.read(n))

def modal_continue(a, root):
    """Keep the real strike, fit every significant recorded resonance, and freeze energy.

    This is a documented designed sustain, NOT a purported naturally endless piano.
    Stereo modal phases come from the same recording; no takes or instruments are mixed.
    The periodic IFFT contains the fitted source modes, rather than harmonic sinusoids
    invented from the MIDI fundamental. Its slow periodic gain prevents level breathing.
    """
    x=a.resample(SR).remove_dc(5).data.astype(np.float64)
    if x.ndim==1:x=np.column_stack([x,x])
    begin=.080; end=min(.70,len(x)/SR-.08)
    seg=x[int(begin*SR):int(end*SR)]
    win=np.hanning(len(seg));nfft=262144
    X=np.fft.rfft(seg*win[:,None],n=nfft,axis=0)
    power=np.mean(abs(X)**2,axis=1)
    freq=np.fft.rfftfreq(nfft,1/SR)
    # Late room/electrical background is not the excitation or human finger gesture.
    noise=x[-min(len(x),int(.6*SR)):]
    nw=np.hanning(len(noise));NX=np.fft.rfft(noise*nw[:,None],n=nfft,axis=0)
    floor=np.mean(abs(NX)**2,axis=1)*(win.sum()/max(nw.sum(),1e-12))**2
    peaks,_=signal.find_peaks(power,distance=max(1,int(1.3/(SR/nfft))))
    peaks=peaks[(freq[peaks]>25)&(freq[peaks]<min(16000,SR*.45))]
    peaks=peaks[(power[peaks]>power.max()*10**(-48/10))&(power[peaks]>floor[peaks]*10)]
    peaks=peaks[np.argsort(power[peaks])[-900:]]
    period=10.0 if root<60 else 8.0; N=int(period*SR)
    spec=np.zeros((N//2+1,2),dtype=np.complex128)
    modes=[]
    for k in peaks:
        logs=np.log(np.maximum(power[k-1:k+2],1e-30))
        frac=np.clip(.5*(logs[0]-logs[2])/(logs[0]-2*logs[1]+logs[2]+1e-30),-.5,.5)
        hz=(k+frac)*SR/nfft; dest=int(round(hz*period))
        if not 0<dest<N//2:continue
        # Recompute the actual complex projection at refined frequency, with a
        # common stereo phase reference. Frequency rounding is <=0.063Hz above C4.
        # The8x zero-padded FFT permits local complex interpolation, avoiding
        # hundreds of equivalent long scalar projections per source note.
        c=(X[k]*(1-abs(frac))+X[k+(1 if frac>=0 else -1)]*abs(frac))*2/win.sum()
        c*=np.exp(-2j*np.pi*hz*begin)
        spec[dest]+=N*c/2
        modes.append([round(hz,4),round(dest/period,4),round(20*np.log10(np.sqrt(np.mean(abs(c)**2))+1e-20),2)])
    if len(modes)<2:raise RuntimeError(f'no usable recorded resonances for root{root}')
    cycle=np.fft.irfft(spec,n=N,axis=0)
    # Periodic, slow common-channel correction preserves stereo and modal beating;
    # it changes energy, never pitch or the source's spectral/mode ratios.
    ef=np.fft.rfftfreq(N,1/SR)
    energy=np.fft.irfft(np.fft.rfft(np.mean(cycle**2,axis=1))*np.exp(-2*np.pi**2*.12**2*ef**2),n=N)
    env=np.sqrt(np.maximum(energy,1e-18))
    natural=np.sqrt(np.mean(x[int(.12*SR):int(.28*SR)]**2))*10**(-2/20)
    # Muted notes can die40dB beneath their own transient within200ms. An
    # endless designed resonance must remain audible: sustain floor is18dB
    # beneath that recording's real attack peak, not a boosted late noise floor.
    target=max(natural,np.max(abs(x[:int(.18*SR)]))*10**(-18/20))
    gain=target/env
    cycle*=gain[:,None]
    total=int((period+1.10)*SR)
    y=cycle[np.arange(total)%N].copy()
    # First180ms of the actual prepared strike are unchanged. The transition
    # ends650ms after note-on; no attack is periodically re-triggered.
    lo=int(.180*SR); hi=int(.650*SR)
    y[:lo]=x[:lo]
    u=np.linspace(0,1,hi-lo);u=u*u*(3-2*u)
    y[lo:hi]=x[lo:hi]*(1-u[:,None])+y[lo:hi]*u[:,None]
    pad=np.zeros((480,2));y=np.concatenate([pad,y])
    start=480+SR;stop=start+N
    # Both20ms windows before the seam are copies of exactly the same cyclic data.
    seam=10*np.log10(np.sum((y[start-960:start]-y[stop-960:stop])**2)/(np.sum(y[start-960:start]**2)*2+1e-20)+1e-20)
    blocks=cycle[:N//2400*2400].reshape(-1,2400,2)
    db=20*np.log10(np.sqrt(np.mean(blocks**2,axis=(1,2)))+1e-20)
    return Audio(y,SR),dict(start=start,end=stop),dict(mode_count=len(modes),modes=modes,source_window=[begin,end],original_attack_seconds=.180,transition_end_seconds=.650,loop_seconds=period,seam_db=float(seam),sustain_rms_db=float(20*np.log10(target+1e-20)),sustain_floor_lift_db=float(20*np.log10(target/(natural+1e-20))),level_span_50ms_db=float(np.ptp(db)),source_mono_loss_db=float(10*np.log10(np.mean(x.mean(axis=1)**2)/(np.mean(x*x)+1e-20)+1e-20)),modal_mono_loss_db=float(10*np.log10(np.mean(cycle.mean(axis=1)**2)/(np.mean(cycle*cycle)+1e-20)+1e-20)))

def figure(audits):
    # A prepared grand seen in plan. String spacing follows measured dominant
    # modes of D3; the intercepted string is the physical preparation, in gold.
    modes=audits['D3.wav']['modes'];strong=sorted(modes,key=lambda m:m[2],reverse=True)[:12]
    freqs=sorted(m[0]for m in strong); logs=np.log(np.maximum(freqs,25));xs=145+(logs-logs.min())/(logs.max()-logs.min()+1e-20)*188
    rim='M123 417 L122 135 Q139 79 199 73 Q277 52 354 116 Q406 165 389 228 Q371 273 334 303 Q300 334 321 417 Z'
    parts=[f'<path d="{rim}" stroke="currentColor" stroke-width="1.3"/>', '<path d="M131 409 L130 139 Q146 87 200 81 Q274 60 348 122 Q398 170 381 226 Q363 272 327 302 Q292 334 313 409" stroke="currentColor" stroke-width=".8"/>']
    # Curved soundboard grain, following the casing instead of a flat wash.
    for i in range(16):parts.append(f'<path d="M{156+i*7} 108 Q{197+i*5} {145+i*3} {181+i*8} 380" stroke="currentColor" stroke-width=".4"/>')
    for xx,f in zip(xs,freqs):
        tip=118+155*(freqs[0]/f)**.24
        parts.append(f'<path d="M{xx:.1f} 392 L{xx:.1f} {tip:.1f}" stroke="currentColor" stroke-width=".75"/>')
        parts.append(f'<circle cx="{xx:.1f}" cy="{tip:.1f}" r="2.2" fill="#f3eee6" stroke="currentColor" stroke-width=".7"/>')
    parts+=['<path d="M145 354 Q218 345 298 325 M145 360 Q218 351 300 331" stroke="currentColor" stroke-width=".9"/>', '<path d="M230 199 L265 207 L261 219 L227 211 Z" fill="#f3eee6" stroke="#b8924f" stroke-width="1.3"/>', '<path d="M233 202 L258 208 M232 206 L257 212 M240 201 L237 211 M250 204 L247 214" stroke="#b8924f" stroke-width=".55"/>']
    for i in range(21):parts.append(f'<path d="M{324+i*2.4:.1f} {140+i*2:.1f} q25 32 4 65" stroke="currentColor" stroke-width=".45"/>')
    parts+=['<path d="M123 399 L316 399 L321 417 L123 417 Z" fill="#f3eee6" stroke="currentColor" stroke-width="1.2"/>']
    parts+=['<path d="'+' '.join(f'M{125+i*3} 400 L{139+i*3} 416'for i in range(57))+'" stroke="currentColor" stroke-width=".5"/>']
    parts+=['<path d="'+' '.join(f'M{195+i*4} 416 L{209+i*4} 400'for i in range(24))+'" stroke="currentColor" stroke-width=".5"/>']
    desc=f'Piano a coda preparato del CCRMA visto in pianta: dodici corde seguono i modi più forti del D3 registrato, da{freqs[0]:.0f} a{freqs[-1]:.0f}Hz, su spaziatura logaritmica. Il solo oggetto dorato intercetta una corda, indicando la preparazione fisica. Il piede di18unità corrisponde ai180ms di attacco reale conservato; la distanza di8unità fra i bordi indica il ciclo di risonanza di8s. La grana segue la tavola e la fascia scura il telaio.'
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>Piano Preparato</title><desc>'+desc+'</desc>'+''.join(parts)+'</svg>'

def build():
    fetch()
    if DEST.exists()and not(DEST/'samples/prepared-map.json').exists()and not(DEST/'builder-owner.json').exists():
        backup=HOME/'Libero-backups/2026-10-03/aria-v2/piano-preparato-before'
        assert not backup.exists(),backup
        backup.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(DEST,backup,symlinks=False)
    S=DEST/'samples';(S/'originals').mkdir(parents=True,exist_ok=True);(S/'continuations').mkdir(exist_ok=True)
    (DEST/'builder-owner.json').write_text(json.dumps({'builder':'build_aria_prepared.py','source':PAGE})+'\n')
    unique={};audits={};rows=[];allfiles=sorted([*CACHE.glob('*.wav'),*CACHE.glob('*.aif')],key=lambda f:('-1'in f.stem,f.name))
    for f in allfiles:
        q=S/'originals'/f.name
        if not q.exists():q.symlink_to(f)
        h=hashlib.sha256(f.read_bytes()).hexdigest()
        if h in unique:audits[f.name]=dict(duplicate_of=unique[h]);continue
        unique[h]=f.name
        stem=f.stem;root=dsp.parse_note(stem.replace('_sus',''));sus='_sus'in stem
        a=Audio.load(f,sr=SR);derived,lp,audit=modal_continue(a,root)
        audit.update(source=str(f),source_sha256=h,source_seconds=a.duration,source_peak_db=a.peak_db,source_clipped_samples=int(np.sum(abs(a.data)>=.99999)),root=root,pedal=sus)
        out=S/'continuations'/(stem+'.flac');derived.save(out,subtype='PCM_24')
        audits[f.name]=audit
        print(f.name,'recorded modes',audit['mode_count'],'loop',audit['loop_seconds'],'s',flush=True)
        rows.append(dict(file=str(out.relative_to(S)),root=root,lo=root,hi=root,dyn=[0,1],take=0,loop=lp,pitched=True,pedal=sus,original=f.name))
    # Pedal and no-pedal are techniques, never fabricated velocity layers.
    dry={r['root']:r for r in rows if not r['pedal']};wet={r['root']:r for r in rows if r['pedal']}
    mapped=[]
    for art,lookup in [('pedale',{**dry,**wet}),('asciutto',dry)]:
        roots=sorted(lookup)
        for i,root in enumerate(roots):
            r=lookup[root].copy();r['articulation']=art
            r['lo']=root if i==0 else(roots[i-1]+root)//2+1
            r['hi']=root if i==len(roots)-1 else(root+roots[i+1])//2
            r.pop('pedal');r.pop('original');mapped.append(r)
    (S/'prepared-map.json').write_text(json.dumps(mapped,indent=2)+'\n');(S/'source-proof.json').write_text(json.dumps(audits,indent=2)+'\n')
    credit=dict(source='CCRMA prepared grand piano, October2011',author='Kurt James Werner',license='CC BY 3.0',license_class='by',url=PAGE,retrieved='2026-10-03',files=[f.name for f in allfiles])
    (S/'credits.json').write_text(json.dumps([credit],indent=2)+'\n')
    shutil.copy2(CACHE/'source-page.html',S/'source-page.html')
    (S/'ATTRIBUTION.md').write_text(f'Prepared Piano samples by Kurt James Werner, recorded October2011 on CCRMA Stanford stage. {PAGE}\nLicense CC BY3.0: https://creativecommons.org/licenses/by/3.0/\nChanges:48kHz conversion, DC removal, unchanged recorded first180ms, declared dense modal sustain fitted to each original recording and held indefinitely, bounded level calibration; no recording mixed with another. Original notes and pedal variants retained. D3-1 is byte-identical to D3 and stays in originals, not falsely labelled as another take. No endorsement implied.\n')
    (DEST/'sound.py').write_text('''"""Actual Cage-prepared CCRMA grand, with declared source-led endless sustain."""
import json
from pathlib import Path
from libero import Sound
sound=Sound(title='Piano Preparato',subtitle='CCRMA2011 · corde preparate per Cage · risonanza tenuta',tags=['piano','prepared','acoustic','sampled'],sample_rate=48000)
sound.articulations([{'id':'pedale','name':'Corde aperte','key':12},{'id':'asciutto','name':'Senza pedale','key':13}])
regions=json.loads((Path(__file__).parent/'samples/prepared-map.json').read_text())
sound.multisample('body',regions,process={'tune':'source','ladder':'smooth','ladder_max_db':3,'peak_db':-12,'align_ms':0,'pre_ms':10,'loop':'source','end_db':-100,'max_seconds':None,'edge_fill':False,'encoding':'flac24'})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={'cents':0,'ms':0,'db':0},onset_ms=10,one_shot=False)
sound.defaults(mode='Poli',glide=0,voices=16,artic=0,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=550,lvl_body=0,lvl_tail=-60,lvl_air=-60,vel_sens=.55,humanize=0,master=-1,tape_wow=0,tape_flutter=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,rev_mode='Cappella',rev_mix=.04,rev_decay=1.2,rev_size=.35,rev_damp=.5)
''')
    svg=figure(audits);assert not validate_svg(svg);(DEST/'figure.svg').write_text(svg)
    count=Counter(r['articulation']for r in mapped)
    (DEST/'notes.md').write_text(f'''# Piano Preparato — 3 ottobre2026

Sperimentale · accordi/texture · REC. Pianoforte a coda sul palco CCRMA Stanford, già preparato per Sonatas and Interludes for Prepared Piano di John Cage. Kurt James Werner registrò ogni nota alterata con ZoomH4n stereo nell’ottobre2011. Sono corde realmente preparate, non un piano normale con effetti. La fonte non identifica oggetto e posizione di ogni singola preparazione: non si attribuiscono bulloni/feltri specifici senza prova.

## Registrazioni e tecnica

69 file originali preservati,68 unici:43 senza pedale e25 con pedale. D3-1 identico byte per byte aD3, mantenuto negli originali ma non chiamato RR. Una sola intensità, un solo take, nessuna release separata: velocity controlla ampiezza, non inventa timbri o dinamiche. {dict(count)} zone su43 radici D1–F7, registri intermedi per radice più vicina. Nella tecnica C0 Corde aperte si usano le25 vere registrazioni con pedale; per le18 radici prive di registrazione con pedale si usa la vera registrazione senza pedale. C#0 seleziona tutte le43 senza pedale.

## Tenuta infinita richiesta

Il pianoforte preparato reale decade; molte note smorzate muoiono in mezzo secondo. Tenere il rumore tardivo in loop avrebbe rialzato hiss invece della risonanza. Primo180ms dell’attacco registrato invariato dopo conversione/DC; passaggio180–650ms a una continuazione modale derivata solo dalla stessa nota: proiezioni complesse sui picchi significativi del suo spettro reale80–700ms, fondo tardivo misurato ed escluso. Frequenze inarmoniche e fasi relative stereo dalla registrazione, nessuna serie armonica inventata dal MIDI, nessun secondo take o oscillatore sotto il piano. Ciclo8s (10s sottoC4), tutti i modi significativi sopra il fondo; envelope comune L/R lento e periodico impedisce pompaggi di livello. Per rendere udibile la sola risonanza tenuta delle note molto mute, il suo RMS non scende sotto18dB rispetto al picco del proprio attacco originale; non viene amplificato il rumore tardivo. È un sustain progettato e dichiarato, non una falsa registrazione infinita. Nessun wow/flutter, chorus, pitch modulation o retrigger dell’attacco nel loop. Le ultime20ms prima del wrap sono identiche alle20ms prima dell’inizio del ciclo. Il periodo conserva battimenti e complessità modale, pur rendendo inevitabilmente periodica l’estensione.

Intonazione intenzionalmente originale: preparazione cambia/subdivide i modi, per esempio D1 ha forti modi110.8/146.1/440.7/1057Hz, C4 un modo171.8Hz. Non si rinomina o rettifica ogni rumore metallico come un fondamentale equal-tempered: si conservano i tasti originali dell’autore. Nessun flattening della preparazione. Livello globale peak−12dBFS e piccoli aggiustamenti≤3dB, Poli/glide0, room4%, amp_sustain1 e release550ms.

## Licenza e limiti

Kurt James Werner: {PAGE}. CC BY3.0, https://creativecommons.org/licenses/by/3.0/. source-proof.json documenta ogni file, hash, spettro, metodi e variante; credits e ATTRIBUTION nominano autore e cambiamenti. Alcuni attacchi della sorgente originale hanno picchi prossimi0dBFS; non si spaccia questo materiale per una ripresa perfetta. Una sola dinamica e assenzaRR limitano le ribattute. Posso misurare/renderizzare/ispezionare, non ascoltare: nessuna affermazione di parità SkyKeys/Omnisphere o di calore dedotta dal lint.
''')
    res=compile_sound(DEST,jobs=6);print(res.text(),flush=True)
    if not res.ok:raise RuntimeError(res.text())
    qa(audits)

def qa(audits=None):
    b=DEST/'build';m=json.loads((b/'manifest.json').read_text())
    findings=lint_bundle(b);txt='\n'.join(f.line()for f in findings);(DEST/'lint.txt').write_text(txt+'\n');print(txt,flush=True)
    stats=[]
    renderer=str(HOME/'.local/bin/libero-render')
    demos={'preview':'12:0:.01:100,50:.05:.7:35,60:1:.8:70,72:2:.8:115,60:3:.2:85,60:3.3:.2:85,60:3.6:.2:85,60:3.9:.2:85,26:4.5:2:100,101:7:2:100,60:10:2.5:100,64:10:2.5:100,67:10:2.5:100,13:14:.01:100,50:14.05:1:75,72:15.5:1:110',
      'held-low':'12:0:.01:100,26:.05:60:100','held-mid':'12:0:.01:100,60:.05:60:100','held-high':'12:0:.01:100,101:.05:60:100','held-dry':'13:0:.01:100,60:.05:30:100','held-octave':'12:0:.01:100,72:.05:60:100'}
    for name,notes in demos.items():
        f=b/(name+'.wav')
        subprocess.run([renderer,'--sound',str(DEST),'--out',str(f),'--notes',notes,'--tail','2'],check=True,capture_output=True)
        x,sr=sf.read(f,always_2d=True);assert abs(x).max()<1
        mono=x.mean(axis=1);rec=dict(file=str(f),seconds=len(x)/sr,peak_db=float(20*np.log10(abs(x).max()+1e-20)),clipped=int(np.sum(abs(x)>=1)),mono_loss_db=float(10*np.log10(np.mean(mono**2)/(np.mean(x*x)+1e-20)+1e-20)))
        if name.startswith('held'):
            frames=x[int(12*sr):int((28 if name=='held-dry' else 58)*sr)];blocks=frames[:len(frames)//(sr//2)*(sr//2)].reshape(-1,sr//2,2);db=20*np.log10(np.sqrt(np.mean(blocks*blocks,axis=(1,2)))+1e-20);rec['held_rms_500ms_span_db']=float(np.ptp(db));rec['held_rms_500ms_min_db']=float(db.min())
        (b/(name+'.png')).write_bytes(analysis.spectrogram(Audio(x,sr),title='Piano Preparato · '+name));stats.append(rec)
    seams=[]
    for z in m['zones']:
        d=_load(b,z,False);seams.append(d.loop_seam_db)
    proof=audits or json.loads((DEST/'samples/source-proof.json').read_text());real=[a for a in proof.values()if 'duplicate_of'not in a]
    ram=sum(sf.info(b/z['file']).frames*sf.info(b/z['file']).channels*4 for z in m['zones'])
    counts=Counter(f.level for f in findings)
    report=dict(source=PAGE,license='CC BY3.0',zones=len(m['zones']),unique_recordings=len(real),dry_recordings=sum(not a['pedal']for a in real),pedal_recordings=sum(a['pedal']for a in real),modes_min=min(a['mode_count']for a in real),modes_max=max(a['mode_count']for a in real),loop_seconds=[8,10],worst_loop_seam_db=max(s for s in seams if s is not None),decoded_ram_mib=ram/2**20,lint_counts={k:counts[k]for k in ['FAIL','WARN','INFO']},native_previews=stats,limitation='one dynamic/one take, intentional inharmonic preparation, source-led modal hold; no actual listening or premium-quality claim')
    report['source_comparison']=references(proof)
    (DEST/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    npth=DEST/'notes.md';base=npth.read_text().split('\n## Verifica tecnica\n')[0]
    npth.write_text(base+'\n## Verifica tecnica\n\n'+txt+'\n\n'+json.dumps(report,indent=2)+'\n\nWARN layers/takes: unico livello/take della fonte; non inventati. WARN release: nessun rilascio isolato registrato, tenuta modale finisce con AR550ms. WARN tuning: modi inarmonici intenzionali, non corretti come errori. WARN loudness: diverse preparazioni hanno eccitazioni diverse, correzione limitata. I sei WARN aliasing misurano energia originale sopra18kHz negli attacchi indicati: si conserva quel dettaglio; possono esserci limiti nel trasporlo verso l’alto. La tenuta modale usa modi sotto16kHz. Non si afferma assenza assoluta di aliasing.\n')
    print(json.dumps(report,indent=2),flush=True)
    assert not counts['FAIL'],'see lint.txt for unresolved failures'
    assert report['worst_loop_seam_db']<=-30,'loop seam above delivery threshold'

def references(proof):
    """Audition the source truth against continuation, matched on the real attack."""
    out=HOME/'Libero/cache/refs/piano-preparato';out.mkdir(parents=True,exist_ok=True)
    clips=[];rows=[]
    for n in ['D3_sus.wav','C4_sus.wav','C5_sus.wav','F7.wav']:
        a=Audio.load(CACHE/n,sr=SR).remove_dc(5).data
        d=Audio.load(DEST/'samples/continuations'/(Path(n).stem+'.flac'),sr=SR).data[480:]
        gain=10**(-29/20)/(np.sqrt(np.mean(a[:8640]**2))+1e-20)
        pair=[]
        for x in [a,d]:
            y=np.zeros((SR*4,2));block=x[:SR*4];y[:len(block)]=block*gain;y[-2400:]*=np.linspace(1,0,2400)[:,None]
            assert abs(y).max()<1
            pair.extend([y,np.zeros((SR//2,2))])
        corr=np.corrcoef(a[:8640].ravel(),d[:8640].ravel())[0,1]
        rows.append(dict(source=n,sequence='original4s / continued4s',gain_db=float(20*np.log10(gain)),first180ms_correlation=float(corr)))
        clips.extend(pair)
    x=np.concatenate(clips);sf.write(out/'source-then-hold.wav',x,SR,subtype='PCM_24')
    (out/'source-then-hold.png').write_bytes(analysis.spectrogram(Audio(x,SR),title='Originale / tenuta · D3,C4,C5,F7 · attacchi matched'))
    differences=[abs(1200*math.log2(m[1]/m[0]))for a in proof.values()if 'modes'in a for m in a['modes']]
    meta=dict(pairs=rows,max_modal_frequency_rounding_cents=max(differences),license='Kurt James Werner, CC BY3.0',source=PAGE)
    (out/'comparison.json').write_text(json.dumps(meta,indent=2)+'\n')
    return meta

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--qa-only',action='store_true');args=ap.parse_args()
    qa()if args.qa_only else build()
