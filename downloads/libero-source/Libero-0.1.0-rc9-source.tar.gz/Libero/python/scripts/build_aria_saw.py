"""Original live subtractive saw: continuous oscillator sustain, no sampled short loop."""
from pathlib import Path
import sys,json,shutil
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero.compiler import compile_sound
from libero import render,analysis
from libero.lint import lint_bundle
DEST=Path.home()/'Libero/banks/aria/saw-rame';DEST.mkdir(parents=True,exist_ok=True)
OUT=Path.home()/'Libero/demo/aria-v4/saw-rame';OUT.mkdir(parents=True,exist_ok=True)
(DEST/'sound.py').write_text('''from libero import Sound
sound=Sound(title="Saw · Rame",subtitle="sega analogica viva · centro solido e bordi mobili",tags=["aria","saw","warm","live-synthesis","infinite"],roots=[36,48,60,72,84],seed=9317)
sound.defaults(mode="Poli",glide=0,voices=16,master=-7,vel_sens=.45,
 amp_attack=14,amp_decay=1000,amp_sustain=1,amp_release=480,
 osc1_wave="Sega",osc1_level=-13,osc1_oct=0,osc1_fine=0,osc1_voices=1,osc1_detune=0,osc1_spread=0,osc1_phase=0,
 osc2_wave="Sega",osc2_level=-23,osc2_oct=0,osc2_fine=-2.7,osc2_voices=7,osc2_detune=.29,osc2_spread=.38,osc2_phase=0,
 sub_wave="Seno",sub_level=-32,osc_drift=.12,osc_retrig="Libera",
 flt_mode="Basso",flt_cutoff=2300,flt_reso=.09,flt_key=.55,flt_vel=.18,flt_env=.12,
 fenv_source="Propria",fenv_attack=12,fenv_decay=1100,fenv_sustain=.45,fenv_release=360,
 lfo_shape="Seno",lfo_rate=.11,lfo_cutoff=.06,lfo_pitch=0,lfo_amp=0,
 drive=.075,res_mix=0,echo_mix=0,tape_wow=0,tape_flutter=0,tape_mix=0,tape_sat=0,tape_age=0,
 rev_mode="Cappella",rev_mix=.055,rev_size=.32,rev_decay=1.1,rev_predelay=12,rev_damp=.62,rev_shimmer=0,
 lvl_body=-60,lvl_attack=-60,lvl_tail=-60,lvl_air=-60)
''')
(DEST/'notes.md').write_text('''# Saw · Rame

Original live subtractive synthesis. A central band-limited saw oscillator, plus a quieter seven-voice saw group spread by ±5.05 cents; central low/mid body, gradual filtered attack and a slow subtle filter movement. The primary oscillator stays at concert pitch. No sampled oscillation, short loop, wow or added phase-offset widening. Oscillators continue as long as a key remains held; release follows MIDI note-off. The small sine sub supplies weight below the main saw and is intentionally quieter than it.

Velocity changes level and filter opening. Defaults are polyphonic with no glide. Minimal live room is adjustable. Author: original Libero design for this session. Code/data may be reused under CC0; no external recordings.

Numbers diagnose clipping, stability, mono and sustain behavior. They do not certify perceived warmth or taste.
''')
(DEST/'figure.svg').write_text('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>Saw · Rame</title><desc>Un mantice di rame: una piega centrale, sette secondarie e una camera centrale per il fondamentale.</desc><path d="M102 179H410V340H102Z" fill="#f3eee6" stroke-width="1.3"/><path d="M86 188V331H69V188ZM426 188V331H443V188Z" stroke-width="1.3"/><g stroke-width="1.1"><path d="M133 184L151 210V310L133 335M169 184L187 210V310L169 335M205 184L223 210V310L205 335M241 184L259 210V310L241 335M277 184L295 210V310L277 335"/><path d="M311 184L322 210V310L311 335M337 184L348 210V310L337 335M363 184L374 210V310L363 335"/></g><g stroke-width=".45"><path d="M111 197H123M111 214H135M111 231H135M111 248H135M111 265H135M111 282H135M111 299H135M111 316H123M303 218H318M303 235H318M303 252H318M303 269H318M303 286H318M303 303H318"/></g><path d="M241 188L259 212V308L241 331" stroke="#b8924f" stroke-width="1.4"/><path d="M106 353H406M119 363H393M131 155H381" stroke-width=".7"/></svg>''')
c=compile_sound(DEST)
if not c.ok:raise RuntimeError(c.text())
findings=[f.line() for f in lint_bundle(DEST/'build')];rows={}
for name,notes,tail in [('phrase','48:0:.5:40,55:.65:.4:80,60:1.2:.65:115,64:2:.5:95,67:2.7:1.3:120',1.5),('chord','48:0:4:127,55:0:4:120,60:0:4:110,64:0:4:100',2),('held60','60:0:60:100',2),('registers','36:0:1:100,48:1.5:1:100,60:3:1:100,72:4.5:1:100,84:6:1:100',1.5)]:
 pv=render.preview('saw-rame',notes,tail=tail);shutil.copy2(pv.wav,OUT/(name+'.wav'));rows[name]=analysis.features(pv.audio)
 print(name,rows[name]['peak_db'],flush=True)
(OUT/'spectrogram.png').write_bytes(analysis.spectrogram(pv.audio,title='Saw · Rame — registri'))
(OUT/'verification.json').write_text(json.dumps({'compile_warnings':c.warnings,'lint':findings,'native':rows},indent=2)+'\n')
