#!/usr/bin/env python3
"""Sequential validation, phrase renders, 4-note chord and 12-second holds for Aria v2."""
from __future__ import annotations
import json, shutil, sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'python'))
from libero import analysis, library, render
from libero.recipe import load_recipe
from libero.compiler import compile_sound
from libero.lint import lint_bundle
BANK=library.home()/'banks'/'aria'; OUT=BANK/'_reports'/'previews'; OUT.mkdir(parents=True,exist_ok=True)
SLUGS=['velluto-arco','fiato-fuso','plettro-ambra','legno-risonante','soffio-di-sax','plettro-vivo','pizzicato-seta','colpo-di-legno']
PADS=set(SLUGS[:4]); PHRASE='48:0:0.65:1,55:0.8:0.5:65,60:1.4:0.7:127,64:2.2:0.55:38,67:2.95:1.1:116,72:4.2:0.7:100,60:5.1:0.7:1,67:5.8:0.55:127,72:6.45:0.6:72'
CHORD='48:0:2.8:127,55:0:2.8:112,60:0:2.8:100,64:0:2.8:88'

def ft(slug,phrase,name):
    pv=render.preview(slug,phrase,tail=1.8)
    shutil.copy2(pv.wav,OUT/f'{slug}-{name}.wav')
    (OUT/f'{slug}-{name}.png').write_bytes(analysis.spectrogram(pv.audio,title=f'{slug} · {name}'))
    return analysis.features(pv.audio)

def formatted(features, label):
    return analysis.format_features(features,label).replace("\n", "  \n")

def body_motion(slug):
    """Diagnostic only: compare the source-derived body before/after its gesture."""
    snd=load_recipe(library.find_sound(slug))
    a=snd.render('body',60,112,take=0,dyn=.55).to_mono()
    y=a.data.astype(np.float64); sr=a.sr
    out={}
    for label,t0,t1 in [('1–2 s',1.0,2.0),('5–8 s',5.0,8.0)]:
        x=y[int(t0*sr):int(t1*sr)]
        rms=float(np.sqrt(np.mean(x*x))+1e-20)
        win=np.hanning(len(x)); spec=np.abs(np.fft.rfft(x*win))**2
        freqs=np.fft.rfftfreq(len(x),1/sr)
        centroid=float(np.sum(freqs*spec)/max(np.sum(spec),1e-20))
        lo=float(spec[(freqs>=200)&(freqs<=1500)].sum()/max(spec.sum(),1e-20))
        partial_levels=[]
        fundamental=261.6256
        # The marimba's strongest source modes are genuinely inharmonic.
        # Measure those calibrated modal bands instead of falsely reporting
        # a nearly empty harmonic series for a spectrally rich body.
        ratios=([1.0,2.76,4.12,5.43,6.90] if slug=='legno-risonante' else [float(k) for k in range(1,19)])
        for ratio in ratios:
            band=spec[(freqs>=fundamental*ratio*.988)&(freqs<=fundamental*ratio*1.012)]
            partial_levels.append(float(band.max()) if len(band) else 0.0)
        maximum=max(partial_levels+[1e-30])
        count=sum(v>=maximum*10**(-36/10) for v in partial_levels)
        out[label]={'rms_dbfs':float(round(20*np.log10(rms),1)),'centroid_hz':int(round(centroid)),'mid_share':float(round(lo,3)),'partials_above_-36dB':int(count)}
    return out

def main():
    rows=[]
    for slug in SLUGS:
        folder=library.find_sound(slug)
        comp=compile_sound(folder)
        if not comp.ok: raise SystemExit(f'{slug}: {comp.text()}')
        findings=lint_bundle(folder/'build'); fails=[f.line() for f in findings if f.level=='FAIL']; warns=[f.line() for f in findings if f.level=='WARN']
        if fails: raise SystemExit(f'{slug}: ' + '; '.join(fails))
        phrase=ft(slug,PHRASE,'phrase')
        soft=ft(slug,'60:0:1.0:1','soft-note'); hard=ft(slug,'60:0:1.0:127','forte-note')
        chord=ft(slug,CHORD,'forte-chord') if slug in PADS else None
        held=ft(slug,'60:0:12.0:112','held-12s') if slug in PADS else None
        motion=body_motion(slug) if slug in PADS else None
        manifest=json.loads((folder/'build'/'manifest.json').read_text())
        rows.append({'slug':slug,'role':'pad' if slug in PADS else 'lead','zones':len(manifest['zones']),'compile':comp.warnings,'warns':warns,'phrase':phrase,'soft':soft,'hard':hard,'chord':chord,'held':held,'motion':motion})
        print(f"{slug}: {len(manifest['zones'])} zones; {len(comp.warnings)} compile warnings; {len(warns)} lint warnings; phrase peak {phrase['peak_db']:.2f}; soft/hard centroid {soft.get('centroid_hz')} / {hard.get('centroid_hz')}; chord peak {chord.get('peak_db') if chord else '—'}")
    lines=['# Aria v2 — validazione e ascolto','','Validazione sequenziale: compilazione, lint, frase melodica a dinamiche estreme, note singole soft/forte, accordo di quattro note sui pad e note sostenute di 12 s. Le misure sono diagnostiche; l’ascolto matched-level resta il criterio musicale. Tutti i preset hanno Poli, glide 0, wow/flutter 0.','','| Voce | Ruoli | Zone | Compile warnings | Lint | Frase picco | Soft → forte centroide | Accordo 4 note | Hold 12 s |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        chord=f"{r['chord']['peak_db']:.2f} dBFS" if r['chord'] else '—'; hold=f"{r['held']['peak_db']:.2f} dBFS" if r['held'] else '—'
        lines.append(f"| {r['slug']} | {r['role']} | {r['zones']} | {len(r['compile'])} | {len(r['warns'])} WARN / 0 FAIL | {r['phrase']['peak_db']:.2f} dBFS | {r['soft'].get('centroid_hz')} → {r['hard'].get('centroid_hz')} Hz | {chord} | {hold} |")
    lines+=['','## Avvisi e misure dettagliate','']
    for r in rows:
        lines += [f"### {r['slug']}",'']
        lines += [f"- Compile: {', '.join(r['compile']) if r['compile'] else 'nessun warning'}",f"- Lint: {'; '.join(r['warns']) if r['warns'] else 'nessun warning o fail'}",f"- Nota soft: {formatted(r['soft'],'Soft')}",f"- Nota forte: {formatted(r['hard'],'Forte')}"]
        if r['chord']: lines.append(f"- Accordo: {formatted(r['chord'],'Accordo')}")
        if r['held']: lines.append(f"- Tenuta 12 s: {formatted(r['held'],'Tenuta')}")
        if r['motion']: lines.append(f"- Movimento del body, render diretto senza effetti live: {r['motion']}")
        lines.append('')
    lines += ['## Figure e preview','','I WAV e PNG della frase, delle dinamiche e delle tenute sono salvati in `_reports/previews/`.','','Rigenerazione: `python/.venv/bin/python python/scripts/build_aria_v2.py` e `python/.venv/bin/python python/scripts/build_aria_v2_qa.py`.']
    report=BANK/'_reports'/'REPORT.md'; report.write_text('\n'.join(lines)+'\n'); print(f'QA report: {report}')
if __name__=='__main__': main()
