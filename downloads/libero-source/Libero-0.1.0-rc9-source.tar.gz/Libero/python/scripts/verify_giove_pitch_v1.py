#!/usr/bin/env python3
"""Native-engine pitch map audit for Giove presets (live Theremin LFO off)."""
import json, math, sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from libero.render import render
from libero.audio import Audio

BANK=Path.home()/'Libero/banks/giove'; OUT=Path.home()/'Libero/demo/giove-v1'; OUT.mkdir(parents=True,exist_ok=True)
SLUGS=['theremin-vetro','theremin-ambra','trautonium-due-formanti','volkstrautonium-manuale','mixturtrautonium-quarta-aperta','mixturtrautonium-frange']
SR=48000; DUR=.42; STEP=.44
def freq_note(n): return 440*2**((n-69)/12)
def cents(f,target): return 1200*math.log2(f/target)
def peak_near(x,sr,target,lo=.985,hi=1.015):
    x=np.asarray(x,dtype=np.float64)
    if len(x)<256 or not np.isfinite(x).all() or float(np.sqrt(np.mean(x*x)))<1e-6: return None
    x=x*np.hanning(len(x)); nfft=1
    while nfft<len(x): nfft*=2
    nfft*=8
    mag=np.abs(np.fft.rfft(x,n=nfft)); freqs=np.fft.rfftfreq(nfft,1/sr)
    inds=np.flatnonzero((freqs>=target*lo)&(freqs<=target*hi))
    if not len(inds): return None
    k=int(inds[np.argmax(mag[inds])]);
    if 0<k<len(mag)-1:
        a,b,c=np.log(np.maximum(mag[k-1:k+2],1e-30)); den=a-2*b+c
        delta=.5*(a-c)/den if abs(den)>1e-15 else 0
    else: delta=0
    return float((k+delta)*sr/nfft)

rows=[]; all_bad=[]
for slug in SLUGS:
    folder=BANK/slug; manifest=json.loads((folder/'build'/'manifest.json').read_text())
    if slug.startswith('theremin-'):
        events=[(n,v) for n in range(36,85) for v in (36,116)]
        params={'mode':'Poli','voices':16,'lfo_pitch':0,'lfo_delay':0,'amp_attack':0,'amp_release':8}
        route='live oscillators; measured with pitch LFO disabled across every MIDI key 36–84 at soft/loud velocity'
    else:
        rootmax=72 if slug.startswith(('trautonium','volkstrautonium')) else 84
        events=[(n,v) for n in range(36,rootmax+1,3) for v in (36,80,116)]
        params={'mode':'Poli','voices':16,'lfo_pitch':0,'lfo_delay':0,'amp_attack':0,'amp_release':8}
        route='compiled root/velocity cells measured in native engine'
    notes=','.join(f'{n}:{i*STEP:.4f}:{DUR}:{v}' for i,(n,v) in enumerate(events))
    out=OUT/f'{slug}-pitch-native.wav'; info=render(folder/'build',out,notes,params=params,tail=.15)
    audio=Audio.load(out); samples=np.asarray(audio.data,dtype=np.float64)
    if samples.ndim>1:samples=samples.mean(axis=1)
    errors=[]; missing=[]
    for i,(n,v) in enumerate(events):
        start=int((i*STEP+.08)*SR); end=int((i*STEP+.34)*SR)
        segment=samples[start:min(end,len(samples))]
        carrier=peak_near(segment,SR,freq_note(n))
        if carrier is None:
            missing.append({'note':n,'velocity':v}); continue
        err=cents(carrier,freq_note(n))
        errors.append({'note':n,'velocity':v,'carrier_hz':round(carrier,5),'cents':round(err,3)})
        if abs(err)>5:all_bad.append({'slug':slug,'note':n,'velocity':v,'cents':round(err,3)})
    branches=[]
    if slug.startswith('mixturtrautonium-'):
        divs=[1,2,3,4] if slug.endswith('aperta') else [1,2,4,7]
        for note in (36,60,84):
            for div in divs:
                target=freq_note(note)/div
                # Find a single isolated native render for an unbiased branch reading.
                test=OUT/f'{slug}-branch-{note}-{div}.wav'
                # The lowest divider output is only ~9–16 Hz, so give it a
                # longer capture; sub-second FFTs cannot resolve that branch
                # accurately enough to make a cents claim.
                bi=render(folder/'build',test,f'{note}:0:4:116',params=params,tail=.05)
                ba=Audio.load(test); bx=np.asarray(ba.data,dtype=np.float64)
                if bx.ndim>1:bx=bx.mean(axis=1)
                seg=bx[int(1.0*SR):int(3.6*SR)]
                measured=peak_near(seg,SR,target,.94,1.06)
                branches.append({'note':note,'divider':div,'target_hz':round(target,5),'measured_hz':round(measured,5) if measured else None,'cents':round(cents(measured,target),3) if measured else None})
                test.unlink(missing_ok=True)
    row={'slug':slug,'source_hash':manifest.get('source_hash'),'route':route,'native_render':str(out),'events_expected':len(events),'events_measured':len(errors),'missing':missing,'carrier_cents_min':round(min((e['cents'] for e in errors),default=0),3),'carrier_cents_max':round(max((e['cents'] for e in errors),default=0),3),'carrier_abs_cents_max':round(max((abs(e['cents']) for e in errors),default=0),3),'measurements':errors,'mixtur_divider_branches':branches,'engine':info}
    rows.append(row); print(slug,row['events_measured'],'/',row['events_expected'],'carrier max cents',row['carrier_abs_cents_max'],'missing',len(missing),flush=True)
(OUT/'pitch-native-report.json').write_text(json.dumps({'method':'native Libero render at 48 kHz; FFT log-parabolic peak interpolation on 260 ms stable window; Theremin pitch LFO disabled at all MIDI keys 36–84 and velocities 36/116; sampled synth roots checked at each mapped root and all three velocity layers. Mixtur divisors are measured separately at low/mid/high anchors.','threshold_cents':5,'errors_over_threshold':all_bad,'presets':rows},indent=2,ensure_ascii=False)+'\n')
