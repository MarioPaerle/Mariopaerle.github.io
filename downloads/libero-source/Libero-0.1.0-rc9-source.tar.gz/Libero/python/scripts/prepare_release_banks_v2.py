"""Prepare a fresh data candidate from audited presets; keep restricted Mellotrons separate."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
from libero import library, licenses


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    out = args.output.expanduser().resolve()
    if out.exists():
        parser.error("output exists; use a fresh directory")
    home = library.home()
    previous = home / "demo/release-replacements-v1/candidate-51/catalog.json"
    original = json.loads(previous.read_text())
    giove_audit = home / "demo/giove-v1/rights-audit.json"
    giove = json.loads(giove_audit.read_text())
    selected = {p["slug"] for pack in original["packs"] for p in pack["programmes"]}
    selected.update(record["slug"] for record in giove["records"])
    assert len(selected) == 75
    available = defaultdict(list)
    for row in library.list_sounds():
        available[row["slug"]].append(row)
    problems, rows = [], []
    for slug in sorted(selected):
        if len(available[slug]) != 1:
            problems.append(f"{slug}: missing or ambiguous")
            continue
        row = available[slug][0]
        folder = Path(row["path"])
        manifest = json.loads((folder / "build/manifest.json").read_text())
        problems.extend(f"{slug}: {error}" for error in library.validate_bundle(folder / "build"))
        if manifest["source_hash"] != library.source_hash(folder):
            problems.append(f"{slug}: stale compiled source")
        license_class = licenses.bundle_license(licenses.read_credits(folder))[1]
        if license_class not in licenses.SHIPPABLE:
            problems.append(f"{slug}: restricted recording terms ({license_class})")
        rows.append((row, folder, manifest, license_class))
    if problems:
        raise RuntimeError("\n".join(problems))
    out.mkdir(parents=True)
    stage = out / "staging-home"
    archives = out / "banks"
    archives.mkdir()
    by_bank = defaultdict(list)
    for row, folder, manifest, license_class in rows:
        bank = {"mie": "trap", "prove": "chitarre"}.get(row["bank"], row["bank"])
        target = stage / "banks" / bank / row["slug"]
        target.mkdir(parents=True)
        shutil.copytree(folder / "build", target / "build")
        for relative in library._PACK_FILES:
            source = folder / relative
            if source.is_file():
                dest = target / relative
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, dest)
        shutil.copy2(ROOT / "docs/release/sound-data-terms.md", target / "SOUND-DATA-TERMS.md")
        # Include source terms whenever a recording's grant is stored separately.
        for relative in ("samples/licenses",):
            source = folder / relative
            if source.is_dir():
                shutil.copytree(source, target / relative)
            elif source.is_file():
                shutil.copy2(source, target / relative)
        by_bank[bank].append({"slug": row["slug"], "title": manifest["title"],
                              "source_hash": manifest["source_hash"], "license_class": license_class,
                              "source_bank": row["bank"],
                              "runtime_files": {str(p.relative_to(folder / "build")): sha(p)
                                                for p in sorted((folder / "build").rglob("*")) if p.is_file()}})
    stamp = datetime.now(timezone.utc).isoformat()
    for bank in by_bank:
        origin = home / "banks" / bank / "bank.json"
        metadata = json.loads(origin.read_text()) if origin.exists() else {"title": bank.title()}
        metadata.update(format="libero.bank/1", slug=bank, version="0.1.0", figure=None,
                        subtitle="First release selection", description="Audited runtime sound-data candidate",
                        license="Recording licenses vary: see per-preset credits. Original Libero-generated data: CC0 1.0.",
                        created=stamp, updated=stamp)
        (stage / "banks" / bank / "bank.json").write_text(json.dumps(metadata, indent=2) + "\n")
    os.environ["LIBERO_HOME"] = str(stage)
    packed = []
    for bank, sounds in sorted(by_bank.items()):
        archive = library.bank_pack(bank, archives / f"{bank}-0.1.0.liberobank")
        metadata = json.loads((stage / "banks" / bank / "bank.json").read_text())
        packed.append({"bank": bank, "title": metadata["title"],
                       "file": archive.name, "presets": len(sounds), "programmes": sounds,
                       "sha256": sha(archive), "bytes": archive.stat().st_size})
    catalog = {"format": "libero.release-banks/2", "created_utc": stamp,
               "status": "Local candidate; software AGPLv3 and original authored sound data CC0; third-party terms retained",
               "preset_count": len(selected), "compressed_bytes": sum(p["bytes"] for p in packed),
               "excluded": "Original 18 restricted presets, other unaudited/conditional presets, authentic freeware-only Mellotron recordings",
               "selection_evidence": [{"file": previous.name, "sha256": sha(previous)},
                                      {"file": giove_audit.name, "sha256": sha(giove_audit)}], "packs": packed}
    (archives / "catalog.json").write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + "\n")
    (archives / "SHA256SUMS").write_text("".join(f"{p['sha256']}  {p['file']}\n" for p in packed))
    shutil.copy2(ROOT / "docs/release/sound-data-terms.md", archives / "SOUND-DATA-TERMS.md")
    (archives / "README.md").write_text(
        "# Libero sound-data candidate\n\n75 audited presets, packaged separately from the plugin. "
        "These are selected collections, not the full working library. Import into a fresh library "
        "for validation; importing a collection with the same identifier can update it.\n\n"
        "Keep the credits with every redistributed preset. Third-party recording terms remain in "
        "force; the project's software license does not replace them. Runtime playback files are "
        "included; recompiling recipes requires their separate production sources.\n\n"
        "The four authentic Mellotron sets have freeware-only terms and are excluded from this "
        "general/open sound-data selection. No upload has been performed.\n"
    )
    print(json.dumps({"path": str(archives), "presets": len(selected), "bytes": catalog["compressed_bytes"]}, indent=2))


if __name__ == "__main__":
    main()
