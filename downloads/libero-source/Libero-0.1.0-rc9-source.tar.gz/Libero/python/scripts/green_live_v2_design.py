"""Four distinct warm-bodied redesigns for the Green live-synth presets.

This is deliberately separate from build_green_v6.py: the root builder can
import LIVE_V2 and apply it for integration without this module rewriting it.
Run this file to build/QA only the four authorized live folders.
"""
from __future__ import annotations

from pathlib import Path
import importlib.util
import argparse
import sys

ROOT = Path(__file__).resolve().parents[2]
BUILDER_PATH = Path(__file__).with_name("build_green_v6.py")
SLUGS = ("cedro-lead", "miele-pulse", "ottone-verde", "bosco-largo")

# The added lower harmonics and octave support are balanced with lower masters;
# each preset has a different spectral/stereo strategy, not a shared supersaw.
# Full held-note/RMS calibration is emitted by the builder's native QA reports.
LIVE_V2 = {
    # Solid single center saw + quiet octave-free triangle support, with a
    # narrow stereo edge. Keep the lead's bite and centre image.
    "cedro-lead": dict(
        osc1_wave="Sega", osc1_level=-18, osc1_voices=1,
        osc1_detune=0, osc1_spread=0,
        osc2_wave="Sega", osc2_level=-37, osc2_oct=1, osc2_voices=3,
        osc2_detune=.15, osc2_spread=.9,
        sub_wave="Seno", sub_level=-45,
        flt_cutoff=5200, flt_env=.12, fenv_attack=5,
        fenv_decay=800, fenv_sustain=.38,
        lfo_rate=.11, lfo_cutoff=.018,
        drive=.018, width=.8, rev_mix=.025, master=-4.4,
    ),
    # Wide hollow pulse around a substantial triangle core; stereo is in
    # pulse-width/unison motion, with less detune than the original patch.
    "miele-pulse": dict(
        osc1_wave="Quadra", osc1_level=-20, osc1_pw=.28,
        osc1_voices=3, osc1_detune=.15, osc1_spread=.82,
        osc2_wave="Triangolo", osc2_level=-20, osc2_voices=1,
        osc2_detune=0, osc2_spread=0,
        sub_wave="Seno", sub_level=-34,
        flt_cutoff=5600, flt_env=.07, fenv_attack=40,
        fenv_decay=1050, fenv_sustain=.50,
        lfo_rate=.13, lfo_pw=.085, lfo_cutoff=.022,
        drive=.012, width=1.15, rev_mix=.028, master=-4.62,
    ),
    # Brass-like midrange: fundamental plus controlled upper square partials,
    # narrow unison and a warmer, less scooped filter envelope.
    "ottone-verde": dict(
        osc1_wave="Sega", osc1_level=-25, osc1_voices=3,
        osc1_detune=.08, osc1_spread=.48,
        osc2_wave="Quadra", osc2_level=-25, osc2_pw=.39,
        osc2_oct=0, osc2_voices=1, osc2_detune=0, osc2_spread=0,
        sub_wave="Seno", sub_level=-40,
        flt_cutoff=3900, flt_env=.19, fenv_attack=55,
        fenv_decay=720, fenv_sustain=.40,
        lfo_rate=.09, lfo_pw=.018, lfo_cutoff=.015,
        drive=.022, width=1.08, rev_mix=.022, master=-1.9,
    ),
    # Slow, choir-like pad: one restrained seven-voice saw bed and a warm
    # triangle center. Stereo arises from modest unison spread, with mono bass.
    "bosco-largo": dict(
        osc1_wave="Sega", osc1_level=-23, osc1_voices=7,
        osc1_detune=.19, osc1_spread=.84,
        osc2_wave="Triangolo", osc2_level=-23, osc2_oct=-1,
        osc2_voices=1, osc2_detune=0, osc2_spread=0,
        sub_wave="Seno", sub_level=-60,
        flt_cutoff=3900, flt_env=.055, fenv_attack=800,
        fenv_decay=2400, fenv_sustain=.62,
        lfo_rate=.055, lfo_cutoff=.035,
        drive=.012, width=1.22, rev_mix=.03, master=-5.14,
    ),
}


def load_builder():
    spec = importlib.util.spec_from_file_location("green_v6_for_live_v2", BUILDER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load builder at {BUILDER_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--slugs", nargs="*", choices=SLUGS, default=SLUGS)
    args = parser.parse_args()
    builder = load_builder()
    builder.LIVE.update(LIVE_V2)
    for slug in args.slugs:
        builder.build(slug)
        builder.qa(slug)


if __name__ == "__main__":
    main()
