"""Render six bass phrases through libero-render and record signal/palette checks."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import find_peaks

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
HOME = Path.home() / "Libero"
BANK = HOME / "banks/bassi"
OUT = HOME / "demo/bassi-synths"
RENDER = Path.home() / ".local/bin/libero-render"
SLUGS = ["sub-ancora", "sub-legno", "sub-rimbalzo", "808-notte", "808-colpo", "808-cavo"]

# Same notes, note lengths, velocities, repetitions and chord for every sound.
EVENTS = [
    (24, 0.00, 0.80, 38), (24, 0.95, 0.80, 116),
    (24, 1.95, 0.24, 120), (24, 2.26, 0.24, 92),
    (36, 2.70, 1.35, 100), (43, 4.15, 0.60, 84),
    (48, 4.90, 1.70, 106),
    (48, 6.85, 0.50, 82), (52, 6.92, 0.50, 86), (55, 7.00, 0.50, 90), (59, 7.08, 0.50, 94),
    (60, 8.00, 2.40, 112),
]
EVENTS_ARG = ",".join(f"{n}:{t:.3f}:{d:.3f}:{v}" for n, t, d, v in EVENTS)
PHRASE_END = 10.8


def render(folder: Path, output: Path, events: str = EVENTS_ARG, tail: float = 0.8) -> np.ndarray:
    subprocess.run([str(RENDER), "--sound", str(folder), "--out", str(output),
                    "--notes", events, "--tail", str(tail), "--sr", "48000"],
                   check=True, timeout=300, capture_output=True, text=True)
    x, sr = sf.read(output, always_2d=True, dtype="float64")
    if sr != 48000:
        raise RuntimeError(f"Unexpected renderer rate {sr}")
    return x


def band_share(x: np.ndarray, sr: int) -> dict:
    mono = x.mean(axis=1)
    n = len(mono)
    p = np.abs(np.fft.rfft(mono * np.hanning(n))) ** 2
    f = np.fft.rfftfreq(n, 1 / sr)
    total = max(float(p.sum()), 1e-30)
    return {label: round(float(p[(f >= lo) & (f < hi)].sum() / total), 5)
            for label, lo, hi in (("sub_20_60", 20, 60), ("bass_60_150", 60, 150),
                                  ("low_mid_150_500", 150, 500), ("mid_500_1500", 500, 1500),
                                  ("upper_1500_5k", 1500, 5000))}


def fundamental_pitch(x: np.ndarray, sr: int, start: float, duration: float = 0.20) -> float:
    y = x[int(start * sr):int((start + duration) * sr)].mean(axis=1)
    if len(y) < 1024:
        return float("nan")
    y = y - np.mean(y)
    nfft = 1 << 17
    spec = np.abs(np.fft.rfft(y * np.hanning(len(y)), n=nfft))
    freq = np.fft.rfftfreq(nfft, 1 / sr)
    # Search likely fundamental only; parabolic interpolation refines the FFT bin.
    lo, hi = np.searchsorted(freq, (24, 260))
    k = lo + int(np.argmax(spec[lo:hi]))
    if 1 <= k < len(spec) - 1:
        a, b, c = np.log(np.maximum(spec[k - 1:k + 2], 1e-30))
        offset = 0.5 * (a - c) / (a - 2 * b + c)
    else:
        offset = 0.0
    return float((k + offset) * sr / nfft)


def rms_db(x: np.ndarray) -> float:
    return float(20 * np.log10(np.sqrt(np.mean(np.asarray(x, dtype=np.float64) ** 2)) + 1e-15))


def sample_metrics(folder: Path) -> dict:
    manifest = json.loads((folder / "build/manifest.json").read_text())
    zones = manifest.get("zones", [])
    body = [z for z in zones if z.get("layer") == "body"]
    stats = []
    decoded_float32_bytes = 0
    for z in body:
        info = sf.info(folder / "build" / z["file"])
        decoded_float32_bytes += int(info.frames * info.channels * 4)
        x, sr = sf.read(folder / "build" / z["file"], dtype="float64", always_2d=True)
        mono = x.mean(axis=1)
        stats.append({"root": z["root"], "duration_s": len(x) / sr,
                      "peak_dbfs": round(20 * np.log10(np.max(np.abs(x)) + 1e-15), 2),
                      "rms_dbfs": round(rms_db(x), 2),
                      "last_500ms_rms_dbfs": round(rms_db(mono[-int(0.5 * sr):]), 2),
                      "dc_offset": round(float(np.mean(mono)), 9),
                      "clipped_samples": int(np.count_nonzero(np.abs(x) >= 1))})
    return {"zones": len(zones), "body_zones": len(body),
            "decoded_float32_memory_mb": round(decoded_float32_bytes / 1_000_000, 2),
            "sample_duration_s": {"min": min((s["duration_s"] for s in stats), default=0),
                                  "max": max((s["duration_s"] for s in stats), default=0)},
            "C1_root_last_500ms_rms_dbfs": next((s["last_500ms_rms_dbfs"] for s in stats if s["root"] == 24), None),
            "source_integrity": {"max_abs_dc": max((abs(s["dc_offset"]) for s in stats), default=0),
                                 "clipped_samples": sum(s["clipped_samples"] for s in stats),
                                 "minimum_peak_dbfs": min((s["peak_dbfs"] for s in stats), default=None)},
            "sample_pitch_note36_at_0.3_0.7_1.2_s_hz": ({
                f"{t:.1f}": round(fundamental_pitch(sf.read(folder / "build" / next(z["file"] for z in body if z["root"] == 36),
                                                                       dtype="float64", always_2d=True)[0], 48000, t), 3)
                for t in (0.3, 0.7, 1.2) if next((z for z in body if z["root"] == 36), None)
            } if body else {})}


def harmonic_profile(x: np.ndarray, sr: int, start: float, duration: float, expected_f0: float,
                     max_partial: int = 15) -> dict:
    y = x[int(start * sr):int((start + duration) * sr)].mean(axis=1)
    y = y - np.mean(y)
    nfft = 1 << 18
    mag = np.abs(np.fft.rfft(y * np.hanning(len(y)), n=nfft))
    freq = np.fft.rfftfreq(nfft, 1 / sr)
    fundamental = fundamental_pitch(x, sr, start, duration)
    base_bin = max(float(fundamental), expected_f0)
    amp = []
    for harmonic in range(1, max_partial + 1):
        center = harmonic * base_bin
        tol = max(2.0, center * 0.012)
        band = (freq >= center - tol) & (freq <= center + tol)
        amp.append(float(np.max(mag[band])) if np.any(band) else 0.0)
    a0 = max(amp[0], 1e-30)
    return {str(n): round(float(20 * np.log10(max(a, 1e-30) / a0)), 1)
            for n, a in enumerate(amp[1:], start=2)}


def probe_metrics(slug: str, folder: Path) -> dict:
    events = "24:0:1.5:38,36:2.2:1.5:38,36:4.4:1.5:120,48:6.6:1.5:120"
    x = render(folder, OUT / f"{slug}-c2-c3-probe.wav", events, tail=1.1)
    entries = {}
    for note, onset, label, velocity in ((24, 0.0, "C1_soft", 38), (36, 2.2, "C2_soft", 38),
                                         (36, 4.4, "C2_hard", 120), (48, 6.6, "C3_hard", 120)):
        target = 440 * 2 ** ((note - 69) / 12)
        clip = x[int(onset * 48000):]
        harmonics = harmonic_profile(x, 48000, onset + 0.5, 0.3, target,
                                     max_partial=45 if note == 24 else 15)
        low_mid = [float(10 ** (float(harmonics[str(n)]) / 10))
                   for n in range(2, len(harmonics) + 2)
                   if 150 <= n * target < 1500]
        entries[label] = {
            "expected_f0_hz": round(target, 3),
            "velocity": velocity,
            "pitch_onset_and_settle_hz": {
                "0.02s_window0.05s": round(fundamental_pitch(clip, 48000, 0.02, 0.05), 3),
                "0.08s_window0.08s": round(fundamental_pitch(clip, 48000, 0.08, 0.08), 3),
                "0.16s_window0.14s": round(fundamental_pitch(clip, 48000, 0.16, 0.14), 3),
            },
            "fundamental_hz_at_s": {
                str(t): round(fundamental_pitch(clip, 48000, t), 3)
                for t in (0.3, 0.7, 1.2)
            },
            "partial_levels_db_relative_to_fundamental_0.5_to_0.8s": harmonics,
            "sum_harmonic_energy_150_to_1500_hz_relative_to_fundamental": round(sum(low_mid), 4),
        }
    return entries


def main() -> None:
    from libero import Audio, analysis
    from libero.lint import lint_bundle

    OUT.mkdir(parents=True, exist_ok=True)
    report = {"route": "trap/rap bass collection; SYN, live oscillators for subs and original procedural oscillator zones for 808 pitch sweeps",
              "comparison_phrase": EVENTS, "sounds": {}}
    normalized_sections = []
    for slug in SLUGS:
        folder = BANK / slug
        wav = OUT / f"{slug}.wav"
        x = render(folder, wav)
        audio = Audio(x.astype(np.float32), 48000)
        spectrogram = analysis.spectrogram(audio, fmin=20, fmax=5000,
                                            title=f"{slug} · phrase, native engine")
        (OUT / f"{slug}-spectrogram.png").write_bytes(spectrogram)
        corr = float(np.corrcoef(x.T)[0, 1]) if x.shape[1] == 2 and np.std(x[:, 0]) and np.std(x[:, 1]) else 1.0
        side = (x[:, 0] - x[:, 1]) / 2
        mono = (x[:, 0] + x[:, 1]) / 2
        nfft = 1 << 17
        spec = np.fft.rfft(mono * np.hanning(len(mono)), n=nfft)
        f = np.fft.rfftfreq(nfft, 1 / 48000)
        side_spec = np.fft.rfft(side * np.hanning(len(side)), n=nfft)
        low = f < 120
        low_side_share = float(np.sum(np.abs(side_spec[low])**2) / max(np.sum(np.abs(spec[low])**2), 1e-30))
        peak = float(np.max(np.abs(x)))
        lint = lint_bundle(folder / "build")
        finding_fail = [z.line() for z in lint if z.level == "FAIL"]
        finding_warn = [z.line() for z in lint if z.level == "WARN"]
        preview = next((folder / "build" / f"preview.{ext}" for ext in ("m4a", "wav")
                        if (folder / "build" / f"preview.{ext}").exists()), None)
        report["sounds"][slug] = {
            "native_phrase_wav": wav.name,
            "preview_file": str(preview.name if preview else None),
            "duration_s": round(len(x) / 48000, 3), "peak_dbfs": round(20 * np.log10(peak + 1e-15), 2),
            "rms_dbfs": round(rms_db(x), 2), "dc_offset": round(float(np.mean(mono)), 9),
            "clipped_samples": int(np.count_nonzero(np.abs(x) >= 1.0)),
            "band_energy_shares_native_phrase": band_share(x, 48000),
            "stereo_correlation": round(corr, 5), "below_120_hz_side_to_mid_energy": round(low_side_share, 7),
            "zones_and_integrity": sample_metrics(folder),
            "isolated_native_note_probes": probe_metrics(slug, folder),
            "lint": {"fail": len(finding_fail), "warn": finding_warn},
        }
        if slug in ("808-notte", "808-cavo"):
            long_file = OUT / f"{slug}-C1-held-12s.wav"
            long_audio = render(folder, long_file, "24:0:12:100", tail=2.0)
            windows = {}
            for label, start, stop in (("10_to_11s", 10.0, 11.0), ("11_to_11.9s", 11.0, 11.9),
                                       ("12_to_12.25s_after_noteoff", 12.0, 12.25),
                                       ("12.25_to_12.5s", 12.25, 12.5),
                                       ("12.5_to_13s", 12.5, 13.0),
                                       ("13_to_14s", 13.0, 14.0)):
                seg = long_audio[int(start * 48000):int(stop * 48000)]
                windows[label] = round(rms_db(seg), 2)
            report["sounds"][slug]["long_held_C1"] = {
                "file": long_file.name, "held_seconds": 12,
                "peak_dbfs": round(20 * np.log10(np.max(np.abs(long_audio)) + 1e-15), 2),
                "clipped_samples": int(np.count_nonzero(np.abs(long_audio) >= 1.0)),
                "rms_by_window_dbfs": windows,
                "body_sample_duration_s": sample_metrics(folder)["sample_duration_s"]["max"],
            }
        # Normalize complete same-note phrase, then lower true-peak headroom for direct A/B playback.
        normalized_sections.append(audio.normalize_loudness(-20, ceiling_db=-2.0))
    # Concatenate 6 sections with a short silent gap; every section contains the identical MIDI phrase.
    silence = np.zeros((int(0.55 * 48000), 2), dtype=np.float32)
    pieces = []
    for audio in normalized_sections:
        pieces.append(audio.data.astype(np.float32))
        pieces.append(silence)
    comparison = Audio(np.concatenate(pieces, axis=0), 48000)
    compare_wav = OUT / "bass-palette-phrase-level-matched.wav"
    comparison.save(compare_wav, subtype="PCM_24")
    comparison_image = analysis.spectrogram(comparison, fmin=20, fmax=5000,
                                             title="Bass palette · same phrase, sections loudness-matched")
    (OUT / "bass-palette-phrase-level-matched.png").write_bytes(comparison_image)
    report["matched_phrase"] = {"file": compare_wav.name, "target_lufs_per_sound": -20,
                                "ceiling_dbfs": -2, "order": SLUGS,
                                "per_sound_normalized_loudness_dbfs": [round(a.rms_db, 2) for a in normalized_sections]}
    report["limits"] = ["This workflow does not audition by ear; figures and measurements verify engineering behavior, not taste.",
                        "Sub patches are engine oscillator-only. 808 zone bodies are mono procedural synthesis, 10 roots each, one velocity layer; velocity still controls level in the player."]
    (OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    (OUT / "README.md").write_text(
        "# Bassi synth QA\n\n"
        "The six section A/B file uses an identical MIDI phrase and each section is loudness-normalized to -20 LUFS, "
        "with -2 dBFS ceiling. Order: " + ", ".join(SLUGS) + ".\n\n"
        "The native WAVs retain each preset's default level and restrained room. Per-sound spectrograms cover 20 Hz–5 kHz. "
        "See report.json for spectrum shares, DC, clipping, low-frequency stereo side energy, body pitch at 0.3/0.7/1.2 s, "
        "zone integrity and lint. Notte and Cavo also include true 12-second C1 holds against 16 s and 14 s unlooped bodies. "
        "This is numerical/visual QA, not a claim of human listening or musical preference.\n",
        encoding="utf-8")
    # Extend every notes document with the same measured technical report and the per-sound figures.
    for slug in SLUGS:
        folder = BANK / slug
        entry = report["sounds"][slug]
        text = (folder / "notes.md").read_text(encoding="utf-8")
        marker = "\n## QA misurato\n"
        if marker in text:
            text = text.split(marker, 1)[0]
        pitch = entry["isolated_native_note_probes"]["C2_soft"]
        c1 = entry["isolated_native_note_probes"]["C1_soft"]
        hard = entry["isolated_native_note_probes"]["C2_hard"]
        long = entry.get("long_held_C1")
        qa = (f"\n## QA misurato\n\n"
              f"Native phrase: `~/Libero/demo/bassi-synths/{slug}.wav`; spectrogram `~/Libero/demo/bassi-synths/{slug}-spectrogram.png`. "
              f"Band shares: `{json.dumps(entry['band_energy_shares_native_phrase'], ensure_ascii=False)}`. "
              f"Peak {entry['peak_dbfs']} dBFS; RMS {entry['rms_dbfs']} dBFS; DC {entry['dc_offset']}; "
              f"clips {entry['clipped_samples']}; low-band side/mid energy {entry['below_120_hz_side_to_mid_energy']}; "
              f"stereo correlation {entry['stereo_correlation']}. Lint: {entry['lint']['fail']} FAIL, "
              f"{len(entry['lint']['warn'])} WARN. C2 post-sweep f0 at 0.3/0.7/1.2 s: "
              f"`{json.dumps(pitch['fundamental_hz_at_s'], ensure_ascii=False)}` Hz; C2 partials relative to f0 "
              f"at 0.5–0.8 s: `{json.dumps(pitch['partial_levels_db_relative_to_fundamental_0.5_to_0.8s'], ensure_ascii=False)}` dB. "
              f"C2 hard velocity f0: `{json.dumps(hard['fundamental_hz_at_s'], ensure_ascii=False)}` Hz; "
              f"C1 150–1500 Hz harmonic energy/fundamental: {c1['sum_harmonic_energy_150_to_1500_hz_relative_to_fundamental']}. "
              f"Decoded float32 body RAM estimate: {entry['zones_and_integrity']['decoded_float32_memory_mb']} MB; "
              f"root C1 last 500 ms RMS {entry['zones_and_integrity']['C1_root_last_500ms_rms_dbfs']} dBFS. "
              f"The 808s use 10 roots × 1 synthesized body layer; oscillator-only subs have zero baked zones. "
              f"Matched phrase: `~/Libero/demo/bassi-synths/bass-palette-phrase-level-matched.wav`.\n\n"
              + (f"A 12 s C1 hold is rendered at `~/Libero/demo/bassi-synths/{long['file']}`; level windows around note-off: "
                 f"`{json.dumps(long['rms_by_window_dbfs'], ensure_ascii=False)}` dBFS.\n\n" if long else "")
              + ("I cannot hear this render in the present workflow. Measurements verify signal behavior and distinct constructions, "
                 "not whether the palette sounds warm or suits the user's taste.\n"))
        (folder / "notes.md").write_text(text + qa, encoding="utf-8")
    print(json.dumps(report["sounds"], indent=2))


if __name__ == "__main__":
    main()
