"""Install six live oscillator bass patches into ~/Libero/banks/bassi.

These are original Libero SYN recipes. The plugin generates their sound from
the live oscillators; no audio source is sampled or redistributed.
Run from the repository with python/.venv/bin/python.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
HOME = Path.home() / "Libero"
BANK = HOME / "banks" / "bassi"

COMMON = {
    "mode": "Poli", "glide": 0, "voices": 24, "humanize": 0,
    "osc_drift": 0, "osc_retrig": "Riavvia", "osc1_phase": 0,
    "osc2_phase": 0, "osc1_voices": 1, "osc2_voices": 1,
    "osc1_detune": 0, "osc2_detune": 0, "osc1_spread": 0,
    "osc2_spread": 0, "width": 0, "master": -16,
    "lvl_attack": -60, "lvl_tail": -60, "lvl_air": -60,
    "vel_sens": 0.45, "dyn_mode": "Velocità",
    "tape_wow": 0, "tape_flutter": 0, "tape_sat": 0,
    "tape_age": 0, "tape_mix": 0, "echo_mix": 0,
    "rev_mode": "Cappella", "rev_size": 0.18, "rev_decay": 0.45,
    "rev_predelay": 5, "rev_damp": 0.75, "rev_width": 0.15,
    "rev_shimmer": 0, "rev_mix": 0.035,
}

PATCHES = [
    {
        "slug": "sub-ancora", "title": "Sub Ancora",
        "subtitle": "fondamentale sinusoidale ferma, per sostenere la linea",
        "role": "Pure sine fundamental, long held body. Sparse by design.",
        "construction": "A single phase-reset sine oscillator. No sub octave, detune, drift, resonator or drive; long sustain and a short controlled release.",
        "color": "#4f83a1", "harmonics": [1],
        "params": {"osc1_wave": "Seno", "osc1_level": -1.5,
                   "osc2_level": -60, "sub_level": -60,
                   "amp_attack": 4, "amp_decay": 900, "amp_sustain": 1,
                   "amp_release": 260, "amp_curve": -0.1,
                   "flt_cutoff": 20000, "flt_reso": 0, "flt_env": 0,
                   "drive": 0, "res_mix": 0},
    },
    {
        "slug": "sub-legno", "title": "Sub Legno",
        "subtitle": "sine centrale e triangolo risonante, caldo ma leggibile",
        "role": "Warm organic sub with a protected sine anchor and a restrained, coherent odd-harmonic body.",
        "construction": "A sine carries the fundamental. A phase-reset, asymmetrical pulse square is coherently layered below it and supplies audible even and odd partials from 2–6; a quiet Legno resonator adds fixed soft body. No detune or modulation.",
        "color": "#9b7653", "harmonics": [1, 3, 5, 7],
        "params": {"osc1_wave": "Seno", "osc1_level": -1,
                   "osc2_wave": "Quadra", "osc2_level": -4.5, "osc2_pw": 0.38,
                   "osc2_oct": 0, "sub_level": -60,
                   "amp_attack": 12, "amp_decay": 1200, "amp_sustain": 0.94,
                   "amp_release": 380, "amp_curve": -0.15,
                   "flt_mode": "Basso", "flt_cutoff": 1550, "flt_reso": 0.08,
                   "flt_env": 0.08, "flt_key": 0.15, "drive": 0.06,
                   "res_mode": "Legno", "res_decay": 0.4, "res_bright": 0.26,
                   "res_mix": 0.08},
    },
    {
        "slug": "sub-rimbalzo", "title": "Sub Rimbalzo",
        "subtitle": "sub elastico con morso breve e ritorno rotondo",
        "role": "Rubber-bounce sub for syncopated short lines; amplitude and filter excitation make its pulse.",
        "construction": "A sine holds the low end while a clearly audible narrow-pulse square supplies a bright, hollow body. A separate fast filter envelope closes its upper edge quickly; the amp envelope rebounds into a stable, shortened sustain.",
        "color": "#b36b4d", "harmonics": [1, 3, 5, 7, 9],
        "params": {"osc1_wave": "Seno", "osc1_level": -1.5,
                   "osc2_wave": "Quadra", "osc2_level": -5.5,
                   "osc2_oct": 0, "osc2_pw": 0.27, "sub_level": -60,
                   "amp_attack": 0, "amp_decay": 520, "amp_sustain": 0.74,
                   "amp_release": 180, "amp_curve": -0.35,
                   "fenv_source": "Propria", "fenv_attack": 0,
                   "fenv_decay": 115, "fenv_sustain": 0.06,
                   "fenv_release": 90, "flt_mode": "Basso", "flt_cutoff": 1450,
                   "flt_reso": 0.1, "flt_env": 0.3, "flt_key": 0.2,
                   "drive": 0.08, "res_mix": 0},
    },
    {
        "slug": "808-notte", "title": "808 Notte",
        "subtitle": "sub lungo e stabile con armonici di corpo dosati",
        "role": "Long trap/rap 808 with a steady sine core and a sustained, restrained upper body.",
        "construction": "Sine fundamental plus a phase-locked triangle at the played pitch, kept quiet enough to protect f0 while making 2–6 partials audible on small speakers. Long amp decay, high sustain and slight live drive; no tape or pitch wobble.",
        "color": "#5c537f", "harmonics": [1, 3, 5, 7, 9], "procedure": "night",
        "params": {"osc1_wave": "Seno", "osc1_level": -1,
                   "osc2_wave": "Triangolo", "osc2_level": -11,
                   "osc2_oct": 0, "sub_level": -60,
                   "amp_attack": 1, "amp_decay": 4200, "amp_sustain": 0.82,
                   "amp_release": 520, "amp_curve": -0.2,
                   "flt_mode": "Basso", "flt_cutoff": 2100, "flt_reso": 0.08,
                   "flt_env": 0.12, "flt_key": 0.1, "drive": 0.16,
                   "res_mix": 0},
    },
    {
        "slug": "808-colpo", "title": "808 Colpo",
        "subtitle": "808 corto e secco, armonica superiore come attacco",
        "role": "Compact punch 808 for fast patterns; its octave harmonic transient separates it from the long 808.",
        "construction": "A sine fundamental is joined by a sine one octave above at a lower level. The amp falls quickly and a distinct filter envelope removes the upper partial early. It has a rounded punch without claiming a pitch-drop envelope (not exposed in the live synth parameters).",
        "color": "#c47642", "harmonics": [1, 2], "procedure": "punch",
        "params": {"osc1_wave": "Seno", "osc1_level": -1,
                   "osc2_wave": "Seno", "osc2_oct": 1, "osc2_level": -8,
                   "sub_level": -60,
                   "amp_attack": 0, "amp_decay": 510, "amp_sustain": 0.16,
                   "amp_release": 140, "amp_curve": -0.48,
                   "fenv_source": "Propria", "fenv_attack": 0,
                   "fenv_decay": 85, "fenv_sustain": 0.02,
                   "fenv_release": 75, "flt_mode": "Basso", "flt_cutoff": 1250,
                   "flt_reso": 0.14, "flt_env": 0.42, "flt_key": 0.1,
                   "drive": 0.13, "res_mix": 0},
    },
    {
        "slug": "808-cavo", "title": "808 Cavo",
        "subtitle": "808 pieno e materico con medio armonico presente",
        "role": "Harmonic-rich but controlled 808: a protected sub under a sustained 150–1500 Hz cable-like body.",
        "construction": "A dedicated sine sub protects the fundamental while a saw and narrow-pulse square at the played pitch provide a distinctly richer 150–1500 Hz body. Mild pre-filter drive and a short filter sweep shape the attack; neither tape nor broad noise is used.",
        "color": "#8a4f57", "harmonics": [1, 2, 3, 4, 5, 6, 7, 8], "procedure": "cable",
        "params": {"osc1_wave": "Sega", "osc1_level": -10,
                   "osc2_wave": "Quadra", "osc2_level": -11,
                   "osc2_oct": 0, "osc2_pw": 0.32,
                   "sub_wave": "Seno", "sub_level": -2,
                   "amp_attack": 1, "amp_decay": 3000, "amp_sustain": 0.76,
                   "amp_release": 450, "amp_curve": -0.2,
                   "fenv_source": "Propria", "fenv_attack": 0,
                   "fenv_decay": 190, "fenv_sustain": 0.32,
                   "fenv_release": 180, "flt_mode": "Basso", "flt_cutoff": 2400,
                   "flt_reso": 0.1, "flt_env": 0.19, "flt_key": 0.12,
                   "drive": 0.19, "res_mix": 0},
    },
]


def preset_parameters(patch: dict) -> dict:
    values = {**COMMON, **patch["params"]}
    if patch.get("procedure"):
        values.update({"osc1_level": -60, "osc2_level": -60, "sub_level": -60})
    return values


def _figure(patch: dict) -> str:
    bars = "".join(
        f'<rect x="{74 + i * 42}" y="{278 - min(154, 154/(i+1)**0.55):.1f}" '
        f'width="21" height="{min(154, 154/(i+1)**0.55):.1f}" rx="4" fill="{patch["color"]}" opacity="{max(.2, 1-i*.095):.2f}"/>'
        for i in range(min(8, len(patch["harmonics"])))
    )
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="520" height="360" viewBox="0 0 520 360">
<rect width="520" height="360" rx="24" fill="#101820"/>
<text x="38" y="52" fill="#f5efe3" font-family="sans-serif" font-size="26" font-weight="700">{patch['title']}</text>
<text x="40" y="82" fill="#a7b5bf" font-family="sans-serif" font-size="13">OSCILLATOR PALETTE · ANALYTICAL SKETCH</text>
<path d="M45 194 H475 M45 278 H475" stroke="#34434e" stroke-width="1"/>
<text x="45" y="120" fill="#95a7b2" font-family="sans-serif" font-size="12">Partials shown by design; level falls across the series</text>
{bars}<text x="72" y="304" fill="#cbd5dc" font-family="sans-serif" font-size="13">1</text>
<text x="114" y="304" fill="#cbd5dc" font-family="sans-serif" font-size="13">2</text>
<text x="156" y="304" fill="#cbd5dc" font-family="sans-serif" font-size="13">3</text>
<text x="200" y="304" fill="#cbd5dc" font-family="sans-serif" font-size="13">4</text>
<text x="38" y="340" fill="#8195a3" font-family="sans-serif" font-size="11">Preset sketch · original synthesis · no sampled audio</text>
</svg>'''


def _recipe(patch: dict) -> str:
    params = {**COMMON, **patch["params"]}
    params["lvl_body"] = 0
    pairs = ",\n    ".join(f"{key}={value!r}" for key, value in params.items())
    if patch.get("procedure"):
        params.update({"osc1_level": -60, "osc2_level": -60, "sub_level": -60})
        pairs = ",\n    ".join(f"{key}={value!r}" for key, value in params.items())
        duration = {"night": 16.0, "punch": 3.1, "cable": 14.0}[patch["procedure"]]
        return f'''"""{patch['title']} — bespoke procedural oscillator body, rendered per key and velocity."""
import numpy as np
from libero import Audio, Sound

sound = Sound(title={patch['title']!r}, subtitle={patch['subtitle']!r},
              tags=["bass", "808", "synth", "trap", "rap", "mono-low", "procedural"],
              roots=list(range(24, 61, 4)), velocities={[100] if patch.get('procedure') else [48, 88, 120]},
              accent={patch['color']!r}, sample_rate=48000)

def _swept_sine(f0, sweep, sr):
    phase = 2 * np.pi * np.cumsum(f0 * np.power(2.0, sweep / 12.0)) / sr
    return np.sin(phase), phase

def _partial_body(phase, f0, sr, style, brightness):
    y = np.zeros_like(phase)
    max_harmonic = min(40, int(0.46 * sr / max(f0, 1.0)))
    for n in range(2, max_harmonic + 1):
        if style == "soft":
            amp = (0.58 if n % 2 else 0.18) / n**1.55
        elif style == "punch":
            amp = 0.68 if n == 2 else 0.42 if n == 3 else 0.12 / n
        else:
            amp = (0.66 if n % 2 else 0.48) / n**(0.86 - 0.18 * brightness)
        y += amp * np.sin(n * phase + 0.12 * n * n)
    return brightness * y

def body(ctx):
    # Bespoke deterministic oscillators; no sampled audio, randomized pitch or noise.
    sr = ctx.sr
    t = np.arange(int({duration} * sr), dtype=np.float64) / sr
    vel = float(np.clip(ctx.vel, 0, 1))
    if {patch['procedure']!r} == "night":
        sweep = 19 * np.exp(-t / 0.055) * (0.82 + 0.25 * vel)
        fundamental, phase = _swept_sine(ctx.freq, sweep, sr)
        lower = 0.76 * np.exp(-t / (1.65 + 0.45 * vel)) + 0.24 * np.exp(-t / 0.72)
        body_env = np.exp(-t / (1.35 + 0.35 * vel))
        upper = _partial_body(phase, ctx.freq, sr, "soft", 0.22 + 0.11 * vel)
        y = 0.78 * fundamental * lower + upper * body_env
    elif {patch['procedure']!r} == "punch":
        sweep = 12 * np.exp(-t / 0.034) * (0.86 + 0.20 * vel)
        fundamental, phase = _swept_sine(ctx.freq, sweep, sr)
        env = 0.82 * np.exp(-t / (0.22 + 0.045 * vel)) + 0.18 * np.exp(-t / 0.53)
        upper = _partial_body(phase, ctx.freq, sr, "punch", 0.2 + 0.12 * vel)
        y = 0.82 * fundamental * env + upper * np.exp(-t / 0.115)
    else:
        sweep = 7 * np.exp(-t / 0.067) * (0.87 + 0.18 * vel)
        fundamental, phase = _swept_sine(ctx.freq, sweep, sr)
        low = 0.82 * np.exp(-t / (1.9 + 0.25 * vel)) + 0.18 * np.exp(-t / 0.74)
        body_env = 0.85 * np.exp(-t / (1.3 + 0.25 * vel)) + 0.15 * np.exp(-t / 0.55)
        upper = _partial_body(phase, ctx.freq, sr, "cable", 0.55 + 0.10 * vel)
        # The sine anchor stays clean; only the harmonic body passes through this soft shaper.
        upper = np.tanh(1.35 * upper) / np.tanh(1.35)
        y = 0.78 * fundamental * low + 0.50 * upper * body_env
    y *= np.minimum(1.0, t / 0.002) * (0.58 + 0.28 * vel)
    fade_s = 0.35 if {patch['procedure']!r} in ("night", "cable") else 0.2
    fade_pos = np.clip((t - ({duration} - fade_s)) / fade_s, 0.0, 1.0)
    y *= 0.5 * (1.0 + np.cos(np.pi * fade_pos))
    peak = float(np.max(np.abs(y)))
    if peak > 0.88:
        y *= 0.88 / peak
    return Audio(y.astype(np.float32), sr)

sound.body(body)
sound.defaults(
    {pairs}
)
'''
    return f'''"""{patch['title']} — oscillator-only live SYN recipe."""
from libero import Sound

sound = Sound(
    title={patch['title']!r},
    subtitle={patch['subtitle']!r},
    tags=["bass", "sub", "synth", "live", "trap", "rap", "mono-low"],
    roots=[24, 36, 48, 60],
    velocities=[48, 88, 120],
    accent={patch['color']!r},
    sample_rate=48000,
)

# {patch['role']}
sound.defaults(
    {pairs}
)
'''


def main() -> None:
    BANK.mkdir(parents=True, exist_ok=True)
    existing = [p["slug"] for p in PATCHES if (BANK / p["slug"]).exists()]
    if existing:
        raise SystemExit("Refusing to overwrite existing sounds: " + ", ".join(existing))
    from libero.compiler import compile_sound
    from libero.lint import lint_bundle
    from libero.preview import make_preview

    for patch in PATCHES:
        folder = BANK / patch["slug"]
        folder.mkdir()
        (folder / "sound.py").write_text(_recipe(patch), encoding="utf-8")
        (folder / "figure.svg").write_text(_figure(patch), encoding="utf-8")
        implementation = ("live oscillators" if not patch.get("procedure") else
                          "bespoke procedural oscillators compiled into mono key/velocity zones")
        if patch.get("procedure"):
            limits = ("The three 808s are original generated oscillator bodies because the live engine has "
                      "no per-note pitch envelope; per-note synthesis permits a real pitch fall while the "
                      "recipe remains reproducible and editable. They do not imitate sampled analog noise "
                      "or claim round robins. Half-pedal does not apply.\n\n")
        else:
            limits = "These oscillator-only patches do not use sample round robins or half-pedal.\n\n"
        role = "bass/808" if patch.get("procedure") else "bass/sub"
        note_text = f"""# {patch['title']}

{patch['subtitle']}.

Route: trap/rap · {role} · SYN · {implementation}.

## Identità e costruzione

{patch['role']} {patch['construction']}

The six recipes use different oscillator/body architectures, not EQ presets of one source. Sine anchors stay phase-coherent and undetuned. There is no oscillator drift, wow, flutter, chorus, random pitch humanisation, stereo spread, or baked noise. Defaults are Poli with glide 0 and 24 voices for held notes and chords; a restrained Cappella room is available at 3.5% mix.

## Limiti e provenienza

Original Libero synthesis; no third-party audio or code sample is bundled. {limits}Measurements and native preview checks are appended by `python/scripts/build_bassi_synth_qa.py`. Numbers establish signal integrity and spectral distinctions; they do not prove perceived warmth or that the palette matches the user's taste.
"""
        (folder / "notes.md").write_text(note_text, encoding="utf-8")
        result = compile_sound(folder, jobs=1)
        if not result.ok:
            raise RuntimeError(f"Compile failed for {patch['slug']}: {result.error}")
        make_preview(folder)
        findings = lint_bundle(folder / "build")
        fails = [f.line() for f in findings if f.level == "FAIL"]
        warns = [f.line() for f in findings if f.level == "WARN"]
        if fails:
            raise RuntimeError(f"Lint failed for {patch['slug']}: {fails}")
        report = {"fail": len(fails), "warn": warns,
                  "zones": len(json.loads((folder / "build" / "manifest.json").read_text()).get("zones", [])),
                  "oscillator_only": not bool(patch.get("procedure")),
                  "preset_parameters": preset_parameters(patch)}
        (folder / "build" / "bass-build.json").write_text(json.dumps(report, indent=2) + "\n")
        print(f"{patch['slug']}: compiled, previewed, lint 0 FAIL / {len(warns)} WARN", flush=True)


if __name__ == "__main__":
    main()
