"""Finalize metadata and read-only QA indexes after every new pack is frozen.

No sound recipe, source recording or compiled audio is changed here.
Run verify_packs_v7.py immediately before this script.
"""
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'python'))
from libero import library

HOME = Path.home() / 'Libero'
OUT = HOME / 'demo/packs-v7'
integration = json.loads((OUT / 'integration.json').read_text())
if integration['errors']:
    raise SystemExit('Integration is not frozen: ' + repr(integration['errors']))
expected = {'mog': 28, 'venere': 14, 'bebop': 13}
now = datetime.now(timezone.utc).isoformat()
all_rows = library.list_sounds()
descriptions = {
    'mog': '28 programmi phonk e Brazilian phonk: lead, bassi, cowbell, texture, due kit ibridi, otto drum singole e un kit dedicato. Sino de Lata disponibile anche in terza maggiore e quarta giusta.',
    'venere': '14 programmi originali ispirati allo spazio: lead, pad, pluck, organi, bassi e texture. Quasar usa una sequenza interna al campione, senza sincronizzazione al tempo della DAW.',
    'bebop': '13 strumenti jazz: tromba, trombone, corno, tuba, quattro sax, clarinetto, pianoforte Steinway, chitarra archtop, contrabbasso e batteria. Articolazioni, dinamiche e round robin conservano le registrazioni disponibili per ogni sorgente.',
}
reports = {}
for bank, count in expected.items():
    rows = sorted((r for r in all_rows if r['bank'] == bank), key=lambda r: r['slug'])
    if len(rows) != count:
        raise SystemExit(f'{bank}: expected {count}, found {len(rows)}')
    programmes, checks = [], []
    for row in rows:
        folder = Path(row['path'])
        m = json.loads((folder / 'build/manifest.json').read_text())
        if library.source_hash(folder) != m['source_hash']:
            raise SystemExit('Source changed after integration: ' + row['slug'])
        arts = m.get('articulations', [])
        default = arts[0]['id'] if arts else None
        body = [z for z in m.get('zones', []) if z['layer'] == 'body'
                and (default is None or z.get('articulation') == default)]
        programmes.append({'slug': row['slug'], 'title': m.get('title', row['title']),
                           'role': m.get('subtitle', '')})
        checks.append({'slug': row['slug'], 'source_hash': m['source_hash'], 'fresh': True,
                       'zones': len(m.get('zones', [])), 'articulations': arts,
                       'default_key_range': [min(z['lo'] for z in body), max(z['hi'] for z in body)] if body else None,
                       'maximum_mapped_takes': max((z.get('take', 0) + 1 for z in body), default=0),
                       'license': m.get('license'),
                       'bundle_problems': library.validate_bundle(folder / 'build')})
    metadata_path = HOME / 'banks' / bank / 'bank.json'
    metadata = json.loads(metadata_path.read_text())
    metadata.update(programs=programmes, description=descriptions[bank], updated=now)
    if bank == 'mog':
        metadata['license'] = 'Source recordings CC0; original synthesis publication license requires rights-holder release choice — see per-instrument credits'
    elif bank == 'bebop':
        metadata['license'] = 'Mixed: CC0 1.0 / CC BY 4.0 — see per-instrument credits'
    metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + '\n')
    reports[bank] = {'bank': bank, 'count': len(checks), 'programmes': checks}

reports['mog']['qa_reports'] = ['../mog-v1/report.json', '../mog-drums-v2/report.json']
reports['venere']['qa_reports'] = ['../venere-v1/report.json']
reports['bebop']['qa_reports'] = ['../bebop-v1/winds-report.json', '../bebop-v1/guitar/report.json',
                                '../bebop-v1/rhythm-keys-bass/', '../bebop-v1/drums/qa-summary.json',
                                '../bebop-v1/ensemble.json']
report = {'created_utc': now, 'integration': 'integration.json', 'new_count': sum(expected.values()),
          'packs': reports, 'historical_incident': '../library-expansion-v6/historical-recompile-incident.json',
          'limits': 'QA verifies mapping, playback and integrity; listener ratings and final release licensing are separate.'}
(OUT / 'report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'counts': expected, 'new_count': sum(expected.values()), 'updated': now}))
