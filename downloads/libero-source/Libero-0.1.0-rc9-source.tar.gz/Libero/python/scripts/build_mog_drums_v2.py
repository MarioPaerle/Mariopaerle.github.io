#!/usr/bin/env python3
"""Build only the new Mog phonk one-shots and assembled 8-key drum kit.

Writes the nine owned preset folders and ~/Libero/demo/mog-drums-v2. Does not
edit bank.json or touch the previous Mog voices/kits. Acoustic snare/hat/rim/tom
source files come from Big Rusty Drums CC0 and are byte-preserved. Kicks and the
Brazilian clap are original oscillator/noise synthesis; no commercial audio is
sampled or copied. Original synthesis is conservatively marked private/unknown
for redistribution until the rights-holder makes a separate release choice.
"""
from __future__ import annotations
import hashlib, importlib.util, json, math, shutil, sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy import signal
from scipy.signal import resample_poly

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, render, library
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero.figure import validate_svg, rasterize

HOME=Path.home(); BANK=HOME/'Libero/banks/mog'; DEMO=HOME/'Libero/demo/mog-drums-v2'
SR=48000
BRD=HOME/'Libero/cache/libraries/karoryfer-big-rusty-drums'
BASE_SCRIPT=ROOT/'python/scripts/build_mog_v1.py'
spec=importlib.util.spec_from_file_location('mog_v1_readonly_helpers',BASE_SCRIPT)
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)

# Exact body sources: authored SYN kick and clap, real close-mic BRD for snare,
# hats, rim and tom. Kit keys follow the requested 8-key GM-ish layout.
PRESETS={
 'kick-phonk':dict(title='Kick Phonk',subtitle='Cassa sintetica phonk · sweep profondo 132→48 Hz, beater secco e corpo armonico',kind='synth_kick_phonk',key=36,color='#e33d2e'),
 'kick-baile':dict(title='Kick Baile',subtitle='Cassa sintetica baile · doppia risonanza tesa, colpo corto e coda controllata',kind='synth_kick_baile',key=40,color='#ef732c'),
 'snare-phonk':dict(title='Snare Phonk',subtitle='Rullante registrato · centro del fusto close-top, dinamiche e round robin Big Rusty',kind='brd',source_key=38,key=38,color='#bd5b4a'),
 'clap-baile':dict(title='Clap Baile',subtitle='Clap sintetico originale · quattro transienti ravvicinati, schiocco largo e pelle breve',kind='synth_clap',key=39,color='#ef8a3a'),
 'hat-phonk':dict(title='HiHat Phonk',subtitle='Charleston chiuso registrato · close mic, take e livelli Big Rusty',kind='brd',source_key=42,key=42,color='#c8a84f'),
 'hat-open-phonk':dict(title='HiHat Open Phonk',subtitle='Charleston aperto registrato · close mic, coda reale e round robin Big Rusty',kind='brd',source_key=46,key=46,color='#dfc374'),
 'rim-baile':dict(title='Rim Baile',subtitle='Rimshot registrato · attacco sul bordo, livelli e round robin Big Rusty',kind='brd',source_key=40,key=37,color='#b46a42'),
 'perc-baile':dict(title='Perc Baile',subtitle='Tom grave corto registrato · tom 18 close mic, pelle e round robin Big Rusty',kind='brd',source_key=43,key=50,color='#d9894a'),
}
KIT='drum-phonk-mog'
KIT_KEYS=[36,37,38,39,40,42,46,50]
KIT_MAP={36:'kick-phonk',37:'rim-baile',38:'snare-phonk',39:'clap-baile',40:'kick-baile',42:'hat-phonk',46:'hat-open-phonk',50:'perc-baile'}
VELOCITIES=[12,32,52,72,94,118]
WARN_REASON={
 'aliasing':'Warnings flag strong energy in the real attack above the linter’s 18 kHz analysis boundary; source recordings are preserved byte-for-byte, and the synthetic clap intentionally contains a short broadband snap.',
 'brightness':'The linter compares velocity layers and independent one-shot kit pieces as if they were sustained pitched notes. Source dynamics remain distinct; authored kick/clap velocity layers change transient and partial balance.',
 'takes':'High waveform correlation is expected for repeated strikes of the same instrument/articulation; all mapped recorded takes remain separate round robins and are exercised in native repeated-note renders.',
 'loudness':'The linter compares unrelated percussion instruments mapped to different GM keys as a pitched-key loudness ladder. Their source levels are retained; kit headroom is checked in two grooves and an all-key stress render.',
 'ladder':'The source’s independent recorded velocity layers are kept as performed; no synthetic duplicate dynamic is substituted.',
}


def sha(p:Path):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def warning_audit(lines):
 from collections import Counter
 warns=[x for x in lines if x.startswith('WARN ')]
 counts=Counter((x.split()[1] if len(x.split())>1 else 'other') for x in warns)
 return {'counts_by_category':dict(sorted(counts.items())),
         'reasons':{k:WARN_REASON.get(k,'Source-specific measurement warning retained for review: '+k) for k in sorted(counts)},
         'all_lines':warns}

def provenance_check(slug):
 folder=BANK/slug;sp=folder/'samples/source-proof.json';proof=json.loads(sp.read_text())
 missing=[];mismatch=[];source_count=0
 for row in proof:
  included=row.get('included') or row.get('file')
  if included:
   f=folder/'samples'/included;want=row.get('sha256_included') or row.get('sha256') or row.get('derived_sha256')
   if not f.is_file():missing.append(included)
   elif want and sha(f)!=want:mismatch.append({'file':included,'kind':'included','expected':want,'actual':sha(f)})
  raw_included=row.get('raw_included')
  if raw_included:
   f=folder/'samples'/raw_included;want=row.get('raw_sha256') or row.get('raw_sha256_in_kit')
   if not f.is_file():missing.append(raw_included)
   elif want and sha(f)!=want:mismatch.append({'file':raw_included,'kind':'raw_included','expected':want,'actual':sha(f)})
  if row.get('source_cache_file'):
   src=Path(row['source_cache_file']);want=row.get('sha256_source')
   if want:
    source_count+=1
    if not src.is_file():missing.append(str(src))
    elif sha(src)!=want:mismatch.append({'file':str(src),'kind':'source_cache','expected':want,'actual':sha(src)})
  if row.get('provenance') and isinstance(row['provenance'],dict):
   inner=row['provenance'];rel=inner.get('source_path');want=inner.get('sha256_source')
   if rel and want:
    src=BRD/rel;source_count+=1
    if not src.is_file():missing.append(str(src))
    elif sha(src)!=want:mismatch.append({'file':str(src),'kind':'source_cache','expected':want,'actual':sha(src)})
 manifest=json.loads((folder/'build/manifest.json').read_text())
 sh=library.source_hash(folder)
 zone_names=sorted({z.get('file') for z in manifest.get('zones',[]) if z.get('file')})
 zone_hashes=[];build_missing=[]
 for name in zone_names:
  f=folder/'build'/name
  if not f.is_file():build_missing.append(name)
  else:zone_hashes.append({'file':name,'sha256':sha(f)})
 return {'source_proof_file':str(sp),'source_proof_sha256':sha(sp),'proof_entries':len(proof),
         'verified_upstream_source_files':source_count,'missing_files':missing,'hash_mismatches':mismatch,
         'all_proof_files_match':not missing and not mismatch,
         'source_map_sha256':sha(folder/'samples/source-map.json') if (folder/'samples/source-map.json').exists() else None,
         'credits_sha256':sha(folder/'samples/credits.json'),
         'current_source_hash':sh,'manifest_source_hash':manifest.get('source_hash'),'source_hash_fresh':sh==manifest.get('source_hash'),
         'manifest_sha256':sha(folder/'build/manifest.json'),'compiled_zones':len(manifest.get('zones',[])),
         'unique_compiled_zone_files':len(zone_names),'compiled_zone_files_missing':build_missing,
         'compiled_audio_zone_tree_sha256':hashlib.sha256(json.dumps(zone_hashes,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
         'compiled_zone_file_hashes':zone_hashes,
         'license':manifest.get('license'),'license_class':manifest.get('license_class'),
         'default_invariants':{k:manifest.get('params',{}).get(k) for k in ['mode','glide','amp_sustain','tape_wow','tape_flutter','caldi_mode']}}

def write_json(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')

def synthetic(kind,vel,variant=0):
 """A distinct authored electro-acoustic drum model per role and velocity."""
 v=(vel-1)/126.0
 if kind.startswith('synth_kick'):
  dur=1.15 if kind=='synth_kick_phonk' else .94
  n=round(dur*SR);t=np.arange(n)/SR
  if kind=='synth_kick_phonk':
   # Low boom: sharp exponential pitch dive, membrane partials and a little
   # beater noise. Increasing velocity adds transient energy and upper modes.
   f=48+84*np.exp(-t/(.030+.009*v));phase=2*np.pi*np.cumsum(f)/SR
   body=np.sin(phase)+(.31+.13*v)*np.sin(2*phase+.16)+(.10+.08*v)*np.sin(3*phase+.35)+.025*np.sin(4*phase)
   body*=np.exp(-t/(.40+.11*v))
   rng=np.random.default_rng(1801+vel)
   click=rng.normal(0,1,n)*np.exp(-t/.0027)*(.035+.10*v)
   x=body*(.58+.12*v)+click
   x=np.tanh((1.35+.4*v)*x)
  else:
   # Baile kick: less sub-focused, two detuned membrane modes and clipped
   # front edge; faster pitch movement keeps it distinct from Kick Phonk.
   f=58+68*np.exp(-t/(.017+.005*v));phase=2*np.pi*np.cumsum(f)/SR
   f2=92+32*np.exp(-t/.025);phase2=2*np.pi*np.cumsum(f2)/SR
   body=(np.sin(phase)+(.35+.11*v)*np.sin(2*phase+.25)) * np.exp(-t/(.25+.055*v))
   membrane=np.sin(phase2+.5)*np.exp(-t/(.105+.02*v))
   rng=np.random.default_rng(2907+vel)
   tick=rng.normal(0,1,n)*np.exp(-t/.0019)*(.025+.09*v)
   x=.54*body+(.20+.07*v)*membrane+tick
   x=np.tanh((1.65+.45*v)*x)
 elif kind=='synth_clap':
  dur=.58;n=round(dur*SR);t=np.arange(n)/SR;rng=np.random.default_rng(3901+vel)
  raw=rng.normal(0,1,n)
  # Four short hand-clap bursts with a wider final slap and filtered chest body.
  burst=np.zeros(n)
  for idx,(when,decay,gain) in enumerate(((0,.008,1),(.012,.010,.83),(.026,.013,.71),(.046,.024,1.08))):
   a=round(when*SR);b=min(n,a+round(.085*SR));tt=np.arange(b-a)/SR
   noise=raw[a:b]
   # crude colored noise: blend current sample with a slightly smoothed copy
   smooth=np.convolve(noise,np.ones(7)/7,mode='same')
   burst[a:b]+=gain*(.72*noise+.28*smooth)*np.exp(-tt/decay)
  body=(np.sin(2*np.pi*(176+17*v)*t+.12*np.sin(2*np.pi*5.2*t))*np.exp(-t/(.105+.02*v))
       +.22*np.sin(2*np.pi*(312+22*v)*t)*np.exp(-t/.043))
  x=(.19+.07*v)*burst+(.17+.04*v)*body
  x=np.tanh((1.25+.5*v)*x)
 else:raise ValueError(kind)
 # Preserve dynamics in envelope and spectrum while matching repeatable peak
 # progression, avoiding compiler/linter amplitude inversion across the six tiers.
 peak=float(np.max(np.abs(x))+1e-20)
 target=.56+(.28*v)
 x=x/peak*target
 # tiny anti-click fade; onset remains < 1.5 ms.
 fade=min(96,len(x)//20);x[:fade]*=np.linspace(0,1,fade,endpoint=False)
 return x

def copy_brd_performance(folder,slug,source_key,output_key):
 samples=folder/'samples';orig=samples/'originals';orig.mkdir(parents=True,exist_ok=True)
 derived_dir=samples/'processed';derived_dir.mkdir(parents=True,exist_ok=True)
 regions=base.selected_brd(base.sources_big_rusty().regions,[source_key])
 rows=[];proof=[];seen=set()
 for r in regions:
  rel=r.sample.relative_to(BRD)
  name=f'brd-midi{source_key}-v{r.lovel:03d}-{r.hivel:03d}-rr{r.seq_position:02d}-{rel.name}'
  dest=orig/name
  if not dest.exists():shutil.copy2(r.sample,dest)
  digest=sha(r.sample);assert sha(dest)==digest
  audio,sr=sf.read(r.sample,always_2d=True,dtype='float64')
  edited,transform=process_recording(slug,audio,sr)
  dname=f'{slug}-{name.rsplit(".",1)[0]}.wav';ddest=derived_dir/dname
  sf.write(ddest,edited,sr,subtype='PCM_24')
  row={'file':f'processed/{dname}','root':output_key,'lo':0,'hi':127,
       'vel':[r.lovel,r.hivel],'take':r.seq_position-1,'pitched':False,'one_shot':True}
  rows.append(row)
  proof.append({'included':row['file'],'sha256_included':sha(ddest),
                'raw_included':f'originals/{name}','raw_sha256':sha(dest),
                'source_cache_file':str(r.sample),'source_path':rel.as_posix(),
                'sha256_source':digest,'source_key':source_key,
                'output_trigger_key':output_key,'velocity':[r.lovel,r.hivel],
                'take':r.seq_position-1,'mic':base.DRUM_MIC[source_key],
                'transform':transform,'derived_file':row['file'],'derived_sha256':sha(ddest)})
  seen.add(rel.as_posix())
 return rows,proof,seen

def process_recording(slug,audio,sr):
 """Gentle, instrument-specific derivation; originals remain unmodified."""
 x=np.asarray(audio,dtype=np.float64)
 fny=sr/2
 def band(low,high):
  return signal.sosfiltfilt(signal.butter(2,[low,high],btype='bandpass',fs=sr,output='sos'),x,axis=0)
 if slug=='snare-phonk':
  body=band(105,235);snap=band(1800,6200)
  y=x+.18*body+.12*snap
  y=np.tanh(1.22*y)/1.22
  t=np.arange(len(y))/sr;tail=np.clip((t-.48)/max(t[-1]-.48,.01),0,1);tail=tail*tail*(3-2*tail)
  env=1-.28*tail
  y*=env[:,None]
  return y,{'name':'phonk-snap-body-soft-saturation-gentle-tail-control','details':'parallel 105-235 Hz body and 1.8-6.2 kHz snap emphasis, 1.22x tanh soft saturation, 28% smooth attenuation only toward the recorded tail; no time truncation or velocity/take substitution'}
 if slug in ('hat-phonk','hat-open-phonk'):
  cutoff=14500 if slug=='hat-phonk' else 15800
  sos=signal.butter(2,cutoff,btype='lowpass',fs=sr,output='sos')
  smoothed=signal.sosfiltfilt(sos,x,axis=0)
  amount=.14 if slug=='hat-phonk' else .11
  y=(1-amount)*smoothed+amount*(np.tanh(1.24*smoothed)/1.24)
  return y,{'name':'soft-high-shelf-and-light-saturation','details':f'gentle {cutoff} Hz low-pass smoothing and {amount:.2f} parallel tanh blend; recorded opening/closing and natural decay are not gated'}
 if slug=='rim-baile':
  y=np.tanh(1.18*x)/1.18
  t=np.arange(len(y))/sr;tail=np.clip((t-.19)/max(t[-1]-.19,.01),0,1);tail=tail*tail*(3-2*tail)
  y*= (1-.48*tail)[:,None]
  return y,{'name':'rim-snap-soft-saturation-dry-tail','details':'1.18x tanh soft saturation and smooth tail attenuation beginning after 190 ms, retaining the full recorded tail and the original source file'}
 if slug=='perc-baile':
  # A fixed +1-semitone resampling tightens the recorded 18-inch tom body;
  # then a mild low-body emphasis and soft late gate shorten the baile phrase.
  ratio=2**(1/12);down=round(ratio*10000)
  tuned=resample_poly(x,up=10000,down=down,axis=0)
  tuned=signal.sosfiltfilt(signal.butter(2,[85,190],btype='bandpass',fs=sr,output='sos'),tuned,axis=0)
  # restore broad source tone underneath a restrained resonant support
  raw_tuned=resample_poly(x,up=10000,down=down,axis=0)
  y=.88*raw_tuned+.12*tuned
  t=np.arange(len(y))/sr;tail=np.clip((t-.34)/max(t[-1]-.34,.01),0,1);tail=tail*tail*(3-2*tail)
  y*= (1-.62*tail)[:,None]
  return y,{'name':'tom-plus-one-semitone-body-focus-gentle-gate','details':'uniform +1 semitone resampling on this 18-inch tom performance; 12% support in 85-190 Hz band and smooth 62% late-tail attenuation after 340 ms; original pitch/performance WAV retained unchanged'}
 return x,{'name':'identity-copy','details':'no processing'}

def synth_performance(folder,kind,out_key):
 s=folder/'samples';synth=s/'authored-synthesis';synth.mkdir(parents=True,exist_ok=True)
 rows=[];proof=[]
 for ix,vel in enumerate(VELOCITIES):
  audio=synthetic(kind,vel);name=f'{kind}-v{vel:03d}.wav';dest=synth/name
  sf.write(dest,audio,SR,subtype='PCM_24')
  lo=1 if ix==0 else (VELOCITIES[ix-1]+vel)//2+1
  hi=127 if ix==len(VELOCITIES)-1 else (vel+VELOCITIES[ix+1])//2
  row={'file':f'authored-synthesis/{name}','root':out_key,'lo':0,'hi':127,
       'vel':[lo,hi],'take':0,'pitched':False,'one_shot':True}
  rows.append(row);proof.append({'file':row['file'],'sha256':sha(dest),'authored_velocity_reference':vel,
                                 'velocity_window':[lo,hi],'design':kind,'sample_rate':SR,'frames':len(audio)})
 return rows,proof

def svg_art(slug,title,color,kind):
 # Vector drawings encode each physical excitation separately, not the shared
 # decorative waveform template used for synth programmes.
 if kind=='synth_kick_phonk':
  body='<circle cx="256" cy="238" r="116"/><circle cx="256" cy="238" r="84"/><path d="M256 52v86m-18-18 18 18 18-18M130 368h252"/>'
 elif kind=='synth_kick_baile':
  body='<ellipse cx="256" cy="232" rx="132" ry="96"/><ellipse cx="256" cy="232" rx="96" ry="64"/><path d="M80 354q88-52 176 0t176 0M122 382h268"/>'
 elif kind=='synth_clap':
  body='<path d="M156 330V206q0-24 22-24t22 24v-71q0-25 22-25t22 25v63-97q0-24 22-24t22 24v100-71q0-23 22-23t22 23v95q0 99-86 99h-4q-77 0-86-94z"/><path d="M352 128l28-25m-16 63 41-8m-52-88 11-37"/>'
 elif kind=='snare':
  body='<ellipse cx="256" cy="190" rx="126" ry="62"/><path d="M130 190v118q126 75 252 0V190M143 310l226 0M165 345l182 0M190 373l132 0"/><ellipse cx="256" cy="190" rx="126" ry="62"/>'
 elif kind=='closedhat':
  body='<path d="M98 204q158-91 316 0-158 93-316 0zm0 28q158 92 316 0M256 232v136m-44 0h88M122 178l22 18m240-18-22 18"/>'
 elif kind=='openhat':
  body='<path d="M82 176q174-104 348 0-174 98-348 0zm28 44q174-94 348 0M256 219v147m-48 0h96M120 292l272-86"/>'
 elif kind=='rim':
  body='<ellipse cx="256" cy="250" rx="132" ry="92"/><path d="M124 250q132 90 264 0M150 322l214-144m-238 84 260 0"/><path d="M370 95l50-44m-22 83 57-8"/>'
 else:
  body='<path d="M132 250q124-166 248 0-124 166-248 0z"/><ellipse cx="256" cy="250" rx="51" ry="91"/><path d="M90 365q166-48 332 0m-301 26h238"/>'
 return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="none" stroke="{color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round">'
         f'<title>{title}</title><desc>{slug}: own drum identity illustration.</desc>{body}</svg>')

def write_sound(folder,title,subtitle,rows,credits,color,kind,tags,master_db=0,kit=False):
 folder.mkdir(parents=True,exist_ok=True);samples=folder/'samples';samples.mkdir(exist_ok=True)
 write_json(samples/'map.json',rows)
 write_json(samples/'credits.json',credits)
 proof_path=samples/'source-proof.json';proof=json.loads(proof_path.read_text()) if proof_path.exists() else []
 transforms=[]
 for item in proof:
  rec=item.get('provenance',{}) if isinstance(item.get('provenance'),dict) else item
  tr=rec.get('transform')
  if tr and tr.get('details') and tr['details'] not in transforms:transforms.append(tr['details'])
 transform_note=(' Derived copies used by mapped zones: '+'; '.join(transforms)+'. Raw recorded WAVs stay unchanged beside their per-file hashes.' if transforms else '')
 proof=[]
 # map with precise copies; synth and source proof already saved by upstream caller.
 sound_py=f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nP=Path(__file__).parent\nKEEP={{'file','root','lo','hi','vel','dyn','take','pitched','one_shot','choke_group','chokes','gain_db','articulation'}}\nregions=[{{k:v for k,v in row.items() if k in KEEP}} for row in json.loads((P/'samples'/'map.json').read_text())]\nsound=Sound(title={title!r},subtitle={subtitle!r},tags={tags!r},roots={[rows[0]['root']] if not kit and rows else KIT_KEYS!r},accent={color!r})\nsound.multisample('body',regions,as_dyn=False,process={{'tune':'none','ladder':'keep','align_ms':0,'pre_ms':0,'loop':'none','max_seconds':None,'end_db':-120,'edge_fill':False,'encoding':'flac24'}})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,rr_reset_ms=1200,humanize={{'cents':0,'ms':0,'db':0}},one_shot=True)\nsound.defaults(mode='Poli',glide=0,voices=32,master={master_db},vel_sens=.72,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=120,rev_mode='Cappella',rev_size=.08,rev_decay=.25,rev_mix=0,width=1,drive=0,tape_wow=0,tape_flutter=0,tape_mix=0,tape_sat=0,caldi_mode='Spento',lvl_body=0,lvl_attack=0,lvl_tail=-60,lvl_air=-60)\n'''
 (folder/'sound.py').write_text(sound_py)
 notes=(f'# {title}\n\n{subtitle}\n\nRoute REC/SYN as appropriate. This is an unpitched one-shot: the input key triggers it without keyboard transposition. Genuine source velocity layers and recorded round robins remain separate. Original synth layers are identified separately from recordings in credits/proof.\n\nDefaults: Poli, glide 0, wow/flutter 0, Caldi Spento. Source recordings remain unaltered; no artificial cymbal choke. Any authored synthesis is not represented as an upstream recording.{transform_note}\n')
 (folder/'notes.md').write_text(notes)
 art=svg_art(folder.name,title,color,kind);assert not validate_svg(art),validate_svg(art)
 (folder/'figure.svg').write_text(art);(folder/'figure.png').write_bytes(rasterize(art,512))

def make_individual(slug,meta,source_regions):
 folder=BANK/slug;folder.mkdir(parents=True,exist_ok=True);(folder/'samples').mkdir(exist_ok=True)
 if meta['kind'].startswith('synth_'):
  rows,proof=synth_performance(folder,meta['kind'],meta['key'])
  sourceclass='private_only'
  credits=[{'source':'Original authored drum synthesis','author':'Libero Mog drum design','license':'Not separately released for sample-data redistribution','license_class':'unknown','url':'','notes':'Original synthetic sound, generated for this instrument. No commercial audio or third-party sample used. Redistribution status remains private pending a separate rights-holder release choice.','files':[r['file'] for r in rows]}]
  kind=meta['kind']
 else:
  rows,proof,seen=copy_brd_performance(folder,slug,meta['source_key'],meta['key'])
  # Keep the exact license notice and the original full-map context beside the files.
  srclic=BANK/'memphis-fita/samples/LICENSE-Big-Rusty-Drums.txt'
  if srclic.exists():shutil.copy2(srclic,folder/'samples/LICENSE-Big-Rusty-Drums.txt')
  else:shutil.copy2(BANK/'baile-rua/samples/LICENSE-Big-Rusty-Drums.txt',folder/'samples/LICENSE-Big-Rusty-Drums.txt')
  sourceclass='cc0';kind={42:'closedhat',46:'openhat',40:'rim',43:'perc',38:'snare'}[meta['source_key']]
  credits=[{'source':'Big Rusty Drums v1.100','author':'Zygmunt Szpaderski / D. Smolken; Karoryfer Samples','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://shop.karoryfer.com/pages/free-big-rusty-drums','license_url':'https://github.com/sfzinstruments/karoryfer.big-rusty-drums/blob/f07ce00/LICENSE','source_commit':'f07ce00','notes':'Only the selected source-mapped close mic for this articulation is included; real source velocity layers and takes are preserved. Raw WAVs remain unchanged. Map zones use separately hashed, instrument-specific derived processing documented per file in source-proof.json.','files':[r['file'] for r in rows]}]
  write_json(folder/'samples/source-map.json',{'source':'Big Rusty Drums v1.100','upstream_commit':'f07ce00','source_zone_count':len(rows),'source_proof':proof})
 write_json(folder/'samples/source-proof.json',proof)
 write_sound(folder,meta['title'],meta['subtitle'],rows,credits,meta['color'],kind,['mog','drums','phonk','one-shot',meta['kind']],master_db=-1.5)
 return sourceclass

def assemble_kit():
 folder=BANK/KIT;s=folder/'samples';orig=s/'originals';orig.mkdir(parents=True,exist_ok=True)
 allrows=[];sourceproof=[];raw_seen={};authored=[];credits_by_source={}
 for key,slug in KIT_MAP.items():
  preset=BANK/slug;desc=PRESETS[slug];srcmap=json.loads((preset/'samples/map.json').read_text())
  pproof=json.loads((preset/'samples/source-proof.json').read_text())
  proof_by_file={}
  for x in pproof:
   proof_by_file[x.get('included',x.get('file'))]=x
   if x.get('derived_file'):proof_by_file[x['derived_file']]=x
  for row in srcmap:
   src=preset/'samples'/row['file'];digest=sha(src);name=f'key{key:03d}-{slug}-{Path(row["file"]).name}'
   is_synth=PRESETS[slug]['kind'].startswith('synth_')
   dest_dir=(s/'authored-synthesis') if is_synth else (s/'processed')
   dest_dir.mkdir(parents=True,exist_ok=True);dest=dest_dir/name
   if not dest.exists():shutil.copy2(src,dest)
   assert sha(dest)==digest,(slug,row['file'],'copy mismatch')
   nr=dict(row);nr['file']=f'{dest_dir.name}/{name}';nr['root']=key;nr['lo']=key;nr['hi']=key
   allrows.append(nr)
   srcproof=proof_by_file.get(row['file'],{})
   item={'kit_key':key,'preset':slug,'included':nr['file'],'sha256_in_kit':digest,
         'sha256_in_preset':sha(src),'provenance':srcproof}
   if not is_synth:
    raw_rel=srcproof.get('raw_included')
    raw_source=preset/'samples'/raw_rel if raw_rel else None
    if raw_source is None or not raw_source.is_file():raise RuntimeError(f'missing raw source copy {slug} {row["file"]}')
    raw_dest=orig/f'key{key:03d}-{slug}-{raw_source.name}'
    if not raw_dest.exists():shutil.copy2(raw_source,raw_dest)
    assert sha(raw_dest)==srcproof['raw_sha256'],(slug,row['file'],'raw copy mismatch')
    item['raw_included']=f'originals/{raw_dest.name}';item['raw_sha256_in_kit']=sha(raw_dest)
    rel=srcproof.get('source_path');want=srcproof.get('sha256_source');cache=(BRD/rel) if rel else None
    if not cache or not cache.exists() or sha(cache)!=want:raise RuntimeError(f'kit source mismatch {slug} {row["file"]}')
    raw_seen[rel]=want
   if is_synth:
    authored.append(nr['file'])
   sourceproof.append(item)
 credits=[{'source':'Big Rusty Drums v1.100','author':'Zygmunt Szpaderski / D. Smolken; Karoryfer Samples','license':'CC0 1.0 Universal','license_class':'cc0','url':'https://shop.karoryfer.com/pages/free-big-rusty-drums','license_url':'https://github.com/sfzinstruments/karoryfer.big-rusty-drums/blob/f07ce00/LICENSE','source_commit':'f07ce00','notes':'One original close-mic performance per selected velocity/take zone; input GM keys route each independent preset voice. Source recordings are byte-identical to verified individual presets.','files':[r['file'] for r in allrows if r['file'] not in authored]}]
 credits.append({'source':'Original authored phonk kick and baile clap synthesis','author':'Libero Mog drum design','license':'Not separately released for sample-data redistribution','license_class':'unknown','url':'','notes':'The two kicks and one clap in this kit are generated by this project’s synthesis models; they are not copied from commercial reference files. Rights-holder release choice remains pending.','files':authored})
 (s/'source-map.json').write_text(json.dumps({'upstream':'Big Rusty Drums v1.100','upstream_commit':'f07ce00','verified_raw_source_files':len(raw_seen),'raw_source_file_hashes':raw_seen,'kit_zone_count':len(allrows),'mapping':{str(k):v for k,v in KIT_MAP.items()},'kit_zone_proof':sourceproof},indent=2,ensure_ascii=False)+'\n')
 write_json(s/'source-proof.json',sourceproof);write_json(s/'map.json',allrows);write_json(s/'credits.json',credits)
 shutil.copy2(BANK/'memphis-fita/samples/LICENSE-Big-Rusty-Drums.txt',s/'LICENSE-Big-Rusty-Drums.txt')
 write_sound(folder,'Drum Phonk Mog','Kit phonk completo · kick phonk/baile, snare, clap, hats, rim e tom sincronizzati su otto tasti GM',allrows,credits,'#d24431','kit',['mog','phonk','memphis-phonk','brazilian-phonk','drum-kit','one-shot'],master_db=-8.0,kit=True)

def compile_owned(slug):
 p=BANK/slug;c=compile_sound(p,jobs=1);print('compile',slug,c.text(),flush=True)
 if not c.ok:raise RuntimeError(f'compile failed {slug}: {c.text()}')
 findings=lint_bundle(p/'build');lines=[f.line() for f in findings]
 (p/'lint.txt').write_text('\n'.join(lines)+'\n')
 fails=[x for x in findings if x.level=='FAIL']
 if fails:raise RuntimeError(f'{slug} lint FAIL: {[x.line() for x in fails]}')
 return lines

def midi_seq(events):return ','.join(f'{n}:{t:.6f}:{d:.5f}:{v}' for n,t,d,v in events)
def db_rms(x):return float(20*math.log10(np.sqrt(np.mean(np.asarray(x,dtype=float)**2))+1e-20))
def audio_stats(path):
 a=Audio.load(path);x=np.asarray(a.data,dtype=float);return {'file':str(path),'peak_dbfs':a.peak_db,'rms_dbfs':a.rms_db,'seconds':len(x)/a.sr,'clipped_samples':int(np.sum(np.abs(x)>=1)),'channels':1 if x.ndim==1 else x.shape[1]}

def qa_individual(slug,lintlines):
 p=BANK/slug;out=DEMO/slug;out.mkdir(parents=True,exist_ok=True)
 meta=PRESETS[slug];vstats=[]
 for vel in (12,32,52,72,94,118):
  path=out/f'hit-v{vel:03d}.wav';render.render(p,path,f'{meta["key"]}:0:.85:{vel}',tail=.25)
  st=audio_stats(path);vstats.append({'velocity':vel,**st})
 # repeated RR test and 2-bar accented groove for recorded zones.
 repeat=out/'round-robin-repeats.wav';render.render(p,repeat,','.join(f'{meta["key"]}:{i*.24:.3f}:.13:{48+(i%4)*22}' for i in range(12)),tail=.5)
 rr=audio_stats(repeat)
 phrase=out/'one-shot-phrase.wav';events=[]
 for i,vel in enumerate([42,88,60,115,53,103,78,120,45,92,66,111,50,100,70,118]):
  events.append((meta['key'],i*.21,.15,vel))
 render.render(p,phrase,midi_seq(events),tail=1.2);ph=audio_stats(phrase)
 return {'slug':slug,'compiled_zones':len(json.loads((p/'build/manifest.json').read_text()).get('zones',[])),
         'source_fresh':library.source_hash(p)==json.loads((p/'build/manifest.json').read_text()).get('source_hash'),
         'compiler_warning_count':len(json.loads((p/'build/manifest.json').read_text()).get('warnings',[])),
         'compile_and_provenance':provenance_check(slug),
         'lint_counts':{k:sum(x.startswith(k+' ') for x in lintlines) for k in ['FAIL','WARN','INFO']},
         'lint_warns':[x for x in lintlines if x.startswith('WARN ')],
         'lint_warn_interpretation':warning_audit(lintlines),
         'lint_failures':[x for x in lintlines if x.startswith('FAIL ')],
         'velocity_hits':vstats,'quick_rr_phrase':rr,'one_shot_phrase':ph,
         'listening_limit':'Native-file checks only; no subjective listening claim.'}

def kit_qa(lintlines):
 p=BANK/KIT;out=DEMO/'drum-phonk-mog';out.mkdir(parents=True,exist_ok=True)
 patterns={}
 for style,bpm in [('memphis-phonk',140),('brazilian-phonk',150)]:
  beat=60/bpm;ev=[]
  for bar in range(4):
   b=bar*4*beat
   # shared heavyweight half-time spine, offset kicks and natural hats
   ev.extend([(36,b,.20,118 if bar%2==0 else 105),(36,b+2.5*beat,.18,107),(38,b+2*beat,.16,114)])
   # one extra baile kick on key 40 and rim ghost-note syncopation
   ev.append((40,b+3.25*beat,.15,92+(bar%2)*12))
   for j in range(8):ev.append((42,b+j*beat/2,.055,56+(j%2)*25))
   ev.append((46,b+3.5*beat,.36,82 if style=='brazilian-phonk' else 70))
   ev.extend([(37,b+1.75*beat,.10,72),(50,b+2.75*beat,.18,94+(bar%2)*15)])
   if style=='brazilian-phonk':
    ev.extend([(39,b+.75*beat,.12,108),(39,b+3.0*beat,.11,92),(40,b+1.5*beat,.15,104)])
   elif bar%2==1:ev.append((39,b+3.5*beat,.12,78))
  path=out/f'{style}-140-native.wav' if style=='memphis-phonk' else out/f'{style}-150-native.wav'
  render.render(p,path,midi_seq(ev),tail=2.0);st=audio_stats(path)
  if st['clipped_samples'] or st['peak_dbfs']>-3.0:raise RuntimeError(f'{style} groove headroom/clipping fail {st}')
  patterns[style]={'bpm':bpm,'meter':'4/4','bars':4,'events':ev,'render':st}
  (out/f'{style}-events.json').write_text(json.dumps(patterns[style],indent=2)+'\n')
 # Dense stress: chords on all 8 kit keys, three overlapping hits and velocities.
 ev=[]
 for i in range(12):
  t=i*.115;vel=[127,107,88][i%3]
  for k in KIT_KEYS:ev.append((k,t,.17,vel if i%3==0 else vel-12))
 stress=out/'dense-eight-key-stress.wav';render.render(p,stress,midi_seq(ev),tail=1.5);ss=audio_stats(stress)
 if ss['clipped_samples'] or ss['peak_dbfs']>-3.0:raise RuntimeError(f'kit stress headroom/clipping fail {ss}')
 # Mono compatibility check; compare true stereo rendered against channel sum.
 mono=out/'dense-eight-key-stress-mono.wav';render.render(p,mono,midi_seq(ev),{'width':0},tail=1.5);ms=audio_stats(mono)
 phrases=[]
 for slug,meta in PRESETS.items():
  if slug not in KIT_MAP.values():continue
  path=BANK/slug/'build'/next(iter([z['file'] for z in json.loads((BANK/slug/'build/manifest.json').read_text())['zones']]))
  phrases.append({'kit_key':meta.get('key'),'source_slug':slug,'first_compiled_zone':str(path)})
 return {'kit':'drum-phonk-mog','compiled_zones':len(json.loads((p/'build/manifest.json').read_text()).get('zones',[])),
         'source_fresh':library.source_hash(p)==json.loads((p/'build/manifest.json').read_text()).get('source_hash'),
         'compiler_warning_count':len(json.loads((p/'build/manifest.json').read_text()).get('warnings',[])),
         'compile_and_provenance':provenance_check(KIT),
         'lint_counts':{k:sum(x.startswith(k+' ') for x in lintlines) for k in ['FAIL','WARN','INFO']},
         'lint_warns':[x for x in lintlines if x.startswith('WARN ')], 'lint_failures':[x for x in lintlines if x.startswith('FAIL ')],
         'lint_warn_interpretation':warning_audit(lintlines),
         'mapping':{str(k):KIT_MAP[k] for k in KIT_KEYS},'patterns':patterns,'dense_eight_key_stress':ss,
         'mono_stress':ms,'native_listening_limit':'Render, RR, clipping, level, and mono checks do not evaluate groove feel or timbre preference.'}

def main():
 DEMO.mkdir(parents=True,exist_ok=True)
 selected=list(PRESETS)+[KIT]
 for slug in PRESETS:
  make_individual(slug,PRESETS[slug],None)
 assemble_kit()
 summary={'created_utc':datetime.now(timezone.utc).isoformat(),'bank':'mog','ownership':'only eight new drum presets plus one new assembled kit; existing bank metadata is not written','presets':[],'kit':None,'source_license':'Big Rusty Drums v1.100 CC0, primary release and attribution details retained; authored synthesis class private/unknown pending explicit redistribution grant.'}
 for slug in PRESETS:
  lines=compile_owned(slug);report=qa_individual(slug,lines);summary['presets'].append(report)
  write_json(DEMO/slug/'verification.json',report)
  p=BANK/slug
  base_notes=(p/'notes.md').read_text().split('\n## Native QA',1)[0]
  reasons=report['lint_warn_interpretation']['reasons']
  explain='\n'.join(f"- {k} ({report['lint_warn_interpretation']['counts_by_category'][k]}): {v}" for k,v in reasons.items()) or '- none'
  (p/'notes.md').write_text(base_notes+'\n## Native QA\n\nCompile: fresh; compiler warnings '+str(report['compiler_warning_count'])+'; lint: 0 FAIL, '+str(report['lint_counts']['WARN'])+' WARN, '+str(report['lint_counts']['INFO'])+' INFO. Six velocity hits, repeated-note run, and one-shot phrase rendered natively. WARN interpretations:\n'+explain+'\n\nFull linter lines are in `~/Libero/demo/mog-drums-v2/'+slug+'/verification.json`. No listening judgment is inferred from metrics.\n')
 lines=compile_owned(KIT);summary['kit']=kit_qa(lines);write_json(DEMO/KIT/'verification.json',summary['kit'])
 p=BANK/KIT;base_notes=(p/'notes.md').read_text().split('\n## Native QA',1)[0]
 reasons=summary['kit']['lint_warn_interpretation']['reasons']
 explain='\n'.join(f"- {k} ({summary['kit']['lint_warn_interpretation']['counts_by_category'][k]}): {v}" for k,v in reasons.items()) or '- none'
 (p/'notes.md').write_text(base_notes+'\n## Native QA\n\nFresh compile; compiler warnings '+str(summary['kit']['compiler_warning_count'])+'; lint 0 FAIL, '+str(summary['kit']['lint_counts']['WARN'])+' WARN. Native Memphis 140 BPM and Brazilian 150 BPM grooves and dense 8-key stress all rendered without clipping; stress peak '+str(round(summary['kit']['dense_eight_key_stress']['peak_dbfs'],2))+' dBFS, mono stress '+str(round(summary['kit']['mono_stress']['peak_dbfs'],2))+' dBFS. WARN interpretations:\n'+explain+'\n\nFull linter lines are in `~/Libero/demo/mog-drums-v2/drum-phonk-mog/verification.json`. Metrics do not certify listening preference or groove feel.\n')
 write_json(DEMO/'report.json',summary)
 print('Built and verified only',selected,flush=True)

if __name__=='__main__':main()
