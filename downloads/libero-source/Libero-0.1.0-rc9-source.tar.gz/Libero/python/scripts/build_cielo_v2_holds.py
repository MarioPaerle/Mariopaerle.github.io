"""Inspect complete compiled low/mid/high holds for all real vowel techniques."""
from pathlib import Path
import sys,json,concurrent.futures
sys.path.insert(0,str(Path(__file__).parent))
from build_cielo_hold_audit import audit
BASE=Path.home()/'Libero/cache/research/cielo-v2';STAGE=BASE/'staged';items=[]
for folder in STAGE.iterdir():
    if not (folder/'sound.py').exists() or folder.name=='ellen-ooh-aha':continue
    m=json.loads((folder/'build/manifest.json').read_text())
    for art in {z['articulation'] for z in m['zones']}:
        zs=[z for z in m['zones'] if z['articulation']==art and z.get('dyn',[0,1])[1]==1];roots=sorted({z['root'] for z in zs});wanted={roots[0],roots[len(roots)//2],roots[-1]}
        items +=[(folder,z) for z in zs if z['root'] in wanted]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(audit,items))
report={'method':'Complete compiled body, low/mid/high per vowel and belt articulation; broad YIN 0.5 s voiced medians; discarded first250 ms/last200 ms. Raw detector octave ambiguity stays explicit. Trillo naturally moves pitch; Volta contains real octave sections, so octave selection is not a source register change. Ellen is a polyphonic original phrase and is explicitly excluded from unison audits.','holds':len(rows),'audits':rows,'flags':[r for r in rows if r['confirmed_non_octave_jump']],'detector_octave_ambiguities':sum(r['tracker_octave_ambiguity'] for r in rows)}
(BASE/'reports/hold-trajectories.json').write_text(json.dumps(report,indent=2));print('holds',len(rows),'flags',len(report['flags']),'octave',report['detector_octave_ambiguities'],flush=True)
for r in report['flags']:print(r,flush=True)
