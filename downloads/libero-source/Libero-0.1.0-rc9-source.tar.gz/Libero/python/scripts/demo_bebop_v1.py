"""Original eight-bar swing arrangement: independently rendered Bebop instruments."""
from pathlib import Path
import json,sys
import numpy as np,soundfile as sf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import render,library
BANK=Path.home()/'Libero/banks/bebop';OUT=Path.home()/'Libero/demo/bebop-v1';STEMS=OUT/'ensemble-stems';STEMS.mkdir(parents=True,exist_ok=True)
B=60/116
tracks={};params={};pans={}
def add(slug,key,beat,length,vel):tracks.setdefault(slug,[]).append((key,beat*B,length*B,vel))
chords=[[53,57,60,63],[53,57,60,63],[58,62,65,68],[53,57,60,63],[55,58,62,65],[60,64,67,70],[53,57,60,63],[60,64,67,70]]
bass=[[29,33,36,38],[29,33,34,35],[34,38,41,40],[29,33,36,37],[31,34,38,40],[36,40,43,42],[29,33,36,38],[36,40,31,28]]
for bar,ch in enumerate(chords):
 base=4*bar
 for beat,key in enumerate(bass[bar]):add('bebop-contrabbasso',key,base+beat,.79,78+(beat%2)*8)
 for beat in [0,1+2/3,2.5]:
  for key in ch:add('bebop-steinway',key,base+beat,.48,80 if beat else 94)
 for beat in [1,3]:
  for key in ch[1:]:add('bebop-chitarra',key,base+beat,.32,84+(bar%2)*8)
 for beat in [0,1,1+2/3,2,3,3+2/3]:add('bebop-batteria',51,base+beat,.16,68+int(beat)%2*15)
 for beat in [1,3]:add('bebop-batteria',44,base+beat,.12,72)
 add('bebop-batteria',36,base,.15,62)
 for beat in [1+2/3,2.5]:add('bebop-batteria',38,base+beat,.15,42)
 if bar in [0,4]:add('bebop-batteria',49,base,.2,85)
 # Independent source instruments provide the ensemble voices. These are
 # separately played parts, not delayed copies of a monophonic melody.
 if bar in [0,2,4,6]:
  for beat in [.5,1+2/3,3]:
   add('bebop-trumpet',ch[2]+12,base+beat,.36,104)
   add('bebop-trombone',ch[0],base+beat,.42,92)
   add('bebop-french-horn',max(50,min(60,ch[1])),base+beat,.48,88)
   add('bebop-tuba',bass[bar][0],base+beat,.43,82)
   add('bebop-sax-alto',ch[1]+12,base+beat,.45,90)
   add('bebop-sax-baritone',bass[bar][0]+12,base+beat,.5,92)
melody=[65,67,69,72,70,69,67,65,68,70,72,74,72,69,67,65,67,69,70,72,74,76,74,72,69,67,65,64,67,70,69,65]
for i,key in enumerate(melody):
 beat=i if i%2==0 else i-1+1+1/3
 add('bebop-sax-tenor',key,beat,.6,96 if i%4==0 else 82)
 if i>=16 and i%2==0:add('bebop-sax-soprano',key+7,beat,.48,78)
 if i in [3,7,11,15,19,23,27,31]:add('bebop-clarinet',key+7,beat,.65,83)
params={'bebop-trumpet':{'artic':2},'bebop-trombone':{'artic':2},'bebop-french-horn':{'artic':1},'bebop-tuba':{'artic':1}}
pans={'bebop-trumpet':.3,'bebop-trombone':-.3,'bebop-french-horn':-.1,'bebop-sax-alto':-.45,'bebop-sax-soprano':.45,'bebop-sax-tenor':.08,'bebop-sax-baritone':-.2,'bebop-clarinet':.25,'bebop-steinway':-.16,'bebop-chitarra':.2}
# Builder's actual baritone final slug is verified against its bank folder.
if not (BANK/'bebop-sax-baritone').exists():tracks['bebop-sax-bari']=tracks.pop('bebop-sax-baritone');pans['bebop-sax-bari']=pans.pop('bebop-sax-baritone')
if not (BANK/'bebop-clarinet').exists():
 candidates=[p.name for p in BANK.iterdir()if 'clarinet' in p.name]
 if len(candidates)!=1:raise RuntimeError('Final clarinet folder unavailable')
 tracks[candidates[0]]=tracks.pop('bebop-clarinet');pans[candidates[0]]=pans.pop('bebop-clarinet')
audio=[];records=[]
for slug,events in tracks.items():
 folder=BANK/slug;m=json.loads((folder/'build/manifest.json').read_text())
 if library.source_hash(folder)!=m['source_hash']:raise RuntimeError('Unfrozen/stale source '+slug)
 file=STEMS/f'{slug}.wav';render.render(folder,file,events,params.get(slug,{}),tail=3);x,sr=sf.read(file,always_2d=True)
 clipped=int(np.count_nonzero(abs(x)>=1))
 if clipped:raise RuntimeError(f'Native stem {slug} clipped {clipped} samples before mix attenuation')
 pan=pans.get(slug,0);x=x*np.array([min(1,1-pan),min(1,1+pan)])
 audio.append(x);records.append({'slug':slug,'source_hash':m['source_hash'],'events':events,'params':params.get(slug,{}),'pan':pan,'file':str(file)})
 print(slug,len(events),flush=True)
mix=np.zeros((max(len(x)for x in audio),2))
for x in audio:mix[:len(x)]+=x
peak=np.max(abs(mix));gain=min(1,10**(-3/20)/max(peak,1e-15));mix*=gain
sf.write(OUT/'bebop-big-band-native.wav',mix,sr,subtype='PCM_24')
(OUT/'ensemble.json').write_text(json.dumps({'tempo':116,'bars':8,'tracks':records,'common_mix_gain_db':float(20*np.log10(gain)),'peak_dbfs':float(20*np.log10(np.max(abs(mix)))),'seconds':len(mix)/sr,'construction':'Original arrangement, independently played native instruments with simple pan and common attenuation; no duplicated/delayed ensemble voices, limiter, or post-render effects. This is a multitrack demo, not a single-key automatic big-band preset.'},indent=2)+'\n')
print('ensemble',len(mix)/sr,'seconds',flush=True)
