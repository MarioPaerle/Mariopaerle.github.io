"""Independent source/provenance and native behavior audit for the four Leisureland Mellotrons."""
from __future__ import annotations
import base64, hashlib, json, math, sys, zipfile
from pathlib import Path
import numpy as np
import soundfile as sf
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'python'))
from libero import library, render
from libero.dsp import estimate_f0
from libero.lint import lint_bundle
from build_giove_mellotron_v2 import BANK, CACHE, DESIGNS, sha
OUT=Path.home()/'Libero/demo/giove-v2/mellotron'
RENDERER=Path('/Users/mario/Documents/Libero/build/plugin/libero_render_artefacts/Release/libero-render')


def audio_stats(path):
    x,sr=sf.read(path,always_2d=True,dtype='float64')
    peak=float(np.max(np.abs(x))) if x.size else 0
    rms=lambda a: float(20*np.log10(max(float(np.sqrt(np.mean(np.square(a)))),1e-15)))
    result={'sample_rate':sr,'frames':len(x),'duration_s':len(x)/sr,'peak_dbfs':20*math.log10(max(peak,1e-15)),
            'clipped_samples':int(np.count_nonzero(np.abs(x)>=1.0)),'finite':bool(np.isfinite(x).all()),
            'early_rms_dbfs':rms(x[int(.5*sr):min(len(x),int(2.5*sr))])}
    if len(x)>int(55*sr): result['late_rms_dbfs']=rms(x[int(10*sr):int(55*sr)])
    if len(x)>int(9*sr): result['tail_rms_dbfs']=rms(x[int(9*sr):])
    return result


def pitch_family_evidence(path, root):
    x,sr=sf.read(path,dtype='float64',always_2d=True); x=x.mean(axis=1)
    expected=440.0*2**((root-69)/12)
    windows=[]
    for start in (1.0,3.0,5.0):
        n=min(int(1.1*sr),len(x)-int(start*sr))
        if n<sr//2: continue
        y=x[int(start*sr):int(start*sr)+n]
        y=(y-y.mean())*np.hanning(n); spec=np.abs(np.fft.rfft(y)); freqs=np.fft.rfftfreq(n,1/sr)
        scores={}
        # Broad octave hypotheses, judged by odd partial families over several windows.
        for shift in (-12,0,12):
            f0=expected*2**(shift/12); vals=[]
            for h in (1,3,5,7,9):
                f=f0*h
                if f>=sr*.45: continue
                mask=np.abs(freqs-f)<=max(2.5, f*.022)
                vals.append(float(np.max(spec[mask]))/h if mask.any() else 0.)
            scores[str(shift)]=float(sum(vals))
        winner=max(scores,key=scores.get)
        denom=max(max(scores.values()),1e-15)
        windows.append({'start_s':start,'best_octave_offset_semitones':int(winner),'candidate_relative_scores':{k:v/denom for k,v in scores.items()}})
    offsets=[w['best_octave_offset_semitones'] for w in windows]
    supported=bool(len(offsets)>=2 and offsets.count(0)>=2)
    ambiguous=not supported and len(set(offsets))>1
    return {'expected_midi':root,'windows':windows,'interpretation':'odd-harmonic family comparison at mapped pitch and ±1 octave; broad check for octave-scale errors, not a cents tuner',
            'status':'supported' if supported else ('ambiguous' if ambiguous or not windows else 'offset-suspected'),
            'consistent_expected_octave_windows':offsets.count(0)}


def autocorr_periodicity(path, filename_root):
    x,sr=sf.read(path,dtype='float64',always_2d=True); x=x.mean(axis=1); windows=[]
    for start in (1.0,3.0,5.0):
        n=min(int(1.05*sr),len(x)-int(start*sr))
        if n<sr//2: continue
        y=x[int(start*sr):int(start*sr)+n].copy(); y-=y.mean(); N=len(y)
        ac=np.fft.irfft(np.abs(np.fft.rfft(y,n=2*N))**2,n=2*N)[:N]
        e=np.r_[0.0,np.cumsum(y*y)]; scores={}
        for shift in (12,0,-12):
            hz=440*2**((filename_root+shift-69)/12); lag=sr/hz
            lo=max(1,int(lag*.985)); hi=min(N-2,int(lag*1.015)+1); vals=[]
            for lag_i in range(lo,hi+1):
                den=np.sqrt(e[N-lag_i]*(e[N]-e[lag_i]))
                if den: vals.append(float(ac[lag_i]/den))
            scores[str(shift)]=max(vals,default=-1.0)
        # A lower octave repeats every two cycles even when it is not the fundamental.
        # Choose the shortest period whose multi-window normalized correlation is strong.
        chosen=next((shift for shift in (12,0,-12) if scores[str(shift)]>=.80),None)
        windows.append({'start_s':start,'normalized_period_correlation_by_offset':scores,
                        'shortest_strong_period_offset_semitones':chosen})
    votes=[w['shortest_strong_period_offset_semitones'] for w in windows if w['shortest_strong_period_offset_semitones'] is not None]
    common=max(set(votes),key=votes.count) if votes else None
    consistent=common is not None and votes.count(common)>=max(2,len(windows)-1)
    return {'windows':windows,'recommended_octave_offset_semitones':common if consistent else None,
            'status':'supported' if consistent else 'ambiguous',
            'method':'normalized autocorrelation; shortest candidate period over 0.80 correlation across at least 2 of 3 windows; octave-only candidate hypotheses'}

def audit_sources(slug,archive_name,errors):
    folder=BANK/slug; samples=folder/'samples'; acquisition=json.loads((CACHE/'acquisition.json').read_text())
    rec=next(r for r in acquisition if r['file']==archive_name); archive=CACHE/archive_name; body=archive.read_bytes()
    zip_ok=sha(archive)==rec['sha256'] and len(body)==rec['bytes'] and base64.b32encode(hashlib.sha1(body).digest()).decode().rstrip('=')==rec['cdx_sha1_base32']
    if not zip_ok: errors.append(f'{slug}: archive SHA/CDX mismatch')
    proof=json.loads((samples/'source-proof.json').read_text()); mapping=json.loads((samples/'map.json').read_text())
    names=[]; rows=[]
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None: errors.append(f'{slug}: damaged ZIP member')
        names=sorted(Path(n).name for n in z.namelist() if n.lower().endswith('.wav'))
        for r in proof:
            p=samples/r['file']; raw=z.read(Path(r['file']).name)
            if hashlib.sha256(raw).hexdigest()!=r['sha256'] or p.read_bytes()!=raw: errors.append(f'{slug}: original changed {r["file"]}')
            info=sf.info(p)
            if info.frames!=r['frames'] or info.samplerate!=r['sample_rate'] or info.subtype!=r['encoding']:
                errors.append(f'{slug}: source info mismatch {r["file"]}')
            if not 6.5 < info.duration < 9.0: errors.append(f'{slug}: unexpected original duration {r["file"]}')
            loop=samples/r['sustained_derivation']['file']
            if sha(loop)!=r['sustained_derivation']['sha256']: errors.append(f'{slug}: derived sustain hash mismatch {loop.name}')
            filename_root=r.get('filename_root',r['root']); mapped_root=r.get('mapped_root',r['root'])
            verified_physical_root=r.get('physical_root') if slug in {'mellotron-mkii-flute','mellotron-mkii-strings'} else None
            analysis_root=mapped_root
            expected=440.0*2**((analysis_root-69)/12); pitch_windows=[]
            mono,_sr=sf.read(p,dtype='float64',always_2d=True); mono=mono.mean(axis=1)
            for start in (0.8,2.2,3.8,5.4):
                seg=mono[int(start*info.samplerate):int((start+1.0)*info.samplerate)]
                hz,voiced=estimate_f0(seg,info.samplerate,30.0,6000.0)
                cents=float(1200*np.log2(hz/expected)) if math.isfinite(hz) and hz>0 else None
                pitch_windows.append({'start_s':start,'f0_hz':float(hz) if math.isfinite(hz) else None,'voiced_fraction':float(voiced),'cents_from_mapped_root':cents})
            finite_cents=[v['cents_from_mapped_root'] for v in pitch_windows if v['cents_from_mapped_root'] is not None and v['voiced_fraction']>=.5]
            median_cents=float(np.median(finite_cents)) if finite_cents else None
            filename_cents=(mapped_root-filename_root)*100.0
            rows.append({'key':filename_root,'physical_key':mapped_root,'file':r['file'],'sha256':r['sha256'],'duration_s':info.duration,
                         'filename_root_midi':filename_root,'mapped_root_midi':mapped_root,'verified_physical_root_midi':verified_physical_root,
                         'broad_period_pitch_windows':pitch_windows,
                         'broad_period_median_cents_from_mapped_root':median_cents,
                         'broad_period_median_cents_from_filename_root':(median_cents+filename_cents),
                         'pitch_family':pitch_family_evidence(p,analysis_root),
                         'autocorrelation_periodicity':autocorr_periodicity(p,filename_root),
                         'loop_error_db':r['sustained_derivation']['loop_error_db']})
    if len(proof)!=35 or len(names)!=35 or sorted(r.get('filename_root',r['root']) for r in proof)!=list(range(43,78)):
        errors.append(f'{slug}: expected precisely 35 notes G2–F5')
    if len(mapping)!=70: errors.append(f'{slug}: expected 70 mapped zones')
    cdx=json.loads((CACHE/'wayback-cdx.json').read_text())
    # The acquisition file records the exact digest returned by the archived CDX query;
    # require the copied CDX capture and acquisition record to carry each digest.
    if not (samples/'wayback-cdx.json').exists(): errors.append(f'{slug}: missing archived CDX evidence')
    original_art=[r for r in mapping if r['articulation']=='tape_original']
    sustain_art=[r for r in mapping if r['articulation']=='sustained']
    if len(original_art)!=35 or len(sustain_art)!=35: errors.append(f'{slug}: articulation map incomplete')
    return {'archive':archive_name,'archive_bytes':len(body),'archive_sha256':sha(archive),
            'archive_cdx_sha1_base32':rec['cdx_sha1_base32'],'archive_integrity_pass':zip_ok,
            'original_wavs':rows,'original_count':len(proof),'map_zones':len(mapping),
            'articulations':{'sustained':len(sustain_art),'tape_original':len(original_art)},
            'all_original_wav_bytes_match_archive':len(proof)==35 and not any(e.startswith(slug+': original changed') for e in errors),
            'octave_audit_summary':{state:sum(r['pitch_family']['status']==state for r in rows) for state in ('supported','ambiguous','offset-suspected')},
            'autocorrelation_octave_offsets':{str(o):sum(r['autocorrelation_periodicity']['recommended_octave_offset_semitones']==o for r in rows) for o in (-12,0,12)},
            'autocorrelation_ambiguous':sum(r['autocorrelation_periodicity']['status']!='supported' for r in rows),
            'broad_period_median_cents_summary':{'median_from_mapped_root':float(np.median([r['broad_period_median_cents_from_mapped_root'] for r in rows if r['broad_period_median_cents_from_mapped_root'] is not None])) if any(r['broad_period_median_cents_from_mapped_root'] is not None for r in rows) else None,'within_50c_of_mapped_root':sum(r['broad_period_median_cents_from_mapped_root'] is not None and abs(r['broad_period_median_cents_from_mapped_root'])<50 for r in rows),'octave_or_larger_from_filename_root':sum(r['broad_period_median_cents_from_filename_root'] is not None and abs(r['broad_period_median_cents_from_filename_root'])>600 for r in rows)},
            'cdx_evidence_sha256':sha(samples/'wayback-cdx.json') if (samples/'wayback-cdx.json').exists() else None}


def verify(slug,archive_name):
    p=BANK/slug; out=OUT/slug; out.mkdir(parents=True,exist_ok=True); errors=[]
    source=audit_sources(slug,archive_name,errors)
    manifest=json.loads((p/'build/manifest.json').read_text())
    if not library.source_hash(p)==manifest['source_hash']: errors.append('stale source hash')
    lint=lint_bundle(p/'build'); errors.extend(f'lint FAIL: {x}' for x in lint if x.level=='FAIL')
    valid=library.validate_bundle(p/'build'); errors.extend(f'bundle invalid: {x}' for x in valid)
    if len(manifest['zones'])!=70: errors.append('compiled zone count != 70')
    originals={Path(r['file']).stem:r for r in source['original_wavs']}
    playable=sorted({z['lo'] for z in manifest['zones'] if z['layer']=='body'})
    if len(playable)!=35: errors.append(f'expected 35 distinct playable roots, got {len(playable)}')
    # The finite zones must retain source duration through compilation (apart from tiny trim/encoding changes).
    durations=[]
    for z in manifest['zones']:
        if z.get('articulation')!='tape_original': continue
        fn=p/'build'/z['file']; compiled=sf.info(fn).duration
        raw=originals.get(Path(z['file'].replace('body_tape_original_n','')).stem)
        # Zone map key is the strongest check; build filenames are note-number based.
        key=z['lo']; src=next(r for r in source['original_wavs'] if r['physical_key']==key)
        delta=compiled-src['duration_s']; durations.append({'key':key,'compiled_s':compiled,'source_s':src['duration_s'],'delta_s':delta})
        if abs(delta)>.08: errors.append(f'finite tape duration changed at key {key}: {delta:.3f}s')
        if z.get('loop'): errors.append(f'finite tape zone unexpectedly looped at {key}')
    holds=[]
    keys=[playable[0],playable[len(playable)//2],playable[-1]]
    for k in keys:
        wav=out/f'hold-{k}-60s.wav'; render.render(p,wav,[(k,0,60,100)],{'artic':0},tail=.5,timeout=240); q=audio_stats(wav)
        holds.append({'key':k,**q})
        if not q['finite'] or q['clipped_samples'] or q.get('late_rms_dbfs',-120)<-48: errors.append(f'60s sustained hold failed key{k}: {q}')
    stack_keys=[playable[round((len(playable)-1)*i/7)] for i in range(8)]
    stacks=[]
    for mode,par in [('default',{'artic':0}),('maximum-dynamics',{'artic':0,'dyn_mode':'Manopola','dynamics':1})]:
        wav=out/f'stack8-{mode}.wav'; render.render(p,wav,[(k,0,4,127) for k in stack_keys],par,tail=.5,timeout=180); q=audio_stats(wav)
        stacks.append({'mode':mode,'keys':stack_keys,'events':8,**q})
        if not q['finite'] or q['clipped_samples'] or q['peak_dbfs']>-.1: errors.append(f'8-note headroom failed {mode}: {q}')
    # Original performance is finite while the MIDI gate remains open; test key-off separately.
    tape_key=playable[len(playable)//2]
    tape=out/'tape-original-held-12s.wav'; render.render(p,tape,[(tape_key,0,12,100)],{'artic':1},tail=.2,timeout=120); tq=audio_stats(tape)
    before,after=sf.read(tape,always_2d=True,dtype='float64'); sr=sf.info(tape).samplerate
    e8=float(np.sqrt(np.mean(before[int(7.8*sr):int(8.2*sr)]**2)))
    e11=float(np.sqrt(np.mean(before[int(10.5*sr):int(11.5*sr)]**2)))
    tape_test={'render':tq,'rms_near_8s_dbfs':20*math.log10(max(e8,1e-15)),
               'rms_10.5_to_11.5s_dbfs':20*math.log10(max(e11,1e-15)),
               'interpretation':'Finite original recording ends naturally while MIDI note remains held.'}
    if e8<e11 or 20*math.log10(max(e11,1e-15))>-50: errors.append(f'tape-original did not decay/end while held: {tape_test}')
    off=out/'tape-original-noteoff.wav'; render.render(p,off,[(tape_key,0,2,100)],{'artic':1},tail=3,timeout=120); oq=audio_stats(off)
    sustained=out/'selector-param.wav'; key=out/'selector-keyswitch.wav'
    render.render(p,sustained,[(tape_key,.1,2,100)],{'artic':0},tail=.2)
    render.render(p,key,[(24,0,.05,100),(tape_key,.1,2,100)],{},tail=.2)
    a,_=sf.read(sustained,dtype='float64'); b,_=sf.read(key,dtype='float64')
    artdiff=float(np.max(np.abs(a-b))) if len(a)==len(b) else None
    if artdiff is None or artdiff>1e-5: errors.append(f'sustained articulation parameter/keyswitch mismatch: {artdiff}')
    render.render(p,out/'tape-param.wav',[(tape_key,.1,2,100)],{'artic':1},tail=.2)
    render.render(p,out/'tape-keyswitch.wav',[(25,0,.05,100),(tape_key,.1,2,100)],{},tail=.2)
    ta,_=sf.read(out/'tape-param.wav',dtype='float64'); tb,_=sf.read(out/'tape-keyswitch.wav',dtype='float64')
    tapediff=float(np.max(np.abs(ta-tb))) if len(ta)==len(tb) else None
    if tapediff is None or tapediff>1e-5: errors.append(f'tape articulation parameter/keyswitch mismatch: {tapediff}')
    pitch_mapping_ok=(slug in {'mellotron-mkii-flute','mellotron-mkii-strings'} and source['broad_period_median_cents_summary']['within_50c_of_mapped_root']==35 and source['autocorrelation_octave_offsets'].get('12',0)==35)
    pitch_status='PASS' if pitch_mapping_ok else 'REVIEW_REQUIRED'
    result={'slug':slug,'status':'PASS' if not errors and pitch_mapping_ok else ('PENDING_PITCH_ROOT' if not errors else 'FAIL'),
            'native_integrity_status':'PASS' if not errors else 'FAIL','pitch_mapping_status':pitch_status,'source_hash':manifest['source_hash'],
            'source_hash_fresh':library.source_hash(p)==manifest['source_hash'],'source_authenticity':source,
            'zones':len(manifest['zones']),'lint':{'FAIL':sum(x.level=='FAIL' for x in lint),'WARN':sum(x.level=='WARN' for x in lint)},
            'finite_source_duration_checks':durations,'duration_max_abs_delta_s':max(abs(x['delta_s']) for x in durations),
            'sustained_holds':holds,'eight_note_headroom':stacks,'finite_articulation_held_12s':tape_test,
            'tape_noteoff':oq,'articulation_param_keyswitch_max_abs_difference':{'sustained':artdiff,'tape_original':tapediff},
            'measurements_note':'Native renderer only. These measurements establish source integrity, mapping, continuity, finite recording behavior, and headroom; they do not establish perceived realism or that the Instagram reference was heard.',
            'errors':errors}
    (out/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    print(slug,result['status'],'hold late dB', [round(x['late_rms_dbfs'],1) for x in holds],
          'peak max',round(max(x['peak_dbfs'] for x in stacks),2),'duration Δ',round(result['duration_max_abs_delta_s'],4),'errors',errors,flush=True)
    return result

def main():
    import os, argparse
    ap=argparse.ArgumentParser(); ap.add_argument('--slugs', nargs='*', choices=DESIGNS, default=list(DESIGNS)); args=ap.parse_args()
    os.environ['LIBERO_RENDER']=str(RENDERER)
    result=[verify(slug,DESIGNS[slug][0]) for slug in args.slugs]
    report={'status':'PASS' if all(x['status']=='PASS' for x in result) else ('PENDING_PITCH_ROOT' if all(x['native_integrity_status']=='PASS' for x in result) else 'FAIL'),'checks':result}
    OUT.mkdir(parents=True,exist_ok=True); (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
