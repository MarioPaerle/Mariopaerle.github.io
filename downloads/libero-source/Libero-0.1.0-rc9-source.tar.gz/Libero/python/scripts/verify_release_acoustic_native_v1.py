#!/usr/bin/env python3
"""Native held-note checks for the seven source-led public acoustic replacements."""
import json, sys
from pathlib import Path
import numpy as np
import soundfile as sf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import render, library
sys.path.insert(0,str(ROOT/'python/scripts'))
from calibrate_blue_v6_body import estimate
BASE=Path.home()/'Libero';OUT=BASE/'demo/release-replacements-v1/acoustic/native';OUT.mkdir(parents=True,exist_ok=True)
FOLDERS={
 'violoncello-solo-libero':BASE/'banks/archi/violoncello-solo-libero',
 'archi-armonici-libero':BASE/'banks/archi/archi-armonici-libero',
 'archi-particolari-libero':BASE/'banks/archi/archi-particolari-libero',
 'mandolino-dorato-libero':BASE/'banks/aria/mandolino-dorato-libero',
 'chitarra-classica-libero':BASE/'banks/chitarre/chitarra-classica-libero',
 'chitarra-classica-accordi-libero':BASE/'banks/chitarre/chitarra-classica-accordi-libero',
 'corno-francese-libero':BASE/'banks/ottoni/corno-francese-libero',
}
def metric(path,note):
    x,sr=sf.read(path,dtype='float32',always_2d=True);peak=float(np.max(np.abs(x)));begin=int(min(10.0,max(.5,len(x)/sr*.25))*sr);end=min(len(x),int(max(.6,len(x)/sr-.2)*sr));late=x[begin:end]
    rms=float(np.sqrt(np.mean(late*late)+1e-20));target=440*2**((note-69)/12);cents=[];freqs=[]
    # Median FFT fundamental across one-second windows, robust to vibrato and
    # tremolo partial movement; search close to the expected fundamental.
    for start in (np.arange(1.0,min(7.0,len(x)/sr-1.0),.5) if len(x)/sr>8 else []):
        seg=x[int(start*sr):int((start+1.0)*sr)].mean(axis=1);n=len(seg)
        spec=np.abs(np.fft.rfft(seg*np.hanning(n)));hz=np.fft.rfftfreq(n,1/sr)
        inds=np.where((hz>=target*.94)&(hz<=target*1.06))[0]
        if len(inds):
            f=float(hz[inds[np.argmax(spec[inds])]]);freqs.append(f);cents.append(1200*np.log2(f/target))
    if len(x)/sr>8:
        pstart=int(2*sr);pend=int(4*sr);freq,cents_est=estimate(x[pstart:pend],sr,target)
    else:freq,cents_est=0.0,0.0
    # Spectral-bin median is retained as a second observation for moving
    # tremolo bodies; the estimator is the primary value for steady sources.
    if len(cents)>1 and np.std(cents)>8:cent=float(np.median(cents));freq=float(np.median(freqs))
    else:cent=float(cents_est)
    return {'duration_seconds':round(len(x)/sr,3),'peak_dbfs':round(20*np.log10(max(peak,1e-12)),2),'late_rms_dbfs':round(20*np.log10(max(rms,1e-12)),2),'clip_samples':int(np.sum(np.abs(x)>=.9999)),'sample_rate':sr,'stable_body_hz':round(freq,3),'stable_body_cents':round(cent,2)}
report={'native_renderer':str(render.find_renderer()),'checks':{},'errors':[],
        'criteria':'60-second native holds: duration >=59.5 s, late-window RMS >= -55 dBFS, zero clipped samples; all-art 3 s native previews; eight-note chord-stack peak <= -3 dBFS.',
        'pitch_limitation':'Stable-body cents are representative-note diagnostics from sampled windows, not an all-key calibration. Recorded tremolo/vibrato and composed multi-note chord tones can confuse a single-fundamental estimator; use native per-root/key-edge audit for tuning decisions.'}
for slug,folder in FOLDERS.items():
 zones=json.loads((folder/'samples/map.json').read_text())['body']; arts=list(dict.fromkeys(z.get('articulation') for z in zones));main=arts[0]
 zs=[z for z in zones if z.get('articulation')==main and z.get('pitched') is not False]
 roots=sorted(set(int(z['root']) for z in zs));
 if slug=='archi-armonici-libero': notes=roots
 else:
  picks=[]
  for q in (.15,.5,.85):
   target=roots[min(len(roots)-1,round(q*(len(roots)-1)))];picks.append(target)
  notes=sorted(set(picks))
 rows=[]
 for n in notes:
  out=OUT/f'{slug}-{main}-{n}-60s.wav'
  try:
   render.render(folder,out,f'{n}:0:60:100',tail=.15,timeout=240)
   m=metric(out,n);rows.append({'note':n,'articulation':main,'file':str(out),**m})
   if m['duration_seconds']<59.5:report['errors'].append(f'{slug} {n}: native output shorter than hold')
   if m['late_rms_dbfs']<-55:report['errors'].append(f'{slug} {n}: late held body is near-silent ({m["late_rms_dbfs"]} dBFS)')
   if m['clip_samples']:report['errors'].append(f'{slug} {n}: native hold clips {m["clip_samples"]} samples')
  except Exception as e:report['errors'].append(f'{slug} {n}: {type(e).__name__}: {e}')
 manifest=json.loads((folder/'build/manifest.json').read_text());art_previews=[]
 for idx,art in enumerate(arts):
  candidates=[z for z in zones if z.get('articulation')==art and z.get('pitched') is not False]
  if not candidates:continue
  z=candidates[len(candidates)//2];note=int(z['root']);out=OUT/f'{slug}-{art}-art-preview.wav'
  try:
   render.render(folder,out,f'{note}:0:3:100',params={'artic':idx},tail=.1,timeout=180)
   art_previews.append({'articulation':art,'note':note,**metric(out,note)})
  except Exception as e:report['errors'].append(f'{slug} articulation {art}: {type(e).__name__}: {e}')
 report['checks'][slug]={'main_articulation':main,'available_roots':roots,'held_notes':rows,'articulation_previews':art_previews,'zone_count':len(zones),'source_hash_fresh':library.source_hash(folder)==manifest['source_hash']}

# Chord preset: eight simultaneous authored chord roots, both major/minor
# articulations, native headroom and clipping check.
folder=FOLDERS['chitarra-classica-accordi-libero'];chords=json.loads((folder/'samples/map.json').read_text())['body'];chord_roots=sorted({int(z['root']) for z in chords});stack=chord_roots[:8]
report['chord_stack']={}
for idx,art in enumerate(('major','minor')):
 out=OUT/f'guitar-chords-{art}-8stack.wav';events=[(n,0,4,127) for n in stack]
 try:
  render.render(folder,out,events,params={'artic':idx},tail=.15,timeout=180);m=metric(out,stack[len(stack)//2]);report['chord_stack'][art]={'notes':stack,**m}
  if m['clip_samples'] or m['peak_dbfs']>-3:report['errors'].append(f'8-chord {art} stack exceeds headroom: peak {m["peak_dbfs"]} dBFS, clips {m["clip_samples"]}')
 except Exception as e:report['errors'].append(f'8-chord {art} stack: {type(e).__name__}: {e}')
report['status']='PASS' if not report['errors'] else 'FAIL'
(OUT.parent/'native-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':report['status'],'errors':report['errors'],'notes':sum(len(x['held_notes']) for x in report['checks'].values()),'report':str(OUT.parent/'native-report.json')},indent=2))
