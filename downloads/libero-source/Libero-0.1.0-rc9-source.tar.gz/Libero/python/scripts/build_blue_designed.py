"""Three original Blue voices: FM keys, additive reed pad, live PWM/triangle pad.

These are declared electronic designs, never purported recordings of real keys.
Only their owned folders are written. Acoustic Blue sources use another builder.
"""
from pathlib import Path
import sys, json, math, shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, analysis, render, library
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero.figure import validate_svg, rasterize

HOME=Path.home();BANK=HOME/'Libero/banks/blue';OUT=HOME/'Libero/demo/blue-designed'
SR=48000;PERIOD=16;ROOTS=[36,43,48,55,60,67,72,79,84]
DESIGNS={
 'fosforo-tasti':('Fosforo · Tasti','tasti FM originali · colpo vellutato, corpo elettrico',0),
 'indaco-ance':('Indaco · Ance','pad additivo originale · registro pieno e formanti mobili',320),
 'rame-notturno':('Rame Notturno','pad analogico vivo · impulsi, triangolo e corpo centrale',500),
}

def original_cycle(slug,root,vel):
    n=SR*PERIOD;t=np.arange(n)/SR;f=round(440*2**((root-69)/12)*PERIOD)/PERIOD
    ph=2*np.pi*f*t;v=(vel-1)/126
    if slug=='fosforo-tasti':
        # Grounded carrier and two quiet higher registers remain audible while
        # phase modulation supplies changing internal partials, not an effect.
        idx=.38+.20*v+.075*np.sin(2*np.pi*t/PERIOD)
        main=.68*np.sin(ph)+.23*np.sin(ph+idx*np.sin(2*ph))
        main+=(.15+.09*v)*np.sin(2*ph+.2)+.08*np.sin(3*ph+.4)
        left=main+.06*np.sin(ph*2+2*np.pi*t/PERIOD+.8)
        right=main+.06*np.sin(ph*2-2*np.pi*t/PERIOD+.8)
        x=np.column_stack([left,right])
        description={'route':'SYN','construction':'grounded carrier + phase-modulated carrier, second/third registers; quiet periodic sidebands','fm_index_range':[.305+.20*v,.455+.20*v],'fundamental_hz':f}
    else:
        # Fixed acoustic-style spectral centres shape an electronic reed cloud.
        # The centre stays stable; changing group weights move its brightness.
        x=np.zeros((n,2));partials=[]
        for k in range(1,min(36,int(12000/f))+1):
            hz=k*f
            form=1+.75*np.exp(-.5*((hz-550)/220)**2)+.9*np.exp(-.5*((hz-1250)/420)**2)
            amp=(1.12 if k==1 else .55/(k**1.16))*form
            amp*=1 if k==1 else (.65+.35*v)
            move=1 if k==1 else 1+.10*np.sin(2*np.pi*(1+k%3)*t/PERIOD+.61*k)
            for c in [0,1]:
                phase=.39*k+(0 if k==1 else (1 if c==0 else -1)*.08)
                x[:,c]+=amp*move*np.sin(2*np.pi*hz*t+phase)
                if k>1:
                    shadow=(round(hz*PERIOD)+(1 if c==0 else -1))/PERIOD
                    x[:,c]+=.10*amp*np.sin(2*np.pi*shadow*t+.61*k)
            partials.append([round(hz,4),round(amp,5)])
        description={'route':'SYN','construction':'stable fundamental, additive reed registers, two spectral centres, quiet upper sidebands','spectral_centres_hz':[550,1250],'partials':partials,'fundamental_hz':f}
    # Separate authored soft and hard timbres: never labelled recorded dynamics.
    x*=10**((-9+5*v)/20)
    count=int((PERIOD+1.15)*SR);y=x[np.arange(count)%n].copy()
    tt=np.arange(count)/SR
    if slug=='fosforo-tasti':
        # One onset only; it cannot recur at a loop wrap.
        transient=np.zeros(count);active=tt<.85
        transient[active]=.12*v*np.sin(2*np.pi*f*tt[active]+(1.2+1.8*v)*np.exp(-tt[active]/.19)*np.sin(6*np.pi*f*tt[active]))*np.exp(-tt[active]/.16)
        y+=transient[:,None]
        y[:288]*=np.linspace(0,1,288)[:,None]
    y=np.concatenate([np.zeros((480,2)),y])
    return Audio(y,SR),{'start':SR+480,'end':SR+480+n},description

def figure(slug):
    if slug=='fosforo-tasti':
        shapes=['<path d="M106 351H406V389H106Z" fill="#f3eee6" stroke-width="1.2"/>']
        for i in range(12):shapes.append(f'<path d="M{117+24*i} 356V386" stroke-width=".6"/>')
        for i,rad in enumerate([104,75,43]):
            shapes.append(f'<path d="M{256-rad} 236a{rad} {rad} 0 0 1 {2*rad} 0a{rad} {rad} 0 0 1 {-2*rad} 0" stroke="{("#b8924f" if i==0 else "currentColor")}" stroke-width="{1.2-i*.2}"/>')
        shapes.append('<path d="M151 235Q196 180 235 235T361 235M256 120V344" stroke-width=".8"/>')
        desc='Tre registri di tasti FM: portante centrale, registro doppio e triplo. Il cerchio dorato è il corpo persistente; il gesto ondulato è la modulazione di fase.'
    elif slug=='indaco-ance':
        shapes=['<path d="M107 369H405V393H107Z" fill="#f3eee6" stroke-width="1.1"/>']
        for i in range(17):
            x=123+i*16;top=121+int(135*(i/16)**.7)
            shapes.append(f'<path d="M{x} 367V{top}q6 -9 12 0v{367-top}" stroke-width=".8"/>')
        shapes+=['<path d="M115 275Q256 305 397 275M115 236Q256 266 397 236" stroke="#b8924f" stroke-width="1.1"/>']
        desc='Un banco di ance elettroniche con fondamentale stabile. Le due curve dorate identificano i centri spettrali a 550 e 1250Hz.'
    else:
        shapes=['<path d="M94 184H418V332H94Z" fill="#f3eee6" stroke-width="1.2"/>','<path d="M113 273V219H157V273H201V219H245V273H289V219H333V273H377" stroke="#b8924f" stroke-width="1.3"/>','<path d="M113 303L179 198L245 303L311 198L377 303" stroke-width=".9"/>','<path d="M94 344H418M94 355H418" stroke-width=".6"/>']
        desc='Impulsi e triangolo nello stesso corpo elettronico. I rettangoli dorati sono il registro pulsato, il profilo triangolare il suo corpo inferiore.'
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>'+DESIGNS[slug][0]+'</title><desc>'+desc+'</desc>'+''.join(shapes)+'</svg>'

def build(slug):
    p=BANK/slug;p.mkdir(parents=True,exist_ok=True);s=p/'samples';s.mkdir(exist_ok=True)
    title,subtitle,attack=DESIGNS[slug];rows=[];proof=[]
    if slug!='rame-notturno':
        for root in ROOTS:
            for lo,hi,vel in [(1,79,55),(80,127,115)]:
                a,lp,meta=original_cycle(slug,root,vel);name=f'{root}-{vel}.flac';a.save(s/name,subtype='PCM_24')
                rows.append({'file':name,'root':root,'vel':[lo,hi],'loop':lp,'take':0})
                proof.append({'file':name,'root':root,'authored_velocity':vel,'period_seconds':PERIOD,**meta})
        (s/'map.json').write_text(json.dumps(rows,indent=2)+'\n')
        (s/'design-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
        recipe=f'''import json
from pathlib import Path
from libero import Sound
sound=Sound(title={title!r},subtitle={subtitle!r},tags=['blue','designed','electronic','infinite'],roots={ROOTS!r})
sound.multisample('body',json.loads((Path(__file__).parent/'samples/map.json').read_text()),as_dyn=False,process={{'tune':'source','ladder':'keep','peak_db':-12,'align_ms':0,'pre_ms':10,'loop':'source','max_seconds':None,'end_db':-100,'encoding':'flac24','edge_fill':True}})
sound.performance(dynamics_source='velocity',dyn_crossfade=0,humanize={{'cents':0,'ms':0,'db':0}})
sound.defaults(mode='Poli',glide=0,voices=16,amp_attack={attack},amp_decay=10000,amp_sustain=1,amp_release={700 if attack else 350},master=-5,vel_sens=.38,osc1_level=-60,osc2_level=-60,sub_level=-60,lvl_body=0,lvl_attack=-60,lvl_air=-60,lvl_tail=-60,drive=0,tape_wow=0,tape_flutter=0,tape_mix=0,tape_sat=0,echo_mix=0,res_mix=0,rev_mix=.045,rev_decay=1.1,rev_damp=.6)
'''
    else:
        recipe=f'''from libero import Sound
sound=Sound(title={title!r},subtitle={subtitle!r},tags=['blue','pad','live-synthesis','infinite'],roots={ROOTS!r})
sound.defaults(mode='Poli',glide=0,voices=16,amp_attack=500,amp_decay=2000,amp_sustain=1,amp_release=1000,master=-7,vel_sens=.34,
osc1_wave='Quadra',osc1_level=-16,osc1_pw=.37,osc1_voices=1,osc1_detune=0,osc1_spread=0,osc1_phase=0,osc1_fine=0,
osc2_wave='Triangolo',osc2_level=-25,osc2_voices=3,osc2_detune=.18,osc2_spread=.35,osc2_fine=-1.6,osc2_oct=0,osc2_phase=0,
sub_level=-29,sub_wave='Seno',osc_drift=.07,osc_retrig='Libera',lfo_shape='Seno',lfo_rate=.083,lfo_pw=.055,lfo_cutoff=.035,lfo_amp=0,lfo_pitch=0,
flt_mode='Basso',flt_cutoff=1850,flt_reso=.075,flt_key=.48,flt_vel=.16,flt_env=.10,fenv_source='Propria',fenv_attack=620,fenv_decay=1400,fenv_sustain=.4,fenv_release=800,
lvl_body=-60,lvl_air=-60,lvl_attack=-60,lvl_tail=-60,drive=.045,tape_wow=0,tape_flutter=0,tape_mix=0,tape_sat=0,echo_mix=0,res_mix=0,rev_mix=.055,rev_decay=1.25,rev_damp=.65)
'''
    (p/'sound.py').write_text(recipe)
    (s/'credits.json').write_text(json.dumps([{'source':'Original Libero electronic design','author':'Libero sound design session','license':'CC0 1.0','license_class':'cc0','url':'https://creativecommons.org/publicdomain/zero/1.0/','files':[r['file']for r in rows]}],indent=2)+'\n')
    svg=figure(slug);assert not validate_svg(svg);(p/'figure.svg').write_text(svg)
    (p/'notes.md').write_text(f'''# {title}

Blues/soul · {'tasti e accordi' if not attack else 'accordi/pad'} · SYN. {subtitle}.
This is original electronic synthesis, not a recorded Rhodes, horn or acoustic reed.
The construction differs from the other Blue voices; no shared sampled acoustic body,
generic noise layer, wow, chorus or reverb conceals it. Rame uses continuous live
oscillators/PWM; Fosforo and Indaco use authored periodic oscillator spectra because
their phase modulation and per-register spectral motion exceed the live engine.
Their explicit 16s cycles retain moving partial balances without replaying the onset.
Soft/hard layers are authored electronic timbres, not alleged recorded dynamics or RR.
Stereo retains a common grounded fundamental; quiet higher sidebands provide motion.
Polyphonic, glide0, held until note-off. Small live room is adjustable. CC0 original
design; source/design proof is in samples. Metrics do not establish musical taste.
''')
    c=compile_sound(p,jobs=2);print(slug,c.text(),flush=True)
    if not c.ok:raise RuntimeError(c.text())
    qa(slug)

def qa(slug):
    p=BANK/slug;out=OUT/slug;out.mkdir(parents=True,exist_ok=True)
    findings=lint_bundle(p/'build');(p/'lint.txt').write_text('\n'.join(f.line()for f in findings)+'\n')
    stats=[]
    for name,notes,tail in [('phrase','48:0:.35:40,55:.5:.45:85,60:1.1:.65:115,63:2:.45:100,67:2.6:1.5:100,60:4.5:3:95',2),('chord','48:0:4:120,55:0:4:110,60:0:4:110,63:0:4:110,67:0:4:105',2),('held60','60:0:60:100',2),('registers','36:0:1.5:100,48:2:1.5:100,60:4:1.5:100,72:6:1.5:100,84:8:1.5:100',2)]:
        pv=render.preview(slug,notes,tail=tail);shutil.copy2(pv.wav,out/(name+'.wav'))
        x=pv.audio.data.astype(float);sr=pv.audio.sr
        if x.ndim==1:x=x[:,None]
        rms=lambda a:float(20*np.log10(np.sqrt(np.mean(a*a))+1e-20))
        row={'name':name,'peak_db':pv.audio.peak_db,'rms_db':pv.audio.rms_db,'mono_loss_db':rms(x.mean(axis=1))-rms(x),'seconds':len(x)/sr}
        assert np.isfinite(x).all() and pv.audio.peak_db<-.5,(slug,name,'headroom')
        if name=='held60':
            lev=[rms(x[i*sr:(i+1)*sr])for i in range(10,59)];row.update(held_min_db=min(lev),held_span_db=max(lev)-min(lev),release_db=rms(x[61*sr:]))
            assert min(lev)>-60,(slug,'held silence')
        stats.append(row);print(slug,name,row,flush=True)
        (out/(name+'.png')).write_bytes(analysis.spectrogram(pv.audio,title=DESIGNS[slug][0]+' · '+name))
    m=json.loads((p/'build/manifest.json').read_text());report={'slug':slug,'route':'SYN','recorded_takes':0,'zones':len(m['zones']),'body_loops':sum(bool(z.get('loop'))for z in m['zones']if z['layer']=='body'),'native':stats,'lint':[f.line()for f in findings],'source_hash_current':library.source_hash(p)==m['source_hash']}
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    with(p/'notes.md').open('a')as f:f.write('\n## Technical verification\n\n'+'\n'.join(q.line()for q in findings)+'\n\nAuthored electronic layers are not recorded dynamics; any one-take/release warning means no separate sampled release was invented. Output uses native MIDI release. See demo/blue-designed for long held, chord, registers and spectral images.\n')
    assert not any(f.level=='FAIL'for f in findings),(slug,'lint FAIL')
    assert report['source_hash_current']
    (out/'figure.png').write_bytes(rasterize((p/'figure.svg').read_text(),512))

if __name__=='__main__':
    for slug in DESIGNS:build(slug)
