"""Read-only new-pack integration; never compile a historical sound to fix QA."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'python'))
from libero import library

HOME = Path.home() / 'Libero'
OUT = HOME / 'demo/packs-v7'
OUT.mkdir(parents=True, exist_ok=True)
BASE = json.loads((HOME / 'demo/library-expansion-v6/v6-frozen-before-new-packs.json').read_text())
rows = library.list_sounds()
errors, preserved, additions = [], [], []
seen = {r['slug'] for r in rows}
for slug in BASE.keys() - seen:
    errors.append(f'{slug}: existing programme missing')
for row in rows:
    slug, folder = row['slug'], Path(row['path'])
    manifest_file = folder / 'build/manifest.json'
    if not manifest_file.exists():
        errors.append(f'{slug}: missing build')
        continue
    m = json.loads(manifest_file.read_text())
    zones, params = m.get('zones', []), m.get('params', {})
    if slug in BASE:
        base = BASE[slug]
        hashes = {z['file']: hashlib.sha256((folder / 'build' / z['file']).read_bytes()).hexdigest() for z in zones}
        if (row['bank'] != base['bank'] or m['source_hash'] != base['source_hash']
                or params != base['params'] or hashes != base['zone_sha256']):
            errors.append(f'{slug}: changed during new-pack work')
        else:
            preserved.append(slug)
        continue
    if row['bank'] not in ('mog', 'venere', 'bebop'):
        errors.append(f'{slug}: unexpected addition outside new banks')
    errors.extend(f'{slug}: {e}' for e in library.validate_bundle(folder / 'build'))
    fresh = library.source_hash(folder) == m['source_hash']
    if not fresh:
        errors.append(f'{slug}: source/build mismatch')
    if params.get('mode') not in ('Poli', 0, None) or params.get('glide', 0) != 0:
        errors.append(f'{slug}: inappropriate playing-mode default')
    if any(params.get(k, 0) for k in ('tape_wow', 'tape_flutter')):
        errors.append(f'{slug}: unsolicited pitch wobble')
    if params.get('caldi_mode', 'Spento') not in ('Spento', 0):
        errors.append(f'{slug}: unsolicited Caldi default')
    default = m.get('articulations', [{}])[0].get('id') if m.get('articulations') else None
    body = [z for z in zones if z['layer'] == 'body' and (default is None or z.get('articulation') == default)]
    is_kit = bool(set(m.get('tags', [])) & {'kit', 'drums', 'drum-kit'}) or (
        bool(body) and all(z.get('pitched') is False for z in body))
    if body and not is_kit and any(not z.get('loop') for z in body):
        errors.append(f'{slug}: pitched default cannot hold continuously')
    additions.append({'slug': slug, 'bank': row['bank'], 'zones': len(zones),
                      'fresh': fresh, 'default_articulation': default, 'kit': is_kit})
duplicates = Counter(r['slug'] for r in rows)
errors.extend(f'{s}: duplicate slug' for s, n in duplicates.items() if n > 1)
mog_baseline = HOME / 'demo/public-new-packs-audit/mog-current.json'
approved_mog_preserved = []
if mog_baseline.exists():
    for original in json.loads(mog_baseline.read_text())['presets']:
        slug = original['slug']
        folder = HOME / 'banks/mog' / slug
        mismatches = []
        for relative, expected in [('sound.py', original['sound_py_sha256']),
                                   ('build/manifest.json', original['manifest_sha256'])]:
            if hashlib.sha256((folder / relative).read_bytes()).hexdigest() != expected:
                mismatches.append(relative)
        for zone in original['compiled_zone_files']:
            if hashlib.sha256((folder / 'build' / zone['file']).read_bytes()).hexdigest() != zone['sha256']:
                mismatches.append(zone['file'])
        if mismatches:
            errors.append(f'{slug}: approved Mog v1 changed: {mismatches}')
        else:
            approved_mog_preserved.append(slug)
for bank in ('mog', 'venere', 'bebop'):
    if not any(r['bank'] == bank for r in additions):
        errors.append(f'{bank}: no completed programmes')
report = {'active_count': len(rows), 'bank_counts': dict(Counter(r['bank'] for r in rows)),
          'v6_preserved_count': len(preserved), 'v6_preserved': preserved,
          'new_count': len(additions), 'additions': additions, 'errors': errors,
          'approved_mog_v1_preserved': approved_mog_preserved,
          'historical_incident': '../library-expansion-v6/historical-recompile-incident.json',
          'limitations': 'The v6 snapshot truthfully includes the previously disclosed Lira/Vetro rebuild incident; the earlier immutable baseline remains separate. Integrity and playback checks do not certify musical taste or redistribution rights.'}
(OUT / 'integration.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k: report[k] for k in ('active_count', 'new_count', 'v6_preserved_count', 'bank_counts', 'errors')}, indent=2))
if errors:
    raise SystemExit(1)
