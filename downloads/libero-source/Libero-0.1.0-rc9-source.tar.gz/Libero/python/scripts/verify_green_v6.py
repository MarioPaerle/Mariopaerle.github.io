"""Native Green pitch, band energy, stereo and cross-voice spectrum audit."""
from pathlib import Path
import argparse, json, sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import Audio, render, library
from build_green_v6 import DESIGNS, BANK, OUT, SR

def frequency(x,sr,expected):
    x=x.mean(1);x=x-x.mean();nfft=524288
    sp=np.abs(np.fft.rfft(x*np.hanning(len(x)),nfft))
    hz=np.fft.rfftfreq(nfft,1/sr)
    candidates=np.where((hz>expected*.975)&(hz<expected*1.025))[0]
    k=int(candidates[np.argmax(sp[candidates])]);q=np.log(np.maximum(sp[k-1:k+2],1e-30))
    delta=float(np.clip(.5*(q[0]-q[2])/(q[0]-2*q[1]+q[2]+1e-30),-.5,.5))
    return (k+delta)*sr/nfft

def energy(x,sr,lo,hi):
    w=np.hanning(len(x));f=np.fft.rfftfreq(len(x),1/sr)
    s=np.fft.rfft(x*w[:,None],axis=0)
    e=2*np.mean(np.sum(abs(s[(f>=lo)&(f<hi)])**2,axis=0))/len(x)**2/np.mean(w*w)
    return float(10*np.log10(e+1e-30))

parser=argparse.ArgumentParser();parser.add_argument('--slugs',nargs='+',choices=list(DESIGNS));args=parser.parse_args()
selected=set(args.slugs or DESIGNS)
previous=json.loads((OUT/'native-audit.json').read_text()) if args.slugs and (OUT/'native-audit.json').exists() else {'voices':[]}
rows=[r for r in previous['voices'] if r['slug'] not in selected];profiles={};upper_profiles={};fails=[]
keys=[36,39,40,43,46,47,50,53,54,57,60,61,64,67,68,71,74,75,78,81,82,85]
for slug in DESIGNS:
    out=OUT/slug;long_live=slug in {'miele-pulse','bosco-largo'};spacing=2.6 if long_live else .9;hold=2.5 if long_live else .82;sequence=[(k,i*spacing,hold,v)for i,(k,v)in enumerate((k,v)for k in keys for v in [50,110])]
    f=out/'pitch-boundaries.wav'
    if slug in selected: render.render(BANK/slug,f,sequence,{'rev_mix':0,'amp_attack':2,'amp_release':5},tail=.1)
    a=Audio.load(f);x=a.data.astype(float);x=x[:,None]if x.ndim==1 else x
    pitch=[]
    for k,start,dur,v in sequence:
        segment=x[round((start+(1.0 if long_live else .25))*SR):round((start+(2.2 if long_live else .75))*SR)]
        expected=440*2**((k-69)/12);measured=frequency(segment,SR,expected)
        cents=float(1200*np.log2(measured/expected));pitch.append({'key':k,'velocity':v,'cents':cents})
    worst=max(abs(q['cents'])for q in pitch)
    centre_control = None
    if slug == 'bosco-largo':
        # An overlapping seven-voice cluster can have a moving FFT maximum
        # outside any constituent frequency. Verify its actual key mapping
        # separately instead of retuning the pad to a phase-dependent peak.
        control_keys = [36,43,50,57,64,71,78,85]
        control_file = out/'centre-pitch-control.wav'
        render.render(BANK/slug,control_file,[(k,i*3,2.8,100)for i,k in enumerate(control_keys)],
            {'osc1_voices':1,'osc1_detune':0,'osc_drift':0,'rev_mix':0,'amp_attack':2,'amp_release':5},tail=.1)
        control = Audio.load(control_file).data.astype(float)
        if control.ndim == 1: control = control[:,None]
        centre_control = []
        for i,k in enumerate(control_keys):
            expected = 440*2**((k-69)/12)
            f0 = frequency(control[(i*3+1)*SR:round((i*3+2.5)*SR)],SR,expected)
            centre_control.append({'key':k,'cents':float(1200*np.log2(f0/expected))})
        if max(abs(q['cents'])for q in centre_control)>5:fails.append(slug+': native centre mapping exceeds 5 cents')
    elif worst>5:fails.append(slug+': centre pitch exceeds 5 cents')
    held=Audio.load(out/'held65.wav').data.astype(float)
    if held.ndim==1:held=held[:,None]
    body=held[20*SR:22*SR];bands={f'{lo}-{hi}Hz':energy(body,SR,lo,hi)for lo,hi in [(30,150),(150,600),(600,2500),(2500,8000)]}
    l,r=body[:,0],body[:,-1];mid=(l+r)/2;side=(l-r)/2
    ratio=float(10*np.log10((np.mean(side**2)+1e-30)/(np.mean(mid**2)+1e-30)))
    corr=float(np.corrcoef(l,r)[0,1]);level=[]
    for i in range(5,64):
        y=held[i*SR:(i+1)*SR];level.append(float(10*np.log10(np.mean(y*y)+1e-30)))
    n=131072;sp=abs(np.fft.rfft(mid*np.hanning(len(mid)),n));hz=np.fft.rfftfreq(n,1/SR)
    profile=np.array([np.sqrt(np.sum(sp[(hz>=261.625565*(k-.3))&(hz<261.625565*(k+.3))]**2))for k in range(1,29)])
    profiles[slug]=profile/max(np.linalg.norm(profile),1e-30)
    upper_profiles[slug]=profile[1:]/max(np.linalg.norm(profile[1:]),1e-30)
    m=json.loads((BANK/slug/'build/manifest.json').read_text())
    rows=[r for r in rows if r['slug']!=slug]
    rows.append({'slug':slug,'pitch_max_abs_cents':worst,'pitch_notes':pitch,'centre_mapping_control':centre_control,'body_band_rms_dbfs':bands,
        'side_to_mid_db':ratio,'stereo_correlation':corr,'held_1s_rms_range_dbfs':[min(level),max(level)],
        'source_hash_fresh':library.source_hash(BANK/slug)==m['source_hash']})
    print(slug,'pitch',round(worst,3),'side/mid',round(ratio,2),flush=True)
similarities=[];upper_similarities=[]
names=list(profiles)
for i,a in enumerate(names):
    for b in names[i+1:]:
        similarities.append({'a':a,'b':b,'spectral_cosine':float(np.dot(profiles[a],profiles[b]))})
        upper_similarities.append({'a':a,'b':b,'spectral_cosine':float(np.dot(upper_profiles[a],upper_profiles[b]))})
report={'voices':rows,'errors':fails,'similarities':sorted(similarities,key=lambda q:-q['spectral_cosine']),
    'upper_partial_similarities':sorted(upper_similarities,key=lambda q:-q['spectral_cosine']),
    'limitations':'The measured fundamental neighbourhood checks source key mapping; intentional unison motion is not per-note MPE. Spectral similarity and width do not establish perceived distinctness, warmth or preference.'}
(OUT/'native-audit.json').write_text(json.dumps(report,indent=2)+'\n')
if fails:raise SystemExit(str(fails))
