#!/usr/bin/env python3
"""Sequential compile, lint, preview and headroom check for the Aria bank."""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PYTHON = ROOT / "python"
sys.path.insert(0, str(PYTHON))

from libero import analysis, library, render  # noqa: E402
from libero.compiler import compile_sound  # noqa: E402
from libero.lint import lint_bundle  # noqa: E402

SLUGS = [
    "ferro-angelico", "fiato-rosso", "corno-di-vetro", "ferrite-luce",
    "ferro-corto", "squid-jab", "ottone-pugno", "vetro-taglio",
]
PADS = {"ferro-angelico", "fiato-rosso", "corno-di-vetro", "ferrite-luce"}
PHRASE = "48:0:0.7:1,60:0.9:0.55:55,60:1.6:0.55:127,72:2.35:2.0:105,84:4.65:0.55:127,48:5.35:0.55:1"
CHORD = "48:0:2.2:127,55:0:2.2:127,60:0:2.2:127,64:0:2.2:127"
BANK = library.home() / "banks" / "aria"
PREVIEWS = BANK / "_reports" / "previews"


def main() -> None:
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    for slug in SLUGS:  # Deliberately sequential: renders share CPU with the desktop.
        folder = library.find_sound(slug)
        result = compile_sound(folder)
        if not result.ok:
            raise SystemExit(result.text())
        manifest = result.manifest or json.loads((folder / "build" / "manifest.json").read_text())
        findings = lint_bundle(folder / "build")
        failures = [f for f in findings if f.level == "FAIL"]
        if failures:
            raise SystemExit("\n".join(f"{slug}: {f.line()}" for f in failures))
        warnings = [f for f in findings if f.level == "WARN"]

        pv = render.preview(slug, PHRASE, tail=2.0)
        shutil.copy2(pv.wav, PREVIEWS / f"{slug}.wav")
        (PREVIEWS / f"{slug}.png").write_bytes(analysis.spectrogram(pv.audio, title=f"{slug} · preview"))
        phrase_ft = analysis.features(pv.audio)

        chord_ft = None
        if slug in PADS:
            chord = render.preview(slug, CHORD, tail=1.2)
            shutil.copy2(chord.wav, PREVIEWS / f"{slug}-forte-chord.wav")
            chord_ft = analysis.features(chord.audio)

        print(f"{slug}: {len(manifest.get('zones', []))} zones; "
              f"lint {sum(f.level == 'FAIL' for f in findings)} FAIL / {len(warnings)} WARN; "
              f"phrase peak {phrase_ft['peak_db']} dBFS; "
              f"forte chord peak {chord_ft['peak_db']} dBFS" if chord_ft else
              f"{slug}: {len(manifest.get('zones', []))} zones; "
              f"lint {sum(f.level == 'FAIL' for f in findings)} FAIL / {len(warnings)} WARN; "
              f"phrase peak {phrase_ft['peak_db']} dBFS")
        rows.append({"slug": slug, "zones": len(manifest.get("zones", [])), "findings": findings,
                     "compile_warnings": result.warnings, "phrase": phrase_ft, "chord": chord_ft})

    lines = [
        "# Aria — build and listening QA",
        "",
        "Validation renders use the Libero renderer in sequence, with the bank’s native parameter defaults. The melody phrase covers velocity 1 and 127, a repeated C4 at soft and forte levels, a 2-second held note, and roots C3 through C6. Four-note pad chords use C3–E4 at velocity 127.",
        "",
        "Commands: `python/.venv/bin/python python/scripts/build_aria.py`, then `python/.venv/bin/python python/scripts/build_aria_qa.py`.",
        "",
        "| Sound | Zones | Lint | Phrase peak | Forte chord peak |",
        "|---|---:|---|---:|---:|",
    ]
    for row in rows:
        fails = sum(f.level == "FAIL" for f in row["findings"])
        warns = sum(f.level == "WARN" for f in row["findings"])
        chord_peak = f"{row['chord']['peak_db']:.2f} dBFS" if row["chord"] else "—"
        lines.append(f"| {row['slug']} | {row['zones']} | {fails} FAIL / {warns} WARN | "
                     f"{row['phrase']['peak_db']:.2f} dBFS | {chord_peak} |")
    lines += ["", "## Compile checks", ""]
    for row in rows:
        status = "; ".join(row["compile_warnings"]) if row["compile_warnings"] else "No compile warnings."
        lines.append(f"- **{row['slug']}**: {row['zones']} zones; {status}")
    lines += ["", "## Lint details", ""]
    for row in rows:
        lines.append(f"### {row['slug']}")
        lines.append("")
        visible = [f.line() for f in row["findings"] if f.level in ("FAIL", "WARN")]
        lines.extend(f"- {line}" for line in visible) if visible else lines.append("- No FAIL or WARN findings.")
        lines.append("")
    lines += ["## Preview measurements", ""]
    for row in rows:
        ft = row["phrase"]
        lines.append(f"### {row['slug']}")
        lines.append("")
        lines.append(analysis.format_features(ft, "Melody phrase").replace("\n", "  \n"))
        if row["chord"]:
            lines.append("")
            lines.append(analysis.format_features(row["chord"], "Forte chord").replace("\n", "  \n"))
        lines.append("")
    report = BANK / "_reports" / "REPORT.md"
    report.write_text("\n".join(lines) + "\n")
    print(f"QA report: {report}")


if __name__ == "__main__":
    main()
