"""Native safety, full played-range diagnostics and source-lane evidence for Giove tapes."""
from pathlib import Path
import argparse,json,sys
import numpy as np
import soundfile as sf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import library,render
from libero.dsp import estimate_f0
from libero.lint import lint_bundle
from build_giove_tapes_v1 import DESIGNS,BANK,OUT,sha
def metrics(p):
 x,sr=sf.read(p,always_2d=True)
 result={'peak_dbfs':float(20*np.log10(max(np.max(np.abs(x)),1e-15))),'clipped_samples':int(np.sum(np.abs(x)>=1)),'finite':bool(np.isfinite(x).all())}
 if len(x)>59*sr:result['late_rms_dbfs']=float(10*np.log10(np.mean(x[10*sr:59*sr]**2)+1e-30))
 return result
def verify(slug):
 p=BANK/slug;o=OUT/slug;o.mkdir(parents=True,exist_ok=True);m=json.loads((p/'build/manifest.json').read_text());proof=json.loads((p/'samples/source-proof.json').read_text());d=DESIGNS[slug]
 errors=library.validate_bundle(p/'build');findings=lint_bundle(p/'build')
 errors.extend(str(f) for f in findings if f.level=='FAIL')
 fresh=library.source_hash(p)==m['source_hash']
 if not fresh:errors.append('stale source hash')
 if any(not z.get('loop') for z in m['zones'] if z['layer']=='body'):errors.append('finite default body zone')
 for row in proof:
  for lane in row['sources']:
   if abs(lane['retained_loop_after_cents'])>5:errors.append(f"source lane loop centre >5c: key{row['key']} {lane['source']} {lane['retained_loop_after_cents']:.2f}c")
   if slug=='nastri-ance':
    evidence=lane.get('physical_root_evidence',{})
    if evidence.get('status')!='supported' or evidence.get('recommended_physical_root')!=lane['source_root']:
     errors.append(f"Unverified physical source root: {lane['source']}")
    if evidence.get('source_sha256')!=sha(lane['source']):
     errors.append(f"Physical-root audit no longer matches source: {lane['source']}")
 keys=list(range(d['keys'][0],d['keys'][1]+1));holds=[]
 for k in sorted({keys[0],keys[len(keys)//2],keys[-1]}):
  wav=o/f'hold-{k}.wav';render.render(p,wav,[(k,0,60,100)],{},tail=.5,timeout=240);r=metrics(wav);holds.append({'key':k,**r})
  if not r['finite'] or r['clipped_samples'] or r['late_rms_dbfs'] < -50:errors.append(f'hold failed key{k}: {r}')
 stress=[keys[round((len(keys)-1)*i/7)] for i in range(8)];stacks=[]
 for label,params in [('default',{}),('maximum-dynamics',{'dyn_mode':'Manopola','dynamics':1})]:
  wav=o/f'8-{label}.wav';render.render(p,wav,[(k,0,4,127) for k in stress],params,tail=.5);r=metrics(wav);stacks.append({'mode':label,'keys':stress,'events':8,**r})
  if not r['finite'] or r['clipped_samples'] or r['peak_dbfs']>-3:errors.append(f'headroom failed {label}: {r}')
 pitch=[]
 for vel in ([45,100] if slug=='nastri-archi' else [100]):
  wav=o/f'chromatic-v{vel}.wav';render.render(p,wav,[(k,i*5,4.8,vel) for i,k in enumerate(keys)],{'rev_mix':0},tail=.1,timeout=240)
  x,sr=sf.read(wav,always_2d=True)
  for i,k in enumerate(keys):
   seg=x[round((i*5+1)*sr):round((i*5+4)*sr)];f=440*2**((k-69)/12);hz,v=estimate_f0(seg,sr,f*.7,f*1.4)
   c=float(1200*np.log2(hz/f)) if np.isfinite(hz) and hz>0 else None
   pitch.append({'key':k,'velocity':vel,'cents':c,'voiced':v})
   # Ensemble F0 is diagnostic; separately measured independent lane centres
   # establish tuning. A semitone-scale mismatch or silence remains a failure.
   if c is None or v<.35 or abs(c)>80:errors.append(f'native root/voicing failed key{k}/v{vel}: {c}/{v}')
 result={'slug':slug,'status':'PASS' if not errors else 'FAIL','source_hash':m['source_hash'],'fresh':fresh,'zones':len(m['zones']),'holds':holds,'stacks':stacks,'source_lane_max_abs_cents':max(abs(z['retained_loop_after_cents']) for q in proof for z in q['sources']),'native_pitch_diagnostics':pitch,'native_max_abs_cents':max((abs(z['cents']) for z in pitch if z['cents'] is not None),default=None),'pitch_method':'Constrained YIN native 1–4s diagnostic across every playable key and recorded dynamic. Each independent source lane additionally centred on its actual retained loop; ensemble beating/vibrato not flattened. No perceptual realism assertion.','lint':[str(f) for f in findings],'errors':errors}
 (o/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('slug','status','source_lane_max_abs_cents','native_max_abs_cents','errors')},indent=2),flush=True);return result
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--slugs',nargs='*',choices=DESIGNS,default=list(DESIGNS));a=ap.parse_args();results=[verify(s) for s in a.slugs]
 snapshots=[]
 for slug in DESIGNS:
  snapshot=OUT/slug/'report.json'
  if snapshot.exists():snapshots.append(json.loads(snapshot.read_text()))
 (OUT/'report.json').write_text(json.dumps({'checks':snapshots,'status':'PASS' if len(snapshots)==len(DESIGNS) and all(r['status']=='PASS' for r in snapshots) else 'FAIL'},indent=2)+'\n')
 return any(r['status']!='PASS' for r in results)
if __name__=='__main__':raise SystemExit(main())
