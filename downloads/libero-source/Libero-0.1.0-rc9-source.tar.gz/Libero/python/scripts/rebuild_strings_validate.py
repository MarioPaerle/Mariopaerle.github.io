"""Native preview, absolute tuning calibration, sample integrity and lint for natural strings.
Run after rebuild_strings_natural.py. Tuning is measured on the compiled first 1.5s
mono head used by Libero lint; source tune is written ONCE as an absolute correction.
Re-running calibration never stacks corrections. No audio dynamics are interpolated.
"""
from pathlib import Path
from collections import defaultdict
import json, subprocess, numpy as np, soundfile as sf
from libero import Audio, analysis
from libero.compiler import compile_sound
from libero.lint import _load, lint_text, lint_bundle
from libero.multisample import align_shift, true_onset
ROOT=Path.home()/'Libero/banks/archi'
RENDER=Path.home()/'.local/bin/libero-render'
def calibrate(slug):
    folder=ROOT/slug; b=folder/'build'
    m=json.loads((b/'manifest.json').read_text())
    mp=json.loads((folder/'samples/map-natural.json').read_text())
    by={(r['articulation'],r['root'],tuple(r['dyn']),r['take']):r for r in mp['body']}
    records=[]
    for z in m['zones']:
        d=_load(b,z,True)
        r=by[(z['articulation'],z['root'],tuple(z['dyn']),z.get('take',0))]
        # Absolute source correction from the measured current residual; source mode
        # prevents the detect path from subtracting the same source deviation twice.
        r['tune_cents']=round(z.get('tune_cents',0)-(d.f0_cents or 0),2)
        records.append({'file':r['file'],'residual_before':d.f0_cents,'absolute_correction':r['tune_cents']})
    (folder/'samples/map-natural.json').write_text(json.dumps(mp,indent=2)+'\n')
    p=folder/'sound.py';p.write_text(p.read_text().replace("'tune':'detect'","'tune':'source'"))
    (folder/'samples/tuning-calibration.json').write_text(json.dumps(records,indent=2)+'\n')
    res=compile_sound(folder)
    if not res.ok: raise RuntimeError(res.text())
    print(slug,res.text().splitlines()[0],flush=True)

def validate(slug):
    folder=ROOT/slug;b=folder/'build'
    text=lint_text(b);(folder/'lint.txt').write_text(text+'\n');print(text,flush=True)
    m=json.loads((b/'manifest.json').read_text()); ds=[_load(b,z,True) for z in m['zones']]
    groups=defaultdict(list)
    for d in ds:
        if d.f0_cents is not None: groups[d.z['articulation']].append(d.f0_cents)
    stats={'zones':len(ds),'native_ram_bytes':sum(d.frames*2*4 for d in ds),
           'bundle_audio_bytes':sum((b/d.z['file']).stat().st_size for d in ds),
           'loop_count':sum(bool(d.z.get('loop')) for d in ds),
           'residual_cents_by_articulation':{k:{'min':min(v),'max':max(v),'spread':max(v)-min(v),'measured_zones':len(v)} for k,v in groups.items()},
           'zone_peak_db_max':max(d.peak_db for d in ds),
           'source_count':len(list((folder/'samples/raw-vsco').rglob('*.wav'))),
           'supplements':json.loads((folder/'samples/nearest-root.json').read_text()),'previews':{}}
    low=55 if slug=='violini' else 48
    notes=f'12:0:0.01:100,{low}:0:1.2:35,60:1.5:1.2:115,64:3:1.2:80,67:3.9:1.2:105,64:5.4:0.3:85,64:5.85:0.3:110,64:6.3:0.3:45,86:7:1.3:115,60:8.6:12:100,14:21:0.01:100,60:21.1:0.18:35,60:21.5:0.18:115,60:21.9:0.18:95,60:22.3:0.18:110,15:23:0.01:100,60:23.1:0.2:35,60:23.5:0.2:115,60:23.9:0.2:90,60:24.3:0.2:110,16:25:0.01:100,{low}:25.1:1.2:40,60:26.5:2:110,86:28.8:2:100'
    for label,params in [('preview',{}),('preview-dry',{'rev_mix':0})]:
        out=b/f'{label}.wav'
        subprocess.run([str(RENDER),'--sound',str(folder),'--out',str(out),'--notes',notes,'--params',json.dumps(params),'--tail','2'],check=True,capture_output=True)
        x,sr=sf.read(out,always_2d=True)
        a=Audio(x,sr);(b/f'{label}.png').write_bytes(analysis.spectrogram(a,title=f'{slug} · {label} · renderer nativo'))
        stats['previews'][label]={'duration_s':len(x)/sr,'peak_db':float(20*np.log10(np.max(np.abs(x))+1e-20)),'dc_db':float(20*np.log10(np.max(np.abs(x.mean(axis=0)))+1e-20)),'clipped_samples':int(np.sum(np.abs(x)>=1)),'rms_db':float(20*np.log10(np.sqrt(np.mean(x*x))+1e-20))}
    (folder/'verification.json').write_text(json.dumps(stats,indent=2)+'\n')
    with (folder/'notes.md').open('a') as p:
        p.write('\n## Verifica finale\n\n'+text+'\n\n')
        p.write('Intonazione: dopo una prima compilazione detect senza correzioni nel map, calibrata una sola correzione assoluta source dal residuale misurato nel bundle (stessa finestra 1.5 s del lint). Le correzioni non alterano il vibrato interno delle registrazioni. Questa misura non garantisce che ogni istante del vibrato sia entro 5 cent.\n\n')
        p.write('Le correzioni ladder_max_db=4 possono cumulare tra correzione della tastiera, del livello e dei take: il report meta.calibration nel manifest riporta i valori effettivi.\n\n')
        p.write('WARN brightness: i livelli sono registrazioni indipendenti reali; il rapporto sopra 4kHz dei primi 300ms non è monotono in tutte le note. Nessun EQ inventato per far passare il test. WARN ladder: dinamiche registrate ancora distanti oltre 10dB in alcune note, calibrazione limitata per mantenerne il carattere. WARN loudness: attacchi originali ancora irregolari su alcune radici. Tutte le WARN effettive sono nel lint.txt e nel testo sopra.\n\n')
        p.write(f"Zone: {len(ds)}; loop: 0; RAM decodificata stereo float32 {stats['native_ram_bytes']/2**20:.1f} MiB; FLAC bundle {stats['bundle_audio_bytes']/2**20:.1f} MiB. Preview con soft/hard, sovrapposizioni legato, ripetizioni, estremi registrati e nota tenuta 12s, poi tutte le articolazioni. Nessun ascolto soggettivo: spettrogrammi e misure numeriche.\n\n")
        p.write(json.dumps(stats['previews'],indent=2)+'\n')
    return stats
if __name__=='__main__':
    for slug in ('violini','viole'):
        res=compile_sound(ROOT/slug)
        if not res.ok: raise RuntimeError(res.text())
        calibrate(slug);validate(slug)
