"""Read-only native chromatic/all-dynamic pitch and major/minor scale audit.

Usage: python/.venv/bin/python python/scripts/audit_blue_keys_pitch.py <before|after> <slug>...
Writes only cache/research/blue-key-pitch-audit; never edits any instrument.
"""
from pathlib import Path
import json,subprocess,sys
import numpy as np
import soundfile as sf
from libero import dsp

home=Path.home();phase=sys.argv[1];slugs=sys.argv[2:]
for slug in slugs:
    p=home/'Libero/banks/blue'/slug;out=home/'Libero/cache/research/blue-key-pitch-audit'/slug;out.mkdir(parents=True,exist_ok=True)
    m=json.loads((p/'build/manifest.json').read_text());zones=[z for z in m['zones']if z['layer']=='body'];lo=min(z['lo']for z in zones);hi=max(z['hi']for z in zones)
    axes=sorted({tuple(z['dyn'])for z in zones});vels=[max(1,round(127*np.mean(v)))for v in axes];rows=[];events=['12:0:.01:100']
    for v in vels:
        for k in range(lo,hi+1):
            t=.1+len(rows)*1.05;rows.append(dict(key=k,velocity=v,time=t));events.append(f'{k}:{t}:.75:{v}')
    wav=out/(phase+'-chromatic.wav');renderer=home/'.local/bin/libero-render'
    subprocess.run([str(renderer),'--sound',str(p),'--out',str(wav),'--notes',','.join(events),'--tail','1'],check=True,capture_output=True)
    x,sr=sf.read(wav,always_2d=True)
    for r in rows:
        expected=440*2**((r['key']-69)/12);t=r['time'];seg=x[int((t+.28)*sr):int((t+.68)*sr)].mean(axis=1)
        hz,confidence=dsp.estimate_f0(seg,sr,fmin=max(20,expected/2.5),fmax=min(14000,expected*2.5))
        r.update(hz=float(hz),confidence=float(confidence),target_hz=expected,cents=float(1200*np.log2(hz/expected))if hz>0 else None)
    del x
    steps=[]
    for a,b in zip(rows,rows[1:]):
        if a['velocity']==b['velocity'] and a['hz']>0 and b['hz']>0:
            steps.append(dict(from_key=a['key'],to_key=b['key'],velocity=a['velocity'],interval_cents=float(1200*np.log2(b['hz']/a['hz']))))
    valid=[r for r in rows if r['cents']is not None];q=dict(slug=slug,phase=phase,source_hash=m['source_hash'],range=[lo,hi],velocities=vels,rows=rows,chromatic_steps=steps,maximum_abs_cents=max(abs(r['cents'])for r in valid),outside_20c=[r for r in valid if abs(r['cents'])>20],missing_pitch=[r for r in rows if r['cents']is None],octave_errors=[r for r in valid if abs(r['cents'])>600])
    (out/(phase+'-pitch.json')).write_text(json.dumps(q,indent=2)+'\n');print(slug,phase,'maxerror',round(q['maximum_abs_cents'],3),'outside20c',len(q['outside_20c']),'missing',len(q['missing_pitch']),flush=True)
    # Both interval sets at medium and hard velocities, with an octave, not a
    # label inferred from harmonics of a single tone.
    events=['12:0:.01:100'];i=0
    for v in [vels[len(vels)//2],vels[-1]]:
        for scale in [[0,2,4,5,7,9,11,12],[0,2,3,5,7,8,10,12]]:
            for n in scale:events.append(f'{min(hi,max(lo,60+n))}:{.1+i*.8}:.65:{v}');i+=1
    subprocess.run([str(renderer),'--sound',str(p),'--out',str(out/(phase+'-major-minor.wav')),'--notes',','.join(events),'--tail','1'],check=True,capture_output=True)
