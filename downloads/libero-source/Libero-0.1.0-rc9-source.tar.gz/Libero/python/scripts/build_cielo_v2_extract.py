"""Acquire/extract authentic VocalSet technique notes for Cielo v2.
Primary original ZIP, CC BY 4.0. No preview or synthesis for VocalSet.
"""
from pathlib import Path
import json, zipfile, hashlib, concurrent.futures
import numpy as np
from scipy import signal
from libero import load,dsp
BASE=Path.home()/'Libero/cache/research/cielo-v2'
ORIGINAL=BASE/'original';DEST=BASE/'notes'
TECHS={'vibrato','belt','breathy','vocal_fry','trillo','trill','lip_trill','slow_forte','slow_piano'}
def acquire():
    archive=Path.home()/'Libero/cache/research/cielo/VocalSet11.zip'
    assert hashlib.md5(archive.read_bytes()).hexdigest()=='0c09396242f946e7111ad7d8fc649b81'
    rows=[]
    with zipfile.ZipFile(archive) as z:
        for n in z.namelist():
            p=Path(n)
            if 'FULL' not in p.parts or p.suffix!='.wav' or p.name.startswith('._') or p.stem.split('_')[-1] not in {'a','e','o'} or p.parent.name not in TECHS:continue
            rel=Path(*p.parts[p.parts.index('FULL')+1:]);dst=ORIGINAL/rel
            if not dst.exists():dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(z.read(n))
            rows.append({'source':n,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
    (BASE/'acquisition.json').write_text(json.dumps({'primary':'https://zenodo.org/records/1442513','license':'CC BY 4.0','md5':'0c09396242f946e7111ad7d8fc649b81','files':rows},indent=2))

def extract(p):
    a=load(p);sr=a.sr;track=dsp.resample_to(dsp.mono(a.data),sr,12000)
    t,f,ap,rms=dsp.yin(track,12000,fmin=65,fmax=1500,frame=1024,hop=120,threshold=.08)
    midi=np.full(len(t),np.nan);v=np.isfinite(f)&(ap<.35)&(rms>max(rms.max()*.025,1e-5));midi[v]=69+12*np.log2(f[v]/440)
    if v.sum()<40:return []
    filled=np.interp(np.arange(len(t)),np.flatnonzero(v),midi[v]);smooth=signal.medfilt(filled,21)
    tech=p.parent.name;labels=np.round(smooth).astype(int)
    if tech in {'trillo','trill'}:
        # Longtone trill ornament stays an entire gesture, not short split pitches.
        centers=np.percentile(midi[v],[10,50,90])
        for _ in range(20):
            cs=np.abs(midi[v,None]-centers[None,:]).argmin(axis=1)
            centers=np.array([np.median(midi[v][cs==i]) if np.any(cs==i) else centers[i] for i in range(3)])
        unique=[]
        for c in sorted(centers):
            if not unique or c-unique[-1]>4:unique.append(c)
        centers=np.array(unique);labels=np.round(centers[np.abs(smooth[:,None]-centers[None,:]).argmin(axis=1)]).astype(int)
    labels[~v]=0
    # Brief detector gaps only within the same pitch, never across separate notes.
    for s in np.flatnonzero(np.diff(np.r_[False,labels==0,False].astype(int))==1):
        e=s
        while e<len(labels) and labels[e]==0:e+=1
        if s>0 and e<len(labels) and e-s<20 and labels[s-1]==labels[e]:labels[s:e]=labels[e]
    labels=signal.medfilt(labels,11)
    edges=np.flatnonzero(np.diff(np.r_[-1,labels,-1])!=0);segs=[]
    for s,e in zip(edges[:-1],edges[1:]):
        if labels[s]<35 or e-s<45:continue
        if tech not in {'trill','trillo'} and np.percentile(abs(midi[s:e][np.isfinite(midi[s:e])]-np.median(midi[s:e][np.isfinite(midi[s:e])])),90)>1:continue
        ss=max(0,t[s]-.06);ee=min(a.duration,t[e-1]+.08)
        segs.append((ss,ee,float(np.nanmedian(midi[s:e]))))
    out=[];rel=p.relative_to(ORIGINAL)
    for i,(s,e,c) in enumerate(segs):
        e=min(a.duration,e+.09)
        if i+1<len(segs):e=min(e,segs[i+1][0]-.01)
        if e-s<.45:continue
        b=a.trim(s,e).remove_dc().highpass(15).fade_in(.003).fade_out(.025)
        root=round(c);anchor=dsp.midi_to_freq(c)
        body=b.trim(min(.12,b.duration*.15),b.duration-.08)
        f0,_=dsp.estimate_f0(body.data,sr,anchor*.88,anchor*1.13)
        if not np.isfinite(f0):continue
        f0=dsp.refine_f0(body.data,sr,f0);n=dsp.freq_to_midi(f0)
        if abs(n-c)>1:continue
        b=b.pitch(root-n);dst=DEST/rel.parent/f'{p.stem}-{i}-{root}.wav';dst.parent.mkdir(parents=True,exist_ok=True);b.save(dst,subtype='PCM_24')
        out.append({'file':str(dst),'source':str(rel),'singer':rel.parts[0],'gender':'female' if rel.parts[0].startswith('female') else 'male','dynamic':tech,'vowel':p.stem.split('_')[-1],'root':root,'seconds':b.duration,'source_seconds':[round(s,3),round(e,3)],'source_cents':round((n-root)*100,3),'lufs':dsp.momentary_max(b.data,sr),'peak_db':b.peak_db})
    return out
if __name__=='__main__':
    acquire();files=sorted(p for p in ORIGINAL.rglob('*.wav') if not p.name.startswith('._'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
        rows=[]
        for i,r in enumerate(ex.map(extract,files)):
            rows.extend(r)
            if i%50==0:print(i,len(rows),flush=True)
    (BASE/'notes.json').write_text(json.dumps(rows,indent=2));print('DONE',len(rows),flush=True)
