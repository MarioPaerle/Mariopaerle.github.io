"""Native previews, source-trajectory audit and loudness-matched v1/v2 comparisons."""
from pathlib import Path
import json,math,subprocess,concurrent.futures
import numpy as np
from scipy import signal
import soundfile as sf
from libero import Audio,load,dsp,analysis
from libero.lint import lint_bundle,lint_text
from libero.render import render
BASE=Path.home()/'Libero/cache/research/cielo-v2';STAGE=BASE/'staged';REPORT=BASE/'reports';REPORT.mkdir(exist_ok=True)
OLD=Path.home()/'Libero-backups/2026-10-02/cielo-v2-feedback'

def trajectory(r):
    a=load(r['file']);x=dsp.resample_to(dsp.mono(a.data),a.sr,12000)
    t,f,ap,rms=dsp.yin(x,12000,fmin=60,fmax=1500,frame=1024,hop=120,threshold=.05)
    v=np.isfinite(f)&(ap<.30)&(rms>max(rms.max()*.04,1e-5));n=np.full(len(f),np.nan);n[v]=69+12*np.log2(f[v]/440)
    windows=[]
    for s in np.arange(.12,max(.13,a.duration-.2),.4):
        q=n[(t>=s)&(t<s+.4)];q=q[np.isfinite(q)]
        if len(q)>8:windows.append(float(np.median(q)))
    dif=np.array(windows)-r['root'];normalized=dif-np.round(dif/12)*12
    return {'file':r['file'],'source':r['source'],'root':r['root'],'seconds':a.duration,'window_midi':windows,'pitch_class_span_cents':round(float(np.ptp(normalized)*100),1) if len(normalized) else None,'octave_ambiguity':bool(np.any(abs(dif)>6)),'non_octave_jump':bool(len(normalized)>1 and np.ptp(normalized)>2.2)}

def metrics(a):
    x=dsp.mono(a.data);f,p=signal.welch(x,a.sr,nperseg=min(8192,len(x)));total=p.sum()+1e-30
    t,env=dsp.rms_envelope(x,a.sr,.025);attack_env=env[:min(len(env),60)];peak=attack_env.max();on=np.flatnonzero(attack_env>=peak*.1);hi=np.flatnonzero(attack_env>=peak*.9);env=env[env>max(env.max()*.02,1e-10)]
    return {'lufs':round(dsp.momentary_max(a.data,a.sr),2),'peak_db':round(a.peak_db,2),'low_80_400_db':round(float(10*np.log10((p[(f>=80)&(f<400)].sum()+1e-30)/total)),2),'mid_400_2000_db':round(float(10*np.log10((p[(f>=400)&(f<2000)].sum()+1e-30)/total)),2),'upper_2000_8000_db':round(float(10*np.log10((p[(f>=2000)&(f<8000)].sum()+1e-30)/total)),2),'centroid_hz':round(float((p*f).sum()/total)),'rms_motion_db':round(float(dsp.db(np.percentile(env,90)/max(np.percentile(env,30),1e-10))),2),'attack_10_90_ms':round(float((t[hi[0]]-t[on[0]])*1000)) if len(on) and len(hi) else None}

def verify(folder):
    b=folder/'build';m=json.loads((b/'manifest.json').read_text());zs=m['zones'];roots=sorted({z['root'] for z in zs});lo=min(z['lo'] for z in zs);hi=max(z['hi'] for z in zs);mid=roots[len(roots)//2]
    # Different musical roles: long chord gestures, intimate lines, rhythmic trillo.
    if folder.name in {'uomini-cenere','trillo-rito'}:
        notes=[(roots[i%len(roots)],i*.55,.7,50+(i%3)*30) for i in range(10)]
        notes +=[(mid,6,2.8,110),(min(hi,mid+3),6.6,2,92)]
    elif folder.name=='ellen-ooh-aha':notes=[(55,0,8.2,92),(54,9.4,8.2,72)]
    else:
        notes=[(lo,0,1.8,40),(hi,2.1,1.8,115),(mid,4.3,4,82),(max(lo,mid-4),4.3,4,80),(min(hi,mid+3),4.3,4,87),(mid,8.9,.7,55),(mid,9.8,.7,113),(mid,11,7,106)]
    render(folder,b/'preview.wav',notes,tail=3)
    a=load(b/'preview.wav')
    art_open=next((i for i,art in enumerate(m.get('articulations',[])) if art['id']=='ah_open'),None)
    if art_open is not None:
        render(folder,b/'apertura.wav',[(mid,0,9,104)],params={'artic':art_open},tail=2)
        a=a.trim(0,14.8).concat(load(b/'apertura.wav'),crossfade=.05)
        a.save(b/'preview.wav',subtype='PCM_24')
    if a.peak_db>-.5:raise RuntimeError('Chord headroom '+folder.name+' '+str(a.peak_db))
    subprocess.run(['/opt/homebrew/bin/ffmpeg','-y','-loglevel','error','-i',str(b/'preview.wav'),'-c:a','aac','-b:a','192k',str(b/'preview.m4a')],check=True)
    (b/'spectrogram.png').write_bytes(analysis.spectrogram(a,title=m['title'].replace('→','verso')+' · native engine'))
    arts=m.get('articulations',[])
    for i,art in enumerate(arts):
        render(folder,b/f'articulation-{i}.wav',[(mid,0,5,102)],params={'artic':i},tail=1)
    findings=lint_bundle(b);report=lint_text(b,folder.name);(b/'lint.txt').write_text(report)
    ram=sum(sf.info(str(b/z['file'])).frames*sf.info(str(b/z['file'])).channels*4 for z in zs)/1048576
    durations=[sf.info(str(b/z['file'])).duration for z in zs]
    data={'zones':len(zs),'roots':roots,'range':[lo,hi],'seconds':[round(min(durations),2),round(max(durations),2)],'ram_mib':round(ram,2),'preview':metrics(a),'fail':sum(f.level=='FAIL' for f in findings),'warn':sum(f.level=='WARN' for f in findings),'warnings':[{'check':f.check,'message':f.text} for f in findings if f.level=='WARN'],'notes':notes,'opening_preview':art_open is not None,'articulations':[a['name'] for a in arts]}
    (b/'verification.json').write_text(json.dumps(data,indent=2));p=folder/'notes.md'
    p.write_text(p.read_text().split('\n## Verifiche tecniche')[0]+f'\n## Verifiche tecniche\n\n{len(zs)} zone, registro MIDI {lo}–{hi}, durata reale {min(durations):.2f}–{max(durations):.2f} s; RAM decodificata {ram:.1f} MiB. Anteprima motore {a.peak_db:.2f} dBFS: piano/forte, ripetizioni, estremi, sovrapposizioni e nota lunga. I campioni senza loop finiscono naturalmente.\n\n'+report+'\n\nAvvisi: gli attacchi eseguiti da interpreti separati e i crescendo mantengono differenze naturali di pochi millisecondi; non richiedono allineamento di fase perché le dinamiche commutano all’attacco. Un solo livello per tecniche registrate una volta; colore non monotono fra esecuzioni originali; livello e composizione cambiano naturalmente col registro. Nessuna dinamica o brillantezza finta aggiunta per annullare questi avvisi.\n')
    print(folder.name,data['fail'],'FAIL',data['warn'],'WARN',round(a.peak_db,2),flush=True);return data

def compare(new,old,pitch):
    # Same phrase, room settings and peak target; source recipes otherwise unchanged.
    notes=[(pitch,0,3,100),(pitch,3.7,.6,90),(pitch,4.5,2.3,115)]
    out=[]
    for label,folder in [('old',OLD/old),('new',STAGE/new)]:
        path=REPORT/f'{new}-{label}.wav';render(folder,path,notes,params={'rev_mix':0,'master':0},tail=.5);a=load(path)
        a=a.gain_db(-23-dsp.momentary_max(a.data,a.sr));a.save(path,subtype='PCM_24');(REPORT/f'{new}-{label}.png').write_bytes(analysis.spectrogram(a,title=f'{new} · {label} · matched −23 LUFS maximum'))
        out.append({'edition':label,**metrics(a)})
    return out
if __name__=='__main__':
    folders=sorted(p for p in STAGE.iterdir() if (p/'sound.py').exists())
    unique={}
    for folder in folders:
        for r in json.loads((folder/'samples/provenance.json').read_text()):
            for s in r.get('sources',[]):unique[s['file']]=s
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:trajectories=list(ex.map(trajectory,unique.values()))
    (REPORT/'source-trajectories.json').write_text(json.dumps(trajectories,indent=2));print('selected component sources',len(trajectories),'jump flags',sum(t['non_octave_jump'] for t in trajectories),'octave flags',sum(t['octave_ambiguity'] for t in trajectories),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:results=dict(zip([p.name for p in folders],ex.map(verify,folders)))
    (REPORT/'verification.json').write_text(json.dumps(results,indent=2))
    comparisons={}
    for new,old,pitch in [('donne-radura','female-a',63),('donne-mezzo','female-a',63),('uomini-pietra','male-a',49),('uomini-cenere','male-a',57),('coro-volta','mixed-a',60),('trillo-rito','mixed-a',61)]:comparisons[new]=compare(new,old,pitch)
    (REPORT/'comparisons.json').write_text(json.dumps(comparisons,indent=2))
    if any(r['fail'] for r in results.values()):raise SystemExit('Unresolved FAIL')
