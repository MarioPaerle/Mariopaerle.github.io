"""Import prepared banks into a fresh isolated home and test runtime bytes/playback."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
import numpy as np
import soundfile as sf
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from libero import library, render

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def native_call(host, operation, archive):
    result = subprocess.run([str(host), operation, str(archive)], capture_output=True, text=True)
    reply = json.loads(result.stdout.strip())
    assert (result.returncode == 0) == bool(reply['ok']), (operation, reply)
    return reply

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--verification-dir', type=Path,
                        help='sibling directory for disposable import homes and the report')
    parser.add_argument('--native-host', type=Path,
                        help='verify plugin-native import through libero-host-test')
    args = parser.parse_args()
    out = args.candidate.resolve()
    catalog = json.loads((out / 'catalog.json').read_text())
    verification = (args.verification_dir or (out.parent / 'verification')).expanduser().resolve()
    verification.mkdir(parents=True, exist_ok=True)
    home = Path(tempfile.mkdtemp(prefix='import-check-', dir=verification))
    os.environ['LIBERO_HOME'] = str(home)
    os.environ['LIBERO_TRASH'] = str(home / '.trash')
    reports = []
    pack_reports = []
    for pack in catalog['packs']:
        archive = Path(pack['file'])
        if not archive.is_absolute():
            archive = out / archive
        assert digest(archive) == pack['sha256'], ('archive changed', archive)
        if args.native_host:
            plan = native_call(args.native_host, '--inspect-bank', archive)
            assert plan['ok'] and plan['action'] == 'install', plan
            assert plan['soundCount'] == pack['presets'], plan
            installed = native_call(args.native_host, '--import-bank', archive)
            assert installed['ok'] and installed['slug'] == pack['bank'], installed
            folder = Path(installed['path'])
            assert folder == home / 'banks' / pack['bank'], installed
            pack_reports.append({'bank': pack['bank'], 'inspection': plan, 'installation': installed})
        else:
            folder = library.bank_install(archive)
        for programme in pack['programmes']:
            sound = folder / programme['slug']
            assert not library.validate_bundle(sound / 'build'), programme['slug']
            manifest = json.loads((sound / 'build/manifest.json').read_text())
            arts = manifest.get('articulations', [])
            default = arts[0]['id'] if arts else None
            body = [z for z in manifest['zones'] if z.get('layer') == 'body'
                    and (default is None or z.get('articulation') == default)]
            keys = sorted({z['root'] for z in body})
            note = keys[len(keys) // 2] if keys else 60
            wav = home / (programme['slug'] + '.wav')
            render.render(sound, wav, [(note, 0, .5, 100)], {}, tail=.2, sr=48000)
            audio, _ = sf.read(wav)
            peak = float(np.max(np.abs(audio)))
            assert peak > 1e-8, (programme['slug'], 'silent')
            expected_files = programme.get('runtime_files')
            original = Path(programme['source']) if 'source' in programme else None
            for f in (sound / 'build').rglob('*'):
                if f.is_file():
                    rel = f.relative_to(sound / 'build')
                    expected = expected_files[str(rel)] if expected_files is not None else digest(original / 'build' / rel)
                    assert digest(f) == expected, (programme['slug'], str(rel))
            reports.append({'bank': pack['bank'], 'slug': programme['slug'],
                            'note': note, 'peak_dbfs': float(20 * np.log10(peak)),
                            'compiled_bytes_match': True})
    assert len(reports) == catalog['preset_count']
    duplicate_checks = None
    if args.native_host:
        smallest = min(catalog['packs'], key=lambda p: p['bytes'])
        archive = out / smallest['file']
        installed_meta = home / 'banks' / smallest['bank'] / 'bank.json'
        before = digest(installed_meta)
        same = native_call(args.native_host, '--import-bank', archive)
        assert not same['ok'] and same['code'] == 'SAME_VERSION', same
        older_archive = verification / 'downgrade-test.liberobank'
        with zipfile.ZipFile(archive) as src, zipfile.ZipFile(older_archive, 'w') as dst:
            for info in src.infolist():
                data = src.read(info)
                if info.filename == smallest['bank'] + '/bank.json':
                    meta = json.loads(data)
                    meta['version'] = '0.0.0'
                    data = json.dumps(meta).encode()
                dst.writestr(info, data)
        older = native_call(args.native_host, '--import-bank', older_archive)
        assert not older['ok'] and older['code'] == 'DOWNGRADE', older
        assert digest(installed_meta) == before, 'duplicate import changed installed metadata'
        assert not list((home / 'banks').glob('.inspect-*')), 'import left temporary staging folders'
        duplicate_checks = {'same_version': 'PASS', 'downgrade': 'PASS', 'installed_metadata_unchanged': True}
    result = {'status': 'PASS', 'count': len(reports), 'pack_count': len(catalog['packs']),
              'renderer_binary': os.environ.get('LIBERO_RENDER'), 'isolated_home': str(home),
              'import_backend': 'native' if args.native_host else 'python',
              'native_host': str(args.native_host) if args.native_host else None,
              'pack_checks': pack_reports, 'duplicate_checks': duplicate_checks,
              'programmes': reports, 'limitation': 'Archive import and native playback smoke test; see separate musical QA and rights audit.'}
    report_path = verification / 'import-verification.json'
    report_path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'count': len(reports),
                      'verification_home': str(home), 'report': str(report_path)}))

if __name__ == '__main__':
    main()
