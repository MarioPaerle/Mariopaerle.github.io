#!/usr/bin/env python3
"""Build seven source-led public replacement presets for the release audit.

Only the seven ``*-libero`` folders named below are written.  Upstream recordings,
SFZ maps, licences and source hashes remain bundled in each preset's samples/
originals directory.  The SF2 reader here only extracts sample PCM and the
instrument/key/velocity maps from the CC0 TavyMusic font; no renderer or SF2 DSP
is baked into the presets.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from urllib.request import Request, urlopen
import json, math, re, shutil, struct, sys

import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
sys.path.insert(0, str(ROOT / "python" / "scripts"))
from libero import render, dsp
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero.ingest.sfz import parse_sfz
from calibrate_blue_v6_body import estimate as estimate_source_body

HOME = Path.home()
LIB = HOME / "Libero"
DESTS = {
    "violoncello-solo-libero": LIB / "banks/archi/violoncello-solo-libero",
    "archi-armonici-libero": LIB / "banks/archi/archi-armonici-libero",
    "archi-particolari-libero": LIB / "banks/archi/archi-particolari-libero",
    "mandolino-dorato-libero": LIB / "banks/aria/mandolino-dorato-libero",
    "chitarra-classica-libero": LIB / "banks/chitarre/chitarra-classica-libero",
    "chitarra-classica-accordi-libero": LIB / "banks/chitarre/chitarra-classica-accordi-libero",
    "corno-francese-libero": LIB / "banks/ottoni/corno-francese-libero",
}
OUT = LIB / "demo/release-replacements-v1/acoustic"
BIGCAT = LIB / "cache/libraries/karoryfer-bigcat-cello"
VSCO = LIB / "cache/libraries/vsco2-ce"
FREEPATS = LIB / "cache/libraries/freepats-nylon/SpanishClassicalGuitar-SFZ-20190618"
TAVY = LIB / "cache/libraries/tavymusic-plucked"
SR = 48000

LICENSES = {
    "bigcat": {"source": "Karoryfer × bigcat cello", "author": "D. Smolken / Karoryfer Lecolds, in collaboration with bigcat instruments", "license": "CC0 1.0", "license_class": "cc0", "url": "https://shop.karoryfer.com/pages/free-karoryfer-x-bigcat-cello", "grant_url": "https://shop.karoryfer.com/pages/free-samples"},
    "vsco": {"source": "VSCO 2 Community Edition", "author": "Versilian Studios; Sam Gossner and Simon Dalzell; samples cut by Elan Hickler / Soundemote", "license": "CC0 1.0", "license_class": "cc0", "url": "https://github.com/sgossner/VSCO-2-CE", "grant_url": "https://github.com/sgossner/VSCO-2-CE/blob/SFZ/LICENSE"},
    "freepats": {"source": "Spanish Classical Guitar SFZ", "author": "Roberto / FreePats", "license": "CC0 1.0", "license_class": "cc0", "url": "https://freepats.zenvoid.org/Guitar/acoustic-guitar.html", "grant_url": "https://freepats.zenvoid.org/FreePatsLicense.html"},
    "tavy": {"source": "Plucked Strings SoundFont", "author": "John Maddock (TavyMusic)", "license": "CC0 1.0", "license_class": "cc0", "url": "https://musescore.org/en/node/23225", "grant_url": "https://creativecommons.org/publicdomain/zero/1.0/"},
}

def digest(p: Path) -> str:
    h=sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""): h.update(b)
    return h.hexdigest()

def copy_source(src: Path, dst: Path) -> None:
    if not src.exists(): raise FileNotFoundError(src)
    shutil.copytree(src,dst,dirs_exist_ok=True)

def fetch_page(url: str, path: Path) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() and path.stat().st_size>500:return
    req=Request(url,headers={"User-Agent":"Libero public acoustic release builder"})
    try:
        with urlopen(req,timeout=30) as r: data=r.read()
        if len(data)<500: raise RuntimeError(f"source page too short: {url}")
        path.write_bytes(data)
    except Exception as e:
        # Local licences and explicit grant URLs remain packaged; reports name
        # the failed page rather than silently asserting a download succeeded.
        (path.parent/(path.name+".unavailable.txt")).write_text(f"Could not snapshot {url}: {e}\n")

def source_doc(folder: Path, licenses: list[dict], upstreams: list[tuple[Path,str]]):
    samples=folder/"samples"; refs=samples/"source-reference"; refs.mkdir(parents=True,exist_ok=True)
    rows=[]
    for i,c in enumerate(licenses):
        fetch_page(c["url"],refs/f"source-{i+1}.html")
        fetch_page(c["grant_url"],refs/f"grant-{i+1}.html")
    for src, label in upstreams:
        if src.is_file():
            rows.append({"file":str(src.relative_to(samples)),"source":label,"bytes":src.stat().st_size,"sha256":digest(src)})
    (samples/"source-root-hashes.json").write_text(json.dumps(rows,indent=2,ensure_ascii=False)+"\n")
    (samples/"credits.json").write_text(json.dumps(licenses,indent=2,ensure_ascii=False)+"\n")

def copy_bigcat(folder: Path):
    raw=folder/"samples/originals/bigcat-cello"
    copy_source(BIGCAT,raw)
    return raw

def make_wrapper(dest: Path, source: Path, includes: list[Path], cc: dict[int,int]|None=None) -> Path:
    dest.parent.mkdir(parents=True,exist_ok=True)
    lines=["<control>",f"default_path={source.as_posix()}/Samples/"]
    for k,v in (cc or {}).items(): lines.append(f"set_cc{k}={v}")
    lines += [f'#include "{p.as_posix()}"' for p in includes]
    dest.write_text("\n".join(lines)+"\n")
    return dest

def pressure_loop(source: Path, dest: Path, loop_start_s: float|None=None, xfade_s: float=.18) -> tuple[dict,dict]:
    """Preserve performed attack/pressure and make a source-overlap sustain loop."""
    x,sr=sf.read(source,dtype="float64",always_2d=True)
    if sr!=SR:
        from scipy.signal import resample_poly
        g=math.gcd(sr,SR); x=resample_poly(x,SR//g,sr//g,axis=0); sr=SR
    env=np.sqrt(np.convolve(np.mean(x*x,axis=1),np.ones(480)/480,mode="same"))
    threshold=max(float(env.max())*10**(-36/20),1e-6)
    active=np.flatnonzero(env>=threshold); onset=float(active[0]/sr) if len(active) else 0.0
    start_s=max(.30,onset+.05) if loop_start_s is None else loop_start_s
    start=round(start_s*sr); xf=min(round(max(xfade_s,.30)*sr),round(.30*sr)); keep=round(.135*sr); end=len(x)-keep
    if end-start<round(.58*sr) or 2*xf>=end-start or start<xf:
        raise RuntimeError(f"no viable sustained performance loop: {source} ({len(x)/sr:.2f}s)")
    y=x[:end].copy(); j=end-xf; tgt=start-xf
    ramp_end=end-keep; n=ramp_end-j
    u=np.linspace(0,1,n,endpoint=True);u=u*u*(3-2*u)
    y[j:ramp_end]=x[j:ramp_end]*(1-u[:,None])+x[tgt:tgt+n]*u[:,None]
    y[end-keep:end]=x[start-keep:start]
    tail=x[end:].copy()
    if len(tail):
        f=min(len(tail),round(.008*sr));tail[-f:]*=np.linspace(1,0,f)[:,None];y=np.concatenate([y,tail])
    dest.parent.mkdir(parents=True,exist_ok=True);sf.write(dest,y.astype(np.float32),sr,format="FLAC",subtype="PCM_24")
    w=round(.020*sr)
    seam=10*np.log10((np.sum((y[start-w:start]-y[end-w:end])**2)+1e-30)/(np.sum(y[start-w:start]**2)+np.sum(y[end-w:end]**2)+1e-30))
    return {"start":start,"end":end},{"method":"same-take loop with preserved performed overlap; no oscillator/noise layer","source_seconds":round(len(x)/sr,4),"source_onset_seconds":round(onset,5),"loop_seconds":round((end-start)/sr,4),"loop_seam_db_20ms":round(float(seam),2),"xfade_ms":round(xf*1000/sr,2),"exact_source_overlap_ms":135,"derived_sha256":digest(dest)}

def _dynamic(stem: str) -> tuple[int,int]:
    m=re.search(r"_(p|mp|mf|f)_",stem)
    return {"p":(1,32),"mp":(33,64),"mf":(65,96),"f":(97,127)}.get(m[1] if m else "",(1,127))

def build_cello_rows(folder: Path, preset: str, art: str="sustain") -> tuple[list,dict]:
    raw=copy_bigcat(folder); ss=folder/"samples"; proof=[]; body=[]
    oldmap={r.get("file"):r for r in json.loads((ss/"map.json").read_text()).get("body",[])} if (ss/"map.json").exists() else {}
    sus_sf=raw/"Programs/vc_arco_sus_map.sfz"
    inst=parse_sfz(sus_sf)
    if inst.warnings: raise RuntimeError(inst.warnings)
    # Keep all played ordinary bow dynamics/takes; the four bonus harmonic
    # slides are exposed as their own secondary voice in their own preset.
    for i,r in enumerate(inst.regions):
        if r.sample.parent.name!="sus":continue
        rel=r.sample.relative_to(raw);dst=ss/"originals/bigcat-cello"/rel
        dyn=_dynamic(r.sample.stem);take=max(0,r.seq_position-1)
        derived=ss/"derived/bow"/(r.sample.stem+"-pressure.flac")
        derivedrel=derived.relative_to(ss).as_posix()
        if not derived.exists(): lp,lpq=pressure_loop(r.sample,derived)
        elif derivedrel in oldmap: lp,lpq=oldmap[derivedrel]["loop"],{"derived_sha256":digest(derived),"reused":True}
        else:
            frames=sf.info(derived).frames;lp={"start":14400,"end":frames-6480};lpq={"derived_sha256":digest(derived),"reused":True}
        row={"file":derivedrel,"root":r.root+12,"lo":r.lokey+12,"hi":r.hikey+12,"vel":list(dyn),"take":take,"tune_cents":r.tune_cents,"gain_db":r.gain_db,"loop":lp,"articulation":art}
        body.append(row)
        proof.append({"source_file":str(r.sample),"source_sha256":digest(r.sample),"relative_file":str(rel),"source_mapping":{"root":r.root,"keys":[r.lokey,r.hikey],"velocity":list(dyn),"take":take},"played_mapping":{"root":r.root+12,"keys":[r.lokey+12,r.hikey+12],"octave_correction_semitones":12},"continuation":lpq})
    return body,{"source_regions":len(inst.regions),"sustain_regions":len(body),"harmonic_gesture_regions":sum(r.sample.parent.name=="noises" and "harmonics" in r.sample.name for r in inst.regions),"proof":proof}

def body_defaults(title, subtitle, roots, arts, accent="#8e603c", master=-8, rev=.02, preserve_keys=False, ladder="keep"):
    # Kept conservative: preserve each take's real level/dynamics; room is subtle.
    arts=[dict(x) for x in arts]
    for i,x in enumerate(arts):x.setdefault("key",6+i)
    return f'''import json\nfrom pathlib import Path\nfrom libero import Sound\nm=json.loads((Path(__file__).parent/'samples/map.json').read_text())\nsound=Sound(title={title!r},subtitle={subtitle!r},tags=['sampled','acoustic','release','cc0'],roots={sorted(set(roots))!r},sample_rate=48000,accent={accent!r})\nsound.articulations({arts!r})\nsound.multisample('body',m['body'],process={{'tune':'source','ladder':{ladder!r},'peak_db':-10,'align_ms':0,'pre_ms':0,'fade_ms':0,'loop':'source','end_db':-100,'max_seconds':None,'preserve_key_ranges':{preserve_keys},'edge_fill':False,'encoding':'flac24'}})\nsound.performance(dynamics_source='velocity',dyn_crossfade=0,rr_reset_ms=1500,humanize={{'cents':0,'ms':0,'db':0}},onset_ms=0)\nsound.defaults(mode='Poli',glide=0,voices=32,amp_attack=0,amp_decay=10000,amp_sustain=1,amp_release=240,lvl_body=0,lvl_tail=-8,lvl_attack=-60,lvl_air=-60,vel_sens=.35,master={master},flt_cutoff=12500,flt_env=0,rev_mix={rev},rev_mode='Cappella',rev_size=.18,rev_decay=.6,width=1,tape_wow=0,tape_flutter=0,tape_mix=0,tape_sat=0,drive=0,lfo_pitch=0,lfo_amp=0,echo_mix=0,caldi_mode='Spento')\n'''

def calibrate_stable_body_tuning(folder:Path):
    """Measure looped source bodies; use one sample-root rebase per map cell."""
    samples=folder/"samples";mp=samples/"map.json";mapping=json.loads(mp.read_text());measured=[];proof=[]
    for row in mapping["body"]:
        lp=row.get("loop")
        if not lp or lp.get("end",0)<=lp.get("start",0) or row.get("pitched") is False:continue
        source=samples/row["file"];x,sr=sf.read(source,dtype="float64",always_2d=True)
        if sr!=SR:raise RuntimeError(f"unexpected source rate in stable-body calibration: {source} {sr}")
        root=int(row["root"]);expected=440*2**((root-69)/12)
        # Measure two complete source loop periods by coherent
        # partial-family power centroids, not the loudest FFT peak or a short
        # YIN window that can follow one side of vibrato/tremolo.
        loop=x[int(lp["start"]):int(lp["end"])]
        if len(loop)<int(.25*sr):raise RuntimeError(f"{folder.name} {row['file']} has an implausibly short source loop")
        seg=np.tile(loop.mean(axis=1),2);seg=seg-seg.mean();nfft=1<<int(np.ceil(np.log2(len(seg)*2)));spec=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),nfft));hz=np.fft.rfftfreq(nfft,1/sr);parts=[]
        for harmonic in range(1,9):
            centre=expected*harmonic
            if centre>=sr*.45:break
            ix=np.flatnonzero((hz>=centre*2**(-90/1200))&(hz<=centre*2**(90/1200)))
            if len(ix)<3:continue
            power=spec[ix]**2;energy=float(power.sum())
            if energy<=0:continue
            f=float((hz[ix]*power).sum()/energy)/harmonic;weight=float(np.sqrt(energy));parts.append((f,weight,harmonic))
        if parts:
            offsets=np.array([1200*np.log2(f/expected) for f,w,h in parts]);weights=np.array([w for f,w,h in parts]);order=np.argsort(offsets);cum=np.cumsum(weights[order]);centre=float(offsets[order[np.searchsorted(cum,cum[-1]/2)]]);keep=np.abs(offsets-centre)<35
            if not keep.any():keep=np.ones(len(offsets),dtype=bool)
            cents=float(np.average(offsets[keep],weights=weights[keep]));freq=expected*2**(cents/1200)
        else:
            freq,cents=estimate_source_body(seg[:,None],sr,expected)
        tune=-float(cents)
        if folder.name=="chitarra-classica-accordi-libero":
            # Each recorded string is corrected separately before chord
            # assembly; a single-f0 estimate from the polyphonic composite
            # must not tune every member by one misleading offset.
            tune=0.0
        # The low E1 tremolo loop was checked natively at mapped edge keys
        # after whole-loop source calibration. Its long-loop family centre was
        # -9.15c at every tested key; correct this one take, not each edge.
        if folder.name=="archi-particolari-libero" and row["file"].endswith("trem_E1_v1_1-pressure.flac"):
            tune+=1.84
        if abs(tune)>100:raise RuntimeError(f"{folder.name} {row['file']} needs a verified root split, residual {tune:.2f} cents")
        row["tune_cents"]=round(tune,4)
        proof.append({"file":row["file"],"source_sha256":digest(source),"articulation":row.get("articulation"),"keys":[row["lo"],row["hi"]],"velocity":row.get("vel"),"root":root,"source_measured_hz":round(freq,5),"source_offset_cents_before_correction":round(cents,3),"native_residual_adjustment_cents":1.84 if folder.name=="archi-particolari-libero" and row["file"].endswith("trem_E1_v1_1-pressure.flac") else 0.0,"tune_cents":round(tune,3),"measurement":"two complete periods of the source's own mapped sustain loop; power centroids of coherent partials 1–8 in ±90-cent masks; robust family centre; no source audio modified"})
    mp.write_text(json.dumps(mapping,indent=2,ensure_ascii=False)+"\n")
    (samples/"stable-body-tuning-v1.json").write_text(json.dumps(proof,indent=2,ensure_ascii=False)+"\n")
    roots=sorted({int(z["root"]) for z in mapping["body"] if z.get("pitched") is not False})
    recipe=folder/"sound.py";txt=recipe.read_text();txt=re.sub(r"roots=\[.*?\],sample_rate=48000",f"roots={roots!r},sample_rate=48000",txt,count=1);recipe.write_text(txt)
    with (folder/"notes.md").open("a") as f:f.write("\n## Accordatura del corpo reale\n\nOgni sorgente sostenuta è misurata su due periodi completi del proprio loop: centroidi di potenza dei parziali coerenti entro ±90 centesimi e centro robusto della famiglia armonica. Si applica solo un offset statico per campione; i WAV originali e derivati non vengono alterati e vibrato/tremolo restano intatti. Misure, root, offset e SHA del body sono in `samples/stable-body-tuning-v1.json`.\n")
    return proof

def simple_svg(title: str, desc: str, shape: str, color="#8e603c") -> str:
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="{color}" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><title>{title}</title><desc>{desc}</desc>{shape}</svg>\n'''

def write_artifacts(folder: Path, title: str, notes: str, credits: list[dict], upstreams: list[tuple[Path,str]], figure: str):
    folder.mkdir(parents=True,exist_ok=True);(folder/"figure.svg").write_text(figure)
    (folder/"notes.md").write_text(notes.strip()+"\n")
    source_doc(folder,credits,upstreams)
    (folder/"ATTRIBUTION.md").write_text("\n".join(f"{c['source']} — {c['author']}; {c['license']}. Source: {c['url']}; licence/grant: {c['grant_url']}." for c in credits)+"\n")

def test_map_region(source_root:Path, rel:Path, destroot:Path, row:dict):
    dest=destroot/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    if not dest.exists():shutil.copy2(source_root/rel,dest)
    return dest

def parse_wrapper(name: str, source: Path, sfz: Path, cc: dict[int,int]|None=None):
    p=OUT/f"maps/{name}.sfz"
    return parse_sfz(make_wrapper(p,source,[sfz],cc))

def add_sfz_rows(inst, rawroot:Path, samplesroot:Path, articulation:str, *, pitched=True, loops=False, selected=None, pitch_offset=0):
    body=[];proof=[]
    for r in inst.regions:
        if selected and not selected(r):continue
        if not r.sample.exists():raise FileNotFoundError(r.sample)
        rel=r.sample.relative_to(rawroot)
        dst=samplesroot/"originals"/rawroot.name/rel;dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists():shutil.copy2(r.sample,dst)
        rr=re.search(r"_rr(\d+)",r.sample.stem,re.I)
        take=(int(rr.group(1))-1) if rr else max(0,r.seq_position-1)
        row={"file":dst.relative_to(samplesroot).as_posix(),"root":r.root+pitch_offset,"lo":r.lokey+pitch_offset,"hi":r.hikey+pitch_offset,"vel":[r.lovel,r.hivel],"take":take,"tune_cents":r.tune_cents,"gain_db":r.gain_db,"articulation":articulation}
        if not pitched: row.update(pitched=False,one_shot=True)
        if loops:
            derived=samplesroot/"derived"/articulation/(r.sample.stem+"-pressure.flac")
            # Recompute the source-overlap region deterministically on every
            # build. A stale derived WAV without its map metadata must never
            # silently become a zero-length (no sustain) loop.
            lp,q=pressure_loop(r.sample,derived)
            row.update(file=derived.relative_to(samplesroot).as_posix(),loop=lp)
        else:q={}
        body.append(row)
        proof.append({"source_file":str(r.sample),"source_sha256":digest(r.sample),"mapped":{"source_root":r.root,"source_keys":[r.lokey,r.hikey],"played_root":r.root+pitch_offset,"played_keys":[r.lokey+pitch_offset,r.hikey+pitch_offset],"pitch_offset_semitones":pitch_offset,"vel":[r.lovel,r.hivel],"take":r.seq_position-1,"articulation":articulation},"continuation":q})
    # Some upstream SFZ maps repeat identical rows verbatim and some RR
    # groups begin at rr2 after a missing rr1. Preserve distinct performances,
    # remove only exact map duplicates, then renumber each actual source group.
    unique=[];seen=set()
    for row in body:
        key=(row["file"],row["root"],row["lo"],row["hi"],tuple(row["vel"]),row["articulation"])
        if key in seen:continue
        seen.add(key);unique.append(row)
    groups=defaultdict(list)
    for row in unique:groups[(row["root"],row["lo"],row["hi"],tuple(row["vel"]),row["articulation"])].append(row)
    for rows in groups.values():
        rows.sort(key=lambda x:(int(re.search(r"_rr(\d+)",Path(x["file"]).stem,re.I).group(1)) if re.search(r"_rr(\d+)",Path(x["file"]).stem,re.I) else x["take"],x["file"]))
        for i,row in enumerate(rows):row["take"]=i
    body=unique
    return body,proof

def calibrate_horn_dynamics(rows):
    """Balance recorded soft/medium/loud captures per pitch using zone gain only."""
    groups=defaultdict(lambda:defaultdict(list))
    for row in rows:
        if row.get("articulation") not in {"sustain","staccato","mute"}:continue
        layer=0 if row["vel"][1]<=41 else (1 if row["vel"][1]<=83 else 2)
        path=DESTS["corno-francese-libero"]/"samples"/row["file"]
        x,sr=sf.read(path,dtype="float32",always_2d=True);x=x.mean(axis=1)
        a=int(.02*sr);b=min(len(x),int(.42*sr));x=x[a:b]
        win=max(1,int(.05*sr));r=np.sqrt(np.convolve(x*x,np.ones(win)/win,mode="valid")) if len(x)>=win else np.array([np.sqrt(np.mean(x*x)+1e-12)])
        level=20*np.log10(max(float(np.max(r)),1e-10))+row.get("gain_db",0)
        groups[(row["articulation"],row["lo"],row["hi"])][layer].append((row,level))
    corrections=[]
    for key,layers in groups.items():
        ids=sorted(layers)
        if len(ids)<2:continue
        observed=np.array([float(np.median([lv for _,lv in layers[i]])) for i in ids])
        # PAVA on levels after removing a modest 2 dB per-layer rise; this is
        # the smallest monotonic correction to the measured recordings.
        z=observed-np.arange(len(ids))*2.;blocks=[[float(v),1] for v in z]
        i=0
        while i<len(blocks)-1:
            if blocks[i][0]<=blocks[i+1][0]:i+=1;continue
            n=blocks[i][1]+blocks[i+1][1];avg=(blocks[i][0]*blocks[i][1]+blocks[i+1][0]*blocks[i+1][1])/n
            blocks[i:i+2]=[[avg,n]];i=max(0,i-1)
        fitted=[]
        for val,n in blocks:fitted.extend([val]*n)
        target=np.array(fitted)+np.arange(len(ids))*2.
        for idx,layer in enumerate(ids):
            delta=float(np.clip(target[idx]-observed[idx],-12,12))
            if abs(delta)<.1:continue
            for row,_ in layers[layer]:row["gain_db"]=round(row.get("gain_db",0)+delta,3)
            corrections.append({"articulation":key[0],"keys":[key[1],key[2]],"source_velocity_layer":layer,"gain_correction_db":round(delta,2),"before_level_db":round(float(observed[idx]),2),"target_level_db":round(float(target[idx]),2)})
    return corrections

def order_horn_velocity_cells(rows):
    """Lift weak recorded layers by exact SFZ velocity cell, never alter PCM."""
    cells=defaultdict(list)
    for row in rows:
        if row.get("articulation") not in {"sustain","staccato","mute"}:continue
        key=(row["articulation"],row["lo"],row["hi"],tuple(row["vel"]))
        path=DESTS["corno-francese-libero"]/"samples"/row["file"]
        x,sr=sf.read(path,dtype="float32",always_2d=True);x=x.mean(axis=1);x=x[int(.02*sr):min(len(x),int(.42*sr))]
        win=max(1,int(.05*sr));r=np.sqrt(np.convolve(x*x,np.ones(win)/win,mode="valid")) if len(x)>=win else np.array([np.sqrt(np.mean(x*x)+1e-12)])
        level=20*np.log10(max(float(r.max()),1e-10))+row.get("gain_db",0)
        cells[key].append((row,level))
    keys_by_pitch=defaultdict(list)
    for key,vals in cells.items():keys_by_pitch[key[:3]].append((key,vals))
    proof=[]
    for pitch,entries in keys_by_pitch.items():
        entries.sort(key=lambda kv:(sum(kv[0][3])/2,kv[0][3][0]))
        levels=[float(np.median([v for _,v in vals])) for _,vals in entries]
        targets=[]
        for i,level in enumerate(levels):targets.append(max(level,(targets[-1]+4) if targets else level))
        for (key,vals),before,target in zip(entries,levels,targets):
            delta=float(np.clip(target-before,0,12))
            if delta<.1:continue
            for row,_ in vals:row["gain_db"]=round(row.get("gain_db",0)+delta,3)
            proof.append({"articulation":pitch[0],"keys":[pitch[1],pitch[2]],"velocity_range":list(key[3]),"measured_level_db":round(before,2),"lift_db":round(delta,2)})
    return proof

def build_horn(folder:Path):
    rawroot=VSCO; samples=folder/"samples";copy_vsco_piece(samples,"Brass/F Horn")
    for f in ("FHornSus.sfz","FHornStac.sfz","FHornMute.sfz","LICENSE"):
        shutil.copy2(rawroot/f,samples/"originals/vsco2-ce"/f)
    sus=parse_sfz(rawroot/"FHornSus.sfz"); stac=parse_sfz(rawroot/"FHornStac.sfz"); mute=parse_sfz(rawroot/"FHornMute.sfz")
    allbody=[];proof=[]
    for inst,art,loop,pitch in [(sus,"sustain",True,True),(stac,"staccato",False,True),(mute,"mute",True,True)]:
        b,p=add_sfz_rows(inst,rawroot,samples,art,pitched=pitch,loops=loop)
        allbody+=b;proof+=p
    dynamic_balance=calibrate_horn_dynamics(allbody)
    exact_cell_lifts=order_horn_velocity_cells(allbody)
    roots=[r["root"] for r in allbody]
    (samples/"map.json").write_text(json.dumps({"body":allbody,"tail":[]},indent=2)+"\n")
    (samples/"source-proof.json").write_text(json.dumps({"regions":proof,"recorded_ladder_balance":"per-zone gain corrections after measured early 50 ms RMS, then exact-SFZ-velocity-cell lifts when a recorded loud layer fell below the preceding cell; no waveform replacement","dynamic_balance":dynamic_balance,"exact_cell_lifts":exact_cell_lifts},indent=2)+"\n")
    arts=[{"id":"sustain","name":"Sostenuto · naturale","key":6},{"id":"staccato","name":"Staccato · registrato","key":7},{"id":"mute","name":"Sordina · naturale","key":8}]
    folder.joinpath("sound.py").write_text(body_defaults("Corno francese · aria e ottone","Corno in Fa · VSCO 2 CE · sostegno, staccato e sordina registrati",roots,arts,"#9a703d",master=-2,preserve_keys=True,ladder="smooth"))
    (folder/"notes.md").write_text("Corno francese registrato. Sostenuto, staccato e sordina sono performance distinte del set VSCO; il sustain principale conserva il primo gesto e viene prolungato con sovrapposizione della stessa presa. I campioni originali e le relative mappature restano inclusi. Il set offre copertura discontinua: fuori dai key-range misurati non si estende il suono.\n")
    write_artifacts(folder,"Corno","Corno francese",[LICENSES["vsco"]],[(samples/"originals/vsco2-ce/LICENSE","VSCO 2 CE licence")],simple_svg("Corno francese · aria e ottone","Corno francese con imboccatura, tubo avvolto, campana e chiavi schematizzate.",'<path d="M128 315c15 0 22-24 26-52l9-69c5-38 25-58 61-58h54c20 0 30 12 30 30s-10 29-30 29h-27c-20 0-25 12-30 42l-10 72c-7 46-26 67-65 67h-23" stroke-width="9"/><path d="M282 153c34-19 67-22 93-5l19 12-14 30-23-8c-17-6-37-2-57 11" stroke-width="7"/><path d="M151 257l-38-7m45-34-38-7m45-34-38-7" stroke-width="5"/><circle cx="126" cy="317" r="28" stroke-width="7"/>',"#9a703d"))

def copy_vsco_piece(samples:Path, relative:str):
    copy_source(VSCO/relative,samples/"originals/vsco2-ce"/relative)

def harmonics_loop(source:Path, root:int, samples:Path):
    """Find a stable early harmonic body loop while keeping the full slide take."""
    x,sr=sf.read(source,dtype="float64",always_2d=True)
    if sr!=SR:
        from scipy.signal import resample_poly
        g=math.gcd(sr,SR);x=resample_poly(x,SR//g,sr//g,axis=0);sr=SR
    mono=x.mean(axis=1); candidates=[]
    # Keep the initial performed harmonic note, before the later pitch slide.
    # Look for a musical period between 0.55 and 1.2 s in the stable opening.
    for a in np.arange(.15,.55,.025):
        for duration in np.arange(.75,1.201,.025):
            b=a+duration
            if b>min(2.0,len(mono)/sr-.02):continue
            n=round(.020*sr);i=round(a*sr);j=round(b*sr)
            left=mono[i:i+n];right=mono[j-n:j]
            if len(left)!=n or len(right)!=n:continue
            en=np.mean(left*left)+np.mean(right*right)+1e-30
            err=20*np.log10(np.sqrt(np.mean((left-right)**2)/(en/2)+1e-30))
            candidates.append((float(err),i,j))
    if not candidates:raise RuntimeError(f"no stable harmonic loop candidate: {source}")
    err,i,j=min(candidates,key=lambda t:t[0])
    # Keep the performed attack and form a same-take join inside the stable
    # opening. A 20-ms exact overlap is excluded from the loop start, and the
    # preceding blend softens the join without adding another source.
    w=round(.020*sr);xf=round(.160*sr);start=i+w
    if j-start<round(.55*sr):raise RuntimeError("harmonic body loop too short")
    y=mono[:j].copy();blend_start=max(start,j-xf)
    n=j-blend_start-w
    if n>0:
        u=np.linspace(0,1,n,endpoint=True);u=u*u*(3-2*u)
        y[blend_start:blend_start+n]=y[blend_start:blend_start+n]*(1-u)+y[i+w:i+w+n]*u
    y[j-w:j]=y[start-w:start]
    out=samples/"derived/harmonics"/(source.stem+"-body.flac");out.parent.mkdir(parents=True,exist_ok=True);sf.write(out,y.astype(np.float32),sr,format="FLAC",subtype="PCM_24")
    seam=10*np.log10((np.sum((y[start-w:start]-y[j-w:j])**2)+1e-30)/(np.sum(y[start-w:start]**2)+np.sum(y[j-w:j]**2)+1e-30))
    return {"start":start,"end":j}, {"file":out.relative_to(samples).as_posix(),"method":"same-take performed early partial loop; exact 20-ms overlap plus 160-ms blend; entire original glide retained as secondary","loop_seam_db_20ms":round(float(seam),2),"loop_start_seconds":round(start/sr,5),"loop_end_seconds":round(j/sr,5),"loop_seconds":round((j-start)/sr,4),"stable_pitch_root_midi":root,"source_sha256":digest(source),"derived_sha256":digest(out)}

def build_authored_guitar_chords(folder:Path, inst):
    """Create transparent authored strums from separate real nylon note takes."""
    samples=folder/"samples";byroot={}
    for r in inst.regions:
        if r.sample.exists() and r.root not in byroot:byroot[r.root]=samples/"originals/freepats-nylon"/r.sample.relative_to(FREEPATS)
    roots=sorted(byroot)
    if not roots:raise RuntimeError("FreePats guitar source map is empty")
    body=[];proof=[];arts=[{"id":"major","name":"Accordo maggiore · strum composto","key":6},{"id":"minor","name":"Accordo minore · strum composto","key":7}]
    from scipy.signal import resample_poly
    from build_aria_mechanical import derive_source_body
    for root in range(max(roots[0],36),min(roots[-1]-16,61)+1):
        for quality,intervals in (("major",(0,7,12,16)),("minor",(0,7,12,15))):
            if not all(root+i in byroot for i in intervals):continue
            parts=[];tones=[]
            for delay_ms,interval in zip((0,13,27,41),intervals):
                wanted=root+interval
                srcroot=wanted;src=byroot[srcroot]
                wave,sr=sf.read(src,dtype="float32",always_2d=True)
                if sr!=SR:
                    g=math.gcd(sr,SR);wave=resample_poly(wave,SR//g,sr//g,axis=0).astype(np.float32)
                # These short plucked recordings have strong attacks and weak
                # fundamentals; the generic f0 estimator can lock to a
                # transient partial. Use a stable-window harmonic-family
                # power centroid before correcting the individual stem.
                seg=wave[int(.12*SR):min(len(wave),int(.62*SR))].mean(axis=1);seg=seg-seg.mean();nfft=1<<int(np.ceil(np.log2(max(4096,len(seg)*2))));sp=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),nfft));hzs=np.fft.rfftfreq(nfft,1/SR);expected=440*2**((wanted-69)/12);family=[]
                for harmonic in range(1,9):
                    centre=expected*harmonic
                    if centre>=SR*.45:break
                    ix=np.flatnonzero((hzs>=centre*2**(-90/1200))&(hzs<=centre*2**(90/1200)))
                    if len(ix)<3:continue
                    power=sp[ix]**2;energy=float(power.sum())
                    if energy>0:family.append((float((hzs[ix]*power).sum()/energy)/harmonic,float(np.sqrt(energy))))
                if family:
                    offsets=np.array([1200*np.log2(f/expected) for f,w in family]);weights=np.array([w for f,w in family]);order=np.argsort(offsets);cum=np.cumsum(weights[order]);med=float(offsets[order[np.searchsorted(cum,cum[-1]/2)]]);keep=np.abs(offsets-med)<35
                    source_cents=float(np.average(offsets[keep],weights=weights[keep]));measured_hz=expected*2**(source_cents/1200)
                else:measured_hz,source_cents=estimate_source_body(wave[int(.12*SR):min(len(wave),int(.62*SR))],SR,expected)
                correction=-float(source_cents)
                # scipy's resample_poly changes heard pitch by down/up at a
                # fixed playback SR, the inverse of its output-length ratio.
                ratio=2**(-correction/1200);up=max(1,round(ratio*10000));down=10000;g=math.gcd(up,down);up//=g;down//=g
                if up!=down:wave=resample_poly(wave,up,down,axis=0).astype(np.float32)
                # Iteratively close the calibration on the actual corrected
                # stem (the initial estimate can be transient-sensitive).
                resid=float('inf')
                for _ in range(3):
                    check=wave[int(.12*SR):min(len(wave),int(.62*SR))].mean(axis=1);check-=check.mean();nn=1<<int(np.ceil(np.log2(max(4096,len(check)*2))));ss=np.abs(np.fft.rfft(check*np.hanning(len(check)),nn));ff=np.fft.rfftfreq(nn,1/SR);cc=[];ww=[]
                    for hh in range(1,9):
                        ce=expected*hh
                        if ce>=SR*.45:break
                        ii=np.flatnonzero((ff>=ce*2**(-90/1200))&(ff<=ce*2**(90/1200)))
                        if len(ii)<3:continue
                        pw=ss[ii]**2;ee=float(pw.sum())
                        if ee>0:cc.append(1200*np.log2(float((ff[ii]*pw).sum()/ee)/hh/expected));ww.append(float(np.sqrt(ee)))
                    if not cc:break
                    oo=np.argsort(cc);cu=np.cumsum(np.asarray(ww)[oo]);mm=cc[oo[np.searchsorted(cu,cu[-1]/2)]];kk=np.abs(np.asarray(cc)-mm)<35;resid=float(np.average(np.asarray(cc)[kk],weights=np.asarray(ww)[kk]))
                    if abs(resid)<.35:break
                    ratio=2**(resid/1200);up=max(1,round(ratio*10000));down=10000;g=math.gcd(up,down);up//=g;down//=g
                    if up!=down:wave=resample_poly(wave,up,down,axis=0).astype(np.float32)
                if abs(resid)>.75:raise RuntimeError(f"chord stem calibration failed {wanted}: {resid:+.2f} cents")
                correction=-float(source_cents)-resid
                parts.append((round(delay_ms*SR/1000),wave))
                comp=samples/"derived/chord-components"/f"{root:03d}-{quality}-{wanted}.flac";comp.parent.mkdir(parents=True,exist_ok=True);sf.write(comp,wave,SR,subtype="PCM_24")
                tones.append({"source_file":str(src),"source_sha256":digest(src),"source_root":srcroot,"chord_tone":wanted,"transpose_semitones":wanted-srcroot,"source_measured_hz":round(float(measured_hz),3),"source_pitch_offset_cents":round(float(source_cents),2),"static_component_correction_cents":round(correction,2),"measured_corrected_stem_residual_cents":round(resid,3),"onset_stagger_ms":delay_ms,"corrected_component_file":comp.relative_to(samples).as_posix(),"corrected_component_sha256":digest(comp)})
            length=max(d+len(w) for d,w in parts);mix=np.zeros((length,1),np.float32)
            for d,w in parts:
                mono=w.mean(axis=1,keepdims=True);mix[d:d+len(mono)]+=mono*.42
            peak=float(np.max(np.abs(mix)))
            if peak>.92:mix*=.92/peak
            raw=samples/"derived/chord-source"/f"{root:03d}-{quality}.wav";raw.parent.mkdir(parents=True,exist_ok=True);sf.write(raw,mix,SR,subtype="PCM_24")
            body.append({"file":raw.relative_to(samples).as_posix(),"root":root,"lo":root,"hi":root,"vel":[1,127],"take":0,"tune_cents":0,"articulation":quality})
            proof.append({"root":root,"quality":quality,"source_chord_sha256":digest(raw),"method":"4 independent FreePats nylon recordings, authored 0/13/27/41 ms stagger, natural recorded decay","tones":tones})
    (samples/"map.json").write_text(json.dumps({"body":body,"tail":[]},indent=2)+"\n")
    (samples/"source-proof.json").write_text(json.dumps({"recorded_chords":False,"authored_strum":True,"proof":proof},indent=2)+"\n")
    title="Chitarra classica · accordi II";subtitle="Accordi maggiori/minori da note nylon indipendenti; strum composto, non registrato"
    folder.joinpath("sound.py").write_text(body_defaults(title,subtitle,[r["root"] for r in body],arts,"#a67a46",master=-12,rev=.035).replace("'loop':'source'", "'loop':'none'"))
    note="Ogni accordo combina quattro riprese nylon FreePats distinte (fondamentale, quinta, ottava, terza maggiore/minore) con ingressi a 0/13/27/41 ms. È uno strum composto in modo dichiarato, non una registrazione reale di accordo o strumming. Il decadimento conserva quello delle registrazioni originali; la fonte è a dinamica singola e senza RR. source-proof.json elenca sample, pitch, trasposizioni e hash.\n"
    write_artifacts(folder,title,note,[LICENSES["freepats"]],[(samples/"originals/freepats-nylon/cc0.txt","FreePats CC0 legal code")],simple_svg(title,"Chitarra classica a corde nylon disegnata per il preset.",'<path d="M256 78c-22 26-23 75-11 107-39 8-71 47-77 91-8 56 19 109 68 128 41 16 91 7 117-24 32-38 31-99-4-140-19-22-44-36-71-42 12-31 11-85-22-120z" stroke-width="5"/><circle cx="256" cy="291" r="40" stroke-width="5"/><path d="M256 80V332M266 82V330M246 82V330M236 82V330M276 82V330M286 82V330M206 342L305 342" stroke-width="1.5"/>',"#a67a46"))

def build_guitar(folder:Path, chords=False):
    samples=folder/"samples";copy_source(FREEPATS,samples/"originals/freepats-nylon")
    inst=parse_sfz(FREEPATS/"SpanishClassicalGuitar-20190618.sfz")
    if chords:return build_authored_guitar_chords(folder,inst)
    body=[];proof=[]
    oldmap={r.get("file"):r for r in json.loads((samples/"map.json").read_text()).get("body",[])} if (samples/"map.json").exists() else {}
    for r in inst.regions:
        rel=r.sample.relative_to(FREEPATS);src=samples/"originals/freepats-nylon"/rel
        body.append({"file":src.relative_to(samples).as_posix(),"root":r.root,"lo":r.lokey,"hi":r.hikey,"vel":[r.lovel,r.hivel],"take":0,"tune_cents":r.tune_cents,"articulation":"nylon"})
        proof.append({"source_file":str(r.sample),"source_sha256":digest(r.sample),"mapping":{"root":r.root,"lo":r.lokey,"hi":r.hikey},"playback":"natural recorded decay, no loop"})
    (samples/"map.json").write_text(json.dumps({"body":body,"tail":[]},indent=2)+"\n");(samples/"source-proof.json").write_text(json.dumps(proof,indent=2)+"\n")
    slug=folder.name
    title="Chitarra classica · nylon" if not chords else "Chitarra classica · accordi"
    subtitle=("Nylon spagnolo FreePats · decadimento naturale" if not chords else "Accordi su tastiera · campioni singola nota FreePats; non sono strumming registrati")
    arts=[{"id":"nylon" if not chords else "chords","name":"Nylon · naturale" if not chords else "Accordi · singole corde registrate","key":6}]
    folder.joinpath("sound.py").write_text(body_defaults(title,subtitle,[r["root"] for r in body],arts,"#a67a46",master=-10,rev=.035).replace("'loop':'source'", "'loop':'none'"))
    content=("Ogni nota deriva da una ripresa nylon FreePats; il decadimento naturale della corda è conservato senza loop. La fonte ha una sola dinamica e nessun RR.\n" if not chords else "Preset per suonare accordi con note MIDI indipendenti; non contiene campioni di strumming o accordi registrati. Ogni nota è la reale singola ripresa nylon FreePats; perciò un accordo eseguito somma le note separate del preset, senza ritardare/copiare una performance unica. La fonte ha una sola dinamica e nessun RR.\n")
    write_artifacts(folder,title,content,[LICENSES["freepats"]],[(samples/"originals/freepats-nylon/cc0.txt","FreePats CC0 legal code")],simple_svg(title,"Chitarra classica a corde nylon disegnata per il preset.",'<path d="M256 78c-22 26-23 75-11 107-39 8-71 47-77 91-8 56 19 109 68 128 41 16 91 7 117-24 32-38 31-99-4-140-19-22-44-36-71-42 12-31 11-85-22-120z" stroke-width="5"/><circle cx="256" cy="291" r="40" stroke-width="5"/><path d="M256 80V332M266 82V330M246 82V330M236 82V330M276 82V330M286 82V330M206 342L305 342" stroke-width="1.5"/><path d="M231 182l50 0M230 193l52 0" stroke-width="3"/>',"#a67a46"))

def _sf2_chunks(path:Path):
    data=path.read_bytes()
    if data[:4]!=b"RIFF" or data[8:12]!=b"sfbk":raise ValueError("not an SF2 RIFF file")
    def chunks(start,end):
        out=[];pos=start
        while pos+8<=end:
            tag=data[pos:pos+4];size=struct.unpack_from('<I',data,pos+4)[0];a=pos+8;b=a+size
            if b>end:raise ValueError(f"bad chunk {tag}")
            out.append((tag,a,b))
            pos=b+(size&1)
        return out
    top=chunks(12,len(data)); groups={}
    for tag,a,b in top:
        if tag==b"LIST":
            kind=data[a:a+4]
            if kind in (b"pdta",b"sdta"):
                groups[kind]={t:(x,y) for t,x,y in chunks(a+4,b)}
    return data,groups

def _sf2_records(blob,fmt):
    sz=struct.calcsize(fmt)
    return [struct.unpack_from(fmt,blob,i) for i in range(0,len(blob)-sz+1,sz)]

def _baggens(data,groups,bagname,genname):
    a,b=groups[b"pdta"][bagname];bags=_sf2_records(data[a:b],'<HH')
    a,b=groups[b"pdta"][genname];gens=_sf2_records(data[a:b],'<HH')
    return [gens[bags[i][0]:bags[i+1][0]] for i in range(len(bags)-1)]

def extract_sf2_preset(sf2:Path,preset_name:str,dest:Path):
    """Minimal hydra-table extraction, retaining actual sample PCM and map ranges."""
    data,groups=_sf2_chunks(sf2); ph=_sf2_records(data[groups[b"pdta"][b"phdr"][0]:groups[b"pdta"][b"phdr"][1]],'<20sHHHIII')
    pg=_baggens(data,groups,b"pbag",b"pgen"); ih=_sf2_records(data[groups[b"pdta"][b"inst"][0]:groups[b"pdta"][b"inst"][1]],'<20sH')
    ig=_baggens(data,groups,b"ibag",b"igen"); sh=_sf2_records(data[groups[b"pdta"][b"shdr"][0]:groups[b"pdta"][b"shdr"][1]],'<20sIIIIIBbHH')
    pidx=next(i for i,x in enumerate(ph[:-1]) if x[0].split(b'\0')[0].decode(errors='replace')==preset_name)
    pbag=ph[pidx][3]; pend=ph[pidx+1][3]; smpl_a,smpl_b=groups[b"sdta"][b"smpl"]
    zones=[]; saved={};
    def vals(gs):return {op:am for op,am in gs}
    def keyrange(v,default=(0,127)):
        if v is None:return default
        return (v&255,(v>>8)&255)
    for pbi in range(pbag,pend):
        pgen=vals(pg[pbi]); instidx=pgen.get(41)
        if instidx is None:continue
        pkr=keyrange(pgen.get(43)); pvr=keyrange(pgen.get(44))
        ibeg=ih[instidx][1]; iend=ih[instidx+1][1]
        for ibi in range(ibeg,iend):
            igen=vals(ig[ibi]); sid=igen.get(53)
            if sid is None or sid>=len(sh)-1:continue
            ikr=keyrange(igen.get(43)); ivr=keyrange(igen.get(44))
            lo=max(pkr[0],ikr[0]);hi=min(pkr[1],ikr[1]);vl=max(pvr[0],ivr[0]);vh=min(pvr[1],ivr[1])
            if lo>hi or vl>vh:continue
            h=sh[sid]; sample_name=h[0].split(b'\0')[0].decode(errors='replace')
            root=igen.get(58,h[6]);fine=igen.get(52,0)
            fine=(fine if fine<128 else fine-256)+(h[7] if h[7]<128 else h[7]-256)
            if sid not in saved:
                start,end,rate=h[1],h[2],h[5]
                pcm=np.frombuffer(data[smpl_a+start*2:smpl_a+end*2],dtype='<i2').copy()
                w=dest/(sample_name+'.wav');w.parent.mkdir(parents=True,exist_ok=True)
                sf.write(w,pcm,rate,subtype='PCM_16');saved[sid]=w
            file=saved[sid]
            zones.append({"file":file,"sample":sample_name,"root":root,"tune_cents":fine,"lo":lo,"hi":hi,"vel":[vl,vh],"take":0,"loop":{"start":h[3]-h[1],"end":h[4]-h[1]}})
    return zones,sorted({z['root'] for z in zones}),len(saved)

def build_mandolin(folder:Path):
    samples=folder/"samples";raw=samples/"originals/tavymusic";copy_source(TAVY,raw)
    sf2=raw/"PluckedStrings.sf2";extract= samples/"extracted-sf2";zones,roots,n=extract_sf2_preset(sf2,"Mando Celtic Oval",extract)
    body=[];proof=[];natural_lo,natural_hi=min(roots),max(roots)
    oldmap={r.get("file"):r for r in json.loads((samples/"map.json").read_text()).get("body",[])} if (samples/"map.json").exists() else {}
    for z in zones:
        src=z['file'];dest=samples/"derived"/(src.stem+"-hold.flac")
        # Plucked-note sustain is a designed continuation of its real early
        # modal body. The attack and natural recorded transient are preserved.
        from build_aria_mechanical import derive_source_body
        destrel=dest.relative_to(samples).as_posix()
        if not dest.exists():lp,audit=derive_source_body(src,dest,z['root'],period=8,transition_end=.42)
        else:lp,audit=oldmap.get(destrel,{}).get("loop",{"start":0,"end":0}),{"measured_component_count":None}
        vel=[max(1,z['vel'][0]),max(1,z['vel'][1])]
        lo=max(natural_lo,z['lo']);hi=min(natural_hi,z['hi'])
        if lo>hi:continue
        body.append({k:v for k,v in {"file":destrel,"root":z['root'],"lo":lo,"hi":hi,"vel":vel,"take":z['take'],"tune_cents":z['tune_cents'],"loop":lp,"articulation":"mandolin"}.items()})
        proof.append({"source_file":str(src),"source_sha256":digest(src),"sf2_sample":z['sample'],"root":z['root'],"velocity":z['vel'],"upstream_keys":[z['lo'],z['hi'] ],"played_keys":[lo,hi],"tune_cents":z['tune_cents'],"continuation":{"method":"phase-fitted same-source modal body","mode_count":audit['measured_component_count'],"loop_seam_db_20ms":None,"source_seconds":sf.info(src).duration,"derived_sha256":digest(dest)}})
    (samples/"map.json").write_text(json.dumps({"body":body,"tail":[]},indent=2)+"\n");(samples/"source-proof.json").write_text(json.dumps({"sf2_source":digest(sf2),"selected_instrument":"Mando Celtic Oval","samples_extracted":n,"zones":proof},indent=2)+"\n")
    art=[{"id":"mandolin","name":"Plettro celtico · registrato","key":6}]
    folder.joinpath("sound.py").write_text(body_defaults("Mandolino dorato · Celtic Oval","TavyMusic Plucked Strings · campioni reali mono, registro misurato, mappa SF2 conservata",roots,art,"#bb9255",master=-9,rev=.03,preserve_keys=True))
    notes="Mandolino suonato a plettro (patch Mando Celtic Oval). Il contenitore SF2 originale e tutti i sample PCM estratti per la mappa sono inclusi. La patch ha una sola dinamica e non offre round robin; non sono stati inventati. La variante sostenuta usa un corpo modale derivato dalla singola registrazione con attacco originale preservato, non è un decadimento naturale infinito. La fonte distingue anche Mando Gibson, mandola, octave mandolin e chitarre; qui è scelto soltanto Celtic Oval.\n"
    write_artifacts(folder,"Mandolino dorato",notes,[LICENSES["tavy"]],[(sf2,"SF2 originale con metadati di licenza interni")],simple_svg("Mandolino dorato · Celtic Oval","Mandolino a guscio con corde doppie e cavigliere schematiche.",'<path d="M256 75c-18 24-15 57 1 83-53 12-93 64-93 127 0 75 45 139 105 139s105-64 105-139c0-63-40-115-93-127 16-26 19-59 1-83z" stroke-width="6"/><circle cx="256" cy="280" r="36" stroke-width="5"/><path d="M256 80V360M248 84V360M264 84V360M240 86V360M272 86V360M232 88V360M280 88V360" stroke-width="1.3"/><path d="M188 210Q256 175 324 210M185 339Q256 371 327 339" stroke-width="2"/>',"#bb9255"))

def build_cello_presets():
    src=BIGCAT; sus=parse_sfz(src/"Programs/vc_arco_sus_map.sfz")
    stac=parse_sfz(make_wrapper(OUT/"maps/stacc.sfz",src,[src/"Programs/vc_arco_staccato_map.sfz"],{107:75}))
    pizz=parse_sfz(src/"Programs/vc_pizz_basic.sfz")
    if not sus.regions or not stac.regions or not pizz.regions: raise RuntimeError("Bigcat cello source maps did not resolve")
    for slug,kind in [("violoncello-solo-libero","solo"),("archi-armonici-libero","harmonics"),("archi-particolari-libero","particular")]:
        folder=DESTS[slug];samples=folder/"samples";copy_bigcat(folder)
        body=[];proof=[];credits=[LICENSES["bigcat"]]
        arts=[]
        if kind=="solo":
            main,meta=build_cello_rows(folder,slug,"sustain");body.extend(main);proof.extend(meta["proof"])
            arts=[{"id":"sustain","name":"Arco · sostenuto","key":6}]
            for inst,art,label,selected in [(stac,"staccato","Staccato · 4 riprese",lambda r:r.sample.parent.name=="staccato"),(pizz,"pizzicato","Pizzicato · 4 riprese",lambda r:r.sample.parent.name=="pizzcato")]:
                b,p=add_sfz_rows(inst,BIGCAT,samples,art,pitched=True,selected=selected,pitch_offset=12);body.extend(b);proof.extend(p);arts.append({"id":art,"name":label,"key":6+len(arts)})
        elif kind=="harmonics":
            arts=[{"id":"harmonics","name":"Armonici · corpo tenuto","key":6},{"id":"slides","name":"Scivolate armoniche · integrali","key":7}]
            roots_by_file={"c1_harmonics.wav":48,"g1_harmonics.wav":43,"d2_harmonics.wav":50,"a2_harmonics.wav":57}
            for r in sus.regions:
                if "harmonics" not in r.sample.name:continue
                rel=r.sample.relative_to(BIGCAT);dst=samples/"originals/bigcat-cello"/rel;root=roots_by_file[r.sample.name]
                lp,detail=harmonics_loop(dst,root,samples)
                body.append({"file":detail["file"],"root":root,"lo":root,"hi":root,"vel":[1,127],"take":0,"loop":lp,"articulation":"harmonics"})
                body.append({"file":dst.relative_to(samples).as_posix(),"root":root,"lo":root,"hi":root,"vel":[1,127],"take":0,"pitched":False,"one_shot":True,"articulation":"slides"})
                proof.append({"source_file":str(r.sample),"source_sha256":digest(r.sample),"source_art":"recorded harmonic slide", "measured_root_midi":root,"source_mapping":{"original_keys":[r.lokey,r.hikey],"original_root":r.root},"loop":detail})
        else:
            # This main voice is a real cello-section tremolo from VSCO, not a
            # second mapping of the solo bow source.
            copy_vsco_piece(samples,"Strings/Cello Section")
            for f in ("CelloEnsTrem.sfz","LICENSE"):
                shutil.copy2(VSCO/f,samples/"originals/vsco2-ce"/f)
            trem=parse_sfz(VSCO/"CelloEnsTrem.sfz")
            main,p=add_sfz_rows(trem,VSCO,samples,"tremolo",pitched=True,loops=True);body.extend(main);proof.extend(p);credits.append(LICENSES["vsco"])
            arts=[{"id":"tremolo","name":"Tremolo · sezione reale","key":6}]
            for inst,art,label,selected in [(stac,"staccato","Staccato · cello solo",lambda r:r.sample.parent.name=="staccato"),(pizz,"pizzicato","Pizzicato · cello solo",lambda r:r.sample.parent.name=="pizzcato"),(pizz,"gestures","Gesti percussivi · registrati",lambda r:r.sample.parent.name=="noises")]:
                b,p=add_sfz_rows(inst,BIGCAT,samples,art,pitched=(art!="gestures"),selected=selected,pitch_offset=(12 if art!="gestures" else 0));body.extend(b);proof.extend(p);arts.append({"id":art,"name":label,"key":6+len(arts)})
        (samples/"map.json").write_text(json.dumps({"body":body,"tail":[]},indent=2)+"\n")
        (samples/"source-proof.json").write_text(json.dumps({"preset":slug,"articulations":arts,"source_regions":len(sus.regions),"source_proof":proof},indent=2)+"\n")
        roots=[r['root'] for r in body if r.get('pitched') is not False]
        if kind=="solo": title="Violoncello solo II";sub="Bigcat Cello · 4 dinamiche/2 riprese d'arco, staccato e pizzicato reali";acc="#9b734e"
        elif kind=="harmonics": title="Armonici del violoncello II";sub="Quattro scivolate armoniche reali, tenute sui parziali registrati stabili";acc="#ac8756"
        else: title="Archi particolari II";sub="Tremolo reale della sezione cello, staccato/pizzicato e gesti acustici";acc="#80634d"
        folder.joinpath("sound.py").write_text(body_defaults(title,sub,roots,arts,acc,master=-9,rev=.03))
        notes=("Sostenuto: entrambe le riprese e tutte le quattro dinamiche sono riprese reali dello stesso violoncellista. Il preset corregge di un’ottava il root numerico storico dell’SFZ Bigcat, verificato contro le frequenze reali; il registro sonoro è C2–C6. Una continuazione periodica dallo stesso segnale conserva ingresso e movimento d'arco; il preset aggiunge staccato (4 riprese) e pizzicato (4 riprese) originali come articolazioni secondarie.\n" if kind=="solo" else "Le quattro sorgenti sono vere scivolate armoniche del violoncello e contengono anche movimento di pitch registrato. Il corpo principale termina l'ingresso su un tratto misurato: C3, G2, D3 e A3, uno per nota; il loop ripete il segmento armonico registrato e non genera un oscillatore. L'articolazione Scivolate riproduce per intero i file originali come gesti one-shot. Solo quattro note sono campionate: non vengono interpolate/camuffate le regioni mancanti. Le finestre e i seam misurati sono nel source-proof.json.\n" if kind=="harmonics" else "Voce principale: tremolo realmente registrato dalla sezione cello di VSCO 2 CE, continuato dalla stessa presa. Art secondarie: staccato e pizzicato con riprese del cello solo Bigcat, più rumori percussivi veri; le code brevi restano naturali. Le due fonti e le loro licenze sono separate in credits.json.\n")
        # Include the full upstream source dataset in each replacement; copies
        # are independently hashable and do not reference another preset.
        upstream=[(samples/"originals/bigcat-cello/LICENSE","CC0 source grant")]
        if kind=="particular":upstream.append((samples/"originals/vsco2-ce/LICENSE","VSCO 2 CE source grant"))
        write_artifacts(folder,title,notes,credits,upstream,simple_svg(title,"Violoncello acustico con manico, tastiera, quattro corde e arco disegnati.",'<path d="M202 79c-26 14-33 48-20 71l16 20-44 156c-14 49 6 108 53 132 47 24 108 4 125-44 14-39 2-76-21-105l-36-47 45-123 26-12c28-13 35-46 15-67-17-19-49-17-64 3l-13 20-45 120-30-40 28-79-8-23c-9-26-36-41-62-28z" stroke-width="5"/><path d="M226 186L174 343M237 190L184 348M248 194L194 352M260 198L204 356M168 344Q132 390 167 438M321 190L142 166" stroke-width="2.2"/><circle cx="248" cy="307" r="23" stroke-width="3"/>',acc))

def build_all():
    OUT.mkdir(parents=True,exist_ok=True)
    # Check source licences/materials before touching any new destination.
    for path in (BIGCAT/"LICENSE",FREEPATS/"cc0.txt",TAVY/"PluckedStrings.sf2",VSCO/"FHornSus.sfz"):
        if not path.exists(): raise RuntimeError(f"required public source missing: {path}")
    build_cello_presets()
    build_guitar(DESTS["chitarra-classica-libero"],False)
    build_guitar(DESTS["chitarra-classica-accordi-libero"],True)
    build_mandolin(DESTS["mandolino-dorato-libero"])
    build_horn(DESTS["corno-francese-libero"])
    tuning_reports={slug:calibrate_stable_body_tuning(folder) for slug,folder in DESTS.items()}
    report={"created_utc":datetime.now(timezone.utc).isoformat(),"presets":{},"errors":[]}
    for slug,folder in DESTS.items():
        result=compile_sound(folder,jobs=2)
        if not result.ok:raise RuntimeError(f"compile {slug}: {result.text()}")
        findings=lint_bundle(Path(result.build));counts=Counter(f.level for f in findings)
        (folder/"lint.txt").write_text("\n".join(f.line() for f in findings)+"\n")
        manifest=json.loads((Path(result.build)/"manifest.json").read_text())
        (folder/"source-hash.json").write_text(json.dumps({"source_hash":manifest["source_hash"],"source_hash_fresh":True},indent=2)+"\n")
        report["presets"][slug]={"compile_summary":result.summary,"lint_counts":dict(counts),"source_hash":manifest["source_hash"],"source_hash_fresh":True,"zones":len(manifest.get("zones",[])),"stable_body_tuned_zones":len(tuning_reports[slug]),"errors":[]}
    (OUT/"build-report.json").write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n")

if __name__=="__main__":
    build_all()
