#!/usr/bin/env python3
"""Build four source-led Aria mallet/chime instruments from VCSL originals.

Every original WAV is retained, mapped exactly once to its measured/labelled key,
and accompanied by a phase-coherent source-derived sustain continuation.
"""
from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen
import json, math, re, shutil, sys

import numpy as np
import soundfile as sf
from scipy.signal import find_peaks

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'python'))
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero import render, analysis

HOME = Path.home()
BANK = HOME / 'Libero' / 'banks' / 'aria'
CACHE = HOME / 'Libero' / 'cache' / 'libraries' / 'vcsl'
DEMO = HOME / 'Libero' / 'demo' / 'aria-expansion-mallets'
DEMO.mkdir(parents=True, exist_ok=True)
VCSL_API = 'https://api.github.com/repos/sgossner/VCSL'
VCSL_RAW = 'https://raw.githubusercontent.com/sgossner/VCSL/master/'
BASE = Path('Idiophones/Struck Idiophones')
INSTRUMENTS = [
    {'slug':'marimba-radice','title':'Marimba radice','subtitle':'VCSL · tre dinamiche registrate, barre lignee profonde',
     'folder':BASE/'Marimba','kind':'marimba'},
    {'slug':'vibrafono-caldo','title':'Vibrafono caldo','subtitle':'VCSL · mazze morbide e dure, più arco registrato',
     'folder':BASE/'Vibraphone','kind':'vibraphone'},
    {'slug':'handchimes-aria','title':'Hand chimes d’aria','subtitle':'VCSL · campane manuali, singole note registrate',
     'folder':BASE/'Hand Chimes','kind':'handchimes'},
    {'slug':'tubolari-risonanti','title':'Tubolari risonanti','subtitle':'VCSL · campane tubolari con dinamiche originali',
     'folder':BASE/'Tubular Bells 1','kind':'tubular'},
]
NOTE_PC = {'C':0,'C#':1,'Db':1,'D':2,'D#':3,'Eb':3,'E':4,'F':5,'F#':6,'Gb':6,'G':7,'G#':8,'Ab':8,'A':9,'A#':10,'Bb':10,'B':11}
DYN_VEL = {'soft':[1,42], 'med':[43,84], 'medium':[43,84], 'loud':[85,127], 'pp':[1,30], 'p':[31,54], 'mp':[31,54], 'mf':[55,78], 'f':[55,78], 'ff':[79,104], 'fff':[105,127], 'v1':[1,42], 'v2':[43,84], 'v3':[85,127]}
LAYER_GAIN = {'vibraphone': {'bowed':30.0}}


def get_json(url):
    req = Request(url, headers={'User-Agent':'Libero Aria source audit/1.0'})
    with urlopen(req, timeout=60) as r: return json.loads(r.read().decode('utf-8'))


def fetch(url, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists() or dest.stat().st_size < 1024:
        req = Request(url, headers={'User-Agent':'Libero Aria source acquisition/1.0'})
        with urlopen(req, timeout=120) as r: payload = r.read()
        if len(payload) < 1024: raise RuntimeError(f'Incomplete download: {url} ({len(payload)} bytes)')
        dest.write_bytes(payload)
    return dest


def midi(label):
    m = re.fullmatch(r'([A-G](?:#|b)?)(-?\d+)', label)
    if not m: raise ValueError(label)
    return (int(m.group(2))+1)*12 + NOTE_PC[m.group(1)]


def note_from_name(name):
    m = re.search(r'(?<![A-Za-z])([A-G](?:#|b)?\d+)(?!\d)', name)
    if not m: raise ValueError(f'No note label in {name}')
    return m.group(1)


def pitch_audit(path, label):
    x, sr = sf.read(path, dtype='float64', always_2d=True)
    mono = x.mean(axis=1)
    expected = midi(label)
    # YIN is useful when it locks to a bar's musical root; retain its raw result
    # and compare the dominant modal family rather than assuming filenames are exact.
    from libero import dsp
    lo_hz = 440 * 2 ** ((expected-69-15)/12)
    hi_hz = 440 * 2 ** ((expected-69+15)/12)
    seg = mono[int(.04*sr):min(len(mono),int(.45*sr))]
    yin, voiced = dsp.estimate_f0(seg, sr, fmin=max(25,lo_hz*.45), fmax=hi_hz*1.5)
    nfft = 1 << int(np.ceil(np.log2(max(65536, len(seg)*12))))
    spec = np.abs(np.fft.rfft(seg*np.hanning(len(seg)), n=nfft))
    freq = np.fft.rfftfreq(nfft,1/sr)
    peaks,_=find_peaks(spec)
    peaks = [int(i) for i in peaks if 35 < freq[i] < min(14000,sr*.47)]
    peaks.sort(key=lambda i: spec[i], reverse=True)
    strongest = float(freq[peaks[0]]) if peaks else None
    f0 = float(yin) if np.isfinite(yin) else float('nan')
    # Report YIN only as a candidate; an inharmonic source's tonal center is
    # confirmed against its filename root and multiple strong modal peaks.
    cents = float(1200*np.log2(f0/(440*2**((expected-69)/12)))) if np.isfinite(f0) else None
    rms = float(np.sqrt(np.mean(mono*mono)))
    return {'source_note_label':label,'label_midi':expected,
            'yin_f0_hz':round(f0,3) if np.isfinite(f0) else None,
            'yin_voiced_fraction':round(float(voiced),3),
            'yin_offset_cents_from_label':round(cents,2) if cents is not None else None,
            'strongest_component_hz':round(strongest,3) if strongest else None,
            'duration_s':round(len(mono)/sr,4),'sample_rate_hz':sr,
            'peak_dbfs':round(20*np.log10(max(float(np.max(np.abs(mono))),1e-12)),2),
            'rms_dbfs':round(20*np.log10(max(rms,1e-12)),2),
            'sha256':sha256(path.read_bytes()).hexdigest()}


def list_source_files(rel):
    api = VCSL_API + '/contents/' + quote(rel.as_posix(), safe='/') + '?ref=master'
    out=[]
    for entry in get_json(api):
        p=Path(entry['path'])
        if entry['type']=='dir': out.extend(list_source_files(p.relative_to(Path('.'))))
        elif p.suffix.lower()=='.wav': out.append(entry)
    return sorted(out,key=lambda x:x['path'])


def get_repo_commit():
    for inst in INSTRUMENTS:
        credits=BANK/inst['slug']/'samples'/'credits.json'
        if credits.exists():
            try:
                commit=json.loads(credits.read_text())[0].get('source_commit')
                if commit: return commit
            except Exception: pass
    return get_json(VCSL_API+'/commits/master')['sha']


def import_source(inst, commit):
    dest=BANK/inst['slug']
    samples=dest/'samples'
    originals=samples/'src'
    originals.mkdir(parents=True,exist_ok=True)
    items=[]
    prior=samples/'provenance.json'
    if prior.exists():
        old=json.loads(prior.read_text())
        entries=[]
        for r in old:
            source=samples/r['file']
            entries.append(({'name':Path(r['source_path']).name,'path':r['source_path'],
                             'size':r['byte_size'],'sha':r['github_blob_sha'],
                             'download_url':r.get('download_url')},source))
    else:
        entries=[(e,None) for e in list_source_files(inst['folder'])]
    for entry,known_source in entries:
        rel=Path(entry['path'])
        # Keep a readable stable name; folder hierarchy is recorded in provenance.
        name=(rel.parent.name.lower().replace(' ','-')+'--' if rel.parent.name != inst['folder'].name else '')+rel.name
        source=known_source if known_source is not None else originals/name
        cache_rel=rel
        cached=CACHE/cache_rel
        if cached.exists() and cached.stat().st_size==entry['size']:
            if not source.exists(): source.write_bytes(cached.read_bytes())
        else:
            url=VCSL_RAW+quote(rel.as_posix(),safe='/')
            fetch(url,source)
        if source.stat().st_size != entry['size']:
            raise RuntimeError(f"Source size mismatch {entry['path']}: {source.stat().st_size} != {entry['size']}")
        items.append((entry,source))
    return dest,items


def dyn_and_art(inst, entry):
    filename=Path(entry['name']).stem
    kind=inst['kind']
    if kind=='marimba':
        m=re.search(r'_(soft|med|loud)_',filename)
        return m.group(1),None,0
    if kind=='vibraphone':
        if 'Bowed' in entry['path']: return None,'bowed',0
        folder='soft' if 'Soft Mallets' in entry['path'] else 'hard'
        m=re.search(r'_v([123])_',filename)
        return ('v'+m.group(1) if m else None),folder,0
    if kind=='handchimes': return None,None,0
    m=re.search(r'_(pp|p|mp|mf|f|ff|fff)_rr(\d+)',filename)
    if not m: raise ValueError(f'Cannot parse tubular layer: {filename}')
    return m.group(1),None,int(m.group(2))


def transition_for(path):
    # Retain a 180 ms human attack. Fast-decaying high bars splice earlier to
    # avoid the audible dip/swell seen with a fixed 650 ms transition.
    x,sr=sf.read(path,dtype='float64',always_2d=True)
    x=x.mean(axis=1)
    def rms(a,b):
        seg=x[int(a*sr):min(len(x),int(b*sr))]
        return float(np.sqrt(np.mean(seg*seg))) if len(seg) else 0.0
    r0=max(rms(.18,.25),1e-12)
    r1=max(rms(.55,.65),1e-12)
    drop=20*np.log10(r1/r0)
    if drop < -14: return .350,round(float(drop),2)
    if drop < -8: return .450,round(float(drop),2)
    return .650,round(float(drop),2)


def parse_row(inst, entry, src):
    label=note_from_name(entry['name'])
    # VCSL's written note is an octave below the acoustical bar/chime pitch.
    # Independent source checks found e.g. marimba B2 at 247 Hz (B3), hand
    # chime A#3 at 467 Hz (A#4), and vibraphone G3 at 392 Hz (G4). Keep the
    # filename token as provenance and map the original sample to its measured
    # sounding octave; the spectra themselves remain untouched.
    root=midi(label)+12
    dyn,art,take=dyn_and_art(inst,entry)
    audit=pitch_audit(src,label)
    # VCSL note labels are the documented musical roots. Inharmonic component
    # peaks are kept intact; no FFT peak is promoted to a false f0.
    audit['playback_root_midi']=root
    audit['source_written_label_offset_semitones']=-12
    return {'entry':entry,'src':src,'label':label,'root':root,'dyn':dyn,'art':art,'take':take,'audit':audit}


def build_sources(inst, items, commit):
    dest=BANK/inst['slug']; samples=dest/'samples'; body=samples/'body';body.mkdir(parents=True,exist_ok=True)
    rows=[]; regions=[]; continuations=[]
    for entry,src in items:
        row=parse_row(inst,entry,src)
        dyn,art,take=row['dyn'],row['art'],row['take']
        audio_name=Path(entry['name']).stem+'.body.wav'
        transition,drop=transition_for(src)
        loop,cont=derive_source_body(src,body/audio_name,row['root'],period=6.0,
                                     transition_end=transition)
        cont.update({'source_file':entry['path'],'source_note':row['label'],
                     'transition_end_seconds':transition,'source_decay_drop_db_180_650':drop})
        continuations.append(cont)
        region={'file':f'body/{audio_name}','root':row['root'],'take':0,
                'tune_cents':0.0,'loop':loop}
        region_gain=LAYER_GAIN.get(inst['kind'],{}).get(dyn,0.0)
        if inst['kind']=='marimba' and row['label'] in ('F5','C6') and dyn=='soft':
            region_gain=6.0
        if art=='bowed': region_gain=LAYER_GAIN['vibraphone']['bowed']
        if region_gain: region['gain_db']=region_gain
        if dyn:
            region['vel']=DYN_VEL[dyn]
        else:
            region['vel']=[1,127]
        if art:region['articulation']=art
        regions.append(region)
        measured=row['audit']
        recorded={'file':f'src/{src.name}','source_path':entry['path'],
                  'download_url':entry.get('download_url'), 'source_note_label':row['label'],
                  'source_root_midi':row['root'],'dynamic_label':dyn,'articulation':art,
                  'filename_take_label':take or None,'runtime_take_index':0,
                  'byte_size':entry['size'],'github_blob_sha':entry['sha'],'git_commit':commit,
                  'license':'CC0 1.0','license_class':'cc0',**measured}
        recorded['playback_root_midi']=row['root']
        recorded['region_gain_db']=region_gain
        rows.append(recorded)
    (samples/'provenance.json').write_text(json.dumps(rows,indent=2)+'\n')
    (samples/'map.json').write_text(json.dumps({'body':regions},indent=2)+'\n')
    (samples/'infinite-provenance.json').write_text(json.dumps(continuations,indent=2)+'\n')
    (samples/'credits.json').write_text(json.dumps([{
        'source':'Versilian Community Sample Library (VCSL), '+inst['folder'].name,
        'author':'Versilian Studios / Sam Gossner','license':'CC0 1.0','license_class':'cc0',
        'url':'https://github.com/sgossner/VCSL','license_url':'https://raw.githubusercontent.com/sgossner/VCSL/master/LICENSE',
        'source_commit':commit,'retrieved':datetime.now(timezone.utc).date().isoformat(),
        'notes':f"Complete original WAV folder preserved in samples/src/ ({len(rows)} files); every file is mapped to a key zone and processed into its own source-led body. See provenance.json and infinite-provenance.json for per-recording hashes, measurements, source path and continuation details."
    }],indent=2)+'\n')
    return rows,regions


def derive_source_body(src_path:Path,dest:Path,root:int,period:float=6.0,transition_end:float=.650):
    # Reuse the audited source-phase/modal continuation implementation from the
    # Aria mechanical builder. It preserves the original attack and aligns the
    # first sustain cycle to the same absolute source timeline.
    global _MECH_BUILDER
    if _MECH_BUILDER is None:
        import importlib.util
        spec=importlib.util.spec_from_file_location('aria_mechanical_builder', ROOT/'python/scripts/build_aria_mechanical.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        _MECH_BUILDER=module
    return _MECH_BUILDER.derive_source_body(src_path,dest,root,period,transition_end)


_MECH_BUILDER=None


def figure(inst):
    # House figure: transparent SVG, currentColor linework, ivory body and gold
    # accent. Each icon names a different physical excitation and resonator.
    base='''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#302a32" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">\n'''
    gold='#b8924f'; ivory='#f3eee6'
    drawings={
    'marimba':f'''<path d="M82 240L430 205L435 235L86 270Z" fill="{ivory}" stroke-width="1.3"/><path d="M99 237L104 211L153 206L150 232ZM157 231L161 205L210 200L207 226ZM215 225L219 199L268 194L265 220ZM273 219L277 193L326 188L323 214ZM331 213L335 187L384 182L381 208ZM389 207L393 181L426 178L423 203Z" fill="{ivory}" stroke-width="1.1"/><path d="M112 277Q126 326 140 274M179 270Q193 319 207 267M247 263Q261 312 275 260M315 256Q329 305 343 253M383 249Q397 298 411 246" stroke-width=".9"/><path d="M155 359L213 251M256 351L256 246M357 343L299 241" stroke-width="1.1"/><circle cx="214" cy="252" r="9" fill="{gold}" stroke-width=".9"/><path d="M90 385H422M118 397H394" stroke-width=".75"/>''',
    'vibraphone':f'''<path d="M94 238H418L409 267H103Z" fill="{ivory}" stroke-width="1.3"/><path d="M110 230V200H151V230M161 230V194H202V230M212 230V189H253V230M263 230V194H304V230M314 230V200H355V230M365 230V205H406V230" fill="{ivory}" stroke-width="1"/><path d="M119 270V334Q119 351 136 351T153 334V272M176 270V344Q176 361 193 361T210 344V270M233 269V353Q233 370 250 370T267 353V269M290 268V344Q290 361 307 361T324 344V268M347 267V334Q347 351 364 351T381 334V267" stroke-width="1"/><path d="M128 378Q254 399 380 378M147 386Q254 404 361 386" stroke-width=".7"/><path d="M179 173L214 217M333 165L298 214" stroke="{gold}" stroke-width="1.3"/><circle cx="214" cy="218" r="7" fill="{gold}" stroke-width="1"/><circle cx="298" cy="215" r="7" fill="{gold}" stroke-width="1"/>''',
    'handchimes':f'''<path d="M105 149H121V288L113 305L105 288ZM163 130H179V288L171 305L163 288ZM221 115H237V288L229 305L221 288ZM279 128H295V288L287 305L279 288ZM337 146H353V288L345 305L337 288ZM395 163H411V288L403 305L395 288Z" fill="{ivory}" stroke-width=".85"/><path d="M113 149V310M171 130V310M229 115V310M287 128V310M345 146V310M403 163V310" stroke-width="1.2"/><path d="M98 310Q113 329 128 310M156 310Q171 329 186 310M214 310Q229 329 244 310M272 310Q287 329 302 310M330 310Q345 329 360 310M388 310Q403 329 418 310" stroke-width="1.1"/><path d="M92 125H424M101 135H415M112 145H404" stroke-width=".6"/><path d="M113 149V277M171 130V277M229 115V277M287 128V277M345 146V277M403 163V277" stroke="{gold}" stroke-width=".75"/><path d="M89 110Q256 74 427 110M111 96Q256 62 406 96" stroke-width=".8"/>''',
    'tubular':f'''<path d="M102 115H114V330H102ZM145 99H157V347H145ZM188 83H200V365H188ZM231 106H243V347H231ZM274 77H286V367H274ZM317 98H329V346H317ZM360 115H372V327H360ZM403 131H415V311H403Z" fill="{ivory}" stroke-width=".85"/><path d="M108 115V330M151 99V347M194 83V365M237 106V347M280 77V367M323 98V346M366 115V327M409 131V311" stroke-width="2.4"/><path d="M108 115V314M151 99V331M194 83V349M237 106V331M280 77V351M323 98V330M366 115V311M409 131V295" stroke="{gold}" stroke-width=".65"/><path d="M95 114H422M95 330H422M95 349H422" stroke-width="1.1"/><path d="M91 359L109 329M419 359L401 329M91 359H419" stroke-width="1.1"/><path d="M194 80V49M183 49H205M280 74V44M269 44H291" stroke-width="1"/>'''
    }
    return base+f'<title>{inst["title"]}</title>\n'+drawings[inst['kind']]+'\n</svg>\n'


def description(inst, rows):
    k=inst['kind']
    if k=='marimba': return 'Barre di marimba VCSL registrate a tre dinamiche reali, dal registro grave al brillante. Il colpo e le risonanze di legno restano riconoscibili; la continuazione di ogni nota si appoggia alle componenti della stessa registrazione, mantenendo corpo anche sui tasti tenuti. Mazze morbide e peso caldo per temi, accordi e raddoppi.'
    if k=='vibraphone': return 'Vibrafono VCSL suonato con mazze morbide e dure, più una vera articolazione ad arco. Le barre metalliche, il vibrato e il modo d’attacco vengono dai campioni; le dinamiche registrate restano distinte. La continuazione source-led mantiene il corpo quando la nota è tenuta.'
    if k=='handchimes': return 'Campane manuali VCSL registrate nota per nota. Il gesto d’attacco e la risonanza irregolare di ogni tubo rimangono nel suono; la coda continua usa componenti misurate nella stessa presa. Una voce melodica luminosa, con centro stabile e spazio sobrio.'
    return 'Campane tubolari VCSL con dinamiche registrate e le varianti nominate nel sorgente conservate. Ogni tubo mantiene la propria distribuzione modale inarmonica; dopo il colpo reale, la continuazione misurata sostiene l’accordo senza coprire il corpo metallico.'


def emit(inst, rows):
    slug=inst['slug'];dest=BANK/slug;samples=dest/'samples'
    roots=sorted({r['playback_root_midi'] for r in rows})
    kind=inst['kind']
    has_dyn=any(r['dynamic_label'] for r in rows)
    arts=[]
    if kind=='vibraphone': arts=[{'id':'soft','name':'Mazza morbida','key':None},{'id':'hard','name':'Mazza dura','key':None},{'id':'bowed','name':'Arco','key':None}]
    (dest/'figure.svg').write_text(figure(inst))
    (dest/'sound.py').write_text(f'''import json
from pathlib import Path
from libero import Sound
ROOTS={roots!r}
REGIONS=json.loads((Path(__file__).parent/'samples'/'map.json').read_text())['body']
sound=Sound(title={inst['title']!r},subtitle={inst['subtitle']!r},
 tags=['aria','sampled','mallet','acoustic','melody'],roots=ROOTS,
 velocities={[24,56,88,116] if has_dyn else [88]!r},sample_rate=48000,takes=1)
{'sound.articulations('+repr(arts)+')' if arts else ''}
sound.multisample('body',REGIONS,
 process={{'pre_ms':0,'align_ms':0,'tune':'source','ladder':'keep','peak_db':-12,
          'max_seconds':None,'end_db':-100,'fade_ms':0,'loop':'source','encoding':'flac24','mono':True}},
 as_dyn={has_dyn!r})
sound.performance(dynamics_source='velocity',velocity_curve=0.9,dyn_crossfade=0,
 rr_reset_ms=0,humanize={{'cents':0,'ms':0,'db':0}})
sound.defaults(mode='Poli',voices=24,glide=0,master=-3,
 amp_attack=0,amp_decay=1,amp_sustain=1,amp_release={1100 if kind in ('handchimes','tubular') else 650},
 lvl_body=0,lvl_attack=-60,lvl_tail=-60,lvl_air=-60,
 osc1_level=-60,osc2_level=-60,sub_level=-60,flt_cutoff=20000,flt_reso=0,flt_env=0,
 drive=0,tape_wow=0,tape_flutter=0,tape_sat=0,tape_age=0,tape_mix=0,
 lfo_pitch=0,lfo_amp=0,res_mix=0,echo_mix=0,rev_mix=0,rev_shimmer=0,rev_mode='Cappella')
''')
    descriptions=description(inst,rows)
    pitch_note={
      'marimba':'Le etichette VCSL sono scritte un’ottava sotto il suono reale: per esempio B2 ha una componente fondamentale misurata intorno a247Hz, cioè B3. Le radici di playback sono quindi label MIDI +12; il tracker e i modi alti restano diagnostici, non sostituiscono la misura.',
      'vibraphone':'Le etichette VCSL delle mazze sono scritte un’ottava sotto il suono reale; le radici di playback sono label MIDI +12. L’arco può produrre una famiglia modale con YIN agganciato a una subarmonica (A2: 2354Hz dominante, YIN circa293Hz), perciò non si ribattezza la radice usando un singolo modo.',
      'handchimes':'Le etichette VCSL delle campane manuali sono scritte un’ottava sotto il suono reale; per esempio A#3 ha una componente fondamentale intorno a467Hz, cioè A#4. Le radici mappate sono label MIDI +12, senza correggere le relazioni modali originali.',
      'tubular':'Le etichette VCSL sono scritte un’ottava sotto il registro acustico verificato: per esempio A#3 presenta un modo forte vicino a936Hz, compatibile con la famiglia del suono A#4 e la convenzione strumentale. Le radici sono label MIDI +12; si conserva la distribuzione inarmonica.'
    }[inst['kind']]
    gain_note={
      'marimba':'Gain +6 dB soltanto alle prese soft di F5 e C6: nel sorgente originale erano 40–46 dB più basse delle prese loud e cadevano sotto la soglia di silenzio del player. Le altre prese restano a gain originale; forme d’onda e ordine dinamico sono preservati.',
      'vibraphone':'Gain uniforme +30 dB all’articolazione bowed, perché le registrazioni ad arco sono molto più basse delle mazze. I livelli originali e le forme d’onda restano misurabili nel provenance; nessuna dinamica o presa è stata inventata.',
      'handchimes':'Una registrazione per radice, senza dinamiche o round robin dichiarati; le differenze di livello sono quelle effettivamente registrate.',
      'tubular':'I passaggi pp/p/f/ff/fff e gli indici RR restano etichettati dal nome originale; non sono prese intercambiabili aggiuntive se non esiste una seconda presa per la stessa nota e dinamica.'
    }[inst['kind']]
    (dest/'notes.md').write_text(f'''# {inst['title']}

{descriptions}

## Costruzione e provenienza

Route HYB. Le registrazioni VCSL originali complete sono conservate in `samples/src/`; `provenance.json` elenca ogni WAV incluso, SHA-256, commit sorgente, nota, dinamica/articolazione e misure. Licenza CC0 1.0, link e commit in `samples/credits.json`. Sono inclusi tutti i file WAV della cartella dello strumento. Nessun RR è inventato: gli indici `rr` originali, quando presenti, sono registrati come etichette della sorgente; vengono usati come round robin soltanto se esiste più di una presa per la stessa nota/dinamica. Le dinamiche originali e gli archi/mazze sono mappati separatamente.

{pitch_note}

{gain_note}

Il corpo mantiene l’attacco registrato per 180 ms, poi si raccorda alla continuazione con fasi e rapporti misurati dalla stessa presa; i dettagli della coda inarmonica non vengono forzati su una griglia ideale. L’intervallo d’analisi è .040–.300 s dall’attacco. `infinite-provenance.json` documenta finestra, componenti, livello, durata del raccordo per decadimento e ciclo esplicito. L’infinito è una continuazione progettata, non il comportamento naturale del colpo acustico. Nessuna saturazione, wow/flutter, chorus o riverbero è incorporato; modalità poli, glide zero, livello contenuto per gli accordi.

## Prove

Figure, frase con ribattute/dinamiche, accordo, note tenute, release e analisi sono in `~/Libero/demo/aria-expansion-mallets/`. Report finale in `~/Libero/demo/aria-expansion-mallets/report.json`. I controlli numerici verificano compilazione, lint, loop, livelli e durata; non sostituiscono l’ascolto musicale.
''')


def qa(inst, rows):
    slug=inst['slug'];dest=BANK/slug
    comp=compile_sound(dest)
    if not comp.ok: raise RuntimeError(f'compile failed {slug}: {comp.text()}')
    lint=lint_bundle(dest/'build')
    warnings=[x.line() for x in lint]
    warning_lines=[x for x in warnings if x.startswith('WARN')]
    roots=sorted({r['playback_root_midi'] for r in rows})
    target=60
    root=min(roots,key=lambda x:abs(x-target))
    held=render.preview(slug,f'{root}:0:60:100',tail=2)
    shutil.copy2(held.wav,DEMO/f'{slug}-held-60s.wav')
    seq=[root,min(roots[-1],root+3),min(roots[-1],root+7),min(roots[-1],root+10),root]
    phrase_spec=','.join(f'{n}:{i*.48:.3f}:.34:{v}' for i,(n,v) in enumerate(zip(seq,[42,72,105,118,86])))
    phrase=render.preview(slug,phrase_spec,tail=2);shutil.copy2(phrase.wav,DEMO/f'{slug}-phrase.wav')
    chordnotes=sorted(set([root,min(roots[-1],root+4),min(roots[-1],root+7),min(roots[-1],root+11)]))
    chord=render.preview(slug,','.join(f'{n}:0:4:100' for n in chordnotes),tail=1)
    shutil.copy2(chord.wav,DEMO/f'{slug}-chord.wav')
    # Lowest/highest register probes and a repeated-note sample.
    edge=render.preview(slug,f'{roots[0]}:0:2:100,{roots[-1]}:2.1:2:100',tail=1)
    shutil.copy2(edge.wav,DEMO/f'{slug}-register-edges.wav')
    repeat=render.preview(slug,','.join(f'{root}:{i*.22:.16}:100' for i in range(6)),tail=1)
    shutil.copy2(repeat.wav,DEMO/f'{slug}-repeated.wav')
    manifest=json.loads((dest/'build'/'manifest.json').read_text())
    zones=manifest.get('zones',[])
    cont=json.loads((dest/'samples'/'infinite-provenance.json').read_text())
    x=held.audio.to_mono().data;sr=held.audio.sr
    rms=[]
    for t in range(60):
        seg=x[t*sr:(t+1)*sr]
        rms.append(round(20*np.log10(np.sqrt(np.mean(seg*seg))+1e-12),2))
    reasons={
      'marimba':'Le fasce soft/med/loud sono livelli originali con una sola presa per tasto: gli scarti >10 dB sono conservati perché appartengono alle registrazioni. I 1.5–2.7 ms di onset sono differenze del gesto acquisito, non un taglio di attacco; l’allineamento è disattivato. I salti di livello fra tasti provengono da prese singole, non da duplicati o round robin.',
      'vibraphone':'Le soglie di livello e brillantezza descrivono differenze delle prese reali tra mazze soft/hard e arco; non sono state appiattite con copie sintetiche. Gli onset entro 1.7 ms restano naturali con allineamento zero. Il picco sopra 18 kHz a −26 dB nella presa ad arco A2 è presente nell’attacco originale ed è lasciato intatto; i salti tra tasti sono misure di prese singole.',
      'handchimes':'Ogni radice ha una sola presa senza livelli dinamici o round robin. I salti di livello fra note sono dunque differenze di esecuzione registrate; nessuna normalizzazione per tasto è applicata.',
      'tubular':'Gli scarti >10 dB sono i livelli reali pp/p/f/ff/fff della raccolta, con coverage sparsa per nota. Non li ho compressi per far apparire una scala più uniforme; i piccoli salti fra note sono presi singoli.'
    }[inst['kind']]
    note_path=dest/'notes.md'
    note_path.write_text(note_path.read_text()+"\n## Lint e avvisi conservati\n\n"+
        ("\n".join(f"- `{w}`" for w in warning_lines) if warning_lines else "Nessun WARN." )+
        f"\n\n{reasons} Tutti i quattro preset compilano con 0 FAIL.\n")
    return {'slug':slug,'compile':'ok','lint':warnings,'warnings_explained':warning_lines,
            'source_count':len(rows),
            'body_regions':len(zones),'explicit_loops':sum(bool(z.get('loop')) for z in zones),
            'roots_midi':roots,'test_root_midi':root,'lowest_highest_midi':[roots[0],roots[-1]],
            'held_duration_s':round(held.audio.duration,3),'held_peak_dbfs':round(held.audio.peak_db,2),
            'held_rms_dbfs_1s':rms,'phrase_peak_dbfs':round(phrase.audio.peak_db,2),
            'chord_notes_midi':chordnotes,'chord_peak_dbfs':round(chord.audio.peak_db,2),
            'edge_peak_dbfs':round(edge.audio.peak_db,2),'repeat_peak_dbfs':round(repeat.audio.peak_db,2),
            'max_loop_seam_db_20ms':max(c['loop_seam_db_20ms'] for c in cont),
            'min_component_count':min(c['measured_component_count'] for c in cont),
            'max_component_count':max(c['measured_component_count'] for c in cont),
            'join_end_seconds':sorted({c['transition_end_seconds'] for c in cont}),
            'generated_utc':datetime.now(timezone.utc).isoformat()}


def main():
    commit=get_repo_commit()
    report={'generated_utc':datetime.now(timezone.utc).isoformat(),'vcsl_commit':commit,'voices':[]}
    for inst in INSTRUMENTS:
        dest,items=import_source(inst,commit)
        rows,regions=build_sources(inst,items,commit)
        emit(inst,rows)
        item=qa(inst,rows)
        report['voices'].append(item)
        (DEMO/'report.json').write_text(json.dumps(report,indent=2,default=lambda x: x.item() if isinstance(x,np.generic) else str(x))+'\n')
        print(inst['slug'],f"sources={len(rows)} loops={item['explicit_loops']} lint={len(item['lint'])}",flush=True)
    print(f'Report: {DEMO/"report.json"}',flush=True)

if __name__=='__main__': main()
