"""Final structural snapshot of the 24 Giove programmes; native QA is separate."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'python'))
from libero import library
from libero.figure import validate_svg
from libero.lint import lint_bundle

BANK = Path.home() / 'Libero/banks/giove'
OUT = Path.home() / 'Libero/demo/giove-v1/bank-integrity.json'
LEGATO = {'theremin-vetro', 'theremin-ambra', 'trautonium-due-formanti',
          'volkstrautonium-manuale', 'mixturtrautonium-quarta-aperta',
          'mixturtrautonium-frange'}


def main():
    folders = sorted(p for p in BANK.iterdir() if p.is_dir() and (p/'sound.py').exists())
    errors = []
    rows = []
    if len(folders) != 24:
        errors.append(f'Expected 24 programmes, found {len(folders)}')
    for p in folders:
        local = library.validate_bundle(p/'build')
        manifest = json.loads((p/'build/manifest.json').read_text())
        params = manifest['params']
        fresh = library.source_hash(p) == manifest['source_hash']
        if not fresh:
            local.append('Source hash is stale')
        findings = lint_bundle(p/'build')
        local.extend(str(f) for f in findings if f.level == 'FAIL')
        figure = p/'figure.svg'
        local.extend(validate_svg(figure.read_text()) if figure.exists() else ['Missing figure'])
        if p.name in LEGATO:
            if params.get('mode') != 'Legato' or params.get('voices') != 1:
                local.append('Continuous instruments require default monophonic Legato')
            if params.get('lfo_delay') != 350 or not 0 < params.get('glide', 0) <= 2000:
                local.append('Expected delayed vibrato and adjustable glide default')
        elif params.get('mode') != 'Poli' or params.get('glide') != 0:
            local.append('Other programmes require default Poli and zero glide')
        if params.get('tape_wow', 0) or params.get('tape_flutter', 0):
            local.append('Unexpected automatic wow/flutter')
        if params.get('caldi_mode', 'Spento') != 'Spento':
            local.append('Unexpected default Caldi stack')
        main_zones = [z for z in manifest['zones']
                      if z.get('layer') == 'body' and not z.get('one_shot')]
        if any(not z.get('loop') for z in main_zones):
            local.append('A main sustained body zone has no loop')
        coverage = []
        if p.name.startswith('marble-'):
            lo = min(z['lo'] for z in manifest['zones'])
            hi = max(z['hi'] for z in manifest['zones'])
            for art in manifest.get('articulations', []):
                zones = [z for z in manifest['zones'] if z.get('articulation') == art['id']]
                for key in range(lo, hi+1):
                    intervals = sorted(z.get('dyn', [0.0, 1.0]) for z in zones if z['lo'] <= key <= z['hi'])
                    end = 0.0
                    gap = not intervals
                    for a, b in intervals:
                        if a > end+1e-5:
                            gap = True
                        end = max(end, b)
                    if gap or end < 1.0-1e-5:
                        coverage.append(dict(articulation=art['id'], key=key, intervals=intervals))
            if coverage:
                local.append(f'{len(coverage)} articulation/key cells have incomplete dynamics coverage')
        row = dict(slug=p.name, title=manifest['title'], fresh=fresh,
                   source_hash=manifest['source_hash'], zones=len(manifest['zones']),
                   mode=params.get('mode'), glide_ms=params.get('glide'),
                   runtime_bytes=sum(f.stat().st_size for f in (p/'build').rglob('*') if f.is_file()),
                   lint_warn=sum(f.level == 'WARN' for f in findings),
                   incomplete_dynamic_cells=coverage, errors=local)
        rows.append(row)
        errors.extend(f'{p.name}: {e}' for e in local)
    result = dict(status='PASS' if not errors else 'FAIL', programmes=len(rows),
                  runtime_bytes=sum(r['runtime_bytes'] for r in rows),
                  presets=rows, errors=errors,
                  limits='Structural freshness, defaults, loops and figures only. Consult native hold, pitch, legato and headroom reports; this does not certify realism or listener preference.')
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
    print(json.dumps({k: result[k] for k in ('status', 'programmes', 'runtime_bytes', 'errors')}, indent=2))
    return bool(errors)


if __name__ == '__main__':
    raise SystemExit(main())
