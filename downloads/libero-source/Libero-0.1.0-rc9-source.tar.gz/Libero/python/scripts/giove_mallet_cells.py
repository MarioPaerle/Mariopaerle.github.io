"""Pure pitch-cell tiling for sampled Giove mallet regions.

`common_cells` retains each source row's root, file, take, tuning and all other
metadata. It only writes common `lo`/`hi` bounds to copies of rows selected by
nearest-source lookup. Within each articulation, all velocity layers share the
same contiguous key-cell boundaries whenever the source-per-layer tuple changes.
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from typing import Any, Iterable, Mapping

Row = Mapping[str, Any]


def _velocity_interval(row: Row) -> tuple[int, int]:
    value = row.get("vel", row.get("velocity"))
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError(f"row needs a two-endpoint vel interval: {row!r}")
    lo, hi = int(value[0]), int(value[1])
    if not 0 <= lo <= hi <= 127:
        raise ValueError(f"invalid MIDI velocity interval {value!r}")
    return lo, hi


def _root(row: Row) -> int:
    try:
        return int(row["root"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"row needs an integer root: {row!r}") from exc


def common_cells(rows: Iterable[Row], low: int, high: int) -> list[dict[str, Any]]:
    """Return copied source rows tiled into common nearest-source key cells.

    For each articulation and each distinct real velocity interval represented
    in the input, each key in ``low..high`` selects the source root with minimum
    absolute distance. Equal-distance roots resolve to the lower root. All
    rows at that chosen root are retained, preserving genuine takes/round robins.

    Keys are then grouped into maximal contiguous runs with the same tuple of
    selected source rows, ordered by velocity interval. Each selected row copy
    gets that run's identical ``lo`` and ``hi``. Missing a velocity layer at a
    key is represented as ``None`` during grouping; no source is invented and
    uncovered cells stay uncovered. Original input rows and nested values are
    never mutated; source roots, files, takes, tunes and velocity ranges remain
    exactly as supplied.
    """
    low, high = int(low), int(high)
    if not 0 <= low <= high <= 127:
        raise ValueError(f"invalid key range {low}..{high}")

    source_rows = [deepcopy(dict(row)) for row in rows]
    if not source_rows:
        return []

    groups: dict[tuple[Any, tuple[int, int]], list[int]] = defaultdict(list)
    roots: dict[int, int] = {}
    for index, row in enumerate(source_rows):
        if "articulation" not in row:
            raise ValueError(f"row needs an articulation: {row!r}")
        art = row["articulation"]
        try:
            hash(art)
        except TypeError as exc:
            raise ValueError(f"articulation must be hashable: {art!r}") from exc
        interval = _velocity_interval(row)
        roots[index] = _root(row)
        groups[(art, interval)].append(index)

    by_art: dict[Any, list[tuple[int, int]]] = defaultdict(list)
    for art, interval in groups:
        by_art[art].append(interval)
    for art in by_art:
        by_art[art] = sorted(set(by_art[art]))

    result: list[dict[str, Any]] = []
    for art in sorted(by_art, key=lambda value: str(value)):
        intervals = by_art[art]
        selected_by_key: list[tuple[tuple[int, ...] | None, ...]] = []
        for key in range(low, high + 1):
            layers: list[tuple[int, ...] | None] = []
            for interval in intervals:
                candidates = groups.get((art, interval), [])
                if not candidates:
                    layers.append(None)
                    continue
                nearest_root = min((roots[index] for index in candidates),
                                   key=lambda source_root: (abs(source_root - key), source_root))
                selected = tuple(index for index in candidates if roots[index] == nearest_root)
                layers.append(selected or None)
            selected_by_key.append(tuple(layers))

        run_start = low
        current = selected_by_key[0]
        for offset in range(1, len(selected_by_key) + 1):
            if offset < len(selected_by_key) and selected_by_key[offset] == current:
                continue
            run_end = low + offset - 1
            for layer in current:
                if layer is None:
                    continue
                for index in layer:
                    copied = dict(source_rows[index])
                    copied["lo"] = run_start
                    copied["hi"] = run_end
                    result.append(copied)
            if offset < len(selected_by_key):
                run_start = low + offset
                current = selected_by_key[offset]

    return result
