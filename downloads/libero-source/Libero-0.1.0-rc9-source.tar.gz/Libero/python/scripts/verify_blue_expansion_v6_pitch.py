"""Native default-articulation root/cell pitch checks for the six Blue additions."""
from pathlib import Path
import argparse,json,sys,numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'python'))
from libero import render,Audio,library
from calibrate_blue_v6_body import estimate
OUT=Path.home()/'Libero/demo/blue-v6';slugs=['prime-zither-blue','nylon-blue','chemnitzer-blue','banjo-blue','clavinet-blue','blues-formant-blue']
parser=argparse.ArgumentParser();parser.add_argument('--slugs',nargs='+',choices=slugs);args=parser.parse_args();selected=args.slugs or slugs
previous=json.loads((OUT/'native-pitch-audit.json').read_text())if args.slugs and (OUT/'native-pitch-audit.json').exists()else {'voices':[],'errors':[]}
reports=[r for r in previous['voices']if r['slug']not in selected];errors=[r for r in previous['errors']if r['slug']not in selected]
for slug in selected:
 p=library.find_sound(slug);m=json.loads((p/'build/manifest.json').read_text());arts=m.get('articulations',[]);a=arts[0]['id']if arts else None
 body=[z for z in m['zones']if z['layer']=='body' and (a is None or z.get('articulation')==a)]
 keys=sorted({k for z in body for k in [z['root'],z['lo'],z['hi']]if 28<=k<=96})
 notes=[(k,i*1.8,1.6,v)for i,(k,v)in enumerate((k,v)for k in keys for v in [50,110])];f=OUT/(slug+'-pitch-cells.wav')
 render.render(p,f,notes,{'rev_mix':0,'amp_attack':2,'amp_release':3,'lvl_tail':-60},tail=.1);audio=Audio.load(f);x=audio.data.astype(float);x=x.mean(1)if x.ndim>1 else x;rows=[]
 for k,start,dur,v in notes:
  seg=x[round((start+1.00)*audio.sr):round((start+1.50)*audio.sr)];expected=440*2**((k-69)/12);freq,cents=estimate(seg[:,None],audio.sr,expected);rows.append({'key':k,'velocity':v,'cents':cents})
 worst=max(abs(r['cents'])for r in rows);limit=8 if slug in ['clavinet-blue','blues-formant-blue']else 15
 failed=[r for r in rows if abs(r['cents'])>limit]
 if failed:errors.append({'slug':slug,'limit_cents':limit,'notes':failed})
 reports.append({'slug':slug,'default_articulation':a,'notes':rows,'max_abs_cents':worst,'source_fresh':m['source_hash']==library.source_hash(p)});print(slug,round(worst,3),len(failed),flush=True)
(OUT/'native-pitch-audit.json').write_text(json.dumps({'voices':reports,'errors':errors,'limitations':'Checks fundamental neighbourhood after attack; unrecorded legato and per-note MPE are not inferred. Performance vibrato may exceed a static tuning tolerance.'},indent=2)+'\n')
if errors:raise SystemExit(1)
