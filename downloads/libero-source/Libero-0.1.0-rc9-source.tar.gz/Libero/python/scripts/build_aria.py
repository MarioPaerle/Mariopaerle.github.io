#!/usr/bin/env python3
"""Rebuild the Aria designed-hybrid bank from CC0 source recordings.

Run with python/.venv/bin/python python/scripts/build_aria.py. Source recordings are
read from ~/Libero/cache/libraries; the Commons transient is downloaded to that
cache on first use. Compiled bundles retain the derived sound, while provenance
and reproducible source paths remain in each sound's notes and credits.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PYTHON = ROOT / "python"
sys.path.insert(0, str(PYTHON))
from libero.library import home  # noqa: E402

LIBERO = home()
BANK = LIBERO / "banks" / "aria"
CACHE = LIBERO / "cache" / "libraries"
RETRIEVED = "2026-10-02"

SOURCES = {
    "string_cyborgs": {
        "source": "Karoryfer String Cyborgs", "author": "Karoryfer",
        "license": "CC0 1.0", "license_class": "cc0",
        "url": "https://github.com/sfzinstruments/karoryfer.string-cyborgs",
    },
    "squidpipes": {
        "source": "Karoryfer Squidpipes", "author": "Karoryfer",
        "license": "CC0 1.0", "license_class": "cc0",
        "url": "https://github.com/sfzinstruments/karoryfer.squidpipes",
    },
    "war_tuba": {
        "source": "Karoryfer War Tuba", "author": "Karoryfer",
        "license": "CC0 1.0", "license_class": "cc0",
        "url": "https://github.com/sfzinstruments/karoryfer.war-tuba",
    },
    "commons_metal": {
        "source": "Fake Metal Bat.wav", "author": "Shawn Eary",
        "license": "CC0 1.0", "license_class": "cc0",
        "url": "https://commons.wikimedia.org/wiki/File:Fake_Metal_Bat.wav",
    },
}

SOUND = [
    dict(slug="ferro-angelico", title="Ferro Angelico", subtitle="coro di corde ferrose, attacco lento",
         kind="pad", source="ironface/a4_single_cycle.wav", source_id="string_cyborgs", f0=440.0,
         style="iron", accent="#a64b38", attack=None,
         desc="A compact iron choir built from a Karoryfer String Cyborg cycle, widened by a fifth and an octave.",
         note="Three stable tones give the pad its width; a slow live envelope keeps chord changes clear."),
    dict(slug="fiato-rosso", title="Fiato Rosso", subtitle="ancia doppia, quinto luminoso",
         kind="pad", source="long_clean/a4_long_clean.wav", source_id="squidpipes", f0=220.0,
         style="reed", accent="#be6a30", attack=None,
         desc="A reed table from the long clean Squidpipes recording anchors a warm fifth and a thin upper reed.",
         note="The pipe recording is the main exciter; the added fifth adds a clear melodic color without a sub layer."),
    dict(slug="corno-di-vetro", title="Corno di Vetro", subtitle="ottone respirato, armonici rifratti",
         kind="pad", source="a1_sus_dyn.wav", source_id="war_tuba", f0=110.0,
         style="brass", accent="#8d6642", attack=None,
         desc="The War Tuba sustain is recast as a spectral table, with a bright third and a high glass partial above it.",
         note="A low brass recording supplies the body color; the added partials and high-pass keep the result out of bass territory."),
    dict(slug="ferrite-luce", title="Ferrite Luce", subtitle="risonanze diseguali, alone metallico",
         kind="pad", source="fake-metal-bat.wav", source_id="commons_metal", f0=296.8,
         style="alloy", accent="#b0873b", attack=None,
         desc="The CC0 metal strike contributes a rough moving window beneath six intentionally inharmonic synthetic modes.",
         note="The modal ratios avoid a conventional chord, while the narrow noise component adds a real struck surface."),
    dict(slug="ferro-corto", title="Ferro Corto", subtitle="placca elettrica, colpo compatto",
         kind="lead", source="blackheart/singlecycle_Eb3.wav", source_id="string_cyborgs", f0=155.56,
         style="clamp", accent="#a64b38", attack="metal-hit.wav",
         desc="A Blackheart string cycle drives a clipped PWM edge; the short metal strike supplies a focused front click.",
         note="Two tuned oscillator structures make a firm single-note hook; a fast decay leaves room for the next phrase."),
    dict(slug="squid-jab", title="Squid Jab", subtitle="ancia corta, risposta nervosa",
         kind="lead", source="short_clean/a4_short_clean_rr1.wav", source_id="squidpipes", f0=220.0,
         style="pipe", accent="#be6a30", attack="metal-hit.wav",
         desc="A short clean pipe note is converted to a moving reed table and joined by a tuned upper sine tooth.",
         note="The original pipe onset stays audible, while the digitally sharpened upper tone makes the sound cut through."),
    dict(slug="ottone-pugno", title="Ottone Pugno", subtitle="frase di tuba, forma di tromba",
         kind="lead", source="a1_sus_dyn.wav", source_id="war_tuba", f0=110.0,
         style="punch", accent="#8d6642", attack="metal-hit.wav",
         desc="A low War Tuba spectral table is reshaped into a compact brass stab with a fifth and a filtered square edge.",
         note="The live note stays stable and pitched; the synthetic edge makes it speak quickly without a sub-bass swell."),
    dict(slug="vetro-taglio", title="Vetro Taglio", subtitle="campana scheggiata, lama armonica",
         kind="lead", source="fake-metal-bat.wav", source_id="commons_metal", f0=296.8,
         style="shard", accent="#b0873b", attack="metal-hit.wav",
         desc="A stable sine/FM/bell oscillator stack with sparse inharmonic modes; the CC0 metal bat recording supplies only its short, focused front click.",
         note="A short, stable ring keeps the melody articulate; four partial ratios create a bright but uncluttered upper register."),
]

def _source_file(item: dict) -> Path:
    if item["source_id"] == "string_cyborgs":
        return CACHE / "karoryfer-string-cyborgs" / "Samples" / item["source"]
    if item["source_id"] == "squidpipes":
        return CACHE / "karoryfer-squidpipes" / "Samples" / item["source"]
    if item["source_id"] == "war_tuba":
        return CACHE / "karoryfer-war-tuba" / "Samples" / item["source"]
    target = CACHE / "aria-commons" / "fake-metal-bat.wav"
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        req = urllib.request.Request(
            "https://upload.wikimedia.org/wikipedia/commons/4/4c/Fake_Metal_Bat.wav",
            headers={"User-Agent": "Libero-Aria-Sound-Pack/1.0 (source attribution retained)"},
        )
        with urllib.request.urlopen(req, timeout=30) as response, target.open("wb") as f:
            shutil.copyfileobj(response, f)
    return target


def _recipe(item: dict, source_name: str) -> str:
    style = item["style"]
    is_pad = item["kind"] == "pad"
    shared = f'''from libero import Sound, Audio, forge
from libero.forge import Patch, Osc, Filter, Env, Noise, FX

sound = Sound(title={item['title']!r}, subtitle={item['subtitle']!r},
    tags={[item['kind'], 'melodic', 'hybrid', 'saturated']!r},
    roots=[48, 60, 72, 84], velocities=[100], dynamics=[0.15, 0.9], sample_rate=48000,
    accent={item['accent']!r})

SOURCE = {source_name!r}
F0 = {item['f0']!r}

def _table(ctx):
    a = ctx.load(SOURCE)
    if SOURCE.endswith('single_cycle.wav'):
        return forge.Wavetable.from_audio(a, frames=20, mode='cycle', f0=F0, t0=0.05, t1=min(a.duration, 2.8))
    if SOURCE == 'metal.wav':
        return forge.Wavetable.from_audio(a, frames=24, mode='window', t0=0.01, t1=min(a.duration, 0.46))
    return forge.Wavetable.from_audio(a, frames=24, mode='cycle', f0=F0, t0=0.18, t1=min(a.duration, 3.0))

'''
    configs = {
        "iron": '''
    p = Patch("ferro-angelico", oscs=[Osc(_table(ctx), level=0.78, pan=-0.12),
             Osc("tri", octave=1, level=0.22, pan=0.1), Osc("sine", octave=2, level=0.17, pan=-0.1)],
             filters=[Filter("lp24", cutoff=7800, res=0.13, drive=0.07)],
             envs=[Env(0.035, 0.4, 0.88, 0.12)], fx=[FX.Distortion("tube", drive=0.08, tone=7200, mix=0.18)], volume_db=-5.2)
''',
        "reed": '''
    p = Patch("fiato-rosso", oscs=[Osc(_table(ctx), level=0.72, pan=-0.12),
             Osc("saw", octave=1, level=0.19, warp1="pwm", warp1_amount=0.15), Osc("sine", octave=2, level=0.12)],
             filters=[Filter("formant", cutoff=1280, res=0.18, morph=0.24, drive=0.04),
                      Filter("lp24", cutoff=12000, res=0.02)], filter_routing="serial",
             envs=[Env(0.18, 0.45, 0.9, 0.18)], fx=[FX.Distortion("tube", drive=0.06, tone=6200, mix=0.12)], volume_db=-6.5)
''',
        "brass": '''
    p = Patch("corno-di-vetro", oscs=[Osc(_table(ctx), level=0.68, pan=-0.08),
             Osc("tri", octave=1, level=0.22), Osc("sine", octave=2, level=0.15)],
             filters=[Filter("hp12", cutoff=95, res=0.02), Filter("formant", cutoff=1550, res=0.15, morph=0.42)],
             filter_routing="serial", envs=[Env(0.24, 0.65, 0.86, 0.2)],
             fx=[FX.Distortion("tube", drive=0.07, tone=6500, mix=0.12)], volume_db=-7.0)
''',
        "alloy": '''
    p = Patch("ferrite-luce", oscs=[Osc(_table(ctx), level=0.55), Osc("tri", octave=1, level=0.2),
             Osc("sine", octave=2, level=0.12)],
             filters=[Filter("hp12", cutoff=180, res=0.01), Filter("lp24", cutoff=10500, res=0.16, drive=0.06)],
             filter_routing="serial", envs=[Env(0.42, 0.7, 0.9, 0.22)],
             fx=[FX.Distortion("tube", drive=0.05, tone=8000, mix=0.10)], volume_db=-6.2)
''',
        "clamp": '''
    p = Patch("ferro-corto", oscs=[Osc(_table(ctx), warp1="pwm", warp1_amount=0.18, unison=2, detune=0.035, spread=0.20, level=0.72),
             Osc("square", octave=1, level=0.20)],
             filters=[Filter("lp24", cutoff=4700, res=0.19, drive=0.08)],
             envs=[Env(0.008, 0.24, 0.63, 0.1)], fx=[FX.Distortion("tube", drive=0.12, tone=5600, mix=0.20)], volume_db=-5.8)
''',
        "pipe": '''
    p = Patch("squid-jab", oscs=[Osc(_table(ctx), warp1="bend+", warp1_amount=0.12, level=0.67),
             Osc("sine", octave=1, semi=7, level=0.22), Osc("square", semi=12, level=0.12)],
             filters=[Filter("formant", cutoff=1780, res=0.22, morph=0.30, drive=0.05)],
             envs=[Env(0.014, 0.28, 0.77, 0.13)], fx=[FX.Distortion("tube", drive=0.08, tone=6400, mix=0.14)], volume_db=-6.0)
''',
        "punch": '''
    p = Patch("ottone-pugno", oscs=[Osc(_table(ctx), unison=2, detune=0.035, spread=0.12, level=0.62),
             Osc("square", semi=7, level=0.18), Osc("saw", octave=1, level=0.16)],
             filters=[Filter("formant", cutoff=2200, res=0.18, morph=0.08, drive=0.08)],
             envs=[Env(0.012, 0.3, 0.68, 0.12)], fx=[FX.Distortion("tube", drive=0.11, tone=7200, mix=0.16)], volume_db=-7.0)
''',
        "shard": '''
    p = Patch("vetro-taglio", oscs=[Osc("sine", level=0.56), Osc("fm", octave=1, level=0.24),
             Osc("bell", octave=2, level=0.16)],
             filters=[Filter("hp12", cutoff=170, res=0.02), Filter("lp24", cutoff=11200, res=0.20, drive=0.06)],
             filter_routing="serial", envs=[Env(0.003, 0.31, 0.42, 0.11)],
             fx=[FX.Distortion("soft", drive=0.07, tone=9000, mix=0.14)], volume_db=-6.2)
''',
    }
    body_len = 5.2 if is_pad else 2.8
    return (shared + f'''@sound.body
def body(ctx):
{configs[style]}    for osc in p.oscs:
        osc.rand_phase = 0.0
    audio = p.render(ctx.note, velocity=ctx.velocity, duration={body_len}, sr=ctx.sr, seed=ctx.seed, tail=0.2).remove_dc().normalize_loudness(-21 + 7 * ctx.dyn, ceiling_db=-3)
    if ctx.dyn >= 0.5:
        shelf = 2500 if {style!r} == "alloy" else 3200
        lift = -4 if {style!r} == "alloy" else -6
        audio = audio + audio.highpass(shelf, order=2, zero_phase=True).gain_db(lift)
        audio = audio.normalize_loudness(-21 + 7 * ctx.dyn, ceiling_db=-3)
    return audio.remove_dc()

'''
        + ('''sound.loop(body=True, min_seconds=1.0, region=(0.35, 4.85))
''' if is_pad else "") + f'''sound.performance(dyn_crossfade=0)
sound.defaults(mode="Poli", glide=0, amp_attack={800 if is_pad else 5},
    amp_decay=1800, amp_sustain={0.92 if is_pad else 0.78}, amp_release={1600 if is_pad else 420},
    rev_mode="Cappella", rev_size=0.42, rev_decay=1.6, rev_predelay=8, rev_damp=0.62,
    rev_mix={0.10 if is_pad else 0.07}, lvl_attack=-10, lvl_air=-32,
    tape_wow=0, tape_flutter=0, tape_sat=0.06, drive=0.04, width=1.08, master=-4)
''')


def _figure(item: dict) -> str:
    title, slug = item["title"], item["slug"]
    color = "#b8924f"
    if item["style"] == "iron":
        shape = '<path d="M128 357 Q183 124 256 96 Q330 125 384 357 M156 350 L356 350 M172 300 L340 300 M190 250 L322 250 M211 200 L301 200"/><path d="M176 338 Q220 279 255 149 Q292 278 336 338" stroke-width="2"/><path d="M250 89 L262 89 L256 57Z" fill="#b8924f"/>'
    elif item["style"] == "reed":
        shape = '<path d="M252 420 C214 338 222 252 249 160 C268 94 264 78 256 62 C245 87 244 114 224 168 C192 257 188 350 222 420Z"/><path d="M240 374 C205 278 257 192 251 113 M265 370 C304 284 258 196 261 113 M210 335 Q252 302 300 336 M205 286 Q254 252 309 285 M219 226 Q253 206 291 225"/><path d="M254 151 Q311 113 354 128" stroke="#b8924f" stroke-width="3"/>'
    elif item["style"] == "brass":
        shape = '<path d="M175 371 L175 219 Q175 153 225 153 L270 153 Q314 153 314 202 L314 269 Q314 317 360 317 L360 371Z"/><path d="M185 357 L300 357 L300 267 Q300 208 266 208 L226 208 Q199 208 199 240 L199 292 M211 171 Q244 130 277 171 M330 299 Q354 266 378 299"/><path d="M178 340 L303 340 M178 326 L303 326 M178 312 L303 312"/><circle cx="255" cy="184" r="8" fill="#b8924f"/>'
    elif item["style"] == "alloy":
        shape = '<path d="M156 357 Q146 259 199 180 Q246 109 311 155 Q371 197 345 290 Q327 352 262 379 Q199 394 156 357Z"/><path d="M174 345 Q224 300 217 238 Q210 181 256 153 Q294 134 331 172 M183 362 Q242 328 247 275 Q250 218 299 192 M202 373 Q273 355 284 308 Q300 248 336 233"/><path d="M256 152 Q275 206 245 261 Q224 300 245 335" stroke="#b8924f" stroke-width="3"/>'
    elif item["style"] == "clamp":
        shape = '<path d="M145 334 L145 207 L203 207 L203 334 M309 334 L309 207 L367 207 L367 334 M145 255 L367 255 M145 286 L367 286"/><path d="M204 207 Q256 147 308 207 M203 334 Q256 374 309 334"/><path d="M240 207 L256 160 L272 207Z" fill="#b8924f"/>'
    elif item["style"] == "pipe":
        shape = '<path d="M209 402 Q209 325 243 263 L243 119 Q243 87 256 73 Q270 88 270 119 L270 263 Q304 325 304 402Z"/><path d="M223 379 L290 379 M226 351 L286 351 M232 322 L280 322 M245 211 L267 211 M245 183 L267 183 M245 155 L267 155"/><path d="M236 136 Q256 115 277 136" stroke="#b8924f" stroke-width="3"/>'
    elif item["style"] == "punch":
        shape = '<path d="M143 282 L231 282 L231 180 Q231 128 281 128 Q331 128 331 180 L331 282 L369 282 L369 332 L331 332 L331 365 L281 365 L281 332 L231 332 L231 365 L181 365 L181 332 L143 332Z"/><path d="M255 145 Q280 99 306 145 M247 174 L314 174 M247 198 L314 198 M247 222 L314 222 M247 246 L314 246"/><path d="M265 128 Q280 160 295 128" stroke="#b8924f" stroke-width="3"/>'
    else:
        shape = '<path d="M176 367 L236 197 L261 84 L282 197 L349 367 L278 330 L256 257 L231 330Z"/><path d="M193 354 L243 213 M319 354 L273 213 M231 330 L257 258 L278 330 M245 186 L275 186 M250 155 L270 155"/><path d="M257 84 L282 197 L261 197Z" fill="#b8924f"/>'
    hatch = '<path d="M175 389 l-18 24 M189 394 l-18 25 M203 397 l-18 25 M217 400 l-18 25 M231 403 l-18 24 M245 405 l-18 22" stroke-width="0.55"/>'
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
<title>{title}</title><desc>{item['desc']}</desc><g stroke-width="1.3">{shape}</g><g stroke-width="0.55">{hatch}<path d="M95 428 H417 M108 441 H404 M120 454 H392"/></g>
<path d="M255 418 L255 459 M246 450 L255 459 L264 450" stroke="{color}" stroke-width="2"/></svg>'''


def _notes(item: dict, source_name: str) -> str:
    meta = SOURCES[item["source_id"]]
    intros = {
        "ferro-angelico": "Un pad compatto di corde ferrose: il ciclo registrato si apre in un coro luminoso, con attacco lento e fondamentali controllate.",
        "fiato-rosso": "Un pad d’ancia caldo e luminoso, con quinte ariose e una risposta morbida che lascia leggibile la melodia.",
        "corno-di-vetro": "Un pad di ottone rifratto: la tuba registrata dà corpo agli armonici alti, senza accumulare energia nei bassi.",
        "ferrite-luce": "Un pad metallico dalle risonanze irregolari, costruito attorno a un colpo reale e a modi sintetici dissonanti.",
        "ferro-corto": "Una voce melodica corta e incisiva, con una placca di metallo all’attacco e un corpo elettrico accordato.",
        "squid-jab": "Una voce d’ancia breve e nervosa, pensata per articolare hook melodici con un attacco netto e un corpo sostenuto.",
        "ottone-pugno": "Uno stab di ottone compatto, con grana di tuba e un bordo sintetico che mantiene chiara ogni nota.",
        "vetro-taglio": "Una campana sintetica scheggiata, dal registro netto e dal decadimento breve, con un colpo metallico registrato in attacco.",
    }
    return f'''{intros[item['slug']]}

## Design

{item['note']}

Route: HYB — recorded source cycle or exciter plus an original oscillator structure written for this sound. The source is the timbral anchor; each recipe adds its own interval layout, filter shape and envelope. Dynamics are rendered at positions 0.15 and 0.90; the hard layer receives a zero-phase high-frequency shelf, level matched after EQ, and switches without crossfade. Saturation is light and level compensated. Reverb stays live and restrained. Tape wow and flutter are zero, polyphony is Poli and glide is zero.

## Source and licence

- {meta['source']} by {meta['author']}, {meta['license']}; {meta['url']}.
- Source file in this recipe: `samples/{source_name}`. Original library cache: `~/Libero/cache/libraries/`.
{'- CC0 Commons transient by Shawn Eary, https://commons.wikimedia.org/wiki/File:Fake_Metal_Bat.wav; cut to a short attack in the recipe.\n' if item.get('attack') else ''}

The source is used as a re-pitched wavetable or exciter inside a newly composed hybrid. This is a designed sound, not a claim to recreate the source instrument. Main roots: MIDI 48, 60, 72, 84; generated dynamics positions: 0.15 and 0.90. The upper partial opens at higher dynamics, with hard layer switching to avoid phase-smearing.

## Measured checks

Generated by `python/scripts/build_aria.py`; compiled and linted by Libero. Preview phrase for this family: soft and loud notes across the roots, a repeated-note pair, a held note, and a short melody. The final build records measured peak, RMS, loop seam and tuning in the compiler output. Numeric warnings are retained in [`_reports/REPORT.md`](../_reports/REPORT.md).
'''


def main():
    prior_created = None
    bank_json = BANK / "bank.json"
    if bank_json.exists():
        try:
            prior_created = json.loads(bank_json.read_text()).get("created")
        except (OSError, json.JSONDecodeError):
            pass
    if BANK.exists() and any(BANK.iterdir()):
        backup = LIBERO / "archive" / f"aria-before-build-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(BANK, backup)
        print(f"backed up existing bank to {backup}")
    BANK.mkdir(parents=True, exist_ok=True)
    commons = _source_file({"source_id": "commons_metal"})
    for item in SOUND:
        folder = BANK / item["slug"]
        samples = folder / "samples"
        samples.mkdir(parents=True, exist_ok=True)
        source = _source_file(item)
        source_name = ("metal-hit.wav" if item["slug"] == "vetro-taglio" else
                       "metal.wav" if item["source_id"] == "commons_metal" else "source.wav")
        shutil.copy2(source, samples / source_name)
        credits = [dict(SOURCES[item["source_id"]], retrieved=RETRIEVED)]
        if item.get("attack") and item["attack"] != source_name:
            shutil.copy2(commons, samples / "metal-hit.wav")
            if item["source_id"] != "commons_metal":
                credits.append(dict(SOURCES["commons_metal"], retrieved=RETRIEVED))
        (samples / "credits.json").write_text(json.dumps(credits, indent=2, ensure_ascii=False) + "\n")
        (samples / "ATTRIBUTION.md").write_text("\n".join(
            f"- {c['source']} — {c['author']}, {c['license']}: {c['url']}" for c in credits) + "\n")
        recipe = _recipe(item, source_name)
        if item.get("attack"):
            recipe += '''\n@sound.attack(pitched=False)\ndef attack(ctx):\n    return ctx.load("metal-hit.wav").trim(0.0, 0.11).fade_in(0.001).fade_out(0.055).highpass(850).gain_db(-22).remove_dc()\n'''
        (folder / "sound.py").write_text(recipe)
        (folder / "figure.svg").write_text(_figure(item) + "\n")
        (folder / "notes.md").write_text(_notes(item, source_name))
        print(f"wrote {item['slug']}")
    bank = {
        "format": "libero.bank/1", "slug": "aria", "title": "Aria",
        "subtitle": "suoni densi per pad e melodie", "description": "Otto strumenti ibridi densi ma controllati: quattro pad evolutivi e quattro voci melodiche, costruiti con registrazioni CC0 acquisite per questo pack e sintesi originale.",
        "version": "1.0.0", "author": "Mario Prignano",
        "created": prior_created or datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"), "updated": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "figure": "figure.svg",
    }
    (BANK / "bank.json").write_text(json.dumps(bank, indent=2, ensure_ascii=False) + "\n")
    (BANK / "figure.svg").write_text('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#2a2430" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><title>Aria</title><desc>Four vertical resonant plates stand behind four tapering reed columns. Their shared central gold plate marks the dense, bright hybrid sound of the bank.</desc><path d="M112 386 L112 180 L157 147 L202 180 L202 386 M220 386 L220 122 L256 85 L292 122 L292 386 M310 386 L310 180 L355 147 L400 180 L400 386" stroke-width="1.3"/><path d="M128 367 L128 198 M144 367 L144 185 M160 367 L160 185 M176 367 L176 198 M236 365 L236 131 M250 365 L250 112 M266 365 L266 112 M280 365 L280 131 M326 367 L326 198 M342 367 L342 185 M358 367 L358 185 M374 367 L374 198" stroke-width="0.55"/><path d="M256 85 L292 122 L256 159 L220 122Z" fill="#b8924f" stroke="#b8924f"/><path d="M82 402 H430 M98 418 H414 M115 434 H397" stroke-width="0.55"/></svg>''')
    from libero.library import bank_refresh
    bank_refresh("aria", touch=True)
    print(f"bank ready: {BANK}")


if __name__ == "__main__":
    main()
