from types import SimpleNamespace
import numpy as np
from libero.audio import Audio
from libero.continuation import restrain_continuation


def test_delayed_sustain_rise_keeps_attack_stereo_and_loop():
    sr = 48000
    time = np.arange(sr * 3) / sr
    level = np.exp(-time * 5)
    level[time >= .55] = .7
    signal = np.sin(2 * np.pi * 200 * time) * level
    source = Audio(np.column_stack((signal, signal * -.6)), sr)
    result = restrain_continuation(source, SimpleNamespace(loop={'start': sr, 'end': sr * 3}), None)
    assert np.array_equal(source.data[:int(.22 * sr)], result.data[:int(.22 * sr)])
    assert np.allclose(result.data[:, 1], result.data[:, 0] * -.6, atol=1e-7)
    before = np.sqrt(np.mean(result.data[int(.42 * sr):int(.52 * sr)] ** 2))
    after = np.sqrt(np.mean(result.data[int(.8 * sr):int(.9 * sr)] ** 2))
    assert after < before * 1.3
    scale = result.data[sr:] / np.where(abs(source.data[sr:]) > 1e-5, source.data[sr:], 1)
    active = abs(source.data[sr:]) > 1e-5
    assert np.ptp(scale[active]) < 1e-6


def test_unlooped_recording_is_untouched():
    source = Audio(np.ones(48000, dtype=np.float32))
    assert restrain_continuation(source, SimpleNamespace(loop=None), None) is source
