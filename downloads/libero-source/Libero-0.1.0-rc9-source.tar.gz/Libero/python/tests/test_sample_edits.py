"""Validation for persisted waveform-editor overlays."""

import json

import numpy as np
import soundfile as sf
import pytest

from libero.library import LibraryError, _validate_sample_edits


def _sound(tmp_path):
    sound = tmp_path / "tone"
    build = sound / "build"
    build.mkdir(parents=True)
    sf.write(build / "body.wav", np.zeros(48_000, dtype=np.float32), 48_000)
    zone = {"file": "body.wav", "layer": "body", "pitched": True, "root": 60,
            "lo": 60, "hi": 60, "vel_lo": 1, "vel_hi": 127, "take": 0,
            "articulation": "sustain"}
    manifest = {"source_hash": "abc123", "zones": [zone]}
    return sound, manifest, zone


def _entry(zone, **changes):
    result = {k: zone.get(k) for k in ("root", "lo", "hi", "vel_lo", "vel_hi", "take", "articulation", "dyn")}
    result.update({"enabled": True, "source_hash": "abc123", "start_s": .1, "end_s": .9,
                   "loop_enabled": True, "loop_start_s": .2, "loop_end_s": .8, "crossfade_ms": 10})
    result.update(changes)
    return result


def _write(sound, edits):
    (sound / "sample-edits.json").write_text(json.dumps({"format": "libero.sample-edits/1", "edits": edits}))


def test_valid_overlay_is_accepted_and_keeps_exact_zone_identity(tmp_path):
    sound, manifest, zone = _sound(tmp_path)
    _write(sound, {"body.wav": _entry(zone)})
    _validate_sample_edits(sound, manifest)


@pytest.mark.parametrize("changes", [
    {"start_s": float("nan")}, {"start_s": -1}, {"end_s": 2},
    {"loop_start_s": .05}, {"crossfade_ms": 501}, {"source_hash": "stale"},
    {"root": 61},
])
def test_invalid_or_stale_overlay_is_rejected(tmp_path, changes):
    sound, manifest, zone = _sound(tmp_path)
    _write(sound, {"body.wav": _entry(zone, **changes)})
    with pytest.raises(LibraryError):
        _validate_sample_edits(sound, manifest)


def test_overlay_cannot_reference_a_path_or_unpitched_zone(tmp_path):
    sound, manifest, zone = _sound(tmp_path)
    _write(sound, {"../body.wav": _entry(zone)})
    with pytest.raises(LibraryError):
        _validate_sample_edits(sound, manifest)
    manifest["zones"][0]["layer"] = "air"
    _write(sound, {"body.wav": _entry(zone)})
    with pytest.raises(LibraryError):
        _validate_sample_edits(sound, manifest)
