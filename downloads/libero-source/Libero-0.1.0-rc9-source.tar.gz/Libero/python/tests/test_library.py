import json
import os
import shutil

import pytest

from libero import library
from libero.library import LibraryError


def test_new_list_save_discard(libero_home, tmp_path):
    folder = library.new_sound("prova", "plucked", "Prova", "sottotitolo")
    assert (folder / "sound.py").read_text().count('title="Prova"') == 1
    items = library.list_sounds()
    assert [(i["slug"], i["saved"]) for i in items] == [("prova", False)]
    saved = library.save_sound("prova")
    assert saved == libero_home / "sounds" / "prova" and saved.is_dir()
    with pytest.raises(LibraryError):
        library.discard_sound("prova")  # saved sounds are not discarded by default
    library.new_sound("bozza", "bell")
    dst = library.discard_sound("bozza")
    assert dst.parent == tmp_path / "Trash" and (dst / "sound.py").exists()
    assert not (libero_home / "sketches" / "bozza").exists()


@pytest.mark.parametrize("slug", ["", "Upper", "has space", "a" * 49, "../x", "x/y"])
def test_bad_slugs(slug):
    with pytest.raises(LibraryError):
        library.new_sound(slug)


@pytest.mark.parametrize("rel", ["../escape.txt", "/etc/passwd", "samples/../../x", "samples/../../../etc/hosts",
                                 "..", "samples/./../../x"])
def test_path_traversal_blocked(rel):
    folder = library.new_sound("s1", "plucked")
    with pytest.raises(LibraryError):
        library.safe_path(folder, rel)
    with pytest.raises(LibraryError):
        library.read_file("s1", rel)
    with pytest.raises(LibraryError):
        library.write_file("s1", rel, "x")


def test_symlink_escape_blocked(tmp_path):
    folder = library.new_sound("s2", "plucked")
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret.txt").write_text("no")
    os.symlink(outside, folder / "samples" / "link")
    with pytest.raises(LibraryError):
        library.read_file("s2", "samples/link/secret.txt")


def test_write_rules():
    library.new_sound("s3", "plucked")
    library.write_file("s3", "notes.md", "# hi")
    library.write_file("s3", "samples/generate.py", "print(1)")
    for rel in ("build/manifest.json", "other.py", "samples/x.wav"):
        with pytest.raises(LibraryError):
            library.write_file("s3", rel, "x")


def test_key_and_velocity_ranges_gapless():
    from libero.compiler import key_ranges, vel_ranges

    for roots in ([60], [36, 48, 60, 72, 84], [0, 127], [20, 21, 22], [38, 45, 52, 59, 66, 73, 80, 87]):
        kr = key_ranges(roots)
        assert kr[0][0] == 0 and kr[-1][1] == 127
        for (lo1, hi1), (lo2, hi2) in zip(kr, kr[1:]):
            assert lo2 == hi1 + 1
        for r, (lo, hi) in zip(sorted(roots), kr):
            assert lo <= r <= hi
    for vels in ([100], [60, 115], [1, 64, 127]):
        vr = vel_ranges(vels)
        assert vr[0][0] == 1 and vr[-1][1] == 127
        for (a, b), (c, d) in zip(vr, vr[1:]):
            assert c == b + 1


def _saved_sound(slug, credits=None):
    f = library.new_sound(slug, "plucked", slug.title())
    from libero.compiler import compile_sound
    result = compile_sound(f, jobs=1)
    assert result.ok, result.error
    (f / "samples" / "raw.wav").write_bytes(b"RIFF")
    if credits:
        (f / "samples" / "credits.json").write_text(json.dumps(credits))
    return library.save_sound(slug)


def test_banks_create_add_pack_install(libero_home, tmp_path, monkeypatch):
    with pytest.raises(LibraryError):
        library.bank_create("mie", "x")
    library.bank_create("antichi", "Antichi", author="io", license="CC0")
    with pytest.raises(LibraryError):
        library.bank_create("antichi", "Antichi")
    _saved_sound("aulos", [{"source": "x", "license_class": "cc0"}])
    library.new_sound("bozza")
    with pytest.raises(LibraryError):
        library.bank_add("bozza", "antichi")      # a sketch cannot go in a bank
    dst = library.bank_add("aulos", "antichi")
    assert dst == libero_home / "banks" / "antichi" / "aulos" and library.find_sound("aulos") == dst
    assert library.is_saved(dst)
    item = next(i for i in library.list_sounds() if i["slug"] == "aulos")
    assert item["bank"] == "antichi" and item["saved"]
    assert {b["slug"]: b["count"] for b in library.bank_list()} == {"antichi": 1, "mie": 0, "prove": 0}
    (dst / "samples/TERMS.md").write_text("Source attribution and redistribution terms")
    license_dir = dst / "samples/licenses/source"
    license_dir.mkdir(parents=True)
    (license_dir / "LICENSE").write_text("Source license text")
    pack = library.bank_pack("antichi", tmp_path / "out")
    import zipfile
    names = set(zipfile.ZipFile(pack).namelist())
    assert "antichi/bank.json" in names and "antichi/aulos/build/manifest.json" in names
    assert "antichi/aulos/sound.py" in names and "antichi/aulos/samples/credits.json" in names
    assert "antichi/aulos/samples/TERMS.md" in names
    assert "antichi/aulos/samples/licenses/source/LICENSE" in names
    assert not any("raw.wav" in n for n in names)
    shutil.rmtree(libero_home / "banks" / "antichi")
    assert library.bank_install(pack) == libero_home / "banks" / "antichi"
    assert (libero_home / "banks" / "antichi" / "aulos" / "build" / "manifest.json").exists()
    with pytest.raises(LibraryError):
        library.bank_install(pack)                # same version: refused
    inspected = library.bank_inspect(pack)
    assert inspected["ok"] and inspected["action"] == "already_installed"
    assert inspected["code"] == "SAME_VERSION" and inspected["soundCount"] == 1
    meta = json.loads(zipfile.ZipFile(pack).read("antichi/bank.json"))
    newer = tmp_path / "new.liberobank"
    with zipfile.ZipFile(pack) as zi, zipfile.ZipFile(newer, "w") as zo:
        for n in zi.namelist():
            zo.writestr(n, json.dumps({**meta, "version": "1.1.0"}) if n == "antichi/bank.json" else zi.read(n))
    monkeypatch.setenv("LIBERO_TRASH", str(tmp_path / "Trash"))
    library.bank_install(newer)
    assert json.loads((libero_home / "banks" / "antichi" / "bank.json").read_text())["version"] == "1.1.0"
    assert library.bank_add("aulos", "mie") == libero_home / "sounds" / "aulos"


def test_bank_pack_refuses_private(libero_home, tmp_path):
    library.bank_create("misto", "Misto")
    _saved_sound("libero-uno", [{"source": "x", "license_class": "cc0"}])
    _saved_sound("privato", [{"source": "y", "license_class": "nc"}])
    library.bank_add("libero-uno", "misto")
    library.bank_add("privato", "misto")
    with pytest.raises(LibraryError, match="privato"):
        library.bank_pack("misto", tmp_path / "m.liberobank")
    assert not (tmp_path / "m.liberobank").exists()


def test_bank_install_rejects_bad_packs(libero_home, tmp_path):
    import zipfile
    bad = tmp_path / "bad.liberobank"
    with zipfile.ZipFile(bad, "w") as z:
        z.writestr("x/../../evil", "1")
    with pytest.raises(LibraryError):
        library.bank_install(bad)


def test_bank_pack_rejects_duplicate_and_windows_paths(tmp_path):
    import zipfile
    for entries in (("x/bank.json", "x/bank.json"), ("x\\..\\evil",)):
        pack = tmp_path / f"bad-{len(list(tmp_path.iterdir()))}.liberobank"
        with zipfile.ZipFile(pack, "w") as z:
            for entry in entries:
                z.writestr(entry, "{}")
        with pytest.raises(LibraryError):
            library.bank_inspect(pack)


def test_bank_pack_rejects_casefold_collisions(tmp_path):
    import zipfile
    pack = tmp_path / "casefold.liberobank"
    with zipfile.ZipFile(pack, "w") as z:
        z.writestr("x/One.wav", b"one")
        z.writestr("x/one.wav", b"two")
    with pytest.raises(LibraryError, match="duplicate path"):
        library.bank_inspect(pack)


def test_bank_inspect_update_downgrade_and_invalid_installed(libero_home, tmp_path):
    import zipfile
    library.bank_create("inspect", "Inspect")
    sound = _saved_sound("inspect-sound", [{"source": "x", "license_class": "cc0"}])
    library.bank_add("inspect-sound", "inspect")
    pack = library.bank_pack("inspect", tmp_path / "inspect.liberobank")
    def rewrite_version(src, dst, version):
        with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, "w") as zout:
            for name in zin.namelist():
                data = zin.read(name)
                if name == "inspect/bank.json":
                    meta = json.loads(data); meta["version"] = version; data = json.dumps(meta).encode()
                zout.writestr(name, data)
    same = library.bank_inspect(pack)
    assert same["action"] == "already_installed" and same["code"] == "SAME_VERSION"
    newer = tmp_path / "newer.liberobank"
    rewrite_version(pack, newer, "1.1.0")
    update = library.bank_inspect(newer)
    assert update["ok"] and update["action"] == "update" and any("replaces the installed bank" in w for w in update["warnings"])
    older = tmp_path / "older.liberobank"
    rewrite_version(pack, older, "0.9.0")
    assert library.bank_inspect(older)["code"] == "DOWNGRADE"
    (libero_home / "banks" / "inspect" / "bank.json").write_text("not json")
    with pytest.raises(LibraryError, match="invalid metadata"):
        library.bank_inspect(newer)
    assert (libero_home / "banks" / "inspect" / "inspect-sound" / "build" / "manifest.json").exists()


def test_bank_install_rolls_back_when_final_rename_fails(libero_home, tmp_path, monkeypatch):
    import zipfile
    library.bank_create("atomic", "Atomic")
    sound = _saved_sound("sound-one", [{"source": "x", "license_class": "cc0"}])
    library.bank_add("sound-one", "atomic")
    old = libero_home / "banks" / "atomic"
    pack = library.bank_pack("atomic", tmp_path / "atomic.liberobank")
    with zipfile.ZipFile(pack) as zin, zipfile.ZipFile(tmp_path / "new.liberobank", "w") as zout:
        for name in zin.namelist():
            data = zin.read(name)
            if name == "atomic/bank.json":
                meta = json.loads(data)
                meta["version"] = "1.0.1"
                data = json.dumps(meta).encode()
            zout.writestr(name, data)
    real_replace = os.replace
    failed = False
    def fail_install(src, dst):
        nonlocal failed
        if Path(src).name == "atomic" and Path(dst) == old and not failed:
            failed = True
            raise OSError("injected final swap failure")
        return real_replace(src, dst)
    from pathlib import Path
    monkeypatch.setattr(os, "replace", fail_install)
    with pytest.raises(OSError, match="injected"):
        library.bank_install(tmp_path / "new.liberobank")
    assert json.loads((old / "bank.json").read_text())["version"] == "1.0.0"
    assert (old / "sound-one" / "build" / "manifest.json").exists()
    assert not list((libero_home / "banks").glob(".install-*"))


def test_bank_schema_license_edit(libero_home):
    credits = [{"source": "a", "license": "CC BY 4.0", "license_class": "by"},
               {"source": "b", "license": "CC BY-SA 4.0", "license_class": "by-sa"}]
    library.bank_create("lic", "Lic", "sub")
    _saved_sound("uno", credits)
    library.bank_add("uno", "lic")
    meta = json.loads((libero_home / "banks" / "lic" / "bank.json").read_text())
    assert set(meta) == {"format", "slug", "title", "subtitle", "description", "version", "author",
                         "license", "created", "updated", "figure"}
    assert meta["license"].startswith("CC BY-SA 4.0") and meta["version"] == "1.0.0"
    m = library.bank_edit("lic", title="Nuova", subtitle="s2", description="d")
    assert (m["title"], m["subtitle"], m["description"]) == ("Nuova", "s2", "d") and m["slug"] == "lic"
    with pytest.raises(LibraryError):
        library.bank_edit("lic", version="v1")
    with pytest.raises(LibraryError):
        library.bank_edit("nope", title="x")


def test_bank_migrate_old_files(libero_home):
    d = libero_home / "banks" / "vecchia"
    d.mkdir(parents=True)
    (d / "bank.json").write_text(json.dumps({"format": "libero.bank/1", "slug": "vecchia", "title": "Vecchia"}))
    assert library.bank_migrate() == ["vecchia"]
    meta = json.loads((d / "bank.json").read_text())
    assert meta["version"] == "1.0.0" and meta["created"] and meta["updated"] and meta["license"]
    assert library.bank_migrate() == []                       # idempotent
    assert library.bank_list()[0]["title"] == "Vecchia"


def test_bank_install_version_and_schema(libero_home, tmp_path):
    import zipfile

    library.bank_create("v", "V")
    pack = library.bank_pack("v", tmp_path / "v.liberobank")
    with pytest.raises(LibraryError, match="already installed"):
        library.bank_install(pack)
    bad = tmp_path / "bad.liberobank"
    with zipfile.ZipFile(bad, "w") as z:
        z.writestr("w/bank.json", json.dumps({"format": "libero.bank/1", "slug": "w", "title": "W", "version": "one"}))
    with pytest.raises(LibraryError, match="semver"):
        library.bank_install(bad)


def test_color_tags(libero_home):
    _saved_sound("tinto")
    assert library.set_color_tag("tinto", 3) == 3 and library.color_tag("tinto") == 3
    library.bank_create("b", "B")
    library.bank_add("tinto", "b")                              # keyed by slug: survives the move
    assert library.color_tag("tinto") == 3
    assert [s["color_tag"] for s in library.list_sounds()] == [3]
    with pytest.raises(LibraryError):
        library.set_color_tag("tinto", 5)
    library.set_color_tag("tinto", 0)
    assert "tags" not in json.loads((libero_home / "config.json").read_text())


def test_bank_pack_refuses_missing_or_malformed_credits(libero_home, tmp_path):
    library.bank_create("unresolved", "Unresolved")
    sound = _saved_sound("uncredited")
    library.bank_add("uncredited", "unresolved")
    for content in (None, "not json", "[]"):
        credits = library.find_sound("uncredited") / "samples" / "credits.json"
        if content is not None:
            credits.write_text(content)
        with pytest.raises(library.LibraryError, match="must not be shared"):
            library.bank_pack("unresolved", tmp_path / "unresolved.liberobank")
