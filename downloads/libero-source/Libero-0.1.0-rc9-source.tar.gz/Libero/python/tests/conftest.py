import os
import shutil
import sys
from pathlib import Path

import numpy as np
import pytest

REPO = Path(__file__).resolve().parents[2]


@pytest.fixture(autouse=True)
def libero_home(tmp_path, monkeypatch):
    """Every test gets its own library and Trash; the real ~/Libero is never touched."""
    home = tmp_path / "Libero"
    monkeypatch.setenv("LIBERO_HOME", str(home))
    monkeypatch.setenv("LIBERO_TRASH", str(tmp_path / "Trash"))
    return home


def cents(a: float, b: float) -> float:
    return 1200.0 * np.log2(a / b)


def harmonic_tone(f0: float, seconds: float = 2.0, sr: int = 48000, n_harm: int = 8, seed: int = 0):
    from libero import Audio

    t = np.arange(int(seconds * sr)) / sr
    rng = np.random.default_rng(seed)
    y = sum(np.sin(2 * np.pi * f0 * k * t + rng.uniform(0, 6.28)) / k for k in range(1, n_harm + 1))
    return Audio(0.3 * y, sr)


def fake_recording(root: int, level_db: float, bright: float, seconds: float = 2.5, pre_s: float = 0.03,
                   seed: int = 0, sr: int = 48000, stereo: bool = True, detune_cents: float = 0.0):
    """A 'recorded' plucked note: silence with a noise floor, then a Karplus string whose
    brightness and level follow the dynamics layer."""
    from libero import Audio, dsp, synth

    f = dsp.midi_to_freq(root) * 2 ** (detune_cents / 1200)
    s = synth.karplus(f, seconds, bright=bright, velocity=bright, decay=2.0, seed=seed, sr=sr)
    s = s.normalize(-6).gain_db(level_db)
    s = s.pad(before=pre_s).noise_floor(-78, "pink", seed=seed + 1)
    return s.pan(0.1) if stereo else s


def make_multisample(folder: Path, roots=(48, 55, 62, 69), layers=((1, 60, -18, 0.25), (61, 127, -6, 0.8)),
                     takes: int = 1, jitter_ms: float = 4.0, sr: int = 48000) -> list[dict]:
    """Write fake recordings under folder/samples/rec and return their region dicts."""
    rng = np.random.default_rng(3)
    regs = []
    (folder / "samples" / "rec").mkdir(parents=True, exist_ok=True)
    for root in roots:
        for li, (vlo, vhi, lvl, br) in enumerate(layers):
            for t in range(takes):
                pre = 0.02 + rng.uniform(0, jitter_ms) * 1e-3
                a = fake_recording(root, lvl, br, pre_s=pre, seed=root * 31 + li * 7 + t)
                name = f"rec/n{root}_v{vhi}_t{t}.wav"
                a.save(folder / "samples" / name)
                r = {"file": name, "root": root, "vel": [vlo, vhi]}
                if t:
                    r["take"] = t
                regs.append(r)
    return regs
