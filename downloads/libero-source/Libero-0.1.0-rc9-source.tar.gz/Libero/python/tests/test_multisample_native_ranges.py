"""Native regression for explicit one-key mappings of neighboring-root RR takes."""
from __future__ import annotations

import json
import math
import textwrap

import numpy as np
import pytest
import soundfile as sf

from libero import library, render
from libero.compiler import compile_sound


def _measure_cents(samples: np.ndarray, sr: int, expected_hz: float) -> float:
    x = np.asarray(samples, dtype=np.float64)
    x -= np.mean(x)
    nfft = 1 << int(math.ceil(math.log2(len(x) * 128)))
    window = np.hanning(len(x))
    spectrum = np.abs(np.fft.rfft(x * window, n=nfft))
    freqs = np.fft.rfftfreq(nfft, 1 / sr)
    band = np.flatnonzero((freqs > expected_hz * 2 ** (-100 / 1200)) &
                          (freqs < expected_hz * 2 ** (100 / 1200)))
    assert len(band), "fundamental search band is empty"
    k = int(band[np.argmax(spectrum[band])])
    logs = np.log(np.maximum(spectrum[k - 1:k + 2], 1e-30))
    den = logs[0] - 2 * logs[1] + logs[2]
    frac = .5 * (logs[0] - logs[2]) / den if abs(den) > 1e-20 else 0.0
    frac = float(np.clip(frac, -.5, .5))
    measured_hz = (k + frac) * sr / nfft
    return 1200 * math.log2(measured_hz / expected_hz)


def test_native_explicit_key_range_rr_roots_stay_on_played_pitch(libero_home, tmp_path):
    """Different source roots mapped to one key stay in tune and remain distinct RR takes."""
    folder = library.new_sound("native-ranges", "plucked")
    samples = folder / "samples"
    samples.mkdir(parents=True, exist_ok=True)
    sr = 48000
    duration = .36
    t = np.arange(round(duration * sr)) / sr
    target_midi = 56
    target_hz = 440 * 2 ** ((target_midi - 69) / 12)
    regions = []
    amplitudes = (.055, .110, .220)
    for take, root in enumerate((56, 57, 58)):
        source_hz = 440 * 2 ** ((root - 69) / 12)
        # Each file contains a real, pitch-coherent source-root sine at a distinct
        # level, so both transposition and RR selection are observable natively.
        wave = amplitudes[take] * np.sin(2 * np.pi * source_hz * t + take * .23)
        edge = round(.004 * sr)
        wave[:edge] *= np.linspace(0, 1, edge, endpoint=False)
        wave[-edge:] *= np.linspace(1, 0, edge, endpoint=False)
        name = f"rr-root-{root}.wav"
        sf.write(samples / name, wave.astype(np.float32), sr, subtype="PCM_24")
        regions.append({"file": name, "root": root, "lo": target_midi, "hi": target_midi,
                        "take": take, "vel": [1, 127]})

    recipe = f"""
from libero import Sound
sound = Sound(title="Native RR range regression", roots=[{target_midi}])
sound.multisample("body", {regions!r}, as_dyn=False,
                  process={{"tune":"none", "ladder":"keep", "align_ms":0,
                           "pre_ms":0, "loop":"none", "end_db":-100,
                           "max_seconds":None, "edge_fill":False,
                           "preserve_key_ranges":True, "encoding":"flac24"}})
sound.performance(rr_reset_ms=1500, humanize={{"cents":0,"ms":0,"db":0}}, onset_ms=0)
sound.defaults(mode="Poli", glide=0, amp_attack=0, amp_decay=10000,
               amp_sustain=1, amp_release=5, master=0, rev_mix=0,
               drive=0, width=1, tape_wow=0, tape_flutter=0,
               lvl_attack=-60, lvl_tail=-60, lvl_air=-60, caldi_mode="Spento")
"""
    (folder / "sound.py").write_text(textwrap.dedent(recipe))

    compiled = compile_sound(folder, jobs=1)
    assert compiled.ok, compiled.error
    manifest = json.loads((folder / "build" / "manifest.json").read_text())
    zones = [z for z in manifest["zones"] if z["layer"] == "body"]
    assert {(z["root"], z["lo"], z["hi"], z.get("take", 0)) for z in zones} == {
        (56, 56, 56, 0), (57, 56, 56, 1), (58, 56, 56, 2)
    }
    assert manifest["rr_reset_ms"] == 1500
    assert library.validate_bundle(folder / "build") == []

    if render.find_renderer() is None:
        pytest.skip("native renderer unavailable after compile/bundle checks")

    count = 90
    starts = [i * .45 for i in range(count)]
    out = folder / "native-repeat.wav"
    notes = [(target_midi, start, .22, 100) for start in starts]
    render.render(folder, out, notes, {"rev_mix": 0, "lvl_tail": -60,
                                      "lvl_air": -60, "lvl_attack": -60}, tail=.1)
    audio, render_sr = sf.read(out, always_2d=True)
    expected_hz = target_hz
    levels = []
    signatures = []
    pitches = []
    for start in starts:
        a = round((start + .025) * render_sr)
        b = round((start + .185) * render_sr)
        segment = audio[a:b]
        rms = float(np.sqrt(np.mean(segment * segment)))
        levels.append(20 * math.log10(rms + 1e-30))
        signatures.append(round(levels[-1], 1))
        pitches.append(_measure_cents(segment.mean(axis=1), render_sr, expected_hz))

    assert max(abs(c) for c in pitches) < 2, (
        "all distinct source roots must render at the played MIDI 56; "
        f"largest residual is {max(abs(c) for c in pitches):.3f} cents")
    distinct = sorted(set(signatures))
    assert len(distinct) == 3, f"native RR output exposed only {distinct}, expected 3 signatures"
    counts = {level: signatures.count(level) for level in distinct}
    assert min(counts.values()) >= 5, f"not all three RR takes were selected: {counts}"
