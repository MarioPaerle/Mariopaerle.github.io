import json
import textwrap

import pytest

from libero import library
from libero.compiler import compile_sound
from libero.lint import lint_bundle
from libero.recipe import RecipeError
from libero.library import validate_articulations, validate_bundle
from conftest import make_multisample

ARTS = [{"id": "sus", "name": "Sostenuto", "key": 24},
        {"id": "stacc", "name": "Staccato", "key": 25},
        {"id": "pizz", "name": "Pizzicato", "key": 26}]


def _build(slug, arts=ARTS, art_ids=("sus", "stacc", "pizz")):
    folder = library.new_sound(slug, "bowed")
    regs = make_multisample(folder, layers=((1, 127, -10, 0.5),), takes=1)
    allregs = [dict(r, articulation=a) for a in art_ids for r in regs]
    (folder / "sound.py").write_text(textwrap.dedent(f"""
        from libero import Sound
        sound = Sound(title="Archi", tags=["string"])
        sound.multisample("body", {allregs!r}, process={{"tune": "detect", "max_seconds": 2.0}})
        sound.articulations({arts!r})
    """))
    res = compile_sound(folder)
    assert res.ok, res.error
    return folder / "build"


def test_compile_writes_articulations():
    build = _build("artc")
    m = json.loads((build / "manifest.json").read_text())
    assert m["format"] == "libero.bundle/2"
    assert [a["id"] for a in m["articulations"]] == ["sus", "stacc", "pizz"]
    assert m["articulations"][0] == {"id": "sus", "name": "Sostenuto", "key": 24}
    zs = [z for z in m["zones"] if z["layer"] == "body"]
    assert {z["articulation"] for z in zs} == {"sus", "stacc", "pizz"}
    # every articulation is a complete keyboard, and no zone covers a keyswitch key
    for a in ("sus", "stacc", "pizz"):
        za = [z for z in zs if z["articulation"] == a]
        assert min(z["lo"] for z in za) == 27 and max(z["hi"] for z in za) == 127
    assert validate_bundle(build) == []
    assert json.loads((build / "info.json").read_text())["articulations"][1]["name"] == "Staccato"
    assert not [f for f in lint_bundle(build) if f.level == "FAIL"]


def test_recipe_rejects_bad_articulations():
    for bad in ([], [{"id": "a", "name": "A", "key": 1}, {"id": "a", "name": "B", "key": 2}],
                [{"id": "a", "name": "A", "key": 1}, {"id": "b", "name": "B", "key": 1}],
                [{"id": "A b", "name": "A", "key": 1}], [{"id": "a", "name": "A", "key": 200}]):
        assert validate_articulations(bad)
    from libero import Sound
    with pytest.raises(RecipeError):
        Sound(title="x").articulations([{"id": "a", "name": "A", "key": 300}])


def test_validate_keyswitch_inside_playing_range(tmp_path):
    build = _build("artv")
    m = json.loads((build / "manifest.json").read_text())
    m["articulations"][0]["key"] = 60
    (build / "manifest.json").write_text(json.dumps(m))
    probs = " | ".join(validate_bundle(build))
    assert "keyswitch key 60 lies inside" in probs
    m["articulations"][0]["key"] = 24
    m["articulations"][1]["id"] = "sus"
    (build / "manifest.json").write_text(json.dumps(m))
    assert "not unique" in " | ".join(validate_bundle(build))
    m["articulations"][1]["id"] = "stacc"
    m["zones"][0]["articulation"] = "nope"
    (build / "manifest.json").write_text(json.dumps(m))
    assert "not in the manifest's articulations" in " | ".join(validate_bundle(build))
