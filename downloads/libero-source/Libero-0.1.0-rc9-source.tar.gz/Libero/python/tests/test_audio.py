import numpy as np
import pytest

from libero import Audio, dsp, synth
from conftest import cents, harmonic_tone

SR = 48000


def test_pitch_up_octave_doubles_f0():
    a = harmonic_tone(220.0)
    b = a.pitch(12)
    assert abs(cents(b.f0(), 440.0)) < 2.0
    assert abs(b.n - a.n / 2) <= 2


@pytest.mark.parametrize("st", [-7, -1, 3.5, 5])
def test_pitch_arbitrary(st):
    a = harmonic_tone(261.63)
    assert abs(cents(a.pitch(st).f0(), 261.63 * 2 ** (st / 12))) < 2.0


@pytest.mark.parametrize("detune_cents,target", [(37.0, 57), (-48.0, "C4"), (12.0, "F#2")])
def test_tune_to_lands_within_5_cents(detune_cents, target):
    note = dsp.parse_note(target)
    f = dsp.midi_to_freq(note + 2) * 2 ** (detune_cents / 1200)  # two semitones and some cents away
    a = harmonic_tone(f, 2.5)
    b = a.tune_to(target)
    assert abs(cents(b.f0(), dsp.midi_to_freq(note))) < 5.0


def test_tune_to_on_plucked_string():
    k = synth.karplus(dsp.midi_to_freq(50) * 2 ** (23 / 1200), 3.0, seed=4)
    assert abs(cents(k.tune_to(50).f0(), dsp.midi_to_freq(50))) < 5.0


def test_stretch_preserves_pitch_and_scales_length():
    a = harmonic_tone(196.0, 2.0)
    for factor in (0.6, 1.5, 2.5):
        b = a.stretch(factor)
        assert abs(b.n - round(a.n * factor)) <= 1
        assert abs(cents(b.f0(), 196.0)) < 2.0
        assert abs(b.rms_db - a.rms_db) < 1.5


def test_stretch_stereo():
    a = harmonic_tone(330.0, 1.0).pan(-0.4)
    b = a.stretch(1.3)
    assert b.is_stereo and abs(cents(b.f0(), 330.0)) < 2.0


def test_convolution_length_and_mix():
    a = Audio(np.random.default_rng(1).standard_normal(10000) * 0.1, SR)
    ir = synth.impulse_response("room", seconds=0.3, sr=SR)
    y = a.convolve(ir, mix=1.0)
    assert y.n == a.n + ir.n - 1
    assert y.is_stereo  # stereo IR makes the result stereo
    dry = a.convolve(ir, mix=0.0)
    assert np.allclose(dry.data[: a.n, 0], a.data, atol=1e-6)


def test_convolve_identity():
    a = harmonic_tone(440.0, 0.5)
    delta = Audio(np.r_[1.0, np.zeros(99)], SR)
    y = a.convolve(delta, mix=1.0, normalize=False)
    assert np.allclose(y.data[: a.n], a.data, atol=1e-6)


def test_loop_points_seamless_on_sustained_tone():
    t = np.arange(4 * SR) / SR
    am = 1.0 + 0.05 * np.sin(2 * np.pi * 0.7 * t)  # a slightly moving sustain
    y = am * sum(np.sin(2 * np.pi * 220.0 * k * t) / k for k in range(1, 6)) * 0.3
    a = Audio(y, SR).fade_in(0.05)
    lp = a.loop_points(min_seconds=0.5)
    assert lp is not None
    assert lp.error_db < -30
    assert lp.end - lp.start >= 0.5 * SR
    m = a.data
    assert m[lp.start - 1] < 0 <= m[lp.start] and m[lp.end - 1] < 0 <= m[lp.end]
    baked = a.bake_loop(lp)
    assert baked.n == lp.end
    # the jump end → start is continuous: its step is no bigger than a normal sample step
    step = abs(float(baked.data[-1]) - float(baked.data[lp.start]))
    typical = float(np.percentile(np.abs(np.diff(m)), 99))
    assert step <= typical


def test_loopgrid_makes_exact_loops():
    g = synth.LoopGrid(261.63, 2.0, SR)
    dur = 0.5 + 2 * g.seconds
    v = synth.saw(g.cents(-7), dur, sr=SR, phase=0.2).mix(synth.saw(synth.vibrato(g.cents(5), g.rate(4.8), 10, 0.0),
                                                                    dur, sr=SR))
    x = v.data
    s = int(0.5 * SR)
    assert np.max(np.abs(x[s: s + 2000] - x[s + g.samples: s + g.samples + 2000])) < 1e-3
    lp = v.loop_points(min_seconds=1.5)
    assert lp.error_db < -60


def test_envelope_adsr_and_points():
    a = Audio(np.ones(SR), SR)
    e = a.envelope(adsr=(0.1, 0.1, 0.5, 0.2))
    d = e.data
    assert d[0] == pytest.approx(0, abs=1e-3)
    assert d[int(0.1 * SR)] == pytest.approx(1.0, abs=0.02)
    assert d[int(0.5 * SR)] == pytest.approx(0.5, abs=0.02)
    assert d[-1] == pytest.approx(0, abs=0.01)
    lin = a.envelope([(0, 0), (1, 1)], curve="linear").data
    assert lin[SR // 2] == pytest.approx(0.5, abs=0.01)


def test_limit_and_normalize():
    a = harmonic_tone(110.0).gain_db(15)
    assert a.peak_db > 0
    assert a.limit(-1.0).peak_db <= -1.0 + 1e-3
    assert a.normalize(-3).peak_db == pytest.approx(-3.0, abs=0.01)
    b = harmonic_tone(110.0).normalize_loudness(-20)
    assert b.lufs_max == pytest.approx(-20.0, abs=0.1)


def test_place_mix_concat_lengths():
    a = Audio.silence(1.0, SR)
    b = harmonic_tone(440.0, 0.5)
    assert a.place(b, 0.8).n == int(1.3 * SR)
    assert a.mix(b).n == SR
    c = b.concat(b, crossfade=0.1)
    assert c.n == 2 * b.n - int(0.1 * SR)
    assert b.pan(0.5).is_stereo and b.pan(0.5).to_mono().channels == 1


def test_transient_aligns_onsets():
    body = Audio.silence(0.1, SR).concat(harmonic_tone(220.0, 1.0))
    click = Audio.silence(0.02, SR).concat(synth.noise("white", 0.01, sr=SR).fade_out(0.008))
    out = body.transient(click, overlap_ms=10)
    assert abs(out.onset() - body.onset()) < 0.002


def test_noise_floor_level():
    a = Audio.silence(2.0, SR)
    b = a.noise_floor(-50, "pink", seed=3)
    assert b.rms_db == pytest.approx(-50, abs=0.5)


def test_resample_and_save_roundtrip(tmp_path):
    a = harmonic_tone(440.0, 0.5)
    b = a.resample(44100)
    assert b.sr == 44100 and abs(cents(b.f0(), 440.0)) < 1.0
    p = b.save(tmp_path / "x.wav")
    c = Audio.load(p)
    assert c.sr == 44100 and c.n == b.n and np.allclose(c.data, b.data)


def test_immutability():
    a = harmonic_tone(440.0, 0.1)
    before = a.data.copy()
    a.gain_db(6).lowpass(1000).reverse()
    assert np.array_equal(a.data, before)
    with pytest.raises(ValueError):
        a.data[0] = 1.0
