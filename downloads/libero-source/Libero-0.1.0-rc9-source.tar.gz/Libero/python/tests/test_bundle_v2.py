import json

import numpy as np
import soundfile as sf

from libero import library


def _bundle(tmp_path, zones, **extra):
    b = tmp_path / "build"
    b.mkdir()
    for z in zones:
        sf.write(str(b / z["file"]), np.zeros(4800, dtype=np.float32), 48000,
                 **({"format": "FLAC", "subtype": "PCM_24"} if z["file"].endswith(".flac") else {"subtype": "FLOAT"}))
    m = {"format": extra.pop("format", "libero.bundle/2"), "slug": "t", "title": "T", "subtitle": "", "tags": [],
         "description": "", "sample_rate": 48000, "compiled_at": "2026-09-30T00:00:00Z", "source_hash": "0" * 64,
         "zones": zones, "params": {}, **extra}
    (b / "manifest.json").write_text(json.dumps(m))
    return b


def _z(file, lo=0, hi=127, dyn=None, layer="body", **k):
    z = {"layer": layer, "file": file, "root": 60, "pitched": True, "lo": lo, "hi": hi, "vel_lo": 1, "vel_hi": 127,
         "gain_db": 0.0, "loop": None, **k}
    if dyn:
        z["dyn"] = dyn
    return z


def test_valid_v2_bundle(tmp_path):
    zones = [_z("a.flac", dyn=[0, 0.4], tune_cents=-3.5), _z("b.flac", dyn=[0.4, 1.0]),
             _z("r.wav", layer="tail", rt_decay=6.0, rt_min_db=-40)]
    b = _bundle(tmp_path, zones, dynamics={"source": "cc1", "velocity_curve": 1.4},
                humanize={"cents": 2, "ms": 3, "db": 0.5}, rr_reset_ms=1500,
                credits=[{"source": "x"}], license="CC0")
    assert library.validate_bundle(b) == []


def test_pitched_limited_range_and_keyswitch_gap(tmp_path):
    # Natural range margins are allowed; an unplayed keyswitch inside that
    # range is exempt from the coverage grid (the playing zones stop around it).
    zones = [_z("lo.flac", lo=60, hi=60), _z("hi.flac", lo=62, hi=62)]
    b = _bundle(tmp_path, zones, articulations=[{"id": "sus", "name": "Sustain", "key": 61}])
    assert library.validate_bundle(b) == []


def test_pitched_internal_gap_without_keyswitch_is_rejected(tmp_path):
    zones = [_z("lo.flac", lo=60, hi=60), _z("hi.flac", lo=62, hi=62)]
    b = _bundle(tmp_path, zones)
    probs = " | ".join(library.validate_bundle(b))
    assert "(61, 1)" in probs


def test_articulation_live_synth_profiles_are_validated_and_preserved(tmp_path):
    from libero.recipe import Sound
    art = {"id": "nasale", "name": "Nasale", "key": 12,
           "params": {"flt_mode": "Vocale", "flt_cutoff": 1800, "sub2_level": -9}}
    sound = Sound(title="SYN profile").articulations([art])
    assert sound.articulations_spec[0]["params"] == art["params"]
    b = _bundle(tmp_path, [], articulations=[art], params={"osc1_level": -6})
    assert library.validate_bundle(b) == []
    (tmp_path / "bad").mkdir()
    bad = _bundle(tmp_path / "bad", [], articulations=[{**art, "params": {"master": 6}}], params={"osc1_level": -6})
    probs = " | ".join(library.validate_bundle(bad))
    assert "unsupported live profile parameters" in probs


def test_v2_errors(tmp_path):
    zones = [_z("a.flac", dyn=[0, 0.4]), _z("b.flac", dyn=[0.5, 1.0], rt_decay=3),
             _z("c.wav", layer="tail", rt_min_db=5)]
    b = _bundle(tmp_path, zones, dynamics={"source": "cc7"}, humanize={"cents": 99, "swing": 1}, rr_reset_ms=-1)
    probs = " | ".join(library.validate_bundle(b))
    for needle in ("do not tile", "rt_decay only applies to tail", "bad rt_min_db", "dynamics.source",
                   "humanize.cents", "unknown keys", "rr_reset_ms"):
        assert needle in probs, needle


def test_v1_must_not_use_v2_features(tmp_path):
    b = _bundle(tmp_path, [_z("a.flac", dyn=[0, 1.0])], format="libero.bundle/1")
    assert any("declares libero.bundle/1" in p for p in library.validate_bundle(b))


def test_takes_up_to_16_in_v2(tmp_path):
    zones = [_z(f"t{i}.wav", take=i) for i in range(12)]
    assert library.validate_bundle(_bundle(tmp_path, zones)) == []
    assert library.bundle_uses_v2({"zones": zones})
    assert not library.bundle_uses_v2({"zones": [_z("x.wav", take="one")]})


def test_dynamics_crossfade_range(tmp_path):
    zones = [_z("a.flac", dyn=[0, 0.4]), _z("b.flac", dyn=[0.4, 1.0])]
    ok = _bundle(tmp_path, zones, dynamics={"source": "velocity", "velocity_curve": 1.0, "crossfade": 0})
    assert library.validate_bundle(ok) == []
    bad = _bundle(tmp_path / "x", zones, dynamics={"source": "velocity", "crossfade": 1.5}) if (tmp_path / "x").mkdir() is None else None
    assert any("dynamics.crossfade" in p for p in library.validate_bundle(bad))


def test_performance_dyn_crossfade_and_family_default():
    import pytest
    from libero import families
    from libero.recipe import RecipeError, Sound

    assert Sound(title="t").performance(dyn_crossfade=0).performance_spec["dynamics"]["crossfade"] == 0.0
    with pytest.raises(RecipeError):
        Sound(title="t").performance(dyn_crossfade=1.2)
    assert families.dyn_crossfade_default(families.of_tags(["guitar", "sampled"])) == 0
    assert families.dyn_crossfade_default("piano") == 0
    assert families.dyn_crossfade_default("bowed") == "aligned"
    assert families.dyn_crossfade_default("synth") is None


def test_lint_crossfade_correlation_flags_unaligned_layers(tmp_path):
    from libero import lint

    sr = 48000
    t = np.arange(sr) / sr
    rng = np.random.default_rng(1)
    zones = []
    for i, (name, x) in enumerate((("a.wav", np.sin(2 * np.pi * 220 * t)), ("b.wav", rng.standard_normal(sr) * 0.3))):
        sf.write(str(tmp_path / name), (x * 0.5).astype(np.float32), sr, subtype="FLOAT")
        zones.append(_z(name, dyn=[i * 0.5, i * 0.5 + 0.5], lo=60, hi=60))
    blended = lint.dyn_crossfade_correlation(tmp_path, zones, 0.3)
    assert blended and blended[0][1] < lint.XF_CORR_MIN
    assert lint.dyn_crossfade_correlation(tmp_path, zones, 0)[0][1] > 0.99
