"""libero.physics: tuning, stability, determinism, speed, API contracts, guide recipes."""

import math
import re
import time
from pathlib import Path

import numpy as np
import pytest

from libero import Audio, analysis, dsp
from libero import physics as ph
from libero.physics import _common as cm
from libero.physics import presets as P
from libero.recipe import Ctx

SR = 48000


@pytest.fixture(scope="module", autouse=True)
def warm():
    """Compile every numba kernel once so the timing tests measure rendering, not compilation."""
    ph.pluck(220, 0.3)
    ph.hammer_string(220, 0.3)
    ph.bow(220, 0.6)
    ph.reed(220, 0.6)
    ph.reed(220, 0.6, bore="conical")
    ph.flute(440, 0.6)
    ph.brass(440, 0.6)
    ph.mallet_strike(ph.bar(440), 0.3)
    ph.fd_plate(200, 0.2)
    ph.spring_ir(0.3)
    ph.shoebox_ir((4, 3, 2.5), "plaster", duration=0.3)


def cents(a, b):
    return 1200.0 * math.log2(a / b)


def partial_peak(a: Audio, f: float, t0=0.05, t1=1.5, tol=0.03):
    """Frequency of the spectral peak near f (parabolic interpolation in the log spectrum)."""
    x = a.data.astype(np.float64)[int(t0 * a.sr): int(t1 * a.sr)]
    n = 1 << 20
    S = np.abs(np.fft.rfft(x * np.hanning(len(x)), n))
    fr = np.fft.rfftfreq(n, 1 / a.sr)
    m = (fr > f * (1 - tol)) & (fr < f * (1 + tol))
    i = int(np.argmax(S * m))
    y0, y1, y2 = np.log(S[i - 1: i + 2] + 1e-30)
    d = 0.5 * (y0 - y2) / (y0 - 2 * y1 + y2)
    return (i + d) * a.sr / n


def steady_cents(a: Audio, f: float) -> float:
    ok, c, r = cm.pitch_lock(a.data, a.sr, f, 0.3, 0.9)
    assert ok, f"not periodic at {f:.1f} Hz (autocorr {r:.2f})"
    return c


# ---------------------------------------------------------------- tuning

@pytest.mark.parametrize("B", [0.0, 2e-4, 3e-3])
def test_string_fundamental_exact_across_range(B):
    for f in (41.2, 82.4, 164.8, 329.6, 659.3, 1318.5, 2637.0):
        a = ph.pluck(f, 1.8, decay=6.0, inharmonicity=B, strings=1)
        assert abs(cents(partial_peak(a, f), f)) < 0.5, f


def test_string_partials_follow_inharmonicity_law():
    f, B = 130.8, 4e-4
    a = ph.pluck(f, 2.0, decay=8.0, decay_hf=0.6, inharmonicity=B, position=0.3)
    for k in (2, 3, 4):
        fk = f * k * math.sqrt((1 + B * k * k) / (1 + B))
        assert abs(cents(partial_peak(a, fk, tol=0.01), fk)) < 4.0, k


def test_hammered_string_tuning_and_brightness_grows_with_velocity():
    f = 261.6
    soft = ph.hammer_string(f, 2.5, velocity=0.15, strings=1)
    loud = ph.hammer_string(f, 2.5, velocity=1.0, strings=1)
    assert abs(cents(partial_peak(loud, f), f)) < 1.0
    def hf_db(a):  # energy above the 6th harmonic, first 300 ms
        x = a.data.astype(np.float64)[: int(0.3 * SR)]
        S = np.abs(np.fft.rfft(x * np.hanning(len(x)), 1 << 16)) ** 2
        fr = np.fft.rfftfreq(1 << 16, 1 / SR)
        return 10 * np.log10(S[fr > 6 * f].sum() / S.sum())
    assert hf_db(loud) > hf_db(soft) + 5.0


def test_bow_locks_to_pitch_and_has_helmholtz_spectrum():
    for f in (98.0, 196.0, 392.0):
        a = ph.bow(f, 2.0, speed=0.25, pressure=0.6, position=0.1, noise=0.2)
        assert abs(cents(analysis.features(a)["f0_hz"], f)) < 3.0, f
        assert abs(steady_cents(a, f)) < 6.0, f
    f = 130.8
    a = ph.bow(f, 2.5, speed=0.25, pressure=0.6, position=0.1, noise=0.0)
    x = a.data.astype(np.float64)[SR: 2 * SR]
    S = np.abs(np.fft.rfft(x * np.hanning(len(x)), 1 << 18))
    fr = np.fft.rfftfreq(1 << 18, 1 / SR)
    amp = np.array([S[(fr > f * k * 0.97) & (fr < f * k * 1.03)].max() for k in range(1, 7)])
    db = 20 * np.log10(amp / amp[0])
    ideal = -20 * np.log10(np.arange(1, 7))
    assert np.sqrt(np.mean((db - ideal) ** 2)) < 4.5  # sawtooth: 1/k


@pytest.mark.parametrize("midi", [50, 62, 74, 86])
def test_clarinet_tuning_and_odd_harmonics(midi):
    f = dsp.midi_to_freq(midi)
    a = P.clarinet().render(f, 0.6, 2.0, seed=1)
    assert abs(steady_cents(a, f)) < 3.0
    if midi <= 74:
        ft = analysis.features(a)
        assert abs(cents(ft["f0_hz"], f)) < 3.0
        x = a.data.astype(np.float64)[int(0.5 * SR): int(1.8 * SR)]
        S = np.abs(np.fft.rfft(x * np.hanning(len(x)), 1 << 18))
        fr = np.fft.rfftfreq(1 << 18, 1 / SR)
        h = lambda k: S[(fr > f * k * 0.98) & (fr < f * k * 1.02)].max()
        assert h(3) > 4 * h(2)  # cylinder: odd harmonics dominate


@pytest.mark.parametrize("name,midi_list", [("oboe", (60, 72, 84)), ("saxophone", (48, 60, 76)),
                                            ("flute", (62, 74, 88)), ("trumpet", (55, 67, 79)),
                                            ("trombone", (42, 54, 64)), ("horn", (45, 57, 70))])
def test_winds_tuned_across_range(name, midi_list):
    inst = P.ALL[name]()
    for midi in midi_list:
        f = dsp.midi_to_freq(midi)
        a = inst.render(f, 0.65, 2.0, seed=2)
        ft = analysis.features(a)
        assert abs(cents(ft["f0_hz"], f)) < 3.0, (name, midi, ft["f0_hz"], f)
        assert ft["voiced_fraction"] > 0.7


@pytest.mark.parametrize("name,midi_list", [("guitar", (43, 60, 80)), ("cello", (38, 52, 66)), ("violin", (58, 72, 90)),
                                            ("marimba", (48, 66, 88)), ("vibraphone", (55, 70, 85))])
def test_strings_and_bars_tuned_across_range(name, midi_list):
    inst = P.ALL[name]()
    for midi in midi_list:
        f = dsp.midi_to_freq(midi)
        a = inst.render(f, 0.7, 2.0, seed=3)
        ft = analysis.features(a)
        assert abs(cents(ft["f0_hz"], f)) < 3.0, (name, midi, ft["f0_hz"], f)


def test_piano_tuned_by_analysis_and_fundamental_present():
    inst = P.piano()
    for midi in (28, 40, 52, 64, 76, 88, 100):
        f = dsp.midi_to_freq(midi)
        a = inst.render(f, 0.7, 3.0, seed=1)
        ft = analysis.features(a)
        assert abs(cents(ft["f0_hz"], f)) < 3.0, (midi, ft["f0_hz"], f)
    # raw model: partial 1 exactly on the note, partials stretched by B
    a = ph.hammer_string(261.6, 3.0, inharmonicity=4e-4, strings=1)
    assert abs(cents(partial_peak(a, 261.6), 261.6)) < 1.0


def test_piano_inharmonicity_curve_and_double_decay():
    assert P.piano_inharmonicity(48) < P.piano_inharmonicity(72) < P.piano_inharmonicity(96)
    a = ph.hammer_string(220.0, 6.0, strings=3, detune_cents=0.5, decay=12.0, bridge_t60=1.5, inharmonicity=3e-4)
    x = a.data.astype(np.float64)
    from scipy import signal
    sos = signal.butter(4, [200, 240], "bandpass", fs=SR, output="sos")
    e = np.abs(signal.hilbert(signal.sosfilt(sos, x)))
    db = lambda t: 20 * np.log10(e[int(t * SR): int((t + 0.2) * SR)].mean() + 1e-12)
    early = (db(0.3) - db(1.3)) / 1.0
    late = (db(3.0) - db(5.0)) / 2.0
    assert early > 1.5 * late  # prompt sound decays faster than the aftersound


def test_modal_bar_ratios_and_bell_partials():
    f = 440.0
    a = ph.mallet_strike(ph.bar(f, "marimba", resonator=0.0), 1.5, velocity=0.9, mallet=ph.Mallet(0.9, 0.05), position=0.25)
    assert abs(cents(partial_peak(a, f, 0.0, 1.0), f)) < 1.0
    assert abs(cents(partial_peak(a, 4 * f, 0.0, 0.5, tol=0.02), 4 * f)) < 3.0
    m = ph.bell(f, "church", beat_hz=0)
    assert np.allclose(m.freqs[:2] / f, [0.5, 1.0], atol=0.004)
    b = ph.mallet_strike(m, 3.0, velocity=0.8)
    assert abs(cents(partial_peak(b, 0.5 * f, 0, 2.0), 0.5 * f)) < 3.0  # hum


def test_membrane_modes_timpani_vs_ideal():
    t = ph.membrane(100.0, "timpani")
    i = ph.membrane(100.0, "ideal")
    order = np.argsort(t.freqs)
    assert any(abs(t.freqs[j] / 100 - 1.5) < 0.01 for j in order)
    assert any(abs(i.freqs[j] / 100 - 1.340) < 0.01 for j in np.argsort(i.freqs))
    assert any(abs(i.freqs[j] / 100 - 0.628) < 0.01 for j in np.argsort(i.freqs))
    a = ph.mallet_strike(t, 2.0, velocity=0.8, position=0.5)
    assert abs(cents(partial_peak(a, 100.0, 0.0, 1.0), 100.0)) < 3.0


def test_fd_plate_lowest_mode_and_cfl():
    for model, f in (("plate", 180.0), ("membrane", 140.0)):
        a = ph.fd_plate(f, 1.5, model=model, aspect=1.3, pickups=((0.3, 0.4),), strike=(0.3, 0.4))
        x = a.data.astype(np.float64)
        n = 1 << 19
        S = np.abs(np.fft.rfft(x * np.hanning(len(x)), n))
        fr = np.fft.rfftfreq(n, 1 / SR)
        band = (fr > 0.9 * f) & (fr < 1.1 * f)
        peak = fr[band][np.argmax(S[band])]
        assert abs(peak / f - 1) < 0.03, (model, peak)
    with pytest.raises(ValueError):
        ph.fd_plate(-5.0, 1.0)


# ---------------------------------------------------------------- stability

EXTREME = [
    lambda: ph.pluck(55, 2.0, decay=60, decay_hf=1.0, inharmonicity=0.05, position=0.02, hardness=1.0, strings=4),
    lambda: ph.pluck(2000, 1.0, decay=0.05, decay_hf=0.01, inharmonicity=0.3, position=0.5, hardness=0.0),
    lambda: ph.hammer_string(30, 2.0, hammer=ph.Hammer(0.02, 1e12, 4.0, 5.0, 10.0, 0.3), velocity=None, strings=3),
    lambda: ph.hammer_string(2000, 1.0, hammer=ph.Hammer(1e-4, 1e7, 1.5, 0.0, 6.0, 20.0), velocity=None),
    lambda: ph.hammer_string(110, 2.0, velocity=1.0, strings=3, bridge_t60=0.05, sympathetic=[55, 165, 220, 330]),
    lambda: ph.bow(110, 1.5, speed=1.0, pressure=1.0, position=0.02, noise=1.0),
    lambda: ph.bow(110, 1.5, speed=0.02, pressure=0.0, position=0.5, noise=1.0),
    lambda: ph.bow(330, 1.5, speed=np.linspace(0, 0.8, 1000), pressure=np.linspace(1, 0, 500)),
    lambda: ph.reed(120, 1.0, pressure=1.2, zeta=1.0, stiffness=0.0, loss=0.001),
    lambda: ph.reed(120, 1.0, pressure=0.0),
    lambda: ph.reed(800, 1.0, pressure=0.9, bore="conical", zeta=0.9, apex=0.05, min_opening=0.3, noise=1.0, edge=1.0),
    lambda: ph.flute(200, 1.0, pressure=1.6, noise=1.0, jet_ratio=0.5),
    lambda: ph.flute(200, 1.0, pressure=0.0),
    lambda: ph.brass(150, 1.0, pressure=1.2, zeta=1.0, brassiness=1.0, lip_ratio=0.6, lip_q=10),
    lambda: ph.brass(150, 1.0, pressure=0.1, brassiness=0.0, lip_q=2),
    lambda: ph.mallet_strike(ph.bell(100, "gong", t60=60.0), 2.0, velocity=1.0, mallet=ph.Mallet(1.0, 1.0)),
    lambda: ph.fd_plate(2000, 0.5, model="stiff_membrane", stiffness_ratio=0.5, aspect=3.0, t60=0.1),
    lambda: ph.fd_plate(40, 1.0, model="plate", aspect=0.5, clamped=True, t60=9.0, t60_hf=9.0),
]


@pytest.mark.parametrize("i", range(len(EXTREME)))
def test_extreme_parameters_stay_finite_and_bounded(i):
    a = EXTREME[i]()
    assert isinstance(a, Audio)
    assert np.all(np.isfinite(a.data))
    assert np.abs(a.data).max() <= 1.0 + 1e-6


def test_long_render_no_energy_growth():
    a = ph.pluck(110, 30.0, decay=3.0, strings=3, bridge_t60=1.0, sympathetic=[220, 330], peak_db=None)
    x = a.data.astype(np.float64)
    seg = lambda t: np.sqrt(np.mean(x[int(t * SR): int((t + 1) * SR)] ** 2))
    assert seg(10) < seg(1) and seg(20) < seg(10) and seg(28) < 1e-3 * seg(0.5)


def test_bad_arguments_fail_loudly():
    with pytest.raises(ValueError):
        ph.pluck(-1.0)
    with pytest.raises(ValueError):
        ph.pluck(30000.0)
    with pytest.raises(ValueError):
        ph.reed(440.0, stiffness=3.0)
    with pytest.raises(ValueError):
        ph.bell(440.0, "kazoo")
    with pytest.raises(ValueError):
        ph.shoebox_ir((6, 4, 3), "plaster", source=(7, 1, 1))
    with pytest.raises(ValueError):
        ph.shoebox_ir((6, 4, 3), "velvet-nonexistent")


# ---------------------------------------------------------------- determinism

def test_determinism_and_take_variation():
    for fn in (lambda s: P.cello().render(130.8, 0.7, 1.5, seed=s),
               lambda s: P.clarinet().render(220.0, 0.7, 1.5, seed=s),
               lambda s: P.piano().render(220.0, 0.7, 2.0, seed=s),
               lambda s: P.bell("church").render(220.0, 0.7, 2.0, seed=s),
               lambda s: ph.spring_ir(1.0, seed=s),
               lambda s: ph.shoebox_ir((6, 4.5, 3), "plaster", seed=s, duration=1.0)):
        a, b, c = fn(5), fn(5), fn(6)
        assert np.array_equal(a.data, b.data)
        assert not np.array_equal(a.data, c.data) or fn is None


# ---------------------------------------------------------------- speed

@pytest.mark.parametrize("name", list(P.ALL))
def test_two_second_note_is_fast(name):
    inst = P.ALL[name]()
    lo, hi = inst.note_range
    f = dsp.midi_to_freq((lo + hi) // 2)
    t = time.time()
    a = inst.render(f, 0.7, 2.0, seed=1)
    dt = time.time() - t
    assert dt < 3.0, (name, dt)
    assert abs(a.duration - 2.0) < 0.35 or name in ("cello", "violin")


def test_rooms_fast():
    t = time.time()
    ph.room_preset("hall")
    ph.spring_ir(3.0)
    assert time.time() - t < 3.0
    t = time.time()
    ph.plate_ir(2.5)
    assert time.time() - t < 10.0


# ---------------------------------------------------------------- bodies, radiation, rooms

def test_body_colours_without_changing_pitch_or_level_much():
    a = ph.pluck(196.0, 2.0)
    for b in (ph.body.guitar("classical"), ph.body.violin(), ph.body.cello(), ph.body.soundboard()):
        y = b.apply(a)
        assert len(y) == len(a)
        assert abs(cents(partial_peak(y, 196.0), 196.0)) < 1.0
        assert abs(y.rms_db - a.rms_db) < 12.0
    h = ph.body.guitar().ir(SR)
    H = np.abs(np.fft.rfft(h.data, 1 << 15))
    fr = np.fft.rfftfreq(1 << 15, 1 / SR)
    assert H[np.argmin(abs(fr - 98))] > 1.5 * np.median(H[(fr > 500) & (fr < 4000)])  # air mode stands out


def test_air_absorption_and_distance():
    a_db = ph.body.air_absorption_db_per_m(np.array([1000.0, 4000.0, 10000.0]), 20.0, 50.0)
    assert 0.002 < a_db[0] < 0.008 and 0.02 < a_db[1] < 0.05 and 0.1 < a_db[2] < 0.25  # ISO 9613-1 at 20 C, 50%
    from libero import synth
    x = synth.noise("white", 1.0, SR, seed=1)
    y = ph.distance(x, 40.0)
    assert abs(y.rms_db - (x.rms_db - 20 * math.log10(40.0))) < 12.0
    Hx = np.abs(np.fft.rfft(x.data))
    Hy = np.abs(np.fft.rfft(y.data))
    fr = np.fft.rfftfreq(len(x), 1 / SR)
    lo = Hy[(fr > 500) & (fr < 1000)].mean() / Hx[(fr > 500) & (fr < 1000)].mean()
    hi = Hy[(fr > 12000) & (fr < 16000)].mean() / Hx[(fr > 12000) & (fr < 16000)].mean()
    assert hi < 0.4 * lo


def test_horn_radiation_and_off_axis_remove_highs_or_lows():
    from libero import synth
    x = synth.noise("white", 1.0, SR, seed=2)
    h = ph.horn_radiation(x, 1500.0, dry=0.0)
    assert h.lowpass(300).rms_db < x.lowpass(300).rms_db - 6
    o = ph.off_axis(x, 60.0, 0.1)
    assert o.highpass(6000).rms_db < x.highpass(6000).rms_db - 6


def test_room_ir_follows_eyring_rt60_and_is_stereo():
    dims = (8.0, 6.0, 3.5)
    for absorption in ("plaster", "carpet", {"all": "plaster", "floor": "carpet", "ceiling": "acoustic_tile"}):
        ir = ph.shoebox_ir(dims, absorption, sr=SR, seed=1)
        assert ir.channels == 2 and np.all(np.isfinite(ir.data))
        rt = ph.room.reverberation_time(dims, absorption)
        from scipy import signal
        bands = ((4, 2000), (5, 4000)) if absorption == "carpet" else ((2, 500), (3, 1000), (4, 2000))
        for band, fc in bands:  # octave band filtered decay vs Eyring (carpet: long bass tails leak into low bands)
            sos = signal.butter(4, [fc / 1.41, fc * 1.41], "bandpass", fs=SR, output="sos")
            x = signal.sosfilt(sos, ir.data[:, 0].astype(np.float64))
            e = np.cumsum((x ** 2)[::-1])[::-1]
            d = 10 * np.log10(e / e[0] + 1e-30)
            measured = 3 * (np.argmax(d < -25) - np.argmax(d < -5)) / SR
            assert 0.6 * rt[band] < measured < 1.7 * rt[band], (absorption, fc, measured, rt[band])
    # left and right are decorrelated, direct sound arrives at distance / c
    src, lis = (2.0, 3.0, 1.5), (6.0, 3.0, 1.5)
    ir = ph.shoebox_ir(dims, "plaster", source=src, listener=lis, sr=SR)
    first = int(np.argmax(np.abs(ir.data[:, 0]) > 0.3 * np.abs(ir.data[:, 0]).max()))
    assert abs(first / SR - 4.0 / cm.C_AIR) < 0.002
    L, R = ir.data[: 4000, 0].astype(float), ir.data[: 4000, 1].astype(float)
    assert abs(np.corrcoef(L, R)[0, 1]) < 0.98


def test_spring_and_plate_ir_shape():
    s = ph.spring_ir(2.0, length_ms=30, decay=2.0)
    assert s.channels == 2 and abs(s.duration - 2.0) < 0.01
    x = s.data[:, 0].astype(float)
    e = np.cumsum((x ** 2)[::-1])[::-1]
    d = 10 * np.log10(e / e[0] + 1e-30)
    t60 = 3 * (np.argmax(d < -25) - np.argmax(d < -5)) / SR
    assert 1.0 < t60 < 3.5
    p = ph.plate_ir(1.2, size=(0.5, 0.4))
    assert p.channels == 2 and np.all(np.isfinite(p.data))
    assert not np.allclose(p.data[:, 0], p.data[:, 1])


# ---------------------------------------------------------------- performance helpers and API

def test_breath_and_bow_stroke_shapes():
    b = ph.breath(2.0, 0.6, attack=0.1, release=0.2, tremor=0.0, overshoot=0.1)
    assert len(b) == 2 * SR and b[0] < 0.02 and b.max() > 0.6 and b[-1] < 0.02
    sp, pr = ph.bow_stroke(2.0, 0.3, 0.6)
    assert sp.max() <= 0.3 * 1.2 and sp[0] < 0.01 and sp[-1] < 0.01
    assert pr[0] < pr[SR] <= 0.6 + 1e-9
    v = ph.vibrato(2.0, 5.5, 20.0, onset=0.3)
    assert abs(v).max() > 10 and abs(v[: int(0.25 * SR)]).max() < 1.0
    a = ph.pitch_modulate(ph.pluck(220, 1.0, decay=20), 0.0)
    assert abs(cents(partial_peak(a, 220), 220)) < 0.5


def test_check_reports_a_good_note_and_a_bad_one():
    f = 220.0
    good = P.clarinet().render(f, 0.6, 2.0, seed=1)
    c = ph.check(good, f)
    assert c["finite"] and c["locked"] and abs(c["cents"]) < 3.0 and c["harmonic_fraction"] > 0.9
    assert abs(c["analysis_cents"]) < 3.0
    bad = ph.check(good, f * 1.5)
    assert not bad["locked"] or abs(bad["cents"]) > 100


def test_humanize_reproducible_and_bounded():
    a, b = ph.humanize(3, 1.0), ph.humanize(3, 1.0)
    assert a == b and ph.humanize(4, 1.0) != a
    assert ph.humanize(3, 0.0).pitch_cents == 0.0
    assert abs(a.pitch_cents) < 8 and abs(a.gain_db) < 3


def make_ctx(note=60, velocity=100, layer="body", seed=1):
    return Ctx(note=note, velocity=velocity, sr=SR, samples=Path("."), folder=Path("."), seed=seed, layer=layer,
               roots=(36, 60, 84), velocities=(60, 110))


def test_render_note_with_ctx_and_overrides():
    ctx = make_ctx(57, 90, seed=11)
    a = ph.render_note(P.guitar(), ctx, 2.0)
    b = ph.render_note(P.guitar(), 57, 90, 2.0, ctx=ctx)
    assert np.array_equal(a.data, b.data) and a.sr == SR
    c = ph.render_note(P.guitar(), "A3", 0.7, 1.0, sr=44100, seed=2, decay=1.0)
    assert c.sr == 44100
    d = ph.render_note(lambda f, v, dur, sr, seed: ph.pluck(f, dur, velocity=v, sr=sr, seed=seed), ctx.note, ctx.vel, 1.0, ctx=ctx)
    assert isinstance(d, Audio)
    h = ph.render_note(P.cello(), 48, 0.7, 1.5, humanise=1.0, seed=3)
    assert isinstance(h, Audio)


def test_instrument_with_through_and_convolved_room():
    g = P.guitar("steel")
    dark = g.with_(decay_hf=0.05).render(220.0, 0.7, 1.5, seed=1)
    bright = g.with_(decay_hf=0.9).render(220.0, 0.7, 1.5, seed=1)
    assert analysis.features(bright)["centroid_hz"] > analysis.features(dark)["centroid_hz"]
    wet = g.through(room=ph.room_preset("studio"), room_mix=0.4).render(220.0, 0.7, 1.0, seed=1)
    assert wet.duration > 1.0 and wet.is_stereo in (True, False)
    assert g.through(body=None).render(220.0, 0.7, 1.0).duration == pytest.approx(1.0, abs=0.01)


def test_all_presets_render_at_44100_and_96000():
    for sr in (44100, 96000):
        for name in ("guitar", "clarinet", "marimba", "trumpet"):
            inst = P.ALL[name]()
            f = dsp.midi_to_freq((inst.note_range[0] + inst.note_range[1]) // 2)
            a = inst.render(f, 0.6, 1.0, sr=sr, seed=1)
            assert a.sr == sr and np.all(np.isfinite(a.data))
            assert abs(steady_cents(a, f)) < 12.0 or name in ("marimba", "guitar")


# ---------------------------------------------------------------- guide and MCP wiring

GUIDE = Path(ph.__file__).resolve().parent.parent / "guides" / "physics.md"


def test_guide_recipes_run_and_render():
    text = GUIDE.read_text()
    blocks = re.findall(r"```python\n(.*?)```", text, re.S)
    recipes = [b for b in blocks if "@sound." in b]
    assert len(recipes) >= 10
    for code in recipes:
        ns: dict = {}
        exec(compile(code, "guide-recipe", "exec"), ns)
        sound = ns["sound"]
        for layer, fn in sound.layers.items():
            root = sound.roots[len(sound.roots) // 2]
            ctx = Ctx(note=root, velocity=int(sound.velocities[-1]), sr=SR, samples=Path("."), folder=Path("."), seed=3,
                      layer=layer, roots=sound.roots, velocities=sound.velocities)
            a = fn.fn(ctx)
            assert isinstance(a, Audio) and np.all(np.isfinite(a.data)) and a.duration > 0.5, code.splitlines()[2]


def test_guide_topic_served_by_mcp():
    import asyncio

    from libero import mcp_server

    async def go():
        return await mcp_server.mcp.call_tool("guide", {"topic": "physics"})

    out = asyncio.run(go())
    text = out[0][0].text if isinstance(out, tuple) else out.content[0].text
    assert "Troubleshooting" in text and "render_note" in text
    sd = (Path(ph.__file__).resolve().parent.parent / "guides" / "sound_design.md").read_text()
    assert "guide('physics')" in sd
