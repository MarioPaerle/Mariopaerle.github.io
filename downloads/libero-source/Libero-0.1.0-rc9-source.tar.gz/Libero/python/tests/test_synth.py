import numpy as np
import pytest

from libero import dsp, synth
from conftest import cents


@pytest.mark.parametrize("note", [28, 40, 52, 64, 76, 88, 100])
def test_karplus_in_tune(note):
    f = dsp.midi_to_freq(note)
    k = synth.karplus(f, 2.0, seed=note)
    assert abs(cents(k.f0(0.05, 1.5), f)) < 1.0
    assert np.isfinite(k.data).all() and k.peak_db < 0


def test_karplus_deterministic():
    a = synth.karplus(220, 1.0, seed=3)
    b = synth.karplus(220, 1.0, seed=3)
    assert np.array_equal(a.data, b.data)


@pytest.mark.parametrize("color,slope", [("white", 0), ("pink", -3), ("brown", -6), ("blue", 3)])
def test_noise_slopes(color, slope):
    from scipy import signal

    x = synth.noise(color, 8.0, seed=1).data.astype(float)
    f, p = signal.welch(x, 48000, nperseg=8192)
    lo = p[(f > 200) & (f < 400)].mean()
    hi = p[(f > 3200) & (f < 6400)].mean()
    measured = 10 * np.log10(hi / lo) / 4  # 4 octaves
    assert measured == pytest.approx(slope, abs=0.8)


def test_saw_band_limited():
    s = synth.saw(3000.0, 1.0)
    f = np.fft.rfftfreq(s.n, 1 / 48000)
    S = np.abs(np.fft.rfft(s.data))
    assert S[f > 21700].max() < 1e-3 * S.max()


@pytest.mark.parametrize("kind", ["room", "hall", "plate", "cave", "spring", "wood", "metal"])
def test_impulse_responses(kind):
    ir = synth.impulse_response(kind, seed=1)
    assert np.isfinite(ir.data).all()
    assert ir.peak_db == pytest.approx(-1.0, abs=0.2)


@pytest.mark.parametrize("preset", list(synth.MODES))
def test_modal_presets(preset):
    m = synth.modal(330.0, preset, 1.0)
    assert np.isfinite(m.data).all() and -7 < m.peak_db < 0


def test_formant_morph_and_bow():
    src = synth.saw(110, 1.0)
    v = synth.formant(src, [(0, "a"), (1, "o")])
    assert v.n == src.n and abs(v.rms_db - src.rms_db) < 0.5
    b = synth.bow(220.0, 1.5)
    assert abs(cents(b.f0(0.5, 1.2), 220.0)) < 5
    g = synth.bow(440.0, 1.5, body="glass")
    assert np.isfinite(g.data).all()
