import json

import numpy as np
import pytest

from libero import Audio, library, synth
from libero import sampletools as T
from libero.multisample import true_onset
from conftest import fake_recording


def test_onset_trim_and_align_set():
    layers = [fake_recording(60, lvl, br, pre_s=pre, seed=s)
              for lvl, br, pre, s in ((-20, 0.2, 0.031, 1), (-10, 0.5, 0.017, 2), (-3, 0.9, 0.044, 3))]
    out, rep = T.align_set(layers)
    ons = [true_onset(a.data, a.sr) for a in out]
    assert max(ons) - min(ons) <= int(0.0015 * 48000)
    assert sum(r.get("reference", False) for r in rep) == 1
    t = T.onset_trim(layers[0], pre_ms=2)
    assert abs(true_onset(t.data, t.sr) - 96) < 48


def test_ladder_report():
    layers = [fake_recording(57, lvl, br, seed=i) for i, (lvl, br) in enumerate(((-20, 0.15), (-12, 0.5), (-4, 0.95)))]
    rep = T.ladder(layers)
    assert rep["monotonic_level"] and rep["monotonic_brightness"]
    assert all(s > 3 for s in rep["steps_db"])
    flat = T.ladder([layers[2].gain_db(-12), layers[2]])
    assert not flat["monotonic_brightness"] or abs(flat["brightness_steps_db"][0]) < 1


@pytest.mark.parametrize("kind", ["damper", "room", "bloom"])
def test_release_from(kind):
    body = fake_recording(48, -6, 0.6, seconds=3)
    rel = T.release_from(body, kind, 0.6)
    assert abs(rel.duration - 0.6) < 0.01 and rel.peak_db < body.peak_db + 3
    assert np.isfinite(rel.data).all() and abs(rel.data[-1]).max() < 1e-3


def test_morph_between_layers():
    a = fake_recording(60, -18, 0.2, seed=1)
    b = fake_recording(60, -4, 0.9, seed=1)
    m = T.morph(a, b, 2)
    assert len(m) == 2 and all(abs(x.n - min(a.n, b.n)) < 8 for x in m)
    lv = [x.lufs_max for x in (a, m[0], m[1], b)]
    assert lv[0] < lv[1] < lv[2] < lv[3]


def test_design_processors():
    src = fake_recording(55, -6, 0.6, seconds=2)
    fr = T.freeze(src, at=0.5, seconds=3)
    assert abs(fr.duration - 3) < 0.01 and fr.rms_db > -80
    gr = T.granular(src, seconds=2, density=30, seed=2)
    assert gr.is_stereo and abs(gr.duration - 2) < 0.01
    tp = T.tape(src, wow=0.5, flutter=0.3, sat=0.3, age=0.5)
    assert tp.n == src.n and np.isfinite(tp.data).all()
    rs = T.reverse_swell(src, seconds=1.5)
    assert abs(rs.duration - 1.5) < 0.05 and rs.data[:100].std() < rs.data[-4800:].std()
    sp = T.stretch_pad(src, factor=3, at=0.2, seconds=0.5)
    assert abs(sp.duration - 1.5) < 0.05


def test_split_runs():
    notes = [fake_recording(n, -6, 0.6, seconds=0.7, pre_s=0.0, stereo=False).fade_out(0.2) for n in (60, 62, 64)]
    run = notes[0].concat(Audio.silence(0.4), notes[1], Audio.silence(0.4), notes[2])
    parts = T.split_runs(run)
    assert [n for n, _ in parts] == [60, 62, 64]
    assert [n for n, _ in T.split_runs(run, first_note="C4", step=2)] == [60, 62, 64]
