import json
import shutil
import textwrap

import pytest
import soundfile as sf

from libero import library
from libero.compiler import compile_sound
from conftest import REPO


def test_template_compiles_to_valid_bundle():
    folder = library.new_sound("plk", "plucked", "Plk")
    res = compile_sound(folder)
    assert res.ok, res.error
    build = folder / "build"
    assert library.validate_bundle(build) == []
    m = json.loads((build / "manifest.json").read_text())
    assert m["format"] == "libero.bundle/1" and m["slug"] == "plk"
    assert m["source_hash"] == library.source_hash(folder)
    layers = {z["layer"] for z in m["zones"]}
    assert layers == {"body", "attack", "tail", "air"}
    air = [z for z in m["zones"] if z["layer"] == "air"]
    assert len(air) == 1 and air[0]["loop"] is not None and not air[0]["pitched"]
    for z in m["zones"]:
        info = sf.info(str(build / z["file"]))
        assert info.subtype == "FLOAT" and info.samplerate == m["sample_rate"]
        a, _ = sf.read(str(build / z["file"]))
        assert abs(a).max() <= 10 ** (-1 / 20) + 1e-4  # limited to -1 dBFS
    assert m["ir"] == "ir.wav" and (build / "ir.wav").exists()
    assert m["params"]["rev_mode"] == "Cappella"

    # recompiling unchanged sources renders nothing
    res2 = compile_sound(folder)
    assert res2.ok and "0 files rendered" in res2.summary
    # editing only defaults() re-renders nothing either
    sp = folder / "sound.py"
    sp.write_text(sp.read_text().replace("rev_mix=0.18", "rev_mix=0.3"))
    res3 = compile_sound(folder)
    assert res3.ok and "0 files rendered" in res3.summary
    assert json.loads((build / "manifest.json").read_text())["params"]["rev_mix"] == 0.3


def test_looped_template_has_good_loops():
    folder = library.new_sound("pd", "pad")
    res = compile_sound(folder)
    assert res.ok, res.error
    m = json.loads((folder / "build" / "manifest.json").read_text())
    body = [z for z in m["zones"] if z["layer"] == "body"]
    assert all(z["loop"] and z["loop"]["end"] - z["loop"]["start"] > 48000 for z in body)
    assert not [w for w in res.warnings if "seam" in w]


def _sketch_with(code: str, slug: str = "bad"):
    folder = library.new_sound(slug, "plucked")
    (folder / "sound.py").write_text(textwrap.dedent(code))
    return folder


def test_recipe_timeout_is_killed():
    folder = _sketch_with("""
        from libero import Sound, synth
        sound = Sound(title="Loop", roots=[60])
        @sound.body
        def body(ctx):
            while True:
                pass
    """)
    res = compile_sound(folder, timeout=8, jobs=1)
    assert not res.ok and "timed out" in res.error
    assert not list(folder.glob(".build.tmp-*"))


def test_recipe_errors_are_reported():
    folder = _sketch_with("""
        from libero import Sound, synth
        sound = Sound(title="Err", roots=[60])
        @sound.body
        def body(ctx):
            return 42
    """)
    res = compile_sound(folder)
    assert not res.ok and "expected Audio" in res.error

    folder = _sketch_with("""
        from libero import Sound
        sound = Sound(title="Err", roots=[60])
        @sound.body
        def body(ctx):
            return None
        sound.defaults(rev_mix=3.0)
    """, "bad2")
    res = compile_sound(folder)
    assert not res.ok and "rev_mix" in res.error


def test_nan_is_rejected():
    folder = _sketch_with("""
        import numpy as np
        from libero import Sound, Audio
        sound = Sound(title="Nan", roots=[60])
        @sound.body
        def body(ctx):
            x = np.zeros(1000); x[10] = np.nan
            return Audio(x, ctx.sr)
    """)
    res = compile_sound(folder)
    assert not res.ok and "NaN" in res.error


@pytest.mark.parametrize("slug", ["lira", "vetro", "coro-di-marmo"])
def test_examples_compile_clean(slug, libero_home):
    dst = libero_home / "sketches" / slug
    shutil.copytree(REPO / "sounds" / slug, dst, ignore=shutil.ignore_patterns("build"))
    res = compile_sound(dst)
    assert res.ok, res.error
    assert library.validate_bundle(dst / "build") == []
    # the only acceptable warning for the repo examples is the missing figure (drawn separately)
    assert [w for w in res.warnings if "figure.svg" not in w] == []


TAKES_RECIPE = """
    from libero import Sound, synth
    sound = Sound(title="Aulos", roots=[57, 69], takes={takes})
    seen = []
    @sound.body
    def body(ctx):
        assert 0 <= ctx.take < ctx.takes
        # a breathy tone whose noise differs per take (ctx.seed changes with ctx.take)
        tone = synth.sine(ctx.freq, 0.5, sr=ctx.sr).gain_db(-12)
        air = synth.noise("pink", 0.5, sr=ctx.sr, seed=ctx.seed).lowpass(3000).gain_db(-30)
        return tone.mix(air)
    @sound.attack
    def attack(ctx):
        return synth.noise("white", 0.02, sr=ctx.sr, seed=ctx.seed).gain_db(-20)
"""


def test_takes_compile_to_round_robin_zones():
    folder = _sketch_with(TAKES_RECIPE.format(takes=3), "rr")
    res = compile_sound(folder)
    assert res.ok, res.error
    build = folder / "build"
    assert library.validate_bundle(build) == []
    m = json.loads((build / "manifest.json").read_text())
    body = [z for z in m["zones"] if z["layer"] == "body"]
    attack = [z for z in m["zones"] if z["layer"] == "attack"]
    assert sorted((z["root"], z["take"]) for z in body) == [(57, 0), (57, 1), (57, 2), (69, 0), (69, 1), (69, 2)]
    assert sorted(z["file"] for z in attack) == ["attack_t0.wav", "attack_t1.wav", "attack_t2.wav"]
    assert "body_n057_v100_t1.wav" in {z["file"] for z in body}
    # takes of one zone share its key range and really differ
    t = {z["take"]: z for z in body if z["root"] == 57}
    assert len({(z["lo"], z["hi"]) for z in t.values()}) == 1
    a0, _ = sf.read(str(build / t[0]["file"]))
    a1, _ = sf.read(str(build / t[1]["file"]))
    assert abs(a0 - a1).max() > 1e-4
    assert "takes 3" in res.summary

    # take 0 is the single-take zone: going from 3 to 4 takes renders only the new take,
    # going back to 1 renders nothing and drops the "take" keys
    sp = folder / "sound.py"
    sp.write_text(sp.read_text().replace("takes=3", "takes=4"))
    res4 = compile_sound(folder)
    assert res4.ok, res4.error
    assert "3 files rendered" in res4.summary  # 2 body roots + 1 attack for take 3
    sp.write_text(sp.read_text().replace("takes=4", "takes=1"))
    res1 = compile_sound(folder)
    assert res1.ok and "0 files rendered" in res1.summary
    m1 = json.loads((build / "manifest.json").read_text())
    assert all("take" not in z for z in m1["zones"])
    b0, _ = sf.read(str(build / "body_n057_v100.wav"))
    assert (b0 == a0).all()


def test_takes_are_validated():
    with pytest.raises(Exception, match="takes"):
        from libero.recipe import Sound
        Sound(title="x", takes=0)
    folder = _sketch_with(TAKES_RECIPE.format(takes=2), "rr2")
    assert compile_sound(folder).ok
    build = folder / "build"
    mp = build / "manifest.json"
    m = json.loads(mp.read_text())
    good = json.dumps(m)
    # a gap in the takes of a zone
    for z in m["zones"]:
        if z["layer"] == "body" and z["root"] == 57 and z["take"] == 1:
            z["take"] = 2
    mp.write_text(json.dumps(m))
    assert any("takes [0, 2]" in p for p in library.validate_bundle(build))
    # a non-integer take
    m = json.loads(good)
    m["zones"][0]["take"] = "one"
    mp.write_text(json.dumps(m))
    assert any("take must be an integer" in p for p in library.validate_bundle(build))
    # a missing "take" is take 0: two zones on the same keys without takes overlap
    m = json.loads(good)
    for z in m["zones"]:
        z.pop("take", None)
    mp.write_text(json.dumps(m))
    assert any("takes [0, 0]" in p for p in library.validate_bundle(build))


def test_retitle_and_appended_defaults_keep_the_cache():
    # What the plugin's "Salva come…" appends to a copied recipe.
    folder = library.new_sound("rt", "plucked", "Prima")
    assert compile_sound(folder).ok
    sp = folder / "sound.py"
    sp.write_text(sp.read_text() + '\n# Saved from the plugin\nsound.retitle("Seconda \\u00e8 meglio")\n'
                  'sound.defaults(rev_mix=0.5, dyn_mode="Velocit\\u00e0", mode="Legato")\n')
    res = compile_sound(folder)
    assert res.ok, res.error
    assert "0 files rendered" in res.summary
    m = json.loads((folder / "build" / "manifest.json").read_text())
    assert m["title"] == "Seconda è meglio"
    assert m["params"]["rev_mix"] == 0.5 and m["params"]["mode"] == "Legato" and m["params"]["dyn_mode"] == "Velocità"
    from libero.recipe import Sound, RecipeError
    with pytest.raises(RecipeError):
        Sound(title="x").retitle("  ")
    s = Sound(title="x", subtitle="a").retitle("y", subtitle="b")
    assert (s.title, s.subtitle) == ("y", "b")


def test_oscillator_only_sound_compiles_to_zoneless_bundle():
    folder = _sketch_with("""
        from libero import Sound
        sound = Sound(title="Sintesi", roots=[60])
        sound.defaults(osc1_level=-6, osc1_wave="Sega", osc1_voices=5, osc1_phase=0.2,
                       fenv_source="Propria", flt_env=0.5, flt_cutoff=800)
    """, "synth")
    res = compile_sound(folder)
    assert res.ok, res.error
    m = json.loads((folder / "build" / "manifest.json").read_text())
    assert m["format"] == "libero.bundle/2" and m["zones"] == []
    assert m["params"]["osc1_level"] == -6 and m["params"]["fenv_source"] == "Propria"
    assert library.validate_bundle(folder / "build") == []

    # without a body and without an oscillator the sound would be silent: refused
    silent = _sketch_with("""
        from libero import Sound
        sound = Sound(title="Muto", roots=[60])
        sound.defaults(osc1_wave="Quadra")
    """, "muto")
    res = compile_sound(silent)
    assert not res.ok and "oscillator" in res.error


def test_validate_bundle_onset_and_zoneless_rules():
    folder = _sketch_with(TAKES_RECIPE.format(takes=1), "onset")
    assert compile_sound(folder).ok
    build = folder / "build"
    mp = build / "manifest.json"
    m = json.loads(mp.read_text())
    m["onset_ms"] = 11.7
    m["zones"][0]["onset_ms"] = 12.0
    mp.write_text(json.dumps(m))
    probs = library.validate_bundle(build)
    assert any("bundle/2" in p for p in probs)          # onset_ms needs bundle/2
    m["format"] = "libero.bundle/2"
    mp.write_text(json.dumps(m))
    assert library.validate_bundle(build) == []
    m["onset_ms"] = -1
    mp.write_text(json.dumps(m))
    assert any("onset_ms" in p for p in library.validate_bundle(build))
    # zones: [] is fine in bundle/2 only when an oscillator is on
    m["onset_ms"] = 0
    m["zones"] = []
    mp.write_text(json.dumps(m))
    assert any("no oscillator" in p for p in library.validate_bundle(build))
    m["params"]["osc2_level"] = -3
    mp.write_text(json.dumps(m))
    assert library.validate_bundle(build) == []


def test_performance_onset_ms_reaches_the_manifest(tmp_path):
    from libero.recipe import Sound, RecipeError
    snd = Sound(title="t").performance(onset_ms=10.5)
    assert snd.performance_spec["onset_ms"] == 10.5
    import pytest
    with pytest.raises(RecipeError):
        Sound(title="t").performance(onset_ms=500)
