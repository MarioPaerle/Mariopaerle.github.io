# libero (Python)

The Python authoring tools: a recipe API, DSP workbench, audio analysis,
bundle compiler and an MCP server for compatible clients.
The on-disk formats are defined in [`../SPEC.md`](../SPEC.md).

```
libero/
  audio.py        Audio: immutable, chainable buffer (trim, pitch, stretch, tune_to, filters,
                  convolve, place, transient, envelope, noise_floor, loop_points, loudness …)
  synth.py        band-limited oscillators, additive, FM, Karplus–Strong, modal banks, noise,
                  breath, bow, formants, synthetic impulse responses, LoopGrid
  dsp.py          YIN pitch, biquads, resampling, limiter, BS.1770 loudness, onsets
  analysis.py     spectrogram / waveform / compare PNGs, features() + compact text
  params.py       the live parameter table (SPEC §5) as data
  recipe.py       Sound, Ctx, decorators, multisample(), performance(), dynamics (SPEC §3)
  compiler.py     sound folder → build/ bundle (SPEC §4, bundle/1 and /2), subprocess + timeout, caches
  multisample.py  editing recorded regions: onset trim, phase alignment, tuning, level ladder, loops
  sampletools.py  onset/align/ladder, release synthesis, layer morph, freeze/granular/tape/swell, split
  lint.py         `libero lint`: objective checks of a compiled bundle
  families.py     per-family presets (piano, plucked, mallet, bowed, wind, brass, voice, …)
  physics/        physical modelling (numba): waveguide strings (pluck / felt hammer / bow friction),
                  reeds, flute, brass, modal bars/bells/membranes, FD plates, bodies, rooms, presets
  licenses.py     licence classes, credits, the bundle's resulting licence
  ingest/         catalog of legal libraries, subset fetching, SFZ parser, SFZ / WAV-set importers
  library.py      ~/Libero layout, sketches/sounds, safe file access, validate_bundle()
  render.py       previews through libero-render (SPEC §7)
  plugin.py       agent-socket client for running plugin instances (SPEC §6)
  download.py     URL / local import, Freesound search + download, attribution
  figure.py       figure.svg checks (SPEC §8) and rasterisation
  workbench.py    free-form snippets in a subprocess (trusted code only)
  mcp_server.py   the MCP server (stdio)
  cli.py          the `libero` command
  templates/      starting recipes: plucked, bell, pad, bowed, percussion, hybrid
  guides/         sound_design.md, sampled.md, physics.md, fast.md, slow.md, figures.md (served by the MCP)
scripts/install_examples.py
scripts/demo_pianoforte.py   renders the piano demo through libero-render
scripts/physics_showcase.py  renders short physical-model notes + spectrograms to ~/Libero/demo/physics
tests/
```

## Install

Requires [uv](https://docs.astral.sh/uv/) and Python 3.12 (uv fetches it).

```sh
cd python
uv sync                    # creates .venv with everything, including pytest
uv run pytest -q           # optional: the test suite (~1 min)
```

or install the commands globally, editable from this checkout:

```sh
uv tool install -e python/
libero list
```

The library lives in `$LIBERO_HOME` (default `~/Libero`). Previews need the
`libero-render` binary from the plugin build (`scripts/build.sh`;
`scripts/install.sh` puts it in `~/.local/bin`); it is also found in the
repo's `build/` tree or through `$LIBERO_RENDER`. Freesound needs an API key
in `FREESOUND_API_KEY` or `"freesound_api_key"` in `~/Libero/config.json`.

## The command line

```sh
libero new lira-2 -t plucked --title "Lira II"   # sketch from a template
libero compile lira-2                            # → ~/Libero/sketches/lira-2/build
libero preview lira-2 "48 60 72" --png out.png   # render through libero-render
libero validate lira-2                           # check the bundle against SPEC §4
libero save lira-2                               # sketch → library
libero discard some-sketch                       # to the Trash (recoverable)
libero mcp                                       # the MCP server on stdio

libero library search "grand piano"              # legal sources, best first
libero library fetch salamander-grand-v3 --subset layers8
libero import pianoforte salamander-grand-v3:"Salamander Grand Piano V3.sfz" -f piano --title Pianoforte
libero compile pianoforte && libero lint pianoforte
libero library usage | prune                     # cache sizes / drop unused edited-region caches
```

Install the example sounds (copies `sounds/*` into the library and compiles):

```sh
uv --directory python run python scripts/install_examples.py            # into ~/Libero/sounds
uv --directory python run python scripts/install_examples.py --sketches # or as sketches
```

## Registering the MCP server

The server speaks MCP over stdio. The command is the same for every client:

```sh
uv --directory /absolute/path/to/Libero/python run libero-mcp
```

Clients configured with an `mcpServers` block use:

```json
{
  "mcpServers": {
    "libero": {
      "command": "uv",
      "args": ["--directory", "/absolute/path/to/Libero/python", "run", "libero-mcp"],
      "env": { "LIBERO_HOME": "/Users/you/Libero" }
    }
  }
}
```

`env` is optional. Give `uv` as an absolute path (e.g. `/Users/you/.local/bin/uv`)
if the client does not inherit your shell's PATH.

Start a conversation with: *read `guide("sound_design")`, then make me …*

## What the MCP offers

- **Guides**: `guide(sound_design | figures | recipe_api | params)`, `params_reference`
- **Sounds**: `sound_new`, `sound_list`, `sound_read`, `sound_write`, `sound_save`, `sound_discard`
- **Samples**: `sample_list`, `sample_import`, `freesound_search`, `freesound_download`,
  `workbench` (free-form Python, trusted code only), `sample_trim`, `sample_pitch`, `sample_stretch`,
  `sample_layer`, `sample_convolve`, `sample_filter`, `sample_fade`, `sample_normalize`,
  `sample_noise_floor`, `sample_attach_transient`, `synth_generate`
- **Recorded instruments**: `library_search`, `library_info`, `library_fetch`, `import_sfz`,
  `import_wav_set`, `family_preset`, `lint`, `sound_licenses`, `sample_trim_onset`, `sample_align`,
  `sample_ladder`, `sample_release`, `sample_morph`, `sample_texture`, `sample_split`
- **Analysis** (images the model can see): `analyze`, `spectrogram`, `waveform`, `compare`
- **Build**: `compile`, `preview`, `figure_view`
- **Live plugin**: `plugin_instances`, `plugin_load`, `plugin_get_params`, `plugin_set_params`,
  `plugin_play`, `plugin_status`

## Recorded instruments

`guide("sampled")` documents recording acquisition and import.
The catalogue (`libero/ingest/catalog.py`)
lists legal sources with their licence class (`cc0`, `by`, `by-sa` are shippable; `nc`, `eula`,
`unknown` are a private lane); `library_fetch` downloads only a subset into
`~/Libero/cache/libraries/` (GitHub tree API + raw files; `sfz:<file>` fetches exactly what an SFZ
uses; Zenodo archives are filtered while streaming), refusing more than `max_mb` (1500) and asking
for `confirm` above 500 MB. `GITHUB_TOKEN`/`GH_TOKEN` or a logged-in `gh` raise GitHub's API rate
limit. Importers link the chosen files into the sketch's `samples/`, write `samples/map.json`
(the regions) and a `sound.py` from the family preset, and record credits. The compiler then edits
the recordings (true-onset trim, phase alignment of layers, stretch-aware tuning, a calibrated level
ladder without per-file normalisation, register-dependent lengths, loops) and writes 24-bit FLAC
zones with continuous dynamics layers (bundle/2). SFZ bake mode through `sfizz_render` is not
included: sfizz is not installable user-locally here, and the structural importer covers the
libraries in the catalogue (including Salamander's `#define`/`#include` control surface).

## Behaviour worth knowing

- Recipes and workbench snippets execute Python with your user permissions.
  They run in a separate process with a timeout, but can access files outside
  the sound folder and inherit environment variables. Only run trusted code.
  The workbench blocks Python socket calls and attempts a macOS network-denial
  profile when available; this is not a security sandbox. On other platforms,
  or if that profile is unavailable, native libraries and child processes are
  not contained by the Python socket patch. Use a separate disposable environment
  without private data or credentials for unfamiliar code.
- Zones are cached in `~/Libero/cache/zones` by a hash of the recipe (its
  AST without `defaults()` and metadata), `samples/` and the library code, so
  editing defaults, titles or comments recompiles instantly.
- Compiled zones get DC removal, a 16-sample fade-in, a 5 ms fade-out when not
  looped, and a transparent peak limiter at −1 dBFS; the compiler warns about
  detuning, aliasing, loop seams and loudness spread across roots.
- Unpitched attack/tail layers are rendered once per velocity layer
  (`attack_v064.wav`, …) when a sound has several velocities, else once
  (`attack.wav`).
- Nothing is ever hard-deleted: discarded sketches move to the Trash.
