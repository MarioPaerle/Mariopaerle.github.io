#!/usr/bin/env bash
# Libero plugin/engine tests. Run after scripts/build.sh.
#
#   plugin/tests/run_tests.sh [--ui] [--installed]
#
#   --ui          also open the real editor (a window appears for ~5 s) and check the WebView
#                 page, the relays, the native functions and the scope/soundChanged events
#   --installed   also validate the installed plugins (auval, Carla discovery arm64 + x86_64)
#
# Everything writes under plugin/tests/out and uses a private LIBERO_HOME; ~/Libero is untouched.
set -uo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
root="$(cd "$here/../.." && pwd)"
build="${LIBERO_BUILD_DIR:-$root/build}"
test_python="${LIBERO_TEST_PYTHON:-python3}"
if [ -z "${LIBERO_TEST_PYTHON:-}" ] && [ -x "$root/python/.venv/bin/python" ]; then
    test_python="$root/python/.venv/bin/python"
fi
art="$build/plugin"

render="$art/libero_render_artefacts/Release/libero-render"
host="$art/libero_host_test_artefacts/Release/libero-host-test"
vst3="$art/Libero_artefacts/Release/VST3/Libero.vst3"
au="$art/Libero_artefacts/Release/AU/Libero.component"

with_ui=0
with_installed=0
for a in "$@"; do
    case "$a" in
        --ui) with_ui=1 ;;
        --installed) with_installed=1 ;;
        *) echo "unknown option $a" >&2; exit 2 ;;
    esac
done

failed=0
step() { echo; echo "== $*"; }
result() { if [ "$1" -eq 0 ]; then echo "PASS: $2"; else echo "FAIL: $2"; failed=1; fi; }

step "architectures"
for f in "$vst3/Contents/MacOS/Libero" "$au/Contents/MacOS/Libero" "$render" "$host"; do
    info="$(lipo -info "$f" 2>&1)"
    echo "$info"
    [[ "$info" == *x86_64* && "$info" == *arm64* ]]
    result $? "universal $(basename "$f")"
done

step "fixtures"
mkdir -p "$here/out" "$here/fixtures"
python3 "$here/make_test_bundle.py" "$here/fixtures/test-tone" >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-noir" --no-ir --rate 48000 --pads >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-takes" --takes 3 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-dyn" --dyn 3 --rt-decay 12 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-dyn-hard" --dyn 3 --dyn-xf 0 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-dyn-hard-cc" --dyn 3 --dyn-xf 0 --dyn-source cc1 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-dyn-attack" --dyn 3 --dyn-attack 3 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-osc" --osc-only >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-onset" --onset-ms 20 --rate 48000 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-onset-ref" --onset-ms 20 --onset-undeclared --rate 48000 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-human" --humanize 5,4,1 --tune-cents 30 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-rr" --takes 3 --rr-reset 300 >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-drums" --drums >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-artic" --artic >/dev/null &&
python3 "$here/make_test_bundle.py" "$here/fixtures/test-streaming" --rate 48000 --dyn 3 --dyn-xf 0 --no-ir --no-loops >/dev/null
result $? "test bundles"

step "libero-render"
python3 "$here/test_render.py" "$render" "$here/fixtures"
result $? "renderer tests"

step "oscillators, LFO, filter envelope, onset_ms"
python3 "$here/test_osc.py" "$render" "$here/fixtures"
result $? "oscillator tests"

step "libero-render under Rosetta (x86_64 slice)"
if arch -x86_64 /usr/bin/true 2>/dev/null; then
    arch -x86_64 "$render" --sound "$here/fixtures/test-tone" --out "$here/out/x86.wav" --notes "60:0:1:100" >/dev/null &&
    arch -x86_64 "$render" --sound "$here/fixtures/test-tone" --out "$here/out/x86b.wav" --notes "60:0:1:100" >/dev/null &&
    cmp -s "$here/out/x86.wav" "$here/out/x86b.wav"
    result $? "x86_64 render runs and is deterministic"
else
    echo "Rosetta not available, skipped"
fi

step "UI override (developer escape hatch)"
ovr="$here/out/ovr-home"
mkdir -p "$ovr/ui-override/js"
printf '<!doctype html><title>override</title>' > "$ovr/ui-override/index.html"
printf 'export const x = 1;' > "$ovr/ui-override/js/x.js"
embedded="$(LIBERO_HOME="$here/out/nohome" "$host" --resource /)"
overridden="$(LIBERO_HOME="$ovr" "$host" --resource /)"
js="$(LIBERO_HOME="$ovr" "$host" --resource /js/x.js)"
escape="$(LIBERO_HOME="$ovr" "$host" --resource /../index.html)"
interop="$(LIBERO_HOME="$ovr" "$host" --resource /juce/index.js)"
echo "embedded: $embedded"; echo "override: $overridden"; echo "js: $js"; echo "escape: $escape"
[[ "$embedded" == text/html* && "$embedded" != *override* && "$overridden" == *"<title>override"* \
   && "$js" == "text/javascript export const x"* && "$escape" == none* && "$interop" == text/javascript* ]]
result $? "~/Libero/ui-override/ replaces the embedded UI (and stays inside its folder)"

step "visualisation collection lifecycle"
LIBERO_HOME="$here/out/visualisation-home" "$host" --visualisation-check
result $? "visualisation stops without a visible editor and resumes when enabled"

step "shared samples and cache invalidation"
LIBERO_HOME="$here/out/cache-home" "$host" --sample-cache-check "$here/fixtures/test-tone"
result $? "shared PCM, isolated edits, invalidation, release and concurrent loads"

step "persistent window size"
LIBERO_HOME="$here/out/editor-size-home" "$host" --editor-size-check
result $? "immediate close, independent instances and DAW state restore"

step "bounded full audio validation"
LIBERO_SAMPLE_STREAMING=1 LIBERO_HOME="$here/out/stream-validation-home" "$host" --stream-validation-check "$here/fixtures/test-streaming"
result $? "parallel full scan accepts valid audio and rejects truncated bodies"

step "sample streaming, resident fallback and failed reads"
LIBERO_SAMPLE_STREAMING=1 LIBERO_HOME="$here/out/stream-storage-home" "$host" --stream-storage-check "$here/fixtures/test-streaming"
result $? "loops/edits/legato fallbacks, held-note continuity and offline rendering"
"$host" --stream-failure-check
result $? "missing files, copied leases and fixed stream capacity"
for rate in 44100 48000 96000; do
    LIBERO_SAMPLE_STREAMING=1 LIBERO_HOME="$here/out/stream-parity-home" "$host" --streaming-check "$here/fixtures/test-streaming" "$rate"
    result $? "streamed render equals resident render at $rate Hz"
done

step "unheard voice replacements"
LIBERO_HOME="$here/out/unheard-home" "$host" --unheard-voice-check "$here/fixtures/test-osc" "$here/fixtures/test-drums"
result $? "simultaneous over-limit and choke notes produce only the retained instrument"

step "rapid dense-chord turnover"
LIBERO_HOME="$here/out/voice-stress-home" "$host" --voice-stress-profile "$here/fixtures/test-osc" 2 48000 128
result $? "rapid polyphony overload remains finite and Panic clears every voice"

step "host and audition MIDI stream merge"
LIBERO_HOME="$here/out/midi-merge-home" "$host" --midi-merge-check "$here/fixtures/test-tone"
result $? "merged MIDI preserves sample offsets, tie order and SysEx boundaries"

step "concurrent audition producers and note-off capacity"
LIBERO_HOME="$here/out/audition-home" "$host" --audition-queue-check "$here/fixtures/test-osc"
result $? "concurrent UI/agent audition overload leaves no sustained notes"

step "concurrent sound and IR handoff, loader teardown"
LIBERO_HOME="$here/out/transition-home" "$host" --sound-transition-check "$here/fixtures/test-tone" "$here/fixtures/test-noir"
result $? "64 concurrent sound/IR switches and 24 loader teardown cycles"

step "resampling cache and cancelled loads"
LIBERO_HOME="$here/out/rate-cache-home" LIBERO_DISABLE_SAMPLE_CACHE=1 "$host" --loading-cache-check "$here/fixtures/test-tone"
result $? "lossless disk cache, corruption recovery and load cancellation"

step "initial sound selection"
LIBERO_HOME="$here/out/initial-load-home" "$host" --initial-load-check "$here/fixtures/test-tone"
result $? "default loads without overriding an explicit sound choice"

step "agent socket (headless host)"
python3 "$here/test_socket.py" "$host" "$here/fixtures/test-tone"
result $? "socket tests"

step "sample waveform editing"
sample_options=()
if [ "$with_ui" -eq 1 ]; then sample_options+=(--ui); fi
"$test_python" "$here/test_sample_editor.py" "$host" "$here/fixtures/test-artic" ${sample_options[@]+"${sample_options[@]}"}
result $? "sample editor tests"

step "batch bank imports"
"$test_python" "$here/test_bank_collection.py" "$host" "$here/fixtures/test-tone"
result $? "batch import tests"

if [ "$with_ui" -eq 1 ]; then
    step "editor (WebView)"
    mkdir -p "$here/out/libero-home/banks/test-bank"
    echo '{"format":"libero.bank/1","slug":"test-bank","title":"Banco di prova","subtitle":"","description":"","version":"1.0.0","author":"","license":"CC0","figure":null}' > "$here/out/libero-home/banks/test-bank/bank.json"
    # A library sound with a preview (build/preview.wav), for the play-button checks.
    pvd="$here/out/libero-home/sounds/test-preview"
    rm -rf "$pvd" && mkdir -p "$pvd" && cp -R "$here/fixtures/test-tone/build" "$pvd/build" &&
    "$render" --sound "$pvd" --out "$pvd/build/preview.wav" --notes "60:0:1:100" --tail 0.5 >/dev/null
    full="$(LIBERO_HOME="$here/out/libero-home" "$host" --ui-check "$here/fixtures/test-tone" "$root/sounds/vetro" "$here/fixtures/test-artic" 2>/dev/null)"
    out="$(echo "$full" | tail -1)"
    writes="$(echo "$full" | grep '^ui-writes ' | sed 's/^ui-writes //')"
    echo "$out"
    echo "ui writes: $writes"
    # rev_mix set through the relay API, flt_mode index 2 of 4, rev_size dragged up by the UI's own handler;
    # dragging tape_age switches the tape on (tape_mix auto-engage).
    python3 -c '
import json, sys
w = json.loads(sys.argv[1] or "{}")
ok = (abs(w.get("rev_mix", 0) - 0.9) < 1e-3 and abs(w.get("flt_mode", 0) - 2 / 3) < 1e-3 and w.get("rev_size", 0) > 0.8
      and w.get("tape_age", 0) > 0.3 and w.get("tape_mix", 0) > 0.3
      and abs(w.get("caldi_mode", 0) - 4 / 5) < 1e-3
      and abs(w.get("caldi_grain", 0) - 0.2) < 1e-3 and abs(w.get("caldi_motion", 0) - 0.1) < 1e-3)
sys.exit(0 if ok else 1)' "$writes"
    result $? "UI controls write plugin parameters (relay, real drags, Caldi radio/keyboard; tape auto-engage)"
    python3 - "$out" <<'EOF'
import json, sys
d = json.loads(sys.argv[1])
t = d.get('calls') or {}
caldi = t.get('caldi') or {}
ok = (d.get('juce') == 'object' and d.get('sliders') == 96 and d.get('combos') == 14
      and caldi.get('tabSelected') is True and caldi.get('controls') == 6 and caldi.get('visible') is True
      and caldi.get('preset') == 'Blue' and abs(caldi.get('grain', 0) - 20) < .01 and abs(caldi.get('motion', 0) - 10) < .01
      and t.get('resizeWidth') and t.get('widthOnly') and t.get('resizeHeight') and t.get('heightOnly')
      and t.get('done') and t.get('noOscUi') is True and t.get('walk') is True and t.get('scope', 0) > 10 and t.get('scopeLen') == 128 and 'tavola' in [x['name'] for x in t.get('themes', [])]
      and t.get('fields') and t.get('favOn') is True and t.get('favOff') is False
      and t.get('reload') is True and t.get('reloadedEvents', 0) >= 1 and t.get('reset') is True and t.get('modified') is False
      and t.get('banks') is True and t.get('moveIn') is True and t.get('moveBad') is True and t.get('moveOut') is True
      and t.get('bankFields') is True and t.get('tagSet') is True and t.get('tagOff') is True and t.get('tagBad') is True
      and t.get('createBank') is True and t.get('editBank') is True and t.get('exportBank') is True and t.get('importSame') is True
      and all(t.get(k) is True for k in ('collectionInspect', 'collectionSkip', 'collectionCleanup', 'collectionExpired'))
      and t.get('inspectSame') is True and t.get('exportBad') is True and t.get('foldersShown') is True and t.get('bankView') is True and t.get('backToTop') is True
      and t.get('returnToSound') is True
      and (d.get('viewport') or {}).get('width', 0) >= 1360 and (d.get('viewport') or {}).get('height', 0) >= 780
      and t.get('saveAs') is True and t.get('afterSave') == 'Prova dalla UI' and t.get('dom')
      and t.get('previewListed') is True and t.get('previewServes') is True and t.get('previewDecodes') is True
      and t.get('previewButton') is True and t.get('previewPlays') is True and t.get('previewStops') is True
      and (d.get('artic') or {}).get('ok') is True)
sys.exit(0 if ok else 1)
EOF
    result $? "editor loads; relays, native functions (favourites, reload, reset, save as) and events work"
fi

if [ "$with_installed" -eq 1 ]; then
    step "installed plugins"
    out="$(auval -v aumu Lbr0 Lbro 2>&1)"
    [[ "$out" == *"AU VALIDATION SUCCEEDED"* ]]
    result $? "auval (native)"
    out="$(arch -x86_64 auval -v aumu Lbr0 Lbro 2>&1)"
    [[ "$out" == *"AU VALIDATION SUCCEEDED"* ]]
    result $? "auval (x86_64)"

    carla=/Applications/Carla.app/Contents/MacOS/carla-discovery-native
    if [ -x "$carla" ]; then
        for a in arm64 x86_64; do
            out="$(arch "-$a" "$carla" vst3 "$HOME/Library/Audio/Plug-Ins/VST3/Libero.vst3" 2>&1)"
            [[ "$out" == *"carla-discovery::name::Libero"* && "$out" == *"carla-discovery::midi.ins::1"* ]]
            result $? "Carla discovery VST3 ($a)"
        done
    else
        echo "Carla not installed, skipped"
    fi
fi

echo
if [ "$failed" -eq 0 ]; then echo "ALL TESTS PASSED"; else echo "SOME TESTS FAILED"; fi
exit $failed
