#pragma once

#include <juce_core/juce_core.h>

// The on-disk library (SPEC §2): sounds, sketches, themes, instances, config.
namespace libero::library
{

juce::File home();                  // $LIBERO_HOME or ~/Libero
juce::File sketchesDir();
juce::File soundsDir();
juce::File banksDir();              // sound packs: banks/<slug>/bank.json + sound folders
juce::File themesDir();
juce::File instancesDir();
juce::File configFile();

// Normalises a path given by a client (sound folder or its build/) to the sound folder.
juce::File soundFolderFor (const juce::File& path);

// {slug, path, title, subtitle, tags, saved, figure, accent, favorite, colorTag, mtime} or void if there's no
// bundle. `favorites` is config.json's list (read from disk when void).
juce::var soundInfo (const juce::File& soundFolder, const juce::var& favorites = {}, const juce::var& tags = {});
juce::var listSounds();   // sketches, sounds, then every bank; each item carries bank {slug, title}

// [{slug, title, subtitle, description, version, author, license, created, updated, count,
//   figureUrl (when the bank has a figure), builtin}] - installed banks, then Mie (sounds/) and Prove (sketches/).
juce::var listBanks();

// Moves a saved sound into a bank (or back to Mie with "mie"). Never overwrites; favourites follow.
// Returns {ok, path} or {ok:false, error}.
juce::var moveSound (const juce::File& soundFolder, const juce::String& bankSlug);

// Favourites live in config.json as {path, slug} pairs; the slug keeps a favourite attached when
// its folder moves (sketch -> sounds).
bool isFavorite (const juce::var& favorites, const juce::String& path, const juce::String& slug);
juce::var setFavorite (const juce::File& soundFolder, bool favorite);

// A copy of a sound under sounds/<slug from title>, sharing its audio (hard links, or copies where
// links aren't possible), with the given title and default params written into build/manifest.json
// and appended to the copied sound.py. Returns {ok, path, slug} or {ok:false, error}.
juce::var saveSoundAs (const juce::File& soundFolder, const juce::String& title, const juce::var& params);
juce::String slugFor (const juce::String& title);

// sketch -> sounds. Returns {ok, path} or {ok:false, error}.
juce::var saveSound (const juce::File& soundFolder);
// sketch -> OS trash. Only accepts folders inside sketches/.
juce::var discardSketch (const juce::File& soundFolder);

// Colour tags (1..4, 0 = none) live in config.json's `tags` {slug: n}, keyed by slug so they survive moves.
int colorTagOf (const juce::var& tags, const juce::String& slug);
juce::var setColorTag (const juce::File& soundFolder, int n);

// Banks (SPEC §2.4), the same behaviour as python/libero/library.py. All return {ok, ...} or {ok:false, error}.
juce::var createBank (const juce::String& title, const juce::String& subtitle);      // + slug
juce::var editBank (const juce::String& slug, const juce::var& fields);               // title/subtitle/description
juce::var exportBank (const juce::String& slug, const juce::File& out);               // -> .liberobank, + path
juce::var deleteBank (const juce::String& slug); // installed pack -> OS trash
juce::var inspectBank (const juce::File& pack);                                       // read-only plan; extracts only to a temporary staging folder
juce::var importBank (const juce::File& pack);                                        // + slug, path
// Inspect one or more .liberobank files and/or a bundle ZIP containing them. ZIP members
// are staged in an opaque session until explicit cleanup; each import remains transactional
// per bank, not across the entire collection.
juce::var inspectBankCollection (const juce::Array<juce::File>& inputs);
juce::var importBankCollectionEntry (const juce::String& sessionId, int index);
juce::var cleanupBankCollection (const juce::String& sessionId);
juce::File bankFigureFile (const juce::File& bankFolder);

juce::var readConfig();
bool writeConfigValue (const juce::String& key, const juce::var& value);

juce::var makeResult (bool ok, const juce::String& error = {});

} // namespace libero::library
