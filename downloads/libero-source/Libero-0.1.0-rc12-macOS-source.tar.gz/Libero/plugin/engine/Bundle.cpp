#include "Bundle.h"
#include "Params.h"
#include "ParamsJson.h"
#include "RateCache.h"

#include <atomic>
#include <bit>
#include <map>
#include <set>
#include <mutex>

#include <cmath>

namespace libero
{

namespace
{
    juce::ThreadPool& decodePool()
    {
        static juce::ThreadPool pool (juce::ThreadPoolOptions{}
            .withThreadName ("Libero sample decoding")
            .withNumberOfThreads (juce::jlimit (1, 4, juce::SystemStats::getNumCpus() / 2))
            .withDesiredThreadPriority (juce::Thread::Priority::low));
        return pool;
    }

    struct DecodeJob final : juce::ThreadPoolJob
    {
        explicit DecodeJob (std::function<void()> taskIn)
            : juce::ThreadPoolJob ("decode samples"), task (std::move (taskIn)) {}
        JobStatus runJob() override { task(); return jobHasFinished; }
        std::function<void()> task;
    };

    struct CachedSound
    {
        std::mutex mutex;
        std::weak_ptr<const SoundData> sound;
    };
    std::shared_ptr<CachedSound> cacheEntry (const juce::String& key)
    {
        static std::mutex mutex;
        static std::map<juce::String, std::shared_ptr<CachedSound>> entries;
        const std::lock_guard<std::mutex> lock (mutex);
        // Weak entries retain neither PCM nor instruments after the last instance releases them.
        for (auto it = entries.begin(); it != entries.end();)
        {
            std::unique_lock<std::mutex> entryLock (it->second->mutex, std::try_to_lock);
            if (entryLock.owns_lock() && it->second.use_count() == 1 && it->second->sound.expired())
            {
                entryLock.unlock();
                it = entries.erase (it);
            }
            else ++it;
        }
        auto& entry = entries[key];
        if (!entry) entry = std::make_shared<CachedSound>();
        return entry;
    }
    juce::String fileStamp (const juce::File& file)
    {
        return file.getFullPathName() + ":" + juce::String (file.getSize()) + ":"
             + juce::String (file.getLastModificationTime().toMilliseconds());
    }
    juce::String cacheKey (const juce::File& build, const juce::var& manifest,
                           const juce::File& edits, double rate)
    {
        juce::String key = fileStamp (build.getChildFile ("manifest.json")) + ":" + juce::String (rate, 12)
                         + ":" + juce::JSON::toString (manifest, true) + ":" + edits.loadFileAsString();
        if (const auto* zones = manifest["zones"].getArray())
            for (const auto& zone : *zones) key += ":" + fileStamp (build.getChildFile (zone["file"].toString()));
        if (manifest["ir"].toString().isNotEmpty()) key += ":" + fileStamp (build.getChildFile (manifest["ir"].toString()));
        return key;
    }
    std::unique_ptr<SoundData> cachedCopy (std::shared_ptr<const SoundData> backing)
    {
        auto copy = std::make_unique<SoundData> (*backing);
        copy->params = juce::JSON::parse (juce::JSON::toString (backing->params, true));
        copy->cacheBacking = std::move (backing);
        return copy;
    }
    constexpr double kMaxZoneSeconds = 120.0;
    constexpr double kMaxIRSeconds   = 12.0;

    //==============================================================================
    struct SincTable
    {
        static constexpr int zeroCrossings = 24;
        static constexpr int oversample    = 512;

        std::vector<float> table;

        SincTable()
        {
            const auto n = zeroCrossings * oversample + 2;
            table.resize ((size_t) n);

            constexpr double beta = 8.6;
            const auto i0Beta = besselI0 (beta);

            for (int i = 0; i < n; ++i)
            {
                const auto x = (double) i / oversample;

                if (x >= zeroCrossings)
                {
                    table[(size_t) i] = 0.0f;
                    continue;
                }

                const auto sinc = x == 0.0 ? 1.0 : std::sin (juce::MathConstants<double>::pi * x) / (juce::MathConstants<double>::pi * x);
                const auto r = x / zeroCrossings;
                const auto w = besselI0 (beta * std::sqrt (1.0 - r * r)) / i0Beta;
                table[(size_t) i] = (float) (sinc * w);
            }
        }

        static double besselI0 (double x)
        {
            double sum = 1.0, term = 1.0;

            for (int k = 1; k < 50; ++k)
            {
                term *= (x / (2.0 * k)) * (x / (2.0 * k));
                sum += term;

                if (term < 1e-12 * sum)
                    break;
            }

            return sum;
        }

        float operator() (double x) const noexcept
        {
            x = std::abs (x) * oversample;
            const auto i = (int) x;

            if (i >= (int) table.size() - 1)
                return 0.0f;

            const auto f = (float) (x - i);
            return table[(size_t) i] + f * (table[(size_t) i + 1] - table[(size_t) i]);
        }
    };

    const SincTable& sincTable()
    {
        static const SincTable t;
        return t;
    }

    //==============================================================================
    Layer parseLayer (const juce::String& s, bool& ok)
    {
        ok = true;
        if (s == "body")   return Layer::body;
        if (s == "attack") return Layer::attack;
        if (s == "tail")   return Layer::tail;
        if (s == "air")    return Layer::air;
        ok = false;
        return Layer::body;
    }

    int intProp (const juce::var& obj, const char* name, int fallback)
    {
        const auto& v = obj[name];
        return v.isVoid() || v.isUndefined() ? fallback : (int) v;
    }

    bool readAudio (juce::AudioFormatManager& fm, const juce::File& file, double maxSeconds,
                    juce::AudioBuffer<float>& out, double& rate, juce::String& error)
    {
        if (! file.existsAsFile())
        {
            error = "missing file " + file.getFileName();
            return false;
        }

        std::unique_ptr<juce::AudioFormatReader> reader (fm.createReaderFor (file));

        if (reader == nullptr)
        {
            error = "unreadable audio " + file.getFileName();
            return false;
        }

        rate = reader->sampleRate;

        if (rate <= 0.0)
        {
            error = "bad sample rate in " + file.getFileName();
            return false;
        }

        const auto length = (int) std::min<juce::int64> (reader->lengthInSamples, (juce::int64) (maxSeconds * rate));
        const auto channels = (int) juce::jlimit (1u, 2u, reader->numChannels);

        if (length <= 0)
        {
            error = "empty audio " + file.getFileName();
            return false;
        }

        out.setSize (channels, length);
        if (! reader->read (&out, 0, length, 0, true, channels > 1))
        { error = "could not read audio " + file.getFileName(); return false; }

        // Scrub anything non-finite so a bad file can never poison the audio thread.
        for (int c = 0; c < channels; ++c)
        {
            auto* d = out.getWritePointer (c);

            for (int i = 0; i < length; ++i)
                if (! std::isfinite (d[i]))
                    d[i] = 0.0f;
        }

        return true;
    }

    juce::AudioBuffer<float> resampleBuffer (juce::AudioBuffer<float> in, double ratio)
    {
        if (std::abs (ratio - 1.0) < 1e-9)
            return in;

        std::vector<std::vector<float>> chans;

        for (int c = 0; c < in.getNumChannels(); ++c)
            chans.push_back (resample (in.getReadPointer (c), in.getNumSamples(), ratio));

        juce::AudioBuffer<float> out (in.getNumChannels(), (int) chans[0].size());

        for (int c = 0; c < in.getNumChannels(); ++c)
            out.copyFrom (c, 0, chans[(size_t) c].data(), (int) chans[(size_t) c].size());

        return out;
    }

    // Bakes a crossfade into the samples just before loopEnd so the jump end -> start is seamless.
    void bakeLoop (Zone& z, int start, int end, int xfade, bool equalPower)
    {
        const auto len = z.length();
        start = juce::jlimit (0, len - 1, start);
        end   = juce::jlimit (start + 1, len, end);

        const auto loopLen = end - start;

        if (loopLen < 16)
        {
            z.looped = false;
            return;
        }

        xfade = juce::jlimit (0, loopLen / 2, xfade);

        // Blend source: the material that precedes loopStart if there is enough of it, otherwise
        // the material that follows it (and then the jump lands after the blended region).
        const auto usePre = start >= xfade;
        const auto src = usePre ? start - xfade : start;

        for (int c = 0; c < z.audio.getNumChannels(); ++c)
        {
            auto* d = z.audio.getWritePointer (c);

            for (int i = 0; i < xfade; ++i)
            {
                const auto t = (float) (i + 1) / (float) (xfade + 1);
                const auto gIn  = equalPower ? std::sin (t * juce::MathConstants<float>::halfPi) : t;
                const auto gOut = equalPower ? std::cos (t * juce::MathConstants<float>::halfPi) : 1.0f - t;
                const auto e = end - xfade + i;
                d[e] = d[e] * gOut + d[src + i] * gIn;
            }
        }

        z.looped    = true;
        z.loopStart = usePre ? start : start + xfade;
        z.loopEnd   = end;

        if (z.loopEnd - z.loopStart < 16)
            z.looped = false;
    }
}

//==============================================================================
int resampleHalo (double ratio) noexcept
{
    return (int) std::ceil (SincTable::zeroCrossings / (std::min (1.0, 1.0 / ratio) * .97)) + 2;
}
void resampleWindow (const float* source, int sourceStart, int totalSourceFrames,
                     double ratio, int targetStart, int targetCount, float* output)
{
    const auto& k = sincTable();
    const auto fc = std::min (1.0, 1.0 / ratio) * 0.97;
    const auto halfWidth = SincTable::zeroCrossings / fc;
    for (int n = 0; n < targetCount; ++n)
    {
        const auto t = (targetStart + n) * ratio;
        const auto k0 = std::max (0, (int) std::ceil (t - halfWidth));
        const auto k1 = std::min (totalSourceFrames - 1, (int) std::floor (t + halfWidth));
        double acc = 0.0;
        if (halfWidth < 31)
        {
            struct Phase { double fraction = -1, ratio = -1; std::array<float, 64> weights; };
            thread_local std::array<Phase, 4096> phases;
            const auto base = (int) std::floor (t);
            const auto fraction = t - base;
            auto hash = std::bit_cast<uint64_t> (fraction) ^ std::bit_cast<uint64_t> (ratio);
            hash ^= hash >> 32; hash ^= hash >> 17; hash *= 0x9e3779b97f4a7c15ULL;
            auto& phase = phases[(size_t) (hash & 4095)];
            if (phase.fraction != fraction || phase.ratio != ratio)
            {
                phase.fraction = fraction; phase.ratio = ratio;
                for (int offset = -32; offset < 32; ++offset)
                    phase.weights[(size_t) (offset + 32)] = k ((fraction - offset) * fc);
            }
            for (int i = k0; i <= k1; ++i)
                acc += (double) source[i - sourceStart] * phase.weights[(size_t) (i - base + 32)];
        }
        else
            for (int i = k0; i <= k1; ++i)
                acc += (double) source[i - sourceStart] * k ((t - i) * fc);
        output[n] = (float) (acc * fc);
    }
}
std::vector<float> resample (const float* input, int numInput, double ratio)
{
    const auto numOut = (int) std::floor ((double) numInput / ratio);
    std::vector<float> out ((size_t) std::max (0, numOut));
    resampleWindow (input, 0, numInput, ratio, 0, numOut, out.data());
    return out;
}

juce::File resolveBuildDir (const juce::File& path)
{
    if (path.getChildFile ("manifest.json").existsAsFile())
        return path;

    if (path.getChildFile ("build").getChildFile ("manifest.json").existsAsFile())
        return path.getChildFile ("build");

    return {};
}

const Zone* SoundData::find (Layer layer, int note, int velocity, int take, float dyn, int art) const noexcept
{
    const auto g = findGroup (layer, note, velocity, dyn, art);
    return g < 0 ? nullptr : &zoneOf (g, take);
}

int SoundData::findGroup (Layer layer, int note, int velocity, float dyn, int art) const noexcept
{
    const auto g = findKeyGroup (layer, note, velocity, art);

    if (g < 0 || dyn < 0.0f || groupDynSet[(size_t) g] < 0)
        return g;

    // Dynamics layer holding `dyn`, else the nearest centre.
    int best = g;
    float bestDist = 1.0e9f;

    for (auto candidate : dynSets[(size_t) groupDynSet[(size_t) g]])
    {
        const auto& z = zoneOf (candidate, 0);
        const auto dist = (dyn >= z.dynLo && dyn <= z.dynHi) ? -1.0f + std::abs (dyn - z.dynCentre())
                                                            : std::abs (dyn - z.dynCentre());
        if (dist < bestDist)
        {
            bestDist = dist;
            best = candidate;
        }
    }

    return best;
}

int SoundData::findKeyGroup (Layer layer, int note, int velocity, int art) const noexcept
{
    const auto& list = byLayer[(size_t) layer];
    const Zone* best = nullptr;
    int bestScore = std::numeric_limits<int>::max();

    for (auto idx : list)
    {
        const auto& z = zones[(size_t) idx];

        if (art >= 0 && z.art >= 0 && z.art != art)
            continue;   // another articulation's zone

        const auto keyDist = note < z.lo ? z.lo - note : (note > z.hi ? note - z.hi : 0);
        const auto velDist = velocity < z.velLo ? z.velLo - velocity : (velocity > z.velHi ? velocity - z.velHi : 0);
        const auto score = keyDist * 256 + velDist;

        if (score < bestScore)
        {
            bestScore = score;
            best = &z;

            if (score == 0)
                break;
        }
    }

    return best != nullptr ? best->group : -1;
}

bool SoundData::validateStreamedAudio (juce::String& error) const
{
    std::vector<const SampleStreamPool::Asset*> assets;
    std::set<juce::String> checked;
    for (const auto& zone : zones)
        if (zone.stream != nullptr && checked.insert (zone.stream->file.getFullPathName()).second)
            assets.push_back (zone.stream);
    if (assets.empty()) return true;

    std::vector<juce::String> errors (assets.size());
    std::atomic<size_t> next { 0 };
    std::atomic<bool> failed { false };
    const auto work = [&]
    {
        juce::AudioFormatManager formats;
        formats.registerBasicFormats();
        juce::AudioBuffer<float> block (2, 8192);
        for (auto index = next++; index < assets.size(); index = next++)
        {
            if (failed.load (std::memory_order_relaxed)) break;
            const auto& asset = *assets[index];
            std::unique_ptr<juce::AudioFormatReader> reader (formats.createReaderFor (asset.file));
            if (reader == nullptr || reader->lengthInSamples < asset.sourceFrames)
                errors[index] = "unreadable streamed audio " + asset.file.getFileName();
            else
                for (juce::int64 frame = 0; frame < asset.sourceFrames; frame += block.getNumSamples())
                {
                    const auto count = (int) std::min<juce::int64> (block.getNumSamples(), asset.sourceFrames - frame);
                    if (! reader->read (&block, 0, count, frame, true, asset.channels > 1))
                    { errors[index] = "could not read audio " + asset.file.getFileName(); break; }
                }
            if (errors[index].isNotEmpty()) failed.store (true, std::memory_order_relaxed);
        }
    };
    auto& pool = decodePool();
    if (pool.getNumThreads() < 2)
    {
        try { work(); }
        catch (...) { error = "streamed audio validation failed"; return false; }
        for (const auto& message : errors)
            if (message.isNotEmpty()) { error = message; return false; }
        return true;
    }
    const auto jobs = juce::jmin (2, pool.getNumThreads() - 1, (int) assets.size());
    std::atomic<int> remaining { 1 };
    juce::WaitableEvent complete;
    const auto finish = [&] { if (remaining.fetch_sub (1) == 1) complete.signal(); };
    for (int i = 0; i < jobs; ++i)
    {
        ++remaining;
        try
        {
            auto job = std::make_unique<DecodeJob> ([&]
            {
                try { work(); }
                catch (...) { failed.store (true, std::memory_order_relaxed); }
                finish();
            });
            pool.addJob (job.get(), true);
            job.release();
        }
        catch (...)
        {
            failed.store (true, std::memory_order_relaxed);
            finish();
            break;
        }
    }
    finish();
    complete.wait();
    if (! failed.load()) return true;
    for (const auto& message : errors)
        if (message.isNotEmpty()) { error = message; return false; }
    error = "streamed audio validation failed";
    return false;
}

std::unique_ptr<SoundData> SoundData::load (const juce::File& path, double targetRate, juce::String& error,
                                          const std::function<bool()>& cancelled, bool allowStreaming)
{
    if (! std::isfinite (targetRate) || targetRate <= 0 || targetRate > 768000)
    { error = "invalid target sample rate"; return nullptr; }
    const auto stopped = [&] { return cancelled && cancelled(); };
    if (stopped()) { error = "load cancelled"; return nullptr; }
    const auto build = resolveBuildDir (path);

    if (! build.isDirectory())
    {
        error = "no manifest.json in " + path.getFullPathName() + " or its build/";
        return nullptr;
    }

    const auto manifest = juce::JSON::parse (build.getChildFile ("manifest.json"));

    if (! manifest.isObject())
    {
        error = "manifest.json is not valid JSON";
        return nullptr;
    }

    // Per-sound sample edits are an optional, user-owned sidecar. They are keyed
    // to an exact compiled zone and applied to freshly decoded bundle audio.
    const auto editorFile = build.getParentDirectory().getChildFile ("sample-edits.json");
    const auto sampleEdits = editorFile.existsAsFile() ? juce::JSON::parse (editorFile) : juce::var();
    const auto* editsObject = sampleEdits["edits"].getDynamicObject();

    const auto streamingOption = juce::SystemStats::getEnvironmentVariable ("LIBERO_SAMPLE_STREAMING", "auto");
    const bool streamingAllowed = allowStreaming && streamingOption != "0";
    const auto contentKey = cacheKey (build, manifest, editorFile, targetRate);
    const auto entry = cacheEntry (contentKey + (streamingAllowed ? ":stream-" + streamingOption : ":resident"));
    const std::unique_lock<std::mutex> cacheLock (entry->mutex);
    if (stopped()) { error = "load cancelled"; return nullptr; }
    const bool reuseCache = juce::SystemStats::getEnvironmentVariable ("LIBERO_DISABLE_SAMPLE_CACHE", {}) != "1";
    if (reuseCache)
        if (const auto cached = entry->sound.lock())
            return cachedCopy (cached);

    const auto format = manifest["format"].toString();

    if (format.isNotEmpty() && ! format.startsWith ("libero.bundle/1") && ! format.startsWith ("libero.bundle/2"))
    {
        error = "unsupported bundle format " + format;
        return nullptr;
    }

    auto sd = std::make_unique<SoundData>();
    sd->buildDir = build;
    sd->folder = build.getFileName() == "build" ? build.getParentDirectory() : build;
    sd->slug = manifest["slug"].toString();
    sd->title = manifest["title"].toString();
    sd->subtitle = manifest["subtitle"].toString();
    sd->description = manifest["description"].toString();
    sd->accent = manifest["accent"].toString();
    sd->params = manifest["params"];

    // Sounds made before the echo could follow the host tempo set `echo_time` in ms: they stay on
    // the free (Libero) echo unless they say otherwise (SPEC §5).
    if (auto* po = sd->params.getDynamicObject())
        if (po->hasProperty ("echo_time") && ! po->hasProperty ("echo_sync"))
            po->setProperty ("echo_sync", "Libero");
    sd->sampleRate = targetRate;
    sd->playbackId = sd->folder.getFullPathName().hashCode();
    sd->contentId = contentKey.hashCode64();

    if (sd->slug.isEmpty())
        sd->slug = sd->folder.getFileName();

    if (sd->title.isEmpty())
        sd->title = sd->slug;

    if (auto* tags = manifest["tags"].getArray())
        for (const auto& t : *tags)
            sd->tags.add (t.toString());

    // Articulations (bundle/2): at most 16 (the `artic` parameter's range); the first is the default.
    if (const auto* arts = manifest["articulations"].getArray())
    {
        for (const auto& a : *arts)
        {
            if (sd->numArticulations() >= 16 || ! a.isObject() || a["id"].toString().isEmpty())
                continue;

            SoundData::Articulation art;
            art.id = a["id"].toString();
            art.name = a["name"].toString().isNotEmpty() ? a["name"].toString() : art.id;
            art.key = a["key"].isVoid() ? -1 : juce::jlimit (-1, 127, (int) a["key"]);
            if (auto* profile = a["params"].getDynamicObject())
            {
                const auto& props = profile->getProperties();
                for (int i = 0; i < props.size(); ++i)
                {
                    const auto key = props.getName (i).toString().toStdString();
                    const auto index = findParam (key);
                    if (index < 0)
                        continue;
                    const auto& ps = spec (index);
                    const auto value = props.getValueAt (i);
                    float plain = ps.def;
                    if (value.isString() && ps.scale == Scale::choice)
                    {
                        const auto choice = choiceIndex (ps, value.toString().toStdString());
                        if (choice >= 0) plain = (float) choice;
                    }
                    else if (value.isDouble() || value.isInt() || value.isInt64())
                        plain = (float) (double) value;
                    art.profile.emplace_back (index, clampPlain (ps, plain));
                }
            }
            const auto index = sd->numArticulations();

            if (art.key >= 0)
                sd->keyswitch[(size_t) art.key] = (int8_t) index;

            sd->articulations.push_back (std::move (art));
        }
    }

    juce::AudioFormatManager fm;
    fm.registerBasicFormats();

    // bundle/2 allows no zones at all: an oscillator-only sound (its params turn the oscillators on).
    const juce::Array<juce::var> noZones;
    const auto* zones = manifest["zones"].getArray();

    if (zones == nullptr)
        zones = &noZones;

    if (zones->isEmpty() && ! format.startsWith ("libero.bundle/2"))
    {
        error = "manifest has no zones";
        return nullptr;
    }

    // All instances share a bounded background pool; audio and UI keep CPU headroom.
    struct Pending { Zone z; juce::var zv; double ratio = 1.0; juce::String error; double sourceDuration = 0.0; };
    std::vector<Pending> pending;
    bool haveAir = false;

    int manifestIndex = 0;
    for (const auto& zv : *zones)
    {
        bool ok = false;
        Zone z;
        z.manifestIndex = manifestIndex++;
        z.layer = parseLayer (zv["layer"].toString(), ok);

        if (! ok)
            continue;   // unknown layers are ignored, not fatal: later formats may add some

        if (z.layer == Layer::air && haveAir)
            continue;   // exactly one air zone; keep the first

        haveAir = haveAir || z.layer == Layer::air;

        z.pitched = z.layer == Layer::air ? false : (bool) zv.getProperty ("pitched", true);
        z.root  = juce::jlimit (0, 127, intProp (zv, "root", 60));
        z.lo    = juce::jlimit (0, 127, intProp (zv, "lo", 0));
        z.hi    = juce::jlimit (z.lo, 127, intProp (zv, "hi", 127));
        z.velLo = juce::jlimit (0, 127, intProp (zv, "vel_lo", 1));
        z.velHi = juce::jlimit (z.velLo, 127, intProp (zv, "vel_hi", 127));
        z.take  = juce::jmax (0, intProp (zv, "take", 0));

        if (const auto artId = zv["articulation"].toString(); artId.isNotEmpty())
            for (int a = 0; a < sd->numArticulations(); ++a)
                if (sd->articulations[(size_t) a].id == artId)
                    z.art = a;

        if (const auto* dyn = zv["dyn"].getArray(); dyn != nullptr && dyn->size() == 2)
        {
            z.dynLo = juce::jlimit (0.0f, 1.0f, (float) (double) (*dyn)[0]);
            z.dynHi = juce::jlimit (z.dynLo, 1.0f, (float) (double) (*dyn)[1]);
        }

        z.tuneCents = juce::jlimit (-100.0f, 100.0f, (float) (double) zv.getProperty ("tune_cents", 0.0));
        z.rtDecay   = juce::jlimit (0.0f, 200.0f, (float) (double) zv.getProperty ("rt_decay", 0.0));
        z.rtMinDb   = juce::jlimit (-120.0f, 0.0f, (float) (double) zv.getProperty ("rt_min_db", -40.0));

        z.oneShot = (bool) zv.getProperty ("one_shot", manifest.getProperty ("one_shot", false));
        z.chokeGroup = juce::jmax (0, intProp (zv, "choke_group", 0));

        if (const auto* ch = zv["chokes"].getArray())
            for (const auto& g : *ch)
                if ((int) g >= 1)
                    z.chokes.push_back ((int) g);

        // Pre-roll before the strike (zone value, else the bundle's): skipped at note-on.
        if (z.layer != Layer::air)
        {
            const auto onsetMs = juce::jlimit (0.0, 1000.0, (double) zv.getProperty ("onset_ms", manifest.getProperty ("onset_ms", 0.0)));
            z.onset = (int) std::lround (onsetMs * 0.001 * targetRate);
            z.onsetFade = z.onset > 0 ? (int) std::lround (0.001 * targetRate) : 0;
        }

        pending.push_back ({ std::move (z), zv, 1.0, {} });
    }

    if (const auto& dyn = manifest["dynamics"]; dyn.isObject())
    {
        const auto source = dyn["source"].toString();
        sd->dynSource = source == "cc1" ? SoundData::DynSource::cc1
                      : source == "cc11" ? SoundData::DynSource::cc11 : SoundData::DynSource::velocity;
        sd->velocityCurve = juce::jlimit (0.1f, 10.0f, (float) (double) dyn.getProperty ("velocity_curve", 1.0));

        if (const auto& xf = dyn["crossfade"]; xf.isInt() || xf.isInt64() || xf.isDouble())
            sd->dynCrossfade = juce::jlimit (0.0f, 1.0f, (float) (double) xf);
    }

    ParamSet playingParams;
    applyJsonParams (playingParams, manifest["params"]);
    bool streamCandidate = streamingAllowed && (zones->size() >= 128 || streamingOption == "1")
        && (int) playingParams[P::mode] == 0
        && editsObject == nullptr;
    if (streamCandidate && streamingOption != "1")
    {
        uint64_t residentBytes = 0;
        for (const auto& zone : pending)
        {
            if (stopped()) { error = "load cancelled"; return nullptr; }
            std::unique_ptr<juce::AudioFormatReader> reader (fm.createReaderFor (build.getChildFile (zone.zv["file"].toString())));
            if (reader && reader->sampleRate > 0 && std::isfinite (reader->sampleRate))
                residentBytes += (uint64_t) (std::min<double> ((double) reader->lengthInSamples, kMaxZoneSeconds * reader->sampleRate)
                                            * targetRate / reader->sampleRate) * juce::jlimit (1u, 2u, reader->numChannels) * sizeof (float);
            if (residentBytes > 256 * 1024 * 1024) break;
        }
        streamCandidate = residentBytes > 256 * 1024 * 1024;
    }
    std::mutex streamMutex;
    std::shared_ptr<SampleStreamPool> streamPool;
    std::atomic<bool> wroteRateCache { false };
    if (! pending.empty())
    {
        std::atomic<size_t> next { 0 };
        std::atomic<bool> decodingFailed { false };
        const auto work = [&]
        {
            juce::AudioFormatManager localFm;
            localFm.registerBasicFormats();

            for (auto i = next++; i < pending.size(); i = next++)
            {
                if (stopped() || decodingFailed.load (std::memory_order_relaxed)) break;
                auto& p = pending[i];
                double fileRate = 0.0;
                juce::AudioBuffer<float> raw;
                const auto file = build.getChildFile (p.zv["file"].toString());
                const auto gainDb = juce::jlimit (-96.0f, 24.0f, (float) (double) p.zv.getProperty ("gain_db", 0.0));
                const auto gain = juce::Decibels::decibelsToGain (gainDb);
                if (streamCandidate && ! p.zv["loop"].isObject() && (! p.z.hasDyn() || sd->dynCrossfade == 0.0f) && p.z.layer != Layer::air
                    && p.z.onset < (int) (targetRate * .05))
                {
                    std::unique_ptr<juce::AudioFormatReader> reader (localFm.createReaderFor (file));
                    if (reader && std::isfinite (reader->sampleRate) && reader->sampleRate > 0 && reader->sampleRate <= 768000
                        && reader->numChannels >= 1 && reader->numChannels <= 2
                        && file.hasFileExtension ("wav;flac;aif;aiff")
                        && reader->lengthInSamples > (juce::int64) (reader->sampleRate * .5))
                    {
                        const auto sourceFrames = (int) std::min<juce::int64> (reader->lengthInSamples, (juce::int64) (kMaxZoneSeconds * reader->sampleRate));
                        const auto ratio = reader->sampleRate / targetRate;
                        const auto frames = (int) std::floor (sourceFrames / ratio);
                        const auto attackFrames = (int) std::ceil (targetRate * .25);
                        const auto channels = (int) reader->numChannels;
                        const bool convert = std::abs (ratio - 1.0) >= 1e-9;
                        const auto readFrames = convert ? std::min (sourceFrames, (int) std::ceil (attackFrames * ratio) + resampleHalo (ratio)) : attackFrames;
                        raw.setSize (channels, readFrames);
                        if (! reader->read (&raw, 0, readFrames, 0, true, channels > 1))
                        { p.error = "could not read sample attack"; continue; }
                        for (int c = 0; c < channels; ++c)
                            for (int frame = 0; frame < raw.getNumSamples(); ++frame)
                                if (! std::isfinite (raw.getSample (c, frame))) raw.setSample (c, frame, 0);
                        raw.applyGain (gain);
                        if (convert)
                        {
                            juce::AudioBuffer<float> attack (channels, attackFrames);
                            for (int c = 0; c < channels; ++c)
                                resampleWindow (raw.getReadPointer (c), 0, sourceFrames, ratio, 0, attackFrames, attack.getWritePointer (c));
                            p.z.audio = std::move (attack);
                        }
                        else p.z.audio = std::move (raw);
                        p.ratio = ratio; p.sourceDuration = (double) sourceFrames / reader->sampleRate;
                        const std::lock_guard<std::mutex> lock (streamMutex);
                        if (! streamPool) streamPool = SampleStreamPool::create();
                        p.z.stream = streamPool->add (file, p.z.audio, frames, gain, ratio, sourceFrames);
                        p.z.streamPool = streamPool.get();
                        continue;
                    }
                }
                const auto identity = rateCache::key (file, targetRate, gainDb);
                int sourceFrames = 0;
                if (rateCache::read (identity, raw, fileRate, sourceFrames))
                {
                    p.ratio = fileRate / targetRate;
                    p.sourceDuration = (double) sourceFrames / fileRate;
                    p.z.audio = std::move (raw);
                    continue;
                }
                if (! readAudio (localFm, file, kMaxZoneSeconds, raw, fileRate, p.error))
                    continue;
                if (stopped()) break;
                raw.applyGain (juce::Decibels::decibelsToGain (gainDb));
                p.ratio = fileRate / targetRate;
                p.sourceDuration = (double) raw.getNumSamples() / fileRate;
                sourceFrames = raw.getNumSamples();
                auto converted = resampleBuffer (std::move (raw), p.ratio);
                if (!stopped() && std::abs (p.ratio - 1.0) >= 1e-9)
                {
                    rateCache::write (identity, converted, fileRate, sourceFrames);
                    wroteRateCache.store (true, std::memory_order_relaxed);
                }
                p.z.audio = std::move (converted);
            }
        };

        auto& pool = decodePool();
        const auto jobs = juce::jmin (pool.getNumThreads(), (int) pending.size());
        // The submitter holds one count until enqueueing is finished. Even a partial
        // enqueue failure must join submitted jobs before their captured locals die.
        std::atomic<int> remaining { 1 };
        juce::WaitableEvent complete;
        const auto finish = [&]
        {
            if (remaining.fetch_sub (1) == 1) complete.signal();
        };
        for (int i = 0; i < jobs; ++i)
        {
            ++remaining;
            try
            {
                auto job = std::make_unique<DecodeJob> ([&]
                {
                    try { work(); }
                    catch (...) { decodingFailed.store (true, std::memory_order_relaxed); }
                    finish();
                });
                pool.addJob (job.get(), true);
                job.release();
            }
            catch (...)
            {
                decodingFailed.store (true, std::memory_order_relaxed);
                finish();
                break;
            }
        }
        finish();
        complete.wait();
        if (decodingFailed.load()) { error = "sample decoding failed"; return nullptr; }
    }
    sd->streaming = std::move (streamPool);
    if (wroteRateCache.load (std::memory_order_relaxed)) rateCache::prune();
    if (stopped()) { error = "load cancelled"; return nullptr; }

    for (auto& p : pending)
    {
        if (p.error.isNotEmpty())
        {
            error = p.error;
            return nullptr;
        }

        auto z = std::move (p.z);
        const auto& zv = p.zv;
        const auto ratio = p.ratio;

        if (z.length() < 2)
            continue;

        const auto& loop = zv["loop"];
        const auto scale = [ratio] (int v) { return (int) std::lround ((double) v / ratio); };
        const auto zoneFile = zv["file"].toString();
        const auto edit = editsObject != nullptr ? editsObject->getProperty (zoneFile) : juce::var();
        const auto number = [] (const juce::var& value, double fallback)
        {
            return value.isInt() || value.isInt64() || value.isDouble() ? (double) value : fallback;
        };
        const auto editStart = number (edit.getProperty ("start_s", {}), std::numeric_limits<double>::quiet_NaN());
        const auto editEnd = number (edit.getProperty ("end_s", {}), std::numeric_limits<double>::quiet_NaN());
        const auto editLoopStart = number (edit.getProperty ("loop_start_s", {}), std::numeric_limits<double>::quiet_NaN());
        const auto editLoopEnd = number (edit.getProperty ("loop_end_s", {}), std::numeric_limits<double>::quiet_NaN());
        const auto editCrossfade = number (edit.getProperty ("crossfade_ms", {}), std::numeric_limits<double>::quiet_NaN());
        bool sameDyn = ! edit.isObject() || edit["dyn"].isVoid() == zv["dyn"].isVoid();
        if (sameDyn && edit.isObject() && edit["dyn"].isArray() && zv["dyn"].isArray())
        {
            const auto* ea = edit["dyn"].getArray();
            const auto* za = zv["dyn"].getArray();
            sameDyn = ea != nullptr && za != nullptr && ea->size() == za->size();
            if (sameDyn)
                for (int i = 0; i < ea->size(); ++i)
                    sameDyn = sameDyn && std::abs ((double) (*ea)[i] - (double) (*za)[i]) < 1.0e-6;
        }
        bool useEdit = edit.isObject() && (bool) edit.getProperty ("enabled", false)
                    && edit["source_hash"].toString() == manifest["source_hash"].toString()
                    && edit.getProperty ("articulation", {}).toString() == zv.getProperty ("articulation", {}).toString()
                    && sameDyn
                    && (int) edit.getProperty ("root", z.root) == z.root
                    && (int) edit.getProperty ("lo", z.lo) == z.lo
                    && (int) edit.getProperty ("hi", z.hi) == z.hi
                    && (int) edit.getProperty ("vel_lo", z.velLo) == z.velLo
                    && (int) edit.getProperty ("vel_hi", z.velHi) == z.velHi
                    && (int) edit.getProperty ("take", z.take) == z.take
                    && std::isfinite (editStart) && std::isfinite (editEnd)
                    && editStart >= 0.0 && editStart + 0.05 <= editEnd
                    && editEnd <= p.sourceDuration + 1.0e-9
                    && std::isfinite (editCrossfade) && editCrossfade >= 0.0 && editCrossfade <= 500.0;
        if (useEdit && (bool) edit.getProperty ("loop_enabled", false))
            useEdit = std::isfinite (editLoopStart) && std::isfinite (editLoopEnd)
                   && editLoopStart >= editStart && editLoopStart + 0.05 <= editLoopEnd && editLoopEnd <= editEnd;

        if (useEdit)
        {
            const auto startSec = editStart;
            const auto endSec = editEnd;
            const auto start = (int) std::llround (startSec * targetRate);
            const auto end = std::min (z.length(), (int) std::llround (endSec * targetRate));
            const auto trimmed = end - start;
            juce::AudioBuffer<float> crop (z.audio.getNumChannels(), trimmed);
            for (int c = 0; c < z.audio.getNumChannels(); ++c)
                crop.copyFrom (c, 0, z.audio.getReadPointer (c) + start, trimmed);
            z.audio = std::move (crop);
            z.sourceStartSeconds = (double) start / targetRate;
            // An explicit start marker replaces the preset's pre-roll skip.
            z.onset = 0;

            if ((bool) edit.getProperty ("loop_enabled", false))
            {
                // A user-created sustain loop must release normally; otherwise a source
                // one-shot would continue looping indefinitely after note-off.
                z.oneShot = false;
                const auto loopStart = (int) std::llround ((editLoopStart - startSec) * targetRate);
                const auto loopEnd = std::min (trimmed, (int) std::llround ((editLoopEnd - startSec) * targetRate));
                const auto xfade = (int) std::llround (editCrossfade * 0.001 * targetRate);
                if (loopStart >= 0 && loopEnd <= trimmed && loopEnd - loopStart >= (int) (0.05 * targetRate))
                    bakeLoop (z, loopStart, loopEnd, xfade, z.layer == Layer::air);
                else
                    z.looped = false;
            }
            else
                z.looped = false;
        }
        else if (loop.isObject())
            bakeLoop (z, scale (intProp (loop, "start", 0)),
                         scale (intProp (loop, "end", z.length())),
                         scale (intProp (loop, "crossfade", 0)), z.layer == Layer::air);
        else if (z.layer == Layer::air)
        {
            // Air always loops; whole file with a generous crossfade.
            const auto xf = std::min (z.length() / 4, (int) (0.25 * targetRate));
            bakeLoop (z, 0, z.length(), xf, true);
        }

        const auto index = (int) sd->zones.size();
        sd->zones.push_back (std::move (z));
        sd->byLayer[(size_t) sd->zones.back().layer].push_back (index);

        if (sd->zones.back().layer == Layer::air)
            sd->airZone = index;
    }

    // Group round-robin takes: same layer, same key and velocity ranges.
    for (size_t i = 0; i < sd->zones.size(); ++i)
    {
        auto& z = sd->zones[i];

        for (size_t g = 0; g < sd->groups.size() && z.group < 0; ++g)
        {
            const auto& o = sd->zones[(size_t) sd->groups[g].front()];

            if (o.layer == z.layer && o.lo == z.lo && o.hi == z.hi && o.velLo == z.velLo && o.velHi == z.velHi && o.art == z.art
                && juce::exactlyEqual (o.dynLo, z.dynLo) && juce::exactlyEqual (o.dynHi, z.dynHi))
            {
                z.group = (int) g;
                sd->groups[g].push_back ((int) i);
            }
        }

        if (z.group < 0)
        {
            z.group = (int) sd->groups.size();
            sd->groups.push_back ({ (int) i });
        }
    }

    for (auto& g : sd->groups)
        std::stable_sort (g.begin(), g.end(), [&] (int a, int b) { return sd->zones[(size_t) a].take < sd->zones[(size_t) b].take; });

    // Dynamics sets: groups with `dyn` sharing layer, key and velocity ranges.
    sd->groupDynSet.assign (sd->groups.size(), -1);

    for (size_t g = 0; g < sd->groups.size(); ++g)
    {
        const auto& z = sd->zoneOf ((int) g, 0);

        if (! z.hasDyn())
            continue;

        for (size_t s = 0; s < sd->dynSets.size() && sd->groupDynSet[g] < 0; ++s)
        {
            const auto& o = sd->zoneOf (sd->dynSets[s].front(), 0);

            if (o.layer == z.layer && o.lo == z.lo && o.hi == z.hi && o.velLo == z.velLo && o.velHi == z.velHi && o.art == z.art)
            {
                sd->groupDynSet[g] = (int) s;
                sd->dynSets[s].push_back ((int) g);
            }
        }

        if (sd->groupDynSet[g] < 0)
        {
            sd->groupDynSet[g] = (int) sd->dynSets.size();
            sd->dynSets.push_back ({ (int) g });
        }
    }

    for (auto& s : sd->dynSets)
        std::stable_sort (s.begin(), s.end(), [&] (int a, int b) { return sd->zoneOf (a, 0).dynCentre() < sd->zoneOf (b, 0).dynCentre(); });

    // Playing behaviour.
    if (const auto& h = manifest["humanize"]; h.isObject())
    {
        sd->humanizeCents = juce::jlimit (0.0f, 100.0f, (float) (double) h.getProperty ("cents", 0.0));
        sd->humanizeMs    = juce::jlimit (0.0f, 100.0f, (float) (double) h.getProperty ("ms", 0.0));
        sd->humanizeDb    = juce::jlimit (0.0f, 24.0f, (float) (double) h.getProperty ("db", 0.0));
        sd->hasHumanize = sd->humanizeCents > 0.0f || sd->humanizeMs > 0.0f || sd->humanizeDb > 0.0f;
    }

    if (const auto& rr = manifest["rr_reset_ms"]; rr.isInt() || rr.isInt64() || rr.isDouble())
        sd->rrResetMs = juce::jlimit (0.0f, 600000.0f, (float) (double) rr);

    if (sd->byLayer[(size_t) Layer::body].empty() && ! format.startsWith ("libero.bundle/2"))
    {
        error = "bundle has no body zones";
        return nullptr;
    }

    const auto irName = manifest["ir"].toString();

    if (irName.isNotEmpty())
    {
        juce::String irError;
        double irRate = 0.0;

        if (readAudio (fm, build.getChildFile (irName), kMaxIRSeconds, sd->ir, irRate, irError))
            sd->irSampleRate = irRate;
        else
            sd->ir.setSize (0, 0);   // a broken IR is not fatal: Impronta falls back to Basilica
    }

    if (!reuseCache) return sd;
    std::shared_ptr<const SoundData> backing (std::move (sd));
    entry->sound = backing;
    return cachedCopy (std::move (backing));
}

} // namespace libero
