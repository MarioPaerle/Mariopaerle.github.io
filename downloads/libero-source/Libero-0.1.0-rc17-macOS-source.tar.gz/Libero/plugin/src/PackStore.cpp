#include "PackStore.h"
#include "PackCatalogue.h"
#include "DeltaPack.h"
#include "Library.h"
#include <juce_cryptography/juce_cryptography.h>
#include <array>
#include <map>
#include <atomic>
#include <mutex>

namespace libero::packs
{
namespace
{
std::mutex activityMutex;
std::map<const void*, juce::File> activeSounds, pendingSounds;
juce::String updatingBank;
bool bankInUseLocked (const juce::File& bank)
{
    for (const auto* rows : {&activeSounds, &pendingSounds})
        for (const auto& item : *rows) if (item.second.isAChildOf (bank)) return true;
    return false;
}
struct LoadGuard
{
    ~LoadGuard() { const std::lock_guard<std::mutex> lock (activityMutex); pendingSounds.erase (this); }
};
struct InstallGuard
{
    ~InstallGuard() { const std::lock_guard<std::mutex> lock (activityMutex); updatingBank = {}; }
};
std::shared_ptr<InstallGuard> acquireInstall (const juce::String& slug)
{
    const std::lock_guard<std::mutex> lock (activityMutex);
    if (bankInUseLocked (library::home().getChildFile ("banks").getChildFile (slug))) return {};
    auto guard = std::make_shared<InstallGuard>(); updatingBank = slug; return guard;
}
bool bankInUse (const juce::String& slug)
{
    const auto bank = library::home().getChildFile ("banks").getChildFile (slug);
    const std::lock_guard<std::mutex> lock (activityMutex);
    return bankInUseLocked (bank);
}
constexpr auto catalogueUrl = "https://mariopaerle.github.io/libero-catalog.json";
juce::var object (std::initializer_list<std::pair<const char*, juce::var>> fields)
{
    auto* o = new juce::DynamicObject();
    for (const auto& f : fields) o->setProperty (f.first, f.second);
    return o;
}
bool trustedUrl (const juce::String& text)
{
    const juce::URL u (text);
   #if LIBERO_HOST_TEST
    if (u.getScheme() == "http" && u.getDomain() == "127.0.0.1") return true;
   #endif
    return u.getScheme() == "https" && (u.getDomain() == "drive.usercontent.google.com"
        || u.getDomain() == "mariopaerle.github.io" || u.getDomain() == "github.com"
        || u.getDomain() == "objects.githubusercontent.com");
}
bool assetValid (const juce::var& p)
{
    const auto hash = p["sha256"].toString();
    return p.isObject() && trustedUrl (p["url"].toString()) && hash.length() == 64
        && hash.containsOnly ("0123456789abcdef") && (double) p["bytes"] > 0
        && (double) p["bytes"] < 20.0 * 1024 * 1024 * 1024
        && (double) p["uncompressed_bytes"] >= (double) p["bytes"];
}
int installedSounds (const juce::String& slug)
{
    int count = 0;
    for (const auto& folder : library::home().getChildFile("banks").getChildFile(slug).findChildFiles(juce::File::findDirectories, false))
        if (folder.getChildFile("build/manifest.json").existsAsFile()) ++count;
    return count;
}
juce::String fingerprint (const juce::String& slug)
{
    const auto f = library::home().getChildFile ("banks").getChildFile (slug);
    if (! f.exists()) return "absent";
    juce::String text = f.getChildFile ("bank.json").loadFileAsString();
    auto children = f.findChildFiles (juce::File::findDirectories, false); children.sort();
    for (const auto& child : children)
    {
        text += child.getFileName() + child.getChildFile ("build/manifest.json").loadFileAsString();
        text += child.getChildFile ("sample-edits.json").loadFileAsString();
        text += child.getChildFile ("sound.py").loadFileAsString();
    }
    return juce::SHA256 (text.toRawUTF8(), (size_t) text.getNumBytesAsUTF8()).toHexString();
}
class Store final : private juce::Thread
{
public:
    Store() : Thread ("Libero downloads"), catalog (juce::JSON::parse (fallbackCatalogue))
    {
        const auto cached = juce::JSON::parse (library::home().getChildFile ("cache/pack-catalog.json"));
        if (validateCatalogue (cached)) catalog = cached;
        const auto ready = juce::JSON::parse (library::home().getChildFile ("cache/update-ready.json"));
        const auto path = ready["path"].toString();
        if (juce::File::isAbsolutePath (path))
        {
            const juce::File file (path);
            if (file.isAChildOf (library::home().getChildFile ("cache/downloads")) && file.existsAsFile()
                && ready["sha256"].toString().length() == 64 && (int) ready["build"] > LIBERO_BUILD)
            {
                installer = file; installerHash = ready["sha256"].toString(); installerVersion = ready["version"].toString();
            }
        }
    }
    ~Store() override { signalThreadShouldExit(); stopThread (-1); }
    juce::var getCatalog (bool refresh)
    {
        if (refresh)
        {
            int code = 0;
            auto stream = juce::URL (catalogueUrl).createInputStream (
                juce::URL::InputStreamOptions (juce::URL::ParameterHandling::inAddress)
                    .withConnectionTimeoutMs (8000).withExtraHeaders ("Cache-Control: no-cache\r\n").withStatusCode (&code).withNumRedirectsToFollow (3));
            bool updated = false;
            if (stream && code == 200)
            {
                juce::MemoryBlock data;
                stream->readIntoMemoryBlock (data, 512 * 1024 + 1);
                auto value = data.getSize() <= 512 * 1024 ? juce::JSON::parse (data.toString()) : juce::var();
                if (validateCatalogue (value))
                {
                    const std::lock_guard<std::mutex> lock (mutex);
                    catalog = value; updated = true;
                    const auto cache = library::home().getChildFile ("cache/pack-catalog.json");
                    cache.getParentDirectory().createDirectory(); cache.replaceWithText (juce::JSON::toString (value));
                }
            }
            const std::lock_guard<std::mutex> lock (mutex);
            offline = ! updated;
        }
        const std::lock_guard<std::mutex> lock (mutex);
        return object ({{"ok", true}, {"catalog", catalog.clone()}, {"offline", offline},
                        {"currentBuild", LIBERO_BUILD}, {"currentVersion", LIBERO_RELEASE},
                       #if JUCE_MAC
                        {"platform", "macos"}
                       #elif JUCE_WINDOWS
                        {"platform", "windows"}
                       #else
                        {"platform", "unsupported"}
                       #endif
                       });
    }
   #if LIBERO_HOST_TEST
    void setForTest (const juce::var& value) { const std::lock_guard<std::mutex> lock (mutex); catalog = value.clone(); }
   #endif
    juce::var getStatus()
    {
        const std::lock_guard<std::mutex> lock (mutex);
        auto value = job.clone();
        value.getDynamicObject()->setProperty ("installerReady", installer.existsAsFile());
        value.getDynamicObject()->setProperty ("installerVersion", installerVersion);
        return value;
    }
    juce::var begin (const juce::String& id, bool app)
    {
        const std::lock_guard<std::mutex> lock (mutex);
        if (isThreadRunning()) return library::makeResult (false, "Another download is in progress.");
        juce::var entry;
        if (app)
        {
           #if JUCE_MAC
            entry = catalog["release"]["packages"]["macos"];
           #elif JUCE_WINDOWS
            entry = catalog["release"]["packages"]["windows"];
           #endif
            if ((int) catalog["release"]["build"] <= LIBERO_BUILD)
                return library::makeResult (false, "Libero is already up to date.");
        }
        else if (auto* rows = catalog["packs"].getArray())
            for (const auto& p : *rows) if (p["id"].toString() == id) entry = p;
        if (! assetValid (entry)) return library::makeResult (false, "This download is unavailable.");
        if (! app)
        {
            const auto installed = juce::JSON::parse (library::home().getChildFile ("banks").getChildFile (id).getChildFile ("bank.json"));
            if (installed.isObject() && installed["version"].toString() == entry["version"].toString()
                && installedSounds (id) >= (int) entry["sounds"])
                return library::makeResult (false, "This version is already installed.");
        }
        if (! app && bankInUse (id)) return library::makeResult (false, "Select a sound from another pack in all Libero instances before updating this pack.");
        asset = entry.clone(); if (app) { asset.getDynamicObject()->setProperty ("version", catalog["release"]["version"]); asset.getDynamicObject()->setProperty ("build", catalog["release"]["build"]); } application = app; transfer = asset.clone(); delta = false;
        if (!app)
        {
            const auto installed = juce::JSON::parse (library::home().getChildFile ("banks").getChildFile (id).getChildFile ("bank.json"));
            if (auto* updates = entry["deltas"].getArray())
                for (const auto& update : *updates)
                    if (update["from_version"].toString() == installed["version"].toString() && assetValid (update)
                        && (double) update["bytes"] < (double) transfer["bytes"])
                    { transfer = update.clone(); delta = true; }
        }
        expected = app ? juce::String() : fingerprint (id);
        stopped.store (false);
        if (app)
        {
            if (installer.exists()) installer.getParentDirectory().deleteRecursively();
            installer = juce::File(); installerHash = {}; installerVersion = {};
            library::home().getChildFile ("cache/update-ready.json").deleteFile();
        }
        job = object ({{"ok", true}, {"id", id}, {"application", app}, {"state", "connecting"},
                      {"jobId", juce::Uuid().toString()}, {"received", (juce::int64) 0}, {"total", transfer["bytes"]}, {"delta", delta}});
        startThread(); return object ({{"ok", true}});
    }
    juce::var abort()
    {
        const std::lock_guard<std::mutex> lock (mutex);
        if (job["state"].toString() == "installing")
            return library::makeResult (false, "Installation has started; wait for it to finish.");
        stopped.store (true); return library::makeResult (true);
    }
    juce::var launch()
    {
        juce::File file; juce::String hash;
        { const std::lock_guard<std::mutex> lock (mutex); file = installer; hash = installerHash; }
        if (! file.existsAsFile() || juce::SHA256 (file).toHexString() != hash)
            return library::makeResult (false, "The verified installer is unavailable. Download it again.");
       #if JUCE_WINDOWS
        return file.startAsProcess() ? library::makeResult (true) : library::makeResult (false, "Could not start the installer.");
       #elif JUCE_MAC
        // The archive is verified; installation is performed by an explicit user action.
        const auto dest = file.getSiblingFile ("unpacked");
        dest.deleteRecursively(); dest.createDirectory();
        juce::ZipFile zip (file);
        for (int i = 0; i < zip.getNumEntries(); ++i)
        {
            const auto name = zip.getEntry (i)->filename;
            if (juce::File::isAbsolutePath (name) || name.contains ("..") || name.contains ("\\"))
                return library::makeResult (false, "Unsafe installer archive.");
        }
        auto result = zip.uncompressTo (dest);
        if (result.failed()) return library::makeResult (false, result.getErrorMessage());
        const auto payload = dest.getChildFile ("Libero-macOS");
        const auto command = payload.getChildFile ("Install Libero.command");
        if (! command.existsAsFile())
        {
            payload.revealToUser();
            return object ({{"ok", true}, {"manual", true}, {"message", "Close your DAW, then copy the VST3/AU from this folder to your plugin folders."}});
        }
        command.setExecutePermission (true);
        return command.startAsProcess() ? library::makeResult (true) : library::makeResult (false, "Could not open the installer.");
       #else
        return library::makeResult (false, "Automatic installation is unavailable on this platform.");
       #endif
    }
private:
    void state (const juce::String& value, const juce::String& error = {})
    {
        const std::lock_guard<std::mutex> lock (mutex);
        job.getDynamicObject()->setProperty ("state", value);
        if (error.isNotEmpty()) job.getDynamicObject()->setProperty ("error", error);
    }
    void run() override
    {
        const auto folder = library::home().getChildFile ("cache/downloads").getChildFile (juce::Uuid().toString());
        const auto file = folder.getChildFile (application ?
           #if JUCE_WINDOWS
            "Libero-Setup.exe"
           #else
            "Libero-macOS.zip"
           #endif
            : "pack.liberobank");
        const auto finish = [&] (juce::String message) { folder.deleteRecursively(); state (stopped.load() ? "cancelled" : "error", stopped.load() ? juce::String() : message); };
        const auto bytes = (juce::int64) transfer["bytes"];
        library::home().createDirectory();
        const auto expanded = delta && transfer.hasProperty ("changed_bytes")
            ? juce::jlimit ((juce::int64) 0, (juce::int64) asset["uncompressed_bytes"], (juce::int64) transfer["changed_bytes"])
            : (juce::int64) asset["uncompressed_bytes"];
        if (library::home().getBytesFreeOnVolume() < bytes + 2 * expanded + 128 * 1024 * 1024)
        { finish ("Not enough disk space to download and install this file."); return; }
        if (! folder.createDirectory()) { finish ("Could not create the download folder."); return; }
        int code = 0;
        auto input = juce::URL (transfer["url"].toString()).createInputStream (
            juce::URL::InputStreamOptions (juce::URL::ParameterHandling::inAddress)
                .withConnectionTimeoutMs (10000).withStatusCode (&code).withNumRedirectsToFollow (5));
        if (! input || code != 200) { finish ("Download server unavailable. Check your connection and try again."); return; }
        juce::int64 received = 0; std::array<char, 128 * 1024> buffer;
        {
            juce::FileOutputStream output (file);
            if (! output.openedOk()) { finish ("Could not write the download."); return; }
            state ("downloading");
            while (! stopped.load() && ! threadShouldExit())
            {
                const auto count = input->read (buffer.data(), (int) buffer.size());
                if (count <= 0) break;
                received += count;
                if (received > bytes || ! output.write (buffer.data(), (size_t) count)) break;
                const std::lock_guard<std::mutex> lock (mutex);
                job.getDynamicObject()->setProperty ("received", received);
            }
            output.flush();
        }
        input.reset();
        if (stopped.load() || threadShouldExit()) { folder.deleteRecursively(); state ("cancelled"); return; }
        if (received != bytes || file.getSize() != bytes) { finish ("Incomplete download or unexpected server response. Try again."); return; }
        state ("verifying");
        if (juce::SHA256 (file).toHexString() != transfer["sha256"].toString())
        { finish ("The download checksum does not match. The file was not installed."); return; }
        if (stopped.load() || threadShouldExit()) { folder.deleteRecursively(); state ("cancelled"); return; }
        if (application)
        {
            { const std::lock_guard<std::mutex> lock (mutex); installer = file; installerHash = asset["sha256"].toString(); installerVersion = asset["version"].toString(); }
            const auto ready = object ({{"path", file.getFullPathName()}, {"sha256", asset["sha256"]},
                                       {"version", asset["version"]}, {"build", asset["build"]}});
            library::home().getChildFile ("cache/update-ready.json").replaceWithText (juce::JSON::toString (ready));
            state ("ready"); return;
        }
        auto bankFile = file;
        if (delta)
        {
            bankFile = folder.getChildFile (asset["id"].toString());
            state ("reconstructing");
            const auto result = reconstructDelta (file, bankFile, asset["id"].toString(), asset["version"].toString());
            if (result.failed())
            {
                // A modified/missing base must never produce a partial install. Retry the full verified pack.
                folder.deleteRecursively(); transfer = asset.clone(); delta = false;
                { const std::lock_guard<std::mutex> lock (mutex);
                  job.getDynamicObject()->setProperty ("received", (juce::int64) 0);
                  job.getDynamicObject()->setProperty ("total", transfer["bytes"]);
                  job.getDynamicObject()->setProperty ("delta", false);
                  job.getDynamicObject()->setProperty ("state", "connecting"); }
                if (!stopped.load() && !threadShouldExit()) run();
                else state ("cancelled");
                return;
            }
        }
        const auto plan = delta ? library::inspectStagedBank (bankFile) : library::inspectBank (bankFile);
        if (! (bool) plan["ok"] || plan["slug"].toString() != asset["id"].toString()
            || plan["bank"]["version"].toString() != asset["version"].toString()
            || (int) plan["soundCount"] != (int) asset["sounds"])
        { finish (plan["error"].toString().isNotEmpty() ? plan["error"].toString() : "The downloaded pack identity, version or sound count does not match the catalogue."); return; }
        const auto installGuard = acquireInstall (asset["id"].toString());
        if (! installGuard)
        { finish ("This pack is now in use. Select a sound from another pack in all instances before updating it."); return; }
        if (fingerprint (asset["id"].toString()) != expected)
        { finish ("The installed pack changed during the download. Review it and try again."); return; }
        if (stopped.load() || threadShouldExit()) { folder.deleteRecursively(); state ("cancelled"); return; }
        state ("installing");
        const auto result = delta ? library::importStagedBank (bankFile)
                                  : library::importBank (bankFile, installedSounds (asset["id"].toString()) < (int) asset["sounds"]);
        folder.deleteRecursively();
        if (! (bool) result["ok"]) { state ("error", result["error"].toString()); return; }
        state ("installed");
    }
    std::mutex mutex;
    juce::var catalog, asset, transfer, job = object ({{"state", "idle"}});
    bool offline = true, application = false, delta = false;
    std::atomic<bool> stopped { false };
    juce::String expected, installerHash, installerVersion;
    juce::File installer;
};
Store& store() { static Store s; return s; }
}
bool validateCatalogue (const juce::var& v)
{
    if (v["format"].toString() != "libero.pack-catalog/1") return false;
    auto* rows = v["packs"].getArray(); if (! rows || rows->size() > 200) return false;
    juce::StringArray seen;
    for (const auto& p : *rows)
    {
        const auto id = p["id"].toString();
        if (id.isEmpty() || id.length() > 48 || ! id.containsOnly ("abcdefghijklmnopqrstuvwxyz0123456789-")
            || seen.contains (id) || p["title"].toString().isEmpty() || p["version"].toString().isEmpty() || ! assetValid (p)) return false;
        if (p.hasProperty ("deltas"))
        {
            auto* updates = p["deltas"].getArray();
            if (!updates || updates->size() > 32) return false;
            juce::StringArray versions;
            for (const auto& update : *updates)
            {
                const auto from = update["from_version"].toString();
                if (from.isEmpty() || from == p["version"].toString() || versions.contains (from) || !assetValid (update)) return false;
                versions.add (from);
            }
        }
        seen.add (id);
    }
    if (v.hasProperty ("release"))
    {
        if ((int) v["release"]["build"] <= 0) return false;
        for (const auto& key : {"macos", "windows"}) if (! assetValid (v["release"]["packages"][key])) return false;
    }
    return true;
}
#if LIBERO_HOST_TEST
void setCatalogueForTest (const juce::var& value) { jassert (validateCatalogue (value)); store().setForTest (value); }
#endif
std::shared_ptr<void> acquireSoundLoad (const juce::File& folder)
{
    const std::lock_guard<std::mutex> lock (activityMutex);
    if (updatingBank.isNotEmpty() && folder.isAChildOf (library::home().getChildFile ("banks").getChildFile (updatingBank))) return {};
    auto guard = std::make_shared<LoadGuard>(); pendingSounds[guard.get()] = folder; return guard;
}
void setActiveSound (const void* instance, const juce::File& folder)
{ const std::lock_guard<std::mutex> lock (activityMutex); activeSounds[instance] = folder; }
void forgetInstance (const void* instance)
{ const std::lock_guard<std::mutex> lock (activityMutex); activeSounds.erase (instance); }
juce::var catalogue (bool refresh) { return store().getCatalog (refresh); }
juce::var status() { return store().getStatus(); }
juce::var start (const juce::String& id, bool application) { return store().begin (id, application); }
juce::var cancel() { return store().abort(); }
juce::var openInstaller() { return store().launch(); }
}
