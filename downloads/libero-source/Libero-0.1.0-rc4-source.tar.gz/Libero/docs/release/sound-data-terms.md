# Sound data terms for the release candidate

The release preparation uses CC0 1.0 for original Libero-generated audio, preset
figures and preset metadata authored for the public selection. This is separate
from the software's AGPLv3. The full CC0 instrument is available at
https://creativecommons.org/publicdomain/zero/1.0/legalcode.en .

Third-party source recordings retain their original terms. Read each preset's
`samples/credits.json`, `samples/ATTRIBUTION.md` and any included source-license
files. CC BY recordings require attribution, source/license links and a record
of modifications. Libero does not grant rights that the recording author did
not grant. A permissive software license does not make every working-library
sound eligible for an open bank.

The 18 restricted original presets remain outside the public selection; their
new cleared replacements are separate presets. The four authentic Taijiguy
Mellotron sets are also outside the general/open selection: their permission is
freeware/no-payware, not CC0 or an unrestricted open-content license.

No public distribution has taken place. Review the catalog and this separation
of software, original sound data and third-party recording terms with the final
release artifacts.
