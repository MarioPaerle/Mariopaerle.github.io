"""Licence classes and the rule that a sound is as restricted as its most restricted source."""

from __future__ import annotations

import json
from pathlib import Path

# most permissive first
CLASSES = ("cc0", "by", "by-sa", "sampling+", "nc", "eula", "unknown")
SHIPPABLE = ("cc0", "by", "by-sa")
LABELS = {"cc0": "CC0 / public domain", "by": "CC BY", "by-sa": "CC BY-SA", "sampling+": "CC Sampling Plus",
          "nc": "non-commercial", "eula": "private use only (EULA)", "unknown": "unknown terms"}


def most_restrictive(classes) -> str:
    cs = [c for c in classes if c]
    if not cs:
        return "cc0"
    return max(cs, key=lambda c: CLASSES.index(c) if c in CLASSES else len(CLASSES) - 1)


def read_credits(folder: Path) -> list[dict]:
    p = Path(folder) / "samples" / "credits.json"
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text())
    except (OSError, json.JSONDecodeError):
        return []
    return [c for c in data if isinstance(c, dict)] if isinstance(data, list) else []


def add_credit(folder: Path, credit: dict) -> None:
    """Add (or refresh, by source name) a structured credit in samples/credits.json."""
    p = Path(folder) / "samples" / "credits.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    items = [c for c in read_credits(folder) if c.get("source") != credit.get("source")]
    items.append(credit)
    p.write_text(json.dumps(items, indent=2, ensure_ascii=False) + "\n")


def bundle_license(credits: list[dict]) -> tuple[str, str]:
    """(licence text for the manifest, class). A sound with no credited sources is its author's own."""
    if not credits:
        return "original work", "cc0"
    cls = most_restrictive(c.get("license_class", "unknown") for c in credits)
    names = sorted({c.get("license", LABELS.get(c.get("license_class", ""), "?")) for c in credits
                    if c.get("license_class", "unknown") == cls})
    text = " + ".join(names)
    if cls not in SHIPPABLE:
        text += " — private use only, do not share this bundle"
    elif cls == "by-sa":
        text += " — share-alike: a shared bundle must carry the same licence"
    return text, cls


def attribution_text(credits: list[dict]) -> str:
    lines = ["# Credits", ""]
    for c in credits:
        parts = [c.get("source", "?")]
        if c.get("author"):
            parts.append(f"by {c['author']}")
        if c.get("license"):
            parts.append(c["license"])
        line = ", ".join(parts)
        if c.get("url"):
            line += f" <{c['url']}>"
        if c.get("retrieved"):
            line += f" (retrieved {c['retrieved']})"
        lines.append(f"- {line}")
    return "\n".join(lines) + "\n"
