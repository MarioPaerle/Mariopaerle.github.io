"""Run a free-form Python snippet against a sound's samples, isolated.

The snippet runs in a fresh interpreter with cwd = the sound folder, a hard
timeout, and no network (sockets are disabled in-process and, on macOS, the
interpreter runs under a sandbox profile that denies network access).
It must assign `result`: an Audio, or a dict {name: Audio} for several outputs.
"""

from __future__ import annotations

import functools
import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

RESULT_TAG = "LIBERO_WORKBENCH "
SANDBOX_PROFILE = "(version 1)(allow default)(deny network-outbound (remote ip))(deny network-inbound)"

PRELUDE_DOC = """In scope: Audio, Sound, synth, dsp, load, sample, np, math, sr (48000), samples (Path),
freq(note) → Hz, note(name) → MIDI, LoopGrid. `load`/`sample` resolve names inside samples/."""


@dataclass
class WorkbenchResult:
    ok: bool
    saved: list[str] = field(default_factory=list)
    stdout: str = ""
    error: str | None = None


@functools.lru_cache(maxsize=1)
def _sandbox_works() -> bool:
    exe = shutil.which("sandbox-exec") or ("/usr/bin/sandbox-exec" if Path("/usr/bin/sandbox-exec").exists() else None)
    if not exe:
        return False
    try:
        r = subprocess.run([exe, "-p", SANDBOX_PROFILE, sys.executable, "-c", "print(1)"], capture_output=True,
                           timeout=20)
        return r.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def run(folder: Path, code: str, out_name: str, timeout: float = 90.0) -> WorkbenchResult:
    from . import library

    folder = Path(folder).resolve()
    library.out_sample_path(folder, out_name)  # validates the name early
    cmd = [sys.executable, "-m", "libero.workbench", str(folder), out_name]
    if _sandbox_works():
        cmd = ["sandbox-exec", "-p", SANDBOX_PROFILE] + cmd
    env = dict(os.environ)
    env["PYTHONPATH"] = str(Path(__file__).resolve().parent.parent) + os.pathsep + env.get("PYTHONPATH", "")
    env["MPLBACKEND"] = "Agg"
    for k in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY"):
        env.pop(k, None)
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                            cwd=str(folder), env=env, start_new_session=True)
    try:
        out, err = proc.communicate(code, timeout=timeout)
    except subprocess.TimeoutExpired:
        import signal

        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            proc.kill()
        proc.wait()
        return WorkbenchResult(False, error=f"timed out after {timeout:.0f} s (killed). Shorten the audio or "
                                            f"simplify the processing.")
    lines = out.splitlines()
    user_out = "\n".join(l for l in lines if not l.startswith(RESULT_TAG))[-3000:]
    for line in reversed(lines):
        if line.startswith(RESULT_TAG):
            d = json.loads(line[len(RESULT_TAG):])
            return WorkbenchResult(d["ok"], d.get("saved", []), user_out, d.get("error"))
    tail = "\n".join(err.strip().splitlines()[-20:])
    return WorkbenchResult(False, stdout=user_out, error=f"workbench process exited with {proc.returncode}:\n{tail}")


def _disable_network():
    import socket

    def blocked(*a, **k):
        raise OSError("network access is disabled in the workbench")

    class NoSocket(socket.socket):
        def connect(self, *a, **k):
            blocked()

        def connect_ex(self, *a, **k):
            blocked()

    socket.socket = NoSocket
    socket.create_connection = blocked
    socket.getaddrinfo = blocked


def _child(folder: str, out_name: str) -> int:
    import math
    import traceback

    import numpy as np

    from . import dsp, library, synth
    from .audio import Audio, load, set_search_dirs
    from .recipe import Sound

    _disable_network()
    folder_p = Path(folder)
    set_search_dirs(folder_p / "samples", folder_p)
    code = sys.stdin.read()
    ns = {
        "Audio": Audio, "Sound": Sound, "synth": synth, "dsp": dsp, "load": load, "sample": load, "np": np,
        "math": math, "sr": 48000, "samples": folder_p / "samples", "freq": dsp.midi_to_freq,
        "note": dsp.parse_note, "LoopGrid": synth.LoopGrid, "__name__": "__workbench__",
    }
    res: dict = {"ok": False}
    try:
        exec(compile(code, "<workbench>", "exec"), ns)
        result = ns.get("result")
        if result is None:
            raise ValueError("the snippet must assign `result` (an Audio, or a dict of name → Audio)")
        items = result.items() if isinstance(result, dict) else [(None, result)]
        saved = []
        for key, a in items:
            if not isinstance(a, Audio):
                raise TypeError(f"result{'[' + repr(key) + ']' if key else ''} is {type(a).__name__}, not Audio")
            name = out_name if key is None else f"{out_name}_{key}"
            p = library.out_sample_path(folder_p, name)
            a.save(p)
            saved.append(str(p.relative_to(folder_p / "samples")))
        res = {"ok": True, "saved": saved}
    except Exception:
        tb = traceback.format_exc(limit=5)
        tb = tb.replace('File "<workbench>"', "snippet")
        res = {"ok": False, "error": tb[-2500:]}
    sys.stdout.write("\n" + RESULT_TAG + json.dumps(res) + "\n")
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(_child(sys.argv[1], sys.argv[2]))
