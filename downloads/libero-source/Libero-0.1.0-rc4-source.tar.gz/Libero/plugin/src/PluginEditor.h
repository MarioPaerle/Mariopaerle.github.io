#pragma once

#include "PluginProcessor.h"

#include <juce_gui_extra/juce_gui_extra.h>

namespace libero
{

// The UI is a WebView serving ui/ from resources embedded in the binary (SPEC §9).
class LiberoEditor : public juce::AudioProcessorEditor,
                     private LiberoProcessor::Listener,
                     private juce::Timer
{
public:
    explicit LiberoEditor (LiberoProcessor&);
    ~LiberoEditor() override;

    juce::WebBrowserComponent& getBrowser() noexcept { return *browser; }

    void paint (juce::Graphics&) override;
    void resized() override;

    // Embedded ui/ resources (also used by the theme functions).
    static std::optional<juce::WebBrowserComponent::Resource> getResource (const juce::String& url);
    static juce::StringArray getBuiltinThemes();
    static juce::String readBuiltinText (const juce::String& path);

private:
    void soundChanged() override;
    void soundLoading (const juce::var& info) override;
    void soundLoadFailed (const juce::String& error) override;
    void agentStatusChanged() override;
    void soundReloaded (bool automatic) override;
    void soundModifiedChanged (bool modified) override;
    void articulationChanged (int index, const juce::String& id) override;
    void timerCallback() override;

    juce::WebBrowserComponent::Options buildOptions();
    void addNativeFunctions (juce::WebBrowserComponent::Options&);

    LiberoProcessor& proc;

    std::vector<std::unique_ptr<juce::WebSliderRelay>> sliderRelays;
    std::vector<std::unique_ptr<juce::WebComboBoxRelay>> comboRelays;
    std::unique_ptr<juce::WebBrowserComponent> browser;
    juce::Label runtimeNotice;
    juce::HyperlinkButton runtimeDownload { "Install Microsoft WebView2 Runtime",
        juce::URL ("https://developer.microsoft.com/microsoft-edge/webview2/") };
    std::vector<std::unique_ptr<juce::WebSliderParameterAttachment>> sliderAttachments;
    std::vector<std::unique_ptr<juce::WebComboBoxParameterAttachment>> comboAttachments;

    std::array<float, 64> scopeL {}, scopeR {};

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LiberoEditor)
};

} // namespace libero
