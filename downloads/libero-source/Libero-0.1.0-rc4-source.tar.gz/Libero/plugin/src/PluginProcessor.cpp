#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "Library.h"
#include "ParamsJson.h"

#include <juce_audio_formats/juce_audio_formats.h>
#include <cmath>

namespace libero
{

namespace
{
    juce::String hostChoiceLabel (const char* canonical)
    {
        // Saved recipes use the canonical labels; host automation keeps the same indices.
        static constexpr std::pair<std::string_view, const char*> labels[] {
            { "Poli", "Poly" }, { "Velocità", "Velocity" },
            { "Modulazione", "Mod Wheel" }, { "Manopola", "Knob" },
            { "Basso", "Low-pass" }, { "Banda", "Band-pass" },
            { "Alto", "High-pass" }, { "Vocale", "Vocal" },
            { "Corde", "Strings" }, { "Vetro", "Glass" },
            { "Legno", "Wood" }, { "Metallo", "Metal" },
            { "Cappella", "Chapel" }, { "Cisterna", "Cistern" },
            { "Piastra", "Plate" }, { "Impronta", "Imprint" },
            { "Sega", "Saw" }, { "Quadra", "Square" },
            { "Triangolo", "Triangle" }, { "Seno", "Sine" },
            { "Rumore", "Noise" }, { "Libera", "Free" },
            { "Riavvia", "Retrigger" }, { "Libero", "Free" },
            { "Dente", "Ramp" }, { "Casuale", "Random" },
            { "Ampiezza", "Amplitude" }, { "Propria", "Dedicated" },
            { "Spento", "Off" }, { "Velluto", "Velvet" },
            { "Presenza", "Presence" }, { "Intimo", "Intimate" },
            { "Blu", "Blue" }, { "Soffio", "Breath" }
        };
        for (const auto& [source, english] : labels)
            if (source == canonical)
                return juce::String::fromUTF8 (english);
        return juce::String::fromUTF8 (canonical);
    }

    juce::var makeObject (std::initializer_list<std::pair<const char*, juce::var>> props)
    {
        auto* o = new juce::DynamicObject();

        for (const auto& [k, v] : props)
            o->setProperty (k, v);

        return juce::var (o);
    }

    // Shared between a waiting socket thread and the message-thread work it requested, so a
    // timed-out wait never leaves a dangling reference behind.
    struct PendingCall
    {
        juce::WaitableEvent done;
        std::atomic<bool> finished { false };
        bool ok = false;
        juce::String message;
        juce::var input;
        juce::Array<juce::var> applied, rejected;
    };

    bool waitFor (PendingCall& call, juce::Thread& caller, int timeoutMs)
    {
        const auto deadline = juce::Time::getMillisecondCounter() + (juce::uint32) timeoutMs;

        while (! call.finished.load())
        {
            if (caller.threadShouldExit() || juce::Time::getMillisecondCounter() > deadline)
                return false;

            call.done.wait (50);
        }

        return true;
    }

    juce::var readJsonFile (const juce::File& file)
    {
        return file.existsAsFile() ? juce::JSON::parse (file) : juce::var();
    }

    juce::var currentZoneEdit (const juce::File& folder, const juce::String& zoneFile,
                               const juce::String& sourceHash, const juce::var& zone)
    {
        const auto sidecar = readJsonFile (folder.getChildFile ("sample-edits.json"));
        const auto edits = sidecar["edits"];
        auto* object = edits.getDynamicObject();
        if (object == nullptr)
            return {};
        auto edit = object->getProperty (zoneFile);
        if (! edit.isObject() || !(bool) edit.getProperty ("enabled", false)
            || edit["source_hash"].toString() != sourceHash)
            return {};
        bool sameDyn = edit["dyn"].isVoid() == zone["dyn"].isVoid();
        if (sameDyn && edit["dyn"].isArray() && zone["dyn"].isArray())
        {
            const auto* ed = edit["dyn"].getArray();
            const auto* zd = zone["dyn"].getArray();
            sameDyn = ed != nullptr && zd != nullptr && ed->size() == zd->size();
            if (sameDyn)
                for (int i = 0; i < ed->size(); ++i)
                    sameDyn = sameDyn && std::abs ((double) (*ed)[i] - (double) (*zd)[i]) < 1.0e-6;
        }
        if ((int) edit.getProperty ("root", -1000) != (int) zone.getProperty ("root", -2000)
            || (int) edit.getProperty ("lo", -1000) != (int) zone.getProperty ("lo", -2000)
            || (int) edit.getProperty ("hi", -1000) != (int) zone.getProperty ("hi", -2000)
            || (int) edit.getProperty ("vel_lo", -1000) != (int) zone.getProperty ("vel_lo", -2000)
            || (int) edit.getProperty ("vel_hi", -1000) != (int) zone.getProperty ("vel_hi", -2000)
            || (int) edit.getProperty ("take", 0) != (int) zone.getProperty ("take", 0)
            || edit.getProperty ("articulation", juce::var()).toString() != zone.getProperty ("articulation", juce::var()).toString()
            || ! sameDyn)
            return {};
        const auto numeric = [] (const juce::var& v) { return v.isInt() || v.isInt64() || v.isDouble(); };
        for (const auto* key : { "start_s", "end_s", "loop_start_s", "loop_end_s", "crossfade_ms" })
            if (! numeric (edit.getProperty (key, juce::var()))) return {};
        const auto start = (double) edit["start_s"], end = (double) edit["end_s"];
        const auto loopStart = (double) edit["loop_start_s"], loopEnd = (double) edit["loop_end_s"];
        const auto crossfade = (double) edit["crossfade_ms"];
        if (! std::isfinite (start) || ! std::isfinite (end) || ! std::isfinite (loopStart)
            || ! std::isfinite (loopEnd) || ! std::isfinite (crossfade) || start < 0.0
            || end - start < 0.05 || crossfade < 0.0 || crossfade > 500.0
            || ((bool) edit.getProperty ("loop_enabled", false)
                && (loopStart < start || loopEnd - loopStart < 0.05 || loopEnd > end)))
            return {};
        return edit;
    }

    bool sampleEditorEligible (const juce::File& folder)
    {
        if (folder.getChildFile ("samples/map.json").existsAsFile())
            return true;
        const auto recipe = folder.getChildFile ("sound.py").loadFileAsString();
        const auto at = recipe.indexOf (".multisample(");
        if (at < 0)
            return false;
        const auto first = recipe.substring (at + 13, recipe.indexOfChar (',', at + 13)).trim();
        return first == "'body'" || first == "\"body\"";
    }

    bool simplePitchedSampleManifest (const juce::var& manifest)
    {
        const auto* zones = manifest["zones"].getArray();
        if (zones == nullptr || zones->isEmpty())
            return false;
        for (const auto& z : *zones)
            if (z["layer"].toString() != "body" || ! (bool) z.getProperty ("pitched", true))
                return false;
        return true;
    }

    bool safeZoneFilename (const juce::String& name)
    {
        return name.isNotEmpty() && name == juce::File (name).getFileName()
            && ! name.contains ("..") && ! name.containsChar ('\\') && ! name.startsWithChar ('/');
    }

    bool readSampleDuration (const juce::File& file, double& duration, double& sampleRate)
    {
        juce::AudioFormatManager fm;
        fm.registerBasicFormats();
        auto reader = std::unique_ptr<juce::AudioFormatReader> (fm.createReaderFor (file));
        if (reader == nullptr || reader->sampleRate <= 0 || reader->lengthInSamples < 2
            || reader->lengthInSamples > (juce::int64) (120.0 * reader->sampleRate))
            return false;
        sampleRate = reader->sampleRate;
        duration = (double) reader->lengthInSamples / sampleRate;
        return std::isfinite (duration) && duration > 0.0;
    }
}

juce::var LiberoProcessor::setColorTag (const juce::File& folder, int tag)
{
    auto r = library::setColorTag (folder, tag);

    if ((bool) r["ok"] && currentSoundInfo.isObject()
        && library::soundFolderFor (folder).getFullPathName() == getCurrentSoundPath())
        currentSoundInfo.getDynamicObject()->setProperty ("colorTag", tag);

    return r;
}

juce::var LiberoProcessor::sampleEditorInfo() const
{
    return sampleEditorInfoForFolder (juce::File (getCurrentSoundPath()));
}

juce::var LiberoProcessor::sampleEditorInfoForFolder (const juce::File& folderIn)
{
    const auto folder = library::soundFolderFor (folderIn);
    const auto build = folder.getChildFile ("build");
    const auto manifest = readJsonFile (build.getChildFile ("manifest.json"));
    const auto sourceHash = manifest["source_hash"].toString();
    const auto sampleRate = (double) manifest.getProperty ("sample_rate", 0.0);
    juce::Array<juce::var> zones;
    juce::Array<juce::var> warnings;
    const auto editable = folder.isAChildOf (library::soundsDir()) || folder.isAChildOf (library::sketchesDir());

    if (! manifest.isObject() || sampleRate <= 0.0 || ! sampleEditorEligible (folder)
        || ! simplePitchedSampleManifest (manifest))
        return makeObject ({ { "eligible", false }, { "editable", false }, { "zones", zones } });

    const auto sidecarFile = folder.getChildFile ("sample-edits.json");
    if (sidecarFile.existsAsFile())
    {
        const auto sidecar = readJsonFile (sidecarFile);
        const auto* edits = sidecar["edits"].getDynamicObject();
        bool stale = ! sidecar.isObject() || sidecar["format"].toString() != "libero.sample-edits/1" || edits == nullptr;
        if (edits != nullptr)
            for (int i = 0; i < edits->getProperties().size(); ++i)
            {
                const auto key = edits->getProperties().getName (i).toString();
                const auto edit = edits->getProperties().getValueAt (i);
                bool matched = false;
                if (const auto* manifestZones = manifest["zones"].getArray())
                    for (const auto& z : *manifestZones)
                        if (z["file"].toString() == key && currentZoneEdit (folder, key, sourceHash, z).isObject())
                            matched = true;
                stale = stale || ! matched || ! edit.isObject();
            }
        if (stale)
            warnings.add ("Some saved sample edits are stale or invalid and are being ignored.");
    }

    if (const auto* list = manifest["zones"].getArray())
    {
        juce::StringArray bodyFiles;
        for (const auto& z : *list)
            if (z["layer"].toString() == "body" && (bool) z.getProperty ("pitched", true))
                bodyFiles.add (z["file"].toString());
        for (const auto& z : *list)
        {
            if (z["layer"].toString() != "body" || !(bool) z.getProperty ("pitched", true))
                continue;
            const auto file = z["file"].toString();
            if (! safeZoneFilename (file) || ! build.getChildFile (file).existsAsFile())
                continue;
            const auto edit = currentZoneEdit (folder, file, sourceHash, z);
            const auto loop = z["loop"];
            const auto defaultLoop = loop.isObject();
            const auto defaultStart = defaultLoop ? (double) loop.getProperty ("start", 0.0) / sampleRate : 0.0;
            const auto defaultEnd = defaultLoop ? (double) loop.getProperty ("end", 0.0) / sampleRate : 0.0;
            const auto start = edit.isObject() ? (double) edit.getProperty ("start_s", 0.0) : 0.0;
            const auto end = edit.isObject() ? (double) edit.getProperty ("end_s", 0.0) : 0.0;
            int fileCount = 0;
            for (const auto& bodyFile : bodyFiles)
                if (bodyFile == file) ++fileCount;
            zones.add (makeObject ({
                { "file", file }, { "root", z.getProperty ("root", 60) },
                { "lo", z.getProperty ("lo", 0) }, { "hi", z.getProperty ("hi", 127) },
                { "vel_lo", z.getProperty ("vel_lo", 1) }, { "vel_hi", z.getProperty ("vel_hi", 127) },
                { "take", z.getProperty ("take", 0) }, { "articulation", z.getProperty ("articulation", juce::var()) },
                { "dyn", z.getProperty ("dyn", juce::var()) }, { "source_hash", sourceHash },
                { "edited", edit.isObject() }, { "duration_s", -1.0 },
                { "start_s", edit.isObject() ? start : 0.0 },
                { "end_s", edit.isObject() ? end : 0.0 },
                { "loop_enabled", edit.isObject() ? (bool) edit.getProperty ("loop_enabled", false) : defaultLoop },
                { "loop_start_s", edit.isObject() ? (double) edit.getProperty ("loop_start_s", 0.0) : defaultStart },
                { "loop_end_s", edit.isObject() ? (double) edit.getProperty ("loop_end_s", 0.0) : defaultEnd },
                { "default_loop_enabled", defaultLoop }, { "default_loop_start_s", defaultStart }, { "default_loop_end_s", defaultEnd },
                { "crossfade_ms", edit.isObject() ? (double) edit.getProperty ("crossfade_ms", 20.0)
                                                   : (defaultLoop ? (double) loop.getProperty ("crossfade", 0) * 1000.0 / sampleRate : 20.0) },
                { "file_unique", fileCount == 1 }
            }));
        }
    }

    return makeObject ({ { "eligible", ! zones.isEmpty() }, { "editable", editable }, { "warnings", warnings },
                         { "sound_path", folder.getFullPathName() }, { "source_hash", sourceHash },
                         { "read_only_reason", editable ? juce::var() : juce::var ("Use Save as… to edit a personal copy.") },
                         { "title", manifest["title"] }, { "zones", zones } });
}

juce::var LiberoProcessor::sampleEditorWaveform (const juce::String& zoneFile) const
{
    return sampleEditorWaveformForFolder (juce::File (getCurrentSoundPath()), zoneFile);
}

juce::var LiberoProcessor::sampleEditorWaveformForFolder (const juce::File& folderIn, const juce::String& zoneFile)
{
    const auto folder = library::soundFolderFor (folderIn);
    const auto build = folder.getChildFile ("build");
    const auto manifest = readJsonFile (build.getChildFile ("manifest.json"));
    const auto sampleRate = (double) manifest.getProperty ("sample_rate", 0.0);
    if (! manifest.isObject() || ! sampleEditorEligible (folder) || ! simplePitchedSampleManifest (manifest)
        || ! safeZoneFilename (zoneFile))
        return makeObject ({ { "ok", false }, { "error", "sample editor is not available for this sound" } });

    bool knownZone = false;
    if (const auto* list = manifest["zones"].getArray())
        for (const auto& z : *list)
            if (z["file"].toString() == zoneFile && z["layer"].toString() == "body"
                && (bool) z.getProperty ("pitched", true))
                knownZone = true;
    if (! knownZone)
        return makeObject ({ { "ok", false }, { "error", "unknown sample zone" } });

    auto reader = std::unique_ptr<juce::AudioFormatReader>();
    juce::AudioFormatManager fm;
    fm.registerBasicFormats();
    reader.reset (fm.createReaderFor (build.getChildFile (zoneFile)));
    if (reader == nullptr || reader->sampleRate <= 0 || reader->lengthInSamples < 2
        || reader->lengthInSamples > (juce::int64) (120.0 * reader->sampleRate))
        return makeObject ({ { "ok", false }, { "error", "could not read sample waveform" } });

    constexpr int bins = 900;
    std::vector<float> mins ((size_t) bins, 1.0f), maxs ((size_t) bins, -1.0f);
    const auto total = (int) reader->lengthInSamples;
    const auto channels = (int) juce::jlimit ((unsigned int) 1, (unsigned int) 2, reader->numChannels);
    juce::AudioBuffer<float> chunk (channels, 8192);
    for (int pos = 0; pos < total; pos += chunk.getNumSamples())
    {
        const auto count = std::min (chunk.getNumSamples(), total - pos);
        chunk.clear();
        if (! reader->read (&chunk, 0, count, pos, true, channels > 1))
            return makeObject ({ { "ok", false }, { "error", "could not decode sample waveform" } });
        for (int i = 0; i < count; ++i)
        {
            float low = 1.0f, high = -1.0f;
            for (int c = 0; c < channels; ++c)
            {
                const auto value = chunk.getSample (c, i);
                low = juce::jmin (low, value);
                high = juce::jmax (high, value);
            }
            const auto bin = juce::jmin (bins - 1, (int) ((juce::int64) (pos + i) * bins / total));
            mins[(size_t) bin] = juce::jmin (mins[(size_t) bin], low);
            maxs[(size_t) bin] = juce::jmax (maxs[(size_t) bin], high);
        }
    }
    juce::Array<juce::var> points;
    for (int i = 0; i < bins; ++i)
        points.add (juce::var (juce::Array<juce::var> { mins[(size_t) i], maxs[(size_t) i] }));

    const auto duration = (double) reader->lengthInSamples / reader->sampleRate;
    juce::var defaultLoop = false;
    double defaultLoopStart = 0.0, defaultLoopEnd = 0.0, defaultCrossfade = 20.0;
    if (const auto* list = manifest["zones"].getArray())
        for (const auto& z : *list)
            if (z["file"].toString() == zoneFile)
            {
                const auto loop = z["loop"];
                defaultLoop = loop.isObject();
                if (defaultLoop && sampleRate > 0.0)
                {
                    defaultLoopStart = (double) loop.getProperty ("start", 0.0) / sampleRate;
                    defaultLoopEnd = (double) loop.getProperty ("end", 0.0) / sampleRate;
                    defaultCrossfade = (double) loop.getProperty ("crossfade", 0.0) * 1000.0 / sampleRate;
                }
                break;
            }
    juce::var result = makeObject ({ { "ok", true }, { "file", zoneFile }, { "sample_rate", reader->sampleRate },
                                    { "duration_s", duration }, { "points", points },
                                    { "source", "compiled playback sample; markers are applied on reload" },
                                    { "default_loop_enabled", defaultLoop }, { "default_loop_start_s", defaultLoopStart },
                                    { "default_loop_end_s", defaultLoopEnd }, { "default_crossfade_ms", defaultCrossfade } });
    return result;
}

void LiberoProcessor::applySampleEditorEdit (const juce::var& input, std::function<void (bool, juce::String)> done)
{
    const auto folder = library::soundFolderFor (juce::File (getCurrentSoundPath()));
    if (! (folder.isAChildOf (library::soundsDir()) || folder.isAChildOf (library::sketchesDir())))
    {
        done (false, "Save as… a personal copy before editing samples.");
        return;
    }
    if (! input.isObject())
    {
        done (false, "invalid sample edit");
        return;
    }
    const auto zoneFile = input["file"].toString();
    if (input["sound_path"].toString() != folder.getFullPathName())
    {
        done (false, "the selected sound changed; reload the waveform and try again");
        return;
    }
    const auto info = sampleEditorInfo();
    const auto* zones = info["zones"].getArray();
    const auto signature = input["zone"];
    const juce::var* selected = nullptr;
    if (zones != nullptr)
        for (const auto& zone : *zones)
        {
            bool sameDyn = zone["dyn"].isVoid() == signature["dyn"].isVoid();
            if (sameDyn && zone["dyn"].isArray() && signature["dyn"].isArray())
            {
                const auto* zd = zone["dyn"].getArray();
                const auto* sd = signature["dyn"].getArray();
                sameDyn = zd != nullptr && sd != nullptr && zd->size() == sd->size();
                if (sameDyn)
                    for (int i = 0; i < zd->size(); ++i)
                        sameDyn = sameDyn && std::abs ((double) (*zd)[i] - (double) (*sd)[i]) < 1.0e-6;
            }
            const bool same = zone["file"].toString() == zoneFile && signature["file"].toString() == zoneFile
                && (int) zone.getProperty ("root", -1000) == (int) signature.getProperty ("root", -2000)
                && (int) zone.getProperty ("lo", -1000) == (int) signature.getProperty ("lo", -2000)
                && (int) zone.getProperty ("hi", -1000) == (int) signature.getProperty ("hi", -2000)
                && (int) zone.getProperty ("vel_lo", -1000) == (int) signature.getProperty ("vel_lo", -2000)
                && (int) zone.getProperty ("vel_hi", -1000) == (int) signature.getProperty ("vel_hi", -2000)
                && (int) zone.getProperty ("take", 0) == (int) signature.getProperty ("take", 0)
                && zone.getProperty ("articulation", juce::var()).toString() == signature.getProperty ("articulation", juce::var()).toString()
                && sameDyn;
            if (same)
            {
                selected = &zone;
                break;
            }
        }
    if (selected == nullptr)
    {
        done (false, "sample zone is unavailable or has changed");
        return;
    }
    if (! (bool) (*selected).getProperty ("file_unique", false)
        || input["source_hash"].toString() != (*selected)["source_hash"].toString())
    {
        done (false, "this zone is shared or changed; select a unique current sample zone");
        return;
    }

    const auto build = folder.getChildFile ("build");
    double duration = 0.0, rate = 0.0;
    if (! safeZoneFilename (zoneFile) || ! readSampleDuration (build.getChildFile (zoneFile), duration, rate))
    {
        done (false, "could not read the selected sample");
        return;
    }
    const auto start = (double) input.getProperty ("start_s", 0.0);
    const auto end = (double) input.getProperty ("end_s", duration);
    const auto loopOn = (bool) input.getProperty ("loop_enabled", false);
    const auto loopStart = (double) input.getProperty ("loop_start_s", start);
    const auto loopEnd = (double) input.getProperty ("loop_end_s", end);
    const auto crossfade = (double) input.getProperty ("crossfade_ms", 20.0);
    if (! std::isfinite (start) || ! std::isfinite (end) || ! std::isfinite (loopStart)
        || ! std::isfinite (loopEnd) || ! std::isfinite (crossfade)
        || start < 0.0 || end > duration || end - start < 0.05
        || crossfade < 0.0 || crossfade > 500.0
        || (loopOn && (loopStart < start || loopEnd > end || loopEnd - loopStart < 0.05)))
    {
        done (false, "sample bounds or loop are outside the selected waveform");
        return;
    }

    const auto sidecarFile = folder.getChildFile ("sample-edits.json");
    auto sidecar = readJsonFile (sidecarFile);
    if (sidecarFile.existsAsFile() && (! sidecar.isObject() || sidecar["format"].toString() != "libero.sample-edits/1"
        || ! sidecar["edits"].isObject() || sidecarFile.getSize() > 1024 * 1024))
    {
        done (false, "sample-edits.json is invalid; no changes were written");
        return;
    }
    if (! sidecar.isObject())
        sidecar = makeObject ({ { "format", "libero.sample-edits/1" }, { "edits", juce::var (new juce::DynamicObject()) } });
    auto edits = sidecar.getProperty ("edits", juce::var (new juce::DynamicObject()));
    if (! edits.isObject())
        edits = juce::var (new juce::DynamicObject());
    auto* em = edits.getDynamicObject();
    juce::var entry = makeObject ({
        { "enabled", true }, { "source_hash", (*selected)["source_hash"] },
        { "root", (*selected)["root"] }, { "lo", (*selected)["lo"] }, { "hi", (*selected)["hi"] },
        { "vel_lo", (*selected)["vel_lo"] }, { "vel_hi", (*selected)["vel_hi"] }, { "take", (*selected)["take"] },
        { "articulation", (*selected)["articulation"] }, { "start_s", start }, { "end_s", end },
        { "loop_enabled", loopOn }, { "loop_start_s", loopStart }, { "loop_end_s", loopEnd },
        { "crossfade_ms", crossfade }
    });
    em->setProperty (zoneFile, entry);
    if (em->getProperties().size() > 4096 || ! sidecarFile.replaceWithText (juce::JSON::toString (sidecar, true) + "\n"))
    {
        done (false, "could not save sample edits");
        return;
    }
    reloadSound (false, [done = std::move (done)] (bool ok, juce::String message) mutable
    {
        done (ok, ok ? juce::String() : message);
    });
}

juce::AudioProcessorValueTreeState::ParameterLayout LiberoProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    for (int i = 0; i < kNumParams; ++i)
    {
        const auto& s = spec (i);
        const juce::ParameterID pid { s.id, 1 };

        switch (s.scale)
        {
            case Scale::choice:
            {
                juce::StringArray choices;

                for (int c = 0; c < s.numChoices; ++c)
                    choices.add (hostChoiceLabel (s.choices[c]));

                layout.add (std::make_unique<juce::AudioParameterChoice> (pid, juce::String::fromUTF8 (s.name), choices, (int) s.def));
                break;
            }

            case Scale::stepped:
                layout.add (std::make_unique<juce::AudioParameterInt> (pid, juce::String::fromUTF8 (s.name), (int) s.min, (int) s.max, (int) s.def,
                                                                       juce::AudioParameterIntAttributes{}.withLabel (juce::String::fromUTF8 (s.unit))));
                break;

            case Scale::continuous:
            {
                juce::NormalisableRange<float> range (s.min, s.max, 0.0f, skewFactor (s));
                layout.add (std::make_unique<juce::AudioParameterFloat> (pid, juce::String::fromUTF8 (s.name), range, s.def,
                                                                         juce::AudioParameterFloatAttributes{}.withLabel (juce::String::fromUTF8 (s.unit))));
                break;
            }
        }
    }

    return layout;
}

LiberoProcessor::LiberoProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, &undoManager, "LIBERO", createLayout())
{
    for (int i = 0; i < kNumParams; ++i)
        rawParams[(size_t) i] = apvts.getRawParameterValue (spec (i).id);

    scopeL.resize (kScopeSize);
    scopeR.resize (kScopeSize);
    scopeReadL.resize (kScopeSize);
    scopeReadR.resize (kScopeSize);
    scopeHistoryL.assign (4096, 0.0f);
    scopeHistoryR.assign (4096, 0.0f);

    hostName = juce::PluginHostType().getHostDescription();

    for (int i = 0; i < kNumParams; ++i)
        paramSnapshot.v[(size_t) i] = rawParams[(size_t) i]->load();

    engine.setParameters (paramSnapshot);

    {
        double bpm = 0.0;

        if (auto* ph = getPlayHead())
            if (auto pos = ph->getPosition())
                if (auto b = pos->getBpm())
                    bpm = *b;

        engine.setTempo (bpm);
    }
    engine.prepare (currentSampleRate.load(), currentBlockSize.load());

    agent.start (hostName);
    startTimerHz (4);

    // A fresh instance should never be silent. Hosts restore state right after
    // construction; if none arrives, fall back to the last sound this machine played,
    // or the first one in the library.
    juce::Timer::callAfterDelay (600, [this, a = alive]
    {
        if (a->load() && ! stateRestored && getCurrentSoundPath().isEmpty())
            loadDefaultSound();
    });
}

void LiberoProcessor::loadDefaultSound()
{
    const auto last = library::readConfig().getProperty ("last_sound", {}).toString();

    if (last.isNotEmpty() && juce::File::isAbsolutePath (last) && resolveBuildDir (juce::File (last)).isDirectory())
    {
        loadSound (juce::File (last), true);
        return;
    }

    juce::String fallback;

    for (const auto& s : *library::listSounds().getArray())
    {
        if (fallback.isEmpty() || (bool) s.getProperty ("saved", false))
            fallback = s.getProperty ("path", {}).toString();

        if ((bool) s.getProperty ("saved", false))
            break;
    }

    if (fallback.isNotEmpty())
        loadSound (juce::File (fallback), true);
}

LiberoProcessor::~LiberoProcessor()
{
    alive->store (false);
    stopTimer();
    agent.stop();
    loaderPool.removeAllJobs (true, 10000);
    engine.collectGarbage();
}

void LiberoProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    currentBlockSize = samplesPerBlock;

    for (int i = 0; i < kNumParams; ++i)
        paramSnapshot.v[(size_t) i] = rawParams[(size_t) i]->load();

    engine.setParameters (paramSnapshot);
    engine.prepare (sampleRate, samplesPerBlock);
    injected.ensureSize (8192);

    for (auto& p : pendingOffs)
        p.pitch = -1;

    // Bundles are resampled at load time: reload if the host rate changed under us.
    const auto folder = getCurrentSoundPath();

    if (folder.isNotEmpty() && std::abs (loadedRate.load() - sampleRate) > 0.5)
    {
        juce::MessageManager::callAsync ([this, folder, a = alive]
        {
            if (a->load())
                loadSound (juce::File (folder), false);
        });
    }
}

bool LiberoProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void LiberoProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;

    const auto n = buffer.getNumSamples();

    if (buffer.getNumChannels() < 2 || n == 0)
    {
        buffer.clear();
        midi.clear();
        return;
    }

    for (int i = 0; i < kNumParams; ++i)
        paramSnapshot.v[(size_t) i] = rawParams[(size_t) i]->load (std::memory_order_relaxed);

    engine.setParameters (paramSnapshot);

    injected.clear();
    injected.addEvents (midi, 0, n, 0);

    for (auto& p : pendingOffs)
    {
        if (p.pitch < 0)
            continue;

        if (p.samplesLeft < n)
        {
            injected.addEvent (juce::MidiMessage::noteOff (1, p.pitch), (int) p.samplesLeft);
            p.pitch = -1;
        }
        else
        {
            p.samplesLeft -= n;
        }
    }

    {
        const auto scope = noteFifo.read (noteFifo.getNumReady());
        const auto sr = currentSampleRate.load();

        const auto handle = [&] (int start, int size)
        {
            for (int k = start; k < start + size; ++k)
            {
                const auto& req = noteQueue[(size_t) k];

                // Panic travels through the same queue so it only silences what came before it.
                if (req.pitch < 0)
                {
                    for (auto& p : pendingOffs)
                        p.pitch = -1;

                    injected.addEvent (juce::MidiMessage::allSoundOff (1), 0);
                    continue;
                }

                injected.addEvent (juce::MidiMessage::noteOn (1, req.pitch, (juce::uint8) req.velocity), 0);

                for (auto& p : pendingOffs)
                {
                    if (p.pitch < 0)
                    {
                        p.pitch = req.pitch;
                        p.samplesLeft = std::max<juce::int64> (1, (juce::int64) (req.durationMs * 0.001 * sr));
                        break;
                    }
                }
            }
        };

        handle (scope.startIndex1, scope.blockSize1);
        handle (scope.startIndex2, scope.blockSize2);
    }

    auto* l = buffer.getWritePointer (0);
    auto* r = buffer.getWritePointer (1);
    engine.process (l, r, n, injected);

    for (int c = 2; c < buffer.getNumChannels(); ++c)
        buffer.clear (c, 0, n);

    if (scopeFifo.getFreeSpace() >= n)
    {
        const auto w = scopeFifo.write (n);
        std::copy (l, l + w.blockSize1, scopeL.data() + w.startIndex1);
        std::copy (r, r + w.blockSize1, scopeR.data() + w.startIndex1);
        std::copy (l + w.blockSize1, l + w.blockSize1 + w.blockSize2, scopeL.data() + w.startIndex2);
        std::copy (r + w.blockSize1, r + w.blockSize1 + w.blockSize2, scopeR.data() + w.startIndex2);
    }

    midi.clear();
}

void LiberoProcessor::queueNote (int pitch, int velocity, int durationMs) noexcept
{
    const auto w = noteFifo.write (1);

    if (w.blockSize1 > 0)
        noteQueue[(size_t) w.startIndex1] = { juce::jlimit (0, 127, pitch), juce::jlimit (1, 127, velocity),
                                              juce::jlimit (1, 60000, durationMs) };
}

void LiberoProcessor::queuePanic() noexcept
{
    const auto w = noteFifo.write (1);

    if (w.blockSize1 > 0)
        noteQueue[(size_t) w.startIndex1] = { -1, 0, 0 };
}

bool LiberoProcessor::readScope (std::array<float, 64>& outL, std::array<float, 64>& outR, float& level)
{
    const auto ready = scopeFifo.getNumReady();

    if (ready == 0)
        return false;

    const auto rd = scopeFifo.read (ready);
    const auto history = (int) scopeHistoryL.size();

    const auto append = [&] (int start, int size)
    {
        // Keep only the newest `history` samples.
        const auto skip = std::max (0, size - history);
        start += skip;
        size -= skip;

        const auto keep = history - size;
        std::move (scopeHistoryL.begin() + size, scopeHistoryL.end(), scopeHistoryL.begin());
        std::move (scopeHistoryR.begin() + size, scopeHistoryR.end(), scopeHistoryR.begin());
        std::copy (scopeL.begin() + start, scopeL.begin() + start + size, scopeHistoryL.begin() + keep);
        std::copy (scopeR.begin() + start, scopeR.begin() + start + size, scopeHistoryR.begin() + keep);
    };

    append (rd.startIndex1, rd.blockSize1);
    append (rd.startIndex2, rd.blockSize2);

    const auto window = juce::jlimit (64, history, (int) (currentSampleRate.load() / 30.0));
    const auto offset = history - window;
    const auto bin = window / 64;
    double sumSq = 0.0;

    for (int p = 0; p < 64; ++p)
    {
        float pl = 0.0f, pr = 0.0f;

        for (int k = 0; k < bin; ++k)
        {
            const auto sl = scopeHistoryL[(size_t) (offset + p * bin + k)];
            const auto sr = scopeHistoryR[(size_t) (offset + p * bin + k)];
            if (std::abs (sl) > std::abs (pl)) pl = sl;
            if (std::abs (sr) > std::abs (pr)) pr = sr;
            sumSq += (double) sl * sl + (double) sr * sr;
        }

        outL[(size_t) p] = pl;
        outR[(size_t) p] = pr;
    }

    level = (float) std::sqrt (sumSq / std::max (1, 2 * bin * 64));
    return true;
}

juce::AudioProcessorEditor* LiberoProcessor::createEditor()
{
    return new LiberoEditor (*this);
}

void LiberoProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    state.setProperty ("soundPath", getCurrentSoundPath(), nullptr);
    state.setProperty ("stateVersion", 1, nullptr);

    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, dest);
}

void LiberoProcessor::setStateInformation (const void* data, int size)
{
    const auto xml = getXmlFromBinary (data, size);

    if (xml == nullptr || ! xml->hasTagName (apvts.state.getType()))
        return;

    auto tree = juce::ValueTree::fromXml (*xml);
    // APVTS retains the previous live value for parameters absent from an old
    // state. Loading a pre-Caldi project into an already warmed instance must
    // restore the bypass, rather than inherit that instance's previous chain.
    // Existing/saved values win, including partial newer states and automation.
    for (int i = (int) P::caldi_mode; i <= (int) P::caldi_output; ++i)
    {
        const auto& s = spec (i);
        if (! tree.getChildWithProperty ("id", s.id).isValid())
        {
            juce::ValueTree child ("PARAM");
            child.setProperty ("id", s.id, nullptr);
            child.setProperty ("value", s.def, nullptr);
            tree.appendChild (child, nullptr);
        }
    }
    apvts.replaceState (tree);

    const auto path = tree.getProperty ("soundPath").toString();
    stateRestored = true;

    if (path.isNotEmpty() && juce::File::isAbsolutePath (path) && resolveBuildDir (juce::File (path)).isDirectory())
    {
        // Saved parameters win over the bundle's defaults.
        juce::MessageManager::callAsync ([this, path, a = alive]
        {
            if (a->load())
                loadSound (juce::File (path), false);
        });
    }
}

void LiberoProcessor::loadSound (const juce::File& path, bool applyManifestParams, std::function<void (bool, juce::String)> done)
{
    const auto gen = ++loadGeneration;
    const auto sr = currentSampleRate.load();
    auto a = alive;
    ++loadsInFlight;

    // Large multisamples take seconds to decode: tell the editor right away.
    juce::MessageManager::callAsync ([this, a, path]
    {
        if (a->load())
        {
            const auto info = library::soundInfo (library::soundFolderFor (path));
            listeners.call ([&info] (Listener& l) { l.soundLoading (info); });
        }
    });

    loaderPool.addJob ([this, path, applyManifestParams, done, gen, sr, a]
    {
        if (! a->load())
            return;

        juce::String error;
        auto sd = gen == loadGeneration.load() ? SoundData::load (path, sr, error) : nullptr;

        if (sd == nullptr && error.isEmpty())
            error = "superseded by a newer load";

        juce::var info, params;
        juce::String title;
        juce::File folder;
        const auto mtime = resolveBuildDir (path).getChildFile ("manifest.json").getLastModificationTime();

        if (sd != nullptr)
        {
            folder = sd->folder;
            title = sd->title;
            params = sd->params;
            info = library::soundInfo (folder);

            if (gen == loadGeneration.load())
            {
                engine.submitSound (std::move (sd));
                loadedRate = sr;
            }
            else
            {
                error = "superseded by a newer load";
            }
        }

        juce::MessageManager::callAsync ([this, a, done, error, info, params, title, folder, applyManifestParams, mtime]
        {
            if (! a->load())
                return;

            --loadsInFlight;

            if (error.isNotEmpty())
            {
                if (error != "superseded by a newer load")
                    listeners.call ([&error] (Listener& l) { l.soundLoadFailed (error); });

                if (done)
                    done (false, error);

                return;
            }

            currentSoundInfo = info;
            lastArticulation = -1;
            manifestParams = params;
            loadedManifestTime = mtime;

            {
                const juce::ScopedLock sl (soundLock);
                currentSoundFolder = folder;
            }

            agent.setSoundPath (folder.getFullPathName());
            library::writeConfigValue ("last_sound", folder.getFullPathName());

            if (applyManifestParams)
            {
                resetParamsToDefaults();
                juce::Array<juce::var> applied, rejected;
                applyParamValues (params, applied, rejected);
            }

            lastModified = isModified();
            currentSoundInfo.getDynamicObject()->setProperty ("modified", lastModified);
            listeners.call ([] (Listener& l) { l.soundChanged(); });

            if (done)
                done (true, title);
        });
    });
}

void LiberoProcessor::soundMoved (const juce::File& from, const juce::File& to)
{
    {
        const juce::ScopedLock sl (soundLock);

        if (currentSoundFolder != from)
            return;

        currentSoundFolder = to;
    }

    currentSoundInfo = library::soundInfo (to);
    agent.setSoundPath (to.getFullPathName());
    listeners.call ([] (Listener& l) { l.soundChanged(); });
}

juce::var LiberoProcessor::getCurrentSoundInfo() const
{
    if (! currentSoundInfo.isObject())
        return currentSoundInfo;

    // Fresh copy carrying the active articulation (index, -1 without any).
    auto* o = new juce::DynamicObject (*currentSoundInfo.getDynamicObject());
    const auto n = currentSoundInfo["articulations"].isArray() ? currentSoundInfo["articulations"].size() : 0;
    o->setProperty ("articulation", n > 0 ? juce::jmin ((int) std::lround (rawParams[(size_t) P::artic]->load()), n - 1) : -1);
    return juce::var (o);
}

void LiberoProcessor::pollArticulation()
{
    const auto a = engine.activeArticulation();

    if (a < 0 || a == lastArticulation)
        return;

    lastArticulation = a;

    if ((int) std::lround (rawParams[(size_t) P::artic]->load()) != a)
        if (auto* p = apvts.getParameter (spec (P::artic).id))
            p->setValueNotifyingHost (toNormalised (spec (P::artic), (float) a));

    juce::String id;

    if (const auto& list = currentSoundInfo["articulations"]; list.isArray() && a < list.size())
        id = list[a]["id"].toString();

    listeners.call ([a, &id] (Listener& l) { l.articulationChanged (a, id); });
}

juce::String LiberoProcessor::getCurrentSoundPath() const
{
    const juce::ScopedLock sl (soundLock);
    return currentSoundFolder == juce::File() ? juce::String() : currentSoundFolder.getFullPathName();
}

juce::var LiberoProcessor::getAgentStatus() const
{
    juce::String last;

    {
        const juce::ScopedLock sl (statusLock);
        last = lastAgentMessage;
    }

    return makeObject ({ { "port", agent.getPort() }, { "clients", agent.getNumClients() }, { "lastMessage", last } });
}

void LiberoProcessor::resetParamsToDefaults()
{
    for (auto* p : getParameters())
    {
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (p))
        {
            const auto def = rp->getDefaultValue();

            if (std::abs (rp->getValue() - def) > 1.0e-6f)
            {
                rp->beginChangeGesture();
                rp->setValueNotifyingHost (def);
                rp->endChangeGesture();
            }
        }
    }
}

void LiberoProcessor::applyParamValues (const juce::var& values, juce::Array<juce::var>& applied, juce::Array<juce::var>& rejected)
{
    auto* obj = values.getDynamicObject();

    if (obj == nullptr)
        return;

    for (const auto& prop : obj->getProperties())
    {
        const auto id = prop.name.toString();
        const auto index = findParam (id.toStdString());
        auto* param = apvts.getParameter (id);

        if (index < 0 || param == nullptr)
        {
            rejected.add (id);
            continue;
        }

        const auto& s = spec (index);
        const auto& v = prop.value;
        float plain = 0.0f;
        bool ok = false;

        if (v.isString())
        {
            if (s.scale == Scale::choice)
            {
                const auto c = choiceIndex (s, v.toString().toStdString());
                ok = c >= 0;
                plain = (float) c;
            }
            else if (v.toString().trim().containsOnly ("0123456789.-+eE"))
            {
                plain = v.toString().getFloatValue();
                ok = true;
            }
        }
        else if (v.isInt() || v.isInt64() || v.isDouble() || v.isBool())
        {
            plain = (float) (double) v;
            ok = std::isfinite (plain);
        }

        if (! ok)
        {
            rejected.add (id);
            continue;
        }

        plain = clampPlain (s, plain);
        const auto norm = param->convertTo0to1 (plain);

        param->beginChangeGesture();
        param->setValueNotifyingHost (norm);
        param->endChangeGesture();
        applied.add (id);
    }
}

bool LiberoProcessor::runOnMessageThread (std::function<void()> fn, juce::Thread& caller, int timeoutMs)
{
    auto* mm = juce::MessageManager::getInstanceWithoutCreating();

    if (mm == nullptr)
        return false;

    if (mm->isThisTheMessageThread())
    {
        fn();
        return true;
    }

    auto call = std::make_shared<PendingCall>();
    juce::MessageManager::callAsync ([call, work = std::move (fn), a = alive]
    {
        if (a->load())
            work();

        call->finished = true;
        call->done.signal();
    });

    return waitFor (*call, caller, timeoutMs);
}

void LiberoProcessor::notifyAgentStatus()
{
    juce::MessageManager::callAsync ([this, a = alive]
    {
        if (a->load())
            listeners.call ([] (Listener& l) { l.agentStatusChanged(); });
    });
}

void LiberoProcessor::agentClientsChanged()
{
    notifyAgentStatus();
}

void LiberoProcessor::timerCallback()
{
    engine.collectGarbage();
    pollArticulation();

    // "modificato": do the parameters still match the sound's defaults?
    if (currentSoundInfo.isObject())
    {
        const auto modified = isModified();

        if (modified != lastModified)
        {
            lastModified = modified;
            currentSoundInfo.getDynamicObject()->setProperty ("modified", modified);
            listeners.call ([modified] (Listener& l) { l.soundModifiedChanged (modified); });
        }
    }

    // About once a second: a recompiled bundle reloads by itself.
    if (++watchTicks < 4)
        return;

    watchTicks = 0;
    const auto folder = getCurrentSoundPath();

    if (folder.isEmpty() || loadsInFlight.load() > 0)
        return;

    const auto manifest = resolveBuildDir (juce::File (folder)).getChildFile ("manifest.json");

    if (manifest.existsAsFile() && manifest.getLastModificationTime() != loadedManifestTime)
        reloadSound (true);
}

void LiberoProcessor::reloadSound (bool automatic, std::function<void (bool, juce::String)> done)
{
    const auto folder = getCurrentSoundPath();

    if (folder.isEmpty())
    {
        if (done)
            done (false, "no sound loaded");

        return;
    }

    // Remember the new mtime now, so a failing bundle isn't retried every second.
    loadedManifestTime = resolveBuildDir (juce::File (folder)).getChildFile ("manifest.json").getLastModificationTime();

    auto a = alive;
    loadSound (juce::File (folder), false, [this, a, automatic, done] (bool ok, juce::String msg)
    {
        if (a->load() && ok)
            listeners.call ([automatic] (Listener& l) { l.soundReloaded (automatic); });

        if (done)
            done (ok, msg);
    });
}

bool LiberoProcessor::resetSound()
{
    if (! currentSoundInfo.isObject())
        return false;

    // One transaction in the plugin's undo history; hosts see one gesture per parameter.
    undoManager.beginNewTransaction ("Ripristina");
    resetParamsToDefaults();
    juce::Array<juce::var> applied, rejected;
    applyParamValues (manifestParams, applied, rejected);
    undoManager.beginNewTransaction();
    return true;
}

juce::var LiberoProcessor::currentParamsAsDefaults() const
{
    auto* o = new juce::DynamicObject();

    for (int i = 0; i < kNumParams; ++i)
    {
        const auto& s = spec (i);
        const auto plain = rawParams[(size_t) i]->load();
        const auto range = (double) (s.max - s.min);

        // Normalised storage leaves float dust (599.99994 for 600): ignore it and round the
        // rest to 1e-5 of the range.
        if (std::abs ((double) plain - s.def) <= 1.0e-4 * range)
            continue;

        if (s.scale == Scale::continuous)
        {
            const auto q = std::pow (10.0, std::floor (std::log10 (range * 1.0e-5)));
            o->setProperty (s.id, std::round ((double) plain / q) * q);
        }
        else
        {
            o->setProperty (s.id, paramToVar (i, plain));
        }
    }

    return juce::var (o);
}

bool LiberoProcessor::isModified() const
{
    ParamSet expected;
    applyJsonParams (expected, manifestParams);

    for (int i = 0; i < kNumParams; ++i)
    {
        if (i == (int) P::artic)
            continue;   // a keyswitch is playing, not editing

        const auto& s = spec (i);
        const auto tolerance = 1.0e-4f * std::max (1.0f, std::abs (s.max - s.min));

        if (std::abs (rawParams[(size_t) i]->load() - expected.v[(size_t) i]) > tolerance)
            return true;
    }

    return false;
}

void LiberoProcessor::saveSoundAs (const juce::String& title, std::function<void (bool, juce::String)> done)
{
    const auto folder = getCurrentSoundPath();

    if (folder.isEmpty())
    {
        done (false, "no sound loaded");
        return;
    }

    const auto result = library::saveSoundAs (juce::File (folder), title, currentParamsAsDefaults());

    if (! (bool) result["ok"])
    {
        done (false, result["error"].toString());
        return;
    }

    const auto path = result["path"].toString();
    loadSound (juce::File (path), false, [done, path] (bool ok, juce::String msg) { done (ok, ok ? path : msg); });
}

juce::var LiberoProcessor::setFavorite (const juce::File& folder, bool favorite)
{
    auto r = library::setFavorite (folder, favorite);

    if ((bool) r["ok"] && currentSoundInfo.isObject()
        && library::soundFolderFor (folder).getFullPathName() == getCurrentSoundPath())
        currentSoundInfo.getDynamicObject()->setProperty ("favorite", favorite);

    return r;
}

AgentServer::Reply LiberoProcessor::handleAgentRequest (const juce::String& method, const juce::var& params, juce::Thread& caller)
{
    using Reply = AgentServer::Reply;

    if (method == "info")
    {
        auto call = std::make_shared<PendingCall>();
        runOnMessageThread ([this, call]
        {
            call->message = currentSoundInfo.isObject() ? currentSoundInfo["title"].toString() : juce::String();
            call->ok = currentSoundInfo.isObject() && isModified();
        }, caller, 2000);

        return Reply::ok (makeObject ({ { "id", agent.getInstanceId() },
                                        { "host", hostName },
                                        { "sound", getCurrentSoundPath() },
                                        { "title", call->message },
                                        { "modified", call->ok },
                                        { "version", juce::String (LIBERO_VERSION) },
                                        { "sample_rate", currentSampleRate.load() },
                                        { "block_size", currentBlockSize.load() } }));
    }

    if (method == "load")
    {
        auto path = params["path"].toString().trim();

        if (path.startsWith ("~"))
            path = juce::File::getSpecialLocation (juce::File::userHomeDirectory).getFullPathName() + path.substring (1);

        if (path.isEmpty() || ! juce::File::isAbsolutePath (path))
            return Reply::fail ("load needs an absolute path");

        if (! resolveBuildDir (juce::File (path)).isDirectory())
            return Reply::fail ("no bundle (build/manifest.json) at " + path);

        auto call = std::make_shared<PendingCall>();

        const auto started = runOnMessageThread ([this, call, path]
        {
            loadSound (juce::File (path), true, [call] (bool ok, juce::String msg)
            {
                call->ok = ok;
                call->message = msg;
                call->finished = true;
                call->done.signal();
            });
        }, caller, 5000);

        if (! started || ! waitFor (*call, caller, 60000))
            return Reply::fail ("load timed out");

        if (! call->ok)
            return Reply::fail (call->message);

        return Reply::ok (makeObject ({ { "ok", true }, { "title", call->message } }));
    }

    if (method == "reload" || method == "save_as")
    {
        const auto title = params["title"].toString().trim();

        if (method == "save_as" && title.isEmpty())
            return Reply::fail ("save_as needs a title");

        auto call = std::make_shared<PendingCall>();

        const auto started = runOnMessageThread ([this, call, method, title]
        {
            auto finish = [call] (bool ok, juce::String msg)
            {
                call->ok = ok;
                call->message = msg;
                call->finished = true;
                call->done.signal();
            };

            if (method == "reload")
                reloadSound (false, finish);
            else
                saveSoundAs (title, finish);
        }, caller, 5000);

        if (! started || ! waitFor (*call, caller, 60000))
            return Reply::fail (method + " timed out");

        if (! call->ok)
            return Reply::fail (call->message);

        if (method == "reload")
            return Reply::ok (makeObject ({ { "ok", true }, { "title", call->message } }));

        return Reply::ok (makeObject ({ { "ok", true }, { "path", call->message },
                                        { "slug", juce::File (call->message).getFileName() } }));
    }

    if (method == "list_banks")
        return Reply::ok (library::listBanks());

    if (method == "move_sound")
    {
        const auto path = params["path"].toString().trim();
        const auto bank = params["bank"].toString().trim();

        if (path.isEmpty() || ! juce::File::isAbsolutePath (path))
            return Reply::fail ("move_sound needs an absolute path");

        const auto from = library::soundFolderFor (juce::File (path));
        auto result = std::make_shared<juce::var>();

        if (! runOnMessageThread ([this, from, bank, result]
        {
            *result = library::moveSound (from, bank);

            if ((bool) (*result)["ok"])
                soundMoved (from, juce::File ((*result)["path"].toString()));
        }, caller, 5000))
            return Reply::fail ("move_sound timed out (message thread busy)");

        if (! (bool) (*result)["ok"])
            return Reply::fail ((*result)["error"].toString());

        return Reply::ok (*result);
    }

    if (method == "set_color_tag")
    {
        const auto path = params["path"].toString().trim();

        if (path.isEmpty() || ! juce::File::isAbsolutePath (path))
            return Reply::fail ("set_color_tag needs an absolute path");

        auto result = std::make_shared<juce::var>();

        if (! runOnMessageThread ([this, path, result, tag = (int) params["color"]]
                                  { *result = setColorTag (juce::File (path), tag); }, caller, 5000))
            return Reply::fail ("set_color_tag timed out (message thread busy)");

        if (! (bool) (*result)["ok"])
            return Reply::fail ((*result)["error"].toString());

        return Reply::ok (*result);
    }

    if (method == "create_bank")
    {
        const auto r = library::createBank (params["title"].toString(), params["subtitle"].toString());
        return (bool) r["ok"] ? Reply::ok (r) : Reply::fail (r["error"].toString());
    }

    if (method == "edit_bank")
    {
        const auto r = library::editBank (params["slug"].toString().trim(), params);
        return (bool) r["ok"] ? Reply::ok (r) : Reply::fail (r["error"].toString());
    }

    if (method == "export_bank" || method == "import_bank")
    {
        const auto path = params["path"].toString().trim();

        if (path.isEmpty() || ! juce::File::isAbsolutePath (path))
            return Reply::fail (method + " needs an absolute path");

        const auto r = method == "export_bank" ? library::exportBank (params["slug"].toString().trim(), juce::File (path))
                                               : library::importBank (juce::File (path));
        return (bool) r["ok"] ? Reply::ok (r) : Reply::fail (r["error"].toString());
    }

    if (method == "reset")
    {
        auto call = std::make_shared<PendingCall>();

        if (! runOnMessageThread ([this, call] { call->ok = resetSound(); }, caller, 5000))
            return Reply::fail ("reset timed out (message thread busy)");

        if (! call->ok)
            return Reply::fail ("no sound loaded");

        return Reply::ok (makeObject ({ { "ok", true } }));
    }

    if (method == "get_params")
    {
        auto* result = new juce::DynamicObject();
        juce::var resultVar (result);
        const auto* ids = params["ids"].getArray();

        const auto addParam = [&] (int index)
        {
            const auto& s = spec (index);

            if (auto* p = apvts.getParameter (s.id))
                result->setProperty (s.id, paramToVar (index, p->convertFrom0to1 (p->getValue())));
        };

        if (ids != nullptr && ! ids->isEmpty())
        {
            for (const auto& id : *ids)
            {
                const auto index = findParam (id.toString().toStdString());

                if (index < 0)
                    return Reply::fail ("unknown parameter " + id.toString());

                addParam (index);
            }
        }
        else
        {
            for (int i = 0; i < kNumParams; ++i)
                addParam (i);
        }

        return Reply::ok (resultVar);
    }

    if (method == "set_params")
    {
        const auto& values = params["values"];

        if (! values.isObject())
            return Reply::fail ("set_params needs {values: {id: value}}");

        auto call = std::make_shared<PendingCall>();
        call->input = values;

        if (! runOnMessageThread ([this, call] { applyParamValues (call->input, call->applied, call->rejected); }, caller, 5000))
            return Reply::fail ("set_params timed out (message thread busy)");

        auto result = makeObject ({ { "ok", call->rejected.isEmpty() }, { "applied", call->applied } });

        if (! call->rejected.isEmpty())
            result.getDynamicObject()->setProperty ("rejected", call->rejected);

        return Reply::ok (result);
    }

    if (method == "note")
    {
        if (! params.hasProperty ("pitch"))
            return Reply::fail ("note needs a pitch");

        queueNote ((int) params["pitch"], (int) params.getProperty ("velocity", 100), (int) params.getProperty ("duration_ms", 800));
        return Reply::ok (makeObject ({ { "ok", true } }));
    }

    if (method == "panic")
    {
        queuePanic();
        return Reply::ok (makeObject ({ { "ok", true } }));
    }

    if (method == "status")
    {
        {
            const juce::ScopedLock sl (statusLock);
            lastAgentMessage = params["text"].toString().substring (0, 500);
        }

        notifyAgentStatus();
        return Reply::ok (makeObject ({ { "ok", true } }));
    }

    return Reply::fail ("unknown method " + method);
}

} // namespace libero

#if ! LIBERO_HOST_TEST
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new libero::LiberoProcessor();
}
#endif
