#include "Library.h"
#include "../engine/Bundle.h"

#include <ctime>
#include <array>
#include <cstdint>
#include <filesystem>
#include <limits>
#include <set>
#include <vector>

#include <map>

namespace libero::library
{

juce::var makeResult (bool ok, const juce::String& error)
{
    auto* o = new juce::DynamicObject();
    o->setProperty ("ok", ok);

    if (error.isNotEmpty())
        o->setProperty ("error", error);

    return juce::var (o);
}

juce::File home()
{
    const auto env = juce::SystemStats::getEnvironmentVariable ("LIBERO_HOME", {});

    if (env.isNotEmpty() && juce::File::isAbsolutePath (env))
        return juce::File (env);

    return juce::File::getSpecialLocation (juce::File::userHomeDirectory).getChildFile ("Libero");
}

juce::File sketchesDir()  { return home().getChildFile ("sketches"); }
juce::File soundsDir()    { return home().getChildFile ("sounds"); }
juce::File banksDir()     { return home().getChildFile ("banks"); }
juce::File themesDir()    { return home().getChildFile ("themes"); }
juce::File instancesDir() { return home().getChildFile ("instances"); }
juce::File configFile()   { return home().getChildFile ("config.json"); }

juce::File soundFolderFor (const juce::File& path)
{
    if (path.getFileName() == "build" && path.getChildFile ("manifest.json").existsAsFile())
        return path.getParentDirectory();

    return path;
}

namespace
{
    std::filesystem::path nativePath (const juce::File& file)
    {
       #if JUCE_WINDOWS
        return std::filesystem::path (file.getFullPathName().toWideCharPointer());
       #else
        return std::filesystem::path (file.getFullPathName().toStdString());
       #endif
    }

    juce::var bankMeta (const juce::File& dir)
    {
        const auto v = juce::JSON::parse (dir.getChildFile ("bank.json"));
        return v.isObject() ? v : juce::var();
    }

    juce::var bankRef (const juce::String& slug, const juce::String& title)
    {
        auto* o = new juce::DynamicObject();
        o->setProperty ("slug", slug);
        o->setProperty ("title", title);
        return juce::var (o);
    }

    // The bank a sound folder belongs to: sketches -> Prove, sounds/ -> Mie, banks/<slug>/ -> that bank.
    juce::var bankOf (const juce::File& folder)
    {
        const auto parent = folder.getParentDirectory();

        if (parent == sketchesDir())
            return bankRef ("prove", "Prove");

        if (parent.getParentDirectory() == banksDir())
        {
            const auto m = bankMeta (parent);
            const auto t = m["title"].toString();
            return bankRef (parent.getFileName(), t.isNotEmpty() ? t : parent.getFileName());
        }

        return bankRef ("mie", "Mie");
    }

    bool soundIsSaved (const juce::File& folder)
    {
        return folder.isAChildOf (soundsDir()) || folder.isAChildOf (banksDir());
    }

    bool slugTaken (const juce::String& slug)
    {
        if (soundsDir().getChildFile (slug).exists() || sketchesDir().getChildFile (slug).exists())
            return true;

        for (const auto& b : banksDir().findChildFiles (juce::File::findDirectories, false))
            if (b.getChildFile (slug).exists())
                return true;

        return false;
    }

    void repointFavorite (const juce::File& from, const juce::File& to)
    {
        const auto list = readConfig()["favorites"];

        if (! list.isArray())
            return;

        juce::Array<juce::var> updated;

        for (const auto& f : *list.getArray())
        {
            if (f["path"].toString() == from.getFullPathName())
            {
                auto* o = new juce::DynamicObject();
                o->setProperty ("path", to.getFullPathName());
                o->setProperty ("slug", f["slug"]);
                updated.add (juce::var (o));
            }
            else
            {
                updated.add (f);
            }
        }

        writeConfigValue ("favorites", updated);
    }
}


namespace
{
    constexpr const char* bankFormat = "libero.bank/1";
    constexpr const char* bankExt = ".liberobank";

    juce::var makeObject (std::initializer_list<std::pair<const char*, juce::var>> properties)
    {
        auto* object = new juce::DynamicObject();
        for (const auto& [key, value] : properties)
            object->setProperty (key, value);
        return juce::var (object);
    }

    bool validSlug (const juce::String& s)
    {
        if (s.isEmpty() || s.length() > 48)
            return false;

        for (auto p = s.getCharPointer(); ! p.isEmpty(); ++p)
            if (! ((*p >= 'a' && *p <= 'z') || (*p >= '0' && *p <= '9') || *p == '-'))
                return false;

        return true;
    }

    juce::String nowUtc()
    {
        const auto t = (std::time_t) (juce::Time::currentTimeMillis() / 1000);
        std::tm tm {};
       #if JUCE_WINDOWS
        gmtime_s (&tm, &t);
       #else
        gmtime_r (&t, &tm);
       #endif
        return juce::String::formatted ("%04d-%02d-%02dT%02d:%02d:%02dZ", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
                                        tm.tm_hour, tm.tm_min, tm.tm_sec);
    }

    juce::Array<juce::File> soundDirsIn (const juce::File& folder)
    {
        auto dirs = folder.findChildFiles (juce::File::findDirectories, false);
        dirs.sort();
        juce::Array<juce::File> out;

        for (const auto& d : dirs)
            if (validSlug (d.getFileName()))
                out.add (d);

        return out;
    }

    bool validateSampleEdits (const juce::File& sound, const juce::var& manifest, juce::String& error)
    {
        const auto sidecarFile = sound.getChildFile ("sample-edits.json");
        if (! sidecarFile.existsAsFile())
            return true;
        if (sidecarFile.getSize() < 2 || sidecarFile.getSize() > 1024 * 1024)
        {
            error = "invalid or oversized sample-edits.json";
            return false;
        }
        const auto sidecar = juce::JSON::parse (sidecarFile);
        const auto* edits = sidecar["edits"].getDynamicObject();
        if (! sidecar.isObject() || sidecar["format"].toString() != "libero.sample-edits/1"
            || edits == nullptr || edits->getProperties().size() > 4096)
        {
            error = "invalid sample edit records";
            return false;
        }
        auto* zones = manifest["zones"].getArray();
        if (zones == nullptr)
        {
            error = "sample edits have no zone list";
            return false;
        }
        juce::AudioFormatManager formats;
        formats.registerBasicFormats();
        for (int ei = 0; ei < edits->getProperties().size(); ++ei)
        {
            const auto filename = edits->getProperties().getName (ei).toString();
            const auto edit = edits->getProperties().getValueAt (ei);
            if (filename.isEmpty() || filename != juce::File (filename).getFileName()
                || filename.contains ("..") || filename.containsChar ('\\') || filename.startsWithChar ('/')
                || ! edit.isObject() || !(bool) edit.getProperty ("enabled", false))
            {
                error = "invalid sample edit key or record";
                return false;
            }
            const juce::var* match = nullptr;
            for (const auto& z : *zones)
            {
                if (z["file"].toString() != filename || z["layer"].toString() != "body"
                    || ! (bool) z.getProperty ("pitched", true))
                    continue;
                bool sameDyn = z["dyn"].isVoid() == edit["dyn"].isVoid();
                if (sameDyn && z["dyn"].isArray() && edit["dyn"].isArray())
                {
                    const auto* zd = z["dyn"].getArray();
                    const auto* ed = edit["dyn"].getArray();
                    sameDyn = zd != nullptr && ed != nullptr && zd->size() == ed->size();
                    if (sameDyn)
                        for (int di = 0; di < zd->size(); ++di)
                            sameDyn = sameDyn && std::abs ((double) (*zd)[di] - (double) (*ed)[di]) < 1.0e-6;
                }
                if (edit["source_hash"].toString() == manifest["source_hash"].toString()
                    && sameDyn
                    && (int) edit.getProperty ("root", -1000) == (int) z.getProperty ("root", -2000)
                    && (int) edit.getProperty ("lo", -1000) == (int) z.getProperty ("lo", -2000)
                    && (int) edit.getProperty ("hi", -1000) == (int) z.getProperty ("hi", -2000)
                    && (int) edit.getProperty ("vel_lo", -1000) == (int) z.getProperty ("vel_lo", -2000)
                    && (int) edit.getProperty ("vel_hi", -1000) == (int) z.getProperty ("vel_hi", -2000)
                    && (int) edit.getProperty ("take", -1000) == (int) z.getProperty ("take", 0)
                    && edit.getProperty ("articulation", juce::var()).toString() == z.getProperty ("articulation", juce::var()).toString())
                {
                    match = &z;
                    break;
                }
            }
            if (match == nullptr)
            {
                error = "sample edit is stale or does not match a pitched body zone";
                return false;
            }
            const auto numeric = [] (const juce::var& v) { return v.isInt() || v.isInt64() || v.isDouble(); };
            for (const auto* key : { "start_s", "end_s", "loop_start_s", "loop_end_s", "crossfade_ms" })
                if (! numeric (edit.getProperty (key, juce::var())))
                {
                    error = "sample edit bounds must be finite numbers";
                    return false;
                }
            const auto start = (double) edit["start_s"], end = (double) edit["end_s"];
            const auto loopStart = (double) edit["loop_start_s"], loopEnd = (double) edit["loop_end_s"];
            const auto crossfade = (double) edit["crossfade_ms"];
            if (! std::isfinite (start) || ! std::isfinite (end) || ! std::isfinite (loopStart)
                || ! std::isfinite (loopEnd) || ! std::isfinite (crossfade) || start < 0.0
                || end - start < 0.05 || crossfade < 0.0 || crossfade > 500.0
                || ((bool) edit.getProperty ("loop_enabled", false)
                    && (loopStart < start || loopEnd - loopStart < 0.05 || loopEnd > end)))
            {
                error = "sample edit has invalid bounds";
                return false;
            }
            std::unique_ptr<juce::AudioFormatReader> reader (formats.createReaderFor (sound.getChildFile ("build").getChildFile (filename)));
            if (reader == nullptr || reader->sampleRate <= 0.0
                || end > (double) reader->lengthInSamples / reader->sampleRate + 1.0e-8)
            {
                error = "sample edit exceeds or cannot read its source zone";
                return false;
            }
        }
        return true;
    }

    // licenses.py: the most restrictive class wins; the first of equals.
    const juce::StringArray licenseClasses { "cc0", "by", "by-sa", "sampling+", "nc", "eula", "unknown" };

    juce::String licenseLabel (const juce::String& c)
    {
        if (c == "cc0") return "CC0 / public domain";
        if (c == "by") return "CC BY";
        if (c == "by-sa") return "CC BY-SA";
        if (c == "sampling+") return "CC Sampling Plus";
        if (c == "nc") return "non-commercial";
        if (c == "eula") return "private use only (EULA)";
        return "unknown terms";
    }

    bool shippable (const juce::String& c) { return c == "cc0" || c == "by" || c == "by-sa"; }

    int classRank (const juce::String& c)
    {
        const auto i = licenseClasses.indexOf (c);
        return i >= 0 ? i : licenseClasses.size() - 1;
    }

    juce::Array<juce::var> creditsOf (const juce::File& sound)
    {
        juce::Array<juce::var> out;
        const auto v = juce::JSON::parse (sound.getChildFile ("samples").getChildFile ("credits.json"));

        if (const auto* a = v.getArray())
            for (const auto& c : *a)
                if (c.isObject())
                    out.add (c);

        return out;
    }

    // {text, class} as licenses.bundle_license
    std::pair<juce::String, juce::String> bundleLicense (const juce::Array<juce::var>& credits)
    {
        if (credits.isEmpty())
            return { "original work", "cc0" };

        juce::String cls;
        int best = -1;

        for (const auto& c : credits)
        {
            const auto k = c.hasProperty ("license_class") ? c["license_class"].toString() : juce::String ("unknown");

            if (classRank (k) > best)
            {
                best = classRank (k);
                cls = k;
            }
        }

        juce::StringArray names;

        for (const auto& c : credits)
        {
            const auto k = c.hasProperty ("license_class") ? c["license_class"].toString() : juce::String ("unknown");

            if (k == cls)
                names.addIfNotAlreadyThere (c.hasProperty ("license") ? c["license"].toString() : licenseLabel (k));
        }

        names.sort (false);
        auto text = names.joinIntoString (" + ");

        if (! shippable (cls))
            text << juce::String::fromUTF8 (" \xe2\x80\x94 private use only, do not share this bundle");
        else if (cls == "by-sa")
            text << juce::String::fromUTF8 (" \xe2\x80\x94 share-alike: a shared bundle must carry the same licence");

        return { text, cls };
    }

    juce::String bankLicense (const juce::File& folder)
    {
        juce::Array<juce::var> all;

        for (const auto& s : soundDirsIn (folder))
            all.addArray (creditsOf (s));

        return bundleLicense (all).first;
    }

    juce::var completeMeta (const juce::File& folder, const juce::var& old, const juce::String& stamp)
    {
        const auto str = [&] (const char* k, const juce::String& dflt)
        {
            const auto v = old[k].toString();
            return v.isNotEmpty() ? v : dflt;
        };

        auto* o = new juce::DynamicObject();
        o->setProperty ("format", bankFormat);
        o->setProperty ("slug", folder.getFileName());
        o->setProperty ("title", str ("title", folder.getFileName()));
        o->setProperty ("subtitle", str ("subtitle", {}));
        o->setProperty ("description", str ("description", {}));
        o->setProperty ("version", str ("version", "1.0.0"));
        o->setProperty ("author", str ("author", {}));
        o->setProperty ("license", bankLicense (folder));
        o->setProperty ("created", str ("created", stamp));
        o->setProperty ("updated", str ("updated", stamp));
        o->setProperty ("figure", old["figure"].toString().isNotEmpty() ? old["figure"] : juce::var());
        return juce::var (o);
    }

    juce::String metaText (const juce::var& meta) { return juce::JSON::toString (meta) + "\n"; }

    bool validSemver (const juce::String& v)
    {
        const auto parts = juce::StringArray::fromTokens (v, ".", "");

        if (parts.size() != 3)
            return false;

        for (const auto& p : parts)
            if (p.isEmpty() || ! p.containsOnly ("0123456789"))
                return false;

        return true;
    }

    juce::String checkMeta (const juce::var& meta, const juce::String& slug)
    {
        if (meta["format"].toString() != bankFormat || meta["slug"].toString() != slug)
            return juce::String ("bank.json is not ") + bankFormat + " for '" + slug + "'";

        if (meta["title"].toString().trim().isEmpty())
            return "bank.json has no title";

        if (! validSemver (meta["version"].toString()))
            return "bank.json version '" + meta["version"].toString() + "' is not semver (x.y.z)";

        return {};
    }

    std::vector<int> versionKey (const juce::String& v)
    {
        std::vector<int> out;
        juce::String digits;

        for (auto p = v.getCharPointer();; ++p)
        {
            if (*p >= '0' && *p <= '9')
                digits << *p;
            else if (digits.isNotEmpty())
            {
                out.push_back (digits.getIntValue());
                digits = {};
            }

            if (p.isEmpty())
                break;
        }

        return out.empty() ? std::vector<int> { 0 } : out;
    }

    struct PreparedBank
    {
        juce::File temp, folder, pack;
        juce::var meta;
        juce::String slug, action, installedVersion, code, error;
        juce::String installedPath;
        juce::String contentSignature;
        juce::StringArray warnings;
        int soundCount = 0;
        juce::int64 compressedBytes = 0, uncompressedBytes = 0;
        bool ok = false;
    };

    bool safeRelativeName (const juce::String& name)
    {
        if (name.isEmpty() || name.startsWithChar ('/') || name.containsChar ('\\') || name.containsChar (':')
            || name.containsChar ('\0'))
            return false;

        const auto parts = juce::StringArray::fromTokens (name, "/", "");

        if (parts.isEmpty())
            return false;

        for (const auto& part : parts)
            if (part.isEmpty() || part == "." || part == "..")
                return false;

        return true;
    }

    juce::var importResult (const PreparedBank& p, bool ok, const juce::String& code = {}, const juce::String& error = {})
    {
        auto* o = new juce::DynamicObject();
        o->setProperty ("ok", ok);
        o->setProperty ("code", code.isNotEmpty() ? code : (p.code.isNotEmpty() ? p.code : juce::String ("OK")));
        o->setProperty ("path", p.pack.getFullPathName());
        if (p.slug.isNotEmpty()) o->setProperty ("slug", p.slug);
        if (p.installedPath.isNotEmpty()) o->setProperty ("installedPath", p.installedPath);
        if (p.pack.existsAsFile()) o->setProperty ("packPath", p.pack.getFullPathName());
        o->setProperty ("installedVersion", p.installedVersion);
        o->setProperty ("action", p.action);
        o->setProperty ("soundCount", p.soundCount);
        o->setProperty ("compressedBytes", (double) p.compressedBytes);
        o->setProperty ("uncompressedBytes", (double) p.uncompressedBytes);
        juce::Array<juce::var> warnings;
        for (const auto& w : p.warnings)
            warnings.add (w);
        o->setProperty ("warnings", warnings);
        if (p.meta.isObject())
        {
            auto* b = new juce::DynamicObject();
            for (const char* k : { "slug", "title", "version" })
                b->setProperty (k, p.meta[k]);
            o->setProperty ("bank", juce::var (b));
        }
        else o->setProperty ("bank", juce::var());
        if (error.isNotEmpty()) o->setProperty ("error", error);
        else if (! p.error.isEmpty()) o->setProperty ("error", p.error);
        return juce::var (o);
    }

    PreparedBank prepareBank (const juce::File& pack)
    {
        PreparedBank p;
        p.pack = pack;
        juce::ZipFile zip (pack);
        p.compressedBytes = pack.getSize();
        if (! pack.existsAsFile() || zip.getNumEntries() <= 0)
        {
            p.code = "INVALID_PACK"; p.error = "not a readable bank pack"; return p;
        }
        juce::StringArray roots;
        std::set<std::string> names;
        std::set<std::string> archiveFiles;
        for (int i = 0; i < zip.getNumEntries(); ++i)
        {
            const auto* e = zip.getEntry (i);
            if (e == nullptr || e->isSymbolicLink || e->uncompressedSize < 0 || ! safeRelativeName (e->filename))
            {
                p.code = "UNSAFE_ARCHIVE"; p.error = "unsafe path, link, or size in bank pack"; return p;
            }
            const auto n = e->filename.trimCharactersAtEnd ("/").toLowerCase().toStdString();
            if (! names.insert (n).second)
            {
                p.code = "UNSAFE_ARCHIVE"; p.error = "duplicate path in bank pack: " + e->filename; return p;
            }
            auto parent = n;
            while (true)
            {
                const auto slash = parent.rfind ('/');
                if (slash == std::string::npos) break;
                parent.resize (slash);
                if (archiveFiles.count (parent) != 0)
                {
                    p.code = "UNSAFE_ARCHIVE"; p.error = "file/directory path collision in bank pack"; return p;
                }
            }
            if (! e->filename.endsWithChar ('/'))
            {
                for (const auto& old : names)
                    if (old.size() > n.size() && old.compare (0, n.size(), n) == 0 && old[n.size()] == '/')
                    {
                        p.code = "UNSAFE_ARCHIVE"; p.error = "file/directory path collision in bank pack"; return p;
                    }
                archiveFiles.insert (n);
            }
            if (p.uncompressedBytes > std::numeric_limits<juce::int64>::max() - e->uncompressedSize)
            {
                p.code = "UNSAFE_ARCHIVE"; p.error = "bank pack size overflow"; return p;
            }
            p.uncompressedBytes += e->uncompressedSize;
            const auto parts = juce::StringArray::fromTokens (e->filename, "/", "");
            if (! parts.isEmpty()) roots.addIfNotAlreadyThere (parts[0]);
        }
        if (roots.size() != 1)
        {
            p.code = "INVALID_PACK"; p.error = "a bank pack holds exactly one bank folder"; return p;
        }
        p.slug = roots[0];
        if (! validSlug (p.slug))
        {
            p.code = "INVALID_BANK_META"; p.error = "invalid bank slug"; return p;
        }
        const auto* metaEntry = zip.getEntry (p.slug + "/bank.json");
        std::unique_ptr<juce::InputStream> mi (metaEntry != nullptr ? zip.createStreamForEntry (*metaEntry) : nullptr);
        p.meta = mi != nullptr ? juce::JSON::parse (mi->readEntireStreamAsString()) : juce::var();
        if (! p.meta.isObject() || checkMeta (p.meta, p.slug).isNotEmpty())
        {
            p.code = "INVALID_BANK_META"; p.error = "the pack has no valid bank.json"; return p;
        }

        banksDir().createDirectory();
        p.temp = banksDir().getChildFile (".inspect-" + juce::String::toHexString (juce::Random::getSystemRandom().nextInt64()));
        if (! p.temp.createDirectory())
        {
            p.code = "IO_ERROR"; p.error = "could not create a working folder"; return p;
        }
        const auto unpack = zip.uncompressTo (p.temp, true);
        if (! unpack.wasOk())
        {
            p.code = "INVALID_PACK"; p.error = "could not unpack the bank"; return p;
        }
        p.folder = p.temp.getChildFile (p.slug);
        const auto stagedMeta = bankMeta (p.folder);
        if (! stagedMeta.isObject() || juce::JSON::toString (stagedMeta) != juce::JSON::toString (p.meta))
        {
            p.code = "INVALID_BANK_META"; p.error = "bank.json changed during extraction"; return p;
        }

        const auto sounds = soundDirsIn (p.folder);
        juce::StringArray sourceParts;
        bool allHaveSourceHashes = true;
        for (const auto& sound : sounds)
        {
            const auto build = sound.getChildFile ("build");
            const auto manifestFile = build.getChildFile ("manifest.json");
            const auto manifest = juce::JSON::parse (manifestFile);
            if (! manifest.isObject())
            {
                p.code = "INVALID_BUNDLE"; p.error = "sound '" + sound.getFileName() + "' has no valid manifest"; return p;
            }
            if (manifest["slug"].toString() != sound.getFileName())
            {
                p.code = "INVALID_BUNDLE"; p.error = "bundle slug does not match folder '" + sound.getFileName() + "'"; return p;
            }
            const auto bundleFormat = manifest["format"].toString();
            const auto sourceHash = manifest["source_hash"].toString();
            allHaveSourceHashes = allHaveSourceHashes && sourceHash.isNotEmpty();
            sourceParts.add (sound.getFileName() + ":" + sourceHash);
            const auto sampleRateVar = manifest["sample_rate"];
            const int sourceRate = (int) sampleRateVar;
            if ((! bundleFormat.startsWith ("libero.bundle/1") && ! bundleFormat.startsWith ("libero.bundle/2"))
                || manifest["title"].toString().trim().isEmpty()
                || (! sampleRateVar.isInt() && ! sampleRateVar.isInt64()) || sourceRate <= 0
                || ! manifest["zones"].isArray())
            {
                p.code = "INVALID_BUNDLE"; p.error = "sound '" + sound.getFileName() + "' has invalid bundle metadata"; return p;
            }
            for (const char* key : { "ir", "figure" })
            {
                const auto rel = manifest[key].toString();
                if (rel.isNotEmpty() && ! safeRelativeName (rel))
                {
                    p.code = "INVALID_BUNDLE"; p.error = "unsafe bundle path in '" + sound.getFileName() + "'"; return p;
                }
                if (rel.isNotEmpty() && ! build.getChildFile (rel).existsAsFile())
                {
                    p.code = "INVALID_BUNDLE"; p.error = "missing bundle file in '" + sound.getFileName() + "'"; return p;
                }
            }
            if (auto* zones = manifest["zones"].getArray())
                for (const auto& z : *zones)
                {
                    const auto rel = z["file"].toString();
                    if (! safeRelativeName (rel) || rel.containsChar ('/'))
                    {
                        p.code = "INVALID_BUNDLE"; p.error = "unsafe zone path in '" + sound.getFileName() + "'"; return p;
                    }
                    const auto layer = z["layer"].toString();
                    if (! z.isObject() || ! z["root"].isInt() || ! z["lo"].isInt() || ! z["hi"].isInt()
                        || ! z["vel_lo"].isInt() || ! z["vel_hi"].isInt()
                        || (layer != "body" && layer != "attack" && layer != "tail" && layer != "air")
                        || ! build.getChildFile (rel).existsAsFile())
                    {
                        p.code = "INVALID_BUNDLE"; p.error = "invalid zone metadata or missing audio in '" + sound.getFileName() + "'"; return p;
                    }
                }
            else
            {
                p.code = "INVALID_BUNDLE"; p.error = "sound '" + sound.getFileName() + "' has no zones"; return p;
            }
            juce::String sampleEditError;
            if (! validateSampleEdits (sound, manifest, sampleEditError))
            {
                p.code = "INVALID_BUNDLE";
                p.error = "invalid sample edits in '" + sound.getFileName() + "': " + sampleEditError;
                return p;
            }
            juce::String loadError;
            if (libero::SoundData::load (sound, 44100.0, loadError) == nullptr)
            {
                p.code = "INVALID_BUNDLE"; p.error = "invalid sound '" + sound.getFileName() + "': " + loadError; return p;
            }
            ++p.soundCount;
        }
        sourceParts.sort (true);
        p.contentSignature = sourceParts.joinIntoString ("\n");
        if (! allHaveSourceHashes)
            p.contentSignature << "\nunknown-source-hash:" << p.pack.getFileName();
        if (p.soundCount == 0)
            p.warnings.add ("This bank contains no sounds.");

        juce::Array<juce::File> otherLocations = banksDir().findChildFiles (juce::File::findDirectories, false);
        otherLocations.add (soundsDir());
        for (const auto& otherBank : otherLocations)
        {
            const bool isBankFolder = otherBank.getParentDirectory() == banksDir();
            if (otherBank.getFileName().startsWithChar ('.') || (isBankFolder && otherBank.getFileName() == p.slug)
                || (isBankFolder && ! otherBank.getChildFile ("bank.json").existsAsFile()))
                continue;
            for (const auto& incoming : soundDirsIn (p.folder))
                for (const auto& existing : soundDirsIn (otherBank))
                    if (incoming.getFileName() == existing.getFileName())
                    {
                        const auto im = juce::JSON::parse (incoming.getChildFile ("build/manifest.json"));
                        const auto om = juce::JSON::parse (existing.getChildFile ("build/manifest.json"));
                        const bool same = im.isObject() && om.isObject() && im["source_hash"].toString().isNotEmpty()
                                       && im["source_hash"].toString() == om["source_hash"].toString();
                        p.warnings.add ("Sound slug '" + incoming.getFileName() + "' also exists in bank '"
                                        + (isBankFolder ? otherBank.getFileName() : juce::String ("Mie")) + "' with "
                                        + (same ? "matching source hash." : "different or unknown source hash."));
                    }
        }

        const auto dst = banksDir().getChildFile (p.slug);
        if (dst.exists())
        {
            const auto installedMeta = bankMeta (dst);
            if (! installedMeta.isObject() || checkMeta (installedMeta, p.slug).isNotEmpty())
            {
                p.code = "INVALID_INSTALLED_BANK"; p.error = "installed bank has invalid metadata; left unchanged"; return p;
            }
            p.installedVersion = installedMeta["version"].toString();
            const auto comparison = versionKey (p.meta["version"].toString()) <= versionKey (p.installedVersion);
            if (comparison)
            {
                p.action = "already_installed";
                p.code = p.meta["version"].toString() == p.installedVersion ? "SAME_VERSION" : "DOWNGRADE";
            }
            else
            {
                p.action = "update";
                p.warnings.add ("Updating replaces the installed bank as a whole, including sounds or edits you added to it.");
            }
        }
        else p.action = "install";

        p.ok = true;
        p.code = p.code.isNotEmpty() ? p.code : "OK";
        return p;
    }

    juce::File importSessionsDir()
    {
        return home().getChildFile ("cache").getChildFile ("import-sessions");
    }

    bool validSessionId (const juce::String& id)
    {
        return id.length() == 32 && id.containsOnly ("0123456789abcdef");
    }

    juce::File sessionFolder (const juce::String& id)
    {
        return validSessionId (id) ? importSessionsDir().getChildFile (id) : juce::File();
    }

    void cleanupExpiredSessions()
    {
        const auto root = importSessionsDir();
        const auto dirs = root.findChildFiles (juce::File::findDirectories, false);
        const auto now = juce::Time::getCurrentTime();
        for (const auto& d : dirs)
            if (validSessionId (d.getFileName())
                && now.toMilliseconds() - d.getLastModificationTime().toMilliseconds() > 7LL * 24 * 60 * 60 * 1000)
                d.deleteRecursively();
    }

    struct CollectionSource
    {
        juce::String label, error;
        juce::File stagedPack;
        juce::String code;
    };

    struct CollectionZipRecord
    {
        juce::int64 localOffset = 0, compressedSize = 0, uncompressedSize = 0;
        uint32_t crc32 = 0;
        uint16_t method = 0, flags = 0;
    };

    uint16_t readLe16 (const uint8_t* p)
    {
        return (uint16_t) p[0] | ((uint16_t) p[1] << 8);
    }

    uint32_t readLe32 (const uint8_t* p)
    {
        return (uint32_t) p[0] | ((uint32_t) p[1] << 8) | ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
    }

    uint64_t readLe64 (const uint8_t* p)
    {
        return (uint64_t) readLe32 (p) | ((uint64_t) readLe32 (p + 4) << 32);
    }

    bool readExact (juce::InputStream& stream, void* dest, int bytes)
    {
        return bytes >= 0 && stream.read (dest, bytes) == bytes;
    }

    bool readCollectionDirectory (const juce::File& file, std::map<juce::String, CollectionZipRecord>& records,
                                  juce::String& error)
    {
        juce::FileInputStream stream (file);
        const auto fileSize = file.getSize();
        if (! stream.openedOk() || fileSize < 22)
        {
            error = "invalid collection ZIP directory";
            return false;
        }
        const auto tailSize = (int) std::min<juce::int64> (fileSize, 65557);
        std::vector<uint8_t> tail ((size_t) tailSize);
        if (! stream.setPosition (fileSize - tailSize) || ! readExact (stream, tail.data(), tailSize))
        {
            error = "could not read collection ZIP directory";
            return false;
        }
        int eocd = -1;
        for (int i = tailSize - 22; i >= 0; --i)
            if (readLe32 (tail.data() + i) == 0x06054b50u)
            {
                const auto comment = readLe16 (tail.data() + i + 20);
                if (i + 22 + comment == tailSize) { eocd = i; break; }
            }
        if (eocd < 0)
        {
            error = "collection ZIP has no valid end directory";
            return false;
        }
        const auto* end = tail.data() + eocd;
        const auto disk = readLe16 (end + 4), directoryDisk = readLe16 (end + 6);
        const auto entryCount = readLe16 (end + 10);
        const auto directorySize = readLe32 (end + 12), directoryOffset = readLe32 (end + 16);
        const auto absoluteEocd = fileSize - tailSize + eocd;
        if (disk != 0 || directoryDisk != 0 || readLe16 (end + 8) != entryCount
            || entryCount == 0xffff || directorySize == 0xffffffffu || directoryOffset == 0xffffffffu
            || (juce::int64) directoryOffset + directorySize > absoluteEocd)
        {
            error = "multi-disk or ZIP64 collection directories are not supported";
            return false;
        }
        if (! stream.setPosition (directoryOffset))
        {
            error = "could not seek collection ZIP directory";
            return false;
        }
        for (uint32_t i = 0; i < entryCount; ++i)
        {
            uint8_t header[46] {};
            if (! readExact (stream, header, (int) sizeof header) || readLe32 (header) != 0x02014b50u)
            {
                error = "invalid collection ZIP central record";
                return false;
            }
            const auto method = readLe16 (header + 10);
            const auto flags = readLe16 (header + 8);
            const auto crc = readLe32 (header + 16);
            const auto compressed = readLe32 (header + 20), uncompressed = readLe32 (header + 24);
            const auto nameLength = readLe16 (header + 28), extraLength = readLe16 (header + 30);
            const auto commentLength = readLe16 (header + 32), diskStart = readLe16 (header + 34);
            const auto localOffset = readLe32 (header + 42);
            if (diskStart != 0 || (flags & (1u | 0x40u)) != 0)
            {
                error = diskStart != 0 ? "multi-disk ZIP entry in collection is not supported"
                                       : "encrypted ZIP entry in collection is not supported";
                return false;
            }
            std::vector<char> name ((size_t) nameLength);
            std::vector<uint8_t> ignored ((size_t) extraLength + commentLength);
            if (nameLength == 0 || ! readExact (stream, name.data(), nameLength)
                || ! readExact (stream, ignored.data(), (int) ignored.size()))
            {
                error = "truncated collection ZIP central record";
                return false;
            }
            auto filename = juce::String::fromUTF8 (name.data(), nameLength);
            juce::int64 actualCompressed = compressed, actualUncompressed = uncompressed, actualOffset = localOffset;
            int extraAt = 0;
            while (extraAt + 4 <= extraLength)
            {
                const auto id = readLe16 (ignored.data() + extraAt);
                const auto size = readLe16 (ignored.data() + extraAt + 2);
                extraAt += 4;
                if (extraAt + size > extraLength) { error = "invalid ZIP extra field"; return false; }
                if (id == 0x0001)
                {
                    int valueAt = extraAt;
                    auto take64 = [&] (juce::int64& target)
                    {
                        if (valueAt + 8 > extraAt + size) return false;
                        const auto value = readLe64 (ignored.data() + valueAt);
                        if (value > (uint64_t) std::numeric_limits<juce::int64>::max()) return false;
                        target = (juce::int64) value;
                        valueAt += 8;
                        return true;
                    };
                    if (uncompressed == 0xffffffffu && ! take64 (actualUncompressed))
                    { error = "invalid ZIP64 uncompressed size"; return false; }
                    if (compressed == 0xffffffffu && ! take64 (actualCompressed))
                    { error = "invalid ZIP64 compressed size"; return false; }
                    if (localOffset == 0xffffffffu && ! take64 (actualOffset))
                    { error = "invalid ZIP64 local offset"; return false; }
                }
                extraAt += size;
            }
            if (actualCompressed < 0 || actualUncompressed < 0 || actualOffset < 0
                || (compressed == 0xffffffffu && actualCompressed == compressed)
                || (uncompressed == 0xffffffffu && actualUncompressed == uncompressed)
                || (localOffset == 0xffffffffu && actualOffset == localOffset))
            { error = "missing ZIP64 entry metadata"; return false; }
            CollectionZipRecord record;
            record.method = method;
            record.crc32 = crc;
            record.compressedSize = actualCompressed;
            record.uncompressedSize = actualUncompressed;
            record.localOffset = actualOffset;
            record.flags = flags;
            if (records.count (filename) != 0)
            {
                error = "duplicate collection ZIP central record";
                return false;
            }
            records.emplace (filename, record);
            if (stream.getPosition() > (juce::int64) directoryOffset + directorySize)
            { error = "collection ZIP central record exceeds directory bounds"; return false; }
        }
        if (stream.getPosition() != (juce::int64) directoryOffset + directorySize)
        { error = "collection ZIP directory size does not match its records"; return false; }
        return true;
    }

    bool extractCollectionZipEntry (const juce::File& archive, const juce::String& filename,
                                    const CollectionZipRecord& record, const juce::File& destination,
                                    juce::String& error)
    {
        if (record.method != 0 && record.method != 8)
        {
            error = "collection ZIP uses an unsupported compression method";
            return false;
        }
        auto fileStream = std::make_unique<juce::FileInputStream> (archive);
        if (! fileStream->openedOk() || ! fileStream->setPosition (record.localOffset))
        {
            error = "could not seek nested archive data";
            return false;
        }
        uint8_t local[30] {};
        if (! readExact (*fileStream, local, (int) sizeof local) || readLe32 (local) != 0x04034b50u)
        {
            error = "invalid nested archive local header";
            return false;
        }
        const auto localNameLength = readLe16 (local + 26), localExtraLength = readLe16 (local + 28);
        const auto localFlags = readLe16 (local + 6), localMethod = readLe16 (local + 8);
        std::vector<char> localName ((size_t) localNameLength);
        if (localNameLength == 0 || ! readExact (*fileStream, localName.data(), localNameLength))
        {
            error = "truncated nested archive local header";
            return false;
        }
        auto localFilename = juce::String::fromUTF8 (localName.data(), localNameLength);
        std::vector<uint8_t> localExtra ((size_t) localExtraLength);
        if (localFilename != filename || localFlags != record.flags || localMethod != record.method
            || ! readExact (*fileStream, localExtra.data(), localExtraLength))
        {
            error = "nested archive local and central names do not match";
            return false;
        }
        const auto dataOffset = record.localOffset + 30 + localNameLength + localExtraLength;
        if (dataOffset < record.localOffset || dataOffset > archive.getSize()
            || record.compressedSize > archive.getSize() - dataOffset || ! destination.getParentDirectory().createDirectory())
        {
            error = "nested archive data lies outside the collection ZIP";
            return false;
        }
        juce::InputStream* bounded = new juce::SubregionStream (fileStream.release(), dataOffset,
                                                                 record.compressedSize, true);
        std::unique_ptr<juce::InputStream> decoded;
        if (record.method == 8)
        {
            decoded.reset (new juce::GZIPDecompressorInputStream (bounded, true,
                            juce::GZIPDecompressorInputStream::deflateFormat, record.uncompressedSize));
            bounded = nullptr;
        }
        else decoded.reset (bounded);
        juce::FileOutputStream output (destination);
        if (! output.openedOk())
        {
            error = "could not write staged nested archive";
            return false;
        }
        static const auto crcTable = []
        {
            std::array<uint32_t, 256> table {};
            for (uint32_t n = 0; n < table.size(); ++n)
            {
                auto c = n;
                for (int k = 0; k < 8; ++k) c = (c & 1) ? (0xedb88320u ^ (c >> 1)) : (c >> 1);
                table[n] = c;
            }
            return table;
        }();
        std::array<uint8_t, 64 * 1024> buffer {};
        juce::int64 written = 0;
        uint32_t crc = 0xffffffffu;
        while (written < record.uncompressedSize)
        {
            const auto ask = (int) std::min<juce::int64> ((juce::int64) buffer.size(), record.uncompressedSize - written);
            const auto count = decoded->read (buffer.data(), ask);
            if (count <= 0 || written > record.uncompressedSize - count || ! output.write (buffer.data(), (size_t) count))
            {
                error = "nested archive did not decompress to its declared size";
                return false;
            }
            for (int i = 0; i < count; ++i) crc = crcTable[(crc ^ buffer[(size_t) i]) & 0xff] ^ (crc >> 8);
            written += count;
        }
        if (! decoded->isExhausted() || (crc ^ 0xffffffffu) != record.crc32)
        {
            error = "nested archive CRC or compressed length did not match";
            return false;
        }
        output.flush();
        return output.getStatus().wasOk() && destination.getSize() == record.uncompressedSize;
    }

    bool stageCollectionInput (const juce::File& input, const juce::File& session,
                               int& nextPack, juce::Array<CollectionSource>& sources,
                               juce::String& error)
    {
        if (input.getFileExtension().equalsIgnoreCase (bankExt))
        {
            CollectionSource source;
            source.label = input.getFullPathName();
            source.stagedPack = session.getChildFile ("pack-" + juce::String (nextPack++).paddedLeft ('0', 3) + bankExt);
            if (! input.existsAsFile() || ! input.copyFileTo (source.stagedPack))
            {
                source.error = "could not copy selected bank pack";
                source.code = input.existsAsFile() ? "IO_ERROR" : "INVALID_PACK";
            }
            sources.add (source);
            return true;
        }

        if (! input.getFileExtension().equalsIgnoreCase (".zip"))
        {
            CollectionSource source;
            source.label = input.getFullPathName();
            source.error = "select .liberobank files or a ZIP collection";
            source.code = "INVALID_INPUT";
            sources.add (source);
            return true;
        }

        juce::ZipFile zip (input);
        if (! input.existsAsFile() || zip.getNumEntries() <= 0)
        {
            error = "not a readable collection ZIP: " + input.getFileName();
            return false;
        }
        std::map<juce::String, CollectionZipRecord> zipRecords;
        if (! readCollectionDirectory (input, zipRecords, error))
            return false;
        std::set<std::string> names, archiveFiles;
        juce::Array<int> bankIndexes;
        juce::int64 total = 0;
        for (int i = 0; i < zip.getNumEntries(); ++i)
        {
            const auto* entry = zip.getEntry (i);
            if (entry == nullptr || entry->isSymbolicLink || entry->uncompressedSize < 0)
            {
                error = "unsafe link or size in collection ZIP";
                return false;
            }
            const auto raw = entry->filename;
            const auto clean = raw.trimCharactersAtEnd ("/");
            if (! safeRelativeName (clean))
            {
                error = "unsafe path in collection ZIP: " + raw;
                return false;
            }
            const auto normalized = clean.toLowerCase().toStdString();
            if (! names.insert (normalized).second)
            {
                error = "duplicate or case-colliding path in collection ZIP: " + raw;
                return false;
            }
            auto parent = normalized;
            while (true)
            {
                const auto slash = parent.rfind ('/');
                if (slash == std::string::npos) break;
                parent.resize (slash);
                if (archiveFiles.count (parent) != 0)
                {
                    error = "file/directory collision in collection ZIP";
                    return false;
                }
            }
            if (! raw.endsWithChar ('/'))
            {
                for (const auto& old : names)
                    if (old.size() > normalized.size() && old.compare (0, normalized.size(), normalized) == 0
                        && old[normalized.size()] == '/')
                    {
                        error = "file/directory collision in collection ZIP";
                        return false;
                    }
                archiveFiles.insert (normalized);
                if (! (total <= std::numeric_limits<juce::int64>::max() - entry->uncompressedSize))
                {
                    error = "collection ZIP uncompressed size overflow";
                    return false;
                }
                total += entry->uncompressedSize;
                if (total > 32LL * 1024 * 1024 * 1024)
                {
                    error = "collection ZIP expands beyond the supported 32 GiB safety limit";
                    return false;
                }
                if (raw.endsWithIgnoreCase (bankExt))
                {
                    const auto record = zipRecords.find (raw);
                    if (record == zipRecords.end() || record->second.uncompressedSize != entry->uncompressedSize)
                    {
                        error = "collection ZIP central directory disagrees with its entries";
                        return false;
                    }
                    bankIndexes.add (i);
                }
                else
                {
                    const auto base = clean.fromLastOccurrenceOf ("/", false, false).toLowerCase();
                    if (base != "readme.txt" && base != "catalog.json" && base != "sha256sums"
                        && base != "sound-data-terms.md")
                    {
                        error = "unexpected file in collection ZIP: " + raw;
                        return false;
                    }
                }
            }
        }
        if (bankIndexes.isEmpty())
        {
            error = "ZIP does not contain any .liberobank archives";
            return false;
        }
        for (const auto index : bankIndexes)
        {
            const auto* entry = zip.getEntry (index);
            if (entry == nullptr)
            {
                error = "collection ZIP entry disappeared during staging";
                return false;
            }
            CollectionSource source;
            source.label = input.getFullPathName() + "!" + entry->filename;
            source.stagedPack = session.getChildFile ("pack-" + juce::String (nextPack++).paddedLeft ('0', 3) + bankExt);
            const auto record = zipRecords.find (entry->filename);
            if (record == zipRecords.end()
                || ! extractCollectionZipEntry (input, entry->filename, record->second, source.stagedPack, error))
                return false;
            sources.add (source);
        }
        return true;
    }

    juce::var collectionEntry (const PreparedBank& p, const juce::String& label, const juce::String& stagedFile)
    {
        auto result = importResult (p, p.ok, p.code, p.error);
        auto* object = result.getDynamicObject();
        object->setProperty ("path", label);
        object->setProperty ("name", label.fromLastOccurrenceOf ("/", false, false));
        object->setProperty ("stagedFile", stagedFile);
        if (p.meta.isObject())
            object->setProperty ("bank", makeObject ({ { "slug", p.slug }, { "title", p.meta["title"] }, { "version", p.meta["version"] } }));
        return result;
    }

    juce::var collectionFailure (const juce::String& code, const juce::String& error)
    {
        return makeObject ({ { "ok", false }, { "format", "libero.bank-collection/1" }, { "code", code }, { "error", error } });
    }

    void refreshBank (const juce::File& dir)
    {
        if (dir.getParentDirectory() != banksDir() || ! dir.getChildFile ("bank.json").existsAsFile())
            return;

        auto meta = completeMeta (dir, bankMeta (dir), nowUtc());
        meta.getDynamicObject()->setProperty ("updated", nowUtc());
        dir.getChildFile ("bank.json").replaceWithText (metaText (meta));
    }
}

namespace
{
    // The library drawer asks for every sound's metadata each time it opens. Reading a large
    // multisample's manifest costs hundreds of ms (thousands of zones), so the light fields are
    // read from build/info.json when the compiler wrote one, and kept in memory until a file changes.
    struct CachedInfo
    {
        juce::int64 manifestTime = 0, infoTime = 0, figureTime = 0;
        juce::var base;
    };

    juce::CriticalSection infoCacheLock;
    std::map<juce::String, CachedInfo> infoCache;

    juce::var readBaseInfo (const juce::File& folder, const juce::File& build)
    {
        const auto infoFile = build.getChildFile ("info.json");
        const auto manifestFile = build.getChildFile ("manifest.json");
        const auto useInfo = infoFile.existsAsFile()
                          && infoFile.getLastModificationTime() >= manifestFile.getLastModificationTime();
        const auto manifest = juce::JSON::parse (useInfo ? infoFile : manifestFile);

        if (! manifest.isObject())
            return {};

        auto figureName = manifest["figure"].toString();

        if (figureName.isEmpty())
            figureName = "figure.svg";

        auto figureFile = build.getChildFile (figureName);

        if (! figureFile.existsAsFile())
            figureFile = folder.getChildFile ("figure.svg");

        auto* o = new juce::DynamicObject();
        const auto slug = manifest["slug"].toString();
        o->setProperty ("slug", slug.isNotEmpty() ? slug : folder.getFileName());
        o->setProperty ("path", folder.getFullPathName());
        o->setProperty ("title", manifest["title"].toString().isNotEmpty() ? manifest["title"].toString() : folder.getFileName());
        o->setProperty ("subtitle", manifest["subtitle"].toString());
        o->setProperty ("tags", manifest["tags"].isArray() ? manifest["tags"] : juce::var (juce::Array<juce::var>()));
        o->setProperty ("figure", figureFile.existsAsFile() && figureFile.getSize() < 4 * 1024 * 1024
                                      ? figureFile.loadFileAsString() : juce::String());
        o->setProperty ("articulations", manifest["articulations"].isArray() ? manifest["articulations"] : juce::var());
        o->setProperty ("accent", manifest["accent"].isString() ? manifest["accent"] : juce::var());
        o->setProperty ("mtime", manifestFile.getLastModificationTime().toMilliseconds());
        return juce::var (o);
    }
}

juce::var soundInfo (const juce::File& folderIn, const juce::var& favoritesIn, const juce::var& tagsIn)
{
    const auto folder = soundFolderFor (folderIn);
    auto build = folder.getChildFile ("build");

    if (! build.getChildFile ("manifest.json").existsAsFile())
    {
        if (folder.getChildFile ("manifest.json").existsAsFile())
            build = folder;
        else
            return {};
    }

    const auto manifestTime = build.getChildFile ("manifest.json").getLastModificationTime().toMilliseconds();
    const auto infoTime = build.getChildFile ("info.json").getLastModificationTime().toMilliseconds();
    const auto figureTime = juce::jmax (build.getChildFile ("figure.svg").getLastModificationTime().toMilliseconds(),
                                        folder.getChildFile ("figure.svg").getLastModificationTime().toMilliseconds());
    juce::var base;

    {
        const juce::ScopedLock sl (infoCacheLock);
        const auto it = infoCache.find (folder.getFullPathName());

        if (it != infoCache.end() && it->second.manifestTime == manifestTime
            && it->second.infoTime == infoTime && it->second.figureTime == figureTime)
            base = it->second.base;
    }

    if (! base.isObject())
    {
        base = readBaseInfo (folder, build);

        if (! base.isObject())
            return {};

        const juce::ScopedLock sl (infoCacheLock);
        infoCache[folder.getFullPathName()] = { manifestTime, infoTime, figureTime, base };
    }

    // Copy, so per-call fields never leak into the cached object.
    auto* o = new juce::DynamicObject (*base.getDynamicObject());
    o->setProperty ("saved", soundIsSaved (folder));
    o->setProperty ("bank", bankOf (folder));

    const auto favorites = favoritesIn.isArray() ? favoritesIn : readConfig()["favorites"];
    o->setProperty ("favorite", isFavorite (favorites, folder.getFullPathName(), o->getProperty ("slug").toString()));
    o->setProperty ("colorTag", colorTagOf (tagsIn.isObject() ? tagsIn : readConfig()["tags"], o->getProperty ("slug").toString()));
    return juce::var (o);
}

bool isFavorite (const juce::var& favorites, const juce::String& path, const juce::String& slug)
{
    if (const auto* list = favorites.getArray())
    {
        for (const auto& f : *list)
        {
            const auto fp = f["path"].toString();

            if (fp == path)
                return true;

            // Moved (sketch saved to the library): the stored path is gone, the slug remains.
            if (slug.isNotEmpty() && f["slug"].toString() == slug && ! juce::File (fp).isDirectory())
                return true;
        }
    }

    return false;
}

juce::var setFavorite (const juce::File& folderIn, bool favorite)
{
    const auto folder = soundFolderFor (folderIn);
    const auto info = soundInfo (folder);

    if (! info.isObject())
        return makeResult (false, "no such sound");

    const auto path = folder.getFullPathName();
    const auto slug = info["slug"].toString();
    juce::Array<juce::var> kept;

    if (const auto* list = readConfig()["favorites"].getArray())
    {
        for (const auto& f : *list)
        {
            const auto same = f["path"].toString() == path
                           || (f["slug"].toString() == slug && ! juce::File (f["path"].toString()).isDirectory());

            if (! same)
                kept.add (f);
        }
    }

    if (favorite)
    {
        auto* o = new juce::DynamicObject();
        o->setProperty ("path", path);
        o->setProperty ("slug", slug);
        kept.add (juce::var (o));
    }

    const auto ok = writeConfigValue ("favorites", kept);
    return makeResult (ok, ok ? juce::String() : juce::String ("could not write config.json"));
}

namespace
{
    // Hard link when the filesystem allows it (no second copy of the audio), else copy.
    bool linkOrCopy (const juce::File& from, const juce::File& to)
    {
        to.getParentDirectory().createDirectory();

        std::error_code ec;
        std::filesystem::create_hard_link (nativePath (from), nativePath (to), ec);
        if (! ec)
            return true;

        return from.copyFileTo (to);
    }

    bool linkTree (const juce::File& fromDir, const juce::File& toDir, const juce::StringArray& skip = {})
    {
        for (const auto& f : fromDir.findChildFiles (juce::File::findFiles, true))
        {
            const auto rel = f.getRelativePathFrom (fromDir);

            if (skip.contains (rel) || f.getFileName().startsWith ("."))
                continue;

            if (! linkOrCopy (f, toDir.getChildFile (rel)))
                return false;
        }

        return true;
    }

    juce::String pythonLiteral (const juce::var& v)
    {
        if (v.isString())
            return juce::JSON::toString (v);   // a JSON string is a valid Python string literal

        if (v.isBool())
            return (bool) v ? "True" : "False";

        if (v.isInt() || v.isInt64())
            return juce::String ((juce::int64) v);

        return juce::JSON::toString (v);   // shortest round-trip form, e.g. 0.6
    }
}

juce::String slugFor (const juce::String& title)
{
    static const juce::String from = juce::String::fromUTF8 ("àáâãäåèéêëìíîïòóôõöùúûüýÿñçÀÁÂÃÄÅÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝÑÇ");
    static const juce::String to   = "aaaaaaeeeeiiiiooooouuuuyyncaaaaaaeeeeiiiiooooouuuuync";

    juce::String out;
    bool dash = false;

    for (auto p = title.getCharPointer(); ! p.isEmpty(); ++p)
    {
        auto c = *p;
        const auto i = from.indexOfChar (c);

        if (i >= 0)
            c = to[i];

        c = juce::CharacterFunctions::toLowerCase (c);

        if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9'))
        {
            if (dash && out.isNotEmpty())
                out << '-';

            out << juce::String::charToString (c);
            dash = false;
        }
        else
        {
            dash = true;
        }
    }

    out = out.substring (0, 48).trimCharactersAtEnd ("-");
    return out.isNotEmpty() ? out : juce::String ("suono");
}

juce::var saveSoundAs (const juce::File& folderIn, const juce::String& titleIn, const juce::var& params)
{
    const auto folder = soundFolderFor (folderIn);
    const auto title = titleIn.trim();

    if (title.isEmpty())
        return makeResult (false, "the new sound needs a title");

    const auto build = folder.getChildFile ("build");
    const auto manifest = juce::JSON::parse (build.getChildFile ("manifest.json"));

    if (! manifest.isObject())
        return makeResult (false, "the current sound has no compiled bundle");

    // Unique slug across the library and the sketches.
    const auto base = slugFor (title).substring (0, 44);
    auto slug = base;

    for (int n = 2; slugTaken (slug); ++n)
        slug = base + "-" + juce::String (n);

    const auto dest = soundsDir().getChildFile (slug);

    if (! dest.createDirectory())
        return makeResult (false, "could not create " + dest.getFullPathName());

    const auto fail = [&dest] (const juce::String& why)
    {
        dest.deleteRecursively();
        return makeResult (false, why);
    };

    if (! linkTree (build, dest.getChildFile ("build"), { "manifest.json" }))
        return fail ("could not link the bundle's audio");

    if (folder.getChildFile ("samples").isDirectory() && ! linkTree (folder.getChildFile ("samples"), dest.getChildFile ("samples")))
        return fail ("could not link the samples");

    for (const auto* name : { "notes.md", "figure.svg", "sample-edits.json" })
        if (folder.getChildFile (name).existsAsFile())
            folder.getChildFile (name).copyFileTo (dest.getChildFile (name));

    // The bundle: new identity, current settings as its defaults.
    auto* m = manifest.getDynamicObject();
    m->setProperty ("slug", slug);
    m->setProperty ("title", title);
    m->setProperty ("params", params);

    if (! dest.getChildFile ("build").getChildFile ("manifest.json").replaceWithText (juce::JSON::toString (manifest) + "\n"))
        return fail ("could not write the manifest");

    // The recipe: same source, plus the new title and defaults so a recompile keeps them.
    const auto recipe = folder.getChildFile ("sound.py");

    if (recipe.existsAsFile())
    {
        juce::StringArray args;

        if (auto* p = params.getDynamicObject())
            for (const auto& kv : p->getProperties())
                args.add (kv.name.toString() + "=" + pythonLiteral (kv.value));

        auto text = recipe.loadFileAsString().trimEnd();
        text << "\n\n# Saved from the plugin as " << juce::JSON::toString (title)
             << " with the settings it was playing with.\n"
             << "sound.retitle(" << juce::JSON::toString (title) << ")\n";

        if (! args.isEmpty())
            text << "sound.defaults(" << args.joinIntoString (", ") << ")\n";

        if (! dest.getChildFile ("sound.py").replaceWithText (text))
            return fail ("could not write sound.py");
    }

    auto r = makeResult (true);
    r.getDynamicObject()->setProperty ("path", dest.getFullPathName());
    r.getDynamicObject()->setProperty ("slug", slug);
    return r;
}

juce::var listSounds()
{
    juce::Array<juce::var> list;
    const auto cfg = readConfig();
    const auto favorites = cfg["favorites"];
    const auto tags = cfg["tags"].isObject() ? cfg["tags"] : juce::var (new juce::DynamicObject());

    juce::Array<juce::File> dirs { sketchesDir(), soundsDir() };
    auto banks = banksDir().findChildFiles (juce::File::findDirectories, false);
    banks.sort();

    for (const auto& b : banks)
        if (b.getChildFile ("bank.json").existsAsFile())
            dirs.add (b);

    for (const auto& dir : dirs)
    {
        if (! dir.isDirectory())
            continue;

        auto folders = dir.findChildFiles (juce::File::findDirectories, false);
        folders.sort();

        for (const auto& f : folders)
        {
            const auto info = soundInfo (f, favorites.isArray() ? favorites : juce::var (juce::Array<juce::var>()), tags);

            if (! info.isObject())
                continue;

            // Figures travel as URLs served by the editor's resource provider: passing hundreds
            // of KB of SVG text through a native-function result takes seconds in WKWebView.
            auto* o = info.getDynamicObject();
            const auto hasFigure = o->getProperty ("figure").toString().isNotEmpty();
            o->removeProperty ("figure");

            if (hasFigure)
                o->setProperty ("figureUrl", "/fig/" + juce::URL::addEscapeChars (f.getFullPathName().trimCharactersAtStart ("/"), false)
                                               + "?v=" + juce::String (o->getProperty ("mtime").toString()));

            // build/preview.m4a (or .wav): a few seconds of the sound, rendered at compile time.
            const auto buildDir = f.getChildFile ("build").isDirectory() ? f.getChildFile ("build") : f;

            for (const auto* name : { "preview.m4a", "preview.wav" })
            {
                const auto pf = buildDir.getChildFile (name);

                if (pf.existsAsFile())
                {
                    o->setProperty ("previewUrl", "/preview/" + juce::URL::addEscapeChars (f.getFullPathName().trimCharactersAtStart ("/"), false)
                                                     + "?v=" + juce::String (pf.getLastModificationTime().toMilliseconds()));
                    break;
                }
            }

            list.add (info);
        }
    }

    return list;
}

juce::var listBanks()
{
    juce::Array<juce::var> list;

    const auto countIn = [] (const juce::File& dir)
    {
        int n = 0;

        for (const auto& f : dir.findChildFiles (juce::File::findDirectories, false))
            if (f.getChildFile ("build").getChildFile ("manifest.json").existsAsFile())
                ++n;

        return n;
    };

    auto banks = banksDir().findChildFiles (juce::File::findDirectories, false);
    banks.sort();

    for (const auto& b : banks)
    {
        const auto m = bankMeta (b);

        if (! m.isObject())
            continue;

        auto* o = new juce::DynamicObject();
        const auto t = m["title"].toString();
        o->setProperty ("slug", b.getFileName());
        o->setProperty ("title", t.isNotEmpty() ? t : b.getFileName());
        o->setProperty ("subtitle", m["subtitle"].toString());
        o->setProperty ("description", m["description"].toString());
        o->setProperty ("version", m["version"].toString());
        o->setProperty ("author", m["author"].toString());
        o->setProperty ("license", m["license"].toString());
        o->setProperty ("created", m["created"].toString());
        o->setProperty ("updated", m["updated"].toString());
        o->setProperty ("count", countIn (b));
        o->setProperty ("builtin", false);

        if (const auto fig = bankFigureFile (b); fig.existsAsFile())
            o->setProperty ("figureUrl", "/bankfig/" + juce::URL::addEscapeChars (b.getFullPathName().trimCharactersAtStart ("/"), false)
                                           + "?v=" + juce::String (fig.getLastModificationTime().toMilliseconds()));

        list.add (juce::var (o));
    }

    const auto builtin = [&] (const juce::String& slug, const juce::String& title, const juce::File& dir)
    {
        auto* o = new juce::DynamicObject();
        o->setProperty ("slug", slug);
        o->setProperty ("title", title);
        o->setProperty ("subtitle", juce::String());
        o->setProperty ("count", countIn (dir));
        o->setProperty ("builtin", true);
        list.add (juce::var (o));
    };

    builtin ("mie", "Mie", soundsDir());
    builtin ("prove", "Prove", sketchesDir());
    return list;
}

juce::var moveSound (const juce::File& folderIn, const juce::String& bankSlug)
{
    const auto folder = soundFolderFor (folderIn);

    if (! folder.isDirectory() || ! soundInfo (folder).isObject())
        return makeResult (false, "no such sound");

    if (! soundIsSaved (folder))
        return makeResult (false, "save the sketch first");

    const auto slug = bankSlug.trim();
    juce::File destDir;

    if (slug.isEmpty() || slug == "mie")
        destDir = soundsDir();
    else if (slug.containsAnyOf ("/\\") || slug.startsWith ("."))
        return makeResult (false, "invalid bank");
    else
        destDir = banksDir().getChildFile (slug);

    if (destDir != soundsDir() && ! destDir.getChildFile ("bank.json").existsAsFile())
        return makeResult (false, "no such bank: " + slug);

    if (folder.getParentDirectory() == destDir)
    {
        auto r = makeResult (true);
        r.getDynamicObject()->setProperty ("path", folder.getFullPathName());
        return r;
    }

    const auto dest = destDir.getChildFile (folder.getFileName());

    if (dest.exists())
        return makeResult (false, "there is already a sound called " + folder.getFileName() + " there");

    destDir.createDirectory();

    if (! folder.moveFileTo (dest))
        return makeResult (false, "could not move the sound");

    repointFavorite (folder, dest);
    refreshBank (folder.getParentDirectory());
    refreshBank (destDir);
    auto r = makeResult (true);
    r.getDynamicObject()->setProperty ("path", dest.getFullPathName());
    return r;
}

juce::var saveSound (const juce::File& folderIn)
{
    const auto folder = soundFolderFor (folderIn);

    if (! folder.isDirectory())
        return makeResult (false, "no such sound");

    if (soundIsSaved (folder))
    {
        auto r = makeResult (true);
        r.getDynamicObject()->setProperty ("path", folder.getFullPathName());
        return r;
    }

    if (! folder.isAChildOf (sketchesDir()))
        return makeResult (false, "only sketches can be saved");

    soundsDir().createDirectory();

    auto dest = soundsDir().getChildFile (folder.getFileName());

    for (int n = 2; dest.exists(); ++n)
        dest = soundsDir().getChildFile (folder.getFileName() + "-" + juce::String (n));

    if (! folder.moveFileTo (dest))
        return makeResult (false, "could not move the sketch");

    repointFavorite (folder, dest);

    auto r = makeResult (true);
    r.getDynamicObject()->setProperty ("path", dest.getFullPathName());
    return r;
}

juce::var discardSketch (const juce::File& folderIn)
{
    const auto folder = soundFolderFor (folderIn);

    if (! folder.isAChildOf (sketchesDir()))
        return makeResult (false, "only sketches can be discarded");

    if (! folder.isDirectory())
        return makeResult (false, "no such sketch");

    const auto ok = folder.moveToTrash();
    return makeResult (ok, ok ? juce::String() : juce::String ("could not move to the trash"));
}

int colorTagOf (const juce::var& tags, const juce::String& slug)
{
    const auto n = (int) tags[juce::Identifier (slug)];
    return n >= 1 && n <= 4 ? n : 0;
}

juce::var setColorTag (const juce::File& folderIn, int n)
{
    const auto folder = soundFolderFor (folderIn);
    const auto info = soundInfo (folder);

    if (! info.isObject())
        return makeResult (false, "no such sound");

    if (n < 0 || n > 4)
        return makeResult (false, "colour tag must be 0-4");

    auto* tags = new juce::DynamicObject();
    juce::var out (tags);

    if (const auto* cur = readConfig()["tags"].getDynamicObject())
        for (const auto& p : cur->getProperties())
            tags->setProperty (p.name, p.value);

    const juce::Identifier key (info["slug"].toString());

    if (n > 0)
        tags->setProperty (key, n);
    else
        tags->removeProperty (key);

    auto cfg = readConfig();
    home().createDirectory();

    if (tags->getProperties().size() > 0)
        cfg.getDynamicObject()->setProperty ("tags", out);
    else
        cfg.getDynamicObject()->removeProperty ("tags");

    const auto ok = configFile().replaceWithText (juce::JSON::toString (cfg) + "\n");
    return makeResult (ok, ok ? juce::String() : juce::String ("could not write config.json"));
}

juce::File bankFigureFile (const juce::File& bank)
{
    const auto name = bankMeta (bank)["figure"].toString();
    const auto f = bank.getChildFile (name.isNotEmpty() ? name : "figure.svg");
    return f.isAChildOf (bank) && f.existsAsFile() && f.getSize() < 1024 * 1024 ? f : juce::File();
}

juce::var createBank (const juce::String& titleIn, const juce::String& subtitle)
{
    const auto title = titleIn.trim();

    if (title.isEmpty())
        return makeResult (false, "a bank needs a title");

    auto base = slugFor (title).substring (0, 44);

    if (base.isEmpty())
        base = "banca";

    auto slug = base;

    for (int n = 2; slug == "mie" || slug == "prove" || banksDir().getChildFile (slug).exists(); ++n)
        slug = base + "-" + juce::String (n);

    const auto folder = banksDir().getChildFile (slug);

    if (! folder.createDirectory())
        return makeResult (false, "could not create " + folder.getFullPathName());

    const auto now = nowUtc();
    auto* o = new juce::DynamicObject();
    o->setProperty ("format", bankFormat);
    o->setProperty ("slug", slug);
    o->setProperty ("title", title);
    o->setProperty ("subtitle", subtitle.trim());
    o->setProperty ("description", juce::String());
    o->setProperty ("version", "1.0.0");
    o->setProperty ("author", juce::String());
    o->setProperty ("license", "original work");
    o->setProperty ("created", now);
    o->setProperty ("updated", now);
    o->setProperty ("figure", juce::var());

    if (! folder.getChildFile ("bank.json").replaceWithText (metaText (juce::var (o))))
        return makeResult (false, "could not write bank.json");

    auto r = makeResult (true);
    r.getDynamicObject()->setProperty ("slug", slug);
    r.getDynamicObject()->setProperty ("path", folder.getFullPathName());
    return r;
}

juce::var editBank (const juce::String& slug, const juce::var& fields)
{
    const auto folder = banksDir().getChildFile (slug);

    if (! validSlug (slug) || ! folder.getChildFile ("bank.json").existsAsFile())
        return makeResult (false, "no bank named '" + slug + "'");

    auto meta = completeMeta (folder, bankMeta (folder), nowUtc());
    auto* o = meta.getDynamicObject();

    for (const char* k : { "title", "subtitle", "description" })
        if (fields.hasProperty (k))
            o->setProperty (k, juce::String (k) == "description" ? fields[k].toString() : fields[k].toString().trim());

    if (const auto err = checkMeta (meta, slug); err.isNotEmpty())
        return makeResult (false, err);

    o->setProperty ("updated", nowUtc());

    if (! folder.getChildFile ("bank.json").replaceWithText (metaText (meta)))
        return makeResult (false, "could not write bank.json");

    auto r = makeResult (true);
    r.getDynamicObject()->setProperty ("slug", slug);
    return r;
}

juce::var exportBank (const juce::String& slug, const juce::File& outIn)
{
    const auto folder = banksDir().getChildFile (slug);

    if (! validSlug (slug) || ! folder.getChildFile ("bank.json").existsAsFile())
        return makeResult (false, "no bank named '" + slug + "'");

    const auto sounds = soundDirsIn (folder);
    juce::StringArray blocked;

    for (const auto& s : sounds)
    {
        const auto cls = bundleLicense (creditsOf (s)).second;

        if (! shippable (cls))
            blocked.add (s.getFileName() + " (" + licenseLabel (cls) + ")");
    }

    if (! blocked.isEmpty())
        return makeResult (false, "cannot pack: these sounds must not be shared: " + blocked.joinIntoString (", "));

    auto out = outIn;

    if (out.isDirectory())
        out = out.getChildFile (slug + bankExt);

    const auto meta = completeMeta (folder, bankMeta (folder), nowUtc());
    juce::ZipFile::Builder zip;
    const auto text = metaText (meta).toStdString();
    zip.addEntry (std::make_unique<juce::MemoryInputStream> (text.data(), text.size(), true), 9, slug + "/bank.json", juce::Time::getCurrentTime());

    const auto add = [&] (const juce::File& f)
    {
        if (f.existsAsFile())
            zip.addFile (f, 9, slug + "/" + f.getRelativePathFrom (folder).replaceCharacter ('\\', '/'));
    };

    if (meta["figure"].toString().isNotEmpty())
        add (folder.getChildFile (meta["figure"].toString()));

    for (const auto& s : sounds)
    {
        for (const auto& f : s.getChildFile ("build").findChildFiles (juce::File::findFiles, true))
            if (! f.getFileName().startsWith ("."))
                add (f);

        for (const char* r : { "figure.svg", "notes.md", "sound.py", "sample-edits.json", "SOUND-DATA-TERMS.md", "samples/ATTRIBUTION.md",
                               "samples/credits.json", "samples/TERMS.md" })
            add (s.getChildFile (r));

        for (const auto& f : s.getChildFile ("samples/licenses").findChildFiles (juce::File::findFiles, true))
            if (! f.getFileName().startsWith ("."))
                add (f);
    }

    out.getParentDirectory().createDirectory();
    out.deleteFile();

    {
        juce::FileOutputStream stream (out);

        if (! stream.openedOk())
            return makeResult (false, "could not write " + out.getFullPathName());

        if (! zip.writeToStream (stream, nullptr))
        {
            stream.flush();
            out.deleteFile();
            return makeResult (false, "could not write the pack");
        }
    }

    auto r = makeResult (true);
    r.getDynamicObject()->setProperty ("path", out.getFullPathName());
    return r;
}

juce::var inspectBank (const juce::File& pack)
{
    auto p = prepareBank (pack);
    const auto result = importResult (p, p.ok, p.code, p.error);
    if (p.temp.exists()) p.temp.deleteRecursively();
    return result;
}

juce::var importBank (const juce::File& pack)
{
    auto p = prepareBank (pack);
    const auto cleanup = [&p] { if (p.temp.exists()) p.temp.deleteRecursively(); };
    if (! p.ok)
    {
        auto result = importResult (p, false, p.code, p.error);
        cleanup();
        return result;
    }
    if (p.action == "already_installed")
    {
        auto result = importResult (p, false, p.code, "bank is already installed; no changes made");
        cleanup();
        return result;
    }

    const auto dst = banksDir().getChildFile (p.slug);
    juce::File backup;
    if (dst.exists())
    {
        backup = banksDir().getChildFile (".backup-" + p.slug + "-" + juce::String::toHexString (juce::Random::getSystemRandom().nextInt64()));
        std::error_code ec;
        std::filesystem::rename (nativePath (dst), nativePath (backup), ec);
        if (ec)
        {
            p.code = "IO_ERROR"; p.error = "could not create a recoverable backup of the installed bank";
            auto result = importResult (p, false, p.code, p.error); cleanup(); return result;
        }
    }
    std::error_code installError;
    std::filesystem::rename (nativePath (p.folder), nativePath (dst), installError);
    if (installError)
    {
        if (backup.existsAsFile() || backup.isDirectory())
        {
            std::error_code restoreError;
            std::filesystem::rename (nativePath (backup), nativePath (dst), restoreError);
            if (restoreError)
                p.error = "install failed and prior bank remains recoverable at " + backup.getFullPathName();
            else
                p.error = "install failed; previous bank was restored";
        }
        else p.error = "could not install the staged bank";
        p.code = "IO_ERROR";
        auto result = importResult (p, false, p.code, p.error); cleanup(); return result;
    }
    p.folder = dst;
    if (backup.existsAsFile() || backup.isDirectory())
    {
        if (! backup.moveToTrash())
            p.warnings.add ("The previous bank is retained as a recoverable backup at " + backup.getFullPathName());
    }
    p.installedPath = dst.getFullPathName();
    auto result = importResult (p, true, "OK");
    result.getDynamicObject()->setProperty ("path", dst.getFullPathName());
    cleanup();
    return result;
}

juce::var inspectBankCollection (const juce::Array<juce::File>& inputs)
{
    if (inputs.isEmpty())
        return collectionFailure ("INVALID_INPUT", "select one or more bank packs or a bank collection ZIP");
    cleanupExpiredSessions();
    const auto root = importSessionsDir();
    if (! root.createDirectory())
        return collectionFailure ("IO_ERROR", "could not create an import session folder");
    auto& rng = juce::Random::getSystemRandom();
    juce::String sessionId;
    for (int i = 0; i < 4; ++i)
        sessionId << juce::String::toHexString ((juce::uint32) rng.nextInt()).paddedLeft ('0', 8);
    sessionId = sessionId.toLowerCase();
    const auto session = root.getChildFile (sessionId);
    if (! session.createDirectory())
        return collectionFailure ("IO_ERROR", "could not create an import session");

    juce::Array<CollectionSource> sources;
    int nextPack = 0;
    for (const auto& input : inputs)
    {
        juce::String error;
        if (! stageCollectionInput (input, session, nextPack, sources, error))
        {
            session.deleteRecursively();
            return collectionFailure ("UNSAFE_ARCHIVE", error);
        }
    }
    if (sources.isEmpty())
    {
        session.deleteRecursively();
        return collectionFailure ("INVALID_INPUT", "no bank archives were found in the selected inputs");
    }

    juce::Array<juce::var> entries;
    std::vector<juce::String> signatures;
    for (const auto& source : sources)
    {
        if (source.error.isNotEmpty())
        {
            auto entry = makeObject ({ { "ok", false }, { "code", source.code }, { "error", source.error },
                                      { "path", source.label }, { "name", source.label.fromLastOccurrenceOf ("/", false, false) },
                                      { "warnings", juce::Array<juce::var>() } });
            entries.add (entry);
            signatures.push_back ({});
            continue;
        }
        auto prepared = prepareBank (source.stagedPack);
        if (prepared.temp.exists()) prepared.temp.deleteRecursively();
        auto entry = collectionEntry (prepared, source.label, source.stagedPack.getFileName());
        entry.getDynamicObject()->removeProperty ("stagedFile");
        entry.getDynamicObject()->removeProperty ("packPath");
        entries.add (entry);
        signatures.push_back (prepared.contentSignature);
    }

    // A selection can contain the same bank at multiple versions. Keep only its highest
    // version. Identical same-version copies collapse to one; divergent same-version copies
    // are explicitly marked as conflicts so the user can choose a source.
    std::map<juce::String, std::vector<int>> bySlug;
    for (int i = 0; i < entries.size(); ++i)
    {
        const auto entry = entries[i];
        if ((bool) entry.getProperty ("ok", false) && entry["bank"].isObject())
            bySlug[entry["bank"]["slug"].toString()].push_back (i);
    }
    for (const auto& [slug, indexes] : bySlug)
    {
        (void) slug;
        if (indexes.size() < 2) continue;
        int winner = indexes.front();
        for (const auto i : indexes)
            if (versionKey (entries[i]["bank"]["version"].toString())
                > versionKey (entries[winner]["bank"]["version"].toString()))
                winner = i;
        const auto highestVersion = entries[winner]["bank"]["version"].toString();
        bool conflict = false;
        for (const auto i : indexes)
            if (i != winner && entries[i]["bank"]["version"].toString() == highestVersion
                && signatures[(size_t) i] != signatures[(size_t) winner])
                conflict = true;
        if (conflict)
        {
            for (const auto i : indexes)
                if (entries[i]["bank"]["version"].toString() == highestVersion)
                {
                    auto* obj = entries.getReference (i).getDynamicObject();
                    obj->setProperty ("ok", false);
                    obj->setProperty ("action", "conflict");
                    obj->setProperty ("code", "VERSION_CONFLICT");
                    obj->setProperty ("error", "multiple selected archives have this bank version but different sound source hashes");
                }
            for (const auto i : indexes)
                if (entries[i]["bank"]["version"].toString() != highestVersion)
                {
                    auto* obj = entries.getReference (i).getDynamicObject();
                    obj->setProperty ("action", "already_installed");
                    obj->setProperty ("code", "DUPLICATE_SELECTION");
                    obj->setProperty ("warnings", juce::Array<juce::var> { "Skipped because a selected newer version has a source conflict." });
                }
            continue;
        }
        for (const auto i : indexes)
            if (i != winner)
            {
                auto* obj = entries.getReference (i).getDynamicObject();
                obj->setProperty ("action", "already_installed");
                obj->setProperty ("code", "DUPLICATE_SELECTION");
                obj->setProperty ("warnings", juce::Array<juce::var> {
                    "Skipped because a newer or identical version of this bank is also selected." });
            }
    }

    juce::Array<juce::var> storedEntries;
    for (int i = 0; i < entries.size(); ++i)
    {
        const auto publicEntry = entries[i];
        const auto stagedFile = sources[i].stagedPack.getFileName();
        storedEntries.add (makeObject ({ { "pack_file", stagedFile },
                                         { "importable", (bool) publicEntry["ok"]
                                             && (publicEntry["action"].toString() == "install" || publicEntry["action"].toString() == "update") },
                                         { "code", publicEntry["code"] }, { "error", publicEntry["error"] } }));
    }
    auto stored = makeObject ({ { "format", "libero.bank-import-session/1" }, { "entries", storedEntries } });
    if (! session.getChildFile ("session.json").replaceWithText (juce::JSON::toString (stored, true) + "\n"))
    {
        session.deleteRecursively();
        return collectionFailure ("IO_ERROR", "could not persist the import session");
    }
    session.setLastModificationTime (juce::Time::getCurrentTime());
    return makeObject ({ { "ok", true }, { "format", "libero.bank-collection/1" },
                         { "sessionId", sessionId }, { "entries", entries }, { "count", entries.size() } });
}

juce::var importBankCollectionEntry (const juce::String& sessionId, int index)
{
    const auto session = sessionFolder (sessionId);
    const auto sessionFile = session.getChildFile ("session.json");
    if (! session.isDirectory() || ! sessionFile.existsAsFile())
        return makeResult (false, "import session expired or does not exist");
    const auto stored = juce::JSON::parse (sessionFile);
    const auto* entries = stored["entries"].getArray();
    if (! stored.isObject() || stored["format"].toString() != "libero.bank-import-session/1"
        || entries == nullptr || index < 0 || index >= entries->size())
        return makeResult (false, "invalid import session entry");
    const auto entry = (*entries)[index];
    if (! (bool) entry.getProperty ("importable", false))
        return makeResult (false, entry["error"].toString().isNotEmpty() ? entry["error"].toString()
                                                                          : "this bank was skipped during collection inspection");
    const auto name = entry["pack_file"].toString();
    if (name.isEmpty() || name != juce::File (name).getFileName() || ! name.endsWithIgnoreCase (bankExt))
        return makeResult (false, "invalid staged bank reference");
    const auto pack = session.getChildFile (name);
    if (! pack.isAChildOf (session) || ! pack.existsAsFile())
        return makeResult (false, "staged bank archive is missing");
    session.setLastModificationTime (juce::Time::getCurrentTime());
    return importBank (pack);
}

juce::var cleanupBankCollection (const juce::String& sessionId)
{
    const auto session = sessionFolder (sessionId);
    if (! session.isDirectory())
        return makeObject ({ { "ok", true }, { "removed", false } });
    if (! session.getChildFile ("session.json").existsAsFile())
        return makeResult (false, "refusing to remove a folder that is not an import session");
    const auto removed = session.deleteRecursively();
    return makeObject ({ { "ok", removed }, { "removed", removed } });
}

juce::var readConfig()
{
    const auto f = configFile();

    if (! f.existsAsFile())
        return juce::var (new juce::DynamicObject());

    const auto v = juce::JSON::parse (f);
    return v.isObject() ? v : juce::var (new juce::DynamicObject());
}

bool writeConfigValue (const juce::String& key, const juce::var& value)
{
    auto config = readConfig();
    config.getDynamicObject()->setProperty (key, value);
    home().createDirectory();
    return configFile().replaceWithText (juce::JSON::toString (config) + "\n");
}

} // namespace libero::library
