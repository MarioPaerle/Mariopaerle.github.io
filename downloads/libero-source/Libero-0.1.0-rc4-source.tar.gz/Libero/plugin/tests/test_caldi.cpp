// Standalone DSP regressions: clang++ -std=c++20 -O2 -Iplugin/engine
// plugin/tests/test_caldi.cpp plugin/engine/Effects.cpp plugin/engine/Params.cpp -o /tmp/test-caldi
#include "Effects.h"
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>
#include <algorithm>

using libero::Caldi;
static_assert((int)libero::P::caldi_mode==94, "Caldi must append after all existing host indices");
struct Stereo { std::vector<float> l,r; };
static int failed=0;
void check(bool ok, const char* label) {std::cout<<(ok ? "ok " : "FAIL ")<<label<<'\n'; failed+=!ok;}
Stereo tone(int sr, float hz, float amplitude, float right=.25f)
{
    Stereo x; x.l.resize((size_t)sr*3); x.r.resize(x.l.size());
    for(size_t i=0;i<x.l.size();++i) {x.l[i]=amplitude*std::sin(6.283185307179586*hz*(double)i/sr);x.r[i]=right*x.l[i];}
    return x;
}
void run(Caldi& fx, Stereo& x)
{for(size_t i=0;i<x.l.size();i+=127) fx.process(x.l.data()+i,x.r.data()+i,(int)std::min(size_t(127),x.l.size()-i));}
double rms(const std::vector<float>& x,size_t begin=48000)
{double s=0;for(size_t i=begin;i<x.size();++i)s+=x[i]*x[i];return std::sqrt(s/std::max(size_t(1),x.size()-begin));}
int main()
{
    for(int rate : {44100,48000,96000})
    {
        Caldi fx;fx.prepare((float)rate);auto raw=tone(rate,440,.35f), x=raw;
        fx.set(0,1,1,1,1,1,3);fx.reset();run(fx,x);
        check(x.l==raw.l && x.r==raw.r,"Spento is bit-exact at every macro extreme");
        fx.set(3,0,1,1,1,1,3);fx.reset();x=raw;run(fx,x);
        check(x.l==raw.l && x.r==raw.r,"zero amount is bit-exact");
        for(int mode=1;mode<=5;++mode)
        {
            fx.set(mode,1,.5f,.5f,0,0,0);fx.reset();x=raw;run(fx,x);
            double error=0, peak=0;
            for(size_t i=0;i<x.l.size();++i) {error=std::max(error,(double)std::abs(x.r[i]-.25f*x.l[i]));peak=std::max(peak,(double)std::abs(x.l[i]));}
            check(error<1e-6,"stereo-linked compression retains channel ratio");
            check(std::isfinite(peak) && peak<1,"normal input remains finite with headroom");
            fx.set(mode,1,1,1,1,1,3);fx.reset();x=tone(rate,440,.12f);run(fx,x);
            bool finite=true;for(float v:x.l)finite&=std::isfinite(v)&&std::abs(v)<1;
            check(finite,"all chain/macro extremes remain safe for -18dB input");
            Stereo silent;silent.l.resize(rate*2);silent.r.resize(rate*2);fx.reset();run(fx,silent);
            check(rms(silent.l,0)==0 && rms(silent.r,0)==0,"texture never creates idle hiss");
        }
    }
    Caldi fx;fx.prepare(48000);fx.set(1,1,.5f,.5f,0,0,0);fx.reset();auto quiet=tone(48000,1000,.015f);run(fx,quiet);
    fx.reset();auto loud=tone(48000,1000,.45f);run(fx,loud);
    check(rms(loud.l)/.45 < rms(quiet.l)/.015*.85,"loud notes compressed more than quiet notes");
    fx.set(1,1,.5f,.5f,0,0,0);fx.reset();auto bass=tone(48000,125,.01f);run(fx,bass);
    fx.reset();auto high=tone(48000,8000,.01f);run(fx,high);
    check(rms(bass.l)>rms(high.l)*1.5,"Velluto has measurable warm shelf balance");
    fx.set(5,.8f,.5f,.5f,1,.7f,0);fx.reset();auto a=tone(48000,330,.2f);run(fx,a);
    fx.reset();auto b=tone(48000,330,.2f);run(fx,b);
    check(a.l==b.l && a.r==b.r,"generative texture deterministic after reset");
    Stereo silence;silence.l.resize(48000*2);silence.r.resize(48000*2);run(fx,silence);
    check(rms(silence.l)<1e-12,"input-off texture stops; no sustained noise after note");
    fx.set(0,1,1,1,1,1,3);auto bypass=tone(48000,330,.2f);auto reference=bypass;run(fx,bypass);
    check(std::equal(bypass.l.begin()+48000,bypass.l.end(),reference.l.begin()+48000),"switching off returns to exact dry after bounded fade");
    fx.set(1,.65f,.5f,.5f,0,0,0);fx.reset();auto automated=tone(48000,440,.2f);
    for(size_t i=0;i<automated.l.size();i+=127)
    {
        const int segment=(int)i/24000;
        if(i%24000<127)fx.set(segment%6,.65f,segment%2 ? 1.f : 0.f,segment%2 ? 0.f : 1.f,0,0,segment%2 ? 3.f : -12.f);
        fx.process(automated.l.data()+i,automated.r.data()+i,(int)std::min(size_t(127),automated.l.size()-i));
    }
    double transient=0;
    for(size_t i=2;i<automated.l.size();++i)transient=std::max(transient,(double)std::abs(automated.l[i]-2*automated.l[i-1]+automated.l[i-2]));
    check(transient<.006,"preset/amount/EQ/output automation has bounded transition transients");
    std::cout<<failed<<" failures\n";return failed ? 1 : 0;
}
