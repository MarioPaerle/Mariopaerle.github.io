#!/usr/bin/env python3
"""Opt-in full native audit/import of the published 11-bank Base Bundle ZIP."""
import json
import os
import pathlib
import subprocess
import sys
import tempfile

host = pathlib.Path(sys.argv[1]).resolve()
archive = pathlib.Path(sys.argv[2]).resolve()

with tempfile.TemporaryDirectory(prefix="libero-base-bundle-") as td:
    home = pathlib.Path(td) / "Libero"
    env = dict(os.environ, LIBERO_HOME=str(home))
    inspected = subprocess.run([str(host), "--inspect-bank-collection", str(archive)], env=env,
                               text=True, capture_output=True, timeout=3600)
    if inspected.returncode:
        raise SystemExit(f"Base Bundle inspection failed: {inspected.stdout}\n{inspected.stderr}")
    plan = json.loads(inspected.stdout.strip().splitlines()[-1])
    entries = plan.get("entries", [])
    if plan.get("ok") is not True or len(entries) != 11:
        raise SystemExit(f"expected 11 pack entries, got {len(entries)}: {inspected.stdout}")
    failures = [e for e in entries if not e.get("ok") or e.get("action") not in ("install", "update")]
    if failures:
        raise SystemExit(f"Base Bundle has entries not importable: {json.dumps(failures, indent=2)}")
    for index, entry in enumerate(entries):
        imported = subprocess.run([str(host), "--import-bank-collection-entry", plan["sessionId"], str(index)],
                                  env=env, text=True, capture_output=True, timeout=600)
        if imported.returncode:
            raise SystemExit(f"import failed for {entry.get('name')}: {imported.stdout}\n{imported.stderr}")
        result = json.loads(imported.stdout.strip().splitlines()[-1])
        if not result.get("ok"):
            raise SystemExit(f"import failed for {entry.get('name')}: {json.dumps(result)}")
    cleanup = subprocess.run([str(host), "--cleanup-bank-collection", plan["sessionId"]], env=env,
                             text=True, capture_output=True, timeout=120)
    if cleanup.returncode:
        raise SystemExit(f"session cleanup failed: {cleanup.stdout}\n{cleanup.stderr}")
    banks = sorted(p.name for p in (home / "banks").iterdir() if (p / "bank.json").is_file())
    if len(banks) != 11:
        raise SystemExit(f"expected 11 imported banks, found {banks}")
    print(json.dumps({"ok": True, "banks": banks, "entries": len(entries),
                      "session_cleaned": True}, indent=2))
