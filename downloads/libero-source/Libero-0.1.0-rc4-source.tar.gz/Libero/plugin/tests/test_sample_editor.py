#!/usr/bin/env python3
"""Exercise waveform editing through the native processor in an isolated library."""
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import soundfile as sf
import zipfile

host = pathlib.Path(sys.argv[1]).resolve()
fixture = pathlib.Path(sys.argv[2]).resolve()
with tempfile.TemporaryDirectory(prefix="libero-sample-editor-") as td:
    home = pathlib.Path(td)
    sound = home / "sounds" / "sample-editor-fixture"
    sound.mkdir(parents=True)
    shutil.copytree(fixture / "build", sound / "build")
    manifest_path = sound / "build" / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    manifest["zones"] = [z for z in manifest["zones"] if z.get("layer") == "body"]
    for zone in manifest["zones"]:
        zone["one_shot"] = True
    manifest_path.write_text(json.dumps(manifest))
    body_file = sound / "build" / manifest["zones"][0]["file"]
    samples, rate = sf.read(body_file, dtype="float32", always_2d=True)
    if samples.shape[1] > 1:
        samples[:, 1] = -samples[:, 0]
        sf.write(body_file, samples, rate, subtype="FLOAT")
    (sound / "samples").mkdir()
    (sound / "samples" / "map.json").write_text("{}\n")
    env = dict(os.environ, LIBERO_HOME=str(home))
    run = subprocess.run([str(host), "--sample-editor-check", str(sound)], env=env,
                         text=True, capture_output=True, timeout=90)
    print(run.stdout)
    if run.returncode:
        print(run.stderr, file=sys.stderr)
        raise SystemExit(run.returncode)
    result = json.loads(run.stdout.strip().splitlines()[-1])
    expected = ["eligible", "waveform", "applied", "loaded_44100", "loaded_48000", "crop_content", "save_copy"]
    if not all(result.get(key) for key in expected):
        raise SystemExit(f"native waveform check failed: {result}")
    copied = list((home / "sounds").glob("waveform-copy*"))
    if len(copied) != 1 or not (copied[0] / "sample-edits.json").is_file():
        raise SystemExit("Save As did not preserve sample-edits.json")
    os.environ["LIBERO_HOME"] = str(home)
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "python"))
    from libero import library
    library.bank_create("waveform-bank", "Waveform test")
    library.bank_add(copied[0].name, "waveform-bank")
    pack = home / "waveform-bank.liberobank"
    exported = subprocess.run([str(host), "--export-bank", "waveform-bank", str(pack)], env=env,
                              text=True, capture_output=True, timeout=90)
    if exported.returncode or not pack.is_file():
        raise SystemExit(f"native export failed: {exported.stdout}{exported.stderr}")
    imported_home = home / "import-home"
    imported_env = dict(os.environ, LIBERO_HOME=str(imported_home))
    imported = subprocess.run([str(host), "--import-bank", str(pack)], env=imported_env,
                              text=True, capture_output=True, timeout=90)
    if imported.returncode:
        moved = home / "banks" / "waveform-bank" / copied[0].name
        print((moved / "sample-edits.json").read_text(), file=sys.stderr)
        mm = json.loads((moved / "build" / "manifest.json").read_text())
        print(mm.get("source_hash"), file=sys.stderr)
        print([z for z in mm["zones"] if z["file"] == "body_n036_v100.wav"], file=sys.stderr)
        raise SystemExit(f"native reimport failed: {imported.stdout}{imported.stderr}")
    restored = imported_home / "banks" / "waveform-bank" / copied[0].name / "sample-edits.json"
    if not restored.is_file():
        raise SystemExit("native export/import did not preserve sample-edits.json")
    invalid_pack = home / "invalid-stale-edit.liberobank"
    with zipfile.ZipFile(pack) as source, zipfile.ZipFile(invalid_pack, "w", zipfile.ZIP_DEFLATED) as target:
        for item in source.infolist():
            payload = source.read(item.filename)
            if item.filename.endswith("/sample-edits.json"):
                sidecar = json.loads(payload)
                next(iter(sidecar["edits"].values()))["source_hash"] = "stale"
                payload = json.dumps(sidecar).encode()
            target.writestr(item, payload)
    rejected = subprocess.run([str(host), "--inspect-bank", str(invalid_pack)], env=imported_env,
                              text=True, capture_output=True, timeout=90)
    if rejected.returncode == 0 or "INVALID_BUNDLE" not in rejected.stdout:
        raise SystemExit(f"native importer did not reject stale sample edit: {rejected.stdout}{rejected.stderr}")
