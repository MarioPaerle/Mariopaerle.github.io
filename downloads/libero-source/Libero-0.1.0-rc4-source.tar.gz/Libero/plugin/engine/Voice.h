#pragma once

#include "Bundle.h"
#include "Dsp.h"
#include "Osc.h"
#include "Params.h"

#include <array>

namespace libero
{

// Maximum samples per engine sub-block (control rate).
constexpr int kChunk = 32;

// Control values the engine computes once per sub-block and shares with every voice.
struct VoiceControl
{
    float sampleRate = 48000.0f;
    float playbackScale = 1.0f;     // sound sample rate / engine sample rate

    // Per-sample (smoothed) layer gains and Corde amount for this chunk.
    const float* gAttack = nullptr;
    const float* gBody   = nullptr;
    const float* gTail   = nullptr;
    const float* corde   = nullptr;

    float attackMs = 2.0f, decayMs = 400.0f, sustain = 1.0f, releaseMs = 300.0f, curve = 0.0f;
    float pitchOffset = 0.0f;       // tune + fine + bend, semitones
    float glideMs = 0.0f;
    float velSens = 0.7f;

    int fltModeA = 0, fltModeB = 0; // crossfade A -> B by fltMix (equal when settled)
    float fltMix = 1.0f, fltMixStart = 1.0f;   // crossfade position at chunk end / start
    float cutoff = 12000.0f, reso = 0.15f, fltEnv = 0.0f, drive = 0.0f;
    float fltDyn = 0.0f;          // CC1/knob timbre range, total octaves around dynamics centre
    float ampDyn = 0.0f;          // expression-to-level amount for live oscillators

    float resTune = 0.0f, resDecay = 0.5f, resBright = 0.5f;

    // Live dynamics (CC or knob): value at chunk start / end. Otherwise each voice uses the
    // dynamics its velocity gave it at note-on.
    bool dynLive = false;
    float dynStart = 0.0f, dynEnd = 0.0f;

    // Oscillators (null or all off: sample layers only) and the global LFO.
    const OscControl* osc = nullptr;
    float lfoStart = 0.0f, lfoEnd = 0.0f;          // -1..1 at chunk start / end
    float lfoPitch = 0.0f, lfoCutoff = 0.0f, lfoAmp = 0.0f, lfoPw = 0.0f, lfoDelayMs = 0.0f;

    // Filter: its own envelope (else it follows the amp envelope), key and velocity tracking.
    bool fenvOwn = false;
    float fenvAttack = 0.0f, fenvDecay = 400.0f, fenvSustain = 0.0f, fenvRelease = 300.0f;
    float fltKey = 0.0f, fltVel = 0.0f;
};

//==============================================================================
class Envelope
{
public:
    enum class Stage { idle, attack, decay, sustain, release };

    void start() noexcept              { stage = Stage::attack; progress = 0.0f; from = value; }
    void release() noexcept            { if (stage != Stage::idle) { stage = Stage::release; progress = 0.0f; from = value; } }
    void reset() noexcept              { stage = Stage::idle; value = 0.0f; progress = 0.0f; }
    bool isIdle() const noexcept       { return stage == Stage::idle; }
    float get() const noexcept         { return value; }

    // Advances by n samples and returns the value at the end.
    float advance (int n, const VoiceControl& c) noexcept;

private:
    static float shape (float p, float curve, bool rising) noexcept;

    Stage stage = Stage::idle;
    float value = 0.0f, from = 0.0f, progress = 0.0f;
};

//==============================================================================
// Sympathetic strings: four tuned feedback combs excited by the voice.
class CordeResonator
{
public:
    void prepare (float sampleRate);
    void reset() noexcept;
    void setNote (float noteSemis, const VoiceControl&) noexcept;   // control rate
    void process (const float* inL, const float* inR, float* outL, float* outR,
                  const float* amount, int n) noexcept;

private:
    static constexpr int kStrings = 4;

    std::array<dsp::DelayLine, kStrings> lines;
    std::array<float, kStrings> delay {}, fb {}, prev {}, panL {}, panR {};
    float c0 = 1.0f, c1 = 0.0f, inGain = 0.0f;
    float sampleRate = 48000.0f;
    bool active = false;
};

// Round-robin take per layer for one note.
struct Takes { int body = 0, attack = 0, tail = 0; };

// Everything decided for one note-on besides pitch and velocity.
struct NoteSetup
{
    Takes takes;
    int art = -1;           // active articulation (index), -1 = none
    float dyn = -1.0f;      // dynamics from velocity (0..1), < 0 = none
    float detune = 0.0f;    // humanize, semitones
    float gain = 1.0f;      // humanize, linear
    float velocityGain = 1.0f;
    bool hasVelocityGain = false;
    int delay = 0;          // humanize, samples before the note sounds
    uint32_t oscSeed = 1;   // oscillator start phases / drift
    bool oscRetrigger = false;
};

//==============================================================================
class Voice
{
public:
    void prepare (float sampleRate);

    void start (const SoundData&, int note, int velocity, float startPitch, uint64_t order,
                const VoiceControl&, const NoteSetup& setup = {}) noexcept;

    // Legato: move this sounding voice to a new note without retriggering the envelope or the
    // attack. The pitch slurs over max(glide, 25 ms); if the new key uses another body zone,
    // the two are phase-aligned and crossfaded over 30 ms (set up on the next render).
    void legatoTo (int newNote, const NoteSetup&) noexcept;

    void noteOff() noexcept;
    void holdBySustain() noexcept   { keyDown = false; sustained = true; }
    void steal() noexcept;
    void choke() noexcept;           // ~15 ms raised-cosine fade, then free
    void kill() noexcept;

    bool isActive() const noexcept   { return active; }
    bool isStealing() const noexcept { return stealing; }
    bool isKeyDown() const noexcept  { return keyDown; }
    bool isReleased() const noexcept { return released; }
    const Zone* leadBodyZone() const noexcept { return bodyZone; }
    int getNote() const noexcept     { return note; }
    uint64_t getOrder() const noexcept { return order; }
    float getPitch() const noexcept  { return pitch; }
    float getLevel() const noexcept  { return lastEnv * velGain; }   // body level, for stealing
    const SoundData* getSound() const noexcept { return sound; }

    bool sustained = false;          // key released while the sustain pedal was down

    // Adds this voice's output into outL/outR.
    void render (const VoiceControl&, float* outL, float* outR, int n) noexcept;

private:
    struct Player
    {
        const Zone* zone = nullptr;
        double pos = 0.0, inc = 1.0;
        bool active = false;

        int fadeLeft = 0, fadeLen = 0;   // fade-in after an onset_ms skip

        void start (const Zone* z) noexcept
        {
            zone = z;
            active = z != nullptr;
            pos = z != nullptr ? (double) std::min (z->onset, std::max (0, z->length() - 1)) : 0.0;
            fadeLeft = fadeLen = z != nullptr ? z->onsetFade : 0;
        }
        float sample (int ch, int i) const noexcept;
        void read (float& l, float& r) const noexcept;
        float mono (double at) const noexcept;
        void advance() noexcept;
        double ratioFor (float semitones, float playbackScale) const noexcept;
    };

    // The body: one player, or one per dynamics layer crossfaded by the dynamics value
    // (equal power between the two layers whose centres bracket it, over `xf` of the gap; 0 = hard switch). Layers share a timeline.
    struct BodySource
    {
        static constexpr int kMax = 8;
        std::array<Player, kMax> p;
        std::array<float, kMax> centre {}, w0 {}, w1 {};
        int count = 0, lead = 0;
        float xf = -1.0f;   // dynamics crossfade (see SoundData::dynCrossfade); < 0 = legacy full-gap blend

        void setup (const SoundData&, int note, int velocity, int take, Layer layer = Layer::body, int art = -1) noexcept;
        const Zone* leadZone() const noexcept { return count > 0 ? p[(size_t) lead].zone : nullptr; }
        void clear() noexcept;
        bool active() const noexcept;
        bool sameAs (const BodySource& o) const noexcept;
        void weigh (float d0, float d1) noexcept;
        void setInc (float semitones, float playbackScale) noexcept;
        void setPos (double pos) noexcept;
        void read (int i, int n, float& l, float& r) const noexcept;
        void advance() noexcept;
    };

    static void weightsFor (const BodySource&, float d, std::array<float, BodySource::kMax>& w) noexcept;

    void beginLegato (const VoiceControl&) noexcept;
    void updateFilter (const VoiceControl&, float env, float lfoOctaves) noexcept;
    float filterOne (int ch, float x, float mix, const VoiceControl&) noexcept;

    const SoundData* sound = nullptr;
    BodySource attack, tail;   // with `dyn` layers: crossfaded at trigger time, then fixed
    BodySource body;
    BodySource bodyOld;              // previous body while a legato crossfade runs
    Envelope env, fenv;
    float lastFenv = 0.0f;
    Takes takes;
    int art = -1;                    // articulation this note was started with
    float xfade = 1.0f, xfadeStep = 0.0f, xfadeRho = 0.0f;
    bool legatoPending = false, legatoGlide = false;

    std::array<dsp::SVF, 2> svf;
    std::array<std::array<dsp::SVF, 3>, 2> formant;
    std::array<float, 3> formantGain {};
    float bpNorm = 1.0f;

    CordeResonator corde;
    VoiceOscillators oscs;
    std::array<float, kChunk> oscL {}, oscR {};

    std::array<float, kChunk> bufL {}, bufR {};

    float sampleRate = 48000.0f;
    int note = 60, velocity = 100;
    float velGain = 1.0f, velGainTarget = 1.0f, velGainStep = 0.0f;
    int velGainRamp = 0;
    float noteDyn = -1.0f, lastDyn = 0.0f, tailGain = 1.0f;
    int startDelay = 0;
    int64_t age = 0;                 // samples sounded since note-on (release-by-duration)
    float pitch = 60.0f, targetPitch = 60.0f;   // semitones incl. glide, excl. global offset
    float lastEnv = 0.0f;
    float stealGain = 1.0f, stealStep = 0.0f;
    int silentSamples = 0, ringSamples = 0;
    bool hasTail = false, oneShot = false;
    const Zone* bodyZone = nullptr;   // body zone at note-on (one-shot and choke data)
    uint64_t order = 0;
    bool active = false, stealing = false, keyDown = false, released = false;
};

} // namespace libero
