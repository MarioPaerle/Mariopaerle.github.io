#include "Effects.h"

namespace libero
{

using namespace dsp;

float Caldi::Biquad::tick (float x) noexcept
{
    const float y = b0*x + z1;
    z1 = b1*x - a1*y + z2;
    z2 = b2*x - a2*y;
    if (std::abs(z1)<1e-25f) z1=0;
    if (std::abs(z2)<1e-25f) z2=0;
    return sanitize(y);
}

void Caldi::Biquad::shelf (float hz, float db, bool high, float rate) noexcept
{
    const float A=std::pow(10.f, db/40.f), w=kTwoPi*clampf(hz,20.f,rate*.4f)/rate;
    const float c=std::cos(w), s=std::sin(w), alpha=s/std::sqrt(2.f), t=2*std::sqrt(A)*alpha;
    float a0;
    if (high)
    {
        b0=A*((A+1)+(A-1)*c+t); b1=-2*A*((A-1)+(A+1)*c); b2=A*((A+1)+(A-1)*c-t);
        a0=(A+1)-(A-1)*c+t; a1=2*((A-1)-(A+1)*c); a2=(A+1)-(A-1)*c-t;
    }
    else
    {
        b0=A*((A+1)-(A-1)*c+t); b1=2*A*((A-1)-(A+1)*c); b2=A*((A+1)-(A-1)*c-t);
        a0=(A+1)+(A-1)*c+t; a1=-2*((A-1)+(A+1)*c); a2=(A+1)+(A-1)*c-t;
    }
    b0/=a0; b1/=a0; b2/=a0; a1/=a0; a2/=a0;
}

void Caldi::Biquad::peak (float hz, float db, float q, float rate) noexcept
{
    const float A=std::pow(10.f,db/40.f), w=kTwoPi*hz/rate, c=std::cos(w), alpha=std::sin(w)/(2*q);
    const float a0=1+alpha/A;
    b0=(1+alpha*A)/a0; b1=-2*c/a0; b2=(1-alpha*A)/a0;
    a1=-2*c/a0; a2=(1-alpha/A)/a0;
}

void Caldi::prepare (float rate)
{
    sr=rate;
    for (auto* s : {&mix,&bodyS,&lightS,&grainS,&motionS,&outputS}) s->setTimeMs(30,sr);
    reset();
}

void Caldi::set (int mode, float amt, float b, float lightValue, float g, float m, float out) noexcept
{
    requested=std::clamp(mode,0,5); amount=clampf(amt,0.f,1.f);
    body=clampf(b,0.f,1.f); light=clampf(lightValue,0.f,1.f);
    grain=clampf(g,0.f,1.f); motion=clampf(m,0.f,1.f); output=clampf(out,-12.f,3.f);
    bodyS.target=body; lightS.target=light; grainS.target=grain;
    motionS.target=motion; outputS.target=output;
    // Fade the old chain to dry before changing coefficients/state; then fade
    // the new chain in. Preset automation never swaps a ringing filter abruptly.
    mix.target=(requested==active && active!=0) ? amount : 0.f;
}

void Caldi::reset() noexcept
{
    active=requested; mix.reset(active==0 ? 0.f : amount);
    bodyS.reset(body); lightS.reset(light); grainS.reset(grain); motionS.reset(motion); outputS.reset(output);
    for (auto& b : eqL) b.clear(); for (auto& b : eqR) b.clear();
    envelope=gainDb=gate=0; phase=phase2=0; rng.reseed(0xc41d15u);
    noiseLow.reset(); noiseHigh.reset(); configure();
}

void Caldi::configure() noexcept
{
    struct Chain {float low, high, mid, hz, threshold, ratio, attack, release, parallel, makeup, bottom, top;};
    static constexpr Chain chains[] = {
        {0,0,0,800,-22,2,25,220,0,0,180,2200},
        {2.2f,-3.2f,-.8f,900,-22,2.5f,30,260,.45f,1.0f,140,1800},
        {.6f,1.2f,1.5f,1600,-19,2.0f,18,180,.35f,.6f,600,3800},
        {1.4f,-5.0f,-1.0f,450,-26,3.0f,38,340,.55f,1.5f,90,1200},
        {3.0f,-1.4f,-1.0f,650,-20,2.8f,24,240,.45f,1.0f,200,2600},
        {0.0f,2.0f,.6f,2600,-24,1.8f,35,300,.30f,.5f,1200,6200},
    };
    const auto& c=chains[active];
    threshold=c.threshold; ratio=c.ratio; attack=onePoleCoeff(c.attack,sr); release=onePoleCoeff(c.release,sr);
    parallel=c.parallel; makeup=c.makeup; noiseBottom=c.bottom; noiseTop=c.top;
    for (auto* bank : {&eqL,&eqR})
    {
        (*bank)[0].shelf(180,c.low+8*(bodyS.current-.5f),false,sr);
        (*bank)[1].peak(c.hz,c.mid,.75f,sr);
        (*bank)[2].shelf(2800,c.high+8*(lightS.current-.5f),true,sr);
    }
    noiseLow.setHz(noiseTop,sr); noiseHigh.setHz(noiseBottom,sr);
}

void Caldi::process (float* l, float* r, int n) noexcept
{
    if (requested!=active && mix.current<1e-5f)
    {
        active=requested;
        for (auto& b : eqL) b.clear(); for (auto& b : eqR) b.clear();
        envelope=gainDb=gate=0; noiseLow.reset(); noiseHigh.reset();
        mix.current=0; mix.target=active==0 ? 0.f : amount;
    }
    if (active==0 && mix.current<=0.f) return; // bit-exact, including output macro
    bodyS.advance(n); lightS.advance(n); configure();
    const float detectorCoeff=onePoleCoeff(8,sr), gateAttack=onePoleCoeff(8,sr), gateRelease=onePoleCoeff(100,sr);
    for (int i=0;i<n;++i)
    {
        const float dryL=l[i], dryR=r[i];
        const float p=std::max(dryL*dryL,dryR*dryR); // stereo link; no channel image steering
        envelope+=detectorCoeff*(p-envelope);
        const float level=10*std::log10(std::max(envelope,1e-20f));
        const float over=level-threshold, knee=10.f;
        float reduction=0;
        if (over>knee*.5f) reduction=(1.f/ratio-1.f)*over;
        else if (over>-knee*.5f) reduction=(1.f/ratio-1.f)*(over+knee*.5f)*(over+knee*.5f)/(2*knee);
        gainDb+=(reduction<gainDb ? attack : release)*(reduction-gainDb);
        const float linkedGain=std::pow(10.f,(gainDb+makeup)*.05f);
        const float compGain=lerp(1.f,linkedGain,parallel);
        float wetL=dryL*compGain, wetR=dryR*compGain;
        for (int j=0;j<3;++j) {wetL=eqL[(size_t)j].tick(wetL); wetR=eqR[(size_t)j].tick(wetR);}
        // Gate from the actual input, with a smooth -72..-54dB threshold. No
        // noise excitation at rest, even immediately after a previous note.
        const float gateTarget=clampf((level+72.f)/18.f,0.f,1.f);
        gate+=(gateTarget>gate ? gateAttack : gateRelease)*(gateTarget-gate);
        const float g=grainS.next(), movement=motionS.next();
        phase+=kTwoPi*.071/sr; if (phase>kTwoPi) phase-=kTwoPi;
        phase2+=kTwoPi*.113/sr; if (phase2>kTwoPi) phase2-=kTwoPi;
        const float slow=(float)std::sin(phase), slow2=(float)std::sin(phase2+1.1);
        const float filtered=noiseLow.tick(rng.bipolar());
        const float noise=filtered-noiseHigh.tick(filtered);
        const float texture=(p>1e-20f ? 1.f : 0.f)*gate*std::sqrt(std::max(envelope,0.f))*g*.055f*noise*(1+movement*.25f*slow2);
        wetL=(wetL+texture)*(1+movement*.025f*slow);
        wetR=(wetR+texture)*(1+movement*.025f*slow);
        const float amt=mix.next(), trim=std::pow(10.f,outputS.next()*.05f);
        l[i]=sanitize(lerp(dryL,wetL*trim,amt)); r[i]=sanitize(lerp(dryR,wetR*trim,amt));
    }
}

namespace
{
    float resonatorT60 (float decay) noexcept { return 0.05f * std::exp2 (8.0f * clampf (decay, 0.0f, 1.0f)); }

    struct ModeTable
    {
        float baseHz;
        float t60Scale;
        float ratio[12];
        float amp[12];
    };

    // Vetro: wine-glass + free-bar partials with a slightly detuned pair for beating.
    constexpr ModeTable kGlass { 523.25f, 1.0f,
        { 1.0f, 1.0031f, 2.32f, 2.756f, 4.25f, 5.404f, 6.63f, 8.933f, 9.38f, 13.34f, 15.8f, 19.2f },
        { 1.0f, 0.8f,    0.7f,  0.55f,  0.5f,  0.4f,   0.35f, 0.3f,   0.25f, 0.2f,   0.15f, 0.12f } };

    // Legno: low-Q body resonances (air mode, main wood modes, bridge hill) around C4.
    constexpr ModeTable kWood { 261.63f, 0.12f,
        { 0.38f, 0.8f, 1.53f, 2.1f, 3.06f, 4.2f, 6.1f, 8.4f, 11.5f, 15.3f, 1.8f, 2.6f },
        { 0.9f,  1.0f, 0.9f,  0.8f, 0.7f,  0.6f, 0.5f, 0.45f, 0.35f, 0.25f, 0.6f, 0.5f } };

    // Metallo: rectangular plate modes (aspect 1.37), note the near-degenerate pair.
    constexpr ModeTable kMetal { 130.81f, 1.3f,
        { 1.0f, 2.043f, 2.957f, 3.781f, 4.0f, 5.738f, 6.214f, 6.219f, 8.171f, 9.0f, 9.342f, 11.83f },
        { 1.0f, 0.9f,   0.85f,  0.8f,   0.7f, 0.65f,  0.6f,   0.6f,   0.5f,   0.45f, 0.4f,  0.35f } };

    const ModeTable& tableFor (ResMode m) noexcept
    {
        switch (m)
        {
            case ResMode::legno:   return kWood;
            case ResMode::metallo: return kMetal;
            case ResMode::vetro:
            case ResMode::corde:   break;
        }

        return kGlass;
    }
}

//==============================================================================
void ModalResonator::prepare (float sr)
{
    sampleRate = sr;
    configure (current);
    reset();
}

void ModalResonator::reset() noexcept
{
    for (auto& m : modes)
        m.y1 = m.y2 = 0.0f;

    x1 = x2 = 0.0f;
}

void ModalResonator::configure (ResMode m) noexcept
{
    const auto& t = tableFor (m);
    baseHz = t.baseHz;

    for (int i = 0; i < kModes; ++i)
    {
        auto& md = modes[(size_t) i];
        md.ratio = t.ratio[i];
        md.amp = t.amp[i];
        md.decayScale = t.t60Scale;
        md.pan = (i % 2 == 0) ? 0.3f + 0.04f * (float) (i / 2) : 0.7f - 0.04f * (float) (i / 2);
    }

    dirty = true;
}

void ModalResonator::set (ResMode mode, float tuneSemis, float decayIn, float brightIn) noexcept
{
    if (mode == ResMode::corde)
        mode = current;

    if (mode != pending)
    {
        pending = mode;

        if (running)
            fadeStep = -1.0f / (0.02f * sampleRate);
        else
        {
            current = pending;
            configure (current);
        }
    }

    const auto changed = [] (float a, float b) { return std::abs (a - b) > 1.0e-6f; };

    if (changed (tuneSemis, tune) || changed (decayIn, decay) || changed (brightIn, bright))
    {
        tune = tuneSemis;
        decay = decayIn;
        bright = brightIn;
        dirty = true;
    }

    if (dirty)
        computeCoeffs();
}

void ModalResonator::computeCoeffs() noexcept
{
    dirty = false;

    const auto base = baseHz * std::exp2 (tune / 12.0f);
    const auto t60 = resonatorT60 (decay);
    const auto dark = 1.0f - clampf (bright, 0.0f, 1.0f);

    for (auto& m : modes)
    {
        const auto f = base * m.ratio;

        if (f >= 0.45f * sampleRate || f < 15.0f)
        {
            m.a1 = m.a2 = m.b = 0.0f;
            continue;
        }

        const auto modeT60 = std::max (0.005f, t60 * m.decayScale * std::pow (m.ratio, -0.7f * dark));
        const auto r = std::exp (-6.9078f / (modeT60 * sampleRate));
        const auto comp = std::min (8.0f, std::pow (kPi / (1.0f - r), 0.25f));

        m.a1 = 2.0f * r * std::cos (kTwoPi * f / sampleRate);
        m.a2 = r * r;
        m.b = (1.0f - r) * m.amp * std::pow (m.ratio, -1.2f * dark) * comp * 0.5f;
        m.gl = std::sqrt (1.0f - m.pan);
        m.gr = std::sqrt (m.pan);
    }
}

void ModalResonator::process (float* l, float* r, const float* amount, int n) noexcept
{
    if (amount[0] <= 0.0f && amount[n - 1] <= 0.0f)
    {
        if (running)
        {
            reset();
            running = false;

            if (pending != current)
            {
                current = pending;
                configure (current);
                computeCoeffs();
            }

            fade = 1.0f;
            fadeStep = 0.0f;
        }

        return;
    }

    running = true;

    for (int i = 0; i < n; ++i)
    {
        const auto x = (l[i] + r[i]) * 0.5f;
        const auto xin = x - x2;
        x2 = x1;
        x1 = x;

        float wl = 0.0f, wr = 0.0f;

        for (auto& m : modes)
        {
            const auto y = m.b * xin + m.a1 * m.y1 - m.a2 * m.y2;
            m.y2 = m.y1;
            m.y1 = y;
            wl += y * m.gl;
            wr += y * m.gr;
        }

        if (fadeStep != 0.0f)
        {
            fade += fadeStep;

            if (fade <= 0.0f)
            {
                fade = 0.0f;
                current = pending;
                configure (current);
                computeCoeffs();
                reset();
                fadeStep = 1.0f / (0.02f * sampleRate);
            }
            else if (fade >= 1.0f)
            {
                fade = 1.0f;
                fadeStep = 0.0f;
            }
        }

        const auto g = amount[i] * fade;
        l[i] += g * sanitize (wl);
        r[i] += g * sanitize (wr);
    }
}

//==============================================================================
void Tape::prepare (float sr)
{
    sampleRate = sr;
    lineL.allocate ((int) (0.03f * sr));
    lineR.allocate ((int) (0.03f * sr));

    for (auto* s : { &wow, &flutter, &sat, &age, &mix })
        s->setTimeMs (30.0f, sr);

    baseDelay.setTimeMs (150.0f, sr);
    dcL.setup (sr);
    dcR.setup (sr);
    satDcL.setup (sr, 8.0f);
    satDcR.setup (sr, 8.0f);
    hissL.setHz (7000.0f, sr);
    hissR.setHz (7000.0f, sr);
    drift.setHz (0.4f, sr);
    reset();
}

void Tape::reset() noexcept
{
    lineL.reset();
    lineR.reset();

    for (auto* s : { &wow, &flutter, &sat, &age, &mix, &baseDelay })
        s->reset (0.0f);

    for (auto* f : { &hfL, &hfR, &hissL, &hissR, &drift })
        f->reset();

    dcL.reset();
    dcR.reset();
    satDcL.reset();
    satDcR.reset();
    rng.reseed (0x7a9e5eedu);
    wowPhase = flutPhase = flutPhase2 = 0.0;
    driftTarget = 0.0f;
    driftCounter = 0;
    dropCountdown = (int) sampleRate;
    dropRemaining = 0;
    dropDepth = 0.0f;
    dropGain = 1.0f;
}

void Tape::set (float w, float f, float s, float a, float m) noexcept
{
    wow.target = w;
    flutter.target = f;
    sat.target = s;
    age.target = a;
    mix.target = m;
}

void Tape::process (float* l, float* r, int n) noexcept
{
    if (mix.target <= 0.0f && mix.current < 1.0e-5f)
    {
        // Bypassed: keep the transport fed so turning it back up never starts from an empty line.
        mix.current = 0.0f;

        for (int i = 0; i < n; ++i)
        {
            lineL.push (l[i]);
            lineR.push (r[i]);
        }

        return;
    }

    const auto wowRate = 0.55 / sampleRate, flutRate = 6.8 / sampleRate, flutRate2 = 11.3 / sampleRate;
    const auto dropSmooth = onePoleCoeff (4.0f, sampleRate);

    // Age and saturation shape coefficients per call; they are smoothed, so this is zipper-free.
    const auto a = age.advance (n);
    const auto s = sat.advance (n);
    hfL.setHz (20000.0f * std::exp2 (-2.6f * a), sampleRate);
    hfR.a = hfL.a;

    const auto hissGain = a > 0.0f ? dbToGain (-72.0f + 26.0f * a) : 0.0f;
    const auto satWet = std::min (1.0f, s * 4.0f);
    const auto g = 1.0f + 6.0f * s;
    const auto bias = 0.15f * s;
    const auto tb = fastTanh (bias);
    const auto norm = 0.5f / std::max (1.0e-3f, fastTanh (g * 0.5f + bias) - tb);

    for (int i = 0; i < n; ++i)
    {
        const auto wowD = wow.next() * 0.004f * sampleRate;
        const auto flD  = flutter.next() * 0.0002f * sampleRate;
        const auto m    = mix.next();

        if (--driftCounter <= 0)
        {
            driftCounter = 2048;
            driftTarget = rng.bipolar();
        }

        const auto dr = drift.tick (driftTarget);

        wowPhase += wowRate;     if (wowPhase >= 1.0) wowPhase -= 1.0;
        flutPhase += flutRate;   if (flutPhase >= 1.0) flutPhase -= 1.0;
        flutPhase2 += flutRate2; if (flutPhase2 >= 1.0) flutPhase2 -= 1.0;

        const auto wowMod = 0.75f * std::sin (kTwoPi * (float) wowPhase) + 0.6f * dr;
        const auto flMod  = 0.7f * std::sin (kTwoPi * (float) flutPhase) + 0.3f * std::sin (kTwoPi * (float) flutPhase2);

        const auto base = baseDelay.next();
        baseDelay.target = wowD * 1.4f + flD * 1.05f;
        const auto d = base + wowD * wowMod + flD * flMod;

        const auto dryL = l[i], dryR = r[i];
        lineL.push (dryL);
        lineR.push (dryR);

        auto wl = d < 2.0f ? lineL.readLinear (d) : lineL.readHermite (d);
        auto wr = d < 2.0f ? lineR.readLinear (d) : lineR.readHermite (d);

        if (satWet > 0.0f)
        {
            // The bias makes the curve asymmetric (even harmonics) and so also makes DC.
            wl = satDcL.tick (lerp (wl, (fastTanh (g * wl + bias) - tb) * norm, satWet));
            wr = satDcR.tick (lerp (wr, (fastTanh (g * wr + bias) - tb) * norm, satWet));
        }

        if (a > 0.0f)
        {
            wl = hfL.tick (wl);
            wr = hfR.tick (wr);

            if (--dropCountdown <= 0)
            {
                dropCountdown = (int) ((0.5f + 3.0f * rng.uniform()) / std::max (0.05f, a) * sampleRate);
                dropRemaining = (int) ((0.02f + 0.1f * rng.uniform()) * sampleRate);
                dropDepth = a * (0.3f + 0.5f * rng.uniform());
            }

            const auto dropTarget = dropRemaining > 0 ? 1.0f - dropDepth : 1.0f;
            dropRemaining = std::max (0, dropRemaining - 1);
            dropGain += dropSmooth * (dropTarget - dropGain);

            wl = wl * dropGain + dcL.tick (hissL.tick (rng.bipolar())) * hissGain;
            wr = wr * dropGain + dcR.tick (hissR.tick (rng.bipolar())) * hissGain;
        }

        l[i] = dryL + m * (wl - dryL);
        r[i] = dryR + m * (wr - dryR);
    }
}

//==============================================================================
void Echo::prepare (float sr)
{
    sampleRate = sr;
    lineL.allocate ((int) (4.1f * sr));
    lineR.allocate ((int) (4.1f * sr));
    xfStep = 1.0f / (0.05f * sr);
    time.setTimeMs (90.0f, sr);
    feedback.setTimeMs (30.0f, sr);
    spread.setTimeMs (30.0f, sr);
    mix.setTimeMs (30.0f, sr);
    reset();
}

void Echo::reset() noexcept
{
    lineL.reset();
    lineR.reset();
    time.reset (time.target > 0.0f ? time.target : 0.375f * sampleRate);
    feedback.reset (feedback.target);
    spread.reset (spread.target);
    mix.reset (0.0f);
    curT = newT = synced && syncTarget > 0.0f ? syncTarget : time.current;
    xf = 1.0f;

    for (auto* f : { &lpL, &lpR, &hpL, &hpR })
        f->reset();
}

void Echo::set (float timeMs, float fb, float tone, float sp, float m) noexcept
{
    time.target = clampf (timeMs, 10.0f, 2000.0f) * 0.001f * sampleRate;
    feedback.target = clampf (fb, 0.0f, 0.95f);
    spread.target = clampf (sp, 0.0f, 1.0f);
    mix.target = clampf (m, 0.0f, 1.0f);

    tone = clampf (tone, 0.0f, 1.0f);
    lpL.setHz (1000.0f * std::exp2 (4.0f * tone), sampleRate);
    lpR.a = lpL.a;
    hpL.setHz (40.0f * std::exp2 (2.3f * tone), sampleRate);
    hpR.a = hpL.a;
}

void Echo::setSynced (bool s, float beats, float bpm) noexcept
{
    if (! std::isfinite (bpm) || bpm < 10.0f || bpm > 999.0f)
        bpm = kDefaultBpm;

    synced = s;
    syncTarget = clampf (beats * 60.0f / bpm * 1000.0f, 10.0f, 4000.0f) * 0.001f * sampleRate;
}

void Echo::process (float* l, float* r, int n) noexcept
{
    for (int i = 0; i < n; ++i)
    {
        const auto fb = feedback.next();
        const auto s = spread.next();
        const auto m = mix.next();

        float wl, wr;

        if (! synced)
        {
            // Libero mode: the original path, bit for bit. curT shadows it so that switching to
            // Tempo crossfades from where the delay actually is.
            const auto t = time.next();
            curT = newT = t;
            xf = 1.0f;
            wl = lineL.readHermite (t - 1.0f);
            wr = lineR.readHermite (t - 1.0f);
        }
        else
        {
            if (xf >= 1.0f)
            {
                // Settled: follow small moves (a host ramping its tempo) smoothly, start a
                // crossfade for real jumps.
                if (std::abs (syncTarget - curT) > 0.02f * curT + 2.0f)
                {
                    newT = syncTarget;
                    xf = 0.0f;
                }
                else
                {
                    curT += 0.002f * (syncTarget - curT);
                }
            }

            if (xf < 1.0f)
            {
                newT = syncTarget;
                xf = std::min (1.0f, xf + xfStep);
                const auto gi = std::sin (xf * 1.5707963f), go = std::cos (xf * 1.5707963f);
                wl = lineL.readHermite (curT - 1.0f) * go + lineL.readHermite (newT - 1.0f) * gi;
                wr = lineR.readHermite (curT - 1.0f) * go + lineR.readHermite (newT - 1.0f) * gi;

                if (xf >= 1.0f)
                    curT = newT;
            }
            else
            {
                wl = lineL.readHermite (curT - 1.0f);
                wr = lineR.readHermite (curT - 1.0f);
            }

            time.current = time.target = curT;
        }

        auto fl = (1.0f - s) * wl + s * wr;
        auto fr = (1.0f - s) * wr + s * wl;

        fl = lpL.tick (fl);
        fr = lpR.tick (fr);
        fl -= hpL.tick (fl);
        fr -= hpR.tick (fr);

        const auto xl = l[i], xr = r[i];
        const auto inL = lerp (xl, 0.5f * (xl + xr), s);
        const auto inR = xr * (1.0f - s);

        lineL.push (sanitize (inL + fb * fastTanh (fl)));
        lineR.push (sanitize (inR + fb * fastTanh (fr)));

        const auto dryG = std::sqrt (1.0f - m), wetG = std::sqrt (m);
        l[i] = xl * dryG + wl * wetG;
        r[i] = xr * dryG + wr * wetG;
    }
}

} // namespace libero
